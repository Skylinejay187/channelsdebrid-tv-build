package com.debridchannels.core.data

import com.debridchannels.core.model.CatalogRow
import com.debridchannels.core.model.MediaItem
import com.debridchannels.core.model.MediaType
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.net.HttpURLConnection
import java.net.URI

private const val manifestUrl = "https://catalog.skylinejay187.it.com/manifest.json"
private val yearPattern = Regex("""\b(?:18|19|20)\d{2}\b""")

private fun JsonObject.field(key: String): String? =
    get(key)?.takeIf { it.isJsonPrimitive }?.asString?.trim()?.takeIf { it.isNotEmpty() }

private fun JsonObject.objects(key: String) =
    get(key)?.takeIf { it.isJsonArray }?.asJsonArray?.mapNotNull { if (it.isJsonObject) it.asJsonObject else null }.orEmpty()

internal fun readCatalog(url: URI): String = requestCatalog(url, null)

private fun requestCatalog(url: URI, jsonBody: String?): String {
    val connection = url.toURL().openConnection() as HttpURLConnection
    try {
        connection.connectTimeout = if (jsonBody == null) 8000 else 4000
        connection.readTimeout = if (jsonBody == null) 12000 else 4000
        connection.instanceFollowRedirects = false
        connection.setRequestProperty("Accept", "application/json")
        if (jsonBody != null) {
            connection.requestMethod = "POST"
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json")
            connection.outputStream.use { it.write(jsonBody.toByteArray(Charsets.UTF_8)) }
        }
        check(connection.responseCode == 200) { "Catalog returned HTTP ${connection.responseCode}" }
        return connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
    } finally {
        connection.disconnect()
    }
}

data class OfficialCatalogBatch(
    val rows: List<CatalogRow>,
    val expectedRows: Int,
    val uniquelyDeclaredRowIds: Set<String> = emptySet(),
)

fun loadOfficialCatalog(fetch: (URI) -> String = ::readCatalog): List<CatalogRow> =
    loadOfficialCatalogBatch(fetch).rows

fun loadOfficialCatalogBatch(fetch: (URI) -> String = ::readCatalog): OfficialCatalogBatch {
    val manifest = JsonParser.parseString(fetch(URI(manifestUrl))).asJsonObject
    val endpoint = batchEndpoint(manifest)
    return CatalogMapper(manifest).full(JsonParser.parseString(fetch(endpoint)).asJsonObject.objects("rows"))
}

private fun batchEndpoint(manifest: JsonObject): URI {
    val source = URI(manifestUrl)
    val endpoint = source.resolve(requireNotNull(manifest.getAsJsonObject("debridChannels")?.field("batchRowsURL")))
    require(endpoint.scheme == "https" && endpoint.rawAuthority.equals(source.rawAuthority, true))
    return endpoint
}

private class CatalogMapper(manifest: JsonObject) {
    private val catalogs = manifest.objects("catalogs")
    private val declarations = catalogs.groupBy { it.field("id") }
    private val uniqueDeclarations = declarations.mapNotNull { (id, matches) ->
        val type = when (matches.singleOrNull()?.field("type")) {
            "movie" -> MediaType.MOVIE
            "series" -> MediaType.SHOW
            else -> return@mapNotNull null
        }
        id?.let { "${type.name}:$it" }
    }.toSet()

    fun row(row: JsonObject): CatalogRow? {
        val id = row.field("id") ?: return null
        val matches = declarations[id].orEmpty()
        val declaration = matches.singleOrNull() ?: matches.firstOrNull { it.field("type") == row.field("type") }
        val type = when (declaration?.field("type") ?: row.field("type")) {
            "movie" -> MediaType.MOVIE
            "series" -> MediaType.SHOW
            else -> return null
        }
        val items = row.objects("metas").mapNotNull { officialItem(it, type) }.distinctBy { it.id }
        if (items.isEmpty()) return null
        return CatalogRow("${type.name}:$id", row.field("name") ?: id, items = items)
    }

    fun batch(rows: List<CatalogRow>, sourceCount: Int): OfficialCatalogBatch {
        val unique = rows.distinctBy { it.id }
        require(unique.isNotEmpty()) { "Catalog contained no usable rows" }
        return OfficialCatalogBatch(unique, maxOf(sourceCount, catalogs.size), uniqueDeclarations)
    }

    fun full(rows: List<JsonObject>) = batch(rows.mapNotNull(::row), rows.size)
}

private val youtubeTrailerId = Regex("[A-Za-z0-9_-]{6,20}")

private fun JsonObject.previewUrl(): String? {
    for (key in listOf("previewVideo", "preview", "trailer")) {
        field(key)?.takeIf { it.startsWith("http") }?.let { return it }
    }
    for (trailer in objects("trailers")) {
        val source = trailer.field("source") ?: continue
        if (source.startsWith("http")) return source
        if (youtubeTrailerId.matches(source)) return "https://www.youtube.com/watch?v=$source"
    }
    for (video in objects("videos")) {
        val source = video.field("url") ?: video.field("src") ?: video.field("source")
        if (source != null && source.startsWith("http")) return source
    }
    return null
}

private fun officialItem(meta: JsonObject, type: MediaType): MediaItem? {
    val id = meta.field("id") ?: return null
    val title = meta.field("name") ?: return null
    fun image(key: String) = meta.field(key)?.let { catalogHeroArtwork(it, artworkBackend, false, false)?.baseUrl }
    val poster = image("poster") ?: return null
    val year = meta.field("releaseInfo")?.let { yearPattern.find(it)?.value?.toIntOrNull() }
    val genre = meta.get("genres")
    val genres = if (genre?.isJsonArray == true) genre.asJsonArray.filter { it.isJsonPrimitive }.map { it.asString }.take(3)
        else listOfNotNull(meta.field("genres"))
    return MediaItem(id, title, type, year, genres.joinToString(" • "),
        meta.field("description") ?: "No description available yet.", "", "",
        genres = genres, rating = meta.field("imdbRating")?.toDoubleOrNull(),
        landscapeUrl = image("background") ?: poster, posterUrl = poster,
        imdbId = meta.field("imdbId") ?: meta.field("imdb_id"),
        tmdbId = meta.field("tmdbId") ?: meta.field("tmdb_id"),
        tvdbId = meta.field("tvdbId") ?: meta.field("tvdb_id"), previewUrl = meta.previewUrl())
}

data class CatalogReloadResult(val batch: OfficialCatalogBatch, val failedRows: List<String>)

fun reloadOfficialCatalog(
    fetch: (URI) -> String = ::readCatalog,
    checkActive: () -> Unit = {},
): CatalogReloadResult {
    checkActive()
    val seed = loadOfficialCatalogBatch(fetch)
    val maximum = seed.rows.maxOf { it.items.size }
    val boundaries = setOf(12, 20, 24, 25, 30, 40, 48, 50, 60, 80, 96, 100)
    val failures = mutableListOf<String>()
    val rows = seed.rows.map { row ->
        checkActive()
        val count = row.items.size
        if (count < 12 || (count != maximum && count !in boundaries)) return@map row
        val type = row.items.first().type
        val protocolType = if (type == MediaType.MOVIE) "movie" else "series"
        val id = java.net.URLEncoder.encode(row.id.substringAfter(':'), "UTF-8").replace("+", "%20")
        val base = URI(manifestUrl).resolve("catalog/$protocolType/$id")
        val merged = row.items.toMutableList()
        val seen = merged.mapTo(mutableSetOf()) { it.id }
        var skip = count
        var pageFailed = false
        for (page in 1..8) {
            if (merged.size >= 500) break
            var rawCount = 0
            var validResponse = false
            for (url in listOf("$base.json?skip=$skip", "$base/skip=$skip.json")) {
                checkActive()
                val metas = try {
                    JsonParser.parseString(fetch(URI(url))).asJsonObject.getAsJsonArray("metas")
                        ?: error("Missing catalog metas")
                } catch (e: java.util.concurrent.CancellationException) {
                    throw e
                } catch (_: Exception) {
                    continue
                }
                validResponse = true
                val additions = metas.mapNotNull { element ->
                    if (element.isJsonObject) officialItem(element.asJsonObject, type) else null
                }.filter { seen.add(it.id) }
                if (additions.isEmpty()) continue
                merged.addAll(additions)
                rawCount = metas.size()
                break
            }
            if (!validResponse) {
                failures.add("${row.id} at offset $skip")
                pageFailed = true
            }
            if (rawCount < 8) break
            skip += rawCount
        }
        if (pageFailed && merged.size == count) row
        else row.copy(items = merged, pageSeedSize = count)
    }
    checkActive()
    return CatalogReloadResult(seed.copy(rows = rows), failures)
}

/** Revisions are valid only for the manifest that supplied their row presentation. */
class OfficialCatalogRefresh(
    private val fetch: (URI) -> String = ::readCatalog,
    private val post: (URI, String) -> String = { url, body -> requestCatalog(url, body) },
    private val nanos: () -> Long = System::nanoTime,
) {
    private data class Entry(val revision: String, val row: CatalogRow)
    private var previousManifest: JsonObject? = null
    private var entries: Map<String, Entry> = emptyMap()
    private var failedAt: Long? = null

    @Synchronized
    fun refresh(accept: (OfficialCatalogBatch) -> List<CatalogRow>): List<CatalogRow> {
        val manifest = JsonParser.parseString(fetch(URI(manifestUrl))).asJsonObject
        val source = batchEndpoint(manifest)
        val mapper = CatalogMapper(manifest)
        val failure = failedAt
        if (failure == null || nanos() - failure >= 60_000_000_000L) {
            try {
                val existing = if (manifest == previousManifest) entries else emptyMap()
                val next = fetchDelta(source, existing, mapper)
                val batch = mapper.batch(next.values.map { it.row }, next.size)
                require(batch.rows.size == next.size)
                val accepted = accept(batch)
                entries = next
                previousManifest = manifest
                failedAt = null
                return accepted
            } catch (e: java.util.concurrent.CancellationException) {
                throw e
            } catch (_: Exception) {
                failedAt = nanos()
            }
        }
        val full = JsonParser.parseString(fetch(source)).asJsonObject.objects("rows")
        return accept(mapper.full(full))
    }

    private fun fetchDelta(source: URI, existing: Map<String, Entry>, mapper: CatalogMapper): Map<String, Entry> {
        val known = JsonObject()
        existing.forEach { (key, entry) -> known.addProperty(key, entry.revision) }
        val request = JsonObject().apply {
            addProperty("source", source.toString())
            add("known", known)
        }
        val url = URI("$artworkBackend/api/catalog/rows/delta/v1")
        val response = JsonParser.parseString(post(url, request.toString())).asJsonObject
        val order = response.getAsJsonArray("order")
        require(order.size() in 1..256)
        val changes = response.getAsJsonArray("rows").iterator()
        val next = linkedMapOf<String, Entry>()
        for (element in order) {
            val revision = element.asJsonObject
            val key = revision.requiredString("key")
            val version = revision.requiredString("revision")
            require(key !in next)
            val prior = existing[key]
            next[key] = if (prior?.revision == version) prior else {
                require(changes.hasNext())
                val changed = changes.next().asJsonObject
                require(changed.requiredString("key") == key && changed.requiredString("revision") == version)
                Entry(version, requireNotNull(mapper.row(changed.get("row").asJsonObject)))
            }
        }
        require(!changes.hasNext())
        return next
    }

    private fun JsonObject.requiredString(key: String): String =
        requireNotNull(get(key)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }?.asString)
            .also { require(it.isNotBlank()) }
}
