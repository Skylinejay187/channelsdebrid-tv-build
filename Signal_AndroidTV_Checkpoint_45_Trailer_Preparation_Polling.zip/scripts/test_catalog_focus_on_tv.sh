#!/usr/bin/env bash
set -euo pipefail

# Prefer the newer of the available official TV system images up to API 35.
packages=$(sdkmanager --list)
image=$(awk -F'|' '{
    gsub(/[[:space:]]/, "", $1)
    if ($1 ~ /^system-images;android-(30|31|32|33|34|35);android-tv;x86(_64)?$/) print $1
}' <<< "$packages" | sort -Vu | tail -1)
if [[ -z "$image" ]]; then
    echo "No supported Android TV x86 SDK image is available." >&2
    exit 1
fi
sdkmanager "emulator" "$image"
echo no | avdmanager create avd --force --name signal-focus --package "$image"
if [[ -c /dev/kvm && ! -w /dev/kvm ]]; then
    sudo setfacl -m "u:$(id -un):rw" /dev/kvm
fi
export ANDROID_SERIAL=emulator-5554
"$ANDROID_HOME/emulator/emulator" -avd signal-focus -port 5554 -no-window -no-audio -no-boot-anim \
    -gpu swiftshader_indirect -no-snapshot -skin 1920x1080 > /tmp/signal-focus-emulator.log 2>&1 &
emulator_pid=$!
trap 'kill "$emulator_pid" 2>/dev/null || true' EXIT
for attempt in {1..120}; do
    if ! kill -0 "$emulator_pid" 2>/dev/null; then cat /tmp/signal-focus-emulator.log; exit 1; fi
    if [[ "$(adb shell getprop sys.boot_completed 2>/dev/null | tr -d '\r')" == 1 ]]; then break; fi
    sleep 2
done
[[ "$(adb shell getprop sys.boot_completed | tr -d '\r')" == 1 ]]
adb shell input keyevent KEYCODE_WAKEUP
adb shell wm dismiss-keyguard
gradle --no-daemon :app:connectedDebugAndroidTest \
    -Pandroid.testInstrumentationRunnerArguments.class=com.debridchannels.tv.CatalogDetailFocusTest,com.debridchannels.tv.MovieSourcePickerTest,com.debridchannels.tv.MovieStartupPlaybackTest
