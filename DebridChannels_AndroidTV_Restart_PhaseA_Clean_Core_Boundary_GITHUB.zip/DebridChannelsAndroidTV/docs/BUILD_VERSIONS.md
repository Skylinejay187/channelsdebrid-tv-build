# Build versions

- Android Gradle Plugin: 8.13.2
- Gradle wrapper: 8.13
- Kotlin: 2.3.21
- Compose BOM: 2026.06.00
- Compose for TV material: 1.1.0
- Compile SDK: 36
- Target SDK: 36
- Minimum SDK: 23
- Java toolchain: 17

## Restart Phase A application marker

- Version code: 2
- Version name: 0.2.0-restart-phase-a
- GitHub artifact: DebridChannels-AndroidTV-Restart-PhaseA
