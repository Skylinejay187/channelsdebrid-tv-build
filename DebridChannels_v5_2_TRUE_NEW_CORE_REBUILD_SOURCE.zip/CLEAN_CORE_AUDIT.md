# Debrid Channels v5.2 TRUE NEW CORE REBUILD Audit

Build marker: `DC_V5_2_TRUE_NEW_CORE_REBUILD`

## Result
This package is a fresh v5.2 Android project structure with new Java source under `app/src/main/java/com/channelsdebrid/tv`.

## Legacy carryover policy
- Old Kotlin/Java Activity stack: **not carried over**.
- Old `LiveTvActivity` conflict path: **not carried over**.
- Old Glide listener/fallback callback pattern: **not carried over**.
- Old settings persistence implementation: **not carried over**.
- Old patch-note stacked source pattern: **not carried over**.
- Visual assets/icons/logo artwork: **carried over only as UI assets**, not executable app logic.

## Rebuilt owners
- `NavigationController` — single app navigation owner.
- `PlayerManager` — single video playback attachment owner.
- `LiveTvStateMachine` — single Live TV category/guide/player state owner.
- `GuideCacheOwner` — single guide/channel cache owner.
- `TimeshiftEngine` — single timeshift capability owner.
- `UiStateStore` — single persistent settings/layout store.

## Functional surfaces recreated cleanly
- Hero top menu with icon placement setting.
- Settings surface with Pro Layout Editor entry.
- Persistent Pro Layout Editor controls.
- Stremio manifest/catalog loader path.
- M3U / Channels DVR URL loader path.
- Live TV DPAD rules: UP hero, RIGHT guide, LEFT categories.
- Player screen that uses one PlayerManager.

## Important honesty note
This is the first true-new-core migration package. It is intentionally free of copied legacy source, but it may still need iterative feature parity work to match every old v2.1.3 visual and playback behavior exactly. Future builds must extend this clean core, not copy old code back in.
