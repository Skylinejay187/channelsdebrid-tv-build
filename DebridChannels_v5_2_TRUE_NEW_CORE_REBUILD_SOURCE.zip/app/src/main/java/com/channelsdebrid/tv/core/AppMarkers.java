package com.channelsdebrid.tv.core;
public final class AppMarkers { public static final String BUILD="DC_V5_2_TRUE_NEW_CORE_REBUILD"; private AppMarkers(){} }
