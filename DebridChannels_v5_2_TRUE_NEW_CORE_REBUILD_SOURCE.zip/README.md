# Debrid Channels v5.2 TRUE NEW CORE REBUILD

Use `gradle assembleDebug` or `./gradlew assembleDebug` in CI environments pinned to Gradle 8.7.

Marker: `DC_V5_2_TRUE_NEW_CORE_REBUILD`
