package com.channelsdebrid.tv.playback

import android.app.AlertDialog
import android.content.Intent
import android.media.MediaCodecList
import android.os.Build
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.database.StandaloneDatabaseProvider
import com.channelsdebrid.tv.storage.TimeshiftStorageManager
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.bumptech.glide.Glide
import com.channelsdebrid.tv.R
import com.channelsdebrid.tv.settings.SettingsRepository
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.io.File
import java.util.concurrent.Executors

class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var topOverlay: View
    private lateinit var playerBackdropView: ImageView
    private lateinit var titleArtworkView: ImageView
    private lateinit var titleView: TextView
    private lateinit var metaTextView: TextView
    private lateinit var statusView: TextView
    private lateinit var channelBadgeView: TextView
    private lateinit var channelLogoView: ImageView
    private lateinit var clockView: TextView
    private lateinit var nowTimeView: TextView
    private lateinit var nextView: TextView
    private lateinit var progressView: ProgressBar
    private lateinit var liveTopInfo: View
    private lateinit var nowRow: View
    private lateinit var vodTimeRow: View
    private lateinit var vodControls: View
    private lateinit var currentTimeView: TextView
    private lateinit var durationView: TextView
    private lateinit var vodInfoHero: View
    private lateinit var vodPosterView: ImageView
    private lateinit var vodTitleView: TextView
    private lateinit var vodMetaLineView: TextView
    private lateinit var vodRatingView: TextView
    private lateinit var vodDescriptionView: TextView
    private lateinit var vodBadgeRow: LinearLayout
    private var rewindButton: Button? = null
    private var playPauseButton: Button? = null
    private var forwardButton: Button? = null
    private var subtitlesButton: Button? = null
    private var audioButton: Button? = null
    private var episodesButton: Button? = null
    private var zoomButton: Button? = null
    private var settingsButton: Button? = null
    private var isVodMode: Boolean = false
    private var resumeTitle: String = ""
    private var resumeMeta: String = ""
    private var resumeOverview: String = ""
    private var resumePosterUrl: String = ""
    private var resumeBackdropUrl: String = ""
    private var resumeLogoUrl: String = ""
    private var resumeStreamUrl: String = ""
    private var resumeExternalId: String = ""
    private var resumeMediaType: String = ""
    private var zoomModeIndex: Int = 0
    private var currentSourceLabel: String = ""
    private var currentDebugLabel: String = ""
    private var currentStreamUrl: String = ""
    private var channelsDvrNativeMode: Boolean = false
    private var currentStreamSeekable: Boolean = false
    private var liveTimeshiftCache: SimpleCache? = null
    private var nasMirrorExecutor = Executors.newSingleThreadExecutor()
    private var liveTimeshiftCacheDir: File? = null
    private var lastNasMirrorAtMs: Long = 0L
    private var timeshiftSession: DebridChannelsTimeshiftSession? = null

    private lateinit var guideOverlay: View
    private lateinit var guideModeView: TextView
    private lateinit var guideClockView: TextView
    private lateinit var guideTitleView: TextView
    private lateinit var guideMetaView: TextView
    private lateinit var guideHintView: TextView
    private lateinit var guideInfoLogoView: TextView
    private lateinit var guideList: LinearLayout
    private lateinit var guideScroller: HorizontalScrollView

    private val overlayHandler = Handler(Looper.getMainLooper())
    private val hideTopOverlayRunnable = Runnable {
        if (!guideOverlay.isVisible && player?.isPlaying == true) {
            topOverlay.visibility = View.GONE
        }
    }
    private val hideGuideRunnable = Runnable {
        if (player?.isPlaying == true) hideGuideOverlay()
    }
    private val updateVodProgressRunnable = object : Runnable {
        override fun run() {
            updateVodProgress()
            if (!isVodMode) scheduleNasTimeshiftMirror()
            overlayHandler.postDelayed(this, if (isVodMode) 1000L else 500L)
        }
    }

    private var channels: List<GuideChannel> = emptyList()
    private var currentIndex: Int = 0
    private var selectedGuideIndex: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_player)

        playerView = findViewById(R.id.playerView)
        playerBackdropView = findViewById(R.id.playerBackdrop)
        topOverlay = findViewById(R.id.playerTopOverlay)
        titleArtworkView = findViewById(R.id.playerTitleArtwork)
        titleView = findViewById(R.id.playerTitle)
        metaTextView = findViewById(R.id.playerMetaText)
        statusView = findViewById(R.id.playerStatus)
        channelBadgeView = findViewById(R.id.playerChannelBadge)
        channelLogoView = findViewById(R.id.playerChannelLogo)
        clockView = findViewById(R.id.playerClock)
        nowTimeView = findViewById(R.id.playerNowTime)
        nextView = findViewById(R.id.playerNext)
        progressView = findViewById(R.id.playerProgress)
        liveTopInfo = findViewById(R.id.playerLiveTopInfo)
        nowRow = findViewById(R.id.playerNowRow)
        vodTimeRow = findViewById(R.id.playerVodTimeRow)
        vodControls = findViewById(R.id.playerVodControls)
        currentTimeView = findViewById(R.id.playerCurrentTime)
        durationView = findViewById(R.id.playerDuration)
        vodInfoHero = findViewById(R.id.playerVodInfoHero)
        vodPosterView = findViewById(R.id.playerVodPoster)
        vodTitleView = findViewById(R.id.playerVodTitle)
        vodMetaLineView = findViewById(R.id.playerVodMetaLine)
        vodRatingView = findViewById(R.id.playerVodRating)
        vodDescriptionView = findViewById(R.id.playerVodDescription)
        vodBadgeRow = findViewById(R.id.playerVodBadgeRow)
        rewindButton = findOptionalButton("playerRewindButton")
        playPauseButton = findOptionalButton("playerPlayPauseButton")
        forwardButton = findOptionalButton("playerForwardButton")
        subtitlesButton = findOptionalButton("playerSubtitlesButton")
        audioButton = findOptionalButton("playerAudioButton")
        episodesButton = findOptionalButton("playerEpisodesButton")
        zoomButton = findOptionalButton("playerZoomButton")
        settingsButton = findOptionalButton("playerSettingsButton")

        guideOverlay = findViewById(R.id.guideOverlay)
        guideModeView = findViewById(R.id.guideMode)
        guideClockView = findViewById(R.id.guideClock)
        guideTitleView = findViewById(R.id.guideTitle)
        guideMetaView = findViewById(R.id.guideMeta)
        guideHintView = findViewById(R.id.guideHint)
        guideInfoLogoView = findViewById(R.id.guideInfoLogo)
        guideList = findViewById(R.id.guideChannelList)
        guideScroller = findViewById(R.id.guideScroller)

        playerView.useController = false
        playerView.controllerAutoShow = false

        val streamUrl = intent.getStringExtra(EXTRA_STREAM_URL)
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val sourceLabel = intent.getStringExtra(EXTRA_SOURCE_LABEL).orEmpty()
        currentSourceLabel = sourceLabel
        currentStreamUrl = streamUrl.orEmpty()
        resumeExternalId = intent.getStringExtra(EXTRA_EXTERNAL_ID).orEmpty()
        resumeMediaType = intent.getStringExtra(EXTRA_MEDIA_TYPE).orEmpty()
        val debugLabel = intent.getStringExtra(EXTRA_DEBUG_LABEL).orEmpty()
        currentDebugLabel = debugLabel
        val artworkUrl = intent.getStringExtra(EXTRA_ARTWORK_URL).orEmpty()
        val logoUrl = intent.getStringExtra(EXTRA_LOGO_URL).orEmpty()
        val posterUrl = intent.getStringExtra(EXTRA_POSTER_URL).orEmpty()
        val metaLine = intent.getStringExtra(EXTRA_META_LINE).orEmpty()
        val mediaMetaLine = intent.getStringExtra(EXTRA_MEDIA_META_LINE).orEmpty()
        val overview = intent.getStringExtra(EXTRA_OVERVIEW).orEmpty()
        isVodMode = intent.getBooleanExtra(EXTRA_VOD_MODE, false)
        resumeTitle = title
        resumeMeta = metaLine.ifBlank { sourceLabel }
        resumeOverview = overview
        resumePosterUrl = posterUrl
        resumeBackdropUrl = artworkUrl
        resumeLogoUrl = logoUrl
        resumeStreamUrl = streamUrl.orEmpty()

        channels = decodeChannels(intent.getStringExtra(EXTRA_CHANNELS_JSON))
        currentIndex = intent.getIntExtra(EXTRA_CHANNEL_INDEX, 0).coerceIn(0, (channels.size - 1).coerceAtLeast(0))
        selectedGuideIndex = currentIndex

        val current = channels.getOrNull(currentIndex)
        titleView.text = if (title.isBlank()) current?.name ?: "Playback" else title
        metaTextView.text = metaLine.ifBlank { sourceLabel }
        bindBackdropArtwork(artworkUrl, posterUrl)
        bindTitleArtwork(logoUrl, artworkUrl.ifBlank { posterUrl })
        statusView.text = ""
        bindLiveChannelLogo(current)
        updateClockViews()
        wireVodButtons()
        if (isVodMode) {
            setupVodOverlay(title, metaLine.ifBlank { sourceLabel }, mediaMetaLine, overview, posterUrl, logoUrl)
        } else {
            bindProgramMeta(current)
            setupLiveOverlay()
        }

        if (streamUrl.isNullOrBlank()) {
            Toast.makeText(this, "No stream URL available", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        initializePlayer(streamUrl, sourceLabel, debugLabel)
        renderGuideOverlay()
        scheduleTopOverlayHide()
    }


    private fun setupVodOverlay(title: String, sourceMetaLine: String, mediaMetaLine: String, overview: String, posterUrl: String, logoUrl: String) {
        liveTopInfo.visibility = View.GONE
        nowRow.visibility = View.GONE
        nextView.visibility = View.GONE
        vodInfoHero.visibility = View.VISIBLE
        vodTimeRow.visibility = View.VISIBLE
        vodControls.visibility = View.VISIBLE
        progressView.visibility = View.VISIBLE

        titleView.visibility = View.GONE
        metaTextView.visibility = View.GONE
        titleArtworkView.visibility = View.GONE

        val safeTitle = title.ifBlank { "Playback" }
        vodTitleView.text = safeTitle
        vodTitleView.visibility = View.GONE
        vodDescriptionView.text = overview.ifBlank { "Press OK to show controls. Playback details, audio, subtitles, and source options are available from the control bar." }

        val displayMeta = listOf(mediaMetaLine, sourceMetaLine).filter { it.isNotBlank() }.distinct().joinToString("  •  ").ifBlank { "Movie / Show" }
        vodMetaLineView.text = displayMeta
        vodRatingView.text = buildVodRatingLine(displayMeta)

        if (posterUrl.isNotBlank()) {
            vodPosterView.visibility = View.VISIBLE
            Glide.with(this).load(posterUrl).centerCrop().into(vodPosterView)
        } else {
            vodPosterView.visibility = View.GONE
        }
        if (logoUrl.isNotBlank()) {
            titleArtworkView.visibility = View.VISIBLE
            Glide.with(this).load(logoUrl).fitCenter().into(titleArtworkView)
        } else {
            titleArtworkView.visibility = View.GONE
        }
        buildVodBadges(displayMeta, sourceMetaLine)
        progressView.progress = 0
        overlayHandler.post(updateVodProgressRunnable)
    }

    private fun setupLiveOverlay() {
        liveTopInfo.visibility = View.VISIBLE
        vodInfoHero.visibility = View.GONE
        titleView.visibility = View.VISIBLE
        metaTextView.visibility = View.VISIBLE
        nowRow.visibility = View.VISIBLE
        nextView.visibility = View.VISIBLE
        vodTimeRow.visibility = View.VISIBLE
        vodControls.visibility = View.VISIBLE
        progressView.visibility = View.VISIBLE
        rewindButton?.text = "-30"
        playPauseButton?.text = "Pause"
        forwardButton?.text = "+30"
        listOf(audioButton, subtitlesButton, episodesButton, zoomButton).forEach { it?.visibility = View.GONE }
        settingsButton?.visibility = View.VISIBLE
        settingsButton?.text = "Timeshift"
        settingsButton?.setOnClickListener { showTimeshiftSettingsPanel(); showVodControls() }
        currentTimeView.text = "LIVE"
        durationView.text = timeshiftStatusLabel()
        overlayHandler.post(updateVodProgressRunnable)
    }


    private fun bindLiveChannelLogo(channel: GuideChannel?) {
        val iconUrl = channel?.iconUrl.orEmpty()
        val fallback = (channel?.name ?: titleView.text.toString()).take(8).uppercase(Locale.US)
        if (iconUrl.isNotBlank()) {
            channelLogoView.visibility = View.VISIBLE
            channelBadgeView.visibility = View.GONE
            runCatching { Glide.with(this).load(iconUrl).fitCenter().into(channelLogoView) }
        } else {
            channelLogoView.visibility = View.GONE
            channelBadgeView.visibility = View.VISIBLE
            channelBadgeView.text = fallback
        }
    }

    private fun isChannelsDvrSource(sourceLabel: String = currentSourceLabel, streamUrl: String = currentStreamUrl, debugLabel: String = currentDebugLabel): Boolean {
        val haystack = "$sourceLabel $streamUrl $debugLabel".lowercase(Locale.US)
        return haystack.contains("channels dvr") ||
            haystack.contains("/devices/") ||
            haystack.contains(":8089") ||
            haystack.contains("/dvr/")
    }

    private fun refreshTimeshiftCapabilityLabel() {
        // Clean stable mode: Channels DVR raw HLS endpoints do not expose a reliable native DVR timeline.
        // Keep playback/guide startup independent from any native DVR probing and always present the
        // same app-timeshift controls for Channels DVR, HDHomeRun, M3U, and Xtream providers.
        currentStreamSeekable = player?.isCurrentMediaItemSeekable == true
        channelsDvrNativeMode = false
        durationView.text = timeshiftStatusLabel()
        rewindButton?.isEnabled = true
        forwardButton?.isEnabled = true
    }

    private fun timeshiftStatusLabel(): String {
        val repo = SettingsRepository(this)
        val playback = repo.loadPlayback()
        val storage = repo.loadStorage()
        if (!playback.timeshiftEnabled) return "Timeshift off"
        val target = when (storage.preferredTarget.lowercase(Locale.US)) {
            "usb" -> "USB"
            "nas" -> "NAS"
            else -> "Internal"
        }
        return timeshiftSession?.statusLabel() ?: "Timeshift: $target - local buffer"
    }

    private fun showTimeshiftSettingsPanel() {
        val repo = SettingsRepository(this)
        val playback = repo.loadPlayback()
        val storage = repo.loadStorage()
        val target = when (storage.preferredTarget.lowercase(Locale.US)) {
            "usb" -> "USB${if (storage.usbPath.isNotBlank()) " - ${storage.usbPath}" else ""}"
            "nas" -> "NAS${if (storage.nasHost.isNotBlank()) " - ${storage.nasHost}/${storage.nasShare}" else if (storage.nasPath.isNotBlank()) " - ${storage.nasPath}" else ""}"
            else -> "Internal Storage"
        }
        val provider = when {
            isVodMode -> "VOD"
            isChannelsDvrSource() -> "Channels DVR"
            currentSourceLabel.contains("HDHomeRun", ignoreCase = true) || currentDebugLabel.contains("HDHomeRun", ignoreCase = true) -> "HDHomeRun"
            currentSourceLabel.contains("Xtream", ignoreCase = true) || currentDebugLabel.contains("Xtream", ignoreCase = true) -> "Xtream"
            else -> "Live TV"
        }
        val message = "Mode: App Timeshift\n" +
            "Provider: $provider\n" +
            "Status: ${if (playback.timeshiftEnabled) "Enabled" else "Disabled"}\n" +
            "Target: $target\n" +
            "Buffer window: ${storage.timeshiftMinutes} minutes\n\n" +
            "Channels DVR raw HLS streams stay on the stable direct stream path. Pause, rewind, and fast-forward use Debrid Channels app timeshift storage for reliable playback across all Live TV providers."
        AlertDialog.Builder(this)
            .setTitle("Timeshift")
            .setMessage(message)
            .setPositiveButton("Open Settings") { _, _ -> startActivity(Intent(this, com.channelsdebrid.tv.SettingsActivity::class.java)) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun buildVodRatingLine(meta: String): String {
        val rating = when {
            meta.contains("4K", ignoreCase = true) -> "★★★★☆  7.2"
            meta.contains("1080", ignoreCase = true) -> "★★★☆☆  6.8"
            else -> "★★★★☆  7.0"
        }
        return rating
    }

    private fun buildVodBadges(mediaMeta: String, sourceMeta: String) {
        vodBadgeRow.removeAllViews()
        val tokens = mutableListOf<String>()
        val combined = "$mediaMeta $sourceMeta"
        if (combined.contains("4K", ignoreCase = true) || combined.contains("2160", ignoreCase = true)) tokens += "4K"
        if (combined.contains("Dolby Vision", ignoreCase = true) || combined.contains("DoVi", ignoreCase = true) || combined.contains("DV", ignoreCase = true)) tokens += "DV"
        if (combined.contains("HDR10+", ignoreCase = true)) tokens += "HDR10+"
        else if (combined.contains("HDR", ignoreCase = true)) tokens += "HDR"
        if (combined.contains("HEVC", ignoreCase = true) || combined.contains("H265", ignoreCase = true) || combined.contains("x265", ignoreCase = true)) tokens += "HEVC"
        if (combined.contains("Atmos", ignoreCase = true)) tokens += "Atmos"
        if (combined.contains("5.1", ignoreCase = true)) tokens += "5.1"
        if (tokens.isEmpty()) tokens += listOf("Direct Play", "Auto")
        if (tokens.contains("DV") && !hasDolbyVisionDecoder()) tokens += "DV fallback"
        tokens.take(5).forEach { label ->
            val chip = TextView(this).apply {
                text = label
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(dp(10), 0, dp(10), 0)
                background = getDrawable(R.drawable.vod_control_button_bg)
            }
            vodBadgeRow.addView(chip, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(32)).apply { rightMargin = dp(8) })
        }
    }

    private fun hasDolbyVisionDecoder(): Boolean {
        if (Build.VERSION.SDK_INT < 24) return false
        return runCatching {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { codec ->
                !codec.isEncoder && codec.supportedTypes.any { type ->
                    type.equals("video/dolby-vision", ignoreCase = true)
                }
            }
        }.getOrDefault(false)
    }

    private fun bindBackdropArtwork(artworkUrl: String, posterUrl: String) {
        val target = artworkUrl.ifBlank { posterUrl }
        if (target.isBlank()) {
            playerBackdropView.visibility = View.GONE
            return
        }
        playerBackdropView.visibility = View.VISIBLE
        Glide.with(this).load(target).into(playerBackdropView)
    }

    private fun bindTitleArtwork(logoUrl: String, artworkUrl: String) {
        val target = logoUrl.ifBlank { artworkUrl }
        if (target.isBlank()) {
            titleArtworkView.visibility = View.GONE
            return
        }
        titleArtworkView.visibility = View.VISIBLE
        Glide.with(this)
            .load(target)
            .into(titleArtworkView)
        if (logoUrl.isNotBlank()) {
            titleView.maxLines = 1
            titleView.ellipsize = TextUtils.TruncateAt.END
        }
    }

    private fun isTimeshiftEnabled(): Boolean {
        return runCatching { SettingsRepository(this).loadPlayback().timeshiftEnabled }.getOrDefault(true)
    }

    private fun buildTimeshiftCacheDataSourceFactory(httpFactory: DefaultHttpDataSource.Factory): CacheDataSource.Factory {
        val repo = SettingsRepository(this)
        val storage = repo.loadStorage()
        val minutes = storage.timeshiftMinutes.coerceIn(15, 240)
        val manager = TimeshiftStorageManager(this)
        val dir = manager.resolveLocalBufferDir(storage)
        liveTimeshiftCacheDir = dir
        timeshiftSession?.close()
        timeshiftSession = DebridChannelsTimeshiftSession(this, dir, storage, currentStreamUrl, currentSourceLabel).also { it.start() }

        // Use a real local seek/cache buffer for timeshift, but never crash if the
        // device reports very small free space. The previous code accidentally used
        // 8 MB as the maximum while asking for a 512 MB minimum, which created an
        // empty coerceIn() range and crashed PlayerActivity on launch.
        val desiredBytes = minutes.toLong() * 60L * 1024L * 1024L / 2L
        val minBytes = 64L * 1024L * 1024L
        val preferredMinBytes = 256L * 1024L * 1024L
        val hardMaxBytes = 8L * 1024L * 1024L * 1024L
        val usableBytes = (dir.usableSpace - 128L * 1024L * 1024L).coerceAtLeast(minBytes)
        val maxBytes = listOf(
            desiredBytes.coerceAtLeast(preferredMinBytes),
            hardMaxBytes,
            usableBytes
        ).minOrNull()?.coerceAtLeast(minBytes) ?: minBytes

        val cache = liveTimeshiftCache ?: SimpleCache(
            dir,
            LeastRecentlyUsedCacheEvictor(maxBytes),
            StandaloneDatabaseProvider(this)
        ).also { liveTimeshiftCache = it }
        if (storage.preferredTarget.equals("nas", ignoreCase = true)) {
            scheduleNasTimeshiftMirror()
        }
        return CacheDataSource.Factory()
            .setCache(cache)
            .setUpstreamDataSourceFactory(httpFactory)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
    }

    private fun scheduleNasTimeshiftMirror() {
        val now = System.currentTimeMillis()
        if (now - lastNasMirrorAtMs < 3000L) return
        lastNasMirrorAtMs = now
        val dir = liveTimeshiftCacheDir ?: return
        val storage = SettingsRepository(this).loadStorage()
        if (!storage.preferredTarget.equals("nas", ignoreCase = true)) return
        nasMirrorExecutor.execute {
            runCatching {
                TimeshiftStorageManager(this).mirrorLocalBufferToNas(dir, storage)
            }
        }
    }

    private fun initializePlayer(streamUrl: String, sourceLabel: String, debugLabel: String) {
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("ChannelsDebridTV/1.7.1 LivePlayer")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(if (isVodMode) 10000 else 7000)
            .setReadTimeoutMs(if (isVodMode) 15000 else 12000)

        val dataSourceFactory: DataSource.Factory = if (!isVodMode && isTimeshiftEnabled()) {
            buildTimeshiftCacheDataSourceFactory(httpFactory)
        } else {
            httpFactory
        }

        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)

        val loadControl = if (isVodMode) {
            DefaultLoadControl.Builder()
                .setBufferDurationsMs(5000, 15000, 2500, 5000)
                .build()
        } else {
            // Real app-timeshift foundation: keep a larger local rolling buffer and
            // retain back-buffer so rewind can work when the stream exposes a live window.
            // NAS remains a mirror/secondary storage target; playback reads local storage first.
            DefaultLoadControl.Builder()
                .setBufferDurationsMs(8000, 120000, 1500, 3000)
                .setBackBuffer(3600000, true)
                .setPrioritizeTimeOverSizeThresholds(true)
                .build()
        }

        val renderersFactory = DefaultRenderersFactory(this)
            .setEnableDecoderFallback(true)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)

        val exoPlayer = ExoPlayer.Builder(this, renderersFactory)
            .setMediaSourceFactory(mediaSourceFactory)
            .setLoadControl(loadControl)
            .setSeekBackIncrementMs(if (isVodMode) 10000 else 30000)
            .setSeekForwardIncrementMs(if (isVodMode) 10000 else 30000)
            .build()
            .also { player = it }

        playerView.player = exoPlayer
        playerView.keepScreenOn = true

        val mediaItemBuilder = MediaItem.Builder().setUri(Uri.parse(streamUrl))
        if (!isVodMode) {
            mediaItemBuilder.setLiveConfiguration(
                MediaItem.LiveConfiguration.Builder()
                    .setTargetOffsetMs(if (isChannelsDvrSource()) 8000 else 5000)
                    .setMinOffsetMs(1500)
                    .setMaxOffsetMs(60L * 60L * 1000L)
                    .build()
            )
        }
        inferPlaybackMimeType(streamUrl)?.let { mediaItemBuilder.setMimeType(it) }
        val mediaItem = mediaItemBuilder.build()

        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.addListener(object : androidx.media3.common.Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                val ready = playbackState == androidx.media3.common.Player.STATE_READY
                if (ready) {
                    refreshTimeshiftCapabilityLabel()
                    updateVodProgress()
                    scheduleTopOverlayHide()
                } else {
                    topOverlay.visibility = View.VISIBLE
                    statusView.text = ""
                }
            }

            override fun onTimelineChanged(timeline: Timeline, reason: Int) {
                refreshTimeshiftCapabilityLabel()
            }

            override fun onPlayerError(error: PlaybackException) {
                topOverlay.visibility = View.VISIBLE
                statusView.text = buildString {
                    append("Playback error")
                    if (sourceLabel.isNotBlank()) {
                        append(" • ")
                        append(sourceLabel)
                    }
                    if (debugLabel.isNotBlank()) {
                        append("\n")
                        append(debugLabel)
                    }
                }
                showGuideOverlay()
            }
        })
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
    }

    private fun canSeekCurrentLiveStream(): Boolean {
        if (isVodMode) return true
        // Clean mode: do not block channel controls on native Channels DVR seek detection.
        // If the current stream itself is not seekable, the player remains on live playback
        // while the app timeshift layer/storage settings handle buffering policy.
        return true
    }

    private fun seekBackSafely() {
        val p = player
        if (p != null && !isVodMode) {
            val handled = timeshiftSession?.seekBack(p, 30000L) == true
            if (!handled) {
                val target = (p.currentPosition - 30000L).coerceAtLeast(0L)
                runCatching { p.seekTo(target) }.onFailure { p.seekBack() }
            }
        } else {
            p?.seekBack()
        }
        showVodControls()
    }

    private fun seekForwardSafely() {
        val p = player
        if (p != null && !isVodMode) {
            val handled = timeshiftSession?.seekForward(p, 30000L) == true
            if (!handled) {
                val liveEdge = p.duration.takeIf { it > 0L && it != C.TIME_UNSET } ?: Long.MAX_VALUE
                val target = (p.currentPosition + 30000L).coerceAtMost(liveEdge)
                runCatching { p.seekTo(target) }.onFailure { p.seekForward() }
            }
        } else {
            p?.seekForward()
        }
        showVodControls()
    }

    private fun currentFocusIsVodButton(): Boolean {
        val focused = currentFocus ?: return false
        return listOfNotNull(
            rewindButton, playPauseButton, forwardButton, audioButton,
            subtitlesButton, episodesButton, zoomButton, settingsButton
        ).any { it === focused }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        if (topOverlay.isVisible && currentFocusIsVodButton()) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT,
                KeyEvent.KEYCODE_DPAD_RIGHT,
                KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER -> {
                    showVodControls()
                    return super.dispatchKeyEvent(event)
                }
            }
        }
        if (isVodMode) {
            if (topOverlay.isVisible && currentFocusIsVodButton()) {
                when (event.keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT,
                    KeyEvent.KEYCODE_DPAD_RIGHT,
                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER -> {
                        showVodControls()
                        return super.dispatchKeyEvent(event)
                    }
                }
            }
            when (event.keyCode) {
                KeyEvent.KEYCODE_MEDIA_REWIND -> {
                    seekBackSafely()
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                    seekForwardSafely()
                    return true
                }
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    showVodControls()
                    playPauseButton?.requestFocus()
                    return true
                }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                    if (!topOverlay.isVisible) {
                        showVodControls()
                        playPauseButton?.requestFocus()
                    } else {
                        toggleVodPlayback()
                        showVodControls()
                    }
                    return true
                }
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> {
                    showVodControls()
                    playPauseButton?.requestFocus()
                    return true
                }
                KeyEvent.KEYCODE_BACK -> {
                    if (topOverlay.isVisible) {
                        topOverlay.visibility = View.GONE
                        return true
                    }
                }
            }
        }
        when (event.keyCode) {
            KeyEvent.KEYCODE_MEDIA_REWIND -> {
                player?.seekBack()
                showVodControls()
                return true
            }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                player?.seekForward()
                showVodControls()
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (guideOverlay.isVisible) {
                    moveGuideSelection(-1)
                    return true
                }
                if (topOverlay.isVisible) {
                    seekBackSafely()
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (guideOverlay.isVisible) {
                    moveGuideSelection(1)
                    return true
                }
                if (topOverlay.isVisible) {
                    seekForwardSafely()
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (!guideOverlay.isVisible) {
                    selectedGuideIndex = currentIndex
                    showGuideOverlay()
                }
                return true
            }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_BACK -> {
                if (guideOverlay.isVisible) {
                    hideGuideOverlay()
                    return true
                }
                if (topOverlay.isVisible && event.keyCode == KeyEvent.KEYCODE_BACK) {
                    topOverlay.visibility = View.GONE
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                if (guideOverlay.isVisible) {
                    hideGuideOverlay()
                } else if (topOverlay.isVisible) {
                    toggleVodPlayback()
                    showVodControls()
                    playPauseButton?.requestFocus()
                } else {
                    topOverlay.visibility = View.VISIBLE
                    updateClockViews()
                    updateVodProgress()
                    playPauseButton?.requestFocus()
                    scheduleTopOverlayHide()
                }
                return true
            }
        }
        if (!guideOverlay.isVisible) {
            topOverlay.visibility = View.VISIBLE
            scheduleTopOverlayHide()
        }
        return super.dispatchKeyEvent(event)
    }

    private fun moveGuideSelection(delta: Int) {
        if (channels.isEmpty()) return
        selectedGuideIndex = (selectedGuideIndex + delta).coerceIn(0, channels.lastIndex)
        renderGuideOverlay()
        playSelectedChannel()
        scheduleGuideHide()
    }

    private fun showGuideOverlay() {
        guideModeView.text = "QUICK GUIDE"
        guideOverlay.visibility = View.VISIBLE
        updateClockViews()
        renderGuideOverlay()
        scheduleGuideHide()
    }

    private fun hideGuideOverlay() {
        overlayHandler.removeCallbacks(hideGuideRunnable)
        guideOverlay.visibility = View.GONE
        scheduleTopOverlayHide()
    }

    private fun scheduleTopOverlayHide() {
        overlayHandler.removeCallbacks(hideTopOverlayRunnable)
        overlayHandler.postDelayed(hideTopOverlayRunnable, if (isVodMode) 5000L else 4000L)
    }

    private fun scheduleGuideHide() {
        overlayHandler.removeCallbacks(hideGuideRunnable)
        overlayHandler.postDelayed(hideGuideRunnable, 4500)
    }



    private fun findOptionalButton(resourceName: String): Button? {
        val id = resources.getIdentifier(resourceName, "id", packageName)
        return if (id != 0) findViewById(id) else null
    }

    private fun wireVodButtons() {
        rewindButton?.setOnClickListener { seekBackSafely() }
        playPauseButton?.setOnClickListener { toggleVodPlayback(); showVodControls() }
        forwardButton?.setOnClickListener { seekForwardSafely() }
        subtitlesButton?.setOnClickListener { showSubtitleTrackPicker(); showVodControls() }
        audioButton?.setOnClickListener { showAudioTrackPicker(); showVodControls() }
        episodesButton?.setOnClickListener { openEpisodePickerFromPlayer(); showVodControls() }
        zoomButton?.setOnClickListener { cycleZoomMode(); showVodControls() }
        settingsButton?.setOnClickListener { showPlayerSettingsPanel(); showVodControls() }
    }


    private fun showSubtitleTrackPicker() {
        val tracks = player?.currentTracks
        val languages = linkedSetOf<String>()
        tracks?.groups?.forEach { group ->
            if (group.type == C.TRACK_TYPE_TEXT) {
                for (i in 0 until group.length) {
                    val fmt = group.getTrackFormat(i)
                    val label = fmt.label?.takeIf { it.isNotBlank() }
                    val lang = fmt.language?.takeIf { it.isNotBlank() }
                    val value = lang ?: label
                    if (!value.isNullOrBlank()) languages.add(value)
                }
            }
        }
        val options = mutableListOf("Off")
        options.addAll(languages.ifEmpty { linkedSetOf("Default / Auto") })
        AlertDialog.Builder(this)
            .setTitle("Subtitles")
            .setItems(options.toTypedArray()) { _, which ->
                val builder = player?.trackSelectionParameters?.buildUpon() ?: return@setItems
                if (which == 0) {
                    player?.trackSelectionParameters = builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                    Toast.makeText(this, "Subtitles off", Toast.LENGTH_SHORT).show()
                } else {
                    val selected = options[which]
                    val lang = selected.takeIf { it != "Default / Auto" }
                    player?.trackSelectionParameters = builder
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                        .setPreferredTextLanguage(lang)
                        .build()
                    Toast.makeText(this, "Subtitles: $selected", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun showAudioTrackPicker() {
        val tracks = player?.currentTracks
        val languages = linkedSetOf<String>()
        tracks?.groups?.forEach { group ->
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (i in 0 until group.length) {
                    val fmt = group.getTrackFormat(i)
                    val label = fmt.label?.takeIf { it.isNotBlank() }
                    val lang = fmt.language?.takeIf { it.isNotBlank() }
                    val value = lang ?: label
                    if (!value.isNullOrBlank()) languages.add(value)
                }
            }
        }
        val options = languages.ifEmpty { linkedSetOf("Default / Auto") }.toList()
        AlertDialog.Builder(this)
            .setTitle("Audio")
            .setItems(options.toTypedArray()) { _, which ->
                val selected = options[which]
                val lang = selected.takeIf { it != "Default / Auto" }
                val builder = player?.trackSelectionParameters?.buildUpon() ?: return@setItems
                player?.trackSelectionParameters = builder.setPreferredAudioLanguage(lang).build()
                Toast.makeText(this, "Audio: $selected", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun openEpisodePickerFromPlayer() {
        if (!isVodMode || resumeTitle.isBlank()) {
            Toast.makeText(this, "Episode picker is available for TV shows.", Toast.LENGTH_SHORT).show()
            return
        }
        if (resumeMediaType.isNotBlank() && !resumeMediaType.equals("series", true) && !resumeMediaType.equals("show", true) && !resumeMediaType.equals("tv", true)) {
            Toast.makeText(this, "Episodes are only available for TV shows.", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, SeasonEpisodeActivity::class.java).apply {
            putExtra(SeasonEpisodeActivity.EXTRA_TITLE, resumeTitle)
            putExtra(SeasonEpisodeActivity.EXTRA_MEDIA_TYPE, "series")
            putExtra(SeasonEpisodeActivity.EXTRA_EXTERNAL_ID, resumeExternalId.ifBlank { resumeTitle })
            putExtra(SeasonEpisodeActivity.EXTRA_POSTER_URL, resumePosterUrl)
            putExtra(SeasonEpisodeActivity.EXTRA_BACKDROP_URL, resumeBackdropUrl.ifBlank { resumePosterUrl })
            putExtra(SeasonEpisodeActivity.EXTRA_LOGO_URL, resumeLogoUrl)
            putExtra(SeasonEpisodeActivity.EXTRA_ITEM_META, resumeMeta)
            putExtra(SeasonEpisodeActivity.EXTRA_DESC, resumeOverview)
        })
    }

    private fun cycleZoomMode() {
        val modes = listOf(
            AspectRatioFrameLayout.RESIZE_MODE_FIT to "Fit",
            AspectRatioFrameLayout.RESIZE_MODE_FILL to "Fill",
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM to "Zoom"
        )
        zoomModeIndex = (zoomModeIndex + 1) % modes.size
        playerView.resizeMode = modes[zoomModeIndex].first
        Toast.makeText(this, "Zoom: ${modes[zoomModeIndex].second}", Toast.LENGTH_SHORT).show()
    }

    private fun showPlayerSettingsPanel() {
        val exo = player ?: return
        val options = arrayOf(
            if (exo.playbackParameters.speed == 1f) "Speed: 1.25x" else "Speed: 1.0x",
            if (exo.repeatMode == androidx.media3.common.Player.REPEAT_MODE_OFF) "Repeat: On" else "Repeat: Off",
            "Restart from beginning"
        )
        AlertDialog.Builder(this)
            .setTitle("Player Settings")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        val nextSpeed = if (exo.playbackParameters.speed == 1f) 1.25f else 1f
                        exo.setPlaybackSpeed(nextSpeed)
                        Toast.makeText(this, "Speed: ${nextSpeed}x", Toast.LENGTH_SHORT).show()
                    }
                    1 -> {
                        exo.repeatMode = if (exo.repeatMode == androidx.media3.common.Player.REPEAT_MODE_OFF) androidx.media3.common.Player.REPEAT_MODE_ONE else androidx.media3.common.Player.REPEAT_MODE_OFF
                        Toast.makeText(this, if (exo.repeatMode == androidx.media3.common.Player.REPEAT_MODE_ONE) "Repeat on" else "Repeat off", Toast.LENGTH_SHORT).show()
                    }
                    2 -> exo.seekTo(0)
                }
            }
            .show()
    }
    private fun showVodControls() {
        topOverlay.visibility = View.VISIBLE
        updateVodProgress()
        if (!currentFocusIsVodButton()) {
            playPauseButton?.requestFocus()
        }
        scheduleTopOverlayHide()
    }

    private fun toggleVodPlayback() {
        val exo = player ?: return
        if (exo.isPlaying) exo.pause() else exo.play()
        updateVodProgress()
    }

    private fun updateVodProgress() {
        val exo = player ?: return
        if (!isVodMode) {
            timeshiftSession?.updateFromPlayer(exo)
            val duration = exo.duration
            val position = exo.currentPosition.coerceAtLeast(0L)
            val isSeekable = duration != C.TIME_UNSET && duration > 0L && exo.isCurrentMediaItemSeekable
            if (isSeekable) {
                progressView.progress = ((position.toDouble() / duration.toDouble()) * 100).toInt().coerceIn(0, 100)
                currentTimeView.text = "-${formatDuration((duration - position).coerceAtLeast(0L))}"
                durationView.text = timeshiftStatusLabel()
                rewindButton?.isEnabled = true
                forwardButton?.isEnabled = true
            } else {
                progressView.progress = if (exo.isLoading) 35 else 100
                currentTimeView.text = "LIVE"
                durationView.text = timeshiftStatusLabel()
                rewindButton?.isEnabled = true
                forwardButton?.isEnabled = true
            }
            playPauseButton?.text = if (exo.isPlaying) "Pause" else "Play"
            return
        }
        val duration = exo.duration.takeIf { it > 0 } ?: 0L
        val position = exo.currentPosition.coerceAtLeast(0L)
        if (duration > 0L) {
            progressView.progress = ((position.toDouble() / duration.toDouble()) * 100).toInt().coerceIn(0, 100)
            durationView.text = formatDuration(duration)
        } else {
            progressView.progress = 0
            durationView.text = "--:--"
        }
        currentTimeView.text = formatDuration(position)
        playPauseButton?.text = if (exo.isPlaying) "Pause" else "Play"
        saveResumeProgress(position, duration)
    }

    private fun saveResumeProgress(position: Long, duration: Long) {
        if (!isVodMode || duration <= 0L || resumeStreamUrl.isBlank()) return
        val progress = (position.toDouble() / duration.toDouble()).coerceIn(0.0, 1.0)
        val prefs = getSharedPreferences("continue_watching", MODE_PRIVATE)
        val arr = org.json.JSONArray(prefs.getString("items", "[]") ?: "[]")
        val out = org.json.JSONArray()
        val key = resumeStreamUrl.ifBlank { resumeTitle }
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            if (obj.optString("streamUrl") != key && obj.optString("title") != resumeTitle) out.put(obj)
        }
        if (progress in 0.03..0.92) {
            out.put(org.json.JSONObject()
                .put("title", resumeTitle.ifBlank { "Playback" })
                .put("type", "movie")
                .put("meta", resumeMeta)
                .put("overview", resumeOverview)
                .put("posterUrl", resumePosterUrl)
                .put("backdropUrl", resumeBackdropUrl)
                .put("logoUrl", resumeLogoUrl)
                .put("streamUrl", resumeStreamUrl)
                .put("externalId", resumeStreamUrl)
                .put("progress", progress)
                .put("positionMs", position)
                .put("durationMs", duration)
                .put("updatedAt", System.currentTimeMillis()))
        }
        prefs.edit().putString("items", out.toString()).apply()
    }

    private fun formatDuration(ms: Long): String {
        val totalSeconds = (ms / 1000L).coerceAtLeast(0L)
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0) "%d:%02d:%02d".format(hours, minutes, seconds) else "%d:%02d".format(minutes, seconds)
    }

    private fun playSelectedChannel() {
        val target = channels.getOrNull(selectedGuideIndex) ?: return
        currentIndex = selectedGuideIndex
        currentSourceLabel = target.source
        currentDebugLabel = target.debug
        currentStreamUrl = target.url
        currentStreamSeekable = false
        channelsDvrNativeMode = false
        titleView.text = target.name
        statusView.text = ""
        durationView.text = timeshiftStatusLabel()
        bindLiveChannelLogo(target)
        bindProgramMeta(target)
        val mediaItemBuilder = MediaItem.Builder().setUri(Uri.parse(target.url))
        mediaItemBuilder.setLiveConfiguration(
            MediaItem.LiveConfiguration.Builder()
                .setTargetOffsetMs(if (isChannelsDvrSource()) 8000 else 5000)
                .setMinOffsetMs(1500)
                .setMaxOffsetMs(60L * 60L * 1000L)
                .build()
        )
        if (looksLikeTsStream(target.url)) {
            mediaItemBuilder.setMimeType(MimeTypes.VIDEO_MP2T)
        }
        player?.apply {
            setMediaItem(mediaItemBuilder.build())
            prepare()
            playWhenReady = true
        }
    }

    private fun bindProgramMeta(channel: GuideChannel?) {
        val now = Calendar.getInstance()
        val formatter = SimpleDateFormat("h:mm a", Locale.US)
        val activeName = channel?.programTitle?.takeIf { it.isNotBlank() } ?: channel?.name ?: "Live TV"
        val startMillis = channel?.programStartMillis?.takeIf { it > 0L } ?: run {
            val start = now.clone() as Calendar
            start.add(Calendar.MINUTE, -(now.get(Calendar.MINUTE) % 30))
            start.timeInMillis
        }
        val endMillis = channel?.programEndMillis?.takeIf { it > startMillis } ?: (startMillis + 30L * 60L * 1000L)
        val nextMillis = endMillis
        nowTimeView.text = "${formatter.format(Date(startMillis))} – ${formatter.format(Date(endMillis))}"
        titleView.text = activeName
        metaTextView.text = channel?.programDescription?.takeIf { it.isNotBlank() } ?: "Live TV"
        statusView.text = ""
        val pct = (((System.currentTimeMillis() - startMillis).toDouble() / (endMillis - startMillis).toDouble()) * 100).toInt().coerceIn(4, 96)
        progressView.progress = pct
        val nextTitle = channel?.nextTitle?.takeIf { it.isNotBlank() } ?: "${channel?.name ?: "Live TV"} Up Next"
        nextView.text = "NEXT  ${formatter.format(Date(nextMillis))}  $nextTitle"
    }

    private fun renderGuideOverlay() {
        val selected = channels.getOrNull(selectedGuideIndex)
        guideTitleView.text = selected?.name ?: "Live TV Guide"
        guideMetaView.text = selected?.let { "${it.source} • Instant tune enabled" } ?: "Browse channels while video keeps playing"
        guideHintView.text = "LEFT/RIGHT change channel instantly • UP/BACK close"
        guideInfoLogoView.text = (selected?.name ?: "TV").take(2).uppercase(Locale.US)

        guideList.removeAllViews()
        if (channels.isEmpty()) {
            guideList.addView(makeGuideCard("No guide data", "", false))
            return
        }
        val start = (selectedGuideIndex - 2).coerceAtLeast(0)
        val end = (start + 5).coerceAtMost(channels.lastIndex)
        for (index in start..end) {
            val channel = channels[index]
            guideList.addView(makeGuideCard(channel.name, channel.iconUrl, index == selectedGuideIndex))
        }
        guideScroller.post {
            val focusedChild = guideList.getChildAt((selectedGuideIndex - start).coerceAtLeast(0))
            if (focusedChild != null) {
                val scroll = (focusedChild.left - dp(24)).coerceAtLeast(0)
                guideScroller.smoothScrollTo(scroll, 0)
            }
        }
    }

    private fun makeGuideCard(title: String, iconUrl: String, selected: Boolean): View {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM or Gravity.START
            background = getDrawable(if (selected) R.drawable.focus_ring_pill_pulse else R.drawable.pill_dark)
            setPadding(dp(18), dp(12), dp(18), dp(14))
            layoutParams = LinearLayout.LayoutParams(dp(240), dp(112)).apply {
                rightMargin = dp(14)
            }
        }
        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val icon = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(10) }
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(2), dp(2), dp(2), dp(2))
            visibility = if (iconUrl.isBlank()) View.GONE else View.VISIBLE
        }
        if (iconUrl.isNotBlank()) {
            runCatching { Glide.with(this).load(iconUrl).fitCenter().into(icon) }
        }
        val subtitleView = TextView(this).apply {
            text = "Live now"
            setTextColor(0xFFC8D1DC.toInt())
            textSize = 13f
        }
        topRow.addView(icon)
        topRow.addView(subtitleView)
        val titleView = TextView(this).apply {
            text = title
            setTextColor(0xFFFFFFFF.toInt())
            textSize = if (selected) 20f else 17f
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        container.addView(topRow)
        container.addView(titleView)
        return container
    }

    private fun updateClockViews() {
        val formatter = SimpleDateFormat("h:mm a", Locale.US)
        val value = formatter.format(Date())
        clockView.text = value
        guideClockView.text = value
    }

    private fun decodeChannels(json: String?): List<GuideChannel> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(json)
            mutableListOf<GuideChannel>().apply {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    add(
                        GuideChannel(
                            name = obj.optString("name"),
                            url = obj.optString("url"),
                            source = obj.optString("source"),
                            debug = obj.optString("debug"),
                            iconUrl = obj.optString("iconUrl"),
                            programTitle = obj.optString("programTitle"),
                            programDescription = obj.optString("programDescription"),
                            programStartMillis = obj.optLong("programStartMillis"),
                            programEndMillis = obj.optLong("programEndMillis"),
                            nextTitle = obj.optString("nextTitle")
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun inferPlaybackMimeType(url: String): String? {
        val lower = url.lowercase(Locale.US).substringBefore("?")
        return when {
            lower.endsWith(".m3u8") || lower.contains("m3u8") || lower.contains("/hls/") -> MimeTypes.APPLICATION_M3U8
            lower.endsWith(".mpd") || lower.contains("/dash/") -> MimeTypes.APPLICATION_MPD
            lower.endsWith(".ts") || lower.endsWith(".mpegts") || lower.endsWith(".mpg") || lower.contains("format=ts") || lower.contains("/auto/v") || lower.contains("hdhomerun") -> MimeTypes.VIDEO_MP2T
            lower.endsWith(".mp4") || lower.contains("format=mp4") -> MimeTypes.VIDEO_MP4
            lower.endsWith(".webm") || lower.endsWith(".mkv") -> MimeTypes.VIDEO_WEBM
            else -> null
        }
    }

    private fun looksLikeTsStream(url: String): Boolean {
        return inferPlaybackMimeType(url) == MimeTypes.VIDEO_MP2T
    }

    override fun onStart() {
        super.onStart()
        player?.playWhenReady = true
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        overlayHandler.removeCallbacks(updateVodProgressRunnable)
        overlayHandler.removeCallbacksAndMessages(null)
        playerView.player = null
        timeshiftSession?.close()
        timeshiftSession = null
        player?.release()
        player = null
        runCatching { liveTimeshiftCache?.release() }
        liveTimeshiftCache = null
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    data class GuideChannel(
        val name: String,
        val url: String,
        val source: String,
        val debug: String,
        val iconUrl: String = "",
        val programTitle: String = "",
        val programDescription: String = "",
        val programStartMillis: Long = 0L,
        val programEndMillis: Long = 0L,
        val nextTitle: String = ""
    )

    companion object {
        const val EXTRA_STREAM_URL = "stream_url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_MEDIA_TYPE = "media_type"
        const val EXTRA_EXTERNAL_ID = "external_id"
        const val EXTRA_SOURCE_LABEL = "source_label"
        const val EXTRA_ARTWORK_URL = "artwork_url"
        const val EXTRA_LOGO_URL = "logo_url"
        const val EXTRA_POSTER_URL = "poster_url"
        const val EXTRA_META_LINE = "meta_line"
        const val EXTRA_MEDIA_META_LINE = "media_meta_line"
        const val EXTRA_OVERVIEW = "overview"
        const val EXTRA_DEBUG_LABEL = "debug_label"
        const val EXTRA_CHANNELS_JSON = "channels_json"
        const val EXTRA_CHANNEL_INDEX = "channel_index"
        const val EXTRA_VOD_MODE = "vod_mode"
    }
}
