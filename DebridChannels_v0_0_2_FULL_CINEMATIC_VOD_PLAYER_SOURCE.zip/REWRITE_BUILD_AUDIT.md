# Rewrite Build Audit - v0.0.2 FULL CINEMATIC VOD PLAYER

Base used: v0.0.1 stable card clip/logo fixed line.
Rule: clean rewrite/consolidation only; no broken v7.x or stale generated build path carried forward.

Preserved:
- stable row navigation and active row viewport
- clipped rounded landscape cards
- centered row logos
- hero artwork and IMDb/TMDB badge behavior
- Pro Layout Editor and settings scroll behavior
- default backend http://192.168.100.55:8181

Added:
- full cinematic VOD player overlay
- poster, clearlogo/title, metadata, ratings, description
- progress bar and DPAD-friendly controls
- pause/play, +/-10 seek, audio/subtitles/episodes/zoom/settings placeholders
- 5 second auto-hide overlay

Version:
- versionCode 2
- versionName 0.0.2
- visible marker DC_V0_0_2_FULL_CINEMATIC_PLAYER
- logcat marker DC_V0_0_2_ACTIVE
