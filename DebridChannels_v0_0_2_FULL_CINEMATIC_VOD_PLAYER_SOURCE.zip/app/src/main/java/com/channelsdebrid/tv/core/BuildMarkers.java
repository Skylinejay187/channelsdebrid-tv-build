package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.0.2 FULL CINEMATIC VOD PLAYER";
    public static final String LOG_MARKER = "DC_V0_0_2_ACTIVE";
    private BuildMarkers() {}
}
