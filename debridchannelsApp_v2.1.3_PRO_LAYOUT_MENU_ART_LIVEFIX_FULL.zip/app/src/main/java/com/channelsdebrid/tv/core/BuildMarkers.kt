package com.channelsdebrid.tv.core

import android.util.Log
import com.channelsdebrid.tv.BuildConfig

object BuildMarkers {
    const val BUILD_MARKER = "TRUE_LIVETV_LOAD_FIX_START"
    const val ARCHITECTURE_MARKER = "live_tv_load_restored_known_good_guide_tree"

    fun log(component: String) {
        Log.i("DebridChannels", "$BUILD_MARKER component=$component build=${BuildConfig.VERSION_NAME} code=${BuildConfig.VERSION_CODE} arch=$ARCHITECTURE_MARKER")
    }
}
