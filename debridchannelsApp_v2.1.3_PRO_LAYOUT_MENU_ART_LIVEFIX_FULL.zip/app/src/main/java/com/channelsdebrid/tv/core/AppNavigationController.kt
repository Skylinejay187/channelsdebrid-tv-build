package com.channelsdebrid.tv.core

import android.app.Activity
import android.content.Intent
import android.os.SystemClock
import android.util.Log

class AppNavigationController(private val activity: Activity) {
    private var lastLaunchAtMs = 0L
    private var activeTarget = ""

    fun launchOnce(intent: Intent, target: String, minIntervalMs: Long = 700L): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (activeTarget == target && now - lastLaunchAtMs < minIntervalMs) {
            Log.w("DebridChannels", "NavigationOwner blocked duplicate launch target=$target")
            return false
        }
        activeTarget = target
        lastLaunchAtMs = now
        Log.i("DebridChannels", "NavigationOwner launch target=$target")
        activity.startActivity(intent)
        activity.overridePendingTransition(0, 0)
        return true
    }

    fun clearLaunchGate(reason: String) {
        Log.i("DebridChannels", "NavigationOwner clear target=$activeTarget reason=$reason")
        activeTarget = ""
    }
}
