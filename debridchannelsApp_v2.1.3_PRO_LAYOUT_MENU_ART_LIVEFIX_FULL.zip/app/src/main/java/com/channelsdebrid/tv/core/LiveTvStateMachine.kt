package com.channelsdebrid.tv.core

import android.util.Log

class LiveTvStateMachine {
    enum class ScreenState { LOADING, CATEGORY, GUIDE, TOP_NAV, FULL_PLAYER, DESTROYED }

    var state: ScreenState = ScreenState.LOADING
        private set

    fun moveTo(next: ScreenState, reason: String) {
        if (state == ScreenState.DESTROYED && next != ScreenState.DESTROYED) return
        if (state != next) {
            Log.i("DebridChannels", "LiveTvState ${state.name} -> ${next.name} reason=$reason")
            state = next
        }
    }

    fun ownsGuideInput(): Boolean = state == ScreenState.CATEGORY || state == ScreenState.GUIDE
    fun ownsTopNavInput(): Boolean = state == ScreenState.TOP_NAV
    fun isLaunchingPlayer(): Boolean = state == ScreenState.FULL_PLAYER
}
