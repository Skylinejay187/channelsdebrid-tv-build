package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.6.6 Live TV endpoint guide preview fix";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.6.6 Live TV endpoint guide preview fix";
    private BuildMarkers() {}
}
