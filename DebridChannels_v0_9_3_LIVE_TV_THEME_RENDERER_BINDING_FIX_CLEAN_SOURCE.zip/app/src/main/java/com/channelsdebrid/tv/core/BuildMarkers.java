package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.9.2 Real Theme Pack + Force Refresh Removal";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.9.2_real_theme_pack_force_refresh_removed_clean_base";
}
