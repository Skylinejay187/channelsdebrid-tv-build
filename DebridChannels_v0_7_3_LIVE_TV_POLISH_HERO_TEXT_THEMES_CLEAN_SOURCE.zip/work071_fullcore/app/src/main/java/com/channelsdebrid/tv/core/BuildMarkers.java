package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.7.3 Live TV Polish + Hero Text Themes";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.7.3_livetv_polish_hq_artwork_vod_player_hero_text_themes_clean_base";
}
