# v1.7.3 Clean Live TV Timeshift

- Removed the misleading Channels DVR Native / Detecting state from the live player overlay.
- Removed UI dependency on Channels DVR native DVR seek detection.
- Keeps Channels DVR playback on the stable direct HLS stream path.
- Uses the app timeshift UX consistently for Channels DVR, HDHomeRun, M3U, and Xtream.
- Timeshift settings panel now shows provider, enabled status, target storage, and buffer window.
- Rewind/forward controls no longer show native DVR unavailable toast messages.
