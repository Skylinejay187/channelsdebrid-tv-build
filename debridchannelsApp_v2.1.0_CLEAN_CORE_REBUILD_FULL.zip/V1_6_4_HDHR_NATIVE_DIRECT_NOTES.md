# v1.6.4 Native HDHomeRun + Direct Live Providers

- Adds native HDHomeRun discovery/channel loading as its own Live TV provider.
- HDHomeRun now checks:
  - SiliconDust cloud/local discover JSON
  - `hdhomerun.local`
  - `/discover.json`
  - `/lineup.json`
  - full local /24 fallback when mDNS/multicast is blocked
- Channels DVR remains direct-to-app and can still auto-detect locally from the Android app without backend involvement.
- Live TV provider order:
  1. HDHomeRun native
  2. Channels DVR Direct
  3. M3U/IPTV
  4. Xtream/IPTV
- Backend Live TV refresh remains disabled; backend should only serve VOD/debrid/catalog/artwork/trailers.
