# v1.7.5 NAS Auth UI + Backend Extractor Pairing

- Fixed Storage settings layout so NAS username/password fields are visible.
- Clarified UGREEN NAS setup flow: discover NAS, enter SMB username/password, lock path, then save.
- Backend trailer extractor should use yt-dlp through `YTDLP_BIN` and can be checked at `/trailers/extractor/status`.
