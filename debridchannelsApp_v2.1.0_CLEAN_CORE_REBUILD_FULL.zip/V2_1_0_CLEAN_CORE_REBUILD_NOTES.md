# Debrid Channels v2.1.0 Clean Core Rebuild

This build consolidates the layered Live TV/player patches into a cleaner ownership model.

## Preserved
- Existing package name and GitHub workflow layout
- Current VOD player UI with posters, logos, ratings, metadata, controls, subtitles/audio buttons, episodes, zoom, and settings
- Live TV guide UI, preview, guide cache, CDN/backend settings, external cache/timeshift settings

## Cleaned
- Removed backup/temp Kotlin files from the source tree
- Removed stale `singleTop` reuse for LiveTvActivity and PlayerActivity launch paths
- Added one-shot Live TV finish/navigation ownership guard
- Added one-shot PlayerActivity finish/result/release guard
- Player exit now releases playback resources before returning to guide
- Live TV player launch no longer reuses a stale PlayerActivity instance
- Main shell launches Live TV as a clean instance instead of reviving old focus state
- Removed duplicate player load-control builder call

## Intent
Live TV owns guide/top-menu DPAD.
PlayerActivity owns playback keys.
Preview player is stopped/reset before fullscreen playback and restarted at live edge after return.
