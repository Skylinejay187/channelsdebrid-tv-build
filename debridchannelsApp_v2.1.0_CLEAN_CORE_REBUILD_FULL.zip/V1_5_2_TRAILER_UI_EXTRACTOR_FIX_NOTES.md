# v1.5.2 Trailer UI + extractor reliability patch

- Detail page Add Favorite is now an icon button.
- Detail page Play Trailer is now an icon button.
- Trailer mute control uses a glass pill background.
- Trailer mute control auto-hides after 5 seconds.
- Trailer popup auto-trigger delay moved to 5 seconds.
- Android backend trailer request timeout increased so yt-dlp has time to resolve streams.
- Android no longer blocks backend-selected trailers with overly strict app-side title filtering.
- Backend yt-dlp timeout increased and search widened to improve trailer resolving.
- Backend format fallback now allows 720p+ instead of failing when 1080p/4K is not available.
