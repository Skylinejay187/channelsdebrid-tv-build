# v1.9.7 Live TV Hard DPAD Focus Lock

Patched from `debridchannelsApp_v1.9.6_LIVE_TV_HARD_FOCUS_BUILD_FULL.zip`.

## Fixed
- Live TV now owns DPAD/OK/BACK through a hard key anchor instead of relying on Android TV auto-focus.
- Top menu items are no longer focusable by default, preventing focus from landing on Resume Watching and blocking guide navigation.
- Pressing UP from the top category/guide row intentionally enters the top menu.
- Pressing DOWN or BACK from the top menu returns to the Live TV guide/category zone.
- Loading overlay now restores Live TV focus after it hides, so the remote does not get stuck after channels finish loading.
- Category rows and guide rows are non-focusable click targets, keeping remote movement controlled by the synthetic Live TV focus zones.
- XML root is now explicitly focusable/clickable and blocks descendant focus inside the guide body.

## Expected remote behavior
- Live TV opens directly in guide/category control mode.
- UP from the first guide/category item moves to the top menu.
- LEFT/RIGHT moves between categories and the full guide.
- OK on a guide row opens the channel player.
