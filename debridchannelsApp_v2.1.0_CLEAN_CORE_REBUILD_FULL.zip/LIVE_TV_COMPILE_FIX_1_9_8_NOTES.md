# Debrid Channels v1.9.8 Live TV Compile Fix

This full GitHub-ready zip patches the previous v1.9.7 hard DPAD focus build.

Fixed:
- `descendantFocusability` compile error by safely casting `contentRoot` to `ViewGroup`.
- Kotlin `Any but Boolean was expected` compile error by returning `true` from NAV restore branches.
- Keeps the hard Live TV DPAD focus guard from v1.9.7.

Expected behavior:
- Live TV guide owns DPAD focus after loading.
- UP from top of category/guide moves to the top menu.
- DOWN from top menu returns to Live TV.
- LEFT/RIGHT/DOWN remain deterministic inside Live TV.
