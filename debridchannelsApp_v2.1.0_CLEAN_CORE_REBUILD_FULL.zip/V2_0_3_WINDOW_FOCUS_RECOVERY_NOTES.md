# Debrid Channels v2.0.3 - Window Focus Recovery Fix

This build targets the repeated Android TV logcat warning:

`ViewRootImpl[LiveTvActivity]: Cancelling event due to no window focus`

## Fixes
- Added LiveTvActivity `onWindowFocusChanged()` recovery so guide focus is restored only after Android confirms the window is active.
- Added `onPause()`/`onStop()` ownership release so Live TV does not keep DPAD ownership while PlayerActivity or the main shell is on top.
- Changed Live TV content root to `FOCUS_BEFORE_DESCENDANTS` so the key anchor remains stable and Android TV does not jump to stale child/top-nav focus.
- Disabled Live TV input during full-player launch, then re-enabled it only after LiveTvActivity regains real window focus.
- Removed `FLAG_ACTIVITY_SINGLE_TOP` from Live TV launching PlayerActivity.
- Changed PlayerActivity manifest launch mode from `singleTop` to standard so every selected channel receives a fresh player intent instead of reusing a stale player instance.

## Expected behavior
- First channel opens full player.
- Back returns to guide.
- Second channel OK opens full player again.
- Moving to top menu/main shell no longer leaves Live TV intercepting DPAD.
- No automatic snap-back to guide from Smart/Home sections.
