# v9.9 Compile Fix

Fixes included:
- MainActivity.kt trailer resolver URL encoding compile error fixed by converting mediaId to String before URLEncoder.encode.
- SettingsActivity.kt missing android.view.View import fixed.
- YouTube API key remains removed from visible settings and stored preferences cleanup remains active.
- Trailer cache remains per item from v9.8.
