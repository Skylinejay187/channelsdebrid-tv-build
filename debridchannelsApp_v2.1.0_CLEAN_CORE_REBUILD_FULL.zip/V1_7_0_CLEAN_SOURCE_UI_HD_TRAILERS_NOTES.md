# v1.7.0 Clean Source UI + HD Trailer/Posters Patch

- Source selection cards now use a clean grouped multi-line layout instead of one long cropped text line.
- Cards show primary video quality/title, clean codec/audio/size flags, and the source details without aggressive truncation.
- Source selection poster/backdrop loading upgrades TMDB/Stremio artwork URLs to original/large variants and caches full-resolution images.
- Details background artwork now requests original-size images through Glide.
- Trailer requests now pass the actual 1080p/2160p preference to the backend instead of forcing 1080p/false every time.
- Trailer player now prefers the highest supported bitrate and allows 4K when the trailer setting is enabled.
- YouTube WebView fallback requests HD playback quality.
