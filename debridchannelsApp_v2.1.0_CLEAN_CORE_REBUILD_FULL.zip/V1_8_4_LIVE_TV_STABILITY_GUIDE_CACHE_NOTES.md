# Debrid Channels v1.8.4 - Live TV Stability + Guide Cache Patch

This patch keeps the existing Live TV preview behavior enabled and stabilizes it instead of removing features.

## Android TV changes
- Kept auto preview enabled while browsing categories and guide rows.
- Added a preview request token so stale focus events cannot start old streams after the user scrolls away.
- Preview player now avoids re-preparing the same URL when already active.
- Preview callbacks are invalidated on stop/destroy to prevent stale playback work.
- Glide logo loading now uses disk cache and no animation to reduce focus-row jank.
- Guide cache duration now follows the selectable Settings value: 6h / 12h / 24h.
- Default guide cache duration is now 12 hours.
- Removed old Off/1h/3h guide schedule choices from Settings to match the stable cache modes.
- Existing Channels DVR, HDHomeRun, M3U, Xtream, NAS timeshift, and trailer features were not removed.

## Stability rules preserved
- Focus changes only start preview playback.
- Provider refreshes run in background.
- Guide data loads from local cache first.
- Guide refresh does not block UI rendering.
- Category browsing does not reload providers or parse guide data.
