# v1.6.7 - HDHomeRun EPG + Auto Preview Guide

## Live TV
- Added HDHomeRun XMLTV guide lookup using discovered HDHomeRun DeviceAuth values.
- Caches HDHomeRun XMLTV guide locally for 12 hours.
- HDHomeRun channels now attempt guide matching by guide number, channel name, and normalized channel name.
- Channels DVR, HDHomeRun, M3U/IPTV, and Xtream remain app-owned direct Live TV providers.

## Guide Preview UX
- Moving through guide rows now auto-starts the selected channel preview.
- OK/Enter opens the selected channel player instead of requiring a separate preview arm step.
- Preview playback stays visible and continues while the user moves back into the category rail.
- Pressing RIGHT from categories expands the guide and auto-starts preview for the selected channel.

## Notes
- HDHomeRun lineup discovery still comes from /discover.json and /lineup.json.
- HDHomeRun guide data requires HDHomeRun guide/XMLTV availability from SiliconDust; if unavailable, the guide safely falls back to cached data or "No information" blocks.
