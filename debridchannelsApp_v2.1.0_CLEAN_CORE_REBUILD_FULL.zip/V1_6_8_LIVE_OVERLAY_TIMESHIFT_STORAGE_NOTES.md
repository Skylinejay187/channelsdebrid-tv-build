# v1.6.8 Live Overlay + Timeshift Storage

- Live player overlay now prefers the channel logo in the top-left pill instead of repeating the channel name.
- Player title now uses the current EPG program title when available.
- Player description line now uses the current EPG description when available.
- Removed the visible `Buffering Channels DVR...` label from the live overlay.
- Live player passes now/next EPG metadata from the guide into playback.
- Added Timeshift button on the live player control row.
- Added persistent storage settings for timeshift target:
  - Internal Storage
  - USB path
  - NAS/SMB path
  - NAS host/IP
  - NAS share/folder
  - NAS username/password
  - Timeshift minutes
- Timeshift label now reflects the selected storage target.
