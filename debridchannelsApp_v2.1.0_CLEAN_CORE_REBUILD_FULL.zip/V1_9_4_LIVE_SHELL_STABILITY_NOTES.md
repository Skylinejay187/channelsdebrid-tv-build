# v1.9.4 Live Shell Stability Patch

- Version updated to 1.9.4-live-shell-stability so the installed APK can be verified.
- Live TV and Player now use singleTop/reorder-to-front behavior to reduce stacked activity launches.
- Added a DPAD/center debounce before opening PlayerActivity from LiveTvActivity.
- Reduced force-guide refresh batch size to avoid device freezes.
- Timeshift defaults safely off if the playback setting cannot be read.
- Added safer cache release path for repeated PlayerActivity opens.

Logcat issue addressed:
- Repeated PlayerActivity starts
- no-window-focus key event churn
- ExoPlayer internal DB/cache leakage risk
