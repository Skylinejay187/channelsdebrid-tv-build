# v1.4.10 Trailer Popup + YouTube Fallback Patch

## What changed
- Disabled hero/home trailer autoplay. Browsing poster rows no longer launches trailers.
- Media details screen now auto-opens the trailer popup after ~1.5 seconds.
- Trailer popup still tries the existing backend `/trailers/resolve` first.
- If backend trailer resolution fails, the app searches YouTube directly for `{title} {year} movie/series official trailer`, extracts a video id, and plays it in the popup with an Android WebView iframe.
- Backend trailer timeouts were reduced so an unreachable backend does not stall the popup for a long time before fallback.
- Force Refresh Guide was moved out of the Live TV info/header area and placed at the bottom-left overlay.
- Force Refresh Guide is no longer focusable through normal DPAD navigation, reducing accidental clicks.

## Files changed
- app/src/main/java/com/channelsdebrid/tv/playback/MediaDetailsActivity.kt
- app/src/main/java/com/channelsdebrid/tv/MainActivity.kt
- app/src/main/java/com/channelsdebrid/tv/settings/AppConfigModels.kt
- app/src/main/java/com/channelsdebrid/tv/settings/SettingsRepository.kt
- app/src/main/res/layout/activity_live_tv.xml
