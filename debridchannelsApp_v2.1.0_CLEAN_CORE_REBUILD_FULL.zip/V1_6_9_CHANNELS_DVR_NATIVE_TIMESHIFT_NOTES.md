# v1.6.9 Channels DVR Native Timeshift

- Adds provider-aware Live TV timeshift behavior.
- Channels DVR streams are detected by provider/source/debug/URL and use Channels DVR native seekable live-buffer controls when ExoPlayer reports a seekable timeline.
- HDHomeRun, M3U, and Xtream/IPTV remain on Debrid Channels app timeshift storage using Internal / USB / NAS settings.
- Rewind/fast-forward are enabled for Channels DVR only after the live timeline is seekable; otherwise the UI shows that native buffer is still detecting/unavailable and avoids invalid seek calls.
- Switching channels from the quick guide resets and re-detects timeshift capability per channel.
