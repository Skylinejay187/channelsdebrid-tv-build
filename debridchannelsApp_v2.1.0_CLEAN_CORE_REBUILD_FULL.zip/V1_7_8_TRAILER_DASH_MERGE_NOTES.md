v1.7.8 full trailer fix:
- Backend returns split DASH videoUrl/audioUrl for 1080p/4K trailers.
- Android Media3 player merges video+audio with MergingMediaSource.
- Progressive 360p is fallback only when split streams are unavailable.
