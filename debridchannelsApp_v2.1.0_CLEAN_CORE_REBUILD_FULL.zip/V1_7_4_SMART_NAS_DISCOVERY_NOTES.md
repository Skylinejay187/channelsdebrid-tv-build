# v1.7.4 Smart NAS Discovery

- Added Settings > Storage smart NAS discovery for local SMB/NAS devices.
- Scans ARP-discovered devices plus local subnet candidates for SMB ports 445/139.
- Presents discovered devices in a picker so the user does not have to manually type the IP.
- Adds Lock NAS Path button that normalizes and locks `smb://host/share`, sets target to NAS, and prompts the user to save.
- Keeps manual entry as fallback for routed/VLAN/guest Wi-Fi networks where discovery is blocked.
- Preserves existing Internal and USB timeshift choices.
