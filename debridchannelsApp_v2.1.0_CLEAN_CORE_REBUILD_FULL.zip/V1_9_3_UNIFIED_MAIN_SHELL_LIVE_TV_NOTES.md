# Debrid Channels v1.9.3 - Unified Main Shell Live TV

This patch makes Live TV feel like part of the main app shell instead of a fully separate standalone area.

## Included
- Adds the same top navigation menu directly to the Live TV screen.
- Keeps Live TV selected/highlighted while browsing the guide.
- Allows quick return to Smart Home, Resume Watching, Movies, and TV Shows from the top menu.
- Removes transition animation when entering Live TV for a faster app-shell feel.
- Keeps v1.9.2 safe-mode behavior: no automatic heavy guide/provider refresh on Live TV startup.
- Keeps Live TV preview and cached guide behavior intact.

## Why this is safer than a full rewrite right now
A full Activity-to-fragment/main-shell conversion would require restructuring the large Live TV controller and preview player lifecycle. This patch gives the Arvio-style integrated navigation now while avoiding another freeze-prone lifecycle rewrite.

## Next phase
Convert Live TV controller into a true reusable view/controller hosted directly by MainActivity after this build is confirmed stable.
