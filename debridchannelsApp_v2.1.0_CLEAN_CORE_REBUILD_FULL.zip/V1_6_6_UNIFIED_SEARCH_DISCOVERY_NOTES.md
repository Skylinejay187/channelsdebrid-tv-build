# v1.6.6 Unified Search + Movies/TV Wiring

- Search now runs as one unified app search layer.
- Results can include Movies, TV Shows, Live TV channels, and cached EPG/program events.
- Search runs off the UI thread so TV navigation does not freeze while sources are queried.
- Movies and TV menu rows now pull from backend catalog, TMDB when configured, Stremio addon catalogs, and safe fallback rows.
- Playback path remains Stremio stream lookup + Real-Debrid/TorBox resolution through the existing Source Selection screen.
- Live results open direct IPTV/Channels DVR/HDHomeRun streams from the app-owned Live TV provider cache.
- EPG search uses the 12-hour persistent local guide cache, so searches like NFL, team names, movie titles, and live event names can find matching guide programs without forcing a guide refresh.
