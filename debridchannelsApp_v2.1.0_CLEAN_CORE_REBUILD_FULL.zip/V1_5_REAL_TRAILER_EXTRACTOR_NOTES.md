# v1.5 Real Trailer Extractor Patch

Included in this build:

- Backend `/trailers/resolve` real trailer resolver.
- Backend `/trailers/prewarm` cache warmup endpoint.
- Compatibility `/api/trailer/:id` endpoint.
- `yt-dlp` powered official-trailer search and stream extraction.
- Title/year matching score system to avoid clips, concepts, reactions, fan trailers, and random videos.
- 1080p default extraction with optional 4K preference.
- Direct DASH/HLS/MP4 stream response for Android Media3 playback.
- In-memory trailer cache and duplicate request de-dupe.
- Android focus autoplay re-enabled: poster focus waits the configured delay, calls backend first, and starts the extracted trailer.

Backend container requirement:

- Dockerfile installs `yt-dlp` and `ffmpeg`.
- If running outside Docker, install `yt-dlp` or set `YTDLP_BIN`.

Primary endpoint:

`GET /trailers/resolve?title=Movie%20Title&year=2024&prefer4k=false&mediaId=123&mediaType=movie`

Response:

```json
{
  "ok": true,
  "trailer": {
    "playbackUrl": "...",
    "mimeType": "application/dash+xml",
    "quality": "1080p adaptive",
    "source": "yt-dlp-adaptive-manifest"
  }
}
```
