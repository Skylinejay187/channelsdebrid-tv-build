# v2.0.5 Live Edge / Timeshift Exit Fix

Fixes the issue where returning from full-screen live playback made the guide preview appear to rewind.

Changes:
- LiveTvActivity now clears the paused preview media item before launching PlayerActivity.
- On return/resume, LiveTvActivity reloads the selected channel preview from the original live URL instead of resuming a stale ExoPlayer buffer position.
- PlayerActivity channel switching now resets to the live default position.
- Live max offset is tightened so live playback does not drift far behind the live edge.
- Duplicate shell/navigation finish requests are guarded to avoid repeated LiveTvActivity restarts.
