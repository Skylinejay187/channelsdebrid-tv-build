# v2.0.6 Live TV Tree Rebuild Notes

This build rebuilds the Live TV navigation ownership model instead of adding another focus patch.

## Fixed
- Player launch now uses a bounded request/result flow so LiveTvActivity does not relaunch itself after full-screen playback.
- PlayerActivity returns a result on BACK/finish so LiveTvActivity can restore the guide once, cleanly.
- Added a debounce guard to MainActivity Live TV launch to stop repeated OK/DPAD events from creating duplicate LiveTvActivity starts.
- Removed REORDER_TO_FRONT from Live TV launch path to avoid reviving stale LiveTvActivity window/input state.
- Added repeat-key protection for OK/ENTER inside Live TV guide.
- Hardened PlayerActivity release so ExoPlayer/timeshift/cache cleanup only runs once per player instance.
- Guide preview is restarted from live edge after PlayerActivity result instead of inheriting a timeshift/rewind position.

## Goal
One active owner at a time:
- LiveTvActivity owns guide/category/top menu DPAD.
- PlayerActivity owns full-screen playback DPAD.
- MainActivity owns home/top shell DPAD.
