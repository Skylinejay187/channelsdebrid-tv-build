# Debrid Channels v1.9.0 Timeshift + Guide Stability Patch

This full project zip is based on the uploaded v1.8.9 project.

## Live TV guide crash fixes
- Force Refresh Guide no longer clears cache and immediately rebuilds the whole Live TV source list on the UI path.
- Force Refresh Guide now clears guide cache in the background, leaves the current guide/channel list visible, and queues local guide refresh safely.
- Added additional empty-list guards around category/channel selection to prevent `coerceIn()` empty-range crashes during first-open guide loading or provider refresh.
- Guide refresh errors now keep the visible channel list instead of taking down Live TV.

## Timeshift fixes
- Keeps NAS as a secondary mirror/storage target rather than the playback source.
- Player reads from local app buffer first for more stable pause/rewind/fast-forward behavior.
- Increased live buffer window and retained back buffer for Live TV playback.
- Increased Media3 live offset window to allow a longer app-managed timeshift buffer when the stream exposes a seekable live window.
- Existing NAS mirror support remains enabled through `TimeshiftStorageManager`.

## Important behavior
- This is still app-side only.
- Backend/server does not need to be updated for this patch.
- Some raw non-seekable live streams may still require a future full recorder-to-local-HLS engine to get cable-DVR-style rewind from the first second.
