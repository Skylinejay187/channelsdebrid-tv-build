# v1.6.2 Live TV guide/player support patch

Baseline: Android v1.6.1 + Backend v1.5.4.

## Fixed
- Live TV guide refresh button can now receive focus from the category rail by pressing DPAD down from the last category.
- Refresh button handles OK/Enter directly, DPAD up/back returns to categories, DPAD right expands guide.
- Added focused scale/alpha feedback for the refresh button.

## Live TV player support
- Full player and live preview now use Media3 renderer decoder fallback.
- Extension renderer mode is set to prefer available extension codecs.
- Added live MIME detection for HLS `.m3u8`, DASH `.mpd`, MPEG-TS, MP4, WebM/MKV.
- Expanded Live TV player read/connect timeouts for IPTV stability.
- Kept Live TV lightweight preview while browsing; full playback still opens in PlayerActivity.

Trailer speed/UI changes from v1.6.1 are preserved.
