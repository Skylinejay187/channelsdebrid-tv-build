# Debrid Channels v1.8.6 NAS + Timeshift Wiring Patch

## NAS connection changes
- NAS discovery still finds SMB hosts on the local network.
- `Login / Browse NAS` now performs a real SMB login using the entered username/password.
- After successful login, the app opens a NAS folder browser.
- Users can browse shares and folders from the NAS file system.
- Selecting `Use this folder for timeshift` runs a write test by creating/deleting a small temp file.
- The NAS path is only locked when the selected folder is confirmed writable.
- Save now validates the selected timeshift storage target.

## Timeshift wiring changes
- Added `TimeshiftStorageManager` for storage validation.
- Internal, USB, and NAS targets are validated through the same storage manager.
- NAS timeshift target requires host, username, password, and a writable SMB folder.
- Player settings panel now reflects the selected timeshift target from saved settings.

## Important
This patch does not remove any Live TV provider behavior. Channels DVR, HDHomeRun, M3U/Xtream and preview behavior remain intact.
