# v1.7.6 App trailer extractor wiring

- Default trailer behavior is auto-play after 5 seconds.
- Home/details trailers call the configured backend `/trailers/resolve` endpoint.
- Requests prefer 2160p/1080p when 4K trailers are enabled, otherwise 1080p.
- App accepts `playbackUrl`, `url`, `directUrl`, or `streamUrl` from the backend extractor response.
- Backend URL uses the saved backend setting with fallback to the existing default.
