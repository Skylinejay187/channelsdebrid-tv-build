# Live TV Remote DPAD Focus Fix

This patch fixes the Live TV screen being completely stuck with a remote while mouse clicks still worked.

Changes:
- Makes the Live TV content root the real Android TV focus holder on entry.
- Prevents Android from defaulting focus to the first top nav item (`Resume Watching`).
- Restores DPAD UP/DOWN/LEFT/RIGHT routing through the synthetic Live TV category/guide focus system.
- Makes BACK from the category rail return to the main hero shell instead of doing nothing or falling through.
- Keeps top navigation accessible by pressing UP from the first category/guide row, then DOWN/BACK returns to the guide.
