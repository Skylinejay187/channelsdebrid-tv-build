# Live TV Focus Stuck Fix

Patched LiveTvActivity so preview/player/scroll containers cannot trap Android TV remote focus. UP from the first category or first guide row returns to the top menu, DOWN/BACK from the top menu returns to Live TV, and guide/category scrolling is routed through one DPAD handler.
