# Debrid Channels v1.9.5 Live Pause / Seek Stability

Fixes included:
- `-30` now routes through the safe rewind handler instead of any direct/default player seek path.
- Remote/media rewind and fast-forward keys now use the same safe handlers as the on-screen buttons.
- Live rewind no longer falls back to unsafe `seekTo(0)` on non-seekable live streams, which could appear to jump forward/live instead of rewinding.
- Live playback no longer uses ExoPlayer `CacheDataSource` by default because the previous path was leaking `exoplayer_internal.db` connections and could freeze/crash after pausing live TV.
- Timeshift session metadata/folders and NAS mirroring remain available, but playback uses the stable direct live stream path until the recorder-backed rolling buffer is added.
- Pause state is tracked safely without triggering guide/provider reloads.
