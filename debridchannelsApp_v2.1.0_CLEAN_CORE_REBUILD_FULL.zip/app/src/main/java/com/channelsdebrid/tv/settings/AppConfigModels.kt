package com.channelsdebrid.tv.settings

data class TmdbSettings(
    val apiKey: String = "",
    val region: String = "US",
    val language: String = "en-US"
)

data class CatalogSettings(
    val trendingMoviesEnabled: Boolean = true,
    val popularMoviesEnabled: Boolean = true,
    val trendingShowsEnabled: Boolean = true,
    val popularShowsEnabled: Boolean = true,
    val platformRowsEnabled: Boolean = true,
    val stremioCatalogRowsEnabled: Boolean = true
)

data class StremioAddonSettings(
    val id: String,
    val name: String,
    val manifestUrl: String,
    val enabled: Boolean = true
) {
    val url: String get() = manifestUrl
}

data class DebridSettings(
    val realDebridEnabled: Boolean = false,
    val realDebridApiKey: String = "",
    val torBoxEnabled: Boolean = false,
    val torBoxApiKey: String = "",
    val preferredProvider: String = "realdebrid",
    val autoFallback: Boolean = true
)

data class ChannelsDvrSettings(
    val autoDetect: Boolean = true,
    val baseUrl: String = "",
    val deviceId: String = ""
)

data class XtreamSettings(
    val server: String = "",
    val username: String = "",
    val password: String = "",
    val m3uUrl: String = "",
    val enabled: Boolean = false
)

data class StorageTarget(
    val id: String,
    val type: String,
    val label: String,
    val path: String,
    val allowTimeshift: Boolean,
    val allowVodCache: Boolean,
    val priority: Int
)

data class StorageSettings(
    val preferredTarget: String = "internal",
    val usbPath: String = "",
    val nasPath: String = "",
    val nasHost: String = "",
    val nasShare: String = "",
    val nasUsername: String = "",
    val nasPassword: String = "",
    val timeshiftMinutes: Int = 90,
    val movieCacheEnabled: Boolean = true
)

data class TrailerSettings(
    val enabled: Boolean = true,
    val autoplayOnFocus: Boolean = true,
    val autoplayDelayMs: Long = 5000,
    val backgroundAutoplayEnabled: Boolean = true,
    val backgroundAutoplayDelayMs: Long = 5000,
    val popupMode: String = "popup",
    val playbackLocation: String = "both",
    val youtubeApiKey: String = "",
    val prefer4k: Boolean = true
)

data class PlaybackSettings(
    val frameRateMatching: Boolean = true,
    val preferExternalStorageForCache: Boolean = true,
    val timeshiftEnabled: Boolean = true,
    val autoPlayBestStream: Boolean = true,
    val fileSizeLimitGb: Int = 40,
    val ultraHdGuideUiEnabled: Boolean = true,
    val liveStatusChecksEnabled: Boolean = true
)


data class LiveBackendSettings(
    val baseUrl: String = "http://192.168.100.55:8181",
    val userId: String = "demo",
    val autoSyncSources: Boolean = true,
    val epgRefreshEveryHours: Int = 12
)


/**
 * Single source of truth for the home-screen layout engine.
 */
data class HomeLayoutSettings(
    val rowTopDp: Int = HomeLayoutDefaults.ROW_TOP_DP,
    val rowLeftDp: Int = HomeLayoutDefaults.ROW_LEFT_DP,
    val cardWidthDp: Int = HomeLayoutDefaults.CARD_WIDTH_DP,
    val cardHeightDp: Int = HomeLayoutDefaults.CARD_HEIGHT_DP,
    val cardSpacingDp: Int = HomeLayoutDefaults.CARD_SPACING_DP,
    val focusedScalePercent: Int = HomeLayoutDefaults.FOCUSED_SCALE_PERCENT,
    val heroTextLeftDp: Int = HomeLayoutDefaults.HERO_TEXT_LEFT_DP,
    val heroTextTopDp: Int = HomeLayoutDefaults.HERO_TEXT_TOP_DP,
    val topMenuOffsetDp: Int = HomeLayoutDefaults.TOP_MENU_OFFSET_DP,
    val bottomSafeDp: Int = HomeLayoutDefaults.BOTTOM_SAFE_DP,
    val previewCardCount: Int = HomeLayoutDefaults.PREVIEW_CARD_COUNT,
    val glowStrengthPercent: Int = HomeLayoutDefaults.GLOW_STRENGTH_PERCENT,
    val pulseStrengthPercent: Int = HomeLayoutDefaults.PULSE_STRENGTH_PERCENT,
    val focusRingEnabled: Int = HomeLayoutDefaults.FOCUS_RING_ENABLED,
    val focusRingThicknessDp: Int = HomeLayoutDefaults.FOCUS_RING_THICKNESS_DP,
    val focusRingColorIndex: Int = HomeLayoutDefaults.FOCUS_RING_COLOR_INDEX,
    val cardTiltPercent: Int = HomeLayoutDefaults.CARD_TILT_PERCENT,
    val cardLiftDp: Int = HomeLayoutDefaults.CARD_LIFT_DP,
    val cornerRadiusDp: Int = HomeLayoutDefaults.CORNER_RADIUS_DP,
    val dimUnfocusedPercent: Int = HomeLayoutDefaults.DIM_UNFOCUSED_PERCENT,
    val topMenuIconStyle: Int = HomeLayoutDefaults.TOP_MENU_ICON_STYLE,
    val topMenuFontIndex: Int = HomeLayoutDefaults.TOP_MENU_FONT_INDEX,
    val heroFontIndex: Int = HomeLayoutDefaults.HERO_FONT_INDEX,
    val contentFontIndex: Int = HomeLayoutDefaults.CONTENT_FONT_INDEX,
    val rowTitleIconsEnabled: Int = HomeLayoutDefaults.ROW_TITLE_ICONS_ENABLED,
    val focusBouncePercent: Int = HomeLayoutDefaults.FOCUS_BOUNCE_PERCENT,
    val glassCardMode: Int = HomeLayoutDefaults.GLASS_CARD_MODE,
    val hoverInfoOverlay: Int = HomeLayoutDefaults.HOVER_INFO_OVERLAY,
    val backgroundDimOnFocusPercent: Int = HomeLayoutDefaults.BACKGROUND_DIM_ON_FOCUS_PERCENT,
    val effectProfileIndex: Int = HomeLayoutDefaults.EFFECT_PROFILE_INDEX
)

object HomeLayoutDefaults {
    const val ROW_TOP_DP = 430
    const val ROW_LEFT_DP = 6
    const val CARD_WIDTH_DP = 286
    const val CARD_HEIGHT_DP = 160
    const val CARD_SPACING_DP = 12
    const val FOCUSED_SCALE_PERCENT = 100
    const val HERO_TEXT_LEFT_DP = 0
    const val HERO_TEXT_TOP_DP = 0
    const val TOP_MENU_OFFSET_DP = 0
    const val BOTTOM_SAFE_DP = 72
    const val PREVIEW_CARD_COUNT = 4
    const val GLOW_STRENGTH_PERCENT = 70
    const val PULSE_STRENGTH_PERCENT = 0
    const val FOCUS_RING_ENABLED = 1
    const val FOCUS_RING_THICKNESS_DP = 2
    const val FOCUS_RING_COLOR_INDEX = 0
    const val CARD_TILT_PERCENT = 0
    const val CARD_LIFT_DP = 0
    const val CORNER_RADIUS_DP = 28
    const val DIM_UNFOCUSED_PERCENT = 0
    const val TOP_MENU_ICON_STYLE = 1
    const val TOP_MENU_FONT_INDEX = 0
    const val HERO_FONT_INDEX = 0
    const val CONTENT_FONT_INDEX = 0
    const val ROW_TITLE_ICONS_ENABLED = 1
    const val FOCUS_BOUNCE_PERCENT = 0
    const val GLASS_CARD_MODE = 0
    const val HOVER_INFO_OVERLAY = 1
    const val BACKGROUND_DIM_ON_FOCUS_PERCENT = 10
    const val EFFECT_PROFILE_INDEX = 0
}

fun homeLayoutRingColor(index: Int): Int = when (index.coerceIn(0, 5)) {
    1 -> 0xFFB46CFF.toInt()
    2 -> 0xFFFFD54A.toInt()
    3 -> 0xFF4DFFB8.toInt()
    4 -> 0xFFFF5C8A.toInt()
    5 -> 0xFFFFFFFF.toInt()
    else -> 0xFF5EE6FF.toInt()
}

fun homeLayoutFontName(index: Int): String = when (index.coerceIn(0, 11)) {
    1 -> "Condensed"
    2 -> "Medium"
    3 -> "Serif Cinema"
    4 -> "Mono Tech"
    5 -> "Rounded"
    6 -> "Black"
    7 -> "Light"
    8 -> "Thin"
    9 -> "Small Caps"
    10 -> "Elegant"
    11 -> "System Regular"
    else -> "Default Bold"
}

fun homeLayoutTypeface(index: Int): android.graphics.Typeface = when (index.coerceIn(0, 11)) {
    1 -> android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD)
    2 -> android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
    3 -> android.graphics.Typeface.create("serif", android.graphics.Typeface.BOLD)
    4 -> android.graphics.Typeface.create("monospace", android.graphics.Typeface.BOLD)
    5 -> android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
    6 -> android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.BOLD)
    7 -> android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL)
    8 -> android.graphics.Typeface.create("sans-serif-thin", android.graphics.Typeface.NORMAL)
    9 -> android.graphics.Typeface.create("sans-serif-smallcaps", android.graphics.Typeface.BOLD)
    10 -> android.graphics.Typeface.create("serif-monospace", android.graphics.Typeface.BOLD)
    11 -> android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
    else -> android.graphics.Typeface.DEFAULT_BOLD
}

fun homeLayoutIconForRow(title: String): String {
    val t = title.lowercase()
    return when {
        "movie" in t -> "🎬"
        "show" in t || "series" in t -> "📺"
        "live" in t || "channel" in t -> "▶"
        "stream" in t || "catalog" in t -> "◆"
        "featured" in t -> "★"
        "popular" in t || "trending" in t -> "🔥"
        else -> "◇"
    }
}

fun homeLayoutDecoratedRowTitle(title: String, enabled: Int): String =
    if (enabled == 1) "${homeLayoutIconForRow(title)}  $title" else title

fun HomeLayoutSettings.sanitized(): HomeLayoutSettings = copy(
    rowTopDp = rowTopDp.coerceIn(260, 660),
    rowLeftDp = rowLeftDp.coerceIn(0, 180),
    cardWidthDp = cardWidthDp.coerceIn(180, 460),
    cardHeightDp = cardHeightDp.coerceIn(100, 300),
    cardSpacingDp = cardSpacingDp.coerceIn(0, 60),
    focusedScalePercent = focusedScalePercent.coerceIn(100, 120),
    heroTextLeftDp = heroTextLeftDp.coerceIn(-120, 260),
    heroTextTopDp = heroTextTopDp.coerceIn(-120, 220),
    topMenuOffsetDp = topMenuOffsetDp.coerceIn(-260, 260),
    bottomSafeDp = bottomSafeDp.coerceIn(24, 180),
    previewCardCount = previewCardCount.coerceIn(1, 8),
    glowStrengthPercent = glowStrengthPercent.coerceIn(0, 100),
    pulseStrengthPercent = pulseStrengthPercent.coerceIn(0, 100),
    focusRingEnabled = focusRingEnabled.coerceIn(0, 1),
    focusRingThicknessDp = focusRingThicknessDp.coerceIn(0, 8),
    focusRingColorIndex = focusRingColorIndex.coerceIn(0, 5),
    cardTiltPercent = cardTiltPercent.coerceIn(0, 100),
    cardLiftDp = cardLiftDp.coerceIn(0, 24),
    cornerRadiusDp = cornerRadiusDp.coerceIn(8, 44),
    dimUnfocusedPercent = dimUnfocusedPercent.coerceIn(0, 70),
    topMenuIconStyle = topMenuIconStyle.coerceIn(0, 3),
    topMenuFontIndex = topMenuFontIndex.coerceIn(0, 11),
    heroFontIndex = heroFontIndex.coerceIn(0, 11),
    contentFontIndex = contentFontIndex.coerceIn(0, 11),
    rowTitleIconsEnabled = rowTitleIconsEnabled.coerceIn(0, 1),
    focusBouncePercent = focusBouncePercent.coerceIn(0, 100),
    glassCardMode = glassCardMode.coerceIn(0, 1),
    hoverInfoOverlay = hoverInfoOverlay.coerceIn(0, 1),
    backgroundDimOnFocusPercent = backgroundDimOnFocusPercent.coerceIn(0, 45),
    effectProfileIndex = effectProfileIndex.coerceIn(0, 4)
)
