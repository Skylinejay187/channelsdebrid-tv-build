package com.channelsdebrid.tv.playback

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView
import com.bumptech.glide.Glide
import com.channelsdebrid.tv.R
import com.channelsdebrid.tv.settings.SettingsRepository
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MediaDetailsActivity : AppCompatActivity() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val trailerExecutor = Executors.newSingleThreadExecutor()
    private var backgroundTrailerRunnable: Runnable? = null
    private var backgroundTrailerPlayer: ExoPlayer? = null
    private lateinit var settingsRepository: SettingsRepository
    private lateinit var trailerPlayerView: PlayerView
    private lateinit var popupTrailerPlayerView: PlayerView
    private lateinit var trailerMuteButton: Button
    private lateinit var playTrailerButton: Button
    private lateinit var trailerPopupOverlay: FrameLayout
    private lateinit var trailerLoadingText: TextView
    private var trailerMuted = false
    private var trailerRequestVersion = 0
    private var popupTrailerWebView: WebView? = null
    private var popupTrailerAutoRunnable: Runnable? = null
    private var trailerMuteHideRunnable: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_media_details)
        settingsRepository = SettingsRepository(this)
        trailerPlayerView = findViewById(R.id.detailsTrailerPlayer)
        popupTrailerPlayerView = findViewById(R.id.detailsTrailerPopupPlayer)
        trailerMuteButton = findViewById(R.id.detailsTrailerMute)
        playTrailerButton = findViewById(R.id.detailsPlayTrailer)
        trailerPopupOverlay = findViewById(R.id.detailsTrailerPopupOverlay)
        trailerLoadingText = findViewById(R.id.detailsTrailerLoading)
        trailerPlayerView.useController = false
        popupTrailerPlayerView.useController = false
        trailerMuteButton.visibility = View.GONE
        findViewById<TextView>(R.id.detailsTrailerPopupClose).visibility = View.GONE

        val backdrop = intent.getStringExtra(EXTRA_BACKDROP_URL).orEmpty()
        val logo = intent.getStringExtra(EXTRA_LOGO_URL).orEmpty()
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val meta = intent.getStringExtra(EXTRA_META_LINE).orEmpty()
        val desc = intent.getStringExtra(EXTRA_DESC).orEmpty()
        val poster = intent.getStringExtra(EXTRA_POSTER_URL).orEmpty()
        val externalId = intent.getStringExtra(EXTRA_EXTERNAL_ID).orEmpty()
        val mediaType = intent.getStringExtra(EXTRA_MEDIA_TYPE).orEmpty().ifBlank { "movie" }

        Glide.with(this).load(upgradeArtworkUrl(backdrop.ifBlank { poster })).override(com.bumptech.glide.request.target.Target.SIZE_ORIGINAL).diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.ALL).centerCrop().into(findViewById<ImageView>(R.id.detailsBackdrop))

        val logoView = findViewById<ImageView>(R.id.detailsLogo)
        val titleView = findViewById<TextView>(R.id.detailsTitle)
        if (logo.isNotBlank()) {
            Glide.with(this).load(logo).fitCenter().into(logoView)
        } else {
            logoView.visibility = View.GONE
            titleView.text = title
            titleView.visibility = TextView.VISIBLE
        }

        findViewById<TextView>(R.id.detailsMeta).text = meta
        findViewById<TextView>(R.id.detailsDesc).text = desc

        val favoriteButton = findViewById<Button>(R.id.detailsFavorite)
        val favoriteKey = "favorite_${mediaType}_${externalId.ifBlank { title }}"
        val prefs = getSharedPreferences("debrid_channels_favorites", MODE_PRIVATE)
        fun refreshFavoriteButton() {
            favoriteButton.text = if (prefs.getBoolean(favoriteKey, false)) "✓" else "♡"
        }
        refreshFavoriteButton()
        favoriteButton.setOnClickListener {
            val next = !prefs.getBoolean(favoriteKey, false)
            prefs.edit().putBoolean(favoriteKey, next).apply()
            refreshFavoriteButton()
            Toast.makeText(this, if (next) "Added to favorites" else "Removed from favorites", Toast.LENGTH_SHORT).show()
        }

        buildCastRow()
        buildRelatedRow(title, poster.ifBlank { backdrop })

        val trailerSettings = settingsRepository.loadTrailers()
        val trailerLocation = trailerSettings.playbackLocation.lowercase()
        val detailsTrailersAllowed = trailerSettings.enabled && trailerLocation != "off" && trailerLocation != "hero"
        if (detailsTrailersAllowed) {
            playTrailerButton.visibility = View.VISIBLE
            trailerMuteButton.visibility = View.GONE
            prewarmTrailer(title, meta, mediaType, externalId)
            playTrailerButton.setOnClickListener { showTrailerPopup(title, meta, mediaType, externalId) }
            popupTrailerAutoRunnable = Runnable {
                if (!isFinishing && !isDestroyed && trailerPopupOverlay.visibility != View.VISIBLE) {
                    showTrailerPopup(title, meta, mediaType, externalId)
                }
            }
            mainHandler.postDelayed(popupTrailerAutoRunnable!!, 5000L)
            scheduleBackgroundTrailer(title, meta, mediaType, externalId)
        } else {
            playTrailerButton.visibility = View.GONE
            trailerMuteButton.visibility = View.GONE
        }

        val detailsPlayButton = findViewById<Button>(R.id.detailsPlay)
        var effectiveMediaType = mediaType
        var effectiveExternalId = externalId
        var treatAsSeries = isSeriesMediaType(effectiveMediaType)
        fun refreshPlayButton() {
            detailsPlayButton.text = if (treatAsSeries) "Browse Episodes" else "Play"
        }
        refreshPlayButton()

        // Do NOT auto-convert movies into series by title search.
        // Some movies share titles with shows, and that caused movie pages to show "Browse Episodes".
        // Only explicit media types (series/show/tv) should open SeasonEpisodeActivity.
        detailsPlayButton.setOnClickListener {
            stopBackgroundTrailer()
            if (treatAsSeries) {
                startActivity(Intent(this, SeasonEpisodeActivity::class.java).apply {
                    putExtra(SeasonEpisodeActivity.EXTRA_TITLE, title)
                    putExtra(SeasonEpisodeActivity.EXTRA_MEDIA_TYPE, "series")
                    putExtra(SeasonEpisodeActivity.EXTRA_EXTERNAL_ID, effectiveExternalId)
                    putExtra(SeasonEpisodeActivity.EXTRA_POSTER_URL, poster)
                    putExtra(SeasonEpisodeActivity.EXTRA_BACKDROP_URL, backdrop.ifBlank { poster })
                    putExtra(SeasonEpisodeActivity.EXTRA_LOGO_URL, logo)
                    putExtra(SeasonEpisodeActivity.EXTRA_ITEM_META, meta)
                    putExtra(SeasonEpisodeActivity.EXTRA_DESC, desc)
                })
            } else {
                startActivity(Intent(this, SourceSelectionActivity::class.java).apply {
                    putExtra(SourceSelectionActivity.EXTRA_TITLE, title)
                    putExtra(SourceSelectionActivity.EXTRA_MEDIA_TYPE, effectiveMediaType)
                    putExtra(SourceSelectionActivity.EXTRA_EXTERNAL_ID, effectiveExternalId)
                    putExtra(SourceSelectionActivity.EXTRA_ARTWORK_URL, backdrop.ifBlank { poster })
                    putExtra(SourceSelectionActivity.EXTRA_BACKDROP_URL, backdrop.ifBlank { poster })
                    putExtra(SourceSelectionActivity.EXTRA_LOGO_URL, logo)
                    putExtra(SourceSelectionActivity.EXTRA_POSTER_URL, poster)
                    putExtra(SourceSelectionActivity.EXTRA_META_LINE, meta)
                    putExtra(SourceSelectionActivity.EXTRA_DESC, desc)
                })
            }
        }
    }


    private fun isSeriesMediaType(mediaType: String): Boolean {
        return mediaType.equals("series", ignoreCase = true) ||
            mediaType.equals("show", ignoreCase = true) ||
            mediaType.equals("tv", ignoreCase = true)
    }

    private fun resolveSeriesIdFromCinemeta(queryTitle: String): String {
        val cleanedTitle = queryTitle.trim()
        if (cleanedTitle.isBlank()) return ""
        return runCatching {
            val encoded = URLEncoder.encode(cleanedTitle, "UTF-8").replace("+", "%20")
            val searchUrls = listOf(
                "https://v3-cinemeta.strem.io/catalog/series/top/search=$encoded.json",
                "https://v3-cinemeta.strem.io/catalog/series/popular/search=$encoded.json",
                "https://v3-cinemeta.strem.io/catalog/series/imdbRating/search=$encoded.json"
            )
            for (urlValue in searchUrls) {
                val body = fetchSmallJsonBody(urlValue)
                val metas = JSONObject(body).optJSONArray("metas") ?: continue
                for (i in 0 until metas.length()) {
                    val meta = metas.optJSONObject(i) ?: continue
                    val name = meta.optString("name").ifBlank { meta.optString("title") }
                    val id = meta.optString("id").trim()
                    val imdbId = meta.optString("imdb_id").trim().ifBlank { meta.optString("imdbId").trim() }
                    val candidate = imdbId.ifBlank { id }
                    if (candidate.isNotBlank() && titlesLooselyMatch(cleanedTitle, name)) return@runCatching candidate
                }
            }
            ""
        }.getOrDefault("")
    }

    private fun fetchSmallJsonBody(urlValue: String): String {
        val connection = (URL(urlValue).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 7000
            readTimeout = 10000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "ChannelsDebridTV/1.0")
        }
        return try {
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        } finally {
            connection.disconnect()
        }
    }

    private fun titlesLooselyMatch(a: String, b: String): Boolean {
        fun normalize(value: String): String = value.lowercase(java.util.Locale.US)
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()
        val left = normalize(a)
        val right = normalize(b)
        if (left.isBlank() || right.isBlank()) return false
        return left == right || left.contains(right) || right.contains(left)
    }

    private fun prewarmTrailer(title: String, meta: String, mediaType: String, externalId: String) {
        if (title.isBlank()) return
        trailerExecutor.execute {
            runCatching {
                val liveBackend = settingsRepository.loadLiveBackend()
                val backendBase = liveBackend.baseUrl.ifBlank { "http://192.168.100.55:8181" }.trimEnd('/')
                val year = Regex("(19|20)\\d{2}").find(meta)?.value.orEmpty()
                val body = JSONObject().apply {
                    put("prefer4k", false)
                    put("items", org.json.JSONArray().put(JSONObject().apply {
                        put("title", title)
                        put("year", year)
                        put("type", mediaType.ifBlank { "movie" })
                        put("externalId", externalId)
                    }))
                }.toString()
                val connection = (URL("$backendBase/trailers/prewarm").openConnection() as HttpURLConnection).apply {
                    connectTimeout = 4000
                    readTimeout = 4000
                    requestMethod = "POST"
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Accept", "application/json")
                }
                connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                (if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream)?.close()
                connection.disconnect()
            }
        }
    }

    private fun scheduleBackgroundTrailer(title: String, meta: String, mediaType: String, externalId: String) {
        val settings = settingsRepository.loadTrailers()
        if (!settings.enabled || !settings.backgroundAutoplayEnabled || title.isBlank()) return
        val delay = settings.backgroundAutoplayDelayMs.coerceIn(0L, 60000L).let { if (it == 3000L) 5000L else it }
        val requestId = ++trailerRequestVersion
        backgroundTrailerRunnable = Runnable {
            trailerExecutor.execute {
                val stream = resolveBackendTrailerStream(title, meta, mediaType, externalId, settings.prefer4k)
                mainHandler.post {
                    if (requestId == trailerRequestVersion && !isFinishing && !isDestroyed && stream?.playbackUrl?.isNotBlank() == true) {
                        startBackgroundTrailer(stream)
                    }
                }
            }
        }
        mainHandler.postDelayed(backgroundTrailerRunnable!!, delay)
    }

    private fun showTrailerPopup(title: String, meta: String, mediaType: String, externalId: String) {
        val settings = settingsRepository.loadTrailers()
        if (!settings.enabled || title.isBlank()) return
        stopBackgroundTrailer()
        trailerPopupOverlay.visibility = View.VISIBLE
        trailerPopupOverlay.alpha = 0f
        trailerPopupOverlay.animate().alpha(1f).setDuration(160L).start()
        trailerPopupOverlay.requestFocus()
        trailerMuteButton.visibility = View.GONE
        trailerMuteHideRunnable?.let(mainHandler::removeCallbacks)
        trailerLoadingText.text = "Loading trailer…"
        trailerLoadingText.visibility = View.VISIBLE
        val requestId = ++trailerRequestVersion
        trailerExecutor.execute {
            val stream = resolveBackendTrailerStream(title, meta, mediaType, externalId, settings.prefer4k)
            mainHandler.post {
                if (requestId != trailerRequestVersion || isFinishing || isDestroyed) return@post
                if (stream?.playbackUrl?.isNotBlank() == true) {
                    popupTrailerWebView?.let { webView ->
                        (webView.parent as? FrameLayout)?.removeView(webView)
                        webView.destroy()
                    }
                    popupTrailerWebView = null
                    popupTrailerPlayerView.visibility = View.VISIBLE
                    startTrailerStream(stream, popupTrailerPlayerView, repeat = false)
                } else {
                    trailerLoadingText.text = "Trailer unavailable from backend"
                    Toast.makeText(this, "Trailer unavailable from backend", Toast.LENGTH_LONG).show()
                    mainHandler.postDelayed({ if (requestId == trailerRequestVersion) closeTrailerPopup() }, 1200L)
                }
            }
        }
    }

    private fun resolveBackendTrailerStream(title: String, meta: String, mediaType: String, externalId: String, prefer4k: Boolean): TrailerStream? {
        return runCatching {
            val liveBackend = settingsRepository.loadLiveBackend()
            val backendBase = liveBackend.baseUrl.ifBlank { "http://192.168.100.55:8181" }.trimEnd('/')
            val encodedTitle = URLEncoder.encode(title.trim(), "UTF-8")
            val year = Regex("(19|20)\\d{2}").find(meta)?.value.orEmpty()
            val requestedQuality = if (prefer4k) "2160p,1080p" else "1080p"
            val query = buildString {
                append("title=").append(encodedTitle)
                append("&year=").append(URLEncoder.encode(year, "UTF-8"))
                append("&type=").append(URLEncoder.encode(mediaType.ifBlank { "movie" }, "UTF-8"))
                append("&externalId=").append(URLEncoder.encode(externalId, "UTF-8"))
                append("&mediaId=").append(URLEncoder.encode(externalId, "UTF-8"))
                append("&quality=").append(URLEncoder.encode(requestedQuality, "UTF-8"))
                append("&prefer4k=").append(if (prefer4k) "true" else "false")
                append("&strictTitle=false&officialOnly=false")
            }
            val url = URL("$backendBase/trailers/resolve?$query")
            val connection = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 60000
                requestMethod = "GET"
                setRequestProperty("Accept", "application/json")
            }
            val response = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            response?.bufferedReader()?.use { reader ->
                val json = JSONObject(reader.readText())
                if (!json.optBoolean("ok", false)) return null
                val trailer = json.optJSONObject("trailer") ?: json
                val videoUrl = trailer.optString("videoUrl").ifBlank { trailer.optString("video_url") }
                val audioUrl = trailer.optString("audioUrl").ifBlank { trailer.optString("audio_url") }
                val playbackUrl = videoUrl.ifBlank { trailer.optString("playbackUrl").ifBlank { trailer.optString("url") }.ifBlank { trailer.optString("directUrl") }.ifBlank { trailer.optString("streamUrl") } }
                val resolvedTitle = trailer.optString("title")
                if (playbackUrl.isBlank()) return null
                // Backend scoring already filters the candidate; do not hide playable trailers with overly strict app-side title rejection.
                TrailerStream(
                    playbackUrl = playbackUrl,
                    audioUrl = audioUrl,
                    mimeType = trailer.optString("videoMimeType").ifBlank { trailer.optString("mimeType") },
                    audioMimeType = trailer.optString("audioMimeType"),
                    quality = trailer.optString("quality"),
                    allow4k = prefer4k
                )
            }
        }.getOrNull()
    }

    private fun buildYouTubeTrailerQuery(title: String, meta: String, mediaType: String): String {
        val year = Regex("(19|20)\\d{2}").find(meta)?.value.orEmpty()
        val typeHint = if (isSeriesMediaType(mediaType)) "series" else "movie"
        return listOf(title.trim(), year, typeHint, "official trailer")
            .filter { it.isNotBlank() }
            .joinToString(" ")
    }

    private fun startYouTubeTrailerSearch(title: String, meta: String, mediaType: String) {
        startYouTubeWebView(buildYouTubeTrailerQuery(title, meta, mediaType))
    }

    private fun startYouTubeTrailer(videoId: String) {
        startYouTubeWebView(videoId, isVideoId = true)
    }

    private fun startYouTubeWebView(value: String, isVideoId: Boolean = false) {
        releaseTrailerPlayer()
        popupTrailerPlayerView.player = null
        popupTrailerPlayerView.visibility = View.GONE
        val container = popupTrailerPlayerView.parent as? FrameLayout ?: return
        popupTrailerWebView?.let {
            container.removeView(it)
            it.destroy()
        }
        val webView = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            isFocusable = true
            isFocusableInTouchMode = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            setOnKeyListener { _, keyCode, event ->
                if (keyCode == android.view.KeyEvent.KEYCODE_BACK && event.action == android.view.KeyEvent.ACTION_DOWN) {
                    closeTrailerPopup()
                    true
                } else false
            }
        }
        popupTrailerWebView = webView
        container.addView(webView, 0, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        trailerLoadingText.visibility = View.GONE
        val src = if (isVideoId) {
            "https://www.youtube.com/embed/${Uri.encode(value)}?autoplay=1&playsinline=1&rel=0&modestbranding=1&vq=hd1080"
        } else {
            val q = URLEncoder.encode(value, "UTF-8").replace("+", "%20")
            "https://www.youtube.com/embed?listType=search&list=$q&autoplay=1&playsinline=1&rel=0&modestbranding=1&vq=hd1080"
        }
        val html = """
            <!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
            <style>html,body,#player{margin:0;width:100%;height:100%;background:#000;overflow:hidden}</style></head>
            <body><iframe id="player" src="$src" frameborder="0" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe></body></html>
        """.trimIndent()
        webView.loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "UTF-8", null)
        webView.requestFocus()
    }

    private fun looksLikeTrailerForTitle(candidate: String, expected: String): Boolean {
        fun normalize(value: String): Set<String> = value.lowercase()
            .replace(Regex("[^a-z0-9 ]"), " ")
            .split(Regex("\\s+"))
            .filter { it.length > 2 && it !in setOf("the", "and", "official", "trailer", "teaser", "clip", "movie", "series", "season") }
            .toSet()
        val expectedWords = normalize(expected)
        if (expectedWords.isEmpty()) return true
        val candidateWords = normalize(candidate)
        return expectedWords.count { it in candidateWords } >= minOf(2, expectedWords.size)
    }

    private fun startBackgroundTrailer(stream: TrailerStream) {
        startTrailerStream(stream, trailerPlayerView, repeat = true)
        trailerPlayerView.visibility = View.VISIBLE
        trailerPlayerView.animate().alpha(1f).setDuration(350L).start()
    }

    private fun startTrailerStream(stream: TrailerStream, playerView: PlayerView, repeat: Boolean) {
        releaseTrailerPlayer()
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Android TV; ChannelsDebrid)")
            .setAllowCrossProtocolRedirects(true)
        val mediaSourceFactory = DefaultMediaSourceFactory(this).setDataSourceFactory(httpFactory)
        val trackSelector = DefaultTrackSelector(this).apply {
            setParameters(
                buildUponParameters()
                    .setMaxVideoSize(if (stream.allow4k) 3840 else 1920, if (stream.allow4k) 2160 else 1080)
                    .setMinVideoSize(1280, 720)
                    .setForceHighestSupportedBitrate(true)
            )
        }
        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(mediaSourceFactory)
            .setTrackSelector(trackSelector)
            .build()
        backgroundTrailerPlayer = player
        playerView.player = player
        val videoItemBuilder = MediaItem.Builder().setUri(stream.playbackUrl)
        if (stream.mimeType.contains("dash", ignoreCase = true) || stream.playbackUrl.contains(".mpd", ignoreCase = true)) {
            videoItemBuilder.setMimeType(MimeTypes.APPLICATION_MPD)
        } else if (stream.mimeType.contains("hls", ignoreCase = true) || stream.playbackUrl.contains(".m3u8", ignoreCase = true)) {
            videoItemBuilder.setMimeType(MimeTypes.APPLICATION_M3U8)
        }
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) trailerLoadingText.visibility = View.GONE
                if (playbackState == Player.STATE_ENDED && !repeat) closeTrailerPopup()
            }
        })
        if (stream.audioUrl.isNotBlank()) {
            val audioItemBuilder = MediaItem.Builder().setUri(stream.audioUrl)
            if (stream.audioMimeType.contains("dash", ignoreCase = true) || stream.audioUrl.contains(".mpd", ignoreCase = true)) {
                audioItemBuilder.setMimeType(MimeTypes.APPLICATION_MPD)
            } else if (stream.audioMimeType.contains("hls", ignoreCase = true) || stream.audioUrl.contains(".m3u8", ignoreCase = true)) {
                audioItemBuilder.setMimeType(MimeTypes.APPLICATION_M3U8)
            }
            val videoSource = mediaSourceFactory.createMediaSource(videoItemBuilder.build())
            val audioSource = mediaSourceFactory.createMediaSource(audioItemBuilder.build())
            player.setMediaSource(MergingMediaSource(videoSource, audioSource))
        } else {
            player.setMediaItem(videoItemBuilder.build())
        }
        player.repeatMode = if (repeat) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        player.volume = 1f
        player.prepare()
        player.playWhenReady = true
    }

    private fun toggleTrailerMute() {
        trailerMuted = false
        backgroundTrailerPlayer?.volume = 1f
        trailerMuteButton.visibility = View.GONE
    }

    private fun refreshTrailerMuteButton() {
        if (::trailerMuteButton.isInitialized) {
            trailerMuteButton.visibility = View.GONE
        }
    }

    private fun closeTrailerPopup() {
        trailerRequestVersion++
        releaseTrailerPlayer()
        popupTrailerWebView?.let { webView ->
            (webView.parent as? FrameLayout)?.removeView(webView)
            webView.destroy()
        }
        popupTrailerWebView = null
        popupTrailerPlayerView.visibility = View.VISIBLE
        popupTrailerPlayerView.player = null
        trailerPopupOverlay.animate().cancel()
        trailerPopupOverlay.animate().alpha(0f).setDuration(140L).withEndAction {
            trailerPopupOverlay.visibility = View.GONE
            if (settingsRepository.loadTrailers().popupMode.contains("popup", ignoreCase = true)) {
                trailerMuteButton.visibility = View.GONE
            }
        }.start()
    }

    private fun stopBackgroundTrailer() {
        trailerRequestVersion++
        popupTrailerAutoRunnable?.let(mainHandler::removeCallbacks)
        trailerMuteHideRunnable?.let(mainHandler::removeCallbacks)
        popupTrailerAutoRunnable = null
        backgroundTrailerRunnable?.let(mainHandler::removeCallbacks)
        backgroundTrailerRunnable = null
        trailerPlayerView.animate().cancel()
        trailerPlayerView.alpha = 0f
        trailerPlayerView.visibility = View.GONE
        trailerPlayerView.player = null
        popupTrailerPlayerView.player = null
        releaseTrailerPlayer()
    }

    private fun releaseTrailerPlayer() {
        backgroundTrailerPlayer?.release()
        backgroundTrailerPlayer = null
    }

    override fun onBackPressed() {
        if (::trailerPopupOverlay.isInitialized && trailerPopupOverlay.visibility == View.VISIBLE) {
            closeTrailerPopup()
            return
        }
        super.onBackPressed()
    }

    override fun onStop() {
        super.onStop()
        closeTrailerPopup()
        stopBackgroundTrailer()
    }

    override fun onDestroy() {
        stopBackgroundTrailer()
        trailerExecutor.shutdownNow()
        super.onDestroy()
    }

    private fun buildCastRow() {
        val row = findViewById<LinearLayout>(R.id.detailsCastRow)
        row.removeAllViews()
        listOf("Cast", "Director", "Creator", "Similar Tone").forEach { label ->
            val chip = TextView(this).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 15f
                gravity = Gravity.CENTER
                setPadding(22, 0, 22, 0)
                background = makePillDrawable(0x33FFFFFF, 0x33FFFFFF)
            }
            row.addView(chip, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 58).apply { marginEnd = 12 })
        }
    }

    private fun buildRelatedRow(title: String, artwork: String) {
        val row = findViewById<LinearLayout>(R.id.detailsRelatedRow)
        row.removeAllViews()
        repeat(4) { index ->
            val frame = FrameLayout(this).apply {
                background = makePillDrawable(0x22000000, 0x44FFFFFF)
                isFocusable = true
            }
            val image = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            frame.addView(image, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            if (artwork.isNotBlank()) Glide.with(this).load(artwork).centerCrop().into(image)
            val label = TextView(this).apply {
                text = if (index == 0) title else "Related"
                setTextColor(Color.WHITE)
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.BOTTOM or Gravity.START
                setPadding(12, 0, 12, 12)
            }
            frame.addView(label, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            row.addView(frame, LinearLayout.LayoutParams(150, 92).apply { marginEnd = 14 })
        }
    }


    private fun upgradeArtworkUrl(url: String): String {
        return url
            .replace("/t/p/w92/", "/t/p/original/")
            .replace("/t/p/w154/", "/t/p/original/")
            .replace("/t/p/w185/", "/t/p/original/")
            .replace("/t/p/w342/", "/t/p/original/")
            .replace("/t/p/w500/", "/t/p/original/")
            .replace("/t/p/w780/", "/t/p/original/")
            .replace("/poster/small/", "/poster/large/")
            .replace("/poster/medium/", "/poster/large/")
    }

    private fun makePillDrawable(fill: Int, stroke: Int): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = 18f
            setColor(fill)
            setStroke(1, stroke)
        }
    }

    private data class TrailerStream(
        val playbackUrl: String,
        val audioUrl: String = "",
        val mimeType: String,
        val audioMimeType: String = "",
        val quality: String,
        val allow4k: Boolean = false
    )

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_META_LINE = "meta_line"
        const val EXTRA_DESC = "desc"
        const val EXTRA_MEDIA_TYPE = "media_type"
        const val EXTRA_EXTERNAL_ID = "external_id"
        const val EXTRA_POSTER_URL = "poster_url"
        const val EXTRA_BACKDROP_URL = "backdrop_url"
        const val EXTRA_LOGO_URL = "logo_url"
    }
}
