package com.channelsdebrid.tv.playback

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.channelsdebrid.tv.R
import com.channelsdebrid.tv.settings.SettingsRepository
import java.util.concurrent.Executors

class SourceSelectionActivity : AppCompatActivity() {
    private lateinit var settingsRepository: SettingsRepository
    private val resolver = StreamingPipelineResolver()
    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var container: LinearLayout
    private lateinit var loading: ProgressBar
    private lateinit var status: TextView
    private lateinit var backgroundView: ImageView
    private lateinit var posterView: ImageView
    private lateinit var metaView: TextView
    private var options: List<StreamingPipelineResolver.StreamOption> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_source_selection)
        settingsRepository = SettingsRepository(this)
        container = findViewById(R.id.sourceList)
        loading = findViewById(R.id.sourceLoading)
        status = findViewById(R.id.sourceStatus)
        backgroundView = findViewById(R.id.sourceBackdrop)
        posterView = findViewById(R.id.sourcePoster)
        metaView = findViewById(R.id.sourceMeta)
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val backdropUrl = intent.getStringExtra(EXTRA_ARTWORK_URL).orEmpty()
        val posterUrl = intent.getStringExtra(EXTRA_POSTER_URL).orEmpty()
        findViewById<TextView>(R.id.sourceTitle).text = title
        metaView.text = intent.getStringExtra(EXTRA_META_LINE).orEmpty()
        if (backdropUrl.isNotBlank()) {
            com.bumptech.glide.Glide.with(this)
                .load(upgradeArtworkUrl(backdropUrl))
                .override(com.bumptech.glide.request.target.Target.SIZE_ORIGINAL)
                .diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.ALL)
                .centerCrop()
                .into(backgroundView)
        }
        if (posterUrl.isNotBlank()) {
            com.bumptech.glide.Glide.with(this)
                .load(upgradeArtworkUrl(posterUrl))
                .override(com.bumptech.glide.request.target.Target.SIZE_ORIGINAL)
                .diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.ALL)
                .centerCrop()
                .into(posterView)
        } else {
            posterView.visibility = View.GONE
        }
        loadSources()
    }

    private fun loadSources() {
        loading.visibility = View.VISIBLE
        status.text = "Loading sources…"
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val externalId = intent.getStringExtra(EXTRA_EXTERNAL_ID).orEmpty()
        val mediaType = intent.getStringExtra(EXTRA_MEDIA_TYPE).orEmpty()
        val addons = settingsRepository.loadStremioAddons()
        val playback = settingsRepository.loadPlayback()
        executor.execute {
            val loaded = resolver.listCandidates(title, externalId, mediaType, addons, playback)
            handler.post {
                loading.visibility = View.GONE
                options = loaded
                if (loaded.isEmpty()) {
                    status.text = "No sources found"
                    return@post
                }
                status.text = "Select a source"
                renderOptions()
            }
        }
    }

    private fun renderOptions() {
        container.removeAllViews()
        options.forEachIndexed { index, option ->
            val row = layoutInflater.inflate(R.layout.item_source_option, container, false) as LinearLayout
            row.findViewById<TextView>(R.id.sourcePrimary).text = sourcePrimaryLine(option)
            row.findViewById<TextView>(R.id.sourceSecondary).text = sourceSecondaryLine(option)
            row.findViewById<TextView>(R.id.sourceExtra).text = sourceExtraLine(option)
            row.isFocusable = true
            row.isFocusableInTouchMode = true
            row.setOnClickListener { selectSource(index) }
            row.setOnFocusChangeListener { _, hasFocus ->
                row.scaleX = if (hasFocus) 1.025f else 1f
                row.scaleY = if (hasFocus) 1.025f else 1f
                if (hasFocus) {
                    status.text = "Press OK to play ${option.qualityLabel.ifBlank { option.displayTitle }}"
                }
            }
            row.setOnKeyListener { v, keyCode, event ->
                if (event.action == KeyEvent.ACTION_DOWN && (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER || keyCode == KeyEvent.KEYCODE_BUTTON_A)) {
                    v.performClick()
                    true
                } else false
            }
            container.addView(row)
            if (index == 0) {
                row.post { row.requestFocus() }
            }
        }
    }

    private fun sourcePrimaryLine(option: StreamingPipelineResolver.StreamOption): String {
        val videoFlags = mutableListOf<String>()
        if (option.qualityLabel.isNotBlank()) videoFlags += option.qualityLabel
        if (option.isDolbyVision) videoFlags += "Dolby Vision"
        val title = option.displayTitle.replace(Regex("\\s+"), " ").trim()
        return (videoFlags + listOf(title)).filter { it.isNotBlank() }.joinToString(" • ")
    }

    private fun sourceSecondaryLine(option: StreamingPipelineResolver.StreamOption): String {
        val raw = option.displayTitle.lowercase()
        val parts = mutableListOf<String>()
        if (option.sizeLabel.isNotBlank()) parts += option.sizeLabel
        if (raw.contains("bluray") || raw.contains("blu-ray")) parts += "BluRay"
        if (raw.contains("web-dl") || raw.contains("webdl")) parts += "WEB-DL"
        if (raw.contains("webrip")) parts += "WEBRip"
        if (raw.contains("hevc") || raw.contains("h265") || raw.contains("x265")) parts += "HEVC"
        if (raw.contains("h264") || raw.contains("x264") || raw.contains("avc")) parts += "H.264"
        if (raw.contains("hdr10+")) parts += "HDR10+"
        else if (raw.contains("hdr")) parts += "HDR"
        if (raw.contains("dolby digital plus") || raw.contains("dd+") || raw.contains("eac3")) parts += "Dolby Digital Plus"
        if (raw.contains("5.1")) parts += "5.1"
        if (raw.contains("7.1")) parts += "7.1"
        return parts.distinct().joinToString(" • ").ifBlank { option.sourceLabel }
    }

    private fun sourceExtraLine(option: StreamingPipelineResolver.StreamOption): String {
        val cleanTitle = option.displayTitle.replace(Regex("\\s+"), " ").replace("|", " • ").trim()
        return listOf("Source: ${option.sourceLabel}", cleanTitle).filter { it.isNotBlank() }.joinToString("\n")
    }

    private fun upgradeArtworkUrl(url: String): String {
        return url
            .replace("/t/p/w92/", "/t/p/original/")
            .replace("/t/p/w154/", "/t/p/original/")
            .replace("/t/p/w185/", "/t/p/original/")
            .replace("/t/p/w342/", "/t/p/original/")
            .replace("/t/p/w500/", "/t/p/original/")
            .replace("/t/p/w780/", "/t/p/original/")
            .replace("/poster/small/", "/poster/large/")
            .replace("/poster/medium/", "/poster/large/")
    }

    private fun selectSource(index: Int) {
        loading.visibility = View.VISIBLE
        status.text = "Resolving source…"
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val externalId = intent.getStringExtra(EXTRA_EXTERNAL_ID).orEmpty()
        val mediaType = intent.getStringExtra(EXTRA_MEDIA_TYPE).orEmpty()
        val addons = settingsRepository.loadStremioAddons()
        val debrid = settingsRepository.loadDebrid()
        val playback = settingsRepository.loadPlayback()
        executor.execute {
            val resolved = resolver.resolveAtIndex(title, externalId, mediaType, addons, debrid, playback, index)
            handler.post {
                loading.visibility = View.GONE
                if (resolved == null) {
                    status.text = "Unable to resolve source"
                    Toast.makeText(this, "Unable to resolve source", Toast.LENGTH_LONG).show()
                    return@post
                }
                val option = options.getOrNull(index)
                startActivity(Intent(this, PlayerActivity::class.java).apply {
                    putExtra(PlayerActivity.EXTRA_STREAM_URL, resolved.url)
                    putExtra(PlayerActivity.EXTRA_TITLE, title)
                    putExtra(PlayerActivity.EXTRA_MEDIA_TYPE, mediaType)
                    putExtra(PlayerActivity.EXTRA_EXTERNAL_ID, externalId)
                    putExtra(PlayerActivity.EXTRA_SOURCE_LABEL, resolved.sourceLabel)
                    putExtra(PlayerActivity.EXTRA_DEBUG_LABEL, resolved.debugLabel)
                    putExtra(PlayerActivity.EXTRA_ARTWORK_URL, intent.getStringExtra(EXTRA_ARTWORK_URL).orEmpty())
                    putExtra(PlayerActivity.EXTRA_LOGO_URL, intent.getStringExtra(EXTRA_LOGO_URL).orEmpty())
                    putExtra(PlayerActivity.EXTRA_POSTER_URL, intent.getStringExtra(EXTRA_POSTER_URL).orEmpty())
                    putExtra("meta_line", listOf(option?.qualityLabel.orEmpty(), if (option?.isDolbyVision == true) "Dolby Vision" else "", option?.sizeLabel.orEmpty()).filter { it.isNotBlank() }.joinToString(" • "))
                    putExtra("media_meta_line", intent.getStringExtra(EXTRA_META_LINE).orEmpty())
                    putExtra("overview", intent.getStringExtra(EXTRA_DESC).orEmpty())
                    putExtra("vod_mode", true)
                })
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_MEDIA_TYPE = "media_type"
        const val EXTRA_EXTERNAL_ID = "external_id"
        const val EXTRA_ARTWORK_URL = "artwork_url"
        const val EXTRA_BACKDROP_URL = "backdrop_url"
        const val EXTRA_LOGO_URL = "logo_url"
        const val EXTRA_POSTER_URL = "poster_url"
        const val EXTRA_META_LINE = "meta_line"
        const val EXTRA_DESC = "desc"
        const val EXTRA_ITEM_META = "item_meta"
        const val EXTRA_SERIES_EXTERNAL_ID = "series_external_id"
        const val EXTRA_SERIES_TITLE = "series_title"
    }
}
