package com.channelsdebrid.tv

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.channelsdebrid.tv.data.UnifiedCatalogRepository
import com.channelsdebrid.tv.playback.MediaDetailsActivity
import com.channelsdebrid.tv.playback.PlayerActivity
import java.util.concurrent.Executors

class SearchActivity : AppCompatActivity() {
    private lateinit var queryBox: EditText
    private lateinit var results: LinearLayout
    private lateinit var repo: UnifiedCatalogRepository
    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private var searchVersion = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = UnifiedCatalogRepository(this)
        setContentView(buildLayout())
        renderResults("")
        queryBox.requestFocus()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun buildLayout(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(4, 7, 11))
            setPadding(dp(54), dp(34), dp(54), dp(34))
        }
        root.addView(TextView(this).apply {
            text = "⌕ Search"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Search movies, TV shows, live channels, and guide events across the app"
            textSize = 14f
            setTextColor(0xFFD7CCBF.toInt())
            setPadding(0, dp(4), 0, dp(18))
        })
        queryBox = EditText(this).apply {
            hint = "Type a movie, show, channel, NFL game, team, or program..."
            setSingleLine(true)
            textSize = 22f
            setTextColor(Color.WHITE)
            setHintTextColor(0x88FFFFFF.toInt())
            setPadding(dp(18), 0, dp(18), 0)
            background = rounded(0x22FFFFFF, 0x665EE6FF, dp(18), dp(2))
            minHeight = dp(58)
            setOnEditorActionListener { _, _, _ -> renderResults(text?.toString().orEmpty()); true }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    val version = ++searchVersion
                    handler.postDelayed({ if (version == searchVersion) renderResults(s?.toString().orEmpty()) }, 260L)
                }
                override fun afterTextChanged(s: Editable?) {}
            })
            setOnKeyListener { _, keyCode, event ->
                if (event.action == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                    results.getChildAt(0)?.requestFocus(); true
                } else false
            }
        }
        root.addView(queryBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60)))
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            setPadding(0, dp(24), 0, 0)
        }
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(results)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return root
    }

    private fun renderResults(rawQuery: String) {
        val version = ++searchVersion
        results.removeAllViews()
        results.addView(TextView(this).apply {
            text = if (rawQuery.isBlank()) "Loading unified recommendations…" else "Searching Movies, TV Shows, Live Channels, and Guide…"
            textSize = 18f
            setTextColor(0xCCFFFFFF.toInt())
            setPadding(0, dp(18), 0, 0)
        })
        executor.execute {
            val filtered = repo.search(rawQuery)
            handler.post {
                if (version != searchVersion || isFinishing || isDestroyed) return@post
                results.removeAllViews()
                filtered.forEach { item -> results.addView(resultView(item)) }
                if (filtered.isEmpty()) {
                    results.addView(TextView(this).apply {
                        text = "No movies, shows, live channels, or guide events matched that search."
                        textSize = 18f
                        setTextColor(0xCCFFFFFF.toInt())
                        setPadding(0, dp(18), 0, 0)
                    })
                }
            }
        }
    }

    private fun resultView(item: UnifiedCatalogRepository.MediaItem): TextView {
        return TextView(this).apply {
            text = "${when (item.type) { "series", "tv" -> "📺"; "live" -> "▶"; else -> "🎬" }}  ${item.title}\n${item.meta}"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            isFocusable = true
            isClickable = true
            setPadding(dp(20), 0, dp(20), 0)
            background = rounded(0x18FFFFFF, 0x00000000, dp(18), 0)
            setOnFocusChangeListener { v, hasFocus ->
                v.background = if (hasFocus) rounded(0x335EE6FF, 0xFF5EE6FF.toInt(), dp(18), dp(2)) else rounded(0x18FFFFFF, 0x00000000, dp(18), 0)
                v.animate().scaleX(if (hasFocus) 1.015f else 1f).scaleY(if (hasFocus) 1.015f else 1f).setDuration(120L).start()
            }
            setOnClickListener { openItem(item) }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(86)).apply { bottomMargin = dp(12) }
        }
    }

    private fun openItem(item: UnifiedCatalogRepository.MediaItem) {
        if (item.type == "live" && item.streamUrl.isNotBlank()) {
            startActivity(Intent(this, PlayerActivity::class.java).apply {
                putExtra(PlayerActivity.EXTRA_STREAM_URL, item.streamUrl)
                putExtra(PlayerActivity.EXTRA_TITLE, item.title)
                putExtra(PlayerActivity.EXTRA_SOURCE_LABEL, item.meta)
            })
            return
        }
        startActivity(Intent(this, MediaDetailsActivity::class.java).apply {
            putExtra(MediaDetailsActivity.EXTRA_TITLE, item.title)
            putExtra(MediaDetailsActivity.EXTRA_META_LINE, item.meta)
            putExtra(MediaDetailsActivity.EXTRA_DESC, item.overview)
            putExtra(MediaDetailsActivity.EXTRA_MEDIA_TYPE, if (item.type == "series" || item.type == "tv") "series" else "movie")
            putExtra(MediaDetailsActivity.EXTRA_EXTERNAL_ID, item.externalId)
            putExtra(MediaDetailsActivity.EXTRA_POSTER_URL, item.posterUrl)
            putExtra(MediaDetailsActivity.EXTRA_BACKDROP_URL, item.backdropUrl)
            putExtra(MediaDetailsActivity.EXTRA_LOGO_URL, item.logoUrl)
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int, strokeWidth: Int): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            setColor(fill)
            cornerRadius = radius.toFloat()
            if (strokeWidth > 0) setStroke(strokeWidth, stroke)
        }
    }
}
