# v1.6 Clean Android Build

Android-side cleanup for the v1.5.3 backend trailer fix.

Included:
- Trailer playback remains backend-first and ExoPlayer-based.
- Trailer response parser accepts `trailer.playbackUrl`, `trailer.url`, `trailer.directUrl`, `trailer.streamUrl`, or matching top-level fields.
- Add Favorite and Play Trailer buttons are icon-only on details pages.
- Mute/Unmute trailer control uses glass pill styling and auto-hides after 5 seconds.
- VOD player controls are wired to actual player actions: subtitles, audio, episodes, zoom, and player settings.
- Episode selector from the player carries media type and external id forward instead of falling back to title only.

Pair this APK with `Backend10-v1.5.3-YTDLP-PATH-TRAILER-FIX-FULL.zip` or newer.
