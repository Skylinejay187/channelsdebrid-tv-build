# Debrid Channels v2.0.2 - Stable Navigation System

Fixes the Live TV -> full player -> guide/home navigation desync reported in the video.

Changes:
- Resets playerLaunchInProgress on onResume/onStop so pressing OK works after returning from PlayerActivity.
- Removes the global decorView DPAD listener that could steal focus from Home after leaving Live TV.
- Adds scoped Live TV input ownership with liveTvInputEnabled.
- Releases Live TV navigation ownership before opening Home/Browse/Resume sections.
- Finishes LiveTvActivity when leaving through top-menu sections so delayed guide handlers cannot snap the app back.
- Clears preview callbacks/tokens before screen transitions.
- Restores guide focus safely on resume without blocking child focus.

Expected test flow:
1. Open Live TV guide.
2. Open first channel full player.
3. Back to guide.
4. Open second channel full player with OK.
5. Back to guide, press UP to top menu, open Smart/Home.
6. Home should scroll normally and should not snap back to guide.
