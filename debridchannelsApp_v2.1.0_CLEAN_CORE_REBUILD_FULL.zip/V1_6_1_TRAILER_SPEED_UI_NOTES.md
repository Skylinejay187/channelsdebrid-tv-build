# v1.6.1 Trailer Speed/UI Patch

- Trailer popup starts unmuted by default.
- Removed the X close button from the trailer popup UI. Back button still closes popup only.
- Removed the trailer mute/unmute glass pill from the details screen/popup.
- Android always requests 1080p trailer playback instead of 4K.
- Added details-page trailer prewarm request so backend can begin resolving/caching before the popup opens.
