# v1.9.6 Top Menu + Channels DVR Preview Guard

- Fixed Live TV top menu focus so DPAD_UP from the guide/category area can focus the shared top navigation.
- DPAD_DOWN/BACK from the top navigation returns to the previous Live TV focus zone.
- Added Channels DVR preview protection:
  - slower preview debounce for DVR streams
  - one active DVR preview request at a time
  - minimum cooldown between DVR preview stream opens
  - temporary cooldown after DVR preview errors
  - old preview is stopped/cleared before opening a new DVR preview stream
- Preview remains enabled; fast scrolling no longer opens a stream for every focused DVR channel.
