# V1.6.3 Direct Live Providers

## Live TV architecture
- Channels DVR is no longer treated as a Debrid backend provider.
- Android TV app now owns Live TV providers directly:
  - Channels DVR Direct
  - M3U/IPTV playlist URL
  - Xtream Codes / IPTV credentials
- The backend stays for Debrid, Torbox, Stremio catalogs, metadata, artwork, and trailers.

## Channels DVR Direct
- App reads Channels DVR directly from:
  - `/devices/ANY/channels.m3u?format=ts`
  - `/devices/ANY/guide/xmltv?duration=43200`
- Channels DVR guide XMLTV is cached locally on the Android device for 12 hours.
- Reopening Live TV uses cached channels/guide instantly and skips refresh until cache expiration.

## M3U / Xtream IPTV
- Existing M3U parser remains wired into the unified Live TV provider list.
- Existing Xtream `player_api.php?action=get_live_streams` support remains wired into the unified Live TV provider list.
- Provider categories/groups are kept from M3U `group-title` and Xtream category metadata.

## Playback
- Media3/ExoPlayer remains direct-play only: no backend proxy and no app transcoding.
- Hardware decoder path is preferred with decoder fallback enabled.
- MPEG-TS, HLS, DASH, MP4 and common IPTV URLs are MIME-hinted for better startup.

## Backend cleanup
- Backend Live TV endpoints now return disabled/410 responses.
- Backend worker live refresh interval is disabled.
- Embedded TypeScript backend live route is stubbed as disabled.
