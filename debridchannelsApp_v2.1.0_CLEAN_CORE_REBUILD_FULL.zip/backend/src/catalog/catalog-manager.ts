import { CatalogSource } from "./source.js"
import { CatalogRowDefinition, HomeRow } from "./types.js"

export class CatalogManager {
  constructor(private readonly sources: CatalogSource[]) {}

  async buildRows(rowDefs: CatalogRowDefinition[]): Promise<HomeRow[]> {
    const rows: HomeRow[] = []
    for (const row of rowDefs) {
      const source = this.sources.find(s => s.canHandle(row))
      if (!source) continue
      const items = await source.getItems(row)
      rows.push({ ...row, items })
    }
    return rows
  }
}
