import { Router, Request } from "express"
import fs from "node:fs"
import path from "node:path"
import crypto from "node:crypto"

const CACHE_ROOT = process.env.GUIDE_CACHE_DIR || process.env.EXTERNAL_GUIDE_CACHE_DIR || "/data/debridchannels/guide-cache"
const TIMESHIFT_ROOT = process.env.TIMESHIFT_ROOT || "/data/debridchannels/timeshift"
const PUBLIC_BASE_URL = (process.env.PUBLIC_BASE_URL || "").replace(/\/$/, "")
const CDN_BASE_URL = (process.env.CDN_BASE_URL || PUBLIC_BASE_URL).replace(/\/$/, "")
const DEFAULT_TTL_HOURS = Number(process.env.GUIDE_CACHE_TTL_HOURS || 12)
const MAX_PREVIEW_PER_USER = Number(process.env.MAX_PREVIEW_PER_USER || 1)
const PREVIEW_TTL_MS = Number(process.env.PREVIEW_TTL_MS || 90_000)

type SourceConfig = {
  id: string
  userId: string
  type: string
  label: string
  url?: string
  enabled: boolean
  updatedAt: number
}

type PreviewSession = {
  id: string
  userId: string
  channelId: string
  sourceId: string
  startedAt: number
  expiresAt: number
  status: "active" | "closed"
}

const sources = new Map<string, SourceConfig>()
const previews = new Map<string, PreviewSession>()

function safeUserId(req: Request): string {
  const raw = String(req.query.userId || req.query.user_id || req.body?.userId || req.body?.user_id || "demo")
  return raw.replace(/[^a-zA-Z0-9_.-]/g, "_").slice(0, 80) || "demo"
}

function userGuideDir(userId: string): string {
  return path.join(CACHE_ROOT, userId)
}

function ensureDir(dir: string) {
  fs.mkdirSync(dir, { recursive: true })
}

function jsonFileFor(userId: string, name: string): string {
  ensureDir(userGuideDir(userId))
  return path.join(userGuideDir(userId), name)
}

function publicUrlFor(relativePath: string): string {
  const rel = relativePath.replace(/^\/+/, "")
  return CDN_BASE_URL ? `${CDN_BASE_URL}/${rel}` : `/${rel}`
}

function isFresh(file: string, ttlHours: number): boolean {
  try {
    if (!fs.existsSync(file)) return false
    const ageMs = Date.now() - fs.statSync(file).mtimeMs
    return ageMs < Math.max(1, ttlHours) * 3600_000
  } catch { return false }
}

function channelKey(value: string): string {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]+/g, "").slice(0, 120)
}

function extractProgramsForChannel(guide: any, req: Request): any[] {
  const targetKeys = [channelKey(String(req.query.tvgId || req.query.tvg_id || "")), channelKey(String(req.query.channelName || req.query.channel_name || "")), channelKey(String(req.query.channelNumber || req.query.channel_number || ""))].filter(Boolean)
  const arrays = [guide?.programs, guide?.guide, guide?.items, guide?.data, guide?.results].filter(Array.isArray) as any[][]
  for (const arr of arrays) {
    const matches = arr.filter(item => {
      const keys = [item?.channelId, item?.channel_id, item?.tvgId, item?.tvg_id, item?.channelName, item?.channel_name, item?.number, item?.channelNumber].map((v: any) => channelKey(String(v || ""))).filter(Boolean)
      return targetKeys.length === 0 || keys.some(k => targetKeys.includes(k))
    })
    if (matches.length) return matches.slice(0, 24)
  }
  return []
}


function writeJson(file: string, data: unknown) {
  ensureDir(path.dirname(file))
  fs.writeFileSync(file, JSON.stringify(data, null, 2))
}

function readJson<T>(file: string, fallback: T): T {
  try {
    if (!fs.existsSync(file)) return fallback
    return JSON.parse(fs.readFileSync(file, "utf8")) as T
  } catch {
    return fallback
  }
}

function prunePreviews(userId?: string) {
  const now = Date.now()
  for (const [id, session] of previews.entries()) {
    if (session.expiresAt <= now || session.status === "closed" || (userId && session.userId === userId && session.expiresAt <= now)) {
      previews.delete(id)
    }
  }
}

function activePreviewCount(userId: string): number {
  prunePreviews(userId)
  return Array.from(previews.values()).filter(p => p.userId === userId && p.status === "active").length
}

export function liveRouter() {
  const router = Router()

  router.get("/live/config", (_req, res) => {
    res.json({
      ok: true,
      publicBaseUrl: PUBLIC_BASE_URL || null,
      cdnBaseUrl: CDN_BASE_URL || null,
      guideCacheDir: CACHE_ROOT,
      timeshiftRoot: TIMESHIFT_ROOT,
      guideCacheTtlHours: DEFAULT_TTL_HOURS,
      previewLimitPerUser: MAX_PREVIEW_PER_USER,
      previewTtlMs: PREVIEW_TTL_MS
    })
  })

  router.get("/live/sources", (req, res) => {
    const userId = safeUserId(req)
    res.json({ ok: true, userId, sources: Array.from(sources.values()).filter(s => s.userId === userId) })
  })

  router.post("/live/sources/connect", (req, res) => {
    const userId = safeUserId(req)
    const type = String(req.body?.type || req.body?.provider || "custom")
    const label = String(req.body?.label || req.body?.name || type.toUpperCase())
    const url = String(req.body?.url || req.body?.baseUrl || req.body?.m3uUrl || "")
    const id = String(req.body?.id || crypto.createHash("sha1").update(`${userId}:${type}:${url}:${label}`).digest("hex").slice(0, 16))
    const source: SourceConfig = { id, userId, type, label, url, enabled: true, updatedAt: Date.now() }
    sources.set(`${userId}:${id}`, source)
    res.json({ ok: true, source })
  })

  router.post("/live/refresh", (req, res) => {
    const userId = safeUserId(req)
    const now = Date.now()
    const progress = { ok: true, userId, status: "ready", startedAt: now, finishedAt: now, message: "Guide refresh queued/completed. External cache is ready for app-side guide data." }
    writeJson(jsonFileFor(userId, "progress.json"), progress)
    res.json(progress)
  })

  router.post("/live/epg/settings", (req, res) => {
    const userId = safeUserId(req)
    const ttlHours = Number(req.body?.ttlHours || req.body?.epgRefreshEveryHours || DEFAULT_TTL_HOURS)
    const settings = { ok: true, userId, ttlHours: ttlHours > 0 ? ttlHours : DEFAULT_TTL_HOURS, updatedAt: Date.now(), cacheDir: userGuideDir(userId) }
    writeJson(jsonFileFor(userId, "settings.json"), settings)
    res.json(settings)
  })

  router.post("/live/epg/refresh", (req, res) => {
    const userId = safeUserId(req)
    const now = Date.now()
    const settings = readJson(jsonFileFor(userId, "settings.json"), { ttlHours: DEFAULT_TTL_HOURS }) as { ttlHours?: number }
    const cacheFile = jsonFileFor(userId, "guide.json")
    const guide = {
      ok: true,
      userId,
      generatedAt: now,
      expiresAt: now + Number(settings.ttlHours || DEFAULT_TTL_HOURS) * 3600_000,
      channels: [],
      programs: [],
      message: "External guide cache placeholder. App can merge Channels DVR/M3U/Xtream guide data without blocking RAM."
    }
    writeJson(cacheFile, guide)
    const progress = { ok: true, userId, status: "ready", generatedAt: now, cacheFile, cdnUrl: publicUrlFor(`live/epg/${userId}/guide.json`) }
    writeJson(jsonFileFor(userId, "progress.json"), progress)
    res.json(progress)
  })

  router.get(["/live/epg/progress", "/live/epg/status"], (req, res) => {
    const userId = safeUserId(req)
    const progress = readJson(jsonFileFor(userId, "progress.json"), { ok: true, userId, status: "idle", message: "No guide refresh has run yet" })
    res.json(progress)
  })

  router.put("/live/epg/:userId/guide.json", (req, res) => {
    const userId = String(req.params.userId).replace(/[^a-zA-Z0-9_.-]/g, "_")
    const file = jsonFileFor(userId, "guide.json")
    const now = Date.now()
    const payload = {
      ok: true,
      userId,
      generatedAt: req.body?.generatedAt || now,
      expiresAt: req.body?.expiresAt || now + DEFAULT_TTL_HOURS * 3600_000,
      channels: Array.isArray(req.body?.channels) ? req.body.channels : [],
      programs: Array.isArray(req.body?.programs) ? req.body.programs : [],
      source: req.body?.source || "app-upload"
    }
    writeJson(file, payload)
    const progress = { ok: true, userId, status: "ready", generatedAt: now, cacheFile: file, cdnUrl: publicUrlFor(`live/epg/${userId}/guide.json`) }
    writeJson(jsonFileFor(userId, "progress.json"), progress)
    res.json(progress)
  })

  router.get(["/live/guide", "/live/epg"], (req, res) => {
    const userId = safeUserId(req)
    const file = jsonFileFor(userId, "guide.json")
    const guide = readJson<any>(file, { ok: true, userId, channels: [], programs: [] })
    const programs = extractProgramsForChannel(guide, req)
    res.setHeader("Cache-Control", "public, max-age=120, stale-while-revalidate=600")
    res.json({ ok: true, userId, cacheFresh: isFresh(file, DEFAULT_TTL_HOURS), programs })
  })

  router.get("/live/cache/status", (req, res) => {
    const userId = safeUserId(req)
    const guideFile = jsonFileFor(userId, "guide.json")
    res.json({ ok: true, userId, guideExists: fs.existsSync(guideFile), guideFresh: isFresh(guideFile, DEFAULT_TTL_HOURS), guideUrl: publicUrlFor(`live/epg/${userId}/guide.json`), cacheDir: userGuideDir(userId), timeshiftRoot: TIMESHIFT_ROOT, cdnBaseUrl: CDN_BASE_URL || null })
  })

  router.get("/live/epg/:userId/guide.json", (req, res) => {
    const userId = String(req.params.userId).replace(/[^a-zA-Z0-9_.-]/g, "_")
    const file = jsonFileFor(userId, "guide.json")
    res.setHeader("Cache-Control", "public, max-age=300, stale-while-revalidate=3600")
    if (fs.existsSync(file)) return res.sendFile(file)
    res.json({ ok: true, userId, channels: [], programs: [], message: "Guide cache empty" })
  })

  router.post("/live/preview/start", (req, res) => {
    const userId = safeUserId(req)
    prunePreviews(userId)
    if (activePreviewCount(userId) >= MAX_PREVIEW_PER_USER) {
      return res.status(429).json({ ok: false, protected: true, message: "Preview limit reached. Close the current preview before starting another." })
    }
    const session: PreviewSession = {
      id: crypto.randomUUID(),
      userId,
      channelId: String(req.body?.channelId || req.body?.channel_id || "unknown"),
      sourceId: String(req.body?.sourceId || req.body?.source_id || "unknown"),
      startedAt: Date.now(),
      expiresAt: Date.now() + PREVIEW_TTL_MS,
      status: "active"
    }
    previews.set(session.id, session)
    res.json({ ok: true, preview: session })
  })

  router.post("/live/preview/heartbeat", (req, res) => {
    const id = String(req.body?.previewId || req.body?.preview_id || "")
    const session = previews.get(id)
    if (!session) return res.status(404).json({ ok: false, message: "Preview session expired" })
    session.expiresAt = Date.now() + PREVIEW_TTL_MS
    previews.set(id, session)
    res.json({ ok: true, preview: session })
  })

  router.post("/live/preview/stop", (req, res) => {
    const id = String(req.body?.previewId || req.body?.preview_id || "")
    if (id) previews.delete(id)
    res.json({ ok: true })
  })

  router.post("/live/timeshift/session", (req, res) => {
    const userId = safeUserId(req)
    const sessionId = crypto.randomUUID()
    const dir = path.join(TIMESHIFT_ROOT, userId, sessionId)
    ensureDir(dir)
    const maxMinutes = Math.max(15, Math.min(240, Number(req.body?.minutes || 90)))
    const manifest = { ok: true, userId, sessionId, dir, startedAt: Date.now(), maxMinutes, statusUrl: publicUrlFor(`live/timeshift/${userId}/${sessionId}/session.json`) }
    writeJson(path.join(dir, "session.json"), manifest)
    res.json(manifest)
  })

  router.get("/live/timeshift/:userId/:sessionId/session.json", (req, res) => {
    const userId = String(req.params.userId).replace(/[^a-zA-Z0-9_.-]/g, "_")
    const sessionId = String(req.params.sessionId).replace(/[^a-zA-Z0-9_.-]/g, "_")
    const file = path.join(TIMESHIFT_ROOT, userId, sessionId, "session.json")
    res.setHeader("Cache-Control", "no-store")
    if (fs.existsSync(file)) return res.sendFile(file)
    res.status(404).json({ ok: false, message: "Timeshift session not found" })
  })

  router.delete("/live/timeshift/:userId/:sessionId", (req, res) => {
    const userId = String(req.params.userId).replace(/[^a-zA-Z0-9_.-]/g, "_")
    const sessionId = String(req.params.sessionId).replace(/[^a-zA-Z0-9_.-]/g, "_")
    const dir = path.join(TIMESHIFT_ROOT, userId, sessionId)
    try { fs.rmSync(dir, { recursive: true, force: true }) } catch {}
    res.json({ ok: true })
  })

  return router
}
