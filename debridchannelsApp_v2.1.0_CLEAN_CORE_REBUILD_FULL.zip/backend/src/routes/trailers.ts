import { Router } from "express"
import { execFile } from "child_process"

type TrailerResolveInput = {
  title: string
  year?: string
  prefer4k?: boolean
  mediaId?: string
  mediaType?: string
}

type TrailerStream = {
  videoId: string
  title: string
  channel: string
  duration: number
  playbackUrl: string
  mimeType: string
  quality: string
  maxHeight?: number
  fallbackUsed?: boolean
  source: string
  searchTitle?: string
  cached?: boolean
}

const trailerCache = new Map<string, { expiresAt: number; value: TrailerStream }>()
const inflightTrailerResolves = new Map<string, Promise<TrailerStream>>()
const TRAILER_CACHE_TTL_MS = Number(process.env.TRAILER_CACHE_TTL_MS || 6 * 60 * 60 * 1000)
const YTDLP_TIMEOUT_MS = Number(process.env.YTDLP_TIMEOUT_MS || 35000)

function execYtDlp(args: string[], timeoutMs = 25000): Promise<string> {
  return new Promise((resolve, reject) => {
    execFile(process.env.YTDLP_BIN || "yt-dlp", args, { timeout: timeoutMs, maxBuffer: 1024 * 1024 * 10 }, (err, stdout, stderr) => {
      if (err) {
        err.message = [err.message, stderr].filter(Boolean).join("\n")
        reject(err)
        return
      }
      resolve(stdout)
    })
  })
}

function cleanTitleForTrailer(title: string): string {
  return String(title || "")
    .replace(/\s*[•|-]\s*(S\d+|Season\s+\d+|Episode\s+\d+|E\d+).*$/i, "")
    .replace(/\s*\((19|20)\d{2}\)\s*$/i, "")
    .replace(/\s+/g, " ")
    .trim()
}

function trailerSearchQuery(title: string, year?: string): string {
  return [cleanTitleForTrailer(title), year, "official trailer"].filter(Boolean).join(" ")
}

function titleTokens(value: string): string[] {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9 ]+/g, " ")
    .split(/\s+/)
    .filter(t => t.length > 1 && !["the", "and", "official", "trailer", "teaser", "movie", "film", "series", "season", "clip", "hd", "4k", "uhd"].includes(t))
}

function normalizeQualityLabel(height?: number, fallback = "best"): string {
  if (!height) return fallback
  if (height >= 2160) return "2160p 4K"
  if (height >= 1440) return "1440p"
  if (height >= 1080) return "1080p"
  return `${height}p`
}

function scoreTrailerCandidate(entry: any, requestedTitle: string, requestedYear?: string): number {
  const reqTokens = titleTokens(cleanTitleForTrailer(requestedTitle))
  const haystack = `${entry.title || ""} ${entry.channel || ""} ${entry.uploader || ""} ${entry.description || ""}`.toLowerCase()
  let score = 0
  for (const token of reqTokens) score += haystack.includes(token) ? 12 : -18
  if (/official trailer/i.test(entry.title || "")) score += 40
  if (/trailer/i.test(entry.title || "")) score += 15
  if (/teaser/i.test(entry.title || "")) score -= 8
  if (/fan\s*made|concept|reaction|review|breakdown|explained|clip|scene|music video/i.test(entry.title || "")) score -= 80
  if (/official/i.test(`${entry.channel || ""} ${entry.uploader || ""}`)) score += 20
  if (/warner|universal|paramount|marvel|disney|pixar|netflix|prime video|hulu|hbo|max|20th century|sony pictures|lionsgate|a24/i.test(`${entry.channel || ""} ${entry.uploader || ""}`)) score += 16
  if (requestedYear && haystack.includes(String(requestedYear))) score += 12
  const duration = Number(entry.duration || 0)
  if (duration > 0) {
    if (duration >= 45 && duration <= 240) score += 10
    if (duration > 420) score -= 30
  }
  return score
}

function bestTrailerEntry(info: any, requestedTitle: string, requestedYear?: string): any {
  const entries = Array.isArray(info.entries) ? info.entries.filter(Boolean) : [info].filter(Boolean)
  if (!entries.length) throw new Error("No trailer results found")
  return entries.map((entry: any) => ({ entry, score: scoreTrailerCandidate(entry, requestedTitle, requestedYear) })).sort((a: any, b: any) => b.score - a.score)[0].entry
}

function bestMuxedFormat(formats: any[], prefer4k: boolean): any | null {
  const withAudioVideo = (formats || []).filter(f => f.url && f.vcodec && f.vcodec !== "none" && f.acodec && f.acodec !== "none")
  const maxHeight = prefer4k ? 2160 : 1080
  const minPreferredHeight = prefer4k ? 1080 : 720
  return withAudioVideo
    .filter(f => !f.height || f.height <= maxHeight)
    .sort((a, b) => {
      const ah = a.height || 0
      const bh = b.height || 0
      const aPreferred = ah >= minPreferredHeight ? 1 : 0
      const bPreferred = bh >= minPreferredHeight ? 1 : 0
      return bPreferred - aPreferred || bh - ah || (b.tbr || 0) - (a.tbr || 0)
    })[0] || null
}

function pickTrailerInfo(info: any, prefer4k: boolean, requestedTitle: string, requestedYear?: string): TrailerStream {
  const chosen = bestTrailerEntry(info, requestedTitle, requestedYear)
  const formats = Array.isArray(chosen.formats) ? chosen.formats : []
  const heights = formats.map((f: any) => Number(f.height || 0)).filter(Boolean)
  const maxAvailableHeight = heights.length ? Math.max(...heights) : 0
  const has4k = maxAvailableHeight >= 2160
  const has1080 = maxAvailableHeight >= 1080
  const manifestUrl = chosen.dash_url || chosen.manifest_url || chosen.hls_url || ""
  if (manifestUrl && (prefer4k || has1080)) {
    return {
      videoId: chosen.id || "",
      title: chosen.title || "",
      channel: chosen.channel || chosen.uploader || "",
      duration: chosen.duration || 0,
      playbackUrl: manifestUrl,
      mimeType: manifestUrl.includes(".m3u8") ? "application/x-mpegURL" : "application/dash+xml",
      quality: has4k && prefer4k ? "2160p 4K adaptive" : (has1080 ? "1080p adaptive" : normalizeQualityLabel(maxAvailableHeight, "adaptive")),
      maxHeight: maxAvailableHeight,
      fallbackUsed: prefer4k && !has4k,
      source: "yt-dlp-adaptive-manifest"
    }
  }
  const muxed = bestMuxedFormat(formats, prefer4k)
  if (muxed) {
    return {
      videoId: chosen.id || "",
      title: chosen.title || "",
      channel: chosen.channel || chosen.uploader || "",
      duration: chosen.duration || 0,
      playbackUrl: muxed.url,
      mimeType: muxed.ext === "m3u8" ? "application/x-mpegURL" : "video/mp4",
      quality: muxed.format_note || normalizeQualityLabel(muxed.height, "best"),
      maxHeight: muxed.height || 0,
      fallbackUsed: prefer4k && (muxed.height || 0) < 2160,
      source: "yt-dlp-direct-muxed"
    }
  }
  if (chosen.url) {
    return {
      videoId: chosen.id || "",
      title: chosen.title || "",
      channel: chosen.channel || chosen.uploader || "",
      duration: chosen.duration || 0,
      playbackUrl: chosen.url,
      mimeType: "video/mp4",
      quality: chosen.format_note || "best",
      source: "yt-dlp-direct"
    }
  }
  throw new Error("No playable trailer stream found")
}

function candidateVideoId(entry: any): string {
  return entry && (entry.id || entry.url || entry.webpage_url || "")
}

async function resolveTrailer({ title, year, prefer4k = false, mediaId = "", mediaType = "movie" }: TrailerResolveInput): Promise<TrailerStream> {
  const cleanTitle = cleanTitleForTrailer(title)
  const cacheKey = [mediaType, mediaId, cleanTitle, year, prefer4k].join("|").toLowerCase()
  const cached = trailerCache.get(cacheKey)
  if (cached && cached.expiresAt > Date.now()) return { ...cached.value, cached: true }
  const inflight = inflightTrailerResolves.get(cacheKey)
  if (inflight) return inflight

  const promise = (async () => {
    const query = trailerSearchQuery(cleanTitle, year)
    const searchStdout = await execYtDlp([
      "--dump-single-json",
      "--no-playlist",
      "--no-warnings",
      "--skip-download",
      "--extractor-args", "youtube:player_client=web,web_creator,tv_embedded,android",
      "ytsearch12:" + query
    ], YTDLP_TIMEOUT_MS)
    const searchInfo = JSON.parse(searchStdout)
    const chosen = bestTrailerEntry(searchInfo, cleanTitle, year)
    const id = candidateVideoId(chosen)
    if (!id) throw new Error("No trailer video id found")
    const videoUrl = String(id).startsWith("http") ? String(id) : `https://www.youtube.com/watch?v=${id}`
    const resolveStdout = await execYtDlp([
      "--dump-single-json",
      "--no-playlist",
      "--no-warnings",
      "--skip-download",
      "--format", prefer4k
        ? "bv*[height>=2160]+ba/bv*[height>=1440]+ba/bv*[height>=1080]+ba/bestvideo[height>=2160]+bestaudio/bestvideo[height>=1440]+bestaudio/bestvideo[height>=1080]+bestaudio/best[height>=1080]/best"
        : "bv*[height>=1080]+ba/bestvideo[height>=1080]+bestaudio/best[height>=1080]/best",
      "--format-sort-force",
      "--format-sort", "res:2160,fps,vcodec:vp9.2,vcodec:vp9,vcodec:av01,vcodec:h264,br",
      "--extractor-args", "youtube:player_client=web,web_creator,tv_embedded,android",
      videoUrl
    ], YTDLP_TIMEOUT_MS)
    const resolvedInfo = JSON.parse(resolveStdout)
    const value = pickTrailerInfo(resolvedInfo, prefer4k, cleanTitle, year)
    value.searchTitle = chosen.title || ""
    trailerCache.set(cacheKey, { value, expiresAt: Date.now() + TRAILER_CACHE_TTL_MS })
    return value
  })().finally(() => inflightTrailerResolves.delete(cacheKey))

  inflightTrailerResolves.set(cacheKey, promise)
  return promise
}

export function trailersRouter() {
  const router = Router()

  router.post("/trailers/prewarm", async (req, res) => {
    const items = Array.isArray(req.body?.items) ? req.body.items.slice(0, 24) : []
    const prefer4k = req.body?.prefer4k !== "false" && req.body?.prefer4k !== false
    for (const item of items) {
      const title = String(item.title || "").trim()
      if (!title) continue
      resolveTrailer({ title, year: String(item.year || "").trim(), prefer4k, mediaId: item.id || item.externalId || item.tmdbId || item.imdbId || title, mediaType: item.type || item.mediaType || "movie" }).catch(() => {})
    }
    res.status(202).json({ ok: true, queued: items.length })
  })

  router.get("/trailers/resolve", async (req, res) => {
    try {
      const title = String(req.query.title ?? "").trim()
      const year = String(req.query.year ?? "").trim()
      const prefer4k = String(req.query.prefer4k ?? "false") !== "false"
      const mediaId = String(req.query.mediaId ?? req.query.id ?? "").trim()
      const mediaType = String(req.query.mediaType ?? req.query.type ?? "movie").trim()
      if (!title) {
        res.status(400).json({ ok: false, error: "title is required" })
        return
      }
      const trailer = await resolveTrailer({ title, year, prefer4k, mediaId, mediaType })
      res.json({ ok: true, trailer })
    } catch (err: any) {
      res.status(502).json({ ok: false, error: err?.message || "Trailer resolver failed", requirement: "Install yt-dlp in the backend container or set YTDLP_BIN." })
    }
  })

  router.get("/api/trailer/:id", async (req, res) => {
    try {
      const title = String(req.query.title ?? req.params.id ?? "").trim()
      const year = String(req.query.year ?? "").trim()
      const prefer4k = String(req.query.prefer4k ?? "false") !== "false"
      const trailer = await resolveTrailer({ title, year, prefer4k, mediaId: req.params.id, mediaType: String(req.query.mediaType ?? "movie") })
      res.json({ ok: true, trailer })
    } catch (err: any) {
      res.status(502).json({ ok: false, error: err?.message || "Trailer resolver failed" })
    }
  })

  return router
}
