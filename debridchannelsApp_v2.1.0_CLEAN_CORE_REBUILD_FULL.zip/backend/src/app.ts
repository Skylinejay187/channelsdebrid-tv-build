import express from "express"
import { homeRouter } from "./routes/home.js"
import { adminRowsRouter } from "./routes/admin-rows.js"
import { CatalogManager } from "./catalog/catalog-manager.js"
import { InternalCatalogSource } from "./catalog/sources/internal-catalog-source.js"
import { StremioCatalogSource } from "./catalog/sources/stremio-catalog-source.js"
import { createTmdbClient } from "./catalog/providers/tmdb-client.js"
import { createAddonRegistry } from "./stremio/addon-registry.js"
import { trailersRouter } from "./routes/trailers.js"
import { liveRouter } from "./routes/live.js"

export async function createApp() {
  const app = express()
  app.disable("x-powered-by")
  app.use((_req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*")
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization")
    res.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS")
    next()
  })
  app.use(express.json({ limit: "25mb" }))

  const tmdb = createTmdbClient(process.env.TMDB_API_KEY ?? "")
  const addonRegistry = createAddonRegistry()

  const catalogManager = new CatalogManager([
    new InternalCatalogSource(tmdb),
    new StremioCatalogSource(addonRegistry),
  ])

  app.use(homeRouter(catalogManager))
  app.use(adminRowsRouter())
  app.use(liveRouter())
  app.use("/api", liveRouter())
  app.use(trailersRouter())

  app.get("/health", (_req, res) => {
    res.json({ ok: true, service: "channels-debrid-foundation" })
  })

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, service: "channels-debrid-foundation" })
  })

  return app
}
