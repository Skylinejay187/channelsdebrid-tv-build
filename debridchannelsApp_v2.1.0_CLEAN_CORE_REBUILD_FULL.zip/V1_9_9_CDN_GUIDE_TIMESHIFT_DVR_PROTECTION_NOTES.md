# v1.9.9 CDN + External Guide Cache + Timeshift + DVR Preview Protection

Added backend `/live` + `/api/live` endpoints for CDN config, external guide cache, timeshift session folders, and DVR preview protection.
