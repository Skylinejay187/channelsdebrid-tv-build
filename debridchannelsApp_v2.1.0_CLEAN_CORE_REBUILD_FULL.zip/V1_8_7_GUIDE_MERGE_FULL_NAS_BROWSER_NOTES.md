# Debrid Channels v1.8.7 Guide Merge + Full NAS Browser Patch

Included in this full project zip:

- Universal guide merge path for HDHomeRun rows:
  - HDHomeRun playback remains direct.
  - HDHomeRun guide first tries SiliconDust XMLTV.
  - If HDHomeRun XMLTV has no data, guide rows fall back to the local Channels DVR XMLTV cache by channel number, tvg-id, normalized name/callsign and common number variants.
- Improved guide lookup keys:
  - Matches 7.1, 7-1, 7_1, 7, callsign/name variants, normalized HD/FHD/UHD/4K suffixes.
- Improved HDHomeRun icon detection:
  - Added ImageURL, GuideImageURL, LogoURL, IconURL, StationLogo and Logo field detection.
- Full NAS browser improvements:
  - SMB username supports user, DOMAIN\\user, or user@domain formats.
  - Login lists root shares first, then lets the user drill into shares/folders.
  - Folder selection validates write permission before saving.
- Timeshift storage validation retained:
  - Internal, USB, and NAS targets validate writable storage before use.

Nothing was removed from v1.8.6. This is a full drop-in project zip for GitHub workflow builds.
