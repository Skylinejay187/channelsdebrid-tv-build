# Debrid Channels v1.8.8 Live Guide Icons + Timeshift Patch

## Fixed
- Delays first-open guide refresh so the Live TV screen renders before EPG parsing starts.
- Reduces first-pass EPG scan size to prevent first-open crashes on Android TV devices.
- Keeps guide refresh on the background executor and safely merges partial guide results.
- Adds HDHomeRun XMLTV channel icon lookup using DeviceAuth when available.
- Preserves HDHomeRun channels even when icon lookup fails.
- Adds Media3 cache-backed app timeshift for live playback.
- Enables pause/rewind/fast-forward controls to use the app buffer instead of only native stream seeking.
- Adds NAS selected-folder mirroring for timeshift session buffer files.
- Keeps NAS validation and folder browser behavior intact.

## Notes
NAS timeshift uses a local Android cache as the active playback buffer and mirrors recent buffer chunks/session manifest into the selected SMB folder. This avoids unstable direct SMB playback while still writing timeshift session data to the NAS.
