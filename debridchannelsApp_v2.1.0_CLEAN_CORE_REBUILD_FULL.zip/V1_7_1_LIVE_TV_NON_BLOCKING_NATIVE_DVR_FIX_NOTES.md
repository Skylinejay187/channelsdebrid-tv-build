# v1.7.1 Live TV Non-Blocking Native DVR Fix

- Fixed Live TV getting stuck on loading after Channels DVR native timeshift work.
- Channels DVR native seek/timeshift detection no longer blocks guide/channel startup.
- Reduced Channels DVR probe timeouts and limited automatic endpoint probing.
- Removed automatic HDHomeRun full /24 scan during normal Live TV startup; this prevented multi-minute loading stalls on Android TV.
- Cached guide/channel data still renders first when available.
- Player now starts normal live playback first and upgrades the timeshift label to Channels DVR Native only when ExoPlayer exposes a seekable timeline.
