# v1.6.5 Persistent Live TV EPG Cache Fix

## Fixed
- Live TV EPG cache is now persistent on disk, not only held in screen/ViewModel memory.
- Re-entering Live TV within 12 hours restores saved program blocks immediately.
- Network guide refresh is skipped while the saved EPG cache is still fresh.
- The manual Refresh Guide button clears both the parsed EPG cache and Channels DVR XMLTV cache.

## Applies To
- Channels DVR Direct
- HDHomeRun native channels with parsed guide blocks where available
- M3U / XMLTV-style channel entries resolved by the app
- Xtream/IPTV short EPG lookups

## Behavior
1. Open Live TV first time: channels load and guide resolves in background.
2. Parsed EPG blocks are saved under app SharedPreferences with a 12-hour timestamp.
3. Leave Live TV and return within 12 hours: guide shows instantly from saved disk cache.
4. After 12 hours: old channel cache shows first, then guide refresh runs in the background.
