# v2.0.4 Player Instance Cleanup / Input Channel Fix

This build targets the logcat issues seen on Xgimi Galileo:

- `SQLiteConnectionPool ... exoplayer_internal.db was leaked`
- `PlayerActivity has no registered input channel`
- repeated LiveTvActivity `Cancelling event due to no window focus`

Changes:

1. Disabled live CacheDataSource/SimpleCache playback path for now.
   - Live playback now uses the stable direct HTTP data source again.
   - Timeshift metadata/session still starts, but the ExoPlayer SQLite cache is not used for live playback until backend buffer endpoints are paired.

2. PlayerActivity now fully releases ExoPlayer resources on stop.
   - Clears PlayerView player reference.
   - Clears media items.
   - Releases ExoPlayer.
   - Releases any SimpleCache instance.
   - Closes the timeshift session.
   - Cancels overlay/progress handlers.

3. LiveTvActivity no longer re-enables input with a delayed timer while PlayerActivity owns the window.
   - Live TV input restores only when LiveTvActivity actually resumes / regains window focus.
   - Added post-resume focus recovery passes.

Expected result:
- First channel opens in full player.
- Back returns to guide cleanly.
- Second channel OK press opens PlayerActivity again.
- Home/Smart Home navigation should not be trapped by stale Live TV input state.
- ExoPlayer SQLite leak should be gone or greatly reduced.
