# v1.5.1 trailer + VOD controls correction

- Removed the trailer popup path from using YouTube WebView iframe search.
- Trailer popup now calls backend `/trailers/resolve` and plays the returned direct stream in Media3/ExoPlayer.
- Background/details trailer autoplay now also schedules through the backend resolver.
- VOD control buttons are wired to real actions:
  - Subtitles: opens selectable subtitle/off dialog using Media3 track parameters.
  - Audio: opens selectable audio language dialog using Media3 track parameters.
  - Episodes: opens TV episode picker flow.
  - Zoom: cycles Fit / Fill / Zoom resize modes.
  - Settings: opens playback speed / repeat / restart panel.
