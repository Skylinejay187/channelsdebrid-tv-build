# v2.0.1 Real Timeshift Buffer Patch

This build changes Live TV timeshift from metadata-only to an active Media3 local cache/back-buffer path.

Fixes:
- Starts a real per-channel timeshift cache session when Live TV playback begins.
- Uses CacheDataSource + SimpleCache for live streams instead of direct HTTP-only playback.
- Rewind now attempts Media3 seek even when the provider reports a non-seekable live timeline, because many live HLS streams keep a local back-buffer but do not expose seekable=true.
- Replaces the old static "Rewind buffer not ready for this channel" message with a buffer-building countdown.
- Keeps NAS/USB as mirror/target storage while local cache remains the safe playback buffer.

Notes:
- Timeshift still depends on the stream type. HLS/DASH/live streams that Media3 can retain in back-buffer will rewind first.
- If a stream truly forbids any seek window, the app fails safely and keeps live playback running.
