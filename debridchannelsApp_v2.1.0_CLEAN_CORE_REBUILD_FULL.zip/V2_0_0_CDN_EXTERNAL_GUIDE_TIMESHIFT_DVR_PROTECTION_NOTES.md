# Debrid Channels v2.0.0 CDN / External Guide Cache / Timeshift / DVR Protection

This full zip advances the v1.9.9 foundation with deeper wiring:

- Backend now exposes CDN-safe guide cache status and channel program lookup endpoints.
- Backend supports app-uploaded guide cache JSON at `/live/epg/:userId/guide.json`.
- Backend returns cache freshness, public CDN URL, guide cache path, and timeshift root from `/live/cache/status`.
- Live TV guide resolver now uses the saved backend base URL and user ID instead of the old empty/demo-only backend settings.
- Timeshift storage manager now supports external guide cache directory resolution and prunes expired rolling buffer sessions.
- Player timeshift sessions now register with the backend when a backend URL is configured.
- Backend imports were normalized for NodeNext builds so the backend can compile into `dist` cleanly.
- CORS and larger JSON payload support added for CDN/backend guide sync flows.

Upload this full zip to the same GitHub workflow pipeline.
