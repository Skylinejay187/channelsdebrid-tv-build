# v1.9.6 Live TV Hard Focus Build

This build replaces Android TV auto-focus guessing in Live TV with an explicit DPAD zone router:

- Zone A: top menu navigation (Resume Watching, Smart Home, Live TV, Movies, TV Shows)
- Zone B: Live TV category rail
- Zone C: Live TV guide rows

Remote behavior:

- Live TV entry starts inside the Live TV controls, not on Resume Watching.
- From the top guide row, pressing UP moves to the top menu.
- From the top menu, LEFT/RIGHT switches menu items.
- From the top menu, DOWN returns to the Live TV guide/category zone.
- OK only activates the currently selected zone/item.
- OK no longer opens Continue Watching unless the top menu is intentionally focused on Resume Watching.
- BACK from guide collapses to categories; BACK from categories returns to the main hero/home shell.
- Preview/player/ScrollView/Button focus traps are bypassed by dispatchKeyEvent before Android auto-focus can steal the remote.
