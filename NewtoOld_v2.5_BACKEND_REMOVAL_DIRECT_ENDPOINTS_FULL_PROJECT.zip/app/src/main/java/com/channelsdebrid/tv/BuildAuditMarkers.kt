package com.channelsdebrid.tv

object BuildAuditMarkers {
    const val BUILD = "DC_BUILD_MARKER: NewtoOld_v2.5_BACKEND_REMOVAL_DIRECT_ENDPOINTS"
    const val BACKEND = "BACKEND_MODE: REMOVED"
    const val IPTV = "IPTV_DIRECT: ACTIVE"
    const val XMLTV = "XMLTV_DIRECT: ACTIVE"
    const val XTREAM = "XTREAM_DIRECT: ACTIVE"
    const val CHANNELS = "CHANNELS_DVR_MANUAL_ONLY: ACTIVE"
    const val HDHR = "HDHOMERUN_AUTO_SCAN: DISABLED"
    const val DEBRID = "DEBRID_STATUS: NOT_PRESENT"
}
