package com.channelsdebrid.tv.data

import android.content.Context
import com.channelsdebrid.tv.settings.SettingsRepository
import com.channelsdebrid.tv.settings.StremioAddonSettings
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

class UnifiedCatalogRepository(private val context: Context) {
    data class MediaItem(
        val title: String,
        val type: String,
        val meta: String,
        val overview: String,
        val externalId: String,
        val posterUrl: String = "",
        val backdropUrl: String = "",
        val logoUrl: String = "",
        val progress: Float = 0f,
        val streamUrl: String = ""
    )

    private val prefs = context.getSharedPreferences("continue_watching", Context.MODE_PRIVATE)
    private val settingsRepository = SettingsRepository(context)
    private val backendBaseUrl = "" // BACKEND_MODE: REMOVED

    fun section(section: String): List<MediaItem> {
        val normalized = when (section.lowercase(Locale.US)) {
            "shows", "tv", "series" -> "shows"
            else -> "movies"
        }
        val path = "" // BACKEND_MODE: REMOVED
        val backendItems = emptyList<MediaItem>()
        val tmdbItems = tmdbSection(normalized)
        val stremioItems = stremioSection(normalized)
        return (backendItems + tmdbItems + stremioItems + fallback(normalized))
            .dedupeMedia()
            .filter { if (normalized == "shows") it.type.equals("series", true) || it.type.equals("tv", true) else it.type.equals("movie", true) }
            .take(160)
    }

    fun search(query: String): List<MediaItem> {
        val q = query.trim()
        if (q.isBlank()) return (fallback("search") + liveChannelResults("") + liveProgramResults("")).dedupeMedia().take(80)
        val encoded = URLEncoder.encode(q, "UTF-8")
        val backend = emptyList<MediaItem>()
        val tmdb = tmdbSearch(q)
        val stremio = stremioSearch(q)
        val live = liveChannelResults(q)
        val guide = liveProgramResults(q)
        return (backend + tmdb + stremio + live + guide)
            .dedupeMedia()
            .ifEmpty { fallback("search").filter { it.title.contains(q, true) || it.type.contains(q, true) } }
            .take(140)
    }

    fun continueWatching(): List<MediaItem> {
        val arr = JSONArray(prefs.getString("items", "[]") ?: "[]")
        val out = mutableListOf<MediaItem>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val progress = obj.optDouble("progress", 0.0).toFloat().coerceIn(0f, 1f)
            if (progress <= 0.02f || progress >= 0.92f) continue
            out += MediaItem(
                title = obj.optString("title").ifBlank { "Continue Watching" },
                type = obj.optString("type").ifBlank { "movie" },
                meta = obj.optString("meta").ifBlank { "${(progress * 100).toInt()}% watched" },
                overview = obj.optString("overview").ifBlank { "Resume from where you left off." },
                externalId = obj.optString("externalId").ifBlank { obj.optString("streamUrl") },
                posterUrl = obj.optString("posterUrl"),
                backdropUrl = obj.optString("backdropUrl"),
                logoUrl = obj.optString("logoUrl"),
                progress = progress,
                streamUrl = obj.optString("streamUrl")
            )
        }
        return out.sortedByDescending { it.progress }.ifEmpty { fallback("resume") }
    }

    private fun tmdbSection(section: String): List<MediaItem> {
        val tmdb = settingsRepository.loadTmdb()
        if (tmdb.apiKey.isBlank()) return emptyList()
        val endpoints = if (section == "shows") listOf("/trending/tv/week", "/tv/popular", "/tv/top_rated") else listOf("/trending/movie/week", "/movie/popular", "/movie/top_rated")
        return endpoints.flatMap { endpoint -> tmdbFetchResults(endpoint, section, tmdb.apiKey, tmdb.language, tmdb.region) }.dedupeMedia()
    }

    private fun tmdbSearch(query: String): List<MediaItem> {
        val tmdb = settingsRepository.loadTmdb()
        if (tmdb.apiKey.isBlank() || query.isBlank()) return emptyList()
        val encoded = URLEncoder.encode(query, "UTF-8")
        return tmdbFetchResults("/search/multi?query=$encoded&include_adult=false", "multi", tmdb.apiKey, tmdb.language, tmdb.region)
    }

    private fun tmdbFetchResults(endpoint: String, forcedSection: String, apiKey: String, language: String, region: String): List<MediaItem> {
        val sep = if (endpoint.contains("?")) "&" else "?"
        val url = "https://api.themoviedb.org/3$endpoint${sep}api_key=${URLEncoder.encode(apiKey, "UTF-8")}&language=${URLEncoder.encode(language.ifBlank { "en-US" }, "UTF-8")}&region=${URLEncoder.encode(region.ifBlank { "US" }, "UTF-8")}".replace("+", "%20")
        val root = fetchJson(url) ?: return emptyList()
        val arr = root.optJSONArray("results") ?: return emptyList()
        val out = mutableListOf<MediaItem>()
        for (i in 0 until minOf(arr.length(), 36)) {
            val obj = arr.optJSONObject(i) ?: continue
            val mediaType = obj.optString("media_type").ifBlank { if (forcedSection == "shows") "tv" else if (forcedSection == "movies") "movie" else "" }
            if (mediaType !in listOf("movie", "tv")) continue
            val title = if (mediaType == "tv") obj.optString("name") else obj.optString("title")
            if (title.isBlank()) continue
            val tmdbId = obj.optInt("id", 0)
            val stremioType = if (mediaType == "tv") "series" else "movie"
            val yearSource = if (mediaType == "tv") obj.optString("first_air_date") else obj.optString("release_date")
            val year = yearSource.takeIf { it.length >= 4 }?.substring(0, 4).orEmpty()
            val imdb = resolveTmdbExternalId(apiKey, mediaType, tmdbId, language)
            val externalId = imdb.ifBlank { "tmdb:$tmdbId" }
            val poster = obj.optString("poster_path").takeIf { it.isNotBlank() }?.let { "https://image.tmdb.org/t/p/original$it" }.orEmpty()
            val backdrop = obj.optString("backdrop_path").takeIf { it.isNotBlank() }?.let { "https://image.tmdb.org/t/p/original$it" }.orEmpty()
            out += MediaItem(
                title = title,
                type = stremioType,
                meta = listOf("TMDB", year, obj.optDouble("vote_average", 0.0).takeIf { it > 0.0 }?.let { "★ ${String.format(Locale.US, "%.1f", it)}" }).filterNotNull().filter { it.isNotBlank() }.joinToString(" • "),
                overview = obj.optString("overview"),
                externalId = externalId,
                posterUrl = poster,
                backdropUrl = backdrop.ifBlank { poster }
            )
        }
        return out
    }

    private fun resolveTmdbExternalId(apiKey: String, mediaType: String, tmdbId: Int, language: String): String {
        if (tmdbId <= 0) return ""
        val endpointType = if (mediaType == "tv") "tv" else "movie"
        val url = "https://api.themoviedb.org/3/$endpointType/$tmdbId/external_ids?api_key=${URLEncoder.encode(apiKey, "UTF-8")}&language=${URLEncoder.encode(language.ifBlank { "en-US" }, "UTF-8")}".replace("+", "%20")
        val obj = fetchJson(url) ?: return ""
        return obj.optString("imdb_id").takeIf { it.startsWith("tt") }.orEmpty()
    }

    private fun stremioSection(section: String): List<MediaItem> {
        val type = if (section == "shows") "series" else "movie"
        return settingsRepository.loadStremioAddons()
            .filter { it.enabled && it.manifestUrl.isNotBlank() }
            .flatMap { addon -> stremioCatalogItems(addon, type, "top", "") + stremioCatalogItems(addon, type, "popular", "") }
            .dedupeMedia()
            .take(120)
    }

    private fun stremioSearch(query: String): List<MediaItem> {
        if (query.isBlank()) return emptyList()
        return settingsRepository.loadStremioAddons()
            .filter { it.enabled && it.manifestUrl.isNotBlank() }
            .flatMap { addon ->
                stremioCatalogItems(addon, "movie", "top", query) +
                    stremioCatalogItems(addon, "movie", "popular", query) +
                    stremioCatalogItems(addon, "series", "top", query) +
                    stremioCatalogItems(addon, "series", "popular", query)
            }
            .dedupeMedia()
            .take(80)
    }

    private fun stremioCatalogItems(addon: StremioAddonSettings, type: String, catalogId: String, query: String): List<MediaItem> {
        val base = addon.manifestUrl.removeSuffix("/manifest.json").trimEnd('/')
        val searchPart = if (query.isNotBlank()) "/search=${URLEncoder.encode(query, "UTF-8").replace("+", "%20")}" else ""
        val url = "$base/catalog/$type/$catalogId$searchPart.json"
        val root = fetchJson(url) ?: return emptyList()
        val arr = root.optJSONArray("metas") ?: root.optJSONArray("items") ?: return emptyList()
        val out = mutableListOf<MediaItem>()
        for (i in 0 until minOf(arr.length(), 30)) {
            val obj = arr.optJSONObject(i) ?: continue
            val title = obj.optString("name").ifBlank { obj.optString("title") }
            if (title.isBlank()) continue
            val id = obj.optString("imdb_id").ifBlank { obj.optString("imdbId") }.ifBlank { obj.optString("id") }
            out += MediaItem(
                title = title,
                type = if (type == "series") "series" else "movie",
                meta = listOf(addon.name.ifBlank { "Stremio" }, obj.optString("releaseInfo").ifBlank { obj.optString("year") }).filter { it.isNotBlank() }.joinToString(" • "),
                overview = obj.optString("description"),
                externalId = id,
                posterUrl = obj.optString("poster"),
                backdropUrl = obj.optString("background").ifBlank { obj.optString("poster") },
                logoUrl = obj.optString("logo")
            )
        }
        return out
    }

    private fun liveChannelResults(query: String): List<MediaItem> {
        val raw = context.getSharedPreferences("live_tv_cache", Context.MODE_PRIVATE).getString("channels_json", "[]").orEmpty()
        val arr = JSONArray(raw.ifBlank { "[]" })
        val out = mutableListOf<MediaItem>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val name = obj.optString("name")
            val groups = groupsLabel(obj)
            if (query.isNotBlank() && !name.contains(query, true) && !groups.contains(query, true) && !obj.optString("source").contains(query, true)) continue
            out += MediaItem(
                title = name,
                type = "live",
                meta = listOf(obj.optString("source").ifBlank { "Live TV Channel" }, groups).filter { it.isNotBlank() }.joinToString(" • "),
                overview = "Live TV channel from your synced lineup.",
                externalId = "live:${obj.optString("url")}",
                posterUrl = obj.optString("iconUrl"),
                logoUrl = obj.optString("iconUrl"),
                streamUrl = obj.optString("url")
            )
        }
        return out.take(80)
    }

    private fun liveProgramResults(query: String): List<MediaItem> {
        val rawChannels = context.getSharedPreferences("live_tv_cache", Context.MODE_PRIVATE).getString("channels_json", "[]").orEmpty()
        val rawEpg = context.getSharedPreferences("live_tv_epg_cache", Context.MODE_PRIVATE).getString("epg_programs_json", "").orEmpty()
        if (rawEpg.isBlank()) return emptyList()
        val channelByUrl = linkedMapOf<String, JSONObject>()
        runCatching {
            val channels = JSONArray(rawChannels.ifBlank { "[]" })
            for (i in 0 until channels.length()) {
                val obj = channels.optJSONObject(i) ?: continue
                val url = obj.optString("url")
                if (url.isNotBlank()) channelByUrl[url] = obj
            }
        }
        val root = JSONObject(rawEpg)
        val out = mutableListOf<MediaItem>()
        val keys = root.keys()
        while (keys.hasNext()) {
            val streamUrl = keys.next()
            val channel = channelByUrl[streamUrl]
            val channelName = channel?.optString("name").orEmpty()
            val icon = channel?.optString("iconUrl").orEmpty()
            val source = channel?.optString("source").orEmpty()
            val programs = root.optJSONArray(streamUrl) ?: continue
            for (i in 0 until programs.length()) {
                val p = programs.optJSONObject(i) ?: continue
                val title = p.optString("title")
                val desc = p.optString("description")
                if (title.isBlank() || title.equals("No information", true)) continue
                val haystack = "$title $desc $channelName $source"
                if (query.isNotBlank() && !haystack.contains(query, true)) continue
                out += MediaItem(
                    title = title,
                    type = "live",
                    meta = listOf("Live Program", channelName, p.optString("startLabel"), p.optString("endLabel")).filter { it.isNotBlank() }.joinToString(" • "),
                    overview = desc.ifBlank { "Airing on $channelName" },
                    externalId = "live-program:$streamUrl:$i",
                    posterUrl = p.optString("imageUrl").ifBlank { icon },
                    backdropUrl = p.optString("imageUrl"),
                    logoUrl = icon,
                    streamUrl = streamUrl
                )
            }
        }
        return out.take(80)
    }

    private fun groupsLabel(obj: JSONObject): String {
        val arr = obj.optJSONArray("groups") ?: return ""
        val values = mutableListOf<String>()
        for (i in 0 until arr.length()) arr.optString(i).takeIf { it.isNotBlank() }?.let(values::add)
        return values.take(3).joinToString(", ")
    }

    private fun fetchItems(url: String): List<MediaItem> = try { parseItems(fetchText(url)) } catch (_: Exception) { emptyList() }

    private fun fetchText(url: String): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 4500
            readTimeout = 6500
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "DebridChannelsTV/1.6.6")
        }
        return try {
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        } finally { conn.disconnect() }
    }

    private fun fetchJson(url: String): JSONObject? = runCatching { JSONObject(fetchText(url)) }.getOrNull()

    private fun parseItems(body: String): List<MediaItem> {
        if (body.isBlank()) return emptyList()
        val trimmed = body.trim()
        val arr = if (trimmed.startsWith("[")) JSONArray(trimmed) else {
            val root = JSONObject(trimmed)
            root.optJSONArray("items") ?: root.optJSONArray("results") ?: root.optJSONArray("metas") ?: root.optJSONArray("catalog") ?: JSONArray()
        }
        val out = mutableListOf<MediaItem>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val type = obj.optString("type").ifBlank { obj.optString("mediaType") }.ifBlank { if (obj.optString("kind") == "tv") "series" else "movie" }
            out += MediaItem(
                title = obj.optString("title").ifBlank { obj.optString("name") },
                type = if (type.equals("tv", true) || type.equals("show", true)) "series" else type,
                meta = obj.optString("meta").ifBlank { obj.optString("year") }.ifBlank { type.replaceFirstChar { it.uppercase() } },
                overview = obj.optString("overview").ifBlank { obj.optString("description") },
                externalId = obj.optString("externalId").ifBlank { obj.optString("imdbId") }.ifBlank { obj.optString("imdb_id") }.ifBlank { obj.optString("id") },
                posterUrl = obj.optString("poster").ifBlank { obj.optString("posterUrl") },
                backdropUrl = obj.optString("background").ifBlank { obj.optString("backdrop").ifBlank { obj.optString("backdropUrl") } },
                logoUrl = obj.optString("logo").ifBlank { obj.optString("logoUrl") },
                progress = obj.optDouble("progress", 0.0).toFloat()
            )
        }
        return out.filter { it.title.isNotBlank() }
    }

    private fun List<MediaItem>.dedupeMedia(): List<MediaItem> {
        val seen = linkedSetOf<String>()
        val out = mutableListOf<MediaItem>()
        for (item in this) {
            val idPart = item.externalId.ifBlank { item.streamUrl }.ifBlank { item.title.lowercase(Locale.US) }
            val key = "${item.type.lowercase(Locale.US)}|$idPart|${item.title.lowercase(Locale.US)}"
            if (seen.add(key)) out += item
        }
        return out
    }

    private fun fallback(section: String): List<MediaItem> {
        val shows = listOf("Shōgun", "Fallout", "Halo", "Mayor of Kingstown", "The Last of Us", "Silo")
        val movies = listOf("Dune: Part Two", "The Batman", "Civil War", "Avatar", "Wonka", "The Martian")
        val titles = when (section.lowercase(Locale.US)) {
            "shows", "tv", "series" -> shows
            "resume" -> listOf("No saved progress yet")
            else -> movies
        }
        return titles.mapIndexed { index, title ->
            MediaItem(
                title = title,
                type = if (section.lowercase(Locale.US) in listOf("shows", "tv", "series")) "series" else "movie",
                meta = if (section == "resume") "Continue Watching" else if (index % 2 == 0) "Popular" else "Trending",
                overview = if (section == "resume") "Paused movies and shows will appear here after playback progress is saved." else "Catalog item from your backend/addon row fallback.",
                externalId = "fallback:$section:$index",
                progress = if (section == "resume") 0f else 0.0f
            )
        }
    }
}
