package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.0.3 LINK SELECTION PLAYER FIX";
    public static final String LOG_MARKER = "DC_V0_0_3_ACTIVE";
    private BuildMarkers() {}
}
