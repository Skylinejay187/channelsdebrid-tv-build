# v0.0.3 Rewrite Build Audit

Base used: v0.0.2 cinematic player line rebuilt from the stable v0.0.1 visual/card baseline.

Rule: no broken v7.x source carried forward.

Fixes:
- Selecting Play now opens Stream Link Selection first.
- VOD overlay/player does not appear until a stream link is selected.
- Stremio addon JSON stream endpoint loading added for stream-capable addon manifests.
- Catalog-only addons such as Cinemeta will not fake playable stream links.
- Preserved card logos, row navigation, hero artwork, ratings, Pro Layout Editor, backend default URL.

Markers:
- versionName: 0.0.3
- versionCode: 3
- logcat: DC_V0_0_3_ACTIVE
- visible marker: DC_V0_0_3_LINK_SELECTION_PLAYER_FIX
