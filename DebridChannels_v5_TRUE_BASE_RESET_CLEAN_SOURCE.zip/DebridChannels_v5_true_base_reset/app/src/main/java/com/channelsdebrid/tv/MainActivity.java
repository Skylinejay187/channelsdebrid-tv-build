package com.channelsdebrid.tv;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.*;
import android.text.InputType;
import java.util.*;

import com.channelsdebrid.tv.core.*;
import com.channelsdebrid.tv.player.*;
import com.channelsdebrid.tv.livetv.*;
import com.channelsdebrid.tv.cache.*;
import com.channelsdebrid.tv.layout.*;
import com.channelsdebrid.tv.backend.*;
import com.channelsdebrid.tv.stremio.*;

public class MainActivity extends Activity {
    private FrameLayout root;
    private NavigationController nav;
    private PlayerManager player;
    private LiveTvStateMachine live;
    private GuideCacheOwner guideCache;
    private TimeshiftEngine timeshift;
    private UiStateStore ui;
    private BackendConfig backend;
    private StremioAddonRegistry stremio;
    private LinearLayout heroMenu;
    private LinearLayout body;
    private final List<TextView> menuItems = new ArrayList<>();

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        nav = new NavigationController(); player = new PlayerManager(this); live = new LiveTvStateMachine();
        guideCache = new GuideCacheOwner(this); timeshift = new TimeshiftEngine(this); ui = new UiStateStore(this);
        backend = new BackendConfig(this); stremio = new StremioAddonRegistry(this);
        AppLogger.mark("BOOT " + BuildMarkers.VERSION + " / clean architecture loaded");
        root = new FrameLayout(this); root.setBackgroundColor(Color.rgb(4,6,12)); setContentView(root);
        showHome();
    }

    private void clear(){ root.removeAllViews(); menuItems.clear(); }
    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density + 0.5f); }
    private TextView tv(String text,int sp,int style){ TextView t=new TextView(this); t.setText(text); t.setTextColor(Color.WHITE); t.setTextSize(sp); t.setTypeface(Typeface.DEFAULT,style); t.setGravity(Gravity.CENTER); return t; }
    private GradientDrawable bg(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp((int)radius)); return g; }
    private GradientDrawable strokeBg(int color,int stroke){ GradientDrawable g=bg(color,24); g.setStroke(dp(2),stroke); return g; }
    private TextView focusButton(String label){
        TextView v=tv(label,16,Typeface.BOLD); v.setFocusable(true); v.setPadding(dp(24),dp(10),dp(24),dp(10));
        v.setBackground(bg(Color.argb(90,255,255,255),28));
        v.setOnFocusChangeListener((x,has)->{ x.animate().scaleX(has?1.08f:1f).scaleY(has?1.08f:1f).setDuration(120).start(); x.setBackground(has?bg(Color.argb(210,255,255,255),28):bg(Color.argb(90,255,255,255),28)); ((TextView)x).setTextColor(has?Color.BLACK:Color.WHITE); });
        return v;
    }

    private void addHeroMenu(FrameLayout parent){
        heroMenu = new LinearLayout(this); heroMenu.setOrientation(LinearLayout.HORIZONTAL); heroMenu.setGravity(Gravity.CENTER); heroMenu.setPadding(dp(12),dp(8),dp(12),dp(8)); heroMenu.setBackground(bg(Color.argb(120,20,25,35),34));
        String[] labels = {"⌕", "Home", "Movies", "Shows", "Live TV", "Resume", "Layout", "⚙"};
        for(String s: labels){ TextView m=focusButton(s); LinearLayout.LayoutParams mlp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(48)); mlp.setMargins(dp(4),0,dp(4),0); heroMenu.addView(m,mlp); menuItems.add(m);
            if(s.equals("Live TV")) m.setOnClickListener(v->showLiveTv());
            else if(s.equals("Layout")) m.setOnClickListener(v->showLayoutEditor());
            else if(s.equals("⚙")) m.setOnClickListener(v->showSettings());
            else if(s.equals("⌕")) m.setOnClickListener(v->showSearch());
            else m.setOnClickListener(v->showHome());
        }
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(880),dp(72)); lp.topMargin=dp(24);
        String pos=ui.menuPosition(); lp.gravity=Gravity.TOP | (pos.equals("left")?Gravity.LEFT:pos.equals("right")?Gravity.RIGHT:Gravity.CENTER_HORIZONTAL);
        lp.leftMargin=dp(40); lp.rightMargin=dp(40); parent.addView(heroMenu,lp);
    }

    private void showHome(){ clear(); nav.go(NavigationController.Screen.HOME); addHeroBackdrop(); addHeroMenu(root);
        TextView logo=tv("DEBRID\nCHANNELS",54,Typeface.BOLD); logo.setGravity(Gravity.LEFT); FrameLayout.LayoutParams llp=new FrameLayout.LayoutParams(dp(520),dp(160)); llp.leftMargin=dp(ui.heroLogoX()); llp.topMargin=dp(ui.heroLogoY()); root.addView(logo,llp);
        TextView meta=tv("v5 TRUE BASE RESET • backend compatible • Stremio JSON ready",18,Typeface.NORMAL); meta.setGravity(Gravity.LEFT); FrameLayout.LayoutParams mlp=new FrameLayout.LayoutParams(dp(720),dp(40)); mlp.leftMargin=dp(82); mlp.topMargin=dp(335); root.addView(meta,mlp);
        addRows("Continue Watching", "Featured Movies", "Live TV Preview");
        menuItems.get(1).requestFocus();
    }
    private void addHeroBackdrop(){ View grad=new View(this); GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.rgb(4,6,12),Color.rgb(16,26,48),Color.rgb(4,6,12)}); grad.setBackground(g); root.addView(grad,new FrameLayout.LayoutParams(-1,-1)); }
    private void addRows(String... titles){ LinearLayout rows=new LinearLayout(this); rows.setOrientation(LinearLayout.VERTICAL); FrameLayout.LayoutParams rlp=new FrameLayout.LayoutParams(-1,dp(390)); rlp.leftMargin=dp(70); rlp.rightMargin=dp(40); rlp.topMargin=dp(430); root.addView(rows,rlp);
        for(String title:titles){ if(ui.rowTitles()){ TextView h=tv(title,22,Typeface.BOLD); h.setGravity(Gravity.LEFT); rows.addView(h,new LinearLayout.LayoutParams(-1,dp(34))); }
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); rows.addView(row,new LinearLayout.LayoutParams(-1,dp(110)));
            for(int i=0;i<8;i++){ TextView card=focusButton(title.split(" ")[0]+" "+(i+1)); card.setBackground(strokeBg(Color.argb(105,30,35,48),Color.argb(80,255,255,255))); LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(dp(165),dp(92)); clp.setMargins(0,0,dp(14),0); row.addView(card,clp); }
        }}

    private void showLiveTv(){ clear(); nav.go(NavigationController.Screen.LIVE_TV); addHeroBackdrop(); addHeroMenu(root);
        TextView title=tv("Live TV",32,Typeface.BOLD); title.setGravity(Gravity.LEFT); FrameLayout.LayoutParams tlp=new FrameLayout.LayoutParams(dp(300),dp(60)); tlp.leftMargin=dp(56); tlp.topMargin=dp(112); root.addView(title,tlp);
        LinearLayout cats=new LinearLayout(this); cats.setOrientation(LinearLayout.VERTICAL); cats.setBackground(bg(Color.argb(120,0,0,0),18)); FrameLayout.LayoutParams clp=new FrameLayout.LayoutParams(dp(260),dp(500)); clp.leftMargin=dp(44); clp.topMargin=dp(180); root.addView(cats,clp);
        String[] c={"Favorites","HD Channels","Movies","News","Sports","Kids","Local"}; for(String s:c){ TextView b=focusButton(s); b.setGravity(Gravity.CENTER_VERTICAL); cats.addView(b,new LinearLayout.LayoutParams(-1,dp(58))); }
        LinearLayout guide=new LinearLayout(this); guide.setOrientation(LinearLayout.VERTICAL); guide.setBackground(bg(Color.argb(135,10,14,24),18)); FrameLayout.LayoutParams glp=new FrameLayout.LayoutParams(dp(850),dp(500)); glp.leftMargin=dp(330); glp.topMargin=dp(180); root.addView(guide,glp);
        TextView header=tv("NOW        1:30 PM        2:00 PM        2:30 PM        3:00 PM",18,Typeface.BOLD); guide.addView(header,new LinearLayout.LayoutParams(-1,dp(50)));
        for(int i=1;i<=7;i++){ TextView row=focusButton("  "+(100+i)+"  Channel "+i+"     Program playing now                    Up next                    Later"); row.setGravity(Gravity.CENTER_VERTICAL); guide.addView(row,new LinearLayout.LayoutParams(-1,dp(60))); }
        TextView preview=tv("LIVE PREVIEW\nPlayer surface owner: PlayerManager",20,Typeface.BOLD); preview.setBackground(strokeBg(Color.argb(150,0,0,0),Color.argb(110,255,255,255))); FrameLayout.LayoutParams plp=new FrameLayout.LayoutParams(dp(360),dp(170)); plp.gravity=Gravity.RIGHT|Gravity.TOP; plp.rightMargin=dp(70); plp.topMargin=dp(84); root.addView(preview,plp);
        cats.getChildAt(0).requestFocus();
    }

    private void showLayoutEditor(){ clear(); nav.go(NavigationController.Screen.LAYOUT_EDITOR); addHeroBackdrop(); addHeroMenu(root);
        TextView title=tv("Pro Layout Editor",36,Typeface.BOLD); title.setGravity(Gravity.LEFT); FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(620),dp(70)); lp.leftMargin=dp(70); lp.topMargin=dp(125); root.addView(title,lp);
        LinearLayout panel=new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(24),dp(20),dp(24),dp(20)); panel.setBackground(bg(Color.argb(135,10,14,24),24)); FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(620),dp(500)); pp.leftMargin=dp(70); pp.topMargin=dp(205); root.addView(panel,pp);
        String[] actions={"Menu Left","Menu Center","Menu Right","Toggle Row Titles","Move Artwork Left","Move Artwork Right","Move Artwork Up","Move Artwork Down","Resize Artwork +","Resize Artwork -"};
        for(String a: actions){ TextView btn=focusButton(a); btn.setGravity(Gravity.CENTER_VERTICAL); btn.setOnClickListener(v->applyLayoutAction(((TextView)v).getText().toString())); panel.addView(btn,new LinearLayout.LayoutParams(-1,dp(44))); }
        TextView art=tv("Layered Artwork System\nPoster • Banner • ClearLogo • Disc/DVD • Character 3D Pop\nSaved with UiStateStore",22,Typeface.BOLD); art.setBackground(strokeBg(Color.argb(100,0,0,0),Color.argb(90,255,255,255))); FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(dp(430),dp(260)); ap.leftMargin=dp(760); ap.topMargin=dp(260); root.addView(art,ap);
        panel.getChildAt(1).requestFocus();
    }
    private void applyLayoutAction(String a){ int x=ui.heroLogoX(), y=ui.heroLogoY(), s=ui.artworkSize(); if(a.contains("Left") && a.startsWith("Menu")) ui.saveMenuPosition("left"); else if(a.contains("Center")) ui.saveMenuPosition("center"); else if(a.contains("Right") && a.startsWith("Menu")) ui.saveMenuPosition("right"); else if(a.contains("Toggle")) ui.saveRowTitles(!ui.rowTitles()); else if(a.contains("Artwork Left")) x-=20; else if(a.contains("Artwork Right")) x+=20; else if(a.contains("Artwork Up")) y-=20; else if(a.contains("Artwork Down")) y+=20; else if(a.contains("+")) s+=20; else if(a.contains("-")) s=Math.max(80,s-20); ui.saveArtwork(x,y,s); showLayoutEditor(); }

    private void showSettings(){ clear(); nav.go(NavigationController.Screen.SETTINGS); addHeroBackdrop(); addHeroMenu(root); LinearLayout p=formPanel("Settings"); addInput(p,"Backend Base URL",backend.baseUrl(),v->backend.saveBaseUrl(v)); addInput(p,"Stremio addon JSON links",stremio.getJsonLinks(),v->stremio.saveJsonLinks(v)); p.getChildAt(1).requestFocus(); }
    private void showSearch(){ clear(); nav.go(NavigationController.Screen.SEARCH); addHeroBackdrop(); addHeroMenu(root); formPanel("Search"); }
    interface SaveFn{ void save(String v); }
    private LinearLayout formPanel(String heading){ TextView h=tv(heading,36,Typeface.BOLD); h.setGravity(Gravity.LEFT); FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(dp(700),dp(70)); hp.leftMargin=dp(70); hp.topMargin=dp(135); root.addView(h,hp); LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setPadding(dp(28),dp(28),dp(28),dp(28)); p.setBackground(bg(Color.argb(135,10,14,24),24)); FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(800),dp(420)); pp.leftMargin=dp(70); pp.topMargin=dp(220); root.addView(p,pp); return p; }
    private void addInput(LinearLayout p,String label,String value,SaveFn fn){ TextView l=tv(label,18,Typeface.BOLD); l.setGravity(Gravity.LEFT); p.addView(l,new LinearLayout.LayoutParams(-1,dp(34))); EditText e=new EditText(this); e.setText(value); e.setSingleLine(false); e.setTextColor(Color.WHITE); e.setHintTextColor(Color.GRAY); e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS); e.setBackground(strokeBg(Color.argb(80,255,255,255),Color.argb(100,255,255,255))); e.setPadding(dp(16),0,dp(16),0); e.setOnFocusChangeListener((v,has)->{ if(!has) fn.save(((EditText)v).getText().toString()); }); p.addView(e,new LinearLayout.LayoutParams(-1,dp(68))); }

    @Override public boolean dispatchKeyEvent(KeyEvent e){
        if(e.getAction()==KeyEvent.ACTION_DOWN && nav.current()==NavigationController.Screen.LIVE_TV){
            if(e.getKeyCode()==KeyEvent.KEYCODE_DPAD_UP){ live.up(); if(!menuItems.isEmpty()) menuItems.get(1).requestFocus(); return true; }
            if(e.getKeyCode()==KeyEvent.KEYCODE_DPAD_RIGHT){ live.right(); return false; }
            if(e.getKeyCode()==KeyEvent.KEYCODE_DPAD_LEFT){ live.left(); return false; }
        }
        return super.dispatchKeyEvent(e);
    }
    @Override protected void onDestroy(){ super.onDestroy(); player.release(); AppLogger.mark("MainActivity destroyed once"); }
}
