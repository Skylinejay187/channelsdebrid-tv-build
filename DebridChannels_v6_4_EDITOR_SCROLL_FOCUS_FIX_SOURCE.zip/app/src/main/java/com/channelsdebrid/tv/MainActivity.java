package com.channelsdebrid.tv;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import android.widget.*;
import android.text.InputType;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;

import com.channelsdebrid.tv.core.*;
import com.channelsdebrid.tv.player.*;
import com.channelsdebrid.tv.livetv.*;
import com.channelsdebrid.tv.cache.*;
import com.channelsdebrid.tv.layout.*;
import com.channelsdebrid.tv.backend.*;
import com.channelsdebrid.tv.stremio.*;

public class MainActivity extends Activity {
    FrameLayout root;
    NavigationController nav;
    PlayerManager player;
    LiveTvStateMachine live;
    GuideCacheOwner guideCache;
    TimeshiftEngine timeshift;
    UiStateStore ui;
    BackendConfig backend;
    StremioAddonRegistry stremio;
    LinearLayout heroMenu;
    final ArrayList<View> menuItems = new ArrayList<>();
    final ArrayList<HomeRow> homeRows = new ArrayList<>();
    final ArrayList<Movie> movies = new ArrayList<>();
    final ArrayList<Channel> channels = new ArrayList<>();
    ImageView heroBackdropImage, heroLogoImage, heroBannerImage;
    ScrollView editorScroll;
    TextView heroTitle, heroDesc, heroMeta;
    boolean suppressRowAutoFocus = false;
    final Handler heroHandler = new Handler(Looper.getMainLooper());
    Runnable pendingHeroRunnable;

    static class Movie {
        String id = "", type = "movie", title = "Untitled", meta = "", url = "";
        String poster = "", background = "", logo = "", banner = "", overview = "", year = "";
        Movie(String title, String meta, String url) { this.title = title; this.meta = meta; this.url = url; }
    }
    static class HomeRow { String id = "", title = "Catalog"; ArrayList<Movie> items = new ArrayList<>(); HomeRow(String title){this.title=title;} }
    static class Channel { String name, group, url, logo; Channel(String n,String g,String u,String l){name=n;group=g;url=u;logo=l;} }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        nav = new NavigationController();
        player = new PlayerManager(this);
        live = new LiveTvStateMachine();
        guideCache = new GuideCacheOwner(this);
        timeshift = new TimeshiftEngine(this);
        ui = new UiStateStore(this);
        backend = new BackendConfig(this);
        stremio = new StremioAddonRegistry(this);
        seedFallback();
        root = new FrameLayout(this);
        setContentView(root);
        AppLogger.mark("BOOT " + BuildMarkers.LOG_MARKER + " backend=" + backend.baseUrl());
        showHome();
        loadBackendHomeRows();
    }

    void seedFallback() {
        movies.clear(); homeRows.clear(); channels.clear();
        Movie a = new Movie("Project Hail Mary", "2026 • FEATURED • IMDB 8.2 • TMDB 7.0", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4");
        a.year="2026"; a.overview="Focus a card to update the cinematic background, logo/title layer, metadata, poster row and future banner/3D art slot."; movies.add(a);
        Movie b = new Movie("The Mummy", "1999 • 4K • Adventure • 7.1", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4");
        b.year="1999"; b.overview="Artwork comes from the backend first: poster, background, logo and banner fields. The app does not require a TMDB key."; movies.add(b);
        Movie c = new Movie("The Super Mario Galaxy Movie", "2026 • Family • 8.0", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4");
        c.year="2026"; c.overview="Each Stremio addon catalog can become a row. Settings will control hide, rename and reorder without changing the clean core."; movies.add(c);
        Movie d = new Movie("Avatar", "2009 • 4K • Sci-Fi", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4");
        d.year="2009"; d.overview="The right-side Banner area is preserved as the extra artwork layer for clearlogo, disc/DVD, character and future 3D pop art."; movies.add(d);
        HomeRow row = new HomeRow("Trending Movies"); row.items.addAll(movies); homeRows.add(row);
        channels.add(new Channel("Sample Live Channel", "Favorites", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4", ""));
        channels.add(new Channel("Movies 24/7", "Movies", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4", ""));
        channels.add(new Channel("Demo Sports", "Sports", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4", ""));
    }

    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);} 
    void clear(){root.removeAllViews();menuItems.clear();}
    GradientDrawable bg(int c,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    GradientDrawable stroke(int c,int s){GradientDrawable g=bg(c,26);g.setStroke(dp(1),s);return g;}
    TextView tv(String x,int sp,int style){TextView t=new TextView(this);t.setText(x);t.setTextColor(Color.WHITE);t.setTextSize(sp);t.setTypeface(Typeface.DEFAULT,style);t.setGravity(Gravity.CENTER);return t;}

    void backdrop(){
        heroBackdropImage = new ImageView(this);
        heroBackdropImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        heroBackdropImage.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(115,80,28),Color.rgb(23,28,42),Color.rgb(1,3,8)}));
        root.addView(heroBackdropImage,new FrameLayout.LayoutParams(-1,-1));
        View tone = new View(this); tone.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.argb(120,120,72,14),Color.argb(70,20,28,46),Color.argb(155,0,0,0)})); root.addView(tone,new FrameLayout.LayoutParams(-1,-1));
        View side = new View(this); side.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.argb(240,0,0,0),Color.argb(155,0,0,0),Color.argb(35,0,0,0)})); root.addView(side,new FrameLayout.LayoutParams(-1,-1));
        View bottom = new View(this); bottom.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,new int[]{Color.argb(245,0,0,0),Color.TRANSPARENT})); root.addView(bottom,new FrameLayout.LayoutParams(-1,dp(400),Gravity.BOTTOM));
    }

    TextView btn(String x){TextView v=tv(x,16,Typeface.BOLD);v.setFocusable(true);v.setPadding(dp(18),0,dp(18),0);v.setBackground(bg(Color.argb(0,0,0,0),18));v.setOnFocusChangeListener((a,h)->focus((TextView)a,h));return v;}
    void focus(TextView a,boolean h){a.animate().scaleX(h?1.08f:1f).scaleY(h?1.08f:1f).setDuration(130).start();a.setBackground(h?bg(Color.argb(165,21,57,88),0):bg(Color.argb(0,0,0,0),0));}

    void addMenu(){
        heroMenu=new LinearLayout(this);heroMenu.setGravity(Gravity.CENTER);heroMenu.setPadding(dp(8),0,dp(8),0);
        String ip=ui.iconPlacement();ArrayList<String> labels=new ArrayList<>();
        if(ip.equals("left")){labels.add("⌕");labels.add("⚙");}
        if(ip.equals("inline"))Collections.addAll(labels,"Home","Live TV","Movies","Shows","Settings","⌕","⚙"); else Collections.addAll(labels,"Home","Live TV","Movies","Shows","Settings");
        if(ip.equals("right")){labels.add("⌕");labels.add("⚙");}
        for(String s:labels){
            TextView m=btn(s);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(48));lp.setMargins(dp(5),0,dp(5),0);heroMenu.addView(m,lp);menuItems.add(m);
            m.setOnClickListener(v->{String z=((TextView)v).getText().toString();if(z.equals("Live TV"))showLiveTv();else if(z.equals("Movies")||z.equals("Shows"))showCatalogs(z);else if(z.equals("Settings")||z.equals("⚙"))showSettings();else if(z.equals("⌕"))showSearch();else showHome();});
            m.setOnKeyListener((v,key,event)->{if(event.getAction()!=KeyEvent.ACTION_DOWN)return false;int pos=menuItems.indexOf(v);if(key==KeyEvent.KEYCODE_DPAD_RIGHT){menuItems.get((pos+1)%menuItems.size()).requestFocus();return true;}if(key==KeyEvent.KEYCODE_DPAD_LEFT){menuItems.get((pos-1+menuItems.size())%menuItems.size()).requestFocus();return true;}return false;});
        }
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(dp(650),dp(58));hp.topMargin=dp(20);hp.leftMargin=dp(ui.topMenuOffsetDp());String pos=ui.menuPosition();hp.gravity=Gravity.TOP|(pos.equals("left")?Gravity.LEFT:pos.equals("right")?Gravity.RIGHT:Gravity.CENTER_HORIZONTAL);root.addView(heroMenu,hp);
    }

    void showHome(){
        clear();nav.go(NavigationController.Screen.HOME);backdrop();addMenu();
        heroLogoImage=new ImageView(this);heroLogoImage.setScaleType(ImageView.ScaleType.FIT_START);heroLogoImage.setAdjustViewBounds(true);FrameLayout.LayoutParams lpLogo=new FrameLayout.LayoutParams(dp(520),dp(118));lpLogo.leftMargin=dp(22+ui.heroTextLeftDp());lpLogo.topMargin=dp(86+ui.heroTextTopDp());root.addView(heroLogoImage,lpLogo);
        heroTitle=tv("Debrid\nChannels",42,Typeface.BOLD);heroTitle.setGravity(Gravity.LEFT);heroTitle.setIncludeFontPadding(false);FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(dp(680),dp(112));tp.leftMargin=dp(22+ui.heroTextLeftDp());tp.topMargin=dp(92+ui.heroTextTopDp());root.addView(heroTitle,tp);
        heroMeta=tv("2026 • FEATURED • IMDB 8.2 | TMDB 7.0",17,Typeface.BOLD);heroMeta.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);heroMeta.setTextColor(Color.rgb(255,225,60));FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(dp(760),dp(42));mp.leftMargin=dp(22+ui.heroTextLeftDp());mp.topMargin=dp(202+ui.heroTextTopDp());root.addView(heroMeta,mp);
        heroDesc=tv("Backend catalog artwork is loading. Focus a row card to update the full-screen background, logo/title layer, metadata and extra-art slot.",20,Typeface.BOLD);heroDesc.setGravity(Gravity.LEFT);FrameLayout.LayoutParams dpv=new FrameLayout.LayoutParams(dp(780),dp(120));dpv.leftMargin=dp(22+ui.heroTextLeftDp());dpv.topMargin=dp(245+ui.heroTextTopDp());root.addView(heroDesc,dpv);
        heroBannerImage=new ImageView(this);heroBannerImage.setScaleType(ImageView.ScaleType.FIT_CENTER);heroBannerImage.setBackground(bg(Color.argb(85,0,0,0),0));heroBannerImage.setAlpha(ui.extraArtworkOpacityPercent()/100f);FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(ui.extraArtworkWidthDp()),dp(ui.extraArtworkHeightDp()));bp.leftMargin=dp(ui.extraArtworkXdp());bp.topMargin=dp(ui.extraArtworkYdp());root.addView(heroBannerImage,bp);
        TextView banner=tv("Banner",20,Typeface.NORMAL);banner.setAlpha(.55f);FrameLayout.LayoutParams btp=new FrameLayout.LayoutParams(dp(ui.extraArtworkWidthDp()),dp(50));btp.leftMargin=dp(ui.extraArtworkXdp());btp.topMargin=dp(ui.extraArtworkYdp()+ui.extraArtworkHeightDp()/2-25);root.addView(banner,btp);
        addHeroRows(); if(!movies.isEmpty())updateHero(movies.get(0));
    }

    GradientDrawable cardBg(int a){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.argb(a,28,50,65),Color.argb(a,8,10,18)});g.setCornerRadius(dp(ui.cornerRadiusDp()));g.setStroke(dp(1),Color.argb(70,255,255,255));return g;}
    void addHeroRows(){int top=ui.rowTopDp();for(int ri=0;ri<Math.min(3,homeRows.size());ri++)addHeroRow(homeRows.get(ri),top+ri*(ui.cardHeightDp()+82));}
    void addHeroRow(HomeRow sourceRow,int topDp){
        if(ui.rowTitleVisibility()==1){TextView rt=tv((ui.rowTitleIconsEnabled()==1?"▸ ":"")+sourceRow.title,22,Typeface.BOLD);rt.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);FrameLayout.LayoutParams rtp=new FrameLayout.LayoutParams(dp(700),dp(44));rtp.leftMargin=dp(38+ui.rowLeftDp());rtp.topMargin=dp(topDp-45);root.addView(rt,rtp);}        
        final HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);hsv.setClipToPadding(false);hsv.setSmoothScrollingEnabled(true);hsv.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);int sidePad=dp(28+ui.rowLeftDp());hsv.setPadding(sidePad,0,dp(320),0);FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(Math.max(190, ui.cardHeightDp()+78)));hp.topMargin=dp(topDp);root.addView(hsv,hp);
        final LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);hsv.addView(row,new HorizontalScrollView.LayoutParams(-2,-1));
        for(int i=0;i<sourceRow.items.size();i++){final Movie movie=sourceRow.items.get(i);FrameLayout card=new FrameLayout(this);card.setFocusable(true);card.setBackground(cardBg(205));
            ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);card.addView(img,new FrameLayout.LayoutParams(-1,-1));loadImage(movie.poster,img,false);
            TextView label=tv(movie.title,17,Typeface.BOLD);label.setGravity(Gravity.LEFT|Gravity.BOTTOM);label.setPadding(dp(14),0,dp(8),dp(10));label.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,new int[]{Color.argb(205,0,0,0),Color.TRANSPARENT}));card.addView(label,new FrameLayout.LayoutParams(-1,-1));
            card.setOnKeyListener((v,key,event)->{if(event.getAction()!=KeyEvent.ACTION_DOWN)return false;int pos=row.indexOfChild(v);if(key==KeyEvent.KEYCODE_DPAD_RIGHT&&pos<row.getChildCount()-1){View next=row.getChildAt(pos+1);next.requestFocus();centerSnap(hsv,next);return true;}if(key==KeyEvent.KEYCODE_DPAD_LEFT&&pos>0){View prev=row.getChildAt(pos-1);prev.requestFocus();centerSnap(hsv,prev);return true;}return false;});
            card.setOnFocusChangeListener((v,h)->{float scale=h?Math.max(1f,ui.focusedScalePercent()/100f):1f;v.animate().scaleX(scale).scaleY(scale).translationY(h?-dp(8):0).setDuration(180).start();v.setBackground(h?stroke(Color.argb(235,20,24,36),Color.argb(190,255,255,255)):cardBg(205));if(h){scheduleHeroUpdate(movie);v.postDelayed(()->centerSnap(hsv,v),40);}});
            card.setOnClickListener(v->showMovieDetails(movie));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(ui.cardWidthDp()),dp(ui.cardHeightDp()));cp.setMargins(0,dp(18),dp(ui.cardSpacingDp()),0);row.addView(card,cp);
        }
        hsv.postDelayed(()->{if(!suppressRowAutoFocus && row.getChildCount()>0){View start=row.getChildAt(0);start.requestFocus();centerSnap(hsv,start);}},140);
    }
    void centerSnap(HorizontalScrollView hsv,View card){int target=card.getLeft()+card.getWidth()/2-getResources().getDisplayMetrics().widthPixels/2;hsv.smoothScrollTo(Math.max(0,target),0);}
    void scheduleHeroUpdate(Movie m){
        if(pendingHeroRunnable!=null)heroHandler.removeCallbacks(pendingHeroRunnable);
        pendingHeroRunnable=()->updateHero(m);
        heroHandler.postDelayed(pendingHeroRunnable,210);
    }

    void updateHero(Movie m){
        if(heroTitle!=null){heroTitle.setText(m.title.replace(" ","\n"));heroTitle.setVisibility((m.logo!=null&&!m.logo.isEmpty())?View.INVISIBLE:View.VISIBLE);} 
        if(heroMeta!=null)heroMeta.setText((m.meta==null||m.meta.isEmpty()?m.year:m.meta));
        if(heroDesc!=null)heroDesc.setText(m.overview==null||m.overview.isEmpty()?"Focused card updates background, logo, banner and metadata from backend artwork fields.":m.overview);
        if(heroBackdropImage!=null)loadImage(first(m.background,m.poster),heroBackdropImage,true);
        if(heroLogoImage!=null)loadImage(m.logo,heroLogoImage,true);
        if(heroBannerImage!=null)loadImage(first(m.banner,m.logo,m.poster),heroBannerImage,true);
    }
    String first(String...v){for(String x:v)if(x!=null&&!x.trim().isEmpty())return x.trim();return "";}

    void showCatalogs(String type){suppressRowAutoFocus=false;clear();nav.go(NavigationController.Screen.VOD);backdrop();addMenu();TextView h=tv(type,38,Typeface.BOLD);h.setGravity(Gravity.LEFT);FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(dp(500),dp(60));hp.leftMargin=dp(55);hp.topMargin=dp(115);root.addView(h,hp);addHeroRows();}
    void showMovieDetails(Movie m){suppressRowAutoFocus=false;clear();backdrop();addMenu();updateHero(m);TextView title=tv(m.title,46,Typeface.BOLD);title.setGravity(Gravity.LEFT);FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(dp(850),dp(70));tp.leftMargin=dp(70);tp.topMargin=dp(145);root.addView(title,tp);TextView play=btn("▶ Play / Select Links");play.setOnClickListener(v->playMovie(m));FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(360),dp(70));pp.leftMargin=dp(70);pp.topMargin=dp(250);root.addView(play,pp);play.requestFocus();}
    void playMovie(Movie m){showVideo(m.title,first(m.url,"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"),"VOD PLAYER UI • artwork, ratings, audio/subtitle/episode/zoom controls");}
    void playChannel(Channel c){showVideo(c.name,c.url,"LIVE TV PLAYER • single PlayerManager owner");}
    void showVideo(String title,String url,String overlay){clear();backdrop();VideoView vv=new VideoView(this);vv.setFocusable(false);root.addView(vv,new FrameLayout.LayoutParams(-1,-1));TextView top=tv(title+"\n"+overlay,24,Typeface.BOLD);top.setGravity(Gravity.LEFT|Gravity.TOP);top.setPadding(dp(32),dp(28),0,0);top.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{Color.argb(190,0,0,0),Color.TRANSPARENT}));root.addView(top,new FrameLayout.LayoutParams(-1,dp(160)));TextView back=btn("Back");back.setOnClickListener(v->showHome());FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(160),dp(55),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);bp.bottomMargin=dp(45);root.addView(back,bp);try{vv.setVideoURI(android.net.Uri.parse(url));vv.setOnPreparedListener(mp->{mp.setLooping(true);vv.start();});}catch(Exception e){}back.requestFocus();}

    void showLiveTv(){suppressRowAutoFocus=false;clear();nav.go(NavigationController.Screen.LIVE_TV);backdrop();addMenu();TextView title=tv("Live TV Guide",34,Typeface.BOLD);title.setGravity(Gravity.LEFT);FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(dp(430),dp(60));tp.leftMargin=dp(52);tp.topMargin=dp(112);root.addView(title,tp);LinearLayout guide=new LinearLayout(this);guide.setOrientation(LinearLayout.VERTICAL);guide.setBackground(bg(Color.argb(145,5,8,16),20));FrameLayout.LayoutParams gp=new FrameLayout.LayoutParams(dp(1120),dp(500));gp.leftMargin=dp(55);gp.topMargin=dp(185);root.addView(guide,gp);TextView th=tv("CHANNEL        NOW              2:30 PM              3:00 PM              3:30 PM",16,Typeface.BOLD);guide.addView(th,new LinearLayout.LayoutParams(-1,dp(50)));for(int i=0;i<8;i++){Channel ch=channels.get(i%channels.size());TextView r=btn("  "+(101+i)+"  "+ch.name+"        Playing Now              Up Next              Later");r.setGravity(Gravity.CENTER_VERTICAL);final Channel fc=ch;r.setOnClickListener(v->playChannel(fc));guide.addView(r,new LinearLayout.LayoutParams(-1,dp(56)));}guide.getChildAt(1).requestFocus();}

    LinearLayout form(String title){
        ScrollView sv=new ScrollView(this);sv.setFillViewport(false);sv.setFocusable(false);
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(dp(60),dp(96),dp(60),dp(60));
        sv.addView(p,new ScrollView.LayoutParams(-1,-2));root.addView(sv,new FrameLayout.LayoutParams(-1,-1));
        TextView h=tv(title,34,Typeface.BOLD);h.setGravity(Gravity.LEFT);p.addView(h,new LinearLayout.LayoutParams(-1,dp(70)));return p;
    }
    LinearLayout overlayForm(String title){
        View dim=new View(this);dim.setBackgroundColor(Color.argb(132,0,0,0));root.addView(dim,new FrameLayout.LayoutParams(-1,-1));
        ScrollView sv=new ScrollView(this);
        editorScroll=sv;
        sv.setFillViewport(false);
        sv.setFocusable(false);
        sv.setFocusableInTouchMode(false);
        sv.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        sv.setSmoothScrollingEnabled(true);
        sv.setClipToPadding(false);
        sv.setPadding(0,0,0,dp(80));
        sv.setBackground(bg(Color.argb(232,9,13,22),28));
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(dp(28),dp(24),dp(28),dp(140));sv.addView(p,new ScrollView.LayoutParams(-1,-2));
        FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(dp(870),-1,Gravity.RIGHT|Gravity.TOP);sp.setMargins(0,dp(78),dp(22),dp(30));root.addView(sv,sp);
        TextView h=tv(title,30,Typeface.BOLD);h.setGravity(Gravity.LEFT);p.addView(h,new LinearLayout.LayoutParams(-1,dp(62)));return p;
    }
    void settingButton(LinearLayout p,String text,View.OnClickListener l){TextView b=btn(text);b.setGravity(Gravity.CENTER_VERTICAL);b.setOnClickListener(l);b.setOnFocusChangeListener((v,has)->{focus((TextView)v,has);if(has)ensureEditorVisible(v);});p.addView(b,new LinearLayout.LayoutParams(dp(790),dp(58)));}
    void ensureEditorVisible(View v){ if(editorScroll==null||v==null)return; editorScroll.postDelayed(()->{try{Rect r=new Rect();v.getDrawingRect(r);editorScroll.offsetDescendantRectToMyCoords(v,r);int pad=dp(90);int top=r.top-pad;int bottom=r.bottom+pad;int sy=editorScroll.getScrollY();int sh=editorScroll.getHeight();if(top<sy)editorScroll.smoothScrollTo(0,Math.max(0,top));else if(bottom>sy+sh)editorScroll.smoothScrollTo(0,bottom-sh);}catch(Exception ignored){}},40); }
    void showSettings(){suppressRowAutoFocus=false;clear();nav.go(NavigationController.Screen.SETTINGS);backdrop();addMenu();LinearLayout p=form("Settings");settingButton(p,"Pro Layout Editor",v->showLayoutEditor());settingButton(p,"Stremio Addon JSON Manager",v->editTextScreen("Stremio addon JSON links",stremio.getJsonLinks(),s->stremio.saveJsonLinks(s)));settingButton(p,"Backend Base URL: "+backend.baseUrl(),v->editTextScreen("Backend Base URL",backend.baseUrl(),s->{backend.saveBaseUrl(s);loadBackendHomeRows();}));settingButton(p,"Live TV M3U / Channels DVR URL",v->editTextScreen("Live TV M3U URL",backend.m3uUrl(),s->{backend.saveM3uUrl(s);loadM3u(s);}));settingButton(p,"Refresh Backend Catalog Rows",v->{loadBackendHomeRows();Toast.makeText(this,"Refreshing backend rows",Toast.LENGTH_SHORT).show();});settingButton(p,"4K UI: "+(ui.ui4k()?"Enabled":"Disabled"),v->{ui.save4k(!ui.ui4k());showSettings();});if(p.getChildCount()>8)p.getChildAt(8).requestFocus();}
    interface SaveText{void save(String s);} void editTextScreen(String title,String current,SaveText save){clear();backdrop();addMenu();LinearLayout p=form(title);EditText e=new EditText(this);e.setText(current);e.setSingleLine(false);e.setMinLines(3);e.setTextColor(Color.WHITE);e.setHintTextColor(Color.GRAY);e.setTextSize(18);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);e.setBackground(stroke(Color.argb(120,20,25,35),Color.argb(100,255,255,255)));p.addView(e,new LinearLayout.LayoutParams(-1,dp(160)));TextView done=btn("Save");done.setOnClickListener(v->{save.save(e.getText().toString());showSettings();});p.addView(done,new LinearLayout.LayoutParams(dp(180),dp(60)));e.requestFocus();}

    void showLayoutEditor(){
        suppressRowAutoFocus=true;showHome();nav.go(NavigationController.Screen.LAYOUT_EDITOR);
        LinearLayout p=overlayForm("Pro Layout Editor");
        settingButton(p,"Save layout",v->{ui.saveLayoutSnapshot();Toast.makeText(this,"Layout saved",Toast.LENGTH_SHORT).show();});
        settingButton(p,"Reset layout",v->{ui.resetLayoutDefaults();Toast.makeText(this,"Layout reset",Toast.LENGTH_SHORT).show();showLayoutEditor();});
        settingButton(p,"View Home",v->{ui.saveLayoutSnapshot();suppressRowAutoFocus=false;showHome();});
        settingButton(p,"Menu position: "+ui.menuPosition(),v->{cycleMenuPosition();showLayoutEditor();});
        settingButton(p,"Icons: "+ui.iconPlacement(),v->{cycleIconPlacement();showLayoutEditor();});
        settingButton(p,"Row titles: "+(ui.rowTitles()?"Shown":"Hidden"),v->{ui.saveRowTitles(!ui.rowTitles());showLayoutEditor();});
        settingButton(p,"4K UI: "+(ui.ui4k()?"Enabled":"Disabled"),v->{ui.save4k(!ui.ui4k());showLayoutEditor();});
        addSlider(p,"Card width","cardWidthDp",UiStateStore.MIN_CARD_WIDTH_DP,UiStateStore.MAX_CARD_WIDTH_DP,ui.cardWidthDp());
        addSlider(p,"Card height","cardHeightDp",UiStateStore.MIN_CARD_HEIGHT_DP,UiStateStore.MAX_CARD_HEIGHT_DP,ui.cardHeightDp());
        addSlider(p,"Card spacing","cardSpacingDp",0,56,ui.cardSpacingDp());
        addSlider(p,"Focused scale %","focusedScalePercent",100,125,ui.focusedScalePercent());
        addSlider(p,"Glow strength %","glowStrengthPercent",0,100,ui.glowStrengthPercent());
        addSlider(p,"Corner radius","cornerRadiusDp",0,44,ui.cornerRadiusDp());
        addSlider(p,"Row vertical position","rowTopDp",260,660,ui.rowTopDp());
        addSlider(p,"Row left offset","rowLeftDp",0,120,ui.rowLeftDp());
        addSlider(p,"Hero text left","heroTextLeftDp",-40,260,ui.heroTextLeftDp());
        addSlider(p,"Hero text top","heroTextTopDp",-60,180,ui.heroTextTopDp());
        addSlider(p,"Top menu offset","topMenuOffsetDp",-260,260,ui.topMenuOffsetDp());
        addSlider(p,"Extra artwork X","extraArtworkXdp",0,1200,ui.extraArtworkXdp());
        addSlider(p,"Extra artwork Y","extraArtworkYdp",0,560,ui.extraArtworkYdp());
        addSlider(p,"Extra artwork width","extraArtworkWidthDp",80,620,ui.extraArtworkWidthDp());
        addSlider(p,"Extra artwork height","extraArtworkHeightDp",60,420,ui.extraArtworkHeightDp());
        addSlider(p,"Extra artwork opacity %","extraArtworkOpacityPercent",0,100,ui.extraArtworkOpacityPercent());
        addSlider(p,"Search item placement","searchItemPlacement",0,3,ui.searchItemPlacement());
        addSlider(p,"Settings item placement","settingsItemPlacement",0,3,ui.settingsItemPlacement());
        addSlider(p,"Effect profile","effectProfileIndex",0,4,ui.effectProfileIndex());
        addSlider(p,"Hover info overlay","hoverInfoOverlay",0,1,ui.hoverInfoOverlay());
        if(p.getChildCount()>8)p.getChildAt(8).requestFocus();
    }
    void cycleMenuPosition(){String m=ui.menuPosition();ui.saveMenuPosition(m.equals("left")?"center":m.equals("center")?"right":"left");}
    void cycleIconPlacement(){String m=ui.iconPlacement();ui.saveIconPlacement(m.equals("right")?"inline":m.equals("inline")?"left":m.equals("left")?"hidden":"right");}
    void addSlider(LinearLayout parent,String label,String key,int min,int max,int current){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setFocusable(true);
        box.setFocusableInTouchMode(true);
        box.setPadding(dp(16),dp(6),dp(16),dp(8));
        box.setBackground(stroke(Color.argb(54,20,25,35),Color.argb(45,255,255,255)));
        TextView title=tv(label+": "+current,15,Typeface.BOLD);
        title.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        TextView hint=tv("◀ / ▶ adjust    OK save preview",11,Typeface.NORMAL);
        hint.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        hint.setTextColor(Color.argb(185,255,255,255));
        ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        bar.setMax(max-min);
        bar.setProgress(Math.max(0,Math.min(max-min,current-min)));
        box.addView(title,new LinearLayout.LayoutParams(dp(750),dp(30)));
        box.addView(bar,new LinearLayout.LayoutParams(dp(750),dp(22)));
        box.addView(hint,new LinearLayout.LayoutParams(dp(750),dp(24)));
        final int[] val=new int[]{Math.max(min,Math.min(max,current))};
        Runnable apply=()->{ title.setText(label+": "+val[0]); bar.setProgress(val[0]-min); ui.saveValue(key,val[0]); };
        box.setOnFocusChangeListener((v,has)->{ box.animate().scaleX(has?1.018f:1f).scaleY(has?1.018f:1f).setDuration(100).start(); box.setBackground(has?stroke(Color.argb(120,18,72,126),Color.argb(210,64,160,255)):stroke(Color.argb(54,20,25,35),Color.argb(45,255,255,255))); if(has)ensureEditorVisible(box); });
        box.setOnKeyListener((v,k,e)->{ if(e.getAction()!=KeyEvent.ACTION_DOWN)return false; int step=(max-min)>500?25:(max-min)>120?10:1; if(k==KeyEvent.KEYCODE_DPAD_LEFT){val[0]=Math.max(min,val[0]-step);apply.run();return true;} if(k==KeyEvent.KEYCODE_DPAD_RIGHT){val[0]=Math.min(max,val[0]+step);apply.run();return true;} if(k==KeyEvent.KEYCODE_DPAD_CENTER||k==KeyEvent.KEYCODE_ENTER){ui.saveLayoutSnapshot();Toast.makeText(this,label+" saved",Toast.LENGTH_SHORT).show();return true;} return false; });
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(790),dp(94));lp.setMargins(0,dp(5),0,dp(10));parent.addView(box,lp);
    }

    void showSearch(){suppressRowAutoFocus=false;clear();backdrop();addMenu();LinearLayout p=form("Search");EditText e=new EditText(this);e.setHint("Search movies, shows, channels");e.setTextColor(Color.WHITE);e.setHintTextColor(Color.GRAY);e.setTextSize(22);e.setSingleLine(true);e.setBackground(stroke(Color.argb(110,20,25,35),Color.argb(100,255,255,255)));p.addView(e,new LinearLayout.LayoutParams(-1,dp(70)));e.requestFocus();}
    void loadM3u(String url){new Thread(()->{try{ArrayList<Channel> out=new ArrayList<>();BufferedReader br=new BufferedReader(new InputStreamReader(new URL(url).openStream()));String line,name="Channel",group="Other",logo="";while((line=br.readLine())!=null){if(line.startsWith("#EXTINF")){int ix=line.lastIndexOf(',');name=ix>=0?line.substring(ix+1).trim():"Channel";group=grab(line,"group-title=\"");logo=grab(line,"tvg-logo=\"");}else if(line.startsWith("http")){out.add(new Channel(name,group,line.trim(),logo));}}if(!out.isEmpty())runOnUiThread(()->{channels.clear();channels.addAll(out);Toast.makeText(this,"Loaded "+out.size()+" channels",Toast.LENGTH_LONG).show();});}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"M3U load failed: "+e.getMessage(),Toast.LENGTH_LONG).show());}}).start();}
    String grab(String line,String key){int s=line.indexOf(key);if(s<0)return "";s+=key.length();int e=line.indexOf('"',s);return e>s?line.substring(s,e):"";}

    void loadBackendHomeRows(){new Thread(()->{try{String txt=httpGet(joinUrl(backend.baseUrl(),"/api/home"));JSONObject rootObj=new JSONObject(txt);JSONArray rails=rootObj.optJSONArray("rails");if(rails==null||rails.length()==0)return;ArrayList<HomeRow> loaded=new ArrayList<>();ArrayList<Movie> flat=new ArrayList<>();for(int r=0;r<rails.length();r++){JSONObject ro=rails.optJSONObject(r);if(ro==null)continue;HomeRow row=new HomeRow(ro.optString("title",ro.optString("name","Catalog")));row.id=ro.optString("slug",ro.optString("id",""));JSONArray items=ro.optJSONArray("items");if(items==null)continue;for(int i=0;i<items.length();i++){JSONObject it=items.optJSONObject(i);if(it==null)continue;Movie m=new Movie(it.optString("title",it.optString("name","Untitled")),metaFrom(it,ro),"");m.id=it.optString("id",it.optString("externalId",it.optString("imdbId","")));m.type=it.optString("type",it.optString("streamLookupType","movie"));m.poster=abs(it.optString("poster",it.optString("posterUrl","")));m.background=abs(it.optString("background",it.optString("backdrop",it.optString("backdropUrl",m.poster))));m.logo=abs(it.optString("logo",it.optString("clearlogo",it.optString("logoUrl",""))));m.banner=abs(it.optString("banner",it.optString("thumb",m.logo)));m.overview=it.optString("overview",it.optString("description",""));m.year=it.optString("year","");row.items.add(m);flat.add(m);}if(!row.items.isEmpty())loaded.add(row);}if(!loaded.isEmpty())runOnUiThread(()->{homeRows.clear();homeRows.addAll(loaded);movies.clear();movies.addAll(flat);showHome();Toast.makeText(this,"Loaded backend artwork rows: "+flat.size(),Toast.LENGTH_SHORT).show();});}catch(Exception e){AppLogger.mark("Backend home load failed: "+e.getMessage());}}).start();}
    String metaFrom(JSONObject it,JSONObject ro){String y=it.optString("year","");String source=it.optString("source",ro.optString("source","Stremio Catalog"));return (y.isEmpty()?source:(y+" • "+source));}
    String joinUrl(String base,String path){if(base==null||base.trim().isEmpty())base="http://192.168.100.55:8181";base=base.trim();while(base.endsWith("/"))base=base.substring(0,base.length()-1);return base+path;}
    String abs(String u){if(u==null)return "";u=u.trim();if(u.isEmpty())return "";if(u.startsWith("http://")||u.startsWith("https://"))return u;if(u.startsWith("/"))return joinUrl(backend.baseUrl(),u);return u;}
    String httpGet(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);c.setRequestProperty("Accept","application/json");try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);return out.toString("UTF-8");}}
    void loadImage(String url,ImageView target,boolean cinematic){url=abs(url);if(target==null)return;if(url.isEmpty()){target.setImageDrawable(null);return;}final String fu=url;new Thread(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(fu).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(12000);c.setRequestProperty("User-Agent","DebridChannelsAndroidTV/6.4");Bitmap bm=BitmapFactory.decodeStream(c.getInputStream());if(bm!=null)runOnUiThread(()->{if(cinematic){target.setAlpha(0f);target.setImageBitmap(bm);target.animate().alpha(1f).setDuration(420).start();}else target.setImageBitmap(bm);});}catch(Exception e){AppLogger.mark("Artwork load failed: "+e.getMessage());}}).start();}

    @Override public boolean dispatchKeyEvent(KeyEvent e){if(e.getAction()==KeyEvent.ACTION_DOWN&&nav.current()==NavigationController.Screen.LIVE_TV){if(e.getKeyCode()==KeyEvent.KEYCODE_DPAD_UP){if(!menuItems.isEmpty())menuItems.get(0).requestFocus();return true;}}return super.dispatchKeyEvent(e);} 
    @Override public void onDestroy(){super.onDestroy();player.release();AppLogger.mark("DESTROY once "+BuildMarkers.LOG_MARKER);} 
}
