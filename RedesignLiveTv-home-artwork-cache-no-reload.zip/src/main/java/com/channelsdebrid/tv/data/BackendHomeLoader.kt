package com.channelsdebrid.tv.data

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class BackendHomeLoader {
    data class BackendItem(
        val id: String,
        val type: String,
        val title: String,
        val year: Int,
        val genre: String,
        val overview: String,
        val source: String,
        val poster: String?,
        val backdrop: String?
    )

    data class BackendRow(
        val slug: String,
        val title: String,
        val items: List<BackendItem>
    )

    fun cachedRowsOrEmpty(baseUrl: String): List<BackendRow> {
        val normalized = baseUrl.trim().trimEnd('/')
        return if (cachedRows.isNotEmpty() && normalized == cachedBaseUrl) cachedRows else emptyList()
    }

    fun loadRows(baseUrl: String, limitPerRow: Int = 12): List<BackendRow> {
        val normalized = baseUrl.trim().trimEnd('/')
        if (normalized.isBlank()) return emptyList()
        val conn = (URL("$normalized/api/home").openConnection() as HttpURLConnection).apply {
            connectTimeout = 5000
            readTimeout = 8000
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
        }
        conn.connect()
        if (conn.responseCode !in 200..299) {
            conn.disconnect()
            return emptyList()
        }
        val body = conn.inputStream.bufferedReader().use { it.readText() }
        conn.disconnect()
        val root = JSONObject(body)
        val rails = root.optJSONArray("rails") ?: return emptyList()
        val rows = mutableListOf<BackendRow>()
        for (i in 0 until rails.length()) {
            val rowObj = rails.optJSONObject(i) ?: continue
            val itemsJson = rowObj.optJSONArray("items")
            val items = mutableListOf<BackendItem>()
            if (itemsJson != null) {
                for (j in 0 until itemsJson.length()) {
                    val itemObj = itemsJson.optJSONObject(j) ?: continue
                    items += BackendItem(
                        id = itemObj.optString("id"),
                        type = itemObj.optString("type", "movie"),
                        title = itemObj.optString("title", "Unknown"),
                        year = itemObj.optInt("year", 0),
                        genre = itemObj.optString("genre", "Featured"),
                        overview = itemObj.optString("overview", ""),
                        source = itemObj.optString("source", "Backend"),
                        poster = itemObj.optString("poster").takeIf { it.isNotBlank() },
                        backdrop = itemObj.optString("backdrop").takeIf { it.isNotBlank() }
                    )
                    if (items.size >= limitPerRow) break
                }
            }
            if (items.isNotEmpty()) {
                rows += BackendRow(
                    slug = rowObj.optString("slug", "backend-row-$i"),
                    title = rowObj.optString("title", "Featured"),
                    items = items
                )
            }
        }
        return rows
    }
}
