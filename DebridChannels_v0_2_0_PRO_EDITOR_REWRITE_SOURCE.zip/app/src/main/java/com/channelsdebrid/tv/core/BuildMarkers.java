package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.2.0 PRO EDITOR REWRITE";
    public static final String LOG_MARKER = "DC_V0_2_0_PRO_EDITOR_REWRITE_ACTIVE";
    private BuildMarkers() {}
}
