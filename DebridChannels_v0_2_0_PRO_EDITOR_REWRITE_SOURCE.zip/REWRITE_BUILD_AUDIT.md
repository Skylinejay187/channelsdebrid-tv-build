# Rewrite Build Audit - v0.2.0 Pro Editor Rewrite

Base used: v0.1.9 working playback/settings line.
Rule followed: clean rewrite/consolidation of the Pro Layout Editor layer; broken v7.x code path not used.

Fixed in this build:
- Rebuilt Pro Layout Editor controls into grouped sections.
- Fixed Settings UI cropping by changing fixed-width rows to full-width adaptive rows.
- Wired font settings into active top menu, hero text, row titles, and settings/editor controls.
- Wired row title text show/hide and row title icon toggle.
- Wired menu style, icon placement, search/settings placement, and top menu offset to the active menu renderer.
- Wired card effects in the active row renderer: focus ring on/off, thickness/color, glow, rounded corners, dim unfocused cards, card lift, tilt, focus bounce, and glass mode.
- Kept working playback/player options from v0.1.9.

Version: 0.2.0 / versionCode 20
Marker: DC_V0_2_0_PRO_EDITOR_REWRITE_ACTIVE
