package com.channelsdebrid.tv

import android.content.Context
import com.bumptech.glide.GlideBuilder
import com.bumptech.glide.MemoryCategory
import com.bumptech.glide.annotation.GlideModule
import com.bumptech.glide.load.engine.cache.InternalCacheDiskCacheFactory
import com.bumptech.glide.module.AppGlideModule

@GlideModule
class ChannelsGlideModule : AppGlideModule() {
    override fun applyOptions(context: Context, builder: GlideBuilder) {
        builder.setDiskCache(InternalCacheDiskCacheFactory(context, "channels_image_cache", 1024L * 1024L * 512L))
        builder.setMemoryCategory(MemoryCategory.HIGH)
    }

    override fun isManifestParsingEnabled(): Boolean = false
}
