package com.channelsdebrid.tv.layout;
import android.content.Context;import android.content.SharedPreferences;
public final class UiStateStore {
    private final SharedPreferences p;
    public UiStateStore(Context c){ p=c.getSharedPreferences("dc_v5_ui_state",Context.MODE_PRIVATE); }
    public String menuPosition(){ return p.getString("menuPosition","center"); }
    public boolean rowTitles(){ return p.getBoolean("rowTitles",true); }
    public int heroLogoX(){ return p.getInt("heroLogoX",80); } public int heroLogoY(){ return p.getInt("heroLogoY",170); }
    public int artworkSize(){ return p.getInt("artworkSize",220); }
    public void saveMenuPosition(String v){ p.edit().putString("menuPosition",v).apply(); }
    public void saveRowTitles(boolean v){ p.edit().putBoolean("rowTitles",v).apply(); }
    public void saveArtwork(int x,int y,int size){ p.edit().putInt("heroLogoX",x).putInt("heroLogoY",y).putInt("artworkSize",size).apply(); }
}
