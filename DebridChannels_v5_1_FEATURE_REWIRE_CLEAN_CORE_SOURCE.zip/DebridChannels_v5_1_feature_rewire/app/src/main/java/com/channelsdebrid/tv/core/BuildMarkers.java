package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v5.0.0 TRUE BASE RESET";
    public static final String LOG_MARKER = "DC_V5_TRUE_BASE_RESET_CLEAN_CORE";
    private BuildMarkers() {}
}
