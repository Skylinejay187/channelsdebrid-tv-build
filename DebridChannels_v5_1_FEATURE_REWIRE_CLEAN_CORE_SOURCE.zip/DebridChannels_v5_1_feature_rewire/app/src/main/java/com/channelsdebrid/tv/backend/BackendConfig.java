package com.channelsdebrid.tv.backend;
import android.content.Context;import android.content.SharedPreferences;
public final class BackendConfig {
    private final SharedPreferences p;
    public BackendConfig(Context c){ p=c.getSharedPreferences("dc_v5_backend",Context.MODE_PRIVATE); }
    public String baseUrl(){ return p.getString("baseUrl", "http://192.168.1.50:8089"); }
    public void saveBaseUrl(String url){ p.edit().putString("baseUrl",url).apply(); }
}
