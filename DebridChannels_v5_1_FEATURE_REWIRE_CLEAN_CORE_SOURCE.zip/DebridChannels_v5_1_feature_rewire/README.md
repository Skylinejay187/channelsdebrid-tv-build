# Debrid Channels v5 TRUE BASE RESET

Clean source rewrite target: Android TV app package `com.channelsdebrid.tv`.

## Build marker
- Version: `5.0.0-TRUE-BASE-RESET`
- Logcat tag: `DC_V5_TRUE_BASE_RESET_CLEAN_CORE`

## Clean architecture owners
- `NavigationController` — one navigation controller
- `PlayerManager` — one player owner; player surface never takes focus
- `LiveTvStateMachine` — one Live TV state machine
- `GuideCacheOwner` — one guide cache owner
- `TimeshiftEngine` — one timeshift owner
- `UiStateStore` — one persistent Pro Layout Editor state store
- `StremioAddonRegistry` — persistent Stremio JSON link support
- `BackendConfig` — unchanged backend-base-url compatibility storage

## v5 reset notes
This is not a patch over the previous architecture. It is a clean Android project layout with one Activity and programmatic Android TV UI to avoid FrameLayout/RelativeLayout XML mismatch crashes.

## Build in GitHub Actions
Upload this zip contents to a repo and run the included workflow: `.github/workflows/android-build.yml`.
