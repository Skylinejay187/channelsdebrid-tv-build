package com.channelsdebrid.tv.playback

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.channelsdebrid.tv.R
import com.channelsdebrid.tv.settings.SettingsRepository
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class SeasonEpisodeActivity : AppCompatActivity() {

    data class EpisodeEntry(
        val season: Int,
        val episode: Int,
        val title: String,
        val stremioId: String
    )

    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var settingsRepository: SettingsRepository
    private lateinit var titleView: TextView
    private lateinit var metaView: TextView
    private lateinit var seasonList: LinearLayout
    private lateinit var episodeList: RecyclerView
    private lateinit var emptyView: TextView

    private var title: String = ""
    private var externalId: String = ""
    private var mediaType: String = "series"
    private var posterUrl: String? = null
    private var backdropUrl: String? = null
    private var logoUrl: String? = null
    private var itemMeta: String? = null
    private var episodes: List<EpisodeEntry> = emptyList()
    private var selectedSeason: Int = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_episode_selection)

        settingsRepository = SettingsRepository(this)
        titleView = findViewById(R.id.episodeTitle)
        metaView = findViewById(R.id.episodeMeta)
        seasonList = findViewById(R.id.seasonList)
        episodeList = findViewById(R.id.episodeList)
        emptyView = findViewById(R.id.episodeEmpty)

        title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        externalId = intent.getStringExtra(EXTRA_EXTERNAL_ID).orEmpty()
        mediaType = intent.getStringExtra(EXTRA_MEDIA_TYPE).orEmpty().ifBlank { "series" }
        posterUrl = intent.getStringExtra(EXTRA_POSTER_URL)
        backdropUrl = intent.getStringExtra(EXTRA_BACKDROP_URL)
        logoUrl = intent.getStringExtra(EXTRA_LOGO_URL)
        itemMeta = intent.getStringExtra(EXTRA_ITEM_META)

        titleView.text = title
        metaView.text = itemMeta ?: "Pick an episode before choosing a stream"
        episodeList.layoutManager = LinearLayoutManager(this)

        loadEpisodes()
    }

    private fun loadEpisodes() {
        val addons = settingsRepository.loadStremioAddons().filter { it.enabled && it.manifestUrl.isNotBlank() }
        if (addons.isEmpty()) {
            emptyView.visibility = View.VISIBLE
            emptyView.text = "Add a Stremio addon first"
            return
        }
        executor.execute {
            val loaded = addons.asSequence().mapNotNull { addon -> fetchEpisodes(addon.manifestUrl, externalId) }.firstOrNull().orEmpty()
            runOnUiThread {
                episodes = loaded.sortedWith(compareBy<EpisodeEntry> { it.season }.thenBy { it.episode })
                if (episodes.isEmpty()) {
                    emptyView.visibility = View.VISIBLE
                    emptyView.text = "No episode data available from your addons"
                } else {
                    emptyView.visibility = View.GONE
                    selectedSeason = episodes.first().season
                    renderSeasons()
                    renderEpisodesForSeason(selectedSeason)
                }
            }
        }
    }

    private fun renderSeasons() {
        seasonList.removeAllViews()
        val seasons = episodes.map { it.season }.distinct().sorted()
        seasons.forEach { season ->
            val chip = TextView(this).apply {
                text = "Season $season"
                textSize = 18f
                setPadding(28, 18, 28, 18)
                setTextColor(ContextCompat.getColor(context, android.R.color.white))
                background = ContextCompat.getDrawable(context, if (season == selectedSeason) R.drawable.guide_category_selected else R.drawable.guide_category_idle)
                isFocusable = true
                isFocusableInTouchMode = true
                setOnClickListener {
                    selectedSeason = season
                    renderSeasons()
                    renderEpisodesForSeason(season)
                }
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = 18
            seasonList.addView(chip, lp)
        }
    }

    private fun renderEpisodesForSeason(season: Int) {
        val seasonEpisodes = episodes.filter { it.season == season }
        episodeList.adapter = EpisodeAdapter(seasonEpisodes)
    }

    private inner class EpisodeAdapter(private val items: List<EpisodeEntry>) : RecyclerView.Adapter<EpisodeHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EpisodeHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_episode_option, parent, false)
            return EpisodeHolder(view)
        }
        override fun getItemCount(): Int = items.size
        override fun onBindViewHolder(holder: EpisodeHolder, position: Int) {
            val item = items[position]
            holder.title.text = String.format(Locale.US, "S%d • E%d", item.season, item.episode)
            holder.subtitle.text = item.title
            holder.itemView.setOnClickListener {
                startActivity(Intent(this@SeasonEpisodeActivity, SourceSelectionActivity::class.java)
                    .putExtra(SourceSelectionActivity.EXTRA_TITLE, if (item.title.isBlank()) title else "$title • ${item.title}")
                    .putExtra(SourceSelectionActivity.EXTRA_EXTERNAL_ID, item.stremioId)
                    .putExtra(SourceSelectionActivity.EXTRA_MEDIA_TYPE, mediaType)
                    .putExtra(SourceSelectionActivity.EXTRA_POSTER_URL, posterUrl)
                    .putExtra(SourceSelectionActivity.EXTRA_BACKDROP_URL, backdropUrl)
                    .putExtra(SourceSelectionActivity.EXTRA_LOGO_URL, logoUrl)
                    .putExtra(SourceSelectionActivity.EXTRA_ITEM_META, itemMeta)
                )
            }
        }
    }

    private class EpisodeHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.episodeOptionTitle)
        val subtitle: TextView = view.findViewById(R.id.episodeOptionSubtitle)
    }

    private fun fetchEpisodes(manifestUrl: String, externalId: String): List<EpisodeEntry>? {
        val base = manifestUrl.removeSuffix("/manifest.json").trimEnd('/')
        val url = "$base/meta/series/${externalId}.json"
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 8000
        connection.readTimeout = 8000
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("User-Agent", "ChannelsDebridTV/1.0")
        return try {
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (connection.responseCode !in 200..299 || body.isBlank()) return null
            val json = JSONObject(body)
            val meta = json.optJSONObject("meta") ?: return null
            val videos = meta.optJSONArray("videos") ?: JSONArray()
            buildList {
                for (i in 0 until videos.length()) {
                    val video = videos.optJSONObject(i) ?: continue
                    val season = video.optInt("season", 0)
                    val episode = video.optInt("episode", 0)
                    if (season <= 0 || episode <= 0) continue
                    val id = video.optString("id").ifBlank { "$externalId:$season:$episode" }
                    add(EpisodeEntry(season, episode, video.optString("title").ifBlank { video.optString("name").ifBlank { "Episode $episode" } }, id))
                }
            }
        } catch (_: Throwable) {
            null
        } finally {
            connection.disconnect()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_EXTERNAL_ID = "external_id"
        const val EXTRA_MEDIA_TYPE = "media_type"
        const val EXTRA_POSTER_URL = "poster_url"
        const val EXTRA_BACKDROP_URL = "backdrop_url"
        const val EXTRA_LOGO_URL = "logo_url"
        const val EXTRA_ITEM_META = "item_meta"
    }
}
