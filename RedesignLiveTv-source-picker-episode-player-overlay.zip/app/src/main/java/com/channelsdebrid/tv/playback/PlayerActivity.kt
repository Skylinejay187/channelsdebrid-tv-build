package com.channelsdebrid.tv.playback

import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.ui.PlayerView
import com.bumptech.glide.Glide
import com.channelsdebrid.tv.R
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var topOverlay: View
    private lateinit var titleView: TextView
    private lateinit var statusView: TextView
    private lateinit var channelBadgeView: TextView
    private lateinit var mediaLogoView: ImageView
    private lateinit var mediaMetaView: TextView
    private lateinit var clockView: TextView
    private lateinit var nowTimeView: TextView
    private lateinit var nextView: TextView
    private lateinit var progressView: ProgressBar

    private lateinit var guideOverlay: View
    private lateinit var guideModeView: TextView
    private lateinit var guideClockView: TextView
    private lateinit var guideTitleView: TextView
    private lateinit var guideMetaView: TextView
    private lateinit var guideHintView: TextView
    private lateinit var guideInfoLogoView: TextView
    private lateinit var guideList: LinearLayout
    private lateinit var guideScroller: HorizontalScrollView

    private val overlayHandler = Handler(Looper.getMainLooper())
    private val hideTopOverlayRunnable = Runnable {
        if (!guideOverlay.isVisible && player?.isPlaying == true) {
            topOverlay.visibility = View.GONE
        }
    }
    private val hideGuideRunnable = Runnable {
        if (player?.isPlaying == true) hideGuideOverlay()
    }

    private var channels: List<GuideChannel> = emptyList()
    private var currentIndex: Int = 0
    private var selectedGuideIndex: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_player)

        playerView = findViewById(R.id.playerView)
        topOverlay = findViewById(R.id.playerTopOverlay)
        titleView = findViewById(R.id.playerTitle)
        statusView = findViewById(R.id.playerStatus)
        channelBadgeView = findViewById(R.id.playerChannelBadge)
        mediaLogoView = findViewById(R.id.playerMediaLogo)
        mediaMetaView = findViewById(R.id.playerMediaMeta)
        clockView = findViewById(R.id.playerClock)
        nowTimeView = findViewById(R.id.playerNowTime)
        nextView = findViewById(R.id.playerNext)
        progressView = findViewById(R.id.playerProgress)

        guideOverlay = findViewById(R.id.guideOverlay)
        guideModeView = findViewById(R.id.guideMode)
        guideClockView = findViewById(R.id.guideClock)
        guideTitleView = findViewById(R.id.guideTitle)
        guideMetaView = findViewById(R.id.guideMeta)
        guideHintView = findViewById(R.id.guideHint)
        guideInfoLogoView = findViewById(R.id.guideInfoLogo)
        guideList = findViewById(R.id.guideChannelList)
        guideScroller = findViewById(R.id.guideScroller)

        playerView.useController = false
        playerView.controllerAutoShow = false

        val streamUrl = intent.getStringExtra(EXTRA_STREAM_URL)
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val sourceLabel = intent.getStringExtra(EXTRA_SOURCE_LABEL).orEmpty()
        val debugLabel = intent.getStringExtra(EXTRA_DEBUG_LABEL).orEmpty()
        val mediaLogoUrl = intent.getStringExtra(EXTRA_MEDIA_LOGO_URL)
        val mediaMeta = intent.getStringExtra(EXTRA_MEDIA_META).orEmpty()

        channels = decodeChannels(intent.getStringExtra(EXTRA_CHANNELS_JSON))
        currentIndex = intent.getIntExtra(EXTRA_CHANNEL_INDEX, 0).coerceIn(0, (channels.size - 1).coerceAtLeast(0))
        selectedGuideIndex = currentIndex

        val current = channels.getOrNull(currentIndex)
        titleView.text = if (title.isBlank()) current?.name ?: "Playback" else title
        statusView.text = if (sourceLabel.isBlank()) "Favorites" else sourceLabel
        channelBadgeView.text = (current?.name ?: titleView.text.toString()).take(6).uppercase(Locale.US)
        mediaMetaView.text = mediaMeta
        if (!mediaLogoUrl.isNullOrBlank()) {
            mediaLogoView.visibility = View.VISIBLE
            Glide.with(this).load(mediaLogoUrl).into(mediaLogoView)
        } else {
            mediaLogoView.visibility = View.GONE
        }
        updateClockViews()
        bindProgramMeta(current)

        if (streamUrl.isNullOrBlank()) {
            Toast.makeText(this, "No stream URL available", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        initializePlayer(streamUrl, sourceLabel, debugLabel)
        renderGuideOverlay()
        scheduleTopOverlayHide()
    }

    private fun initializePlayer(streamUrl: String, sourceLabel: String, debugLabel: String) {
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("ChannelsDebridTV/1.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10000)
            .setReadTimeoutMs(15000)

        val mediaSourceFactory = DefaultMediaSourceFactory(httpFactory)

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(5000, 15000, 2500, 5000)
            .build()

        val exoPlayer = ExoPlayer.Builder(this)
            .setMediaSourceFactory(mediaSourceFactory)
            .setLoadControl(loadControl)
            .setSeekBackIncrementMs(10000)
            .setSeekForwardIncrementMs(10000)
            .build()
            .also { player = it }

        playerView.player = exoPlayer
        playerView.keepScreenOn = true

        val mediaItemBuilder = MediaItem.Builder().setUri(Uri.parse(streamUrl))
        if (looksLikeTsStream(streamUrl)) {
            mediaItemBuilder.setMimeType(MimeTypes.VIDEO_MP2T)
        }
        val mediaItem = mediaItemBuilder.build()

        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.addListener(object : androidx.media3.common.Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                val ready = playbackState == androidx.media3.common.Player.STATE_READY
                if (ready) {
                    scheduleTopOverlayHide()
                } else {
                    topOverlay.visibility = View.VISIBLE
                    statusView.text = if (sourceLabel.isBlank()) "Buffering…" else "Buffering $sourceLabel…"
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                topOverlay.visibility = View.VISIBLE
                statusView.text = buildString {
                    append("Playback error")
                    if (sourceLabel.isNotBlank()) {
                        append(" • ")
                        append(sourceLabel)
                    }
                    if (debugLabel.isNotBlank()) {
                        append("\n")
                        append(debugLabel)
                    }
                }
                showGuideOverlay()
            }
        })
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (!guideOverlay.isVisible) {
                    selectedGuideIndex = currentIndex
                    showGuideOverlay()
                }
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (guideOverlay.isVisible) {
                    moveGuideSelection(-1)
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (guideOverlay.isVisible) {
                    moveGuideSelection(1)
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_BACK -> {
                if (guideOverlay.isVisible) {
                    hideGuideOverlay()
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                if (guideOverlay.isVisible) {
                    hideGuideOverlay()
                } else {
                    topOverlay.visibility = View.VISIBLE
                    updateClockViews()
                    scheduleTopOverlayHide()
                }
                return true
            }
        }
        if (!guideOverlay.isVisible) {
            topOverlay.visibility = View.VISIBLE
            scheduleTopOverlayHide()
        }
        return super.dispatchKeyEvent(event)
    }

    private fun moveGuideSelection(delta: Int) {
        if (channels.isEmpty()) return
        selectedGuideIndex = (selectedGuideIndex + delta).coerceIn(0, channels.lastIndex)
        renderGuideOverlay()
        playSelectedChannel()
        scheduleGuideHide()
    }

    private fun showGuideOverlay() {
        guideModeView.text = "QUICK GUIDE"
        guideOverlay.visibility = View.VISIBLE
        updateClockViews()
        renderGuideOverlay()
        scheduleGuideHide()
    }

    private fun hideGuideOverlay() {
        overlayHandler.removeCallbacks(hideGuideRunnable)
        guideOverlay.visibility = View.GONE
        scheduleTopOverlayHide()
    }

    private fun scheduleTopOverlayHide() {
        overlayHandler.removeCallbacks(hideTopOverlayRunnable)
        overlayHandler.postDelayed(hideTopOverlayRunnable, 4000)
    }

    private fun scheduleGuideHide() {
        overlayHandler.removeCallbacks(hideGuideRunnable)
        overlayHandler.postDelayed(hideGuideRunnable, 4500)
    }

    private fun playSelectedChannel() {
        val target = channels.getOrNull(selectedGuideIndex) ?: return
        currentIndex = selectedGuideIndex
        titleView.text = target.name
        statusView.text = target.source.ifBlank { "Favorites" }
        channelBadgeView.text = target.name.take(6).uppercase(Locale.US)
        bindProgramMeta(target)
        val mediaItemBuilder = MediaItem.Builder().setUri(Uri.parse(target.url))
        if (looksLikeTsStream(target.url)) {
            mediaItemBuilder.setMimeType(MimeTypes.VIDEO_MP2T)
        }
        player?.apply {
            setMediaItem(mediaItemBuilder.build())
            prepare()
            playWhenReady = true
        }
    }

    private fun bindProgramMeta(channel: GuideChannel?) {
        val now = Calendar.getInstance()
        val start = now.clone() as Calendar
        start.add(Calendar.MINUTE, -(now.get(Calendar.MINUTE) % 30))
        val end = start.clone() as Calendar
        end.add(Calendar.MINUTE, 30)
        val next = end.clone() as Calendar
        val formatter = SimpleDateFormat("h:mm a", Locale.US)
        nowTimeView.text = "${formatter.format(start.time)} – ${formatter.format(end.time)}"
        val activeName = channel?.name ?: "Live TV"
        titleView.text = activeName
        progressView.progress = (((now.timeInMillis - start.timeInMillis).toDouble() / (end.timeInMillis - start.timeInMillis).toDouble()) * 100).toInt().coerceIn(4, 96)
        nextView.text = "NEXT  ${formatter.format(next.time)}  ${activeName} Up Next"
    }

    private fun renderGuideOverlay() {
        val selected = channels.getOrNull(selectedGuideIndex)
        guideTitleView.text = selected?.name ?: "Live TV Guide"
        guideMetaView.text = selected?.let { "${it.source} • Instant tune enabled" } ?: "Browse channels while video keeps playing"
        guideHintView.text = "LEFT/RIGHT change channel instantly • UP/BACK close"
        guideInfoLogoView.text = (selected?.name ?: "TV").take(2).uppercase(Locale.US)

        guideList.removeAllViews()
        if (channels.isEmpty()) {
            guideList.addView(makeGuideCard("No guide data", false))
            return
        }
        val start = (selectedGuideIndex - 2).coerceAtLeast(0)
        val end = (start + 5).coerceAtMost(channels.lastIndex)
        for (index in start..end) {
            val channel = channels[index]
            guideList.addView(makeGuideCard(channel.name, index == selectedGuideIndex))
        }
        guideScroller.post {
            val focusedChild = guideList.getChildAt((selectedGuideIndex - start).coerceAtLeast(0))
            if (focusedChild != null) {
                val scroll = (focusedChild.left - dp(24)).coerceAtLeast(0)
                guideScroller.smoothScrollTo(scroll, 0)
            }
        }
    }

    private fun makeGuideCard(title: String, selected: Boolean): View {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM or Gravity.START
            background = getDrawable(if (selected) R.drawable.focus_ring_pill_pulse else R.drawable.pill_dark)
            setPadding(dp(18), dp(16), dp(18), dp(16))
            layoutParams = LinearLayout.LayoutParams(dp(240), dp(112)).apply {
                rightMargin = dp(14)
            }
        }
        val titleView = TextView(this).apply {
            text = title
            setTextColor(0xFFFFFFFF.toInt())
            textSize = if (selected) 20f else 17f
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        val subtitleView = TextView(this).apply {
            text = "Live now"
            setTextColor(0xFFC8D1DC.toInt())
            textSize = 13f
        }
        container.addView(subtitleView)
        container.addView(titleView)
        return container
    }

    private fun updateClockViews() {
        val formatter = SimpleDateFormat("h:mm a", Locale.US)
        val value = formatter.format(Date())
        clockView.text = value
        guideClockView.text = value
    }

    private fun decodeChannels(json: String?): List<GuideChannel> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(json)
            mutableListOf<GuideChannel>().apply {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    add(
                        GuideChannel(
                            name = obj.optString("name"),
                            url = obj.optString("url"),
                            source = obj.optString("source"),
                            debug = obj.optString("debug")
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun looksLikeTsStream(url: String): Boolean {
        val lower = url.lowercase(Locale.US)
        return lower.contains("format=ts") || lower.endsWith(".ts") || lower.endsWith(".mpg")
    }

    override fun onStart() {
        super.onStart()
        player?.playWhenReady = true
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        overlayHandler.removeCallbacksAndMessages(null)
        playerView.player = null
        player?.release()
        player = null
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    data class GuideChannel(
        val name: String,
        val url: String,
        val source: String,
        val debug: String
    )

    companion object {
        const val EXTRA_STREAM_URL = "stream_url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_SOURCE_LABEL = "source_label"
        const val EXTRA_DEBUG_LABEL = "debug_label"
        const val EXTRA_MEDIA_LOGO_URL = "media_logo_url"
        const val EXTRA_MEDIA_POSTER_URL = "media_poster_url"
        const val EXTRA_MEDIA_BACKDROP_URL = "media_backdrop_url"
        const val EXTRA_MEDIA_META = "media_meta"
        const val EXTRA_CHANNELS_JSON = "channels_json"
        const val EXTRA_CHANNEL_INDEX = "channel_index"
    }
}
