package com.channelsdebrid.tv.playback

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.channelsdebrid.tv.R
import com.channelsdebrid.tv.settings.SettingsRepository
import java.util.Locale
import java.util.concurrent.Executors

class SourceSelectionActivity : AppCompatActivity() {

    private val executor = Executors.newSingleThreadExecutor()
    private val pipelineResolver = StreamingPipelineResolver()
    private lateinit var settingsRepository: SettingsRepository
    private lateinit var titleView: TextView
    private lateinit var metaView: TextView
    private lateinit var statusView: TextView
    private lateinit var emptyView: TextView
    private lateinit var heroLogoView: ImageView
    private lateinit var recyclerView: RecyclerView

    private var titleText: String = ""
    private var externalId: String = ""
    private var mediaType: String = "movie"
    private var posterUrl: String? = null
    private var backdropUrl: String? = null
    private var logoUrl: String? = null
    private var itemMeta: String? = null
    private var candidates: List<StreamingPipelineResolver.StreamCandidate> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_source_selection)

        settingsRepository = SettingsRepository(this)
        titleView = findViewById(R.id.sourceTitle)
        metaView = findViewById(R.id.sourceMeta)
        statusView = findViewById(R.id.sourceStatus)
        emptyView = findViewById(R.id.sourceEmpty)
        heroLogoView = findViewById(R.id.sourceHeroLogo)
        recyclerView = findViewById(R.id.sourceList)
        recyclerView.layoutManager = LinearLayoutManager(this)

        titleText = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        externalId = intent.getStringExtra(EXTRA_EXTERNAL_ID).orEmpty()
        mediaType = intent.getStringExtra(EXTRA_MEDIA_TYPE).orEmpty().ifBlank { "movie" }
        posterUrl = intent.getStringExtra(EXTRA_POSTER_URL)
        backdropUrl = intent.getStringExtra(EXTRA_BACKDROP_URL)
        logoUrl = intent.getStringExtra(EXTRA_LOGO_URL)
        itemMeta = intent.getStringExtra(EXTRA_ITEM_META)

        titleView.text = titleText
        metaView.text = itemMeta ?: "Choose a link before playback"
        if (!logoUrl.isNullOrBlank()) {
            heroLogoView.visibility = View.VISIBLE
            Glide.with(this).load(logoUrl).into(heroLogoView)
        } else {
            heroLogoView.visibility = View.GONE
        }

        loadSources()
    }

    private fun loadSources() {
        val addons = settingsRepository.loadStremioAddons()
        val debrid = settingsRepository.loadDebrid()
        val playback = settingsRepository.loadPlayback()
        statusView.text = "Loading sources…"
        executor.execute {
            val loaded = pipelineResolver.listCandidates(externalId, mediaType, addons, playback)
            runOnUiThread {
                candidates = loaded
                if (loaded.isEmpty()) {
                    emptyView.visibility = View.VISIBLE
                    statusView.text = "No playable links found"
                } else {
                    emptyView.visibility = View.GONE
                    statusView.text = "${loaded.size} sources found"
                    recyclerView.adapter = SourceAdapter(loaded, debrid, playback)
                }
            }
        }
    }

    private inner class SourceAdapter(
        private val items: List<StreamingPipelineResolver.StreamCandidate>,
        private val debrid: com.channelsdebrid.tv.settings.DebridSettings,
        private val playback: com.channelsdebrid.tv.settings.PlaybackSettings
    ) : RecyclerView.Adapter<SourceHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SourceHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_source_option, parent, false)
            return SourceHolder(view)
        }
        override fun getItemCount(): Int = items.size
        override fun onBindViewHolder(holder: SourceHolder, position: Int) {
            val item = items[position]
            val quality = pipelineResolver.qualityLabel(item)
            val size = pipelineResolver.sizeLabel(item)
            holder.title.text = listOf(quality, size).filter { it.isNotBlank() }.joinToString(" • ").ifBlank { item.title }
            holder.subtitle.text = item.addonName
            holder.meta.text = item.title
            holder.itemView.setOnClickListener {
                statusView.text = "Resolving ${item.addonName}…"
                executor.execute {
                    val resolved = pipelineResolver.resolveCandidate(item, debrid, playback)
                    runOnUiThread {
                        if (resolved == null) {
                            statusView.text = "Failed to resolve source"
                            Toast.makeText(this@SourceSelectionActivity, "This source could not be resolved", Toast.LENGTH_LONG).show()
                        } else {
                            statusView.text = "Launching ${resolved.sourceLabel}"
                            startActivity(Intent(this@SourceSelectionActivity, PlayerActivity::class.java)
                                .putExtra(PlayerActivity.EXTRA_STREAM_URL, resolved.url)
                                .putExtra(PlayerActivity.EXTRA_TITLE, titleText)
                                .putExtra(PlayerActivity.EXTRA_SOURCE_LABEL, resolved.sourceLabel)
                                .putExtra(PlayerActivity.EXTRA_DEBUG_LABEL, resolved.debugLabel)
                                .putExtra(PlayerActivity.EXTRA_MEDIA_LOGO_URL, logoUrl)
                                .putExtra(PlayerActivity.EXTRA_MEDIA_POSTER_URL, posterUrl)
                                .putExtra(PlayerActivity.EXTRA_MEDIA_BACKDROP_URL, backdropUrl)
                                .putExtra(PlayerActivity.EXTRA_MEDIA_META, listOf(quality, size).filter { it.isNotBlank() }.joinToString(" • ").ifBlank { itemMeta.orEmpty() })
                            )
                        }
                    }
                }
            }
        }
    }

    private class SourceHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.sourceOptionTitle)
        val subtitle: TextView = view.findViewById(R.id.sourceOptionSubtitle)
        val meta: TextView = view.findViewById(R.id.sourceOptionMeta)
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_EXTERNAL_ID = "external_id"
        const val EXTRA_MEDIA_TYPE = "media_type"
        const val EXTRA_POSTER_URL = "poster_url"
        const val EXTRA_BACKDROP_URL = "backdrop_url"
        const val EXTRA_LOGO_URL = "logo_url"
        const val EXTRA_ITEM_META = "item_meta"
    }
}
