package com.channelsdebrid.tv

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import com.channelsdebrid.tv.settings.CatalogSettings
import com.channelsdebrid.tv.settings.ChannelsDvrSettings
import com.channelsdebrid.tv.settings.PlaybackSettings
import com.channelsdebrid.tv.settings.SettingsRepository
import com.channelsdebrid.tv.settings.StorageSettings
import com.channelsdebrid.tv.settings.StremioAddonSettings
import com.channelsdebrid.tv.settings.TmdbSettings
import com.channelsdebrid.tv.settings.TrailerSettings
import com.channelsdebrid.tv.settings.XtreamSettings

class SettingsActivity : AppCompatActivity() {
    private lateinit var repository: SettingsRepository

    private lateinit var backButton: Button
    private lateinit var cancelButton: Button
    private lateinit var saveButton: Button

    private lateinit var tmdbApiKeyInput: EditText
    private lateinit var tmdbRegionInput: EditText
    private lateinit var tmdbLanguageInput: EditText

    private lateinit var catalogTrendingMoviesSwitch: SwitchCompat
    private lateinit var catalogPopularMoviesSwitch: SwitchCompat
    private lateinit var catalogTrendingShowsSwitch: SwitchCompat
    private lateinit var catalogPopularShowsSwitch: SwitchCompat
    private lateinit var catalogPlatformSwitch: SwitchCompat
    private lateinit var catalogStremioSwitch: SwitchCompat

    private lateinit var stremioEnabledSwitch: SwitchCompat
    private lateinit var stremioNameInput: EditText
    private lateinit var stremioManifestInput: EditText

    private lateinit var channelsAutoDetectSwitch: SwitchCompat
    private lateinit var channelsBaseUrlInput: EditText
    private lateinit var channelsUsernameInput: EditText
    private lateinit var channelsPasswordInput: EditText

    private lateinit var xtreamEnabledSwitch: SwitchCompat
    private lateinit var xtreamServerInput: EditText
    private lateinit var xtreamUsernameInput: EditText
    private lateinit var xtreamPasswordInput: EditText

    private lateinit var storageTargetInput: AutoCompleteTextView
    private lateinit var storageUsbInput: EditText
    private lateinit var storageNasInput: EditText
    private lateinit var timeshiftMinutesInput: EditText
    private lateinit var movieCacheSwitch: SwitchCompat

    private lateinit var trailerEnabledSwitch: SwitchCompat
    private lateinit var trailerAutoplaySwitch: SwitchCompat
    private lateinit var trailerDelayInput: EditText
    private lateinit var trailerModeInput: AutoCompleteTextView

    private lateinit var frameRateSwitch: SwitchCompat
    private lateinit var autoPlayBestSwitch: SwitchCompat
    private lateinit var preferExternalSwitch: SwitchCompat
    private lateinit var timeshiftEnabledSwitch: SwitchCompat
    private lateinit var fileSizeLimitInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        repository = SettingsRepository(this)
        bindViews()

        val storageTargets = listOf("internal", "usb", "nas")
        storageTargetInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, storageTargets))
        trailerModeInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("center_modal", "fullscreen")))

        loadAll()
        backButton.setOnClickListener { finish() }
        cancelButton.setOnClickListener { finish() }
        saveButton.setOnClickListener {
            saveAll()
            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun bindViews() {
        backButton = findViewById(R.id.backButton)
        cancelButton = findViewById(R.id.cancelButton)
        saveButton = findViewById(R.id.saveButton)

        tmdbApiKeyInput = findViewById(R.id.tmdbApiKeyInput)
        tmdbRegionInput = findViewById(R.id.tmdbRegionInput)
        tmdbLanguageInput = findViewById(R.id.tmdbLanguageInput)

        catalogTrendingMoviesSwitch = findViewById(R.id.catalogTrendingMoviesSwitch)
        catalogPopularMoviesSwitch = findViewById(R.id.catalogPopularMoviesSwitch)
        catalogTrendingShowsSwitch = findViewById(R.id.catalogTrendingShowsSwitch)
        catalogPopularShowsSwitch = findViewById(R.id.catalogPopularShowsSwitch)
        catalogPlatformSwitch = findViewById(R.id.catalogPlatformSwitch)
        catalogStremioSwitch = findViewById(R.id.catalogStremioSwitch)

        stremioEnabledSwitch = findViewById(R.id.stremioEnabledSwitch)
        stremioNameInput = findViewById(R.id.stremioNameInput)
        stremioManifestInput = findViewById(R.id.stremioManifestInput)

        channelsAutoDetectSwitch = findViewById(R.id.channelsAutoDetectSwitch)
        channelsBaseUrlInput = findViewById(R.id.channelsBaseUrlInput)
        channelsUsernameInput = findViewById(R.id.channelsUsernameInput)
        channelsPasswordInput = findViewById(R.id.channelsPasswordInput)

        xtreamEnabledSwitch = findViewById(R.id.xtreamEnabledSwitch)
        xtreamServerInput = findViewById(R.id.xtreamServerInput)
        xtreamUsernameInput = findViewById(R.id.xtreamUsernameInput)
        xtreamPasswordInput = findViewById(R.id.xtreamPasswordInput)

        storageTargetInput = findViewById(R.id.storageTargetInput)
        storageUsbInput = findViewById(R.id.storageUsbInput)
        storageNasInput = findViewById(R.id.storageNasInput)
        timeshiftMinutesInput = findViewById(R.id.timeshiftMinutesInput)
        movieCacheSwitch = findViewById(R.id.movieCacheSwitch)

        trailerEnabledSwitch = findViewById(R.id.trailerEnabledSwitch)
        trailerAutoplaySwitch = findViewById(R.id.trailerAutoplaySwitch)
        trailerDelayInput = findViewById(R.id.trailerDelayInput)
        trailerModeInput = findViewById(R.id.trailerModeInput)

        frameRateSwitch = findViewById(R.id.frameRateSwitch)
        autoPlayBestSwitch = findViewById(R.id.autoPlayBestSwitch)
        preferExternalSwitch = findViewById(R.id.preferExternalSwitch)
        timeshiftEnabledSwitch = findViewById(R.id.timeshiftEnabledSwitch)
        fileSizeLimitInput = findViewById(R.id.fileSizeLimitInput)
    }

    private fun loadAll() {
        val tmdb = repository.loadTmdb()
        tmdbApiKeyInput.setText(tmdb.apiKey)
        tmdbRegionInput.setText(tmdb.region)
        tmdbLanguageInput.setText(tmdb.language)

        val catalogs = repository.loadCatalogs()
        catalogTrendingMoviesSwitch.isChecked = catalogs.trendingMoviesEnabled
        catalogPopularMoviesSwitch.isChecked = catalogs.popularMoviesEnabled
        catalogTrendingShowsSwitch.isChecked = catalogs.trendingShowsEnabled
        catalogPopularShowsSwitch.isChecked = catalogs.popularShowsEnabled
        catalogPlatformSwitch.isChecked = catalogs.platformRowsEnabled
        catalogStremioSwitch.isChecked = catalogs.stremioCatalogRowsEnabled

        val addon = repository.loadPrimaryAddon()
        stremioEnabledSwitch.isChecked = addon.enabled
        stremioNameInput.setText(addon.name)
        stremioManifestInput.setText(addon.manifestUrl)

        val dvr = repository.loadChannelsDvr()
        channelsAutoDetectSwitch.isChecked = dvr.autoDetect
        channelsBaseUrlInput.setText(dvr.baseUrl)
        channelsUsernameInput.setText(dvr.username)
        channelsPasswordInput.setText(dvr.password)

        val xtream = repository.loadXtream()
        xtreamEnabledSwitch.isChecked = xtream.enabled
        xtreamServerInput.setText(xtream.server)
        xtreamUsernameInput.setText(xtream.username)
        xtreamPasswordInput.setText(xtream.password)

        val storage = repository.loadStorage()
        storageTargetInput.setText(storage.preferredTarget, false)
        storageUsbInput.setText(storage.usbPath)
        storageNasInput.setText(storage.nasPath)
        timeshiftMinutesInput.setText(storage.timeshiftMinutes.toString())
        movieCacheSwitch.isChecked = storage.movieCacheEnabled

        val trailers = repository.loadTrailers()
        trailerEnabledSwitch.isChecked = trailers.enabled
        trailerAutoplaySwitch.isChecked = trailers.autoplayOnFocus
        trailerDelayInput.setText(trailers.autoplayDelayMs.toString())
        trailerModeInput.setText(trailers.popupMode, false)

        val playback = repository.loadPlayback()
        frameRateSwitch.isChecked = playback.frameRateMatching
        autoPlayBestSwitch.isChecked = playback.autoPlayBestStream
        preferExternalSwitch.isChecked = playback.preferExternalStorageForCache
        timeshiftEnabledSwitch.isChecked = playback.timeshiftEnabled
        fileSizeLimitInput.setText(playback.fileSizeLimitGb.toString())
    }

    private fun saveAll() {
        repository.saveTmdb(
            TmdbSettings(
                apiKey = tmdbApiKeyInput.text.toString().trim(),
                region = tmdbRegionInput.text.toString().trim().ifEmpty { "US" },
                language = tmdbLanguageInput.text.toString().trim().ifEmpty { "en-US" }
            )
        )

        repository.saveCatalogs(
            CatalogSettings(
                trendingMoviesEnabled = catalogTrendingMoviesSwitch.isChecked,
                popularMoviesEnabled = catalogPopularMoviesSwitch.isChecked,
                trendingShowsEnabled = catalogTrendingShowsSwitch.isChecked,
                popularShowsEnabled = catalogPopularShowsSwitch.isChecked,
                platformRowsEnabled = catalogPlatformSwitch.isChecked,
                stremioCatalogRowsEnabled = catalogStremioSwitch.isChecked
            )
        )

        repository.savePrimaryAddon(
            StremioAddonSettings(
                id = "primary",
                name = stremioNameInput.text.toString().trim().ifEmpty { "Primary Addon" },
                manifestUrl = stremioManifestInput.text.toString().trim(),
                enabled = stremioEnabledSwitch.isChecked
            )
        )

        repository.saveChannelsDvr(
            ChannelsDvrSettings(
                autoDetect = channelsAutoDetectSwitch.isChecked,
                baseUrl = channelsBaseUrlInput.text.toString().trim(),
                username = channelsUsernameInput.text.toString().trim(),
                password = channelsPasswordInput.text.toString().trim()
            )
        )

        repository.saveXtream(
            XtreamSettings(
                server = xtreamServerInput.text.toString().trim(),
                username = xtreamUsernameInput.text.toString().trim(),
                password = xtreamPasswordInput.text.toString().trim(),
                enabled = xtreamEnabledSwitch.isChecked
            )
        )

        repository.saveStorage(
            StorageSettings(
                preferredTarget = storageTargetInput.text.toString().trim().ifEmpty { "internal" },
                usbPath = storageUsbInput.text.toString().trim(),
                nasPath = storageNasInput.text.toString().trim(),
                timeshiftMinutes = timeshiftMinutesInput.text.toString().toIntOrNull() ?: 90,
                movieCacheEnabled = movieCacheSwitch.isChecked
            )
        )

        repository.saveTrailers(
            TrailerSettings(
                enabled = trailerEnabledSwitch.isChecked,
                autoplayOnFocus = trailerAutoplaySwitch.isChecked,
                autoplayDelayMs = trailerDelayInput.text.toString().toLongOrNull() ?: 1500L,
                popupMode = trailerModeInput.text.toString().trim().ifEmpty { "center_modal" }
            )
        )

        repository.savePlayback(
            PlaybackSettings(
                frameRateMatching = frameRateSwitch.isChecked,
                preferExternalStorageForCache = preferExternalSwitch.isChecked,
                timeshiftEnabled = timeshiftEnabledSwitch.isChecked,
                autoPlayBestStream = autoPlayBestSwitch.isChecked,
                fileSizeLimitGb = fileSizeLimitInput.text.toString().toIntOrNull() ?: 40
            )
        )
    }
}
