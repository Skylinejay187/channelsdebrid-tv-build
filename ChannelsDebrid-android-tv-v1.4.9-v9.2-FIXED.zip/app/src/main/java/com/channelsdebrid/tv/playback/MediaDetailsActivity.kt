package com.channelsdebrid.tv.playback

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView
import com.bumptech.glide.Glide
import com.channelsdebrid.tv.R
import com.channelsdebrid.tv.settings.SettingsRepository
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MediaDetailsActivity : AppCompatActivity() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val trailerExecutor = Executors.newSingleThreadExecutor()
    private var backgroundTrailerRunnable: Runnable? = null
    private var backgroundTrailerPlayer: ExoPlayer? = null
    private lateinit var settingsRepository: SettingsRepository
    private lateinit var trailerPlayerView: PlayerView
    private lateinit var popupTrailerPlayerView: PlayerView
    private lateinit var trailerMuteButton: Button
    private lateinit var playTrailerButton: Button
    private lateinit var trailerPopupOverlay: FrameLayout
    private lateinit var trailerLoadingText: TextView
    private var trailerMuted = true
    private var trailerRequestVersion = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_media_details)
        settingsRepository = SettingsRepository(this)
        trailerPlayerView = findViewById(R.id.detailsTrailerPlayer)
        popupTrailerPlayerView = findViewById(R.id.detailsTrailerPopupPlayer)
        trailerMuteButton = findViewById(R.id.detailsTrailerMute)
        playTrailerButton = findViewById(R.id.detailsPlayTrailer)
        trailerPopupOverlay = findViewById(R.id.detailsTrailerPopupOverlay)
        trailerLoadingText = findViewById(R.id.detailsTrailerLoading)
        trailerPlayerView.useController = false
        popupTrailerPlayerView.useController = false
        refreshTrailerMuteButton()
        trailerMuteButton.setOnClickListener { toggleTrailerMute() }
        findViewById<TextView>(R.id.detailsTrailerPopupClose).setOnClickListener { closeTrailerPopup() }

        val backdrop = intent.getStringExtra(EXTRA_BACKDROP_URL).orEmpty()
        val logo = intent.getStringExtra(EXTRA_LOGO_URL).orEmpty()
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val meta = intent.getStringExtra(EXTRA_META_LINE).orEmpty()
        val desc = intent.getStringExtra(EXTRA_DESC).orEmpty()
        val poster = intent.getStringExtra(EXTRA_POSTER_URL).orEmpty()
        val externalId = intent.getStringExtra(EXTRA_EXTERNAL_ID).orEmpty()
        val mediaType = intent.getStringExtra(EXTRA_MEDIA_TYPE).orEmpty().ifBlank { "movie" }

        Glide.with(this).load(backdrop.ifBlank { poster }).centerCrop().into(findViewById<ImageView>(R.id.detailsBackdrop))

        val logoView = findViewById<ImageView>(R.id.detailsLogo)
        val titleView = findViewById<TextView>(R.id.detailsTitle)
        if (logo.isNotBlank()) {
            Glide.with(this).load(logo).fitCenter().into(logoView)
        } else {
            logoView.visibility = View.GONE
            titleView.text = title
            titleView.visibility = TextView.VISIBLE
        }

        findViewById<TextView>(R.id.detailsMeta).text = meta
        findViewById<TextView>(R.id.detailsDesc).text = desc

        val favoriteButton = findViewById<Button>(R.id.detailsFavorite)
        val favoriteKey = "favorite_${mediaType}_${externalId.ifBlank { title }}"
        val prefs = getSharedPreferences("debrid_channels_favorites", MODE_PRIVATE)
        fun refreshFavoriteButton() {
            favoriteButton.text = if (prefs.getBoolean(favoriteKey, false)) "Favorited" else "Add Favorite"
        }
        refreshFavoriteButton()
        favoriteButton.setOnClickListener {
            val next = !prefs.getBoolean(favoriteKey, false)
            prefs.edit().putBoolean(favoriteKey, next).apply()
            refreshFavoriteButton()
            Toast.makeText(this, if (next) "Added to favorites" else "Removed from favorites", Toast.LENGTH_SHORT).show()
        }

        buildCastRow()
        buildRelatedRow(title, poster.ifBlank { backdrop })

        val trailerSettings = settingsRepository.loadTrailers()
        val trailerLocation = trailerSettings.playbackLocation.lowercase()
        val detailsTrailersAllowed = trailerSettings.enabled && trailerLocation != "off" && trailerLocation != "hero"
        val popupDetailTrailer = detailsTrailersAllowed && (trailerSettings.popupMode.equals("popup_button", true) ||
            trailerSettings.popupMode.equals("popup", true) ||
            trailerSettings.popupMode.equals("button_popup", true))
        if (popupDetailTrailer) {
            playTrailerButton.visibility = View.VISIBLE
            trailerMuteButton.visibility = View.GONE
            playTrailerButton.setOnClickListener { showTrailerPopup(title, meta, mediaType, externalId) }
        } else if (detailsTrailersAllowed) {
            playTrailerButton.visibility = View.GONE
            trailerMuteButton.visibility = View.VISIBLE
            scheduleBackgroundTrailer(title, meta, mediaType, externalId)
        } else {
            playTrailerButton.visibility = View.GONE
            trailerMuteButton.visibility = View.GONE
        }

        val detailsPlayButton = findViewById<Button>(R.id.detailsPlay)
        var effectiveMediaType = mediaType
        var effectiveExternalId = externalId
        var treatAsSeries = isSeriesMediaType(effectiveMediaType)
        fun refreshPlayButton() {
            detailsPlayButton.text = if (treatAsSeries) "Browse Episodes" else "Play"
        }
        refreshPlayButton()

        // Some Stremio/backend catalogs mark TV metadata as movie/featured or leave the type blank.
        // Probe Cinemeta by title and upgrade the details page to episode browsing when the title is a real series.
        if (!treatAsSeries && title.isNotBlank()) {
            trailerExecutor.execute {
                val resolvedSeriesId = resolveSeriesIdFromCinemeta(title)
                if (resolvedSeriesId.isNotBlank()) {
                    runOnUiThread {
                        treatAsSeries = true
                        effectiveMediaType = "series"
                        if (effectiveExternalId.isBlank() || !effectiveExternalId.startsWith("tt")) {
                            effectiveExternalId = resolvedSeriesId
                        }
                        refreshPlayButton()
                    }
                }
            }
        }

        detailsPlayButton.setOnClickListener {
            stopBackgroundTrailer()
            if (treatAsSeries) {
                startActivity(Intent(this, SeasonEpisodeActivity::class.java).apply {
                    putExtra(SeasonEpisodeActivity.EXTRA_TITLE, title)
                    putExtra(SeasonEpisodeActivity.EXTRA_MEDIA_TYPE, "series")
                    putExtra(SeasonEpisodeActivity.EXTRA_EXTERNAL_ID, effectiveExternalId)
                    putExtra(SeasonEpisodeActivity.EXTRA_POSTER_URL, poster)
                    putExtra(SeasonEpisodeActivity.EXTRA_BACKDROP_URL, backdrop.ifBlank { poster })
                    putExtra(SeasonEpisodeActivity.EXTRA_LOGO_URL, logo)
                    putExtra(SeasonEpisodeActivity.EXTRA_ITEM_META, meta)
                    putExtra(SeasonEpisodeActivity.EXTRA_DESC, desc)
                })
            } else {
                startActivity(Intent(this, SourceSelectionActivity::class.java).apply {
                    putExtra(SourceSelectionActivity.EXTRA_TITLE, title)
                    putExtra(SourceSelectionActivity.EXTRA_MEDIA_TYPE, effectiveMediaType)
                    putExtra(SourceSelectionActivity.EXTRA_EXTERNAL_ID, effectiveExternalId)
                    putExtra(SourceSelectionActivity.EXTRA_ARTWORK_URL, backdrop.ifBlank { poster })
                    putExtra(SourceSelectionActivity.EXTRA_BACKDROP_URL, backdrop.ifBlank { poster })
                    putExtra(SourceSelectionActivity.EXTRA_LOGO_URL, logo)
                    putExtra(SourceSelectionActivity.EXTRA_POSTER_URL, poster)
                    putExtra(SourceSelectionActivity.EXTRA_META_LINE, meta)
                    putExtra(SourceSelectionActivity.EXTRA_DESC, desc)
                })
            }
        }
    }


    private fun isSeriesMediaType(mediaType: String): Boolean {
        return mediaType.equals("series", ignoreCase = true) ||
            mediaType.equals("show", ignoreCase = true) ||
            mediaType.equals("tv", ignoreCase = true)
    }

    private fun resolveSeriesIdFromCinemeta(queryTitle: String): String {
        val cleanedTitle = queryTitle.trim()
        if (cleanedTitle.isBlank()) return ""
        return runCatching {
            val encoded = URLEncoder.encode(cleanedTitle, "UTF-8").replace("+", "%20")
            val searchUrls = listOf(
                "https://v3-cinemeta.strem.io/catalog/series/top/search=$encoded.json",
                "https://v3-cinemeta.strem.io/catalog/series/popular/search=$encoded.json",
                "https://v3-cinemeta.strem.io/catalog/series/imdbRating/search=$encoded.json"
            )
            for (urlValue in searchUrls) {
                val body = fetchSmallJsonBody(urlValue)
                val metas = JSONObject(body).optJSONArray("metas") ?: continue
                for (i in 0 until metas.length()) {
                    val meta = metas.optJSONObject(i) ?: continue
                    val name = meta.optString("name").ifBlank { meta.optString("title") }
                    val id = meta.optString("id").trim()
                    val imdbId = meta.optString("imdb_id").trim().ifBlank { meta.optString("imdbId").trim() }
                    val candidate = imdbId.ifBlank { id }
                    if (candidate.isNotBlank() && titlesLooselyMatch(cleanedTitle, name)) return@runCatching candidate
                }
            }
            ""
        }.getOrDefault("")
    }

    private fun fetchSmallJsonBody(urlValue: String): String {
        val connection = (URL(urlValue).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 7000
            readTimeout = 10000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "ChannelsDebridTV/1.0")
        }
        return try {
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        } finally {
            connection.disconnect()
        }
    }

    private fun titlesLooselyMatch(a: String, b: String): Boolean {
        fun normalize(value: String): String = value.lowercase(java.util.Locale.US)
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()
        val left = normalize(a)
        val right = normalize(b)
        if (left.isBlank() || right.isBlank()) return false
        return left == right || left.contains(right) || right.contains(left)
    }

    private fun scheduleBackgroundTrailer(title: String, meta: String, mediaType: String, externalId: String) {
        val settings = settingsRepository.loadTrailers()
        if (!settings.enabled || !settings.backgroundAutoplayEnabled || title.isBlank()) return
        val delay = settings.backgroundAutoplayDelayMs.coerceIn(0L, 60000L)
        val requestId = ++trailerRequestVersion
        backgroundTrailerRunnable = Runnable {
            trailerExecutor.execute {
                val stream = resolveBackendTrailerStream(title, meta, mediaType, externalId, settings.prefer4k)
                mainHandler.post {
                    if (requestId == trailerRequestVersion && !isFinishing && !isDestroyed && stream?.playbackUrl?.isNotBlank() == true) {
                        startBackgroundTrailer(stream)
                    }
                }
            }
        }
        mainHandler.postDelayed(backgroundTrailerRunnable!!, delay)
    }

    private fun showTrailerPopup(title: String, meta: String, mediaType: String, externalId: String) {
        val settings = settingsRepository.loadTrailers()
        if (!settings.enabled || title.isBlank()) return
        stopBackgroundTrailer()
        trailerPopupOverlay.visibility = View.VISIBLE
        trailerPopupOverlay.alpha = 0f
        trailerPopupOverlay.animate().alpha(1f).setDuration(160L).start()
        trailerPopupOverlay.requestFocus()
        trailerMuteButton.visibility = View.VISIBLE
        trailerLoadingText.text = "Loading trailer…"
        trailerLoadingText.visibility = View.VISIBLE
        val requestId = ++trailerRequestVersion
        trailerExecutor.execute {
            val stream = resolveBackendTrailerStream(title, meta, mediaType, externalId, settings.prefer4k)
            mainHandler.post {
                if (requestId != trailerRequestVersion || isFinishing || isDestroyed) return@post
                if (stream?.playbackUrl.isNullOrBlank()) {
                    trailerLoadingText.text = "Trailer unavailable"
                    Toast.makeText(this, "Trailer unavailable", Toast.LENGTH_SHORT).show()
                } else {
                    startTrailerStream(stream!!, popupTrailerPlayerView, repeat = false)
                }
            }
        }
    }

    private fun resolveBackendTrailerStream(title: String, meta: String, mediaType: String, externalId: String, prefer4k: Boolean): TrailerStream? {
        return runCatching {
            val liveBackend = settingsRepository.loadLiveBackend()
            val backendBase = liveBackend.baseUrl.ifBlank { "http://192.168.100.55:8181" }.trimEnd('/')
            val encodedTitle = URLEncoder.encode(title.trim(), "UTF-8")
            val year = Regex("(19|20)\\d{2}").find(meta)?.value.orEmpty()
            val requestedQuality = if (prefer4k) "2160p,1080p" else "1080p"
            val query = buildString {
                append("title=").append(encodedTitle)
                append("&year=").append(URLEncoder.encode(year, "UTF-8"))
                append("&type=").append(URLEncoder.encode(mediaType.ifBlank { "movie" }, "UTF-8"))
                append("&externalId=").append(URLEncoder.encode(externalId, "UTF-8"))
                append("&quality=").append(URLEncoder.encode(requestedQuality, "UTF-8"))
                append("&prefer4k=").append(prefer4k)
                append("&strictTitle=true&officialOnly=true")
            }
            val url = URL("$backendBase/trailers/resolve?$query")
            val connection = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 12000
                readTimeout = 25000
                requestMethod = "GET"
                setRequestProperty("Accept", "application/json")
            }
            val response = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            response?.bufferedReader()?.use { reader ->
                val json = JSONObject(reader.readText())
                if (!json.optBoolean("ok", false)) return null
                val trailer = json.optJSONObject("trailer") ?: return null
                val playbackUrl = trailer.optString("playbackUrl")
                val resolvedTitle = trailer.optString("title")
                if (playbackUrl.isBlank()) return null
                if (resolvedTitle.isNotBlank() && !looksLikeTrailerForTitle(resolvedTitle, title)) return null
                TrailerStream(
                    playbackUrl = playbackUrl,
                    mimeType = trailer.optString("mimeType"),
                    quality = trailer.optString("quality"),
                    allow4k = prefer4k
                )
            }
        }.getOrNull()
    }

    private fun looksLikeTrailerForTitle(candidate: String, expected: String): Boolean {
        fun normalize(value: String): Set<String> = value.lowercase()
            .replace(Regex("[^a-z0-9 ]"), " ")
            .split(Regex("\\s+"))
            .filter { it.length > 2 && it !in setOf("the", "and", "official", "trailer", "teaser", "clip", "movie", "series", "season") }
            .toSet()
        val expectedWords = normalize(expected)
        if (expectedWords.isEmpty()) return true
        val candidateWords = normalize(candidate)
        return expectedWords.count { it in candidateWords } >= minOf(2, expectedWords.size)
    }

    private fun startBackgroundTrailer(stream: TrailerStream) {
        startTrailerStream(stream, trailerPlayerView, repeat = true)
        trailerPlayerView.visibility = View.VISIBLE
        trailerPlayerView.animate().alpha(1f).setDuration(350L).start()
    }

    private fun startTrailerStream(stream: TrailerStream, playerView: PlayerView, repeat: Boolean) {
        releaseTrailerPlayer()
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Android TV; ChannelsDebrid)")
            .setAllowCrossProtocolRedirects(true)
        val mediaSourceFactory = DefaultMediaSourceFactory(this).setDataSourceFactory(httpFactory)
        val trackSelector = DefaultTrackSelector(this).apply {
            setParameters(
                buildUponParameters()
                    .setMaxVideoSize(if (stream.allow4k) 3840 else 1920, if (stream.allow4k) 2160 else 1080)
                    .setMinVideoSize(1280, 720)
                    .setForceHighestSupportedBitrate(false)
            )
        }
        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(mediaSourceFactory)
            .setTrackSelector(trackSelector)
            .build()
        backgroundTrailerPlayer = player
        playerView.player = player
        val mediaItemBuilder = MediaItem.Builder().setUri(stream.playbackUrl)
        if (stream.mimeType.contains("dash", ignoreCase = true) || stream.playbackUrl.contains(".mpd", ignoreCase = true)) {
            mediaItemBuilder.setMimeType(MimeTypes.APPLICATION_MPD)
        } else if (stream.mimeType.contains("hls", ignoreCase = true) || stream.playbackUrl.contains(".m3u8", ignoreCase = true)) {
            mediaItemBuilder.setMimeType(MimeTypes.APPLICATION_M3U8)
        }
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) trailerLoadingText.visibility = View.GONE
                if (playbackState == Player.STATE_ENDED && !repeat) closeTrailerPopup()
            }
        })
        player.setMediaItem(mediaItemBuilder.build())
        player.repeatMode = if (repeat) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        player.volume = if (trailerMuted) 0f else 1f
        player.prepare()
        player.playWhenReady = true
    }

    private fun toggleTrailerMute() {
        trailerMuted = !trailerMuted
        backgroundTrailerPlayer?.volume = if (trailerMuted) 0f else 1f
        refreshTrailerMuteButton()
    }

    private fun refreshTrailerMuteButton() {
        if (::trailerMuteButton.isInitialized) {
            trailerMuteButton.text = if (trailerMuted) "Unmute Trailer" else "Mute Trailer"
        }
    }

    private fun closeTrailerPopup() {
        trailerRequestVersion++
        releaseTrailerPlayer()
        popupTrailerPlayerView.player = null
        trailerPopupOverlay.animate().cancel()
        trailerPopupOverlay.animate().alpha(0f).setDuration(140L).withEndAction {
            trailerPopupOverlay.visibility = View.GONE
            if (settingsRepository.loadTrailers().popupMode.contains("popup", ignoreCase = true)) {
                trailerMuteButton.visibility = View.GONE
            }
        }.start()
    }

    private fun stopBackgroundTrailer() {
        trailerRequestVersion++
        backgroundTrailerRunnable?.let(mainHandler::removeCallbacks)
        backgroundTrailerRunnable = null
        trailerPlayerView.animate().cancel()
        trailerPlayerView.alpha = 0f
        trailerPlayerView.visibility = View.GONE
        trailerPlayerView.player = null
        popupTrailerPlayerView.player = null
        releaseTrailerPlayer()
    }

    private fun releaseTrailerPlayer() {
        backgroundTrailerPlayer?.release()
        backgroundTrailerPlayer = null
    }

    override fun onStop() {
        super.onStop()
        closeTrailerPopup()
        stopBackgroundTrailer()
    }

    override fun onDestroy() {
        stopBackgroundTrailer()
        trailerExecutor.shutdownNow()
        super.onDestroy()
    }

    private fun buildCastRow() {
        val row = findViewById<LinearLayout>(R.id.detailsCastRow)
        row.removeAllViews()
        listOf("Cast", "Director", "Creator", "Similar Tone").forEach { label ->
            val chip = TextView(this).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 15f
                gravity = Gravity.CENTER
                setPadding(22, 0, 22, 0)
                background = makePillDrawable(0x33FFFFFF, 0x33FFFFFF)
            }
            row.addView(chip, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 58).apply { marginEnd = 12 })
        }
    }

    private fun buildRelatedRow(title: String, artwork: String) {
        val row = findViewById<LinearLayout>(R.id.detailsRelatedRow)
        row.removeAllViews()
        repeat(4) { index ->
            val frame = FrameLayout(this).apply {
                background = makePillDrawable(0x22000000, 0x44FFFFFF)
                isFocusable = true
            }
            val image = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            frame.addView(image, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            if (artwork.isNotBlank()) Glide.with(this).load(artwork).centerCrop().into(image)
            val label = TextView(this).apply {
                text = if (index == 0) title else "Related"
                setTextColor(Color.WHITE)
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.BOTTOM or Gravity.START
                setPadding(12, 0, 12, 12)
            }
            frame.addView(label, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            row.addView(frame, LinearLayout.LayoutParams(150, 92).apply { marginEnd = 14 })
        }
    }

    private fun makePillDrawable(fill: Int, stroke: Int): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = 18f
            setColor(fill)
            setStroke(1, stroke)
        }
    }

    private data class TrailerStream(
        val playbackUrl: String,
        val mimeType: String,
        val quality: String,
        val allow4k: Boolean = false
    )

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_META_LINE = "meta_line"
        const val EXTRA_DESC = "desc"
        const val EXTRA_MEDIA_TYPE = "media_type"
        const val EXTRA_EXTERNAL_ID = "external_id"
        const val EXTRA_POSTER_URL = "poster_url"
        const val EXTRA_BACKDROP_URL = "backdrop_url"
        const val EXTRA_LOGO_URL = "logo_url"
    }
}
