package com.channelsdebrid.tv

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.util.Log
import android.view.View
import android.view.ViewGroup

/**
 * TV/projector safe-area helper.
 * Applies extra padding only on Leanback/TV/projector style devices so tablet layouts keep their full-size positioning.
 */
object TvSafeAreaHelper {
    private const val TAG = "DebridChannels"

    data class InsetsDp(val left: Int = 48, val top: Int = 44, val right: Int = 48, val bottom: Int = 64)

    fun isTvLike(context: Context): Boolean {
        val pm = context.packageManager
        val uiMode = context.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
        val modeType = context.resources.configuration.uiMode and Configuration.UI_MODE_TYPE_MASK
        val leanback = pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK) || pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK_ONLY)
        val television = modeType == Configuration.UI_MODE_TYPE_TELEVISION || uiMode?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION
        val manufacturer = Build.MANUFACTURER.orEmpty().lowercase()
        val model = Build.MODEL.orEmpty().lowercase()
        val projector = manufacturer.contains("xgimi") || model.contains("xgimi") || model.contains("projector") || model.contains("galileo")
        return leanback || television || projector
    }

    fun applyIfTv(context: Context, view: View?, screenName: String, insets: InsetsDp = InsetsDp()) {
        if (view == null) return
        val tv = isTvLike(context)
        Log.i(TAG, "TV_SAFE_AREA_MODE: screen=$screenName tvLike=$tv manufacturer=${Build.MANUFACTURER} model=${Build.MODEL}")
        if (!tv) return
        val l = view.paddingLeft + dp(context, insets.left)
        val t = view.paddingTop + dp(context, insets.top)
        val r = view.paddingRight + dp(context, insets.right)
        val b = view.paddingBottom + dp(context, insets.bottom)
        view.setPadding(l, t, r, b)
        if (view is ViewGroup) {
            view.clipToPadding = false
            view.clipChildren = false
        }
    }

    private fun dp(context: Context, value: Int): Int = (value * context.resources.displayMetrics.density + 0.5f).toInt()
}
