# Debrid Channels Android TV — v0.1.6 Old App Stream Parity

Clean rewrite/consolidation from the stable v0.0.1 visual baseline.

Version: 0.1.6
Marker: DC_V0_1_6_OLD_APP_STREAM_PARITY_ACTIVE

Core VOD flow:
Home -> Media Info -> Styled Stream List -> Select Stream -> Media3 ExoPlayer + cinematic overlay.
