package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.1.6 OLD APP STREAM PARITY";
    public static final String LOG_MARKER = "DC_V0_1_6_OLD_APP_STREAM_PARITY_ACTIVE";
    private BuildMarkers() {}
}
