package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.8.5 Live TV Final Polish";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.8.5_livetv_final_polish_preview_smooth_logo_clean_base";
}
