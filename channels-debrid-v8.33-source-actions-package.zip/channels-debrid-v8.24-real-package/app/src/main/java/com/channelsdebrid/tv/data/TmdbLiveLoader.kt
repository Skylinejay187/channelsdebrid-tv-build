package com.channelsdebrid.tv.data

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class TmdbLiveLoader {

    data class LiveCatalogItem(
        val title: String,
        val meta: String,
        val desc: String,
        val badge: String,
        val brand: String,
        val footer: String,
        val progress: Float
    )

    data class LiveRow(
        val title: String,
        val subtitle: String,
        val items: List<LiveCatalogItem>
    )

    fun loadRows(apiKey: String, region: String, language: String, enabledKeys: List<String>, limit: Int = 24): List<LiveRow> {
        if (apiKey.isBlank()) return emptyList()
        return enabledKeys.mapNotNull { key ->
            runCatching { loadRow(apiKey, region, language, key, limit) }.getOrNull()
        }
    }

    private fun loadRow(apiKey: String, region: String, language: String, key: String, limit: Int): LiveRow {
        val (title, subtitle, endpoint, type, brand) = when (key) {
            "trending_movies" -> Quint("Trending in Movies", "TMDB $region • live", "/trending/movie/week", "movie", "TMDB")
            "popular_movies" -> Quint("Popular Movies", "TMDB $region • live", "/movie/popular", "movie", "TMDB")
            "trending_shows" -> Quint("Trending in Shows", "$language • live", "/trending/tv/week", "tv", "TMDB")
            "popular_shows" -> Quint("Popular Shows", "$language • live", "/tv/popular", "tv", "TMDB")
            "platform_rows" -> Quint("Trending on Netflix", "Provider row • live", "/discover/movie?with_watch_providers=8&watch_region=${enc(region)}&sort_by=popularity.desc", "movie", "Netflix")
            else -> throw IllegalArgumentException("Unsupported catalog key: $key")
        }

        val url = buildUrl(apiKey, endpoint, language)
        val json = fetchJson(url)
        val results = json.optJSONArray("results") ?: throw IllegalStateException("Missing results")
        val items = buildList {
            for (i in 0 until minOf(limit, results.length())) {
                val obj = results.optJSONObject(i) ?: continue
                val itemTitle = when (type) {
                    "movie" -> obj.optString("title")
                    else -> obj.optString("name")
                }.ifBlank { "Unknown" }
                val overview = obj.optString("overview").ifBlank { "Live TMDB catalog item." }
                val rating = obj.optDouble("vote_average", 0.0)
                val yearSource = when (type) {
                    "movie" -> obj.optString("release_date")
                    else -> obj.optString("first_air_date")
                }
                val year = yearSource.takeIf { it.length >= 4 }?.substring(0, 4).orEmpty()
                val footer = listOfNotNull(year.takeIf { it.isNotBlank() }, if (rating > 0.0) "★ ${"%.1f".format(rating)}" else null).joinToString("  •  ").ifBlank { brand }
                add(
                    LiveCatalogItem(
                        title = itemTitle,
                        meta = footer,
                        desc = overview,
                        badge = if (rating > 0.0) "⚑  TMDB ${"%.1f".format(rating)}" else "⚑  Live Catalog",
                        brand = brand,
                        footer = footer,
                        progress = 0.18f + ((i % 8) * 0.07f),
                    )
                )
            }
        }
        return LiveRow(title = title, subtitle = subtitle, items = items)
    }

    private fun buildUrl(apiKey: String, endpoint: String, language: String): String {
        val joiner = if (endpoint.contains('?')) '&' else '?'
        return "https://api.themoviedb.org/3$endpoint${joiner}api_key=${enc(apiKey)}&language=${enc(language)}"
    }

    private fun fetchJson(url: String): JSONObject {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 8000
        connection.readTimeout = 8000
        connection.setRequestProperty("Accept", "application/json")
        return connection.inputStream.bufferedReader().use { JSONObject(it.readText()) }
            .also { connection.disconnect() }
    }

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

    private data class Quint(
        val first: String,
        val second: String,
        val third: String,
        val fourth: String,
        val fifth: String,
    )
}
