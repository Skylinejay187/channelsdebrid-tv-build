# v1.5.2 Trailer extractor reliability patch

- yt-dlp timeout increased to 60 seconds.
- YouTube search widened from 12 to 20 candidates.
- Format fallback loosened to return a playable 720p+ stream when 1080p/4K is unavailable.
- This prevents Android from showing a false "No direct trailer found" result caused by short extractor timeouts.
