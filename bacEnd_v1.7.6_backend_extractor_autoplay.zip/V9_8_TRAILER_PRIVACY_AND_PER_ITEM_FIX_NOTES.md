v9.8 Trailer privacy + per-item cache fix

- Backend trailer resolver cache now scopes by mediaId/mediaType/title/year/prefer4k.
- /trailers/resolve accepts mediaId and mediaType query params from Android.
- /trailers/prewarm also keys by item ids where present.
- No YouTube API key is required or stored by this backend path; trailer resolution uses yt-dlp when available.
- Kept v9.7/v9.6/v9.4 Live TV fixes intact.
