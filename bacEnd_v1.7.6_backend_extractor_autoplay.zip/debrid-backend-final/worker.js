
const { refreshCatalogs } = require('./lib');

const catalogIntervalMs = Number(process.env.REFRESH_INTERVAL_MS || 1000 * 60 * 30);
async function runCatalog() {
  try {
    const result = await refreshCatalogs();
    console.log('catalog refresh complete', {
      generatedAt: result.home.generatedAt,
      rails: result.home.rails.length
    });
  } catch (err) {
    console.error('catalog refresh failed', err);
  }
}

console.log('Channels Debrid worker started');
runCatalog();
// runLive();
setInterval(runCatalog, catalogIntervalMs);
// Live TV refresh removed: Android app now owns Channels DVR Direct, M3U, and Xtream/IPTV.
// setInterval(runLive, liveIntervalMs);
