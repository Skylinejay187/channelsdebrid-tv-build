# EPG Refresh Backend Patch

Added backend endpoints expected by the Android TV Settings and Live TV screens:

- `POST /live/epg/settings`
- `POST /live/epg/refresh`
- `GET /live/epg/status`
- `GET /live/epg/progress`
- `GET /live/epg`
- `/api/live/epg/*` aliases

The refresh endpoint now starts a backend guide refresh job instead of returning HTTP 404. Progress is tracked per user and reports stages such as connecting, fetching sources, downloading channels, mapping guide data, complete, or failed.
