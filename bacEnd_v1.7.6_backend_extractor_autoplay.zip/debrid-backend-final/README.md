# Debrid Channels Backend V3

This NAS-safe backend provides two planes:
- Catalog control plane (Cinemeta + Streaming Catalogs)
- Live TV control plane (per-user source connectors, guide/quick-guide payloads, playback resolve)

## Live TV goals
- Take metadata/orchestration load off the Android TV app
- Keep playback direct on the Android TV device/player
- Keep private sources scoped per user
- Avoid global relaying/transcoding

## Supported source types in V1
- `channels_dvr` — direct connector for a user-owned Channels DVR instance
- `m3u` — direct connector for a user-owned M3U playlist URL
- `public_demo` — optional public/admin shared sources (file-backed)

## Core endpoints
- `/health`
- `/api/health`
- `/api/home`
- `/api/sources`
- `POST /api/refresh`

## Live TV endpoints
- `GET /live/sources?user_id=...`
- `POST /live/sources/connect`
- `GET /live/channels?user_id=...`
- `GET /live/channel/:id?user_id=...`
- `GET /live/guide?user_id=...&channel_id=...`
- `GET /live/quick-guide?user_id=...&channel_id=...`
- `POST /live/playback/resolve`
- `POST /live/refresh`

## Credential flow
Users still enter their own credentials in the app, but the app sends them to this backend. The backend stores those source records per user and uses them for guide/channel resolution. Playback remains direct when possible.

## First run
1. Copy `.env.example` to `.env` if you want to customize values.
2. Start the stack: `sudo docker compose up -d --build`
3. Connect a user source, for example:

```bash
curl -X POST http://YOUR_SERVER_IP:8181/live/sources/connect   -H 'Content-Type: application/json'   -d '{
    "userId": "demo",
    "type": "channels_dvr",
    "name": "My Channels DVR",
    "url": "http://192.168.100.55:8089"
  }'
```

4. Refresh live data:

```bash
curl -X POST http://YOUR_SERVER_IP:8181/live/refresh -H 'Content-Type: application/json' -d '{"userId":"demo"}'
```

5. Test:
- `http://YOUR_SERVER_IP:8181/live/channels?user_id=demo`
- `http://YOUR_SERVER_IP:8181/live/quick-guide?user_id=demo`

## Notes
- This is a control plane, not a global stream host.
- Playback resolve returns direct URLs/headers whenever possible.
- Worker refreshes both catalog and live caches on an interval.


## v1.6.3 Live TV architecture change

Channels DVR, M3U, and Xtream/IPTV are no longer loaded through this backend. The Android TV app now connects directly to those Live TV providers and keeps a 12-hour local guide/channel cache. Backend Live TV endpoints intentionally return disabled/410 responses so Docker is not used as a middleman for Channels DVR streams or guide refreshes.
