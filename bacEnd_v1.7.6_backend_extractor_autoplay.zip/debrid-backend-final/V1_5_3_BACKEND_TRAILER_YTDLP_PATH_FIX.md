# v1.5.3 Backend trailer extractor fix

This patch fixes the trailer backend path and extraction logic for UGREEN NAS / Docker installs.

Changes:
- Backend now tries `YTDLP_BIN`, `/usr/local/bin/yt-dlp`, `/usr/bin/yt-dlp`, then `yt-dlp`.
- Docker image installs the latest official yt-dlp binary from GitHub, not the stale apt/pip package.
- Docker image symlinks `/usr/bin/yt-dlp` to `/usr/local/bin/yt-dlp`.
- Trailer resolver now uses the same working direct-url strategy tested on the NAS: `ytsearch1:...` plus `--get-url`.
- JSON metadata lookup is now optional; it will not make trailers fail if YouTube JSON parsing breaks.
- Fallback still parses JSON if direct URL extraction fails.

After deploying, rebuild/restart backend:

```bash
docker compose down
docker compose up -d --build
```

Quick test:

```bash
curl "http://NAS_IP:8181/trailers/resolve?title=super%20mario%20galaxy%20movie&year=2026&prefer4k=false"
```

The response should include `ok: true` and `trailer.playbackUrl`.
