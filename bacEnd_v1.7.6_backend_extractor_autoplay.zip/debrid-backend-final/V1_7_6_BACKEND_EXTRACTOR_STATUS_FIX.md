# v1.7.6 Backend Extractor Status Fix

Adds working yt-dlp status/diagnostic endpoints:

- GET /trailers/extractor/status
- GET /api/trailers/extractor/status
- GET /trailers/extractor/resolve?url=<youtube-url>&quality=1080p|4k

Dockerfile installs the official yt-dlp binary at `/usr/local/bin/yt-dlp` and sets `YTDLP_BIN`.
