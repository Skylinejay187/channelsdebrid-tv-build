# v1.7.0 Trailer Quality Fix

- Fast direct trailer resolver now respects prefer4k instead of always resolving with 1080p mode.
- yt-dlp format selection now prioritizes 720p+ and 1080p/4K before falling back to lower quality.
- 360p is no longer preferred ahead of 720p in the fallback chain.
