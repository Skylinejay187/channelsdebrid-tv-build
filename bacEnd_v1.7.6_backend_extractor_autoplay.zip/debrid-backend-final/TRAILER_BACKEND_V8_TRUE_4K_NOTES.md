# Backend v8 True 4K Trailer Resolve

Changes:
- Two-stage trailer resolving:
  1. Search and score candidate trailers.
  2. Resolve the chosen trailer directly with yt-dlp 2160p-first format chain.
- Uses YouTube web/web_creator/tv_embedded/android clients to improve adaptive 4K availability.
- Prefers DASH manifest URL first so ExoPlayer can select separate 2160p video + audio tracks.
- Keeps 1080p fallback if no 2160p stream exists.
