# Trailer match + 4K fix

- Exact-title scoring for trailer matching.
- Penalizes fan-made/concept/reaction/review/clip videos.
- Uses 2160p adaptive first, then 1440p/1080p fallback.
