# Debrid Channels Backend v9 - Live TV Performance Engine

Added/expanded:

- `GET /performance/status` and `GET /api/performance/status`
  - Reports Live TV, EPG, poster/cache, trailer, and icon engine status.
- EPG aliases:
  - `POST /epg/refresh`
  - `GET /epg/status`
  - `GET /epg/guide`
  - Existing `/live/epg/*` endpoints are still supported.
- Channel icon proxy/cache:
  - `GET /icons/{channelId}?user_id=demo`
  - `GET /live/icons/{channelId}?user_id=demo`
  - Icons are cached in memory for fast Android TV loading.
- Trailer engine remains backend-side:
  - `GET /trailers/resolve`
  - `POST /trailers/prewarm`
  - Android now decides where the trailer plays: hero, details, both, or off.

Architecture:

```text
Backend Performance Engine
 ├── Live TV / EPG refresh + status
 ├── Channel icon proxy/cache
 ├── Catalog/poster backend cache compatibility
 └── Trailer resolve/prewarm cache for Nuvio-style Android playback
```
