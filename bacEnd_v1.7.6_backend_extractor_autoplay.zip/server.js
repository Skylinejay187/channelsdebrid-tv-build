require('./debrid-backend-final/server.js');
