function normalize(name) {
  return name.toLowerCase().replace(/hd|[^a-z0-9]/g, "");
}

function mapChannels(lineup, xmltv) {
  const mapped = [];

  for (const ch of lineup) {
    const norm = normalize(ch.name);

    const match = xmltv.channels.find(x =>
      normalize(x.displayName).includes(norm)
    );

    if (!match) continue;

    const programs = xmltv.programs
      .filter(p => p.channel === match.id)
      .map(p => ({
        title: p.title,
        start: new Date(p.start).getTime() / 1000,
        end: new Date(p.stop).getTime() / 1000
      }));

    mapped.push({
      id: ch.id,
      name: ch.name,
      icon: `/icons/${ch.id}.png`,
      programs
    });
  }

  return mapped;
}

module.exports = { mapChannels };
