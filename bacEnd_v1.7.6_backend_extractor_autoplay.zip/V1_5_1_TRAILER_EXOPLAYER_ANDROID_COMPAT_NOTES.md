# v1.5.1 backend compatibility

Backend v1.5 trailer extractor remains the source for Android trailer playback:

GET /trailers/resolve?title=<title>&year=<year>&type=<movie|series>&externalId=<id>&quality=2160p,1080p

Android v1.5.1 now consumes this endpoint first and no longer displays the YouTube iframe popup.
