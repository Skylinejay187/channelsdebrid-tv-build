# v9.7 Backend Compatibility

No backend behavior was removed. This package keeps the v9.6 backend while matching the Android v9.7 package naming.
