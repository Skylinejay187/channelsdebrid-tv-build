package com.channelsdebrid.tv.settings

object SettingsScaffold {
    val defaultTmdb = TmdbSettings()

    val defaultAddons = listOf(
        StremioAddonSettings(
            id = "cinematic",
            name = "Cinematic",
            manifestUrl = "https://example.com/manifest.json",
            enabled = true
        )
    )

    val defaultChannelsDvr = ChannelsDvrSettings(
        autoDetect = true,
        baseUrl = "",
        username = "",
        password = ""
    )

    val defaultXtream = XtreamSettings(
        server = "",
        username = "",
        password = "",
        enabled = false
    )

    val defaultStorageTargets = listOf(
        StorageTarget(
            id = "internal",
            type = "internal",
            label = "Internal Storage",
            path = "/data/user/0/com.channelsdebrid.tv/files/cache",
            allowTimeshift = true,
            allowVodCache = false,
            priority = 99
        )
    )

    val defaultTrailers = TrailerSettings()
    val defaultPlayback = PlaybackSettings()
}
