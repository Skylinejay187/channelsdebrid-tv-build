# Debrid Channels Android TV

Build: v0.1 CLEAN STABLE BASE

Marker: `DC_V0_1_CLEAN_BASE`
Logcat marker: `DC_V0_1_ACTIVE`

Base used: `DebridChannels_v6_9_EXACT_HERO_RATING_BADGES_SOURCE.zip`

This package resets public app versioning to `versionName 0.1` / `versionCode 1` for GitHub workflow tracking.
