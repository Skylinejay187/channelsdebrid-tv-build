# Rewrite Build Audit — v0.1 CLEAN STABLE BASE

Base used: `DebridChannels_v6_9_EXACT_HERO_RATING_BADGES_SOURCE.zip`

Rule enforced: use the chosen known-good base as the source of truth, do not carry forward broken/stale generated code from later failed builds.

Changes made in this consolidation:
- Reset Gradle versionCode to `1`.
- Reset Gradle versionName to `0.1`.
- Updated BuildMarkers to `v0.1 CLEAN STABLE BASE` and `DC_V0_1_ACTIVE`.
- Added visible on-screen marker `DC_V0_1_CLEAN_BASE`.
- Repaired row focus navigation in the v6.9 code path: menu DOWN enters row 0; card UP/DOWN moves between rows; only row 0 auto-focuses.
- Preserved v6.9 hero artwork, logo-only cards, IMDb/TMDB badge behavior, backend URL default, Pro Layout Editor state, and carousel left/right behavior.

Not carried forward:
- v7.1 broken/frozen row/editor code.
- stale 6.6 version identity.
- later failed experimental code paths.
