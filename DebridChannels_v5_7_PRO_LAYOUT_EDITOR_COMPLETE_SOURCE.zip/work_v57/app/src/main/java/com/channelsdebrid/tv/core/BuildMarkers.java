package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v5.7 PRO LAYOUT EDITOR COMPLETE";
    public static final String LOG_MARKER = "DC_V5_7_PRO_LAYOUT_EDITOR_COMPLETE";
    private BuildMarkers() {}
}
