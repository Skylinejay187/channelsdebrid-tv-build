# DC v5.7 Pro Layout Editor Complete

Base used: DebridChannels_v5_6_FULL_CORE_COMPLETION / v5.1 clean-core lineage.
Reference only: v2.1.3 Pro Layout Menu Art Livefix Full.

What was recreated as new code:
- Pro Layout Editor settings list from v2.1.3 capability set.
- Persistent UI state store for all editor controls.
- Live preview panel for hero, row title, cards, artwork/menu metadata.
- Reset and View Home actions.

No legacy HomeLayoutEditorActivity.kt or SettingsRepository code was copied into this build.
