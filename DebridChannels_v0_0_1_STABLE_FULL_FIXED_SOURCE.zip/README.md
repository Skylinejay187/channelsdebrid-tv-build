Debrid Channels v0.0.1 - Stable Base

Clean rewrite/consolidation from the latest known-good v0.6/v6.9 stable line.

Includes:
- versionCode 1 / versionName 0.0.1
- visible marker DC_V0_0_1_STABLE_BASE
- logcat marker DC_V0_0_1_ACTIVE
- working single active row UP/DOWN navigation
- settings/pro layout editor scroll behavior from stable line
- hero logo/background/rating badge system
- strict card logo filter to prevent square poster overlays on row cards
- backend default http://192.168.100.55:8181
