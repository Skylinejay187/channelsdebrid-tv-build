# Rewrite Build Audit - v0.0.1

Base used: latest known-good v0.6/v6.9 stable line, not broken v7.1 or stale generated patches.

Build rule followed: clean rewrite/consolidation from a stable base. Broken build code was not carried forward.

Versioning:
- versionCode: 1
- versionName: 0.0.1
- visible marker: DC_V0_0_1_STABLE_BASE
- logcat marker: DC_V0_0_1_ACTIVE

Preserved locked features:
- Pro Layout Editor and Settings scroll/focus behavior
- DPAD carousel and single active row UP/DOWN navigation
- backend artwork loading from http://192.168.100.55:8181
- hero background/logo/rating badges
- logo-only clean row cards

Specific v0.0.1 fix:
- strict row-card logo filter: cards no longer display square poster/thumbnail/logo overlays when artwork is not a true clearlogo. Invalid card logo artwork is hidden instead of falling back.
