# Trailer 4K / Unmute / Splash / Pulse Fix

Changes:
- Added detail page trailer mute/unmute button.
- Forced ExoPlayer track selector viewport to 3840x2160 so adaptive DASH/HLS can select 4K tracks instead of being capped by current viewport.
- Replaced focused-card repeating pulse with static focus scale to prevent trailer preview surface jitter/glitching.
- Added simple Debrid Channels startup animation using existing splash branding/logo asset.

Notes:
- 4K still depends on the selected YouTube trailer actually having a 2160p adaptive stream.
- Backend v8 does a two-stage resolve: search/score first, then resolve the selected video with a hard 2160p-first format chain.
