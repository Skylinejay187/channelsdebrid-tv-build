package com.channelsdebrid.tv.playback

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView
import com.bumptech.glide.Glide
import com.channelsdebrid.tv.R
import com.channelsdebrid.tv.settings.SettingsRepository
import org.json.JSONObject
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MediaDetailsActivity : AppCompatActivity() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val trailerExecutor = Executors.newSingleThreadExecutor()
    private var backgroundTrailerRunnable: Runnable? = null
    private var backgroundTrailerPlayer: ExoPlayer? = null
    private lateinit var settingsRepository: SettingsRepository
    private lateinit var trailerPlayerView: PlayerView
    private lateinit var trailerMuteButton: TextView
    private var backgroundTrailerMuted: Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_media_details)
        settingsRepository = SettingsRepository(this)
        trailerPlayerView = findViewById(R.id.detailsTrailerPlayer)
        trailerPlayerView.useController = false
        trailerMuteButton = findViewById(R.id.detailsTrailerMuteButton)
        trailerMuteButton.visibility = View.GONE
        trailerMuteButton.setOnClickListener { toggleBackgroundTrailerMute() }

        val backdrop = intent.getStringExtra(EXTRA_BACKDROP_URL).orEmpty()
        val logo = intent.getStringExtra(EXTRA_LOGO_URL).orEmpty()
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val meta = intent.getStringExtra(EXTRA_META_LINE).orEmpty()
        val desc = intent.getStringExtra(EXTRA_DESC).orEmpty()
        val poster = intent.getStringExtra(EXTRA_POSTER_URL).orEmpty()
        val externalId = intent.getStringExtra(EXTRA_EXTERNAL_ID).orEmpty()
        val mediaType = intent.getStringExtra(EXTRA_MEDIA_TYPE).orEmpty().ifBlank { "movie" }

        // Backdrop artwork loads first so the page feels instant. Trailer fades in later if enabled.
        Glide.with(this).load(backdrop.ifBlank { poster }).centerCrop().into(findViewById<ImageView>(R.id.detailsBackdrop))

        val logoView = findViewById<ImageView>(R.id.detailsLogo)
        val titleView = findViewById<TextView>(R.id.detailsTitle)
        if (logo.isNotBlank()) {
            Glide.with(this).load(logo).fitCenter().into(logoView)
        } else {
            logoView.visibility = View.GONE
            titleView.text = title
            titleView.visibility = TextView.VISIBLE
        }

        findViewById<TextView>(R.id.detailsMeta).text = meta
        findViewById<TextView>(R.id.detailsDesc).text = desc

        val favoriteButton = findViewById<Button>(R.id.detailsFavorite)
        val favoriteKey = "favorite_${mediaType}_${externalId.ifBlank { title }}"
        val prefs = getSharedPreferences("debrid_channels_favorites", MODE_PRIVATE)
        fun refreshFavoriteButton() {
            favoriteButton.text = if (prefs.getBoolean(favoriteKey, false)) "Favorited" else "Add Favorite"
        }
        refreshFavoriteButton()
        favoriteButton.setOnClickListener {
            val next = !prefs.getBoolean(favoriteKey, false)
            prefs.edit().putBoolean(favoriteKey, next).apply()
            refreshFavoriteButton()
            Toast.makeText(this, if (next) "Added to favorites" else "Removed from favorites", Toast.LENGTH_SHORT).show()
        }

        buildCastRow(listOf("Loading cast..."))
        loadAddonMetadata(title, mediaType, externalId, meta)
        buildRelatedRow(title, poster.ifBlank { backdrop })
        scheduleBackgroundTrailer(title, meta)

        val playButton = findViewById<Button>(R.id.detailsPlay)
        val isSeries = mediaType.equals("series", ignoreCase = true) || mediaType.equals("show", ignoreCase = true) || mediaType.equals("tv", ignoreCase = true)
        if (isSeries) playButton.text = "Browse Episodes"

        fun openEpisodes() {
            if (externalId.isBlank()) {
                Toast.makeText(this, "Episode data missing for this show. Try refreshing the backend catalog.", Toast.LENGTH_LONG).show()
                return
            }
            startActivity(Intent(this, SeasonEpisodeActivity::class.java).apply {
                putExtra(SeasonEpisodeActivity.EXTRA_TITLE, title)
                putExtra(SeasonEpisodeActivity.EXTRA_MEDIA_TYPE, "series")
                putExtra(SeasonEpisodeActivity.EXTRA_EXTERNAL_ID, externalId)
                putExtra(SeasonEpisodeActivity.EXTRA_POSTER_URL, poster)
                putExtra(SeasonEpisodeActivity.EXTRA_BACKDROP_URL, backdrop.ifBlank { poster })
                putExtra(SeasonEpisodeActivity.EXTRA_LOGO_URL, logo)
                putExtra(SeasonEpisodeActivity.EXTRA_ITEM_META, meta)
                putExtra(SeasonEpisodeActivity.EXTRA_DESC, desc)
            })
        }

        playButton.setOnClickListener {
            stopBackgroundTrailer()
            if (isSeries) {
                openEpisodes()
            } else {
                startActivity(Intent(this, SourceSelectionActivity::class.java).apply {
                    putExtra(SourceSelectionActivity.EXTRA_TITLE, title)
                    putExtra(SourceSelectionActivity.EXTRA_MEDIA_TYPE, mediaType)
                    putExtra(SourceSelectionActivity.EXTRA_EXTERNAL_ID, externalId)
                    putExtra(SourceSelectionActivity.EXTRA_ARTWORK_URL, backdrop.ifBlank { poster })
                    putExtra(SourceSelectionActivity.EXTRA_BACKDROP_URL, backdrop.ifBlank { poster })
                    putExtra(SourceSelectionActivity.EXTRA_LOGO_URL, logo)
                    putExtra(SourceSelectionActivity.EXTRA_POSTER_URL, poster)
                    putExtra(SourceSelectionActivity.EXTRA_META_LINE, meta)
                    putExtra(SourceSelectionActivity.EXTRA_DESC, desc)
                })
            }
        }
    }

    private fun scheduleBackgroundTrailer(title: String, meta: String) {
        val settings = settingsRepository.loadTrailers()
        if (!settings.enabled || !settings.backgroundAutoplayEnabled || title.isBlank()) return
        val delay = settings.backgroundAutoplayDelayMs.coerceIn(0L, 60000L)
        backgroundTrailerRunnable = Runnable {
            trailerExecutor.execute {
                val stream = resolveBackendTrailerStream(title, meta, settings.prefer4k)
                mainHandler.post {
                    if (!isFinishing && !isDestroyed && stream?.playbackUrl?.isNotBlank() == true) {
                        startBackgroundTrailer(stream)
                    }
                }
            }
        }
        mainHandler.postDelayed(backgroundTrailerRunnable!!, delay)
    }

    private fun resolveBackendTrailerStream(title: String, meta: String, prefer4k: Boolean): TrailerStream? {
        return runCatching {
            val liveBackend = settingsRepository.loadLiveBackend()
            val backendBase = liveBackend.baseUrl.ifBlank { "http://192.168.100.55:8181" }.trimEnd('/')
            val encodedTitle = URLEncoder.encode(title, "UTF-8")
            val year = Regex("(19|20)\\d{2}").find(meta)?.value.orEmpty()
            val url = URL("$backendBase/trailers/resolve?title=$encodedTitle&year=${URLEncoder.encode(year, "UTF-8")}&prefer4k=$prefer4k")
            val connection = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 12000
                readTimeout = 25000
                requestMethod = "GET"
                setRequestProperty("Accept", "application/json")
            }
            connection.inputStream.bufferedReader().use { reader ->
                val json = JSONObject(reader.readText())
                if (!json.optBoolean("ok", false)) return null
                val trailer = json.optJSONObject("trailer") ?: return null
                TrailerStream(
                    playbackUrl = trailer.optString("playbackUrl"),
                    mimeType = trailer.optString("mimeType"),
                    quality = trailer.optString("quality")
                )
            }
        }.getOrNull()
    }

    private fun startBackgroundTrailer(stream: TrailerStream) {
        stopBackgroundTrailer()
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Android TV; ChannelsDebrid)")
            .setAllowCrossProtocolRedirects(true)
        val mediaSourceFactory = DefaultMediaSourceFactory(this).setDataSourceFactory(httpFactory)
        val trackSelector = DefaultTrackSelector(this).apply {
            setParameters(
                buildUponParameters()
                    .setMaxVideoSize(3840, 2160)
                    .setViewportSize(3840, 2160, false)
                    .setMinVideoSize(1920, 1080)
                    .setForceHighestSupportedBitrate(true)
            )
        }
        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(mediaSourceFactory)
            .setTrackSelector(trackSelector)
            .build()
        backgroundTrailerPlayer = player
        trailerPlayerView.player = player
        val mediaItemBuilder = MediaItem.Builder().setUri(stream.playbackUrl)
        if (stream.mimeType.contains("dash", ignoreCase = true) || stream.playbackUrl.contains(".mpd", ignoreCase = true)) {
            mediaItemBuilder.setMimeType(MimeTypes.APPLICATION_MPD)
        } else if (stream.mimeType.contains("hls", ignoreCase = true) || stream.playbackUrl.contains(".m3u8", ignoreCase = true)) {
            mediaItemBuilder.setMimeType(MimeTypes.APPLICATION_M3U8)
        }
        player.setMediaItem(mediaItemBuilder.build())
        player.repeatMode = Player.REPEAT_MODE_ONE
        backgroundTrailerMuted = true
        player.volume = 0f
        player.prepare()
        player.playWhenReady = true
        trailerPlayerView.visibility = View.VISIBLE
        trailerMuteButton.text = "Unmute Trailer"
        trailerMuteButton.visibility = View.VISIBLE
        trailerPlayerView.animate().alpha(1f).setDuration(350L).start()
    }

    private fun toggleBackgroundTrailerMute() {
        val player = backgroundTrailerPlayer ?: return
        backgroundTrailerMuted = !backgroundTrailerMuted
        player.volume = if (backgroundTrailerMuted) 0f else 1f
        trailerMuteButton.text = if (backgroundTrailerMuted) "Unmute Trailer" else "Mute Trailer"
    }

    private fun stopBackgroundTrailer() {
        backgroundTrailerRunnable?.let(mainHandler::removeCallbacks)
        backgroundTrailerRunnable = null
        trailerPlayerView.animate().cancel()
        trailerPlayerView.alpha = 0f
        trailerPlayerView.visibility = View.GONE
        trailerMuteButton.visibility = View.GONE
        trailerPlayerView.player = null
        backgroundTrailerPlayer?.release()
        backgroundTrailerPlayer = null
    }

    override fun onStop() {
        super.onStop()
        stopBackgroundTrailer()
    }

    override fun onDestroy() {
        stopBackgroundTrailer()
        trailerExecutor.shutdownNow()
        super.onDestroy()
    }

    private fun buildCastRow(labels: List<String> = listOf("Cast unavailable")) {
        val row = findViewById<LinearLayout>(R.id.detailsCastRow)
        row.removeAllViews()
        labels.take(12).forEach { label ->
            val chip = TextView(this).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 15f
                gravity = Gravity.CENTER
                setPadding(22, 0, 22, 0)
                background = makePillDrawable(0x33FFFFFF, 0x33FFFFFF)
            }
            row.addView(chip, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 58).apply { marginEnd = 12 })
        }
    }

    private fun loadAddonMetadata(title: String, mediaType: String, externalId: String, currentMeta: String) {
        if (externalId.isBlank()) {
            buildCastRow(listOf("Cast unavailable"))
            return
        }
        trailerExecutor.execute {
            val addons = settingsRepository.loadStremioAddons().filter { it.enabled && it.manifestUrl.isNotBlank() }
            for (addon in addons) {
                val meta = fetchAddonMeta(addon.manifestUrl, mediaType, externalId) ?: continue
                val imdbRating = meta.optString("imdbRating").takeIf { it.isNotBlank() }
                val releaseInfo = meta.optString("releaseInfo").takeIf { it.isNotBlank() }
                val genres = meta.optJSONArray("genres")?.let { arr ->
                    (0 until arr.length()).mapNotNull { arr.optString(it).takeIf(String::isNotBlank) }.take(3).joinToString(" • ")
                }
                val castArray = meta.optJSONArray("cast") ?: meta.optJSONArray("actors") ?: JSONArray()
                val cast = (0 until castArray.length()).mapNotNull { castArray.optString(it).takeIf(String::isNotBlank) }.take(12)
                mainHandler.post {
                    val metaParts = listOfNotNull(releaseInfo, genres, imdbRating?.let { "IMDb $it" }).filter { it.isNotBlank() }
                    if (metaParts.isNotEmpty()) findViewById<TextView>(R.id.detailsMeta).text = metaParts.joinToString("  •  ")
                    buildCastRow(if (cast.isNotEmpty()) cast else listOf("Cast unavailable"))
                }
                return@execute
            }
            mainHandler.post { buildCastRow(listOf("Cast unavailable")) }
        }
    }

    private fun fetchAddonMeta(manifestUrl: String, mediaType: String, externalId: String): JSONObject? {
        return runCatching {
            val base = manifestUrl.removeSuffix("/manifest.json").trimEnd('/')
            val type = if (mediaType.equals("series", true) || mediaType.equals("show", true) || mediaType.equals("tv", true)) "series" else "movie"
            val url = URL("$base/meta/$type/${URLEncoder.encode(externalId, "UTF-8")}.json")
            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8000
                readTimeout = 10000
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "ChannelsDebridTV/1.0")
            }
            try {
                if (connection.responseCode !in 200..299) return@runCatching null
                JSONObject(connection.inputStream.bufferedReader().use { it.readText() }).optJSONObject("meta")
            } finally {
                connection.disconnect()
            }
        }.getOrNull()
    }

    private fun buildRelatedRow(title: String, artwork: String) {
        val row = findViewById<LinearLayout>(R.id.detailsRelatedRow)
        row.removeAllViews()
        repeat(4) { index ->
            val frame = FrameLayout(this).apply {
                background = makePillDrawable(0x22000000, 0x44FFFFFF)
                isFocusable = true
            }
            val image = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            frame.addView(image, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            if (artwork.isNotBlank()) Glide.with(this).load(artwork).centerCrop().into(image)
            val label = TextView(this).apply {
                text = if (index == 0) title else "Related"
                setTextColor(Color.WHITE)
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.BOTTOM or Gravity.START
                setPadding(12, 0, 12, 12)
            }
            frame.addView(label, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            row.addView(frame, LinearLayout.LayoutParams(150, 92).apply { marginEnd = 14 })
        }
    }

    private fun makePillDrawable(fill: Int, stroke: Int): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = 18f
            setColor(fill)
            setStroke(1, stroke)
        }
    }

    private data class TrailerStream(
        val playbackUrl: String,
        val mimeType: String,
        val quality: String
    )

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_META_LINE = "meta_line"
        const val EXTRA_DESC = "desc"
        const val EXTRA_MEDIA_TYPE = "media_type"
        const val EXTRA_EXTERNAL_ID = "external_id"
        const val EXTRA_POSTER_URL = "poster_url"
        const val EXTRA_BACKDROP_URL = "backdrop_url"
        const val EXTRA_LOGO_URL = "logo_url"
    }
}
