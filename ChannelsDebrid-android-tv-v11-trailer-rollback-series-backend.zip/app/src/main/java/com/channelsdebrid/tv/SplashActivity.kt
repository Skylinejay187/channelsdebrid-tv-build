package com.channelsdebrid.tv

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class SplashActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private val launchRunnable = Runnable {
        startActivity(Intent(this, MainActivity::class.java))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        val density = resources.displayMetrics.density
        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }

        val glow = View(this).apply {
            alpha = 0f
            background = ContextCompat.getDrawable(this@SplashActivity, R.drawable.startup_blue_glow)
        }
        root.addView(glow, FrameLayout.LayoutParams((440 * density).toInt(), (440 * density).toInt(), Gravity.CENTER))

        val logo = ImageView(this).apply {
            alpha = 0f
            scaleX = 0.88f
            scaleY = 0.88f
            setImageResource(R.drawable.splash_branding)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        root.addView(logo, FrameLayout.LayoutParams((430 * density).toInt(), (210 * density).toInt(), Gravity.CENTER))

        val title = TextView(this).apply {
            alpha = 0f
            text = "Debrid Channels"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 30f
            letterSpacing = 0.08f
            gravity = Gravity.CENTER
        }
        root.addView(title, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM).apply {
            bottomMargin = (86 * density).toInt()
        })
        setContentView(root)

        AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(glow, View.ALPHA, 0f, 1f),
                ObjectAnimator.ofFloat(glow, View.SCALE_X, 0.72f, 1.16f),
                ObjectAnimator.ofFloat(glow, View.SCALE_Y, 0.72f, 1.16f),
                ObjectAnimator.ofFloat(logo, View.ALPHA, 0f, 1f),
                ObjectAnimator.ofFloat(logo, View.SCALE_X, 0.88f, 1f),
                ObjectAnimator.ofFloat(logo, View.SCALE_Y, 0.88f, 1f),
                ObjectAnimator.ofFloat(title, View.ALPHA, 0f, 1f)
            )
            duration = 1250L
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
        handler.postDelayed(launchRunnable, 1850L)
    }

    override fun onDestroy() {
        handler.removeCallbacks(launchRunnable)
        super.onDestroy()
    }
}
