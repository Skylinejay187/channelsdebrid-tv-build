package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.5.3 LIVE TV GOOGLE GUIDE REAL PLAYBACK REBUILD";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.5.3_live_tv_google_guide_real_playback_clean_base";
    private BuildMarkers() {}
}
