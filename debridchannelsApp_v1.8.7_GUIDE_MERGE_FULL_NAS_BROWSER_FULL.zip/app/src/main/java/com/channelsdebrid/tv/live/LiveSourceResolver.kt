package com.channelsdebrid.tv.live

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

object LiveSourceResolver {

    data class HttpResult(
        val body: String?,
        val error: String?
    )

    data class ChannelItem(
        val name: String,
        val url: String,
        val source: String,
        val debug: String = "",
        val groups: List<String> = emptyList(),
        val number: String = "",
        val iconUrl: String = ""
    )

    data class DvrResult(
        val channels: List<ChannelItem>,
        val message: String,
        val deviceId: String? = null
    )

    data class HdHomeRunDevice(
        val deviceId: String,
        val friendlyName: String,
        val baseUrl: String,
        val lineupUrl: String,
        val deviceAuth: String = ""
    )

    data class HdHomeRunResult(
        val channels: List<ChannelItem>,
        val message: String,
        val devices: List<HdHomeRunDevice> = emptyList()
    )

    fun loadHdHomeRunChannels(): HdHomeRunResult {
        val devices = discoverHdHomeRunDevices()
        if (devices.isEmpty()) {
            return HdHomeRunResult(emptyList(), "HDHomeRun scan found no tuners.")
        }
        val channels = mutableListOf<ChannelItem>()
        val successful = mutableListOf<HdHomeRunDevice>()
        for (device in devices) {
            val lineup = getJson(device.lineupUrl)
            val parsed = parseHdHomeRunLineup(device, lineup.body.orEmpty())
            if (parsed.isNotEmpty()) {
                successful += device
                channels += parsed
            }
        }
        val deduped = channels.distinctBy { it.source + "|" + it.number + "|" + it.name + "|" + it.url }
        return if (deduped.isNotEmpty()) {
            val label = if (successful.size == 1) successful.first().friendlyName else "${successful.size} tuners"
            HdHomeRunResult(deduped, "HDHomeRun connected • ${deduped.size} channels found ($label)", successful)
        } else {
            HdHomeRunResult(emptyList(), "HDHomeRun tuner found, but no channels were returned.", devices)
        }
    }

    fun discoverHdHomeRunDeviceAuths(): List<String> {
        return discoverHdHomeRunDevices()
            .map { it.deviceAuth.trim() }
            .filter { it.isNotBlank() }
            .distinct()
    }

    private fun discoverHdHomeRunDevices(): List<HdHomeRunDevice> {
        val devices = linkedMapOf<String, HdHomeRunDevice>()

        fun normalizeBase(raw: String): String = raw.trim().trimEnd('/')

        fun addDevice(deviceIdRaw: String, friendlyRaw: String, baseRaw: String, lineupRaw: String, deviceAuthRaw: String = "") {
            val base = normalizeBase(baseRaw)
            val lineup = when {
                lineupRaw.trim().startsWith("http", ignoreCase = true) -> lineupRaw.trim()
                lineupRaw.trim().startsWith("/") && base.isNotBlank() -> base + lineupRaw.trim()
                lineupRaw.trim().isNotBlank() && base.isNotBlank() -> "$base/${lineupRaw.trim()}"
                base.isNotBlank() -> "$base/lineup.json"
                else -> ""
            }
            if (lineup.isBlank()) return
            val finalBase = base.ifBlank { lineup.substringBefore("/lineup", "").trimEnd('/') }
            if (finalBase.isBlank()) return
            val deviceId = deviceIdRaw.ifBlank { finalBase }.trim()
            val friendly = friendlyRaw.ifBlank { "HDHomeRun ${deviceId.takeLast(6)}" }.trim()
            devices[deviceId] = HdHomeRunDevice(deviceId, friendly, finalBase, lineup, deviceAuthRaw.trim())
        }

        fun addFromJson(json: String, fallbackBase: String = "") {
            try {
                val arr = if (json.trim().startsWith("[")) JSONArray(json) else JSONArray().put(JSONObject(json))
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val deviceId = obj.optString("DeviceID")
                        .ifBlank { obj.optString("DeviceId") }
                        .ifBlank { obj.optString("deviceId") }
                        .trim()
                    val friendly = obj.optString("FriendlyName")
                        .ifBlank { obj.optString("Name") }
                        .ifBlank { obj.optString("ModelNumber") }
                        .trim()
                    val base = obj.optString("BaseURL")
                        .ifBlank { obj.optString("baseURL") }
                        .ifBlank { obj.optString("DiscoverURL").substringBefore("/discover", "") }
                        .ifBlank { fallbackBase }
                        .trim()
                        .trimEnd('/')
                    val lineupUrl = obj.optString("LineupURL")
                        .ifBlank { obj.optString("lineupURL") }
                        .ifBlank { obj.optString("LineupUrl") }
                        .ifBlank { if (base.isNotBlank()) "$base/lineup.json" else "" }
                        .trim()
                    val deviceAuth = obj.optString("DeviceAuth")
                        .ifBlank { obj.optString("deviceAuth") }
                        .trim()
                    addDevice(deviceId, friendly, base, lineupUrl, deviceAuth)
                }
            } catch (_: Exception) {
            }
        }

        val candidates = linkedSetOf(
            "http://api.hdhomerun.com/discover",
            "http://hdhomerun.local/discover.json"
        )
        val directBases = linkedSetOf("http://hdhomerun.local")
        localSubnetPrefixes().forEach { prefix ->
            // Startup-safe discovery only. A full /24 scan can block Live TV for minutes
            // on Android TV devices, so keep the automatic pass to common tuner hosts.
            // Users can still enter a manual tuner/source later if their network is unusual.
            listOf(1, 2, 10, 20, 50, 55, 80, 89, 100, 101, 150, 200, 254).forEach { host ->
                directBases += "http://$prefix.$host"
            }
        }
        directBases.forEach { base -> candidates += "$base/discover.json" }

        candidates.forEach { url ->
            val base = url.substringBefore("/discover", "").trimEnd('/')
            getJson(url, connectTimeoutMs = 180, readTimeoutMs = 260).body?.let { addFromJson(it, base) }
        }

        // Some tuners/proxies expose lineup.json even when discover.json is not reachable.
        directBases.forEach { base ->
            val lineupUrl = "$base/lineup.json"
            val lineup = getJson(lineupUrl, connectTimeoutMs = 180, readTimeoutMs = 260).body.orEmpty()
            if (lineup.trim().startsWith("[")) {
                addDevice(base.substringAfterLast('.'), "HDHomeRun", base, lineupUrl)
            }
        }
        return devices.values.toList()
    }

    private fun parseHdHomeRunLineup(device: HdHomeRunDevice, json: String): List<ChannelItem> {
        if (json.isBlank()) return emptyList()
        val out = mutableListOf<ChannelItem>()
        try {
            val arr = if (json.trim().startsWith("[")) JSONArray(json) else JSONObject(json).optJSONArray("Guide") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                if (obj.optBoolean("DRM", false)) continue
                val number = obj.optString("GuideNumber").ifBlank { obj.optString("Channel") }.trim()
                val name = obj.optString("GuideName").ifBlank { obj.optString("Name") }.ifBlank { "HDHomeRun ${number.ifBlank { i.toString() }}" }.trim()
                val url = obj.optString("URL").ifBlank {
                    if (number.isNotBlank()) "${device.baseUrl}/auto/v$number" else ""
                }.trim()
                if (url.isBlank()) continue
                val groups = mutableListOf("HDHomeRun")
                val lower = name.lowercase(Locale.US)
                when {
                    "sport" in lower || "espn" in lower -> groups += "Sports"
                    "news" in lower || "cnn" in lower || "fox" in lower || "msnbc" in lower -> groups += "News"
                    "kids" in lower || "disney" in lower || "nick" in lower -> groups += "Kids"
                    "movie" in lower || "hbo" in lower || "starz" in lower || "showtime" in lower -> groups += "Movies"
                }
                val icon = obj.optString("ImageURL")
                    .ifBlank { obj.optString("GuideImageURL") }
                    .ifBlank { obj.optString("GuideImageUrl") }
                    .ifBlank { obj.optString("LogoURL") }
                    .ifBlank { obj.optString("LogoUrl") }
                    .ifBlank { obj.optString("IconURL") }
                    .ifBlank { obj.optString("IconUrl") }
                    .ifBlank { obj.optString("icon") }
                    .ifBlank { obj.optString("Icon") }
                    .ifBlank { obj.optString("StationLogo") }
                    .ifBlank { obj.optString("Logo") }
                    .trim()
                out += ChannelItem(
                    name = name,
                    url = url,
                    source = "HDHomeRun",
                    debug = buildString { append("device=").append(device.deviceId).append(" • ch=").append(number).append(" • native tuner"); if (device.deviceAuth.isNotBlank()) append(" • auth=available") },
                    groups = groups.distinct(),
                    number = number,
                    iconUrl = icon
                )
            }
        } catch (_: Exception) {
        }
        return out
    }


    fun discoverChannelsDvrBaseUrl(): String? {
        val candidates = linkedSetOf<String>()
        candidates += "http://channels.local:8089"
        candidates += "http://channels-dvr.local:8089"
        candidates += "http://192.168.1.50:8089"
        candidates += "http://192.168.100.55:8089"
        localSubnetPrefixes().forEach { prefix ->
            listOf(1, 2, 10, 20, 50, 55, 80, 89, 100, 101, 150, 200, 254).forEach { host ->
                candidates += "http://$prefix.$host:8089"
            }
        }
        return candidates.firstOrNull { base -> isChannelsDvrServer(base) }
    }

    private fun isChannelsDvrServer(baseUrl: String): Boolean {
        val base = baseUrl.trim().trimEnd('/')
        val probes = listOf("$base/status", "$base/devices", "$base/dvr/lineups")
        return probes.any { url ->
            val body = getJson(url, connectTimeoutMs = 250, readTimeoutMs = 350).body.orEmpty()
            body.contains("Channels", ignoreCase = true) ||
                body.contains("Device", ignoreCase = true) ||
                body.contains("lineup", ignoreCase = true) ||
                body.trim().startsWith("[")
        }
    }

    private fun localSubnetPrefixes(): List<String> {
        val prefixes = linkedSetOf<String>()
        return try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (address is Inet4Address && !address.isLoopbackAddress) {
                        val parts = address.hostAddress.split('.')
                        if (parts.size == 4) prefixes += parts.take(3).joinToString(".")
                    }
                }
            }
            prefixes.toList()
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun loadDvrChannels(baseUrl: String, preferredDeviceId: String = ""): DvrResult {
        val base = baseUrl.trim().trimEnd('/').ifBlank { discoverChannelsDvrBaseUrl().orEmpty() }
        if (base.isBlank()) return DvrResult(emptyList(), "Channels DVR auto-detect found no server. Manual IP is still available in Settings.")

        val combined = mutableListOf<ChannelItem>()
        val successfulSources = mutableListOf<String>()
        var firstError: String? = null

        // Do not stop at the first Channels DVR endpoint. Some exports can be filtered
        // (Favorites/HD), while another endpoint contains the full lineup.
        val m3uUrls = listOf(
            "$base/devices/ANY/channels.m3u?format=ts&codec=copy",
            "$base/devices/ANY/channels.m3u?format=ts"
        )
        for (m3uUrl in m3uUrls) {
            val probe = getJson(m3uUrl, connectTimeoutMs = 2500, readTimeoutMs = 3500)
            if (probe.body != null) {
                val parsed = parseDvrM3u(base, probe.body)
                if (parsed.isNotEmpty()) {
                    combined += parsed
                    successfulSources += "M3U ${parsed.size}"
                }
            } else if (firstError == null) {
                firstError = probe.error
            }
        }

        val candidates = linkedSetOf<String>()
        if (preferredDeviceId.isNotBlank()) candidates += preferredDeviceId

        val deviceProbe = getJson("$base/devices", connectTimeoutMs = 1800, readTimeoutMs = 2500)
        if (deviceProbe.body != null) candidates.addAll(parseDeviceNames(deviceProbe.body))
        else if (firstError == null) firstError = deviceProbe.error
        if (!candidates.contains("ANY")) candidates += "ANY"

        for (device in candidates) {
            val encodedDevice = encodeURIComponent(device)
            val probe = getJson("$base/devices/$encodedDevice/channels", connectTimeoutMs = 2500, readTimeoutMs = 3500)
            if (probe.error != null) { if (firstError == null) firstError = probe.error; continue }
            val parsed = parseDvrChannels(base, device, probe.body ?: "")
            if (parsed.isNotEmpty()) {
                combined += parsed
                successfulSources += "$device ${parsed.size}"
            }
        }

        val lineupGroups = loadDvrLineupMap(base)
        val withLineupGroups = if (lineupGroups.isNotEmpty()) combined.map { attachLineupGroups(it, lineupGroups) } else combined
        val deduped = withLineupGroups
            .distinctBy { dedupeDvrKey(it) }
            .sortedWith(compareBy<ChannelItem>({ channelSortNumber(it.number) }, { it.name.lowercase(Locale.US) }))

        if (deduped.isNotEmpty()) {
            val savedDevice = candidates.firstOrNull { !it.equals("ANY", ignoreCase = true) } ?: preferredDeviceId
            val label = successfulSources.distinct().joinToString(" + ").ifBlank { "Channels DVR" }
            return DvrResult(deduped, "Channels DVR connected • ${deduped.size} channels found ($label)", savedDevice)
        }

        return when {
            firstError != null -> DvrResult(emptyList(), "Channels DVR failed: $firstError")
            preferredDeviceId.isNotBlank() -> DvrResult(emptyList(), "Channels DVR connected, but no channels were returned for saved device '$preferredDeviceId'.")
            else -> DvrResult(emptyList(), "Channels DVR connected, but no channels were returned.")
        }
    }

    fun loadXtreamChannels(server: String, user: String, pass: String): Pair<List<ChannelItem>, String> {
        val base = server.trim().trimEnd('/')
        if (base.isBlank() || user.isBlank() || pass.isBlank()) {
            return emptyList<ChannelItem>() to "Xtream is missing server or credentials."
        }
        val probe = getJson("$base/player_api.php?username=$user&password=$pass&action=get_live_streams")
        if (probe.error != null) {
            return emptyList<ChannelItem>() to "Xtream failed: ${probe.error}"
        }
        val json = probe.body ?: return emptyList<ChannelItem>() to "Xtream returned no data."
        val arr = try {
            JSONArray(json)
        } catch (_: Exception) {
            return emptyList<ChannelItem>() to "Xtream returned invalid JSON."
        }
        val items = mutableListOf<ChannelItem>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val id = obj.optString("stream_id")
            if (id.isBlank()) continue
            val ext = obj.optString("container_extension").ifBlank { "m3u8" }
            val name = obj.optString("name").ifBlank { "Channel $id" }
            val category = obj.optString("category_name").trim()
            val epgId = obj.optString("epg_channel_id").ifBlank { obj.optString("epg_id") }.trim()
            val channelNum = obj.optString("num").trim()
            val url = "$base/live/$user/$pass/$id.$ext"
            val iconUrl = obj.optString("stream_icon").trim()
            items += ChannelItem(
                name = name,
                url = url,
                source = "Xtream/IPTV",
                debug = buildString { append("streamId=").append(id).append(" • ext=").append(ext); if (epgId.isNotBlank()) append(" • tvgId=").append(epgId) },
                groups = listOfNotNull(category.takeIf { it.isNotBlank() }, "IPTV"),
                number = channelNum,
                iconUrl = iconUrl
            )
        }
        return if (items.isEmpty()) {
            emptyList<ChannelItem>() to "Xtream connected, but no channels were returned."
        } else {
            items to "Xtream connected • ${items.size} channels found"
        }
    }

    fun loadM3uChannels(m3uUrl: String): Pair<List<ChannelItem>, String> {
        val normalized = m3uUrl.trim()
        if (normalized.isBlank()) return emptyList<ChannelItem>() to "M3U URL missing."
        val probe = getText(normalized)
        if (probe.error != null) return emptyList<ChannelItem>() to "M3U failed: ${probe.error}"
        val body = probe.body ?: return emptyList<ChannelItem>() to "M3U returned no data."
        val lines = body.lines()
        val items = mutableListOf<ChannelItem>()
        var currentMeta = ""
        for (rawLine in lines) {
            val line = rawLine.trim()
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> currentMeta = line
                line.isBlank() || line.startsWith("#") -> Unit
                currentMeta.isNotBlank() -> {
                    val name = currentMeta.substringAfter(',').trim().ifBlank { "IPTV Channel ${items.size + 1}" }
                    val group = Regex("""group-title="([^"]+)""", RegexOption.IGNORE_CASE).find(currentMeta)?.groupValues?.getOrNull(1).orEmpty()
                    val number = Regex("""tvg-chno="([^"]+)""", RegexOption.IGNORE_CASE).find(currentMeta)?.groupValues?.getOrNull(1).orEmpty()
                    val tvgId = Regex("""tvg-id="([^"]+)""", RegexOption.IGNORE_CASE).find(currentMeta)?.groupValues?.getOrNull(1).orEmpty()
                    val tvgName = Regex("""tvg-name="([^"]+)""", RegexOption.IGNORE_CASE).find(currentMeta)?.groupValues?.getOrNull(1).orEmpty()
                    val iconUrl = Regex("""tvg-logo="([^"]+)""", RegexOption.IGNORE_CASE).find(currentMeta)?.groupValues?.getOrNull(1).orEmpty()
                    val debug = buildString {
                        append("m3u")
                        if (group.isNotBlank()) append(" • group=").append(group)
                        if (tvgId.isNotBlank()) append(" • tvgId=").append(tvgId)
                        if (tvgName.isNotBlank()) append(" • tvgName=").append(tvgName)
                        if (number.isNotBlank()) append(" • ch=").append(number)
                    }
                    items += ChannelItem(
                        name = name,
                        url = line,
                        source = "M3U/IPTV",
                        debug = debug,
                        groups = listOfNotNull(group.takeIf { it.isNotBlank() }, "IPTV"),
                        number = number,
                        iconUrl = iconUrl
                    )
                    currentMeta = ""
                }
            }
        }
        return if (items.isEmpty()) emptyList<ChannelItem>() to "M3U connected, but no channels were returned."
        else items to "M3U connected • ${items.size} channels found"
    }

    fun resolveDvrPlayback(baseUrl: String, preferredDeviceId: String = ""): ChannelItem? {
        return loadDvrChannels(baseUrl, preferredDeviceId).channels.firstOrNull()
    }

    private fun loadDvrLineupMap(base: String): Map<String, Set<String>> {
        val result = linkedMapOf<String, MutableSet<String>>()
        val probe = getJson("$base/dvr/lineups")
        val body = probe.body ?: return emptyMap()
        try {
            if (body.trim().startsWith("[")) {
                val arr = JSONArray(body)
                for (i in 0 until arr.length()) collectLineupObject(arr.optJSONObject(i), result)
            } else {
                val root = JSONObject(body)
                val arr = root.optJSONArray("lineups") ?: root.optJSONArray("Lineups") ?: root.optJSONArray("items")
                if (arr != null) {
                    for (i in 0 until arr.length()) collectLineupObject(arr.optJSONObject(i), result)
                } else {
                    collectLineupObject(root, result)
                }
            }
        } catch (_: Exception) {
        }
        return result
    }

    private fun collectLineupObject(obj: JSONObject?, result: MutableMap<String, MutableSet<String>>) {
        if (obj == null) return
        val lineupName = sequenceOf("name", "Name", "title", "Title", "group", "Group")
            .map { obj.optString(it).trim() }
            .firstOrNull { it.isNotBlank() }
            ?: return
        val members = result.getOrPut(lineupName) { linkedSetOf() }
        fun collectAny(value: Any?) {
            when (value) {
                is JSONArray -> for (i in 0 until value.length()) collectAny(value.opt(i))
                is JSONObject -> {
                    listOf("GuideNumber", "guideNumber", "Number", "number", "id", "ID", "GuideName", "guideName", "Name", "name").forEach { key ->
                        val token = value.optString(key).trim()
                        if (token.isNotBlank()) members += token.lowercase(Locale.US)
                    }
                    value.keys().forEach { key ->
                        if (key.equals("name", true) || key.equals("title", true)) return@forEach
                        collectAny(value.opt(key))
                    }
                }
                is String -> {
                    val cleaned = value.trim()
                    if (cleaned.isNotBlank() && !cleaned.startsWith("http")) members += cleaned.lowercase(Locale.US)
                }
                is Number -> members += value.toString().lowercase(Locale.US)
            }
        }
        listOf("channels", "Channels", "channelNumbers", "stations", "members", "items").forEach { key -> collectAny(obj.opt(key)) }
    }

    private fun parseDeviceNames(json: String): List<String> {
        val names = linkedSetOf<String>()
        fun addName(raw: String?) {
            val value = raw?.trim().orEmpty()
            if (value.isNotBlank()) names += value
        }
        fun addFromObject(obj: JSONObject?) {
            if (obj == null) return
            addName(obj.optString("Name"))
            addName(obj.optString("name"))
            addName(obj.optString("FriendlyName"))
            addName(obj.optString("friendlyName"))
            addName(obj.optString("DeviceID"))
            addName(obj.optString("deviceId"))
            addName(obj.optString("ID"))
            addName(obj.optString("id"))
        }
        try {
            if (json.trim().startsWith("[")) {
                val arr = JSONArray(json)
                for (i in 0 until arr.length()) {
                    when (val item = arr.opt(i)) {
                        is JSONObject -> addFromObject(item)
                        is String -> addName(item)
                    }
                }
            } else {
                val root = JSONObject(json)
                val arr = root.optJSONArray("devices")
                    ?: root.optJSONArray("Devices")
                    ?: root.optJSONArray("results")
                    ?: root.optJSONArray("Results")
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        when (val item = arr.opt(i)) {
                            is JSONObject -> addFromObject(item)
                            is String -> addName(item)
                        }
                    }
                }
                addFromObject(root)
            }
        } catch (_: Exception) {
        }
        return names.filterNot { it.equals("ANY", ignoreCase = true) }
    }

    private fun parseDvrChannels(base: String, device: String, json: String): List<ChannelItem> {
        val out = mutableListOf<ChannelItem>()
        try {
            val arr = if (json.trim().startsWith("[")) {
                JSONArray(json)
            } else {
                val root = JSONObject(json)
                root.optJSONArray("channels") ?: root.optJSONArray("Channels") ?: JSONArray()
            }

            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue

                val guideNumber = obj.optString("GuideNumber")
                    .ifBlank { obj.optString("Number") }
                    .ifBlank { obj.optString("number") }

                val id = obj.optString("id")
                    .ifBlank { obj.optString("ID") }
                    .ifBlank { guideNumber }

                val name = obj.optString("GuideName")
                    .ifBlank { obj.optString("Name") }
                    .ifBlank { obj.optString("name") }
                    .ifBlank { obj.optString("channel") }
                    .ifBlank { "Channel ${if (guideNumber.isNotBlank()) guideNumber else id}" }

                val playbackKey = guideNumber.ifBlank { id }
                if (playbackKey.isBlank()) continue

                val encodedDevice = encodeURIComponent(device)
                val encodedChannel = encodeURIComponent(playbackKey)
                val url = "$base/devices/$encodedDevice/channels/$encodedChannel/stream.mpg?format=ts&codec=copy"

                val groups = mutableListOf<String>()
                val lowerName = name.lowercase(Locale.US)
                when {
                    "sport" in lowerName || "espn" in lowerName || "fox sports" in lowerName -> groups += "Sports"
                    "news" in lowerName || "cnn" in lowerName || "fox" in lowerName || "msnbc" in lowerName || "cspan" in lowerName -> groups += "News"
                    "kid" in lowerName || "cartoon" in lowerName || "disney" in lowerName || "nick" in lowerName -> groups += "Kids"
                    "movie" in lowerName || "cinemax" in lowerName || "hbo" in lowerName || "starz" in lowerName || "showtime" in lowerName -> groups += "Movies"
                }
                groups += "Channels DVR"

                val iconUrl = sequenceOf(
                    obj.optString("ImageURL").trim(),
                    obj.optString("Image").trim(),
                    obj.optString("imageUrl").trim(),
                    obj.optString("LogoURL").trim(),
                    obj.optString("logoUrl").trim(),
                    obj.optString("logo").trim()
                ).firstOrNull { it.isNotBlank() }.orEmpty()
                val debug = buildString {
                    append("device=")
                    append(device)
                    if (guideNumber.isNotBlank()) append(" • guide=").append(guideNumber)
                    if (id.isNotBlank()) append(" • id=").append(id)
                    append(" • playKey=")
                    append(playbackKey)
                    if (groups.isNotEmpty()) append(" • groups=").append(groups.joinToString("/"))
                }
                out += ChannelItem(name, url, "Channels DVR", debug, groups.distinct(), guideNumber, iconUrl)
            }
        } catch (_: Exception) {
        }
        return out
    }


    private fun parseDvrM3u(base: String, body: String): List<ChannelItem> {
        val items = mutableListOf<ChannelItem>()
        var currentMeta = ""
        body.lineSequence().forEach { raw ->
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> currentMeta = line
                line.isBlank() || line.startsWith("#") -> Unit
                currentMeta.isNotBlank() -> {
                    val name = currentMeta.substringAfter(',', missingDelimiterValue = "").trim().ifBlank { "DVR Channel ${items.size + 1}" }
                    val group = extinfAttr(currentMeta, "group-title")
                    val tvgName = extinfAttr(currentMeta, "tvg-name")
                    val chno = extinfAttr(currentMeta, "channel-number").ifBlank { extinfAttr(currentMeta, "tvg-chno") }.ifBlank { extinfAttr(currentMeta, "ch-number") }
                    val tvgId = extinfAttr(currentMeta, "channel-id").ifBlank { extinfAttr(currentMeta, "tvg-id") }.ifBlank { extinfAttr(currentMeta, "tvc-guide-stationid") }
                    val iconUrl = extinfAttr(currentMeta, "tvg-logo").ifBlank { extinfAttr(currentMeta, "logo") }
                    val groups = splitGroups(group).toMutableList()
                    val debug = buildString {
                        append("m3u")
                        if (tvgName.isNotBlank()) append(" • tvg=").append(tvgName)
                        if (tvgId.isNotBlank()) append(" • tvgId=").append(tvgId)
                        if (group.isNotBlank()) append(" • group=").append(group)
                        if (chno.isNotBlank()) append(" • ch=").append(chno)
                    }
                    items += ChannelItem(
                        name = if (tvgName.isNotBlank()) tvgName else name,
                        url = line,
                        source = "Channels DVR",
                        debug = debug,
                        groups = (groups + "Channels DVR").distinct(),
                        number = chno,
                        iconUrl = iconUrl
                    )
                    currentMeta = ""
                }
            }
        }
        return items.distinctBy { it.name + "|" + it.url }
    }

    private fun extinfAttr(meta: String, key: String): String {
        return Regex("""(?:^|\s)${Regex.escape(key)}="([^"]*)""", RegexOption.IGNORE_CASE)
            .find(meta)
            ?.groupValues
            ?.getOrNull(1)
            ?.trim()
            .orEmpty()
    }

    private fun splitGroups(raw: String): List<String> {
        return raw.split(";", "|", ",")
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinctBy { it.lowercase(Locale.US) }
    }

    private fun dedupeDvrKey(item: ChannelItem): String {
        val number = item.number.trim().lowercase(Locale.US)
        val url = item.url.trim().lowercase(Locale.US)
        val name = item.name.trim().lowercase(Locale.US)
        return when {
            number.isNotBlank() -> "num:$number"
            url.isNotBlank() -> "url:$url"
            else -> "name:$name"
        }
    }

    private fun channelSortNumber(value: String): Double {
        return Regex("""\d+(?:\.\d+)?""").find(value)?.value?.toDoubleOrNull() ?: Double.MAX_VALUE
    }

    private fun attachLineupGroups(item: ChannelItem, lineupGroups: Map<String, Set<String>>): ChannelItem {
        val keys = linkedSetOf(item.number.lowercase(Locale.US), item.name.lowercase(Locale.US))
        Regex("""(?:id|guide|ch|tvgId)=([^ •]+)""", RegexOption.IGNORE_CASE).findAll(item.debug).forEach { keys += it.groupValues[1].lowercase(Locale.US) }
        val extra = lineupGroups.entries
            .filter { (_, members) -> keys.any { key -> key.isNotBlank() && members.contains(key) } }
            .map { it.key }
        return if (extra.isEmpty()) item else item.copy(groups = (extra + item.groups).distinctBy { it.lowercase(Locale.US) })
    }

    private fun getJson(url: String, connectTimeoutMs: Int = 6000, readTimeoutMs: Int = 6000): HttpResult {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = connectTimeoutMs
        connection.readTimeout = readTimeoutMs
        connection.instanceFollowRedirects = true
        connection.requestMethod = "GET"
        return try {
            connection.connect()
            val code = connection.responseCode
            if (code !in 200..299) {
                HttpResult(null, "HTTP $code")
            } else {
                val body = BufferedReader(InputStreamReader(connection.inputStream)).use { it.readText() }
                HttpResult(body, null)
            }
        } catch (e: Exception) {
            HttpResult(null, e.javaClass.simpleName + (e.message?.let { ": $it" } ?: ""))
        } finally {
            connection.disconnect()
        }
    }

    private fun getText(url: String): HttpResult {
        return getJson(url)
    }

    private fun encodeURIComponent(value: String): String = URLEncoder.encode(value, "UTF-8")
}
