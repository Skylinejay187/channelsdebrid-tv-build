package com.channelsdebrid.tv.storage

import android.content.Context
import com.channelsdebrid.tv.settings.StorageSettings
import java.io.File
import java.util.UUID

/** Validates and resolves the storage target that app-timeshift uses. */
class TimeshiftStorageManager(private val context: Context) {
    fun status(storage: StorageSettings): String {
        return when (storage.preferredTarget.lowercase()) {
            "nas" -> validateNas(storage)
            "usb" -> validateLocalPath(storage.usbPath, "USB")
            else -> validateInternal()
        }
    }

    fun resolveLocalBufferDir(storage: StorageSettings): File {
        return when (storage.preferredTarget.lowercase()) {
            "usb" -> File(storage.usbPath.ifBlank { context.cacheDir.absolutePath }, "DebridChannels/timeshift")
            else -> File(context.cacheDir, "timeshift")
        }.apply { mkdirs() }
    }

    private fun validateInternal(): String {
        val dir = File(context.cacheDir, "timeshift").apply { mkdirs() }
        return if (writeTest(dir)) "Timeshift storage ready: Internal" else "Internal timeshift storage is not writable"
    }

    private fun validateLocalPath(path: String, label: String): String {
        if (path.isBlank()) return "$label path is empty"
        val dir = File(path, "DebridChannels/timeshift").apply { mkdirs() }
        return if (writeTest(dir)) "Timeshift storage ready: $label" else "$label timeshift path is not writable"
    }

    private fun validateNas(storage: StorageSettings): String {
        if (storage.nasHost.isBlank() || storage.nasPath.isBlank()) return "NAS path is not locked yet"
        if (storage.nasUsername.isBlank()) return "NAS username is required"
        val browser = SmbNasBrowser(storage.nasHost, storage.nasUsername, storage.nasPassword)
        return if (browser.ensureWritable(storage.nasPath)) {
            "Timeshift storage ready: NAS ${storage.nasPath}"
        } else {
            "NAS login or write test failed. Check username/password and folder permissions."
        }
    }

    private fun writeTest(dir: File): Boolean = runCatching {
        val file = File(dir, ".debrid_channels_write_test_${UUID.randomUUID()}.tmp")
        file.writeText("ok")
        val ok = file.exists() && file.length() >= 2L
        file.delete()
        ok
    }.getOrDefault(false)
}
