# NewtoOld v2.8.26.39 Branded Animated Startup Audit

Base used: `NewtoOld_v2.8.26.39_SHARP_BASE_LOW_END_PERFORMANCE_MODE_FULL_PROJECT.zip`

Scope: branding-only app update.

Preserved:
- v2.8.26.39 sharp renderer base
- Low-end Android TV performance mode
- Live TV behavior, loader paths, Gracenote support, provider-direct IPTV architecture
- BunnyCDN artwork architecture / backend compatibility
- Row scrolling/focus and Pro Layout Editor behavior
- Cutout work remains paused/backlogged

Changed:
- Replaced all mipmap launcher icons (`mdpi`, `hdpi`, `xhdpi`, `xxhdpi`, `xxxhdpi`)
- Replaced adaptive icon foreground/background resources
- Replaced Android TV launcher banner (`@drawable/banner`)
- Replaced splash/startup branding with a 16:9 no-crop cinematic loading screen
- Rewired `StartupActivity` to use the new full-screen image plus animated glow/loading bar
- Updated app version marker to `NewtoOld_v2.8.26.39_SHARP_BASE_BRANDED_ANIMATED_STARTUP_FULL_PROJECT`
- Added logcat marker: `STARTUP_BRANDING_ACTIVE`

Install note:
Android TV launchers cache icons and banners aggressively. If the icon still appears old after installing over a prior build, uninstall the old app once or clear launcher cache before reinstalling.
