package com.channelsdebrid.tv

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class StartupActivity : AppCompatActivity() {
    private companion object {
        private const val TAG = "DebridChannels"
        private const val STARTUP_DELAY_MS = 1650L
        private const val BUILD_MARKER = "NewtoOld_v2.8.26.39_BRANDED_ANIMATED_STARTUP_CLEAN_PASS"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i(TAG, "STARTUP_BRANDING_ACTIVE: build=$BUILD_MARKER icon=full-replaced splash=16x9-fit animation=glow-bar")

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        val splash = ImageView(this).apply {
            setImageResource(resources.getIdentifier("startup_loading_brand", "drawable", packageName))
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = false
            alpha = 0f
        }
        root.addView(
            splash,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
                Gravity.CENTER
            )
        )

        val glow = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0x00000000, 0x88FF7A22.toInt(), 0x00000000)
            ).apply { cornerRadius = dp(18).toFloat() }
            alpha = 0f
        }
        root.addView(
            glow,
            FrameLayout.LayoutParams(dp(360), dp(5), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = dp(86)
            }
        )

        val progressBack = View(this).apply {
            background = GradientDrawable().apply {
                setColor(0x55222222)
                cornerRadius = dp(3).toFloat()
            }
            alpha = 0f
        }
        val progressFill = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xFF7A2A10.toInt(), 0xFFFF7A22.toInt(), 0xFFE0B071.toInt())
            ).apply { cornerRadius = dp(3).toFloat() }
            alpha = 0f
            scaleX = 0.05f
            pivotX = 0f
        }
        val barParams = FrameLayout.LayoutParams(dp(380), dp(6), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(82)
        }
        root.addView(progressBack, barParams)
        root.addView(progressFill, FrameLayout.LayoutParams(dp(380), dp(6), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(82)
        })

        val proof = TextView(this).apply {
            text = "BRANDED STARTUP • v2.8.26.39"
            textSize = 10f
            letterSpacing = 0.12f
            setTextColor(0x55FFFFFF)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            alpha = 0f
        }
        root.addView(proof, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp(28), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(18) })

        setContentView(root)

        ObjectAnimator.ofFloat(splash, "alpha", 0f, 1f).apply { duration = 420; start() }
        ObjectAnimator.ofFloat(splash, "scaleX", 1.018f, 1f).apply { duration = 1100; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(splash, "scaleY", 1.018f, 1f).apply { duration = 1100; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(progressBack, "alpha", 0f, 1f).apply { duration = 360; startDelay = 260; start() }
        ObjectAnimator.ofFloat(progressFill, "alpha", 0f, 1f).apply { duration = 360; startDelay = 260; start() }
        ObjectAnimator.ofFloat(glow, "alpha", 0f, 0.75f, 0.25f, 0.65f).apply { duration = 1250; startDelay = 260; start() }
        ObjectAnimator.ofFloat(glow, "translationX", -dp(160).toFloat(), dp(160).toFloat()).apply { duration = 1250; startDelay = 260; interpolator = LinearInterpolator(); start() }
        ObjectAnimator.ofFloat(proof, "alpha", 0f, 1f, 0f).apply { duration = 1100; startDelay = 350; start() }
        ValueAnimator.ofFloat(0.05f, 1f).apply {
            duration = 1180
            startDelay = 310
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { progressFill.scaleX = it.animatedValue as Float }
            start()
        }

        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }, STARTUP_DELAY_MS)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
