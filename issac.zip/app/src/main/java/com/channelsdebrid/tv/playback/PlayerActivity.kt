package com.channelsdebrid.tv.playback

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.bumptech.glide.Glide
import com.channelsdebrid.tv.R
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@UnstableApi
class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var backdropArtView: ImageView

    private lateinit var topOverlay: View
    private lateinit var titleView: TextView
    private lateinit var statusView: TextView
    private lateinit var channelBadgeView: TextView
    private lateinit var mediaLogoView: ImageView
    private lateinit var mediaMetaView: TextView
    private lateinit var clockView: TextView
    private lateinit var nowTimeView: TextView
    private lateinit var nextView: TextView
    private lateinit var progressView: ProgressBar

    private lateinit var guideOverlay: View
    private lateinit var guideClockView: TextView
    private lateinit var guideTitleView: TextView
    private lateinit var guideMetaView: TextView
    private lateinit var guideHintView: TextView
    private lateinit var guideInfoLogoView: TextView
    private lateinit var guideList: LinearLayout
    private lateinit var guideScroller: HorizontalScrollView

    private lateinit var vodOverlay: View
    private lateinit var vodLogoView: ImageView
    private lateinit var vodTitleView: TextView
    private lateinit var vodMetaTopView: TextView
    private lateinit var vodSourceTopView: TextView
    private lateinit var vodClockView: TextView
    private lateinit var vodCurrentTimeView: TextView
    private lateinit var vodDurationView: TextView
    private lateinit var vodProgressView: ProgressBar
    private lateinit var vodPlayPauseButton: TextView
    private lateinit var vodSubtitleButton: TextView
    private lateinit var vodAudioButton: TextView
    private lateinit var vodEpisodeButton: TextView
    private lateinit var vodZoomButton: TextView
    private lateinit var vodSettingsButton: TextView

    private val overlayHandler = Handler(Looper.getMainLooper())
    private val hideOverlayRunnable = Runnable {
        if (player?.isPlaying == true) {
            if (isVodMode) {
                if (!vodOverlay.hasFocus()) {
                    vodOverlay.visibility = View.GONE
                }
            } else if (!guideOverlay.isVisible) {
                topOverlay.visibility = View.GONE
            }
        }
    }
    private val hideGuideRunnable = Runnable {
        if (player?.isPlaying == true) hideGuideOverlay()
    }
    private val progressRunnable = object : Runnable {
        override fun run() {
            updateClockViews()
            if (isVodMode) updateVodProgress() else bindProgramMeta(channels.getOrNull(currentIndex))
            overlayHandler.postDelayed(this, 800)
        }
    }

    private var channels: List<GuideChannel> = emptyList()
    private var currentIndex: Int = 0
    private var selectedGuideIndex: Int = 0
    private var isVodMode: Boolean = true

    private var streamUrl: String = ""
    private var titleText: String = ""
    private var sourceLabel: String = ""
    private var debugLabel: String = ""
    private var mediaLogoUrl: String? = null
    private var mediaBackdropUrl: String? = null
    private var mediaMeta: String = ""
    private var mediaType: String = "movie"
    private var seriesExternalId: String? = null
    private var seriesTitle: String? = null
    private var posterUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_player)

        playerView = findViewById(R.id.playerView)
        backdropArtView = findViewById(R.id.playerBackdropArt)

        topOverlay = findViewById(R.id.playerTopOverlay)
        titleView = findViewById(R.id.playerTitle)
        statusView = findViewById(R.id.playerStatus)
        channelBadgeView = findViewById(R.id.playerChannelBadge)
        mediaLogoView = findViewById(R.id.playerMediaLogo)
        mediaMetaView = findViewById(R.id.playerMediaMeta)
        clockView = findViewById(R.id.playerClock)
        nowTimeView = findViewById(R.id.playerNowTime)
        nextView = findViewById(R.id.playerNext)
        progressView = findViewById(R.id.playerProgress)

        guideOverlay = findViewById(R.id.guideOverlay)
        guideClockView = findViewById(R.id.guideClock)
        guideTitleView = findViewById(R.id.guideTitle)
        guideMetaView = findViewById(R.id.guideMeta)
        guideHintView = findViewById(R.id.guideHint)
        guideInfoLogoView = findViewById(R.id.guideInfoLogo)
        guideList = findViewById(R.id.guideChannelList)
        guideScroller = findViewById(R.id.guideScroller)

        vodOverlay = findViewById(R.id.vodOverlay)
        vodLogoView = findViewById(R.id.vodMediaLogo)
        vodTitleView = findViewById(R.id.vodTitle)
        vodMetaTopView = findViewById(R.id.vodMetaTop)
        vodSourceTopView = findViewById(R.id.vodSourceTop)
        vodClockView = findViewById(R.id.vodClock)
        vodCurrentTimeView = findViewById(R.id.vodCurrentTime)
        vodDurationView = findViewById(R.id.vodDuration)
        vodProgressView = findViewById(R.id.vodProgress)
        vodPlayPauseButton = findViewById(R.id.vodPlayPause)
        vodSubtitleButton = findViewById(R.id.vodSubtitle)
        vodAudioButton = findViewById(R.id.vodAudio)
        vodEpisodeButton = findViewById(R.id.vodEpisode)
        vodZoomButton = findViewById(R.id.vodZoom)
        vodSettingsButton = findViewById(R.id.vodSettings)

        playerView.useController = false
        playerView.controllerAutoShow = false

        streamUrl = intent.getStringExtra(EXTRA_STREAM_URL).orEmpty()
        titleText = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        sourceLabel = intent.getStringExtra(EXTRA_SOURCE_LABEL).orEmpty()
        debugLabel = intent.getStringExtra(EXTRA_DEBUG_LABEL).orEmpty()
        mediaLogoUrl = intent.getStringExtra(EXTRA_MEDIA_LOGO_URL)
        posterUrl = intent.getStringExtra(EXTRA_MEDIA_POSTER_URL)
        mediaBackdropUrl = intent.getStringExtra(EXTRA_MEDIA_BACKDROP_URL)
        mediaMeta = intent.getStringExtra(EXTRA_MEDIA_META).orEmpty()
        mediaType = intent.getStringExtra(EXTRA_MEDIA_TYPE).orEmpty().ifBlank { "movie" }
        seriesExternalId = intent.getStringExtra(EXTRA_SERIES_EXTERNAL_ID)
        seriesTitle = intent.getStringExtra(EXTRA_SERIES_TITLE)

        channels = decodeChannels(intent.getStringExtra(EXTRA_CHANNELS_JSON))
        currentIndex = intent.getIntExtra(EXTRA_CHANNEL_INDEX, 0).coerceIn(0, (channels.size - 1).coerceAtLeast(0))
        selectedGuideIndex = currentIndex
        isVodMode = channels.isEmpty()

        if (streamUrl.isBlank()) {
            Toast.makeText(this, "No stream URL available", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        setupModeUi()
        initializePlayer(streamUrl)
        overlayHandler.post(progressRunnable)
    }

    private fun setupModeUi() {
        updateClockViews()
        if (isVodMode) {
            topOverlay.visibility = View.GONE
            guideOverlay.visibility = View.GONE
            vodOverlay.visibility = View.VISIBLE
            setupVodOverlay()
        } else {
            vodOverlay.visibility = View.GONE
            topOverlay.visibility = View.VISIBLE
            titleView.text = if (titleText.isBlank()) channels.getOrNull(currentIndex)?.name ?: "Playback" else titleText
            statusView.text = if (sourceLabel.isBlank()) "Favorites" else sourceLabel
            channelBadgeView.text = (channels.getOrNull(currentIndex)?.name ?: titleView.text.toString()).take(6).uppercase(Locale.US)
            mediaMetaView.text = mediaMeta
            loadLogoInto(mediaLogoView, mediaLogoUrl)
            bindProgramMeta(channels.getOrNull(currentIndex))
            renderGuideOverlay()
            scheduleOverlayHide()
        }
        if (!mediaBackdropUrl.isNullOrBlank()) {
            backdropArtView.visibility = View.VISIBLE
            Glide.with(this).load(mediaBackdropUrl).into(backdropArtView)
        } else if (!posterUrl.isNullOrBlank()) {
            backdropArtView.visibility = View.VISIBLE
            Glide.with(this).load(posterUrl).into(backdropArtView)
        }
    }

    private fun setupVodOverlay() {
        loadLogoInto(vodLogoView, mediaLogoUrl)
        vodTitleView.text = titleText.ifBlank { "Playback" }
        vodTitleView.visibility = if (mediaLogoUrl.isNullOrBlank()) View.VISIBLE else View.GONE
        vodMetaTopView.text = mediaMeta.ifBlank { sourceLabel.ifBlank { "Ready to play" } }
        vodSourceTopView.text = sourceLabel.ifBlank { "Direct stream ready" }
        vodEpisodeButton.visibility = if (mediaType == "series" && !seriesExternalId.isNullOrBlank()) View.VISIBLE else View.GONE
        vodPlayPauseButton.setOnClickListener { togglePlayback() }
        vodSubtitleButton.setOnClickListener { showSubtitleDialog() }
        vodAudioButton.setOnClickListener { showAudioDialog() }
        vodEpisodeButton.setOnClickListener { openEpisodePicker() }
        vodZoomButton.setOnClickListener { showZoomDialog() }
        vodSettingsButton.setOnClickListener { showSettingsDialog() }
        vodPlayPauseButton.requestFocus()
        updateVodProgress()
    }

    private fun initializePlayer(url: String) {
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("ChannelsDebridTV/1.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10000)
            .setReadTimeoutMs(20000)

        val mediaSourceFactory = DefaultMediaSourceFactory(httpFactory)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(5000, 15000, 2500, 5000)
            .build()

        val exoPlayer = ExoPlayer.Builder(this)
            .setMediaSourceFactory(mediaSourceFactory)
            .setLoadControl(loadControl)
            .setSeekBackIncrementMs(10000)
            .setSeekForwardIncrementMs(10000)
            .build()
            .also { player = it }

        playerView.player = exoPlayer
        playerView.keepScreenOn = true

        val mediaItemBuilder = MediaItem.Builder().setUri(Uri.parse(url))
        if (looksLikeTsStream(url)) mediaItemBuilder.setMimeType(MimeTypes.VIDEO_MP2T)
        exoPlayer.setMediaItem(mediaItemBuilder.build())
        exoPlayer.addListener(object : androidx.media3.common.Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == androidx.media3.common.Player.STATE_READY) {
                    if (isVodMode) {
                        vodSourceTopView.text = sourceLabel.ifBlank { "Playing" }
                        updateVodProgress()
                    }
                    scheduleOverlayHide()
                } else {
                    if (isVodMode) {
                        vodOverlay.visibility = View.VISIBLE
                        vodSourceTopView.text = if (sourceLabel.isBlank()) "Buffering…" else "Buffering $sourceLabel…"
                    } else {
                        topOverlay.visibility = View.VISIBLE
                        statusView.text = if (sourceLabel.isBlank()) "Buffering…" else "Buffering $sourceLabel…"
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                if (isVodMode) {
                    vodOverlay.visibility = View.VISIBLE
                    vodSourceTopView.text = buildString {
                        append("Playback error")
                        if (sourceLabel.isNotBlank()) append(" • ").append(sourceLabel)
                    }
                } else {
                    topOverlay.visibility = View.VISIBLE
                    statusView.text = buildString {
                        append("Playback error")
                        if (sourceLabel.isNotBlank()) append(" • ").append(sourceLabel)
                        if (debugLabel.isNotBlank()) append("\n").append(debugLabel)
                    }
                    showGuideOverlay()
                }
            }

            override fun onTracksChanged(tracks: Tracks) {
                updateVodButtonLabels(tracks)
            }
        })
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        if (isVodMode) return handleVodKeys(event) || super.dispatchKeyEvent(event)
        return handleLiveKeys(event) || super.dispatchKeyEvent(event)
    }

    private fun handleVodKeys(event: KeyEvent): Boolean {
        when (event.keyCode) {
            KeyEvent.KEYCODE_BACK -> {
                if (vodOverlay.isVisible) return false
                vodOverlay.visibility = View.VISIBLE
                vodPlayPauseButton.requestFocus()
                scheduleOverlayHide()
                return true
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                if (!vodOverlay.isVisible) {
                    vodOverlay.visibility = View.VISIBLE
                    vodPlayPauseButton.requestFocus()
                    scheduleOverlayHide()
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (!vodOverlay.isVisible) {
                    vodOverlay.visibility = View.VISIBLE
                    vodPlayPauseButton.requestFocus()
                    scheduleOverlayHide()
                    return true
                }
            }
        }
        if (vodOverlay.isVisible) scheduleOverlayHide()
        return false
    }

    private fun handleLiveKeys(event: KeyEvent): Boolean {
        when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (!guideOverlay.isVisible) {
                    selectedGuideIndex = currentIndex
                    showGuideOverlay()
                }
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (guideOverlay.isVisible) {
                    moveGuideSelection(-1)
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (guideOverlay.isVisible) {
                    moveGuideSelection(1)
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_BACK -> {
                if (guideOverlay.isVisible) {
                    hideGuideOverlay()
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                if (guideOverlay.isVisible) {
                    playSelectedChannel()
                    hideGuideOverlay()
                } else {
                    topOverlay.visibility = View.VISIBLE
                    scheduleOverlayHide()
                }
                return true
            }
        }
        if (!guideOverlay.isVisible) {
            topOverlay.visibility = View.VISIBLE
            scheduleOverlayHide()
        }
        return false
    }

    private fun togglePlayback() {
        val target = player ?: return
        if (target.isPlaying) {
            target.pause()
            vodPlayPauseButton.text = "Play"
            vodSourceTopView.text = "Paused"
            vodOverlay.visibility = View.VISIBLE
        } else {
            target.play()
            vodPlayPauseButton.text = "Pause"
            vodSourceTopView.text = sourceLabel.ifBlank { "Playing" }
            scheduleOverlayHide()
        }
    }

    private fun showSubtitleDialog() {
        val target = player ?: return
        val options = mutableListOf("Off")
        val languages = mutableListOf<String?>(null)
        collectTrackLanguages(C.TRACK_TYPE_TEXT).forEach { language ->
            options += language ?: "Unknown"
            languages += language
        }
        AlertDialog.Builder(this)
            .setTitle("Subtitles")
            .setItems(options.toTypedArray()) { _, which ->
                val builder = target.trackSelectionParameters.buildUpon()
                if (which == 0) {
                    builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                } else {
                    builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                    builder.setPreferredTextLanguage(languages[which])
                }
                target.trackSelectionParameters = builder.build()
                vodSubtitleButton.text = if (which == 0) "Subtitles" else "Subs: ${options[which]}"
                vodOverlay.visibility = View.VISIBLE
                scheduleOverlayHide()
            }
            .show()
    }

    private fun showAudioDialog() {
        val target = player ?: return
        val options = mutableListOf<String>()
        val languages = mutableListOf<String?>()
        collectTrackLanguages(C.TRACK_TYPE_AUDIO).forEach { language ->
            options += (language ?: "Default")
            languages += language
        }
        if (options.isEmpty()) {
            Toast.makeText(this, "No alternate audio tracks found", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Audio")
            .setItems(options.toTypedArray()) { _, which ->
                val builder = target.trackSelectionParameters.buildUpon()
                builder.setPreferredAudioLanguage(languages[which])
                target.trackSelectionParameters = builder.build()
                vodAudioButton.text = "Audio: ${options[which]}"
                vodOverlay.visibility = View.VISIBLE
                scheduleOverlayHide()
            }
            .show()
    }

    private fun showZoomDialog() {
        val names = arrayOf("Fit", "Fill", "Zoom")
        val modes = intArrayOf(
            AspectRatioFrameLayout.RESIZE_MODE_FIT,
            AspectRatioFrameLayout.RESIZE_MODE_FILL,
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM
        )
        AlertDialog.Builder(this)
            .setTitle("Zoom")
            .setItems(names) { _, which ->
                playerView.resizeMode = modes[which]
                vodZoomButton.text = "Zoom: ${names[which]}"
                vodOverlay.visibility = View.VISIBLE
                scheduleOverlayHide()
            }
            .show()
    }

    private fun showSettingsDialog() {
        val target = player ?: return
        val labels = arrayOf("0.75x", "1.0x", "1.25x", "1.5x")
        val speeds = floatArrayOf(0.75f, 1.0f, 1.25f, 1.5f)
        AlertDialog.Builder(this)
            .setTitle("Playback settings")
            .setItems(labels) { _, which ->
                target.setPlaybackSpeed(speeds[which])
                vodSettingsButton.text = "Settings: ${labels[which]}"
                vodOverlay.visibility = View.VISIBLE
                scheduleOverlayHide()
            }
            .show()
    }

    private fun openEpisodePicker() {
        val seriesId = seriesExternalId ?: return
        startActivity(Intent(this, SeasonEpisodeActivity::class.java)
            .putExtra(SeasonEpisodeActivity.EXTRA_TITLE, seriesTitle ?: titleText)
            .putExtra(SeasonEpisodeActivity.EXTRA_EXTERNAL_ID, seriesId)
            .putExtra(SeasonEpisodeActivity.EXTRA_MEDIA_TYPE, "series")
            .putExtra(SeasonEpisodeActivity.EXTRA_POSTER_URL, posterUrl)
            .putExtra(SeasonEpisodeActivity.EXTRA_BACKDROP_URL, mediaBackdropUrl)
            .putExtra(SeasonEpisodeActivity.EXTRA_LOGO_URL, mediaLogoUrl)
            .putExtra(SeasonEpisodeActivity.EXTRA_ITEM_META, mediaMeta)
        )
    }

    private fun collectTrackLanguages(trackType: Int): List<String?> {
        val currentTracks = player?.currentTracks ?: return emptyList()
        val found = linkedSetOf<String?>()
        currentTracks.groups.forEach { group ->
            if (group.type != trackType) return@forEach
            for (i in 0 until group.length) {
                val format = group.getTrackFormat(i)
                found += format.language
            }
        }
        return found.toList()
    }

    private fun updateVodButtonLabels(tracks: Tracks) {
        val hasText = tracks.groups.any { it.type == C.TRACK_TYPE_TEXT }
        if (!hasText) vodSubtitleButton.text = "Subtitles"
        val audioLanguages = collectTrackLanguages(C.TRACK_TYPE_AUDIO)
        if (audioLanguages.isNotEmpty()) {
            vodAudioButton.text = "Audio"
        }
    }

    private fun updateVodProgress() {
        val target = player ?: return
        val duration = target.duration.coerceAtLeast(0L)
        val position = target.currentPosition.coerceAtLeast(0L)
        vodCurrentTimeView.text = formatDuration(position)
        vodDurationView.text = formatDuration(duration)
        val progress = if (duration > 0) ((position * 1000L) / duration).toInt() else 0
        vodProgressView.progress = progress.coerceIn(0, 1000)
        vodClockView.text = SimpleDateFormat("h:mm a", Locale.US).format(Date())
        vodPlayPauseButton.text = if (target.isPlaying) "Pause" else "Play"
    }

    private fun moveGuideSelection(delta: Int) {
        if (channels.isEmpty()) return
        selectedGuideIndex = (selectedGuideIndex + delta).coerceIn(0, channels.lastIndex)
        renderGuideOverlay()
        scheduleGuideHide()
    }

    private fun showGuideOverlay() {
        topOverlay.visibility = View.VISIBLE
        guideOverlay.visibility = View.VISIBLE
        updateClockViews()
        renderGuideOverlay()
        scheduleGuideHide()
    }

    private fun hideGuideOverlay() {
        overlayHandler.removeCallbacks(hideGuideRunnable)
        guideOverlay.visibility = View.GONE
        scheduleOverlayHide()
    }

    private fun scheduleOverlayHide() {
        overlayHandler.removeCallbacks(hideOverlayRunnable)
        overlayHandler.postDelayed(hideOverlayRunnable, 4300)
    }

    private fun scheduleGuideHide() {
        overlayHandler.removeCallbacks(hideGuideRunnable)
        overlayHandler.postDelayed(hideGuideRunnable, 4500)
    }

    private fun playSelectedChannel() {
        val target = channels.getOrNull(selectedGuideIndex) ?: return
        currentIndex = selectedGuideIndex
        titleView.text = target.name
        statusView.text = target.source.ifBlank { "Favorites" }
        channelBadgeView.text = target.name.take(6).uppercase(Locale.US)
        bindProgramMeta(target)
        val mediaItemBuilder = MediaItem.Builder().setUri(Uri.parse(target.url))
        if (looksLikeTsStream(target.url)) mediaItemBuilder.setMimeType(MimeTypes.VIDEO_MP2T)
        player?.apply {
            setMediaItem(mediaItemBuilder.build())
            prepare()
            playWhenReady = true
        }
    }

    private fun bindProgramMeta(channel: GuideChannel?) {
        val now = Calendar.getInstance()
        val start = now.clone() as Calendar
        start.add(Calendar.MINUTE, -(now.get(Calendar.MINUTE) % 30))
        val end = start.clone() as Calendar
        end.add(Calendar.MINUTE, 30)
        val next = end.clone() as Calendar
        val formatter = SimpleDateFormat("h:mm a", Locale.US)
        nowTimeView.text = "${formatter.format(start.time)} – ${formatter.format(end.time)}"
        val activeName = channel?.name ?: "Live TV"
        titleView.text = activeName
        progressView.progress = (((now.timeInMillis - start.timeInMillis).toDouble() / (end.timeInMillis - start.timeInMillis).toDouble()) * 100).toInt().coerceIn(4, 96)
        nextView.text = "NEXT  ${formatter.format(next.time)}  ${activeName} Up Next"
    }

    private fun renderGuideOverlay() {
        val selected = channels.getOrNull(selectedGuideIndex)
        guideTitleView.text = selected?.name ?: "Live TV Guide"
        guideMetaView.text = selected?.let { "${it.source} • Instant tune enabled" } ?: "Browse channels while video keeps playing"
        guideHintView.text = "LEFT/RIGHT change channel instantly • UP/BACK close"
        guideInfoLogoView.text = (selected?.name ?: "TV").take(2).uppercase(Locale.US)

        guideList.removeAllViews()
        if (channels.isEmpty()) {
            guideList.addView(makeGuideCard("No guide data", false))
            return
        }
        val start = (selectedGuideIndex - 2).coerceAtLeast(0)
        val end = (start + 5).coerceAtMost(channels.lastIndex)
        for (index in start..end) {
            val channel = channels[index]
            guideList.addView(makeGuideCard(channel.name, index == selectedGuideIndex))
        }
        guideScroller.post {
            val focusedChild = guideList.getChildAt((selectedGuideIndex - start).coerceAtLeast(0))
            if (focusedChild != null) {
                val scroll = (focusedChild.left - dp(24)).coerceAtLeast(0)
                guideScroller.smoothScrollTo(scroll, 0)
            }
        }
    }

    private fun makeGuideCard(title: String, selected: Boolean): View {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM or Gravity.START
            background = getDrawable(if (selected) R.drawable.focus_ring_pill_pulse else R.drawable.pill_dark)
            setPadding(dp(18), dp(16), dp(18), dp(16))
            layoutParams = LinearLayout.LayoutParams(dp(240), dp(112)).apply { rightMargin = dp(14) }
        }
        val subtitleView = TextView(this).apply {
            text = "Live now"
            setTextColor(0xFFC8D1DC.toInt())
            textSize = 13f
        }
        val titleView = TextView(this).apply {
            text = title
            setTextColor(0xFFFFFFFF.toInt())
            textSize = if (selected) 20f else 17f
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        container.addView(subtitleView)
        container.addView(titleView)
        return container
    }

    private fun loadLogoInto(view: ImageView, url: String?) {
        if (url.isNullOrBlank()) {
            view.visibility = View.GONE
        } else {
            view.visibility = View.VISIBLE
            Glide.with(this).load(url).into(view)
        }
    }

    private fun updateClockViews() {
        val value = SimpleDateFormat("h:mm a", Locale.US).format(Date())
        clockView.text = value
        guideClockView.text = value
        vodClockView.text = value
    }

    private fun decodeChannels(json: String?): List<GuideChannel> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(json)
            mutableListOf<GuideChannel>().apply {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    add(GuideChannel(obj.optString("name"), obj.optString("url"), obj.optString("source"), obj.optString("debug")))
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun looksLikeTsStream(url: String): Boolean {
        val lower = url.lowercase(Locale.US)
        return lower.contains("format=ts") || lower.endsWith(".ts") || lower.endsWith(".mpg")
    }

    private fun formatDuration(ms: Long): String {
        if (ms <= 0L || ms == C.TIME_UNSET) return "0:00"
        val totalSeconds = ms / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        else String.format(Locale.US, "%d:%02d", minutes, seconds)
    }

    override fun onStart() {
        super.onStart()
        player?.playWhenReady = true
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        overlayHandler.removeCallbacksAndMessages(null)
        playerView.player = null
        player?.release()
        player = null
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    data class GuideChannel(val name: String, val url: String, val source: String, val debug: String)

    companion object {
        const val EXTRA_STREAM_URL = "stream_url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_SOURCE_LABEL = "source_label"
        const val EXTRA_DEBUG_LABEL = "debug_label"
        const val EXTRA_MEDIA_LOGO_URL = "media_logo_url"
        const val EXTRA_MEDIA_POSTER_URL = "media_poster_url"
        const val EXTRA_MEDIA_BACKDROP_URL = "media_backdrop_url"
        const val EXTRA_MEDIA_META = "media_meta"
        const val EXTRA_CHANNELS_JSON = "channels_json"
        const val EXTRA_CHANNEL_INDEX = "channel_index"
        const val EXTRA_MEDIA_TYPE = "media_type"
        const val EXTRA_SERIES_EXTERNAL_ID = "series_external_id"
        const val EXTRA_SERIES_TITLE = "series_title"
    }
}
