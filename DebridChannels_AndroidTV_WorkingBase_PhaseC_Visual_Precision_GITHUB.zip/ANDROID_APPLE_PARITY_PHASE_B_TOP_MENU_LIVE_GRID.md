# Android Apple-Parity Phase B

Base: verified Phase A / NewtoOld v2.8.26.77 functional project.

Changed only the Android Live TV presentation layer and app version metadata.

- Apple v984-style top navigation on Live TV.
- Four-column, three-visible-row 16:9 channel grid.
- Current-program artwork, channel logo/number, title, source name, and progress line.
- Subtle dual focus ring and focused-card scale.
- DPAD: UP from top row opens top menu; LEFT from first column opens channel/category tools; RIGHT from last column opens the existing guide.
- Full-screen playback still uses the existing PlayerActivity and resolver stack.
- Returning from playback restores the selected grid card.
- Existing guide, categories, HDHomeRun, Channels DVR, M3U/XMLTV/Xtream, Media3/VLC, timeshift, and source logic remain in place.

No player or resolver source files were modified.
