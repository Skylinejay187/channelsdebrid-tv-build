# Debrid Channels Android TV — Phase A Functional-Core Audit

## Audited inputs

- Functional Android base: `NewtoOld_v2.8.26.77_V74_HERO_INFO_REBIND_NO_LOGO_HIDE_FULL_PROJECT`
- Apple visual reference: `DebridChannels_v984_V983_BASE_SOURCE_INTELLIGENCE_25_50_LIMIT_FIX_GITHUB`

## Decision

Use the v2.8.26.77 Android project as the production foundation. Do not transplant only playback into the clean Compose shell later. The working app's playback, source resolution, Live TV, guide, settings, storage, and lifecycle code are interconnected and should remain together.

The Apple v984 project is the authoritative visual/behavioral blueprint. Android presentation will be replaced screen by screen while the functional core remains operational.

## Existing Android functional foundation to preserve

### Playback

- `playback/PlayerActivity.kt`
  - Media3 ExoPlayer primary engine
  - HLS/DASH/progressive playback
  - selectable player engine
  - VLC/libVLC fallback through `VlcPlayerBridge`
  - MPV bridge/foundation
  - VOD and Live TV routing
  - audio/subtitle track handling
  - resume/continue-watching persistence
  - timeshift integration
  - device profile and reliability recovery
  - player options, lifecycle cleanup, and remote input
- `StreamingPipelineResolver.kt`
- `PlaybackResolver.kt`
- `PlayerReliabilitySystem.kt`
- `PlayerDeviceProfileSystem.kt`
- `DebridChannelsTimeshiftSession.kt`
- `TimeshiftStorageManager.kt`

These classes must not be rewritten during initial UI parity work.

### Catalogs, search, and metadata

- `UnifiedCatalogRepository.kt`
  - TMDB discovery/search
  - Stremio catalogs and search
  - backend search
  - continue watching
  - related items
  - artwork enrichment and persistent catalog cache
- `MainActivity.kt`
  - mature input-first startup
  - hero and row rendering
  - image/preview cancellation
  - focus restoration
  - row virtualization and artwork prefetch

### Live TV and guide

- `LiveTvActivity.kt`
  - channel load orchestration
  - category filtering
  - guide virtualization
  - focus recovery
  - full-screen player launch and exact channel-window handoff
  - current/next/later program handling
  - preview player
  - guide artwork prewarm and cache
  - catch-up playback
- `LiveSourceResolver.kt`
  - HDHomeRun discovery/manual lineup
  - Channels DVR discovery and channels
  - Xtream
  - M3U
  - XMLTV icon mapping
- `LiveGuideProgramResolver.kt`
  - EPG and program metadata

### Settings and persistence

- `SettingsRepository.kt`
- `AppConfigModels.kt`
- `UiPresetManager.kt`
- `ProfileManager.kt`
- existing SharedPreferences schemas

Existing preference keys and stored values must remain compatible.

### Backend/runtime

The ZIP includes the existing Node/TypeScript backend and Docker files. They remain intact during Android UI parity work.

## Architecture findings

### Strengths

1. The project already builds as one established Android application module.
2. Media3, VLC fallback, debrid resolution, Live TV sources, EPG, storage, and settings are working in one lifecycle.
3. The app already contains substantial DPAD/focus recovery logic.
4. Existing XML/View rendering avoids introducing a second runtime framework during the first parity passes.

### Risks

1. `MainActivity.kt`, `LiveTvActivity.kt`, and `PlayerActivity.kt` are large and combine presentation with behavior.
2. Replacing whole Activities at once would risk playback, focus, guide, and persistence regressions.
3. The current Live TV screen is guide-first; Apple v984 is grid-first with RIGHT opening the guide.
4. Navigation labels and ordering differ between Android and Apple.
5. Existing focus styling and geometry are not close enough to Apple parity.

## Safe migration strategy

### Phase B1 — Shared Apple-parity chrome

Rebuild only the Android top application chrome using the existing View system:

- absolute top-left Debrid Channels wordmark
- Apple tab order and names
- transparent text-first tabs
- selected underline
- no generic orange focus pill
- search and clock on the right
- DPAD DOWN returns to the current screen content

Do not modify repositories, playback, player Activities, Live TV resolver, or guide logic.

### Phase B2 — Live TV grid-first shell

Inside the existing `LiveTvActivity`, add an Apple-style grid surface that consumes the already-loaded `GuideEntry`/channel models:

- four columns
- three visible landscape rows
- Apple v984 card geometry and spacing
- channel/program artwork and text
- focus ring/scale parity
- exact selected channel identity
- RIGHT opens the existing guide implementation
- LEFT opens existing channel/category tools
- Select launches the existing `PlayerActivity`
- Back/return continues to use existing player result and focus state

The existing guide remains the functional guide engine instead of being rewritten.

### Phase B3 — Grid/guide focus contract

- persist channel identity and category
- grid RIGHT -> existing guide
- guide LEFT -> rebuilt grid
- player exit -> exact grid card
- preserve existing Live TV player window serialization

### Later phases

- Home/catalog parity over `MainActivity`
- details parity over `MediaDetailsActivity`
- Source Intelligence parity
- settings parity
- VOD overlay parity while retaining `PlayerActivity` engines

## Apple measurements identified for the first parity pass

### Top menu

From Apple v984 `TopMenuBar`:

- text size: 25
- focused horizontal padding: 22
- unfocused horizontal padding: 12
- focused vertical padding: 9
- unfocused vertical padding: 7
- corner radius: 18
- item/underline vertical spacing: 7
- selected underline: 54 wide, 4 high (`Settings`: 64 wide)
- focused scale: 1.018
- selected text: white
- inactive text: white at approximately 62% opacity
- wordmark position: x 53, y 25 in a 1920×1080 reference canvas
- menu center: approximately 46% of screen width, y 58

### Live TV grid

From Apple v984 `LiveTVScreen`:

- four columns
- normal horizontal spacing: 36
- normal vertical spacing: 34
- grid uses flexible columns across the available content width
- normal card height: 278 in Apple logical layout
- grid-first behavior; guide is a separate state
- selected card must be materialized before focus is assigned

Android dimensions will be density-aware and derived from the 1920×1080 reference, not copied blindly as dp.

## Locked boundaries for the first UI build

Do not change:

- `playback/PlayerActivity.kt`
- `playback/VlcPlayerBridge.kt`
- `playback/StreamingPipelineResolver.kt`
- `playback/PlaybackResolver.kt`
- `playback/PlayerReliabilitySystem.kt`
- `live/LiveSourceResolver.kt`
- `data/LiveGuideProgramResolver.kt`
- `settings/SettingsRepository.kt`
- backend source
- preference keys
- stream extras sent to `PlayerActivity`

## Phase A result

The functional Android ZIP is suitable and preferable as the base. The clean Compose prototype should not become the production base. It may remain a visual experiment only.

The first code-changing build should be Phase B1/B2: Apple-parity top chrome plus a grid-first Live TV presentation that reuses all existing Android Live TV and playback logic.
