# Android / Apple UI Parity — Phase C Visual Precision

Base: verified Phase B working Android project.

Changes are presentation-only:
- Replaced launcher-tile brand in Live TV header with the Debrid Channels wordmark.
- Tightened top-menu typography and spacing to match the Apple v984 screenshots.
- Adjusted grid top padding, exact 16:9 card height, and vertical spacing so three complete rows occupy the viewport without a fourth-row sliver.
- Rebuilt the focus treatment as an overlay ring, preventing the white side wedges/bottom bar seen in Phase B.
- Refined card text, logo tile, scrim, and progress bar scale/color.
- Kept all playback, resolver, guide, IPTV, DVR, storage, and return-focus behavior unchanged.
