# Debrid Channels Android TV

Build: v0.2 ANR ARTWORK SAFE

Marker: `DC_V0_2_1_ANR_ARTWORK_SAFE_FIXED`
Logcat marker: `DC_V0_2_1_ACTIVE`

Base used: `DebridChannels_v6_9_EXACT_HERO_RATING_BADGES_SOURCE.zip` / v0.1 stable baseline.

Purpose: keep v0.1/v6.9 visual behavior, fix launch freeze/ANR risk from artwork loading, keep row navigation stable, and update version tracking for GitHub workflow builds.
