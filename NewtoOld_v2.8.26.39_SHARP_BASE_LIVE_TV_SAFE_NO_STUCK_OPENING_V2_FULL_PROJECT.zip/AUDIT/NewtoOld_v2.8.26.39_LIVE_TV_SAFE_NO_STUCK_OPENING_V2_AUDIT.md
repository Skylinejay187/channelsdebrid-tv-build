# NewtoOld v2.8.26.39 LIVE_TV_SAFE_NO_STUCK_OPENING_V2 Audit

Base: NewtoOld_v2.8.26.39_SHARP_BASE_PRESET_LOCAL_BACKEND_FUTURE_READY_FULL_PROJECT.zip

Cutout work remains paused/backlogged.

Changes:
- Preserved v2.8.26.39 sharp-image renderer as the app base.
- Preserved the bundled DebridChannels_Full_Preset.json asset.
- Changed bundled default preset import so it does not overwrite user Live TV source keys:
  - dvr_*
  - hdhomerun_*
  - xtream_*
  - live_backend_xmltv_guide_url
  - live_backend_user_id
- Did not add or guess any Channels DVR IP address.
- Added Live TV opening overlay auto-hide safeguard so the UI cannot stay permanently stuck on "Opening Live TV".
- Added logcat proof marker: LIVE_TV_SAFE_NO_STUCK_OPENING_V2.

Not changed:
- Live TV renderer/layout logic.
- Pro Layout Editor.
- Row focus/scrolling.
- Backend compatibility.
- Cutout/foreground subject extraction remains disabled/backlogged.

Known note:
- If the previous build already wiped the user's Live TV source preferences, this build preserves future settings but cannot invent the unknown old DVR/M3U/Xtream values. Re-enter or restore source values once if they were already erased.
