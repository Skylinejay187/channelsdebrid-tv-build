# NewtoOldv0.4 — Live TV Logic + XMLTV + DVR Auto-Detect Hard Removal

Base used: NewtoOldv0.3_REAL_WIRING_FIX.

## What changed
- Hard-disabled Channels DVR auto-detect at every discovered path:
  - Settings default now forces `autoDetect=false`.
  - Save path always writes `dvr_auto_detect=false`.
  - Live TV source loading only uses a manual `dvr.baseUrl`.
  - `LiveSourceResolver.discoverChannelsDvrBaseUrl()` now returns `null` and no longer scans LAN candidates.
  - `loadDvrChannels()` no longer falls back to discovery when base URL is blank.
  - Source test path no longer reports/triggers auto-detect.
  - Manual Channels DVR URL remains supported.
- Added manual XMLTV guide URL setting in Live TV Backend settings.
- Wired manual XMLTV URL into `LiveGuideProgramResolver` so guide rows can hydrate from XMLTV without changing the Live TV UI/layout.
- Preserved old app Live TV UI/layout and player path.

## Clarification
The prior v0.2/v0.3 replacement did not fully wire the donor app Live TV logic. It bridged only parts. This v0.4 pass explicitly patches the old app live source resolver and guide resolver instead of claiming the donor logic was fully active.

## Debug markers
- `DC_BUILD_MARKER: NewtoOldv0.4_LIVE_TV_LOGIC_XMLTV_DVR_AUTODETECT_REMOVED`
- `DVR_AUTO_DETECT: HARD_DISABLED`
- `XMLTV_MANUAL_GUIDE: ENABLED`
- `LIVE_TV_UI_LAYOUT: UNTOUCHED`
- `PLAYER_CORE: UNTOUCHED`
