# NewtoOldv0.6 Live TV Logic Port / IPTV Support Audit

Base: NewtoOldv0.5_ROW_MENU_REAL_WIRING_FIX.
Donor/reference: DebridChannels_v0_9_8_3_CI_JSON_EXCEPTION_FIX_CLEAN_SOURCE.

Status before this pass:
- Live TV logic was only partially carried over.
- Old app still ran HDHomeRun/auto-discovery style scan paths.
- Manual Channels DVR, M3U/IPTV, Xtream and XMLTV pieces existed, but donor behavior was not fully mirrored/verified.

This pass:
- Hard-disables HDHomeRun/auto scan execution from LiveTvActivity startup.
- Keeps manual Channels DVR URL support only; no LAN/server auto detect.
- Keeps UI/layout untouched.
- Keeps player untouched.
- Keeps M3U/IPTV path.
- Keeps Xtream Codes path and adds category lookup from get_live_categories before get_live_streams.
- Preserves manual XMLTV guide resolver support.
- Hides/locks Force Refresh Guide button in this old-app LiveTvActivity path.

Expected logcat markers:
- LIVE_TV_LOGIC_PORT_ACTIVE: v0.6 donor=v0.9.8.3 sources=manual_dvr,m3u,xtream,manual_xmltv
- HDHOMERUN_AUTO_SCAN: DISABLED
- LIVE_TV_SOURCES_APPLIED: dvr=<n> iptv=<n> total=<n> ui=untouched
- FORCE_REFRESH_GUIDE_BUTTON: REMOVED
