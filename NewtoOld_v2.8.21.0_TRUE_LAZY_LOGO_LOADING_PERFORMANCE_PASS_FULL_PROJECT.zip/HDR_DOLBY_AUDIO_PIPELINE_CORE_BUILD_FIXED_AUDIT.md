# NewtoOld v2.8.18.0 HDR/Dolby Audio Pipeline Core Build Fixed

Base: latest stable NewtoOld source with donor one-row renderer, player settings, safe frame-rate hooks, link switching/resume, trailer auto-hide, media info cast, and HDHomeRun lineup work preserved.

Fixes:
- Kotlin compile blocker in PlayerActivity.kt: illegal Regex("\s+") escape corrected to Regex("\\s+").
- Build/version markers updated to v2.8.18.0.

Scope preserved:
- No changes to row system behavior.
- No changes to hero layout/artwork behavior.
- No changes to cache default-off/internal-blocked rules.
- No changes to layout editor except existing saved settings remain intact.

HDR/Dolby pipeline status:
- This source keeps the safe player-production hooks and diagnostics path.
- Device capability handling must be verified on hardware with logcat after APK build/install.
