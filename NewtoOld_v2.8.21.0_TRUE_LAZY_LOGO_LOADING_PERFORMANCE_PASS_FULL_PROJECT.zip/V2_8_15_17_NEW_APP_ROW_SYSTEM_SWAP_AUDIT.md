# v2.8.15.17 New App Row System Swap Audit

Base: v2.8.15.16 clean source tree.

Reason: NewtoOld row system was still broken after RecyclerView and stable-row attempts. User requested replacing NewtoOld rows with the new app row system behavior.

Changes:
- Disabled the old NewtoOld vertical RecyclerView row stack at runtime.
- Replaced active home rows with a new-app-style viewport renderer.
- Only nearby rows and cards are inflated: 4 visible row window, 7 visible card window.
- DPAD focus is explicit and deterministic: UP/DOWN/LEFT/RIGHT calls the focus graph directly.
- No full card/logo prebinding across all rows.
- No internal cache fallback. VOD cache remains off by default unless NAS/USB is enabled.
- Extra hero artwork is preserved and still controlled by layout settings.
- Build marker/versionName enforced: NewtoOld_v2.8.15.17_NEW_APP_ROW_SYSTEM_SWAP.

Expected log markers:
- DC_BUILD_MARKER: NewtoOld_v2.8.15.17_NEW_APP_ROW_SYSTEM_SWAP
- ROW_ENGINE: V8_NEW_APP_VIEWPORT_ROWS_ACTIVE
- ROW_ENGINE_V8_RENDER
- ROW_ENGINE_V8_VIEWPORT_BIND
- FOCUS_GRAPH_V8_MOVE
