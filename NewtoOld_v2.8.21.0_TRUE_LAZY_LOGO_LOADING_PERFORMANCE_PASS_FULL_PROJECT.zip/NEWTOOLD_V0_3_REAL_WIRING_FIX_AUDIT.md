# NewtoOldv0.3 Real Wiring Fix

This fixes the previous bad package where controls appeared but were not wired.

Actually wired in this pass:
- Row text toggle now changes actual MainActivity row title visibility/text.
- 3D extra artwork settings now apply to centered card logo/artwork during focus.
- Top menu bar now applies new-app-style labels/background at runtime.
- Row card renderer emits NEW_APP_STYLE_RENDERER_WIRED and bind/create logs.
- Hero trailers are hard-disabled on Home; media details trailer code is left intact.

Preserved:
- Old app base.
- Live TV UI/layout untouched.
- Existing player and artwork loading preserved.
- Everything not listed above.

Log markers:
- DC_BUILD_MARKER: NewtoOldv0.3_REAL_WIRING_FIX
- ROW_SYSTEM: NEW_APP_STYLE_RENDERER_WIRED
- TOP_MENU: NEW_APP_STYLE_WIRED
- EXTRA_ARTWORK_3D: SETTINGS_TO_RENDERER_WIRED
- ROW_TEXT_TOGGLE: SETTINGS_TO_RENDERER_WIRED
- HERO_TRAILERS: DISABLED_MEDIA_INFO_ONLY
