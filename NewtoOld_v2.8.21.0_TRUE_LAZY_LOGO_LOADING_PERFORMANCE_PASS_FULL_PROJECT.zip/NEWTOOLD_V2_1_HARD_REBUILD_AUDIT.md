# NewtoOld v2.1 Hard Home Rebuild Audit

Base: NewtoOld v2.0 project source

## Reason for this pass
The previous row replacement still allowed old vertical focus/scroll behavior to pull focus back to the previous row. This pass removes the old MainActivity home row execution path from runtime instead of patching it.

## Rebuilt from scratch
- MainActivity no longer uses ActivityMainBinding row slots or ScrollView-based row recovery.
- Home rows now use one vertical RecyclerView with horizontal RecyclerViews inside.
- DPAD UP/DOWN is controlled by an explicit FocusGraph in the card key handlers.
- Old snap/reveal/settle/startup-lock row code is not used in the new MainActivity.

## Added/expanded
- Top menu theme choices now include true no-glass/text-only and transparent-flat modes.
- Layout editor labels now show readable option names instead of only numeric values.
- Preview menu now visibly changes when top menu theme is adjusted.
- Hero extra artwork is integrated into the hero section, with placement modes.
- Hero quality mode added: 0 = 1080p default, 1 = 4K hero.

## Removed/disabled
- Real-Debrid and TorBox repository values are hard-disabled and cleared on save.
- Debrid settings section is hidden in the old Settings screen.

## Debug markers
- DC_BUILD_MARKER: NewtoOld_v2.1_HARD_HOME_REBUILD
- ROW_ENGINE: HARD_REBUILT_FROM_SCRATCH
- ROW_ENGINE: LEGACY_SCROLLVIEW_BINDING_NOT_USED
- FOCUS_GRAPH: EXPLICIT_VERTICAL_AND_HORIZONTAL
- TOP_MENU_ENGINE: FULL_THEME_CHOOSER_ACTIVE noGlassOption=true
- DEBRID_STATUS: NOT_PRESENT runtimeHome=false
