# NewtoOld v2.8.15.13 True Row System Replacement Audit

Base: v2.8.15.12_CACHE_DEFAULT_OFF_INTERNAL_BLOCKED_FULL_PROJECT

Purpose: stop the unacceptable hero/row scrolling behavior shown in the 2026-05-03 video.

What changed:
- Bypassed the old vertical RecyclerView home-row renderer instead of tuning it again.
- Added a new stable linear row engine: ScrollView + vertical LinearLayout + HorizontalScrollView lanes.
- Row/card focus now moves through a deterministic focus graph and does not rely on RecyclerView recycling/rebinding.
- Card focus no longer scales cards or changes row geometry; focus is visual-only to prevent layout jumps.
- Hero extra artwork is kept behind rows and no longer gets elevated above cards during focus updates.
- Stremio/addon catalog cards keep fallback centered title text when no logo exists.
- Added logcat markers:
  - ROW_ENGINE: V5_TRUE_REPLACEMENT_LINEAR_ROWS_NO_RECYCLER_JUMP
  - ROW_ENGINE: OLD_VERTICAL_RECYCLER_BYPASSED_STABLE_LINEAR_ROWS_ACTIVE
  - ROW_ENGINE_V5_RENDER
  - ROW_ENGINE_V5_BIND_ROW
  - FOCUS_GRAPH_V5_MOVE

Preserved:
- Cache default OFF and internal disk VOD cache blocked from v2.8.15.12.
- NAS/USB-only cache rule.
- Top menu actions.
- Settings / Pro Layout config fields.
- Stremio catalog loading and card logo fallback.

Build note:
- Gradle cannot run in this sandbox because the wrapper is a stub and Gradle is not installed here. Source project was rebuilt and zipped clean.
