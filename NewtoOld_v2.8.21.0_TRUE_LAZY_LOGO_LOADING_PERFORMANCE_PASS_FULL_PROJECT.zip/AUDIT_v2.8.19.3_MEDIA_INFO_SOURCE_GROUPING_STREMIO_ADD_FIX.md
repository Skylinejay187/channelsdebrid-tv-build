# v2.8.19.3 Media Info Source Grouping + Stremio Add Fix

Scope-only changes:
- SourceSelectionActivity now groups available movie/show links by addon/provider.
- Provider sections are shown separately, with an additional All Sources section.
- Selection still resolves using the original resolver candidate index.
- Stremio Add Source button is re-armed on text/focus/render changes and no longer depends on manifest metadata refresh completing.
- Removed duplicate Stremio source row render loop introduced in earlier Settings patches.

Preserved:
- Row/hero system
- Media info layout
- Player behavior/settings
- Cache rules
- Live TV/EPG settings
- Trailer/cast/preset behavior
