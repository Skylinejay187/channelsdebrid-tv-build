# NewtoOld v2.5 — Backend Removal + Direct Endpoint Audit

Base: NewtoOld v2.4 backendless artwork project.

## Purpose
This pass removes the backend as a runtime requirement and audits the direct-source endpoint paths before CDN support is added later.

## Backend removal
- Backend home loader converted to a no-network compatibility stub.
- Home artwork rows now use direct metadata providers/local cache only.
- Unified catalog/search no longer calls backend catalog/search endpoints.
- Settings "backend" section is repurposed as Direct XMLTV Guide.
- Backend test/sync buttons are hidden or converted to direct-source tests.
- Backend EPG/provider methods are hard no-op/removed from execution.

## Direct Live TV endpoints
- IPTV/M3U loads directly from the user-entered playlist URL.
- Xtream calls are direct:
  - `player_api.php?username=...&password=...&action=get_live_categories`
  - `player_api.php?username=...&password=...&action=get_live_streams`
  - Stream URL: `/live/{username}/{password}/{stream_id}.{extension}`
- XMLTV guide URL is direct and locally cached.
- Channels DVR is manual URL only.
- HDHomeRun/Channels LAN auto scan is disabled and returns empty without scanning.

## Preserved
- Working row scrolling from v2.1+.
- Top menu system and theme options.
- Hero logo and row-card logo restoration.
- Extra artwork controls.
- Player playback core.
- Live TV layout/UI.

## Still deferred
- Trailer extractor without backend.
- CDN acceleration layer for posters, guide/cable metadata, and trailers.

## Future CDN note
CDN should be added later as an optional provider layer, not as a required backend:
- `ArtworkProvider -> DirectMetadata -> OptionalCdnCache -> LocalCache`
- `GuideProvider -> DirectXMLTV/Xtream/Channels -> OptionalCdnCache -> LocalCache`
- `TrailerProvider -> DirectTrailerResolver -> OptionalCdnCache -> LocalCache`

## Debug markers to verify
- `DC_BUILD_MARKER: NewtoOld_v2.5_BACKEND_REMOVAL_DIRECT_ENDPOINTS`
- `BACKEND_MODE: REMOVED`
- `BACKEND_HOME_LOADER: REMOVED`
- `IPTV_DIRECT: ACTIVE`
- `XMLTV_DIRECT: ACTIVE`
- `XTREAM_DIRECT: ACTIVE`
- `CHANNELS_DVR_MANUAL_ONLY: ACTIVE`
- `HDHOMERUN_AUTO_SCAN: DISABLED`
- `DEBRID_STATUS: NOT_PRESENT`
