# NewtoOld v2.8.15.16 Row Memory Kill Fix Audit

Root cause from user logcat:
- No Java FATAL was emitted.
- Android lowmemorykiller killed com.channelsdebrid.tv to free ~1.1GB.
- InputDispatcher showed the MainActivity window stalled processing input for >2s before the process death.
- The v2.8.15.14/15 row path inflated every card view and eagerly loaded artwork/logos for full rows on the main screen.

Fixes:
- Replaced all-at-once LinearLayout/HorizontalScrollView card inflation with recycled vertical/horizontal RecyclerView rows.
- Limited first-pass home binding to 8 rows x 18 cards to avoid Xgimi low-memory kills.
- Removed per-card log spam.
- Changed card/row image loads to bounded decode sizes and RGB_565.
- Kept hero extra artwork enabled and controlled by existing settings.
- Kept cache default OFF and internal disk cache blocked from v2.8.15.12.
- Enforced versionName/versionCode and log marker: NewtoOld_v2.8.15.16_ROW_MEMORY_KILL_FIX_RECYCLED_ROWS.

Backlog remains:
- Infuse-style full prefetch/cache engine stays disabled/backlogged until a reliable single-source local cache proxy is designed.
