# NewtoOld v2.8.15.10 - Full Ahead NAS Tee Cache Audit

Base used: NewtoOld_v2.8.15.9_DIRECT_PLAYBACK_TEE_NAS_CACHE_SOURCE_LOAD_FIX_FULL_PROJECT.zip

Clean/stable rule: preserved the latest known-good source and consolidated the NAS cache path rather than stacking another fake UI patch.

What changed:
- Removed the competing background NAS downloader for NAS tee playback. That downloader was overwriting the real tee manifest with `waiting_source_start` / `source_refused` even while `.dcache` was growing.
- Playback remains direct to the original source URL. No localhost proxy is used.
- ExoPlayer is now the single allowed source connection in NAS mode.
- VOD load control is expanded for NAS mode so ExoPlayer keeps pulling the movie far ahead through the same connection while playback continues.
- The DataSource tee writes those exact player-loaded bytes to SMB `.dcache`.
- Manifest state now reports `tee_full_ahead_active` while the one player connection is filling the movie ahead.
- Option B preserved: cache is temporary and deleted when playback exits.

Expected verification:
- `vod_cache_manifest.txt` should no longer sit at `waiting_source_start` when the `.dcache` file is growing.
- State should become `tee_full_ahead_active`.
- `bytes=` should increase as ExoPlayer fills ahead.
- Percent should increase when source length is known.
- `.dcache` should grow well beyond the first few MB as long as playback remains open and the source/network is fast enough.

Logcat markers:
- `DC_BUILD_MARKER: NewtoOld_v2.8.15.10_FULL_AHEAD_NAS_TEE_CACHE`
- `VOD_CACHE_TEE_FULL_AHEAD`
- `VOD_DISK_CACHE_PROGRESS`
