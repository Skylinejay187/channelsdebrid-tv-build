# NewtoOld v2.6.8 IPTV Pipeline Stability Fix

Base: NewtoOld_v2.6.7_HDHOMERUN_MANUAL_MODE_BUILD_FIX_FULL_PROJECT.zip

Purpose:
- Fix issue where Live TV only loaded HDHomeRun while M3U/IPTV/Xtream sources were skipped.

Changes:
- M3U/Xtream loading no longer depends only on the legacy IPTV enabled toggle.
- If an M3U URL is present, it loads automatically.
- If Xtream credentials are present, they load automatically.
- Supports multiple M3U URLs separated by comma, semicolon, or newline.
- Keeps HDHomeRun manual/base URL loading intact.
- Keeps Channels DVR manual loading intact.
- Restores visible source status badges: DVR, HDHR, IPTV, XMLTV.
- Fixes HDHomeRun DeviceAuth icon/guide metadata URL to include actual DeviceAuth value.
- Adds log marker: IPTV_DIRECT_LOAD_APPLIED.

Endpoints preserved:
- M3U direct URL parsing.
- Xtream player_api.php live categories and streams.
- XMLTV manual guide URL.
- Channels DVR manual base URL.
- HDHomeRun manual base URL / lineup.json / lineup.m3u / lineup.xml.

No backend dependency was reintroduced.
