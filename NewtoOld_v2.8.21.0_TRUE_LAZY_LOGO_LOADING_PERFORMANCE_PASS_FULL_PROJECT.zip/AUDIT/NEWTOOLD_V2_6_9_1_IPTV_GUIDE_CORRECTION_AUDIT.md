# NewtoOld v2.6.9.1 IPTV Guide Correction Audit

Base used: NewtoOld_v2.6.8.1_CLEAN_FIX_FULL_PROJECT.zip

Purpose:
- Correct the v2.6.9 source separation mistake without carrying forward the auto-preview disable behavior.
- Keep M3U and Xtream together under the unified IPTV settings pipeline.
- Fix stale guide/channel cache when switching between channel sources.
- Improve large playlist handling for 600-2500+ channels without disabling preview.
- Keep the guide layout at a minimum of four full program columns visible.

Changes:
- Added source signature cache key using DVR, HDHomeRun, IPTV/M3U, Xtream, and XMLTV settings.
- Invalidates stale Live TV cache when source settings change.
- M3U and Xtream remain one IPTV path; no separate M3U source section is introduced.
- Optimized M3U parser with one-pass lineSequence parsing and precompiled EXTINF regexes.
- Preserved auto preview for guide focus; no large-lineup preview disable.
- Retained virtual/windowed guide row rendering.
- Timeline now guarantees four primary time columns.
- Added debug logs: IPTV_PARSE_COUNT, SOURCE_CACHE_KEY, GUIDE_VISIBLE_ROWS, GUIDE_VISIBLE_COLUMNS.

Preserved:
- Backendless direct endpoints.
- HDHomeRun manual mode.
- Channels DVR manual mode.
- Xtream direct endpoints.
- XMLTV manual guide support.
- New row engine / top menu / native 4K-oriented UI work from prior builds.
