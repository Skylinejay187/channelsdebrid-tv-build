# NewtoOld v2.8.20.5 Audit

Base: v2.8.20.4 clean project.

Changes:
- Added background Movies/Shows discovery prewarm from Home.
- Added persistent discovery row cache for fast first render.
- Added Glide disk prefetch for posters/backdrops/logos via backend image proxy.
- Added real Related Movies/Shows row on Media Details using cached discovery rows.
- Updated backend base to https://api.skylinejay187.it.com.

Preserved:
- Hero/row layout, Pro Layout Editor, source grouping, XGIMI audio fallback, player UI.
