# NewtoOld v2.4 — Backendless Artwork Provider Audit

Base: NewtoOld v2.3 compile-fix full project.

## Goal
Make posters/backdrops/logos load without requiring the Debrid Channels backend.
Trailers are intentionally not implemented in this pass.

## Added
- `BackendlessArtworkProvider`
  - Loads artwork rows directly from enabled Stremio/Cinemeta-style addon catalogs.
  - Loads optional TMDB rows only when the user has a TMDB API key configured.
  - Normalizes poster/background/logo URLs through the existing Stremio/TMDB loaders.
  - Leaves Glide/local disk cache as the app-side image cache.

## Runtime Changes
- Home screen default artwork mode is now **Direct metadata**.
- Backend home rows are no longer required for posters/backdrops/logos.
- Backend is only queried when Artwork Source Mode is set to Hybrid or Backend-only.
- Browse/Search repository skips backend calls when direct artwork mode is selected.

## Layout Editor
Added option:
- Artwork source mode
  - 0 = Direct metadata
  - 1 = Hybrid direct + optional backend
  - 2 = Backend only
  - 3 = Offline/local fallback

## Preserved
- Working row scrolling from v2.1/v2.2 path.
- Top menu system.
- Hero logo/card logo rendering.
- Extra artwork controls.
- Live TV logic/player.
- Real-Debrid/TorBox remains hidden/disabled.

## Debug markers
- `DC_BUILD_MARKER: NewtoOld_v2.4_BACKENDLESS_ARTWORK`
- `BACKENDLESS_ARTWORK_PROVIDER: ACTIVE`
- `ARTWORK_SOURCE_MODE: ...`
- `ARTWORK_PROVIDER_DIRECT_ROWS: ... backendRequired=false`
- `ARTWORK_ROWS_APPLIED: ... backendRequired=false`

## Not included yet
- Trailer extractor/provider system. This should be a separate pass after artwork is confirmed stable.
