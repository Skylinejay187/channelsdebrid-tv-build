# NewtoOld v2.6.3 Native 4K Correction Audit

Base: `NewtoOld_v2.6.2_NATIVE_4K_FEATURE_MERGE_FULL_PROJECT.zip`

Corrections applied after user testing:

- TMDB hero badge restored/kept visible with blue TMDB-style badge styling even when direct metadata has no TMDB vote yet.
- Hero lighting changed from overpowered yellow wash to subtle native 4K depth overlay.
- Hero lighting default reduced to 22% and max clamped to 45% so it is no longer overkill.
- HDHomeRun auto-scan setting made obvious in the Settings area under `Channels DVR + HDHomeRun`.
- Stremio addon add flow now fetches the manifest before saving so detected name + icon URL are stored immediately.
- Stremio settings list now shows the addon icon preview using Glide.
- Extra/hero artwork loading upgraded to request original/highest available artwork and use full disk cache.
- Loading-links/source-selection screen redesigned: portrait poster removed, list widened, text reduced, and focused highlight changed from bright white to softer cyan.

Build marker: `NewtoOld_v2.6.3_NATIVE_4K_FEATURE_CORRECTION`
