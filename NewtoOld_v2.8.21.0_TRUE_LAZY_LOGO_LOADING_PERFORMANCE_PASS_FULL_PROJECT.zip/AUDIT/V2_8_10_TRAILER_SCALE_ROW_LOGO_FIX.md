# NewtoOld v2.8.10 - Trailer Scale + Row Logo Size Fix

Base: NewtoOld v2.8.9_MEDIA_INFO_INFUSE_CACHE_MIRROR_FULL_PROJECT.zip

Changes:
- Reworked trailer popup video area to a true 16:9 surface inside the preview card.
- Increased popup card height so the controls no longer squeeze the player surface.
- Set PlayerView resize mode to fit and disabled controller inside popup so the custom controls remain the active UI.
- Reduced center row-card logo size back to a controlled medium size while preserving high-quality artwork loading.
- Reduced center logo glow height to avoid oversized logo emphasis.

Notes:
- This is a UI correction only. It does not change trailer resolving, VOD playback, Live TV, or search behavior.
