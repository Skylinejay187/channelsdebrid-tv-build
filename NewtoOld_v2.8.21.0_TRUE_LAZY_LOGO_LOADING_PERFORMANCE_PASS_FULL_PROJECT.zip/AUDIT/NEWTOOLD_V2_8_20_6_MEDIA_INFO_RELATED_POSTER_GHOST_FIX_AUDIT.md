# NewtoOld v2.8.20.6 Media Info Related Poster + Ghost Fix Audit

Base used: NewtoOld_v2.8.20.5_MOVIES_SHOWS_PRELOAD_RELATED_CACHE_FIX.

Changes:
- Converted Media Info related recommendations from small landscape tiles to larger portrait poster cards.
- Related cards now prefer poster artwork first, falling back to backdrop only when poster is missing.
- Increased related row viewport height and DP-based card sizing for Android TV focus/clickability.
- Disabled ScrollView fading-edge drawing/cache behavior that could create ghosting/trailing artifacts while scrolling over the cinematic backdrop.
- Preserved backend/CDN domain integration, Movies/Shows preload, related row behavior, XGIMI audio fixes, logo fallback systems, player settings, and existing UI flow.

Verification:
- XML structure patched without changing activity hierarchy.
- Kotlin related-row rendering changed only inside MediaDetailsActivity related-section path.
