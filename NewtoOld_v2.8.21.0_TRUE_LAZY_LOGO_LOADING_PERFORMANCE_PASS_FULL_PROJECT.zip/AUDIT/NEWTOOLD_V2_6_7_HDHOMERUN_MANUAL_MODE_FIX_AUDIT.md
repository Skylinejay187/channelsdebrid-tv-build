# NewtoOld v2.6.7 HDHomeRun Manual Mode Fix Audit

Base: NewtoOld_v2.6.6_MEDIA_POPULATION_PERFORMANCE_HDHR_FIX_FULL_PROJECT.zip

## Changes
- HDHomeRun manual override now loads even when auto-scan is disabled.
- Manual field accepts a device base URL such as `http://192.168.100.166`.
- Manual field accepts direct `/lineup.json`, `/lineup.m3u`, or `/lineup.xml`.
- If a base URL is entered, the resolver tries `/lineup.json`, `/lineup.m3u`, and `/lineup.xml` automatically.
- If multiple URLs are pasted separated by commas/newlines/semicolons, the resolver safely tries each URL instead of treating it as one invalid URL.
- Settings label/hint clarified so users do not need to enter comma-separated URLs.
- Auto scan is now separate from manual override; manual override is always honored.

## Preserved
- v2.6.6 media population/performance fixes.
- Movies/Shows/Search background loading.
- TMDB/Stremio/Cinemeta caching behavior.
- Native 4K-oriented UI mode.
- Episode preview Option B.

## Debug
Look for `HDHOMERUN_LOAD: manual=true auto=...` and the HDHomeRun manual override status message in Live TV.
