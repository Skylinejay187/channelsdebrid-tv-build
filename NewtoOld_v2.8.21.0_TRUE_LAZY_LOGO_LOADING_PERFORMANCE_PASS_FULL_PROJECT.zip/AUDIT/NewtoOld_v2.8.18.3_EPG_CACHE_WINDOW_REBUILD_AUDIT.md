# NewtoOld v2.8.18.3 EPG Cache Window Rebuild Audit

Base: v2.8.18.3 EPG cache window source.

Scope preserved: VOD player, row system, hero quality, focus effects, cast, trailer controls, presets, cache rules, HDHomeRun manual lineup/XMLTV behavior.

Verified/adjusted:
- EPG cache window options remain exactly 3 / 6 / 12 hours.
- Default cache window remains 6 hours.
- LiveTvActivity TTL clamps values to 3, 6, or 12.
- Settings parser clamps values to 3, 6, or 12.
- Fixed visibility regression: EPG cache window input is no longer hidden with removed backend fields.
- Build/logcat marker updated to REBUILD_CLEAN for install verification.
