# NewtoOld v2.7.6 — Hero Badge Themes + Row Focus Rewrite Audit

Base used: NewtoOld_v2.7.5_HERO_BADGES_TILT_JUMP_FIX_FULL_PROJECT.zip

Clean/stable build rule applied: this build keeps the existing old-app foundation, preserves the native 4K-oriented UI path, guide performance work, IPTV/M3U/Xtream/HDHR fixes, and adds only stabilizing UI upgrades.

## Added / Changed
- IMDb/TMDB badges promoted into Pro Layout Editor controls:
  - IMDb badge on/off
  - TMDB badge on/off
  - rating number on/off
  - badge position selector
  - 9 badge themes: reference logo, compact pill, glass, flat, neon, mono, card block, logo-only, rating-only
- TMDB badge no longer disappears just because rating extraction fails; badge can stay visible with rating hidden or rating number disabled.
- TMDB rating extraction expanded for TMDB, tmdbRating, tmdb_rating, vote_average, voteAverage and fallback text patterns.
- Row focus rewrite layer added:
  - stable card IDs
  - row RecyclerViews set fixed size
  - hero updates debounced during DPAD movement
  - repeated hero updates skipped when focused item did not change
  - focused card scale clamped in stable mode to reduce layout jumping
- Extra artwork 3D tilt strengthened and kept controlled by existing layout editor tilt setting.

## Preserved
- Native 4K-oriented UI mode, no forced density override.
- IPTV/M3U/Xtream/XMLTV/HDHomeRun direct endpoint pipeline.
- Guide performance and 4 visible guide row work.
- Top menu glow/underline focus behavior.
- Backendless artwork provider and direct Stremio/TMDB metadata path.

## Debug Markers
- DC_BUILD_MARKER: NewtoOld_v2.7.6_HERO_BADGE_THEMES_ROW_FOCUS_REWRITE
- HERO_BADGE_SYSTEM: theme/toggle/rating settings logged at startup
- ROW_FOCUS_REWRITE: stable row mode logged at startup
