# NewtoOld v2.6.8.1 Clean Fix Audit

Base: NewtoOld_v2.6.8_IPTV_PIPELINE_STABILITY_FIX_FULL_PROJECT.zip

Fixes:
- Corrected Kotlin compile failure in LiveTvActivity.kt around M3U multi-URL parsing.
- Replaced invalid multi-character char literal separator with Regex("[,;\\n]+").
- Preserved M3U, XMLTV, Xtream, HDHomeRun manual mode, source badges, and DeviceAuth changes from v2.6.8.

Build marker:
DC_BUILD_MARKER: NewtoOld_v2.6.8.1_CLEAN_FIX
