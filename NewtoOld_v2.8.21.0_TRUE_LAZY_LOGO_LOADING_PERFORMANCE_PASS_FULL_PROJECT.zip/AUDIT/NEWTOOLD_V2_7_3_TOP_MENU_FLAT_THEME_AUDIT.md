# NewtoOld v2.7.3 - Live TV Flat Top Menu Theme Audit

Base used: NewtoOld_v2.7.2_GUIDE_4_VISIBLE_ROWS_CORRECTION_FULL_PROJECT.zip

Changes included:
- Live TV top navigation now uses flat text-only labels: RESUME / HOME / LIVE / MOVIES / TV SHOWS.
- Removed emoji/icon labels from the Live TV top nav default renderer.
- Replaced heavy pill/glass active menu treatment with subtle underline + slight scale focus behavior.
- Added `top_nav_flat_text_selector.xml` for transparent idle + focused/selected underline styling.
- Pro Layout Editor theme names updated to expose Flat Text / Transparent Flat / Minimal Pill menu choices.
- Default HomeLayout top menu settings changed to text-only + flat theme for clean Live TV guide appearance.
- Preserved v2.7.2 guide performance, 4 visible guide row work, IPTV/M3U/Xtream unified source behavior, HDHomeRun manual mode, and auto preview.

Debug marker: TOP_MENU_FLAT_THEME_ACTIVE
