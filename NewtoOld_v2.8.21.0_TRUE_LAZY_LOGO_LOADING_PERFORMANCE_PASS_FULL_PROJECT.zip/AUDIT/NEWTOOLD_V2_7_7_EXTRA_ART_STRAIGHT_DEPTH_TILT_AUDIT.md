# NewtoOld v2.7.7 — Extra Artwork Straight Depth Tilt Correction

Base: NewtoOld v2.7.6 hero badge themes + row focus rewrite.

## Fixes
- Replaced sideways extra-art tilt with centered perspective depth.
- Locked extra artwork pivot to center.
- Removed translationX drift during tilt.
- Removed translationY drift during tilt.
- Removed scale distortion during tilt to preserve clarity.
- Increased camera distance to reduce warping.
- Kept high-quality artwork loading path unchanged.
- Renamed Layout Editor controls to straight depth tilt / perspective depth.

## Expected behavior
Extra artwork should tilt into the screen while staying straight, centered, sharp, and stable.
