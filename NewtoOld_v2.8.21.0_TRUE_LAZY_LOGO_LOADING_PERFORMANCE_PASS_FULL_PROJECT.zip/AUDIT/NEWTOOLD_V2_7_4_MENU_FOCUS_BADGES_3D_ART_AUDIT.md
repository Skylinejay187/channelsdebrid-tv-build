# NewtoOld v2.7.4 Menu Focus + Badge + 3D Extra Art Correction

Base: NewtoOld v2.7.3 TOP_MENU_FLAT_THEME full project.

Changes:
- Removed yellow top-menu focus treatment for flat/transparent menu themes.
- Added glow + underline + slight scale focus behavior for top menu.
- Added Hero Top Menu Position option 3: Top Edge compact, while preserving Top/Center/Lower.
- Reduced focus-jump when pressing DOWN from top menu by avoiding forced vertical scroll when the row is already bound.
- Rebuilt IMDb/TMDB hero rating pills to match badge-style theme better, including TMDB always-visible fallback and improved rating extraction.
- Added stronger cinematic 3D tilt behavior for extra artwork/banner/poster layer using camera distance, rotationX/rotationY, translationZ, and subtle scale.

Debug markers:
- TOP_MENU_FOCUS: GLOW_UNDERLINE_NO_YELLOW
- HERO_MENU_POSITION: TOP_EDGE_COMPACT_ADDED
- HERO_RATING_BADGES: IMDB_TMDB_PILLS_ACTIVE
- EXTRA_ARTWORK_3D_TILT: ACTIVE
