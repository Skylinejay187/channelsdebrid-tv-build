# NewtoOld v2.6.5 — Dual Metadata Media Population Audit

Base: `NewtoOld_v2.6.4_EPISODE_PREVIEW_OPTION_B_FULL_PROJECT.zip`

## Goal
Make Movies, Shows, and Search sections populate from configured Stremio/Cinemeta catalogs while automatically using the existing TMDB API key setting as a metadata enhancer.

## Implemented
- Movies section uses Stremio/Cinemeta catalog discovery plus optional TMDB enhancement.
- Shows section uses Stremio/Cinemeta catalog discovery plus optional TMDB enhancement.
- Search uses Stremio/Cinemeta search/catalog paths plus optional TMDB enhancement.
- Existing TMDB settings field is reused; no extra metadata preference is required.
- TMDB key is optional: if blank or lookup fails, the app keeps Stremio/Cinemeta metadata.
- Enrichment upgrades poster, backdrop, overview, TMDB rating line, IMDb external id, and logo artwork where available.
- High-quality TMDB image paths are used: poster `w780`, backdrop/logo `original`.

## Preserved
- v2.6.4 episode preview Option B system.
- v2.6.3 correction fixes.
- Native 4K-oriented UI mode direction; no forced density override.
- Backend remains removed for catalog/artwork population. Trailer backend is left alone for future trailer resolving/caching.

## Build markers
- `DC_BUILD_MARKER: NewtoOld_v2.6.5_DUAL_METADATA_MEDIA_POPULATION`
- `MOVIES_SHOWS_SEARCH: STREMIO_CINEMETA_TMDB_AUTO_ENRICH_ACTIVE`
