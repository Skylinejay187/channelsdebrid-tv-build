# NewtoOld v2.8.6.3 Clean Cache + Player Fix Audit

Base used: `NewtoOld_v2.8.5_4K_ARTWORK_LOGO_ROW_SYSTEM_FULL_PROJECT.zip`

Reason for rebuild:
- v2.8.6.x introduced an unresolved `playerCacheStatus` reference in `PlayerActivity.kt`.
- The NAS/VOD cache UI chain was rebuilt from the last stable visual/artwork base instead of carrying forward the broken cache chain.

Changes:
- Wired VOD playback through `CacheDataSource` when movie cache is enabled.
- Existing NAS/USB/internal storage settings are used to resolve the VOD cache directory.
- Added visible cache status text under the VOD progress bar.
- Uses ExoPlayer buffered percentage as the visible secondary/cache bar fallback.
- Added log markers:
  - `VOD_CACHE_ACTIVE`
  - `VOD_DISK_CACHE_PROGRESS`
- Fixed trailer popup focus behavior so Mute/Fullscreen/Close keep focus instead of the video/WebView stealing it.
- Kept v2.8.5 landscape row-card + center logo artwork quality work.

Notes:
- Full exact disk-cache percentage depends on the source exposing direct-file byte range / content length.
- Unknown-size streams still show buffered secondary progress and cache status instead of hiding the cache UI.
- Gradle was not run locally because this project wrapper is configured to build through GitHub Actions.
