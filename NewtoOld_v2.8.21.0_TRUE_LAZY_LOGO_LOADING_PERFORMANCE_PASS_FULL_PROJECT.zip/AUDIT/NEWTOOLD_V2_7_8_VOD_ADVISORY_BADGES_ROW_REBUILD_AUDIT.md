# NewtoOld v2.7.8 — VOD Advisory + Badge Theme + Row Stability Rebuild Audit

Base: NewtoOld_v2.7.7_EXTRA_ART_STRAIGHT_DEPTH_TILT_FULL_PROJECT.zip

## Added
- VOD player content advisory animation overlay.
- Advisory tags appear top-left during VOD playback, fade in, hold briefly, then fade out.
- Advisory tags are based on current VOD metadata/overview keywords and do not loop constantly.

## Badge System
- Expanded IMDb/TMDB badge theme range from 0–8 to 0–14.
- TMDB badge remains visible when enabled even if rating value is missing.
- Rating numbers remain optional via Layout Editor.
- Added more font/color/style variants: classic reference, glass outline, flat block, luxury dark, cyber mono, large logo chip, lowercase pill, bold cinema, premium glass, terminal.

## Extra Artwork Tilt
- Replaced sideways yaw tilt with straight centered depth transform.
- rotationY locked to 0 to avoid sideways drift.
- centered pivot/cameraDistance retained for clarity.

## Row Focus Stability
- Added stable row adapter IDs.
- Reduced focused card scale in stable mode to prevent layout push/jump.
- Increased hero debounce and removed hero text fade jiggle during fast DPAD movement.
- Kept row movement functional while reducing layout rebind pressure.

## Notes
- Gradle was not run locally because this project wrapper says to use GitHub Actions.
