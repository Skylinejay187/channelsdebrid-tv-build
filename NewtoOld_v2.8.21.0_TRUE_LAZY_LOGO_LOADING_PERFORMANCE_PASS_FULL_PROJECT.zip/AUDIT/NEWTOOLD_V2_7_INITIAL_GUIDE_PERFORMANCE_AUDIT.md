# NewtoOld v2.7 Initial Guide Performance Audit

Base: NewtoOld v2.6.9.1 IPTV guide correction.

Changes:
- Preserved unified IPTV pipeline: M3U and Xtream remain under IPTV settings.
- Preserved auto preview; no feature disabling used as a performance workaround.
- Reduced initial Live TV freeze risk by applying persistent EPG cache off the UI thread before first render.
- Removed duplicate first-render passes that built categories/guide, then rebuilt them again after EPG cache merge.
- Keeps guide window virtualized and increases the visible guide window from 10 to 11 rows so the guide has one more finished row card on screen.
- Delays background EPG indexing slightly so the first visible guide shell can appear before deeper program matching starts.
- Background EPG refresh now scans a smaller initial window first and updates in smaller batches.
- Minimum four program columns remain visible.

Debug markers:
- GUIDE_VISIBLE_COLUMNS: 4_minimum rows=11
- LIVE_TV_SOURCES_APPLIED ui=progressive
- SOURCE_CACHE_KEY
