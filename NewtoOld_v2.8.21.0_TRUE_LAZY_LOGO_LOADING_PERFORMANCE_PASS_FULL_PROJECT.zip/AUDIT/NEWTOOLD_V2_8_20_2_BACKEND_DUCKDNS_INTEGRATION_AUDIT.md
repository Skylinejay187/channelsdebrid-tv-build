# NewtoOld_v2.8.20.2_BACKEND_DUCKDNS_AUTO_SWITCH_INTEGRATION

Scope: backend/CDN integration only.

Preserved:
- Donor one-row hero system, focus effects, hero quality.
- VOD player controls/settings, resume, switch link, scrubbing behavior.
- Trailer extractor routes and existing backend-facing trailer calls.
- HDHomeRun, EPG, cast, presets, Stremio grouping/add-source behavior.

Added/changed:
- Added `BackendEndpoint` routing helper.
- External backend default set to `http://skylinejay187.duckdns.org:8181`.
- Local backend fallback constant retained as `http://192.168.100.55:8181` for future LAN-aware routing.
- Artwork image loads route through backend `/api/image?url=` where practical.
- Existing trailer/backend base defaults now use DuckDNS.
- Version/build markers updated for verification.

Notes:
- This build does not add Cloudflare/domain support. DuckDNS + port 8181 is used as requested.
- Video stream URLs are not CDN-proxied or rewritten.
