# NewtoOld v2.6.4 — Episode Preview Option B Audit

Base: NewtoOld_v2.6.3_NATIVE_4K_CORRECTION_FULL_PROJECT.zip

## Preserved
- Native 4K-oriented UI direction from v2.6.2/v2.6.3.
- TMDB/IMDb badge correction layer from v2.6.3.
- Subtle hero lighting correction from v2.6.3.
- HDHomeRun setting visibility correction from v2.6.3.
- Stremio addon icon/name correction layer from v2.6.3.
- Source/link selection readability correction from v2.6.3.

## Added in v2.6.4 Option B
- Episode card system for season/episode browsing.
- Episode preview images in each episode row.
- Right-side focused episode preview panel.
- Delayed focus preview update for Android TV DPAD browsing.
- Focus zoom behavior on episode cards.
- Episode metadata extraction from Stremio/Cinemeta video objects:
  - thumbnail/image/still/poster
  - overview/description/summary
  - released/firstAired
  - runtime/duration
  - imdbRating/rating
- High-quality episode still image upgrade path using original-size TMDB-style URLs when available.
- Episode source selection now forwards episode-specific artwork and description when available.

## Trailer Design Note
Trailers were not implemented in this build. Recommended next step is a small trailer resolver layer that can use YouTube Data API or a lightweight backend cache/proxy, then play trailers through the existing app player popup.
