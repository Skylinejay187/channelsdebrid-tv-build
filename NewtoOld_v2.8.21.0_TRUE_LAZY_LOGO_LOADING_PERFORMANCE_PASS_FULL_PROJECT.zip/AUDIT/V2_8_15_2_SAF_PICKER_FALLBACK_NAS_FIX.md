# NewtoOld v2.8.15.2 — SAF Picker Fallback + NAS Fix

Base: v2.8.15.1 real SAF stream writer build-fix.

Changes:
- Android folder picker now checks whether ACTION_OPEN_DOCUMENT_TREE exists before launch.
- If no picker app exists, Settings no longer crashes or bounces back to hero.
- Added chooser launch when a picker exists.
- Added fallback dialog with two paths:
  - Login / Browse NAS for SMB storage.
  - Manual URI / path entry for content:// or smb:// locations.
- Kept SAF writer and SMB NAS fallback path intact.

Notes:
- On Android TV builds with no DocumentsUI/folder picker, use Login / Browse NAS.
- If a third-party file manager exposes a content URI, use Manual URI / path.
