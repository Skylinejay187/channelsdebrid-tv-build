# NewtoOld v2.7.1 — Guide Safe-Load Performance Audit

Base: NewtoOld_v2.7_INITIAL_GUIDE_PERFORMANCE_FULL_PROJECT.zip

Purpose: fix lower-end Android TV initial guide freeze without removing auto preview.

Implemented:
- Instant guide open with first-screen-only channel shell.
- First 48 channels render immediately; full channel index hydrates in background chunks.
- Background channel indexing added with generation/source guards so stale source switches cannot apply old rows.
- Local parsed channel cache reused with the same first-screen-only strategy.
- EPG indexing delayed until after first screen/hydration so XMLTV cache merge does not block first render.
- Lazy logo loading added to guide rows; logos load after row attachment instead of during row creation.
- Auto preview remains enabled and unchanged.
- Minimum 4 guide columns preserved.
- Visible guide row target increased to 12.

Debug markers:
- GUIDE_INITIAL_SHELL
- GUIDE_INITIAL_SHELL_CACHE
- BACKGROUND_CHANNEL_INDEX
- GUIDE_VISIBLE_COLUMNS
- SOURCE_CACHE_KEY

Notes:
- CDN can still help image/guide download speed, but this build focuses on device-side render/parsing safety.
- No IPTV/M3U/Xtream/HDHomeRun endpoints were removed.
