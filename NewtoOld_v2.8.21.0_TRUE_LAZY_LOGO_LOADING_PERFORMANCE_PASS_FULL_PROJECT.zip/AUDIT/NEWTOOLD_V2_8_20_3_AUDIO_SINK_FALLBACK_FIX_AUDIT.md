# NewtoOld_v2.8.20.3_AUDIO_SINK_FALLBACK_FIX

Scope: VOD/player audio compatibility only.

Changes:
- Added smart audio sink failure detection for AudioTrack/audio sink initialization errors.
- Keeps normal Dolby/surround behavior first.
- Retries VOD playback once with safe stereo, max 2 audio channels, AAC/standard audio preference, and tunneling disabled only after audio failure.
- Preserves user-facing Audio Output Mode setting: Auto, Prefer Surround, Stereo Only.
- Logs `PLAYER_AUDIO_FALLBACK_RETRY` and `PLAYER_TRACK_SELECTOR` for verification.

Preserved:
- Backend/DuckDNS integration.
- Row/hero/media details/source grouping/trailer/cast/settings/cache behavior.
