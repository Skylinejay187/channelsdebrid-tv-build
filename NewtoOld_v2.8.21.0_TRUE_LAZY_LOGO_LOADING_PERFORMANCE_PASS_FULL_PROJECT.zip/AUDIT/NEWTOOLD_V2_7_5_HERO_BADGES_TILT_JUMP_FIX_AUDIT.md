# NewtoOld v2.7.5 — Hero Badges / Tilt / Jump Fix Audit

Base used: NewtoOld_v2.7.4_MENU_FOCUS_BADGES_3D_ART_FULL_PROJECT.zip

Corrections:
- Rebuilt IMDb/TMDB badge renderer as compact brand-label + rating blocks.
- TMDB badge no longer forces a fake placeholder rating; it only displays when a real TMDB/vote_average rating is present.
- Expanded rating parser to detect IMDb, IMDB, imdbRating, TMDB, vote_average, voteAverage, and score formats.
- Reduced hero focus jank by caching hero backdrop/logo/extra-art URLs and avoiding unnecessary Glide reloads.
- Stopped removing/re-adding hero logo and extra artwork views during focus changes; layout params update in place.
- Added real post-layout 3D tilt application for hero extra artwork so width/height pivots are valid.
- Strengthened tilt depth and added a visible tilt-into-screen behavior with camera distance, pivot, rotationY/X, translationZ, and scale.
- Renamed Pro Layout controls to make the extra artwork tilt setting obvious.

Verification markers:
- HERO_RATING_BADGES_APPLY
- HERO_EXTRA_ART_LAYER_APPLY tiltEnabled/depth/cached
