# NewtoOld v2.6.2 Native 4K Feature Merge Audit

Base used: `NewtoOld_v2.5.2_TRUE_4K_FULL_PROJECT.zip` uploaded by user.

## Direction change
- Removed the density-forcing approach from `UiModeApplier`.
- Added native 4K-oriented mode matching the new app strategy: renderer/layout presets, native spacing, 4K quality preference, no forced density mutation.

## Merged features
- IMDb/TMDB hero rating badges as icon-style colored badges.
- Hero poster/art lighting overlay with editor controls.
- HDHomeRun auto-scan setting saved separately from Channels DVR manual server config.
- Live TV now reads `hdHomeRunAutoScan` for scan behavior.
- Stremio manifest detection now supports detected name + icon URL storage.
- Stremio catalog rows are loaded into the home/hero row system via `StremioLiveLoader` and the new row engine.
- Hero top menu vertical position control: Top / Center / Lower.

## Build markers
- `DC_BUILD_MARKER: NewtoOld_v2.6.2_NATIVE_4K_FEATURE_MERGE`
- `NATIVE_4K_UI_MODE: NEW_APP_STYLE_NO_DENSITY_OVERRIDE`
- `HDHOMERUN_AUTO_SCAN: SETTING_ACTIVE`
- `STREMIO_ADDON_MANIFEST_NAME_ICON_CATALOG_ROWS: ACTIVE`
