# NewtoOld v2.7.2 Guide 4 Visible Rows Correction

Base: v2.7.1 guide safe-load performance build.

This is a targeted correction for the missed visible-row requirement. The previous build changed render-window targets, but the visible viewport was still too short, so only about three full guide rows/cards appeared on some screens.

Changes:
- Reduced Live TV top/bottom shell padding to free guide viewport height.
- Reduced hero/header block from 245dp to 214dp.
- Reduced timeline height from 34dp to 30dp.
- Compacted guide rows without duplicating fake rows: row padding is smaller, program cards are 46dp, logo tile is 70x44dp, row gap is 6dp.
- Updated row height estimate to 60dp so virtual top/bottom spacers match the real compact row height.
- Increased render window to 14 rows while preserving virtual/windowed rendering.

Expected result:
- At least four full channel rows/cards visible in the guide area.
- Auto preview remains enabled.
- Instant guide open, first-screen load, background indexing, local parsed cache reuse, and lazy logo loading are preserved.
