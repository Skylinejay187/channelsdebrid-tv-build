# NewtoOld v2.8.13 — Media Info 4K Layout + Cache Diagnostics

Base: v2.8.12 media info/cache prefetch correction.

## APK/screenshot audit findings
- Media info was still using a floating right-side glass placeholder panel, causing text and controls to look like the old layout.
- Action row and cast row were still too close when 1080p/scaled layouts were active.
- Media info screen did not have its own native 4K layout toggle in the Pro Layout Editor.
- NAS cache manifest with `state=source_refused`, `bytes=0`, `total=unknown` means the prefetch downloader did not receive an accepted duplicate HTTP stream from the source. This is not a writable-path issue; it is a source/prefetch acceptance issue.

## Changes
- Removed the visible right-side placeholder panel from media info.
- Rebuilt media info as a single left cinematic flow: logo/title, meta, description, actions, cast row.
- Added `Media info 4K UI mode` setting to Pro Layout Editor.
- Media info now applies native 4K sizing/padding when that setting is enabled or native UI mode is forced to 4K.
- Kept cache status honest: no fake 0% progress claim if source refuses duplicate prefetch.

## Cache note
Current cache system still needs a future tee/proxy data source to write NAS bytes from the same stream ExoPlayer is reading when sources reject duplicate downloader requests. This build prevents misleading placeholder UI/files and makes the media info layout correction independent from cache behavior.
