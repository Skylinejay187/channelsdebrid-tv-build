# NewtoOld_v2.8.20.4_ROW_HERO_LOGO_XGIMI_AUDIO_FIX

Base: NewtoOld_v2.8.20.3_AUDIO_SINK_FALLBACK_FIX clean project.

Scope kept narrow:
- Home row card logo recovery.
- Hero logo recovery.
- XGIMI / Galileo audio-route stability.

Changes:
- Added `resolveDisplayLogoUrl()` in MainActivity.
- If an addon/Stremio item has an IMDb id but no explicit logo field, row cards and hero now fall back to `images.metahub.space/logo/large/<ttid>/img`.
- This fixes rows that show centered text instead of focused-card logos when source metadata omits logo URLs.
- Hero logo uses the same fallback path so focused hero branding stays consistent.
- Added log marker `ROW_HERO_LOGO_FALLBACK`.
- Added XGIMI/Galileo audio compatibility detection.
- For XGIMI Auto audio mode, playback uses safe stereo/no-tunnel output to avoid Bluetooth/A2DP AudioTrack drops.
- Added long-playback stall watchdog with `PLAYBACK_STALL_RECOVERY` logging.

Preserved:
- Current hero layout and row layout.
- Backend/CDN domain behavior.
- Source grouping.
- Trailer extraction flow.
- Settings/menu/UI structure.

Compile note:
- Gradle wrapper in this source reports Gradle unavailable in the local sandbox, so syntax was patched conservatively without local Gradle execution.
