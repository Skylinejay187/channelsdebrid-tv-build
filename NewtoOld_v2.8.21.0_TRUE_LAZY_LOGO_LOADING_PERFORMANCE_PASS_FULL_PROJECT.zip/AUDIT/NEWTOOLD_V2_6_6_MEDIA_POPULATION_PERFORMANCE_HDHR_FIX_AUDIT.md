# NewtoOld v2.6.6 Media Population + Performance + HDHomeRun Manual Override Audit

Base: NewtoOld_v2.6.5_DUAL_METADATA_MEDIA_POPULATION_FULL_PROJECT.zip

Fixes included:
- Movies/Shows sections now load catalogs off the UI thread to prevent whole-app slowdown.
- UnifiedCatalogRepository now uses cached TMDB/Stremio/Cinemeta JSON requests and shorter network timeouts.
- TMDB section population no longer performs per-card external-id lookups during list loading.
- Cinemeta/Stremio default catalog fallback remains active even when user add-ons are not enough.
- Search results now render poster/backdrop artwork instead of text-only rows.
- TMDB rating text is placed in the media meta line as `TMDB x.x` so the visible TMDB badge has a value to bind/read.
- HDHomeRun manual lineup override setting added to Settings.
- HDHomeRun manual override supports:
  - http://hdhomerun.local/lineup.xml
  - http://hdhomerun.local/lineup.m3u
  - http://hdhomerun.local/lineup.json
- Live TV passes the manual HDHomeRun override into the HDHomeRun loader before LAN discovery fallback.

Performance correction:
- List population and metadata enrichment are no longer allowed to block the activity render path.
- TMDB enrichment is capped on first batch and cached to avoid repeated network hits while browsing/focusing.

Build marker:
DC_BUILD_MARKER: NewtoOld_v2.6.6_MEDIA_POPULATION_PERFORMANCE_HDHR_FIX
