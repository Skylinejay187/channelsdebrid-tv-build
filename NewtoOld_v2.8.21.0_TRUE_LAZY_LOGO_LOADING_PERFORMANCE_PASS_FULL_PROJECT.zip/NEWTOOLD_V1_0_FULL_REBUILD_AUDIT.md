# NewtoOld v1.0 Full Rebuild Audit

Base: NewtoOldv0.6_LIVE_TV_LOGIC_PORT_IPTV_XMLTV_FIX.zip
Donor/reference: DebridChannels_v0_9_8_3_CI_JSON_EXCEPTION_FIX_CLEAN_SOURCE.zip

## Intent
Hard-replace the old home row and top menu execution paths with a new clean system modeled after the new app direction, while preserving the old app as the base.

## Preserved
- Player code and playback activity
- Live TV UI/layout
- Live TV player/core logic from v0.6
- Manual XMLTV/IPTV/Xtream support from v0.6
- Backend/artwork loading paths
- Media information trailers only

## Rebuilt / Rewired
- Home row rendering now uses the clean landscape card holder and binder path in MainActivity.RowAdapter.
- Row text visibility is routed through HomeLayoutSettings.rowTextVisible at every row source bind path.
- 3D extra artwork is routed through focused card/logo renderer path.
- Top menu is top-center by default inside the real topNav execution path.
- Old left topActions are hidden so the visible menu is the new top-center bar.
- Added navSettings into the top-center bar so Settings is reachable through the real menu path.
- Added top-menu scroll/focus animation setting:
  - 0 None
  - 1 Clean Glide
  - 2 Elastic Bounce
  - 3 Glass Pulse
  - 4 Underline Sweep

## Debug markers
- DC_BUILD_MARKER: NewtoOld_v1.0_FULL_REBUILD
- ROW_SYSTEM: NEW_ENGINE_ACTIVE
- ROW_SYSTEM: OLD_REMOVED
- TOP_MENU: NEW_ACTIVE
- TOP_MENU_POSITION: TOP_CENTER
- TOP_MENU_ANIMATION_OPTIONS: 0=None,1=Clean Glide,2=Elastic Bounce,3=Glass Pulse,4=Underline Sweep
- TOP_MENU_ANIMATION_APPLY: style=...

## Notes
Gradle is not installed in this container. The included gradlew wrapper still requires a local Gradle install per this project wrapper script, so I could not run a full compile here.
