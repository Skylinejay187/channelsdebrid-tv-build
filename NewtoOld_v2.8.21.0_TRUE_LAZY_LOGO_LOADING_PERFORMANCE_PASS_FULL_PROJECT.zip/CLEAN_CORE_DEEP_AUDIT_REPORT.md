# v2.8.19.0 Clean Core Deep Audit Report

Removed stale source backup file:
- app/src/main/java/com/channelsdebrid/tv/LiveTvActivity.kt.bak_v27

Removed old historical patch-note clutter from the root project package.

Fixed Media Information TV/projector cropping root cause:
- TV safe area was applied before Media Info native layout, then native layout overwrote it.
- Media Info cast section was fixed-height and could be pushed/cropped when descriptions or future sections extend downward.
- Media Info left content now scrolls safely, with bottom scroll padding for cast/episodes/related sections.
- Cast section now uses wrap_content/min-height instead of a hard fixed height.
- Tablet layouts remain unchanged because TV safe area still no-ops unless the device is TV-like.

Preserved:
- donor one-row home system
- hero quality
- focus effects
- VOD player settings/tools
- cache rules
- Stremio, HDHomeRun, trailer, cast metadata, presets
