# NewtoOldv0.5 — Row/Menu Real Wiring Verification

Base: NewtoOldv0.4_LIVE_TV_LOGIC_XMLTV_DVR_AUTODETECT_REMOVED
Donor/reference: DebridChannels_v0_9_8_3_CI_JSON_EXCEPTION_FIX_CLEAN_SOURCE

## What this pass fixes
Previous packages added settings/toggles and bridge markers, but did not prove every real renderer path was using those settings. This pass patches the execution paths that actually create/bind visible row cards and top navigation.

## Real execution paths touched
- `MainActivity.RowAdapter.onCreateViewHolder()` and `onBindViewHolder()` now emit `ROW_SYSTEM_REPLACEMENT_ACTIVE` from the actual adapter used by home rows.
- Backend, static, TMDB, and Stremio row title paths now route row-title visibility through `HomeLayoutSettings.rowTextVisible`.
- TMDB/Stremio rows were specifically fixed because they were still using decorated titles without checking `rowTextVisible`.
- Main top menu now logs `TOP_MENU_REPLACEMENT_ACTIVE: target=MainActivity.topNav executionPath=real` from the actual `applyTopMenuIconStyle()` path.
- Live TV unified top nav is relabeled through the actual `LiveTvActivity.setupUnifiedShellNavigation()` path without touching the Live TV player or layout.
- 3D artwork now applies visible depth to focused card frame/artwork and logo path, so the toggle is no longer only a dormant setting.

## Verification markers
Look for these in logcat:
- `DC_BUILD_MARKER: NewtoOldv0.5_ROW_MENU_REAL_WIRING`
- `ROW_SYSTEM_REPLACEMENT_ACTIVE: create holder=NewAppLandscapeCard actualAdapter=MainActivity.RowAdapter`
- `ROW_SYSTEM_REPLACEMENT_ACTIVE: bind holder=NewAppLandscapeCard ...`
- `ROW_TEXT_TOGGLE_APPLY: source=backend|static|tmdb|stremio ...`
- `TOP_MENU_REPLACEMENT_ACTIVE: target=MainActivity.topNav executionPath=real`
- `TOP_MENU_REPLACEMENT_ACTIVE: target=LiveTvActivity.unifiedTopNav ...`
- `EXTRA_ARTWORK_3D_FRAME_APPLY: enabled=true ...`
- `EXTRA_ARTWORK_3D_APPLY: enabled=...`

## Not changed
- Player engine untouched.
- Live TV streaming logic preserved from v0.4.
- Live TV UI/layout untouched except top nav label replacement.
- Backend/artwork loading preserved.
- No DVR auto-detection reintroduced.
