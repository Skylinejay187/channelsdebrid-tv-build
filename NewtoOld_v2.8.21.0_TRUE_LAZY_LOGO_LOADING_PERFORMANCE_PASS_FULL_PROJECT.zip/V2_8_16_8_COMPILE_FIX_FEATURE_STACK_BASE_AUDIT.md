# NewtoOld v2.8.16.8 Compile Fix / Feature Stack Base

Base: v2.8.16.7 UI preset save/restore with player true production stack and row reset behavior preserved.

Fix:
- Removed invalid PlayerView.setFrameRate call that failed CI at PlayerActivity.kt:999.
- Replaced it with a safe frame-rate matching hook/log marker so playback is not blocked and future Surface-based implementation can be added safely.

Preserved:
- Donor/new-app one-row renderer.
- Focus scale/ring/lift effects.
- High-quality hero backdrop path.
- Cache OFF direct playback gate.
- Internal cache blocked unless NAS/USB is enabled.
- UI preset export/import.

Markers:
- versionName: NewtoOld_v2.8.16.8_COMPILE_FIX_FEATURE_STACK_BASE
- versionCode: 281608
- logcat: DC_BUILD_MARKER: NewtoOld_v2.8.16.8_COMPILE_FIX_FEATURE_STACK_BASE
