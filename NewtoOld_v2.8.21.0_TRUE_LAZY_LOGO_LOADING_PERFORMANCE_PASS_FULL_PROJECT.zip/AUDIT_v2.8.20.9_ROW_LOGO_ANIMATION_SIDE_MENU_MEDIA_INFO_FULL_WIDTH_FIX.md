# v2.8.20.9 Row Logo Animation + Side Menu + Media Info Full Width Fix

Planned/recorded changes from latest clean base v2.8.20.8:
- Row card logos/title overlays are focus-only, not always visible on unfocused cards.
- No clock/time overlay added; video timer was only a screen recording artifact.
- Focused row card reveal uses smooth fade + slide + scale style animation.
- Added optional Side Menu Bar mode as an alternative to Top Menu Bar.
- Media Information screen uses more horizontal screen real estate with reduced left gutter while preserving TV safe margins.
- Cast names restored under cast portraits.
- Media Info density kept TV/projector friendly so Cast and Related sections can fit better together.

Preserved:
- Backend/CDN routing behavior.
- QR/account sync backlog.
- XGIMI audio safeguards.
- Movies/Shows preload/cache behavior.
- Related portrait poster behavior.
