package com.channelsdebrid.tv.data

import android.content.Context

/**
 * Backend has been removed from NewtoOld v2.5.
 * This class remains as a no-network compatibility stub so old imports compile while
 * all artwork/catalog loading is handled by direct metadata providers and local cache.
 */
class BackendHomeLoader {
    data class BackendItem(
        val id: String,
        val type: String,
        val title: String,
        val year: Int,
        val genre: String,
        val overview: String,
        val source: String,
        val poster: String?,
        val backdrop: String?,
        val logo: String?,
        val imdbId: String?
    )

    data class BackendRow(
        val slug: String,
        val title: String,
        val items: List<BackendItem>
    )

    fun loadCachedRows(context: Context, baseUrl: String, limitPerRow: Int = 12): List<BackendRow> = emptyList()

    fun loadRows(context: Context, baseUrl: String, limitPerRow: Int = 12): List<BackendRow> {
        android.util.Log.i("DebridChannels", "BACKEND_HOME_LOADER: REMOVED")
        return emptyList()
    }
}
