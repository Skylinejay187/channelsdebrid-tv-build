package com.channelsdebrid.tv.playback

import com.channelsdebrid.tv.settings.DebridSettings
import com.channelsdebrid.tv.settings.PlaybackSettings
import com.channelsdebrid.tv.settings.StremioAddonSettings
import android.media.MediaCodecList
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.Locale

class StreamingPipelineResolver {

    data class StreamOption(
        val index: Int,
        val addonName: String,
        val displayTitle: String,
        val qualityLabel: String,
        val sizeLabel: String,
        val sourceLabel: String,
        val debug: String,
        val isDolbyVision: Boolean = false
    )

    data class StreamCandidate(
        val addonName: String,
        val title: String,
        val url: String? = null,
        val magnet: String? = null,
        val infoHash: String? = null,
        val fileIdx: Int? = null,
        val sizeBytes: Long? = null,
        val qualityScore: Int = 0,
        val debug: String = "",
        val isDolbyVision: Boolean = false,
        val isHdr10Plus: Boolean = false,
        val isHdr: Boolean = false
    )

    data class ResolvedStream(
        val url: String,
        val sourceLabel: String,
        val debugLabel: String
    )


    fun listCandidates(
        title: String,
        externalId: String,
        mediaType: String?,
        addons: List<StremioAddonSettings>,
        playback: PlaybackSettings
    ): List<StreamOption> {
        val normalizedType = when (mediaType?.lowercase(Locale.US)) {
            "movie" -> "movie"
            "series", "show", "tv" -> "series"
            else -> "movie"
        }
        return addons
            .asSequence()
            .filter { it.enabled && it.manifestUrl.isNotBlank() }
            .flatMap { addon -> loadCandidates(addon, normalizedType, externalId).asSequence() }
            .filter { candidate ->
                val limitGb = playback.fileSizeLimitGb.coerceAtLeast(1)
                val sizeGb = candidate.sizeBytes?.toDouble()?.div(1024.0 * 1024.0 * 1024.0)
                (sizeGb == null || sizeGb <= limitGb + 0.01) && qualityAllowed(candidate, playback.streamQualityPreference)
            }
            .sortedWith(streamComparator())
            .mapIndexed { index, candidate ->
                StreamOption(
                    index = index,
                    addonName = candidate.addonName,
                    displayTitle = candidate.title.ifBlank { title },
                    qualityLabel = qualityLabel(candidate),
                    sizeLabel = sizeLabel(candidate),
                    sourceLabel = candidate.addonName,
                    debug = candidate.debug,
                    isDolbyVision = candidate.isDolbyVision
                )
            }
            .toList()
    }

    fun resolveAtIndex(
        title: String,
        externalId: String,
        mediaType: String?,
        addons: List<StremioAddonSettings>,
        debrid: DebridSettings,
        playback: PlaybackSettings,
        candidateIndex: Int
    ): ResolvedStream? {
        return resolveAtIndexWithFallback(title, externalId, mediaType, addons, debrid, playback, candidateIndex)
    }

    fun resolveAtIndexWithFallback(
        title: String,
        externalId: String,
        mediaType: String?,
        addons: List<StremioAddonSettings>,
        debrid: DebridSettings,
        playback: PlaybackSettings,
        candidateIndex: Int
    ): ResolvedStream? {
        val normalizedType = when (mediaType?.lowercase(Locale.US)) {
            "movie" -> "movie"
            "series", "show", "tv" -> "series"
            else -> "movie"
        }
        val candidates = addons
            .asSequence()
            .filter { it.enabled && it.manifestUrl.isNotBlank() }
            .flatMap { addon -> loadCandidates(addon, normalizedType, externalId).asSequence() }
            .filter { candidate ->
                val limitGb = playback.fileSizeLimitGb.coerceAtLeast(1)
                val sizeGb = candidate.sizeBytes?.toDouble()?.div(1024.0 * 1024.0 * 1024.0)
                (sizeGb == null || sizeGb <= limitGb + 0.01) && qualityAllowed(candidate, playback.streamQualityPreference)
            }
            .sortedWith(streamComparator())
            .toList()
        if (candidates.isEmpty()) {
            android.util.Log.w("DebridChannels", "RESOLVER_FALLBACK: no_candidates title=${title.take(60)} externalId=$externalId")
            return null
        }
        val orderedIndexes = buildList {
            if (candidateIndex in candidates.indices) add(candidateIndex)
            for (i in candidates.indices) if (i != candidateIndex) add(i)
        }
        android.util.Log.i("DebridChannels", "RESOLVER_FALLBACK: candidates=${candidates.size} selected=$candidateIndex order=${orderedIndexes.take(6).joinToString(",")}")
        for ((attempt, index) in orderedIndexes.withIndex()) {
            val target = candidates[index]
            val resolved = resolveDirect(target)
            if (resolved == null) {
                android.util.Log.w("DebridChannels", "RESOLVER_FALLBACK: skip index=$index reason=no_direct_url")
                continue
            }
            val probe = probeStreamUrl(resolved.url)
            if (probe || attempt == 0) {
                val label = if (index == candidateIndex) resolved.sourceLabel else "${resolved.sourceLabel} • fallback #$index"
                android.util.Log.i("DebridChannels", "RESOLVER_FALLBACK: selected index=$index attempt=$attempt probe=$probe host=${runCatching { URL(resolved.url).host }.getOrDefault("unknown")}")
                return resolved.copy(sourceLabel = label, debugLabel = resolved.debugLabel + "\nResolver attempt: $attempt index=$index probe=$probe")
            }
            android.util.Log.w("DebridChannels", "RESOLVER_FALLBACK: probe_failed index=$index host=${runCatching { URL(resolved.url).host }.getOrDefault("unknown")}")
        }
        return null
    }

    private fun qualityAllowed(candidate: StreamCandidate, preference: String): Boolean {
        val pref = preference.lowercase(Locale.US).trim()
        val q = candidate.qualityScore
        return when {
            pref.isBlank() || pref == "auto" || pref == "4k preferred" -> true
            pref == "720p only" -> q in 200 until 300
            pref == "1080p only" -> q in 300 until 400
            pref == "4k only" -> q >= 400
            pref == "1080p or higher" -> q >= 300
            else -> true
        }
    }

    private fun qualityLabel(candidate: StreamCandidate): String {
        val base = when {
            candidate.qualityScore >= 400 -> "4K"
            candidate.qualityScore >= 300 -> "1080p"
            candidate.qualityScore >= 200 -> "720p"
            else -> "SD"
        }
        val tags = buildList {
            if (candidate.isDolbyVision) add("DV")
            if (candidate.isHdr10Plus) add("HDR10+")
            else if (candidate.isHdr) add("HDR")
        }
        return (listOf(base) + tags).joinToString(" • ")
    }

    private fun streamComparator(): Comparator<StreamCandidate> {
        val dolbyVisionSupported = isDolbyVisionSupported()
        return compareByDescending<StreamCandidate> { candidate ->
            candidate.qualityScore + when {
                candidate.isDolbyVision && dolbyVisionSupported -> 22
                candidate.isDolbyVision && !dolbyVisionSupported -> -120
                candidate.isHdr10Plus -> 12
                candidate.isHdr -> 8
                else -> 0
            }
        }.thenByDescending { it.sizeBytes ?: 0L }
    }

    private fun sizeLabel(candidate: StreamCandidate): String {
        val bytes = candidate.sizeBytes ?: return ""
        val gb = bytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
        return String.format(Locale.US, "%.1f GB", gb)
    }

    fun resolve(
        title: String,
        externalId: String,
        mediaType: String?,
        addons: List<StremioAddonSettings>,
        debrid: DebridSettings,
        playback: PlaybackSettings
    ): ResolvedStream? {
        val normalizedType = when (mediaType?.lowercase(Locale.US)) {
            "movie" -> "movie"
            "series", "show", "tv" -> "series"
            else -> "movie"
        }
        val candidates = addons
            .asSequence()
            .filter { it.enabled && it.manifestUrl.isNotBlank() }
            .flatMap { addon -> loadCandidates(addon, normalizedType, externalId).asSequence() }
            .filter { candidate ->
                val limitGb = playback.fileSizeLimitGb.coerceAtLeast(1)
                val sizeGb = candidate.sizeBytes?.toDouble()?.div(1024.0 * 1024.0 * 1024.0)
                (sizeGb == null || sizeGb <= limitGb + 0.01) && qualityAllowed(candidate, playback.streamQualityPreference)
            }
            .sortedWith(streamComparator())
            .toList()

        if (candidates.isEmpty()) return null

        android.util.Log.i("DebridChannels", "DEBRID_STATUS: NOT_PRESENT directOnly=true")
        return candidates.firstNotNullOfOrNull { resolveDirect(it) }
    }

    private fun buildProviderOrder(debrid: DebridSettings): List<String> {
        android.util.Log.i("DebridChannels", "DEBRID_STATUS: NOT_PRESENT directOnly=true")
        return listOf("direct")
    }

    private fun probeStreamUrl(url: String): Boolean {
        // Fast source health check for resolver fallback. Many CDN/playback URLs support HEAD;
        // when they do not, we treat 405 as usable and let ExoPlayer do the real open.
        return runCatching {
            val connection = URL(url).openConnection() as HttpURLConnection
            connection.requestMethod = "HEAD"
            connection.instanceFollowRedirects = true
            connection.connectTimeout = 3500
            connection.readTimeout = 3500
            connection.setRequestProperty("Range", "bytes=0-1")
            connection.setRequestProperty("User-Agent", "ChannelsDebridTV/2.8.16.5 ResolverProbe")
            val code = connection.responseCode
            connection.disconnect()
            code in 200..399 || code == 405 || code == 416
        }.getOrElse { error ->
            android.util.Log.w("DebridChannels", "RESOLVER_PROBE: unavailable ${error.javaClass.simpleName}:${error.message}")
            true
        }
    }

    private fun resolveDirect(candidate: StreamCandidate): ResolvedStream? {
        val direct = candidate.url?.takeIf { it.startsWith("http://") || it.startsWith("https://") } ?: return null
        return ResolvedStream(
            url = direct,
            sourceLabel = "${candidate.addonName} • Direct",
            debugLabel = candidate.debug.ifBlank { candidate.title }
        )
    }

    private fun loadCandidates(addon: StremioAddonSettings, mediaType: String, externalId: String): List<StreamCandidate> {
        val base = addon.manifestUrl.removeSuffix("/manifest.json").trimEnd('/')
        val streamUrl = "$base/stream/$mediaType/${URLEncoder.encode(externalId, "UTF-8")}.json".replace("+", "%20")
        val response = httpGetJson(streamUrl) ?: return emptyList()
        val streams = response.optJSONArray("streams") ?: return emptyList()
        val results = mutableListOf<StreamCandidate>()
        for (i in 0 until streams.length()) {
            val stream = streams.optJSONObject(i) ?: continue
            val title = buildCandidateTitle(stream)
            val debug = buildDebug(stream)
            val streamText = title + " " + stream.optString("description") + " " + stream.optString("name")
            val sizeBytes = parseSizeBytes(streamText)
            val qualityScore = scoreQuality(streamText)
            val isDv = looksDolbyVision(streamText)
            val isHdrPlus = looksHdr10Plus(streamText)
            val isHdr = isDv || isHdrPlus || looksHdr(streamText)
            val behaviorHints = stream.optJSONObject("behaviorHints")
            val directUrl = stream.optString("url").takeIf { it.startsWith("http://") || it.startsWith("https://") }
            val magnet = stream.optString("externalUrl").takeIf { it.startsWith("magnet:") }
                ?: stream.optString("infoHash").takeIf { it.isNotBlank() }?.let { "magnet:?xt=urn:btih:$it" }
                ?: behaviorHints?.optString("magnet")?.takeIf { it.startsWith("magnet:") }
            val infoHash = stream.optString("infoHash").ifBlank {
                behaviorHints?.optString("infoHash").orEmpty()
            }.ifBlank { null }
            val fileIdx = when {
                stream.has("fileIdx") -> stream.optInt("fileIdx")
                behaviorHints?.has("fileIdx") == true -> behaviorHints.optInt("fileIdx")
                else -> -1
            }.takeIf { it >= 0 }
            if (directUrl == null && magnet == null && infoHash == null) continue
            results += StreamCandidate(
                addonName = addon.name.ifBlank { "Stremio" },
                title = title,
                url = directUrl,
                magnet = magnet,
                infoHash = infoHash,
                fileIdx = fileIdx,
                sizeBytes = sizeBytes,
                qualityScore = qualityScore,
                debug = debug,
                isDolbyVision = isDv,
                isHdr10Plus = isHdrPlus,
                isHdr = isHdr
            )
        }
        return results
    }

    private fun buildCandidateTitle(stream: JSONObject): String {
        val parts = listOf(
            stream.optString("name").takeIf { it.isNotBlank() },
            stream.optString("title").takeIf { it.isNotBlank() },
            stream.optString("description").takeIf { it.isNotBlank() }
        )
        return parts.joinToString(" • ").ifBlank { "Addon stream" }
    }

    private fun buildDebug(stream: JSONObject): String {
        val behavior = stream.optJSONObject("behaviorHints")
        val infoHash = stream.optString("infoHash").ifBlank { behavior?.optString("infoHash").orEmpty() }
        val fileIdx = if (stream.has("fileIdx")) stream.optInt("fileIdx") else behavior?.optInt("fileIdx") ?: -1
        return buildString {
            append(stream.optString("title").ifBlank { stream.optString("name").ifBlank { "Stremio stream" } })
            if (infoHash.isNotBlank()) append("\nHash: ${infoHash.take(12)}…")
            if (fileIdx >= 0) append("\nFile index: $fileIdx")
        }
    }

    private fun scoreQuality(text: String): Int {
        val lower = text.lowercase(Locale.US)
        return when {
            listOf("2160", "4k", "uhd").any { it in lower } -> 400
            listOf("1080", "fhd").any { it in lower } -> 300
            listOf("720").any { it in lower } -> 200
            else -> 100
        } + when {
            "remux" in lower -> 40
            "bluray" in lower || "blu-ray" in lower -> 30
            "web-dl" in lower || "webrip" in lower -> 20
            else -> 0
        }
    }

    private fun looksDolbyVision(text: String): Boolean {
        val lower = text.lowercase(Locale.US)
        return listOf("dolby vision", "dovi", " dv ", " dv.", " dv-", " dv_", ".dv.", "-dv-").any { it in lower }
    }

    private fun looksHdr10Plus(text: String): Boolean {
        val lower = text.lowercase(Locale.US)
        return listOf("hdr10+", "hdr10plus", "hdr 10+").any { it in lower }
    }

    private fun looksHdr(text: String): Boolean {
        val lower = text.lowercase(Locale.US)
        return listOf("hdr", "hlg", "bt2020", "bt.2020").any { it in lower }
    }

    private fun isDolbyVisionSupported(): Boolean {
        if (Build.VERSION.SDK_INT < 24) return false
        return runCatching {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { codec ->
                !codec.isEncoder && codec.supportedTypes.any { type ->
                    type.equals("video/dolby-vision", ignoreCase = true)
                }
            }
        }.getOrDefault(false)
    }

    private fun parseSizeBytes(text: String): Long? {
        val regex = Regex("(\\d+(?:\\.\\d+)?)\\s*(gb|gib|mb|mib)", RegexOption.IGNORE_CASE)
        val match = regex.find(text) ?: return null
        val value = match.groupValues[1].toDoubleOrNull() ?: return null
        return when (match.groupValues[2].lowercase(Locale.US)) {
            "gb", "gib" -> (value * 1024 * 1024 * 1024).toLong()
            "mb", "mib" -> (value * 1024 * 1024).toLong()
            else -> null
        }
    }

    private fun isLikelyVideoFile(path: String): Boolean {
        val lower = path.lowercase(Locale.US)
        return listOf(".mkv", ".mp4", ".avi", ".ts", ".m2ts", ".mov", ".wmv").any { lower.endsWith(it) || it in lower }
    }

    private fun httpGetJson(url: String, headers: Map<String, String> = emptyMap()): JSONObject? {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 12000
        connection.readTimeout = 20000
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("User-Agent", "ChannelsDebridTV/1.0")
        headers.forEach { (key, value) -> connection.setRequestProperty(key, value) }
        return try {
            val body = (if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (connection.responseCode !in 200..299 || body.isBlank()) return null
            JSONObject(body)
        } catch (_: Exception) {
            null
        } finally {
            connection.disconnect()
        }
    }

    private fun httpFormJson(url: String, method: String, headers: Map<String, String>, form: LinkedHashMap<String, String>): JSONObject? {
        val connection = openFormConnection(url, method, headers, form)
        return try {
            val body = (if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (connection.responseCode !in 200..299 || body.isBlank()) return null
            JSONObject(body)
        } catch (_: Exception) {
            null
        } finally {
            connection.disconnect()
        }
    }

    private fun openFormConnection(url: String, method: String, headers: Map<String, String>, form: LinkedHashMap<String, String>): HttpURLConnection {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = method
        connection.doOutput = true
        connection.connectTimeout = 12000
        connection.readTimeout = 30000
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        connection.setRequestProperty("User-Agent", "ChannelsDebridTV/1.0")
        headers.forEach { (key, value) -> connection.setRequestProperty(key, value) }
        val body = form.entries.joinToString("&") { (k, v) -> "${URLEncoder.encode(k, "UTF-8") }=${URLEncoder.encode(v, "UTF-8")}" }
        OutputStreamWriter(connection.outputStream).use { it.write(body) }
        return connection
    }
}
