package com.channelsdebrid.tv.config

import android.content.Context
import android.util.Log

/** Native 4K-oriented mode: keep system density intact; apply UI presets in renderers. */
object UiModeApplier {
    fun apply(context: Context) {
        Log.i("DebridChannels", "NATIVE_4K_UI_MODE: density_override_removed ${UIConfigManager.describe(context)}")
    }
}
