package com.channelsdebrid.tv.config

import android.content.Context
import android.util.DisplayMetrics

/**
 * NewtoOld v2.6.2 native 4K-oriented UI config.
 * This intentionally does NOT mutate Android density. The new-app style 4K mode
 * uses layout presets, native spacing, text/artwork sizing, and 4K asset preference.
 */
object UIConfigManager {
    enum class UiRenderMode { AUTO, NATIVE_1080P, NATIVE_4K }
    enum class HeroMenuPosition { TOP, CENTER, LOWER, TOP_EDGE }

    var uiRenderMode: UiRenderMode = UiRenderMode.AUTO
    var heroMenuPosition: HeroMenuPosition = HeroMenuPosition.CENTER
    var heroLightingEnabled: Boolean = true
    var heroLightingIntensity: Float = 0.58f
    var hdHomeRunAutoScanEnabled: Boolean = true

    fun isNative4KActive(context: Context): Boolean {
        val width = context.resources.displayMetrics.widthPixels
        return when (uiRenderMode) {
            UiRenderMode.NATIVE_4K -> true
            UiRenderMode.NATIVE_1080P -> false
            UiRenderMode.AUTO -> width >= 3840
        }
    }

    fun is4KActive(context: Context): Boolean = isNative4KActive(context)

    fun menuTopMarginDp(context: Context, requested: HeroMenuPosition = heroMenuPosition): Int {
        val fourK = isNative4KActive(context)
        return when (requested) {
            HeroMenuPosition.TOP_EDGE -> if (fourK) 24 else 16
            HeroMenuPosition.TOP -> if (fourK) 54 else 42
            HeroMenuPosition.CENTER -> if (fourK) 82 else 58
            HeroMenuPosition.LOWER -> if (fourK) 124 else 96
        }
    }

    fun describe(context: Context): String {
        val dm: DisplayMetrics = context.resources.displayMetrics
        return "NATIVE_UI_MODE=$uiRenderMode active4K=${isNative4KActive(context)} width=${dm.widthPixels} density=${dm.density}"
    }
}
