package com.channelsdebrid.tv.data

class SourceTestRunner {
    private val probe = SourceProbe()
    private val tmdb = TmdbLiveLoader()

    fun testTmdb(apiKey: String, region: String, language: String): String {
        if (apiKey.isBlank()) return "TMDB key missing"
        val enabled = listOf("trending_movies")
        val rows = tmdb.loadRows(apiKey, region.ifBlank { "US" }, language.ifBlank { "en-US" }, enabled, 5)
        val count = rows.firstOrNull()?.items?.size ?: 0
        return if (count > 0) "TMDB connected • $count items loaded" else "TMDB connected • no items"
    }

    fun testStremio(name: String, manifestUrl: String): String {
        return probe.probeStremio(manifestUrl) ?: "$name manifest unavailable"
    }

    fun testChannelsDvr(autoDetect: Boolean, baseUrl: String): String {
        return probe.probeChannelsDvr(false, baseUrl) ?: "Channels DVR manual URL not configured"
    }

    fun testXtream(server: String, username: String, password: String, m3uUrl: String = ""): String {
        return probe.probeXtream(server, username, password, m3uUrl) ?: "Xtream or M3U not configured"
    }

    fun testRealDebrid(apiKey: String): String = "DEBRID_STATUS: NOT_PRESENT"

    fun testTorBox(apiKey: String): String = "DEBRID_STATUS: NOT_PRESENT"
}
