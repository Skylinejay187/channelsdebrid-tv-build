package com.channelsdebrid.tv.data

import android.content.Context
import android.util.Log
import com.channelsdebrid.tv.settings.SettingsRepository

/**
 * NewtoOld v2.4 backendless artwork provider.
 *
 * The app no longer needs the Debrid Channels backend for poster/backdrop/logo rows.
 * This provider resolves artwork directly from user-configured Stremio/Cinemeta catalogs
 * and optional TMDB settings, then lets Glide cache the final image URLs locally.
 */
class BackendlessArtworkProvider(private val context: Context) {
    private val settings = SettingsRepository(context)
    private val stremio = StremioLiveLoader()
    private val tmdb = TmdbLiveLoader()

    data class ArtworkItem(
        val title: String,
        val meta: String,
        val overview: String,
        val type: String,
        val externalId: String,
        val posterUrl: String?,
        val backdropUrl: String?,
        val logoUrl: String?,
        val source: String
    )

    data class ArtworkRow(
        val title: String,
        val items: List<ArtworkItem>
    )

    fun loadDirectRows(limitPerRow: Int = 24): List<ArtworkRow> {
        val rows = mutableListOf<ArtworkRow>()
        rows += loadStremioRows(limitPerRow)
        rows += loadTmdbRows(limitPerRow)
        val deduped = rows
            .map { row -> row.copy(items = row.items.dedupeArtworkItems()) }
            .filter { it.items.isNotEmpty() }
            .take(8)
        Log.i("DebridChannels", "ARTWORK_PROVIDER_DIRECT_ROWS: rows=${deduped.size} backendRequired=false")
        return deduped
    }

    private fun loadStremioRows(limitPerRow: Int): List<ArtworkRow> {
        return settings.loadStremioAddons()
            .filter { it.enabled && it.manifestUrl.isNotBlank() }
            .flatMap { addon ->
                runCatching { stremio.loadRows(addon.name.ifBlank { "Cinemeta" }, addon.manifestUrl, limitPerRow) }
                    .getOrDefault(emptyList())
                    .map { row ->
                        ArtworkRow(
                            title = row.title,
                            items = row.items.map { item ->
                                ArtworkItem(
                                    title = item.title,
                                    meta = item.meta,
                                    overview = item.desc,
                                    type = item.mediaType ?: "movie",
                                    externalId = item.externalId ?: item.title,
                                    posterUrl = item.posterUrl,
                                    backdropUrl = item.backdropUrl ?: item.posterUrl,
                                    logoUrl = item.logoUrl,
                                    source = addon.name.ifBlank { "Stremio" }
                                )
                            }
                        )
                    }
            }
    }

    private fun loadTmdbRows(limitPerRow: Int): List<ArtworkRow> {
        val tmdbSettings = settings.loadTmdb()
        if (tmdbSettings.apiKey.isBlank()) return emptyList()
        val enabled = settings.loadCatalogs().let { catalog ->
            buildList {
                if (catalog.trendingMoviesEnabled) add("trending_movies")
                if (catalog.popularMoviesEnabled) add("popular_movies")
                if (catalog.trendingShowsEnabled) add("trending_shows")
                if (catalog.popularShowsEnabled) add("popular_shows")
                if (catalog.platformRowsEnabled) add("platform_rows")
            }
        }
        return runCatching { tmdb.loadRows(tmdbSettings.apiKey, tmdbSettings.region, tmdbSettings.language, enabled, limitPerRow) }
            .getOrDefault(emptyList())
            .map { row ->
                ArtworkRow(
                    title = row.title,
                    items = row.items.map { item ->
                        ArtworkItem(
                            title = item.title,
                            meta = item.meta,
                            overview = item.desc,
                            type = item.mediaType ?: "movie",
                            externalId = item.externalId ?: item.tmdbId.takeIf { it > 0 }?.let { "tmdb:$it" } ?: item.title,
                            posterUrl = item.posterUrl,
                            backdropUrl = item.backdropUrl ?: item.posterUrl,
                            logoUrl = item.logoUrl,
                            source = "TMDB"
                        )
                    }
                )
            }
    }

    private fun List<ArtworkItem>.dedupeArtworkItems(): List<ArtworkItem> {
        val seen = LinkedHashSet<String>()
        return filter { item ->
            val key = item.externalId.ifBlank { item.title }.lowercase()
            seen.add(key)
        }
    }
}
