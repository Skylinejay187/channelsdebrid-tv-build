# NewtoOld v2.8.16.1 — Donor New-App One-Row Swap Audit

Base: v2.8.16.0 NewtoOld source plus uploaded donor new app zip `DebridChannels_v0_9_8_1_CI_COMPILE_FIX_CLEAN_SOURCE.zip`.

User correction honored:
- Deleted the visible multi-row viewport behavior from the active renderer.
- Removed the seven-card viewport window behavior.
- Home now attaches only the active row at a time.
- Active row uses the donor-style HorizontalScrollView + LinearLayout row/card interaction path.
- Full row item count is preserved in the active row; no seven-card visual cap.
- DPAD UP/DOWN swaps the active row instead of showing previous/next rows stacked together.
- Extra art is preserved; no extra-art removal.
- Cache remains OFF by default and internal disk cache remains blocked.

Markers:
- versionCode: 281601
- versionName: NewtoOld_v2.8.16.1_DONOR_NEW_APP_ONE_ROW_SWAP
- logcat: DC_BUILD_MARKER: NewtoOld_v2.8.16.1_DONOR_NEW_APP_ONE_ROW_SWAP
- row marker: ROW_ENGINE: V9_DONOR_NEW_APP_ONE_ACTIVE_ROW_FULL_CARD_STRIP

Backlog preserved:
- Infuse-style forced prefetch / full anti-buffer cache engine remains backlog until NAS/USB cache path is redesigned.
