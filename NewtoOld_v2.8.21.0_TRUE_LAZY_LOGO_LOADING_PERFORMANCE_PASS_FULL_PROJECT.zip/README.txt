Android source placeholder with guide + trailer wiring instructions

NewtoOld_v2.8.18.3_EPG_CACHE_WINDOW_3_6_12_REBUILD_CLEAN
- Live TV/Channels DVR EPG cache window options limited to 3, 6, and 12 hours.
- Default EPG cache window changed from 12 hours to 6 hours.
- No VOD/player/row/hero/cache changes.
