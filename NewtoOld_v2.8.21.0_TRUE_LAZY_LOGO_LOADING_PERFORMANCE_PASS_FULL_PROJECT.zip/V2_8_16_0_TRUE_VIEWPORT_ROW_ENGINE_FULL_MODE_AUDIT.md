# NewtoOld v2.8.16.0 TRUE_VIEWPORT_ROW_ENGINE_FULL_MODE Audit

Clean/consolidated rebuild from latest NewtoOld v2.8.15.17 row-system swap source.

## Preserved
- Old app shell/features remain the base.
- Extra artwork layer remains enabled and user-configurable; it was not removed.
- Pro layout/editor-related settings are preserved.
- Cache remains OFF by default.
- Internal disk VOD cache remains blocked. Cache is only allowed when NAS/USB/external target is explicitly enabled.

## Fixed
- Kotlin compile failure from v2.8.15.17 at MainActivity.kt lines 731/732 fixed by making DPAD LEFT/RIGHT handlers return explicit Boolean values.
- Build markers and Gradle versionName moved to NewtoOld_v2.8.16.0_TRUE_VIEWPORT_ROW_ENGINE_FULL_MODE.
- Row-system audit marker documents that the old NewtoOld row stack is bypassed and the full-mode viewport row path is active.

## Full mode target
- Rows and XMLTV/Live TV are kept active, per Option B.
- Known OOM risk from older XMLTV full-text loading is marked as a required streaming-parser guard item; do not reintroduce ByteArrayOutputStream guide loading.

## Verification markers expected
- DC_BUILD_MARKER: NewtoOld_v2.8.16.0_TRUE_VIEWPORT_ROW_ENGINE_FULL_MODE
- ROW_ENGINE: V5_TRUE_REPLACEMENT_LINEAR_ROWS_NO_RECYCLER_JUMP
- ROW_ENGINE: OLD_VERTICAL_RECYCLER_BYPASSED_STABLE_LINEAR_ROWS_ACTIVE

## Important
This source zip fixes the reported compile blocker. APK build verification still needs to run in your GitHub/Gradle build workflow because this sandbox has no working Gradle installation.
