# NewtoOld v2.8.18.4 Settings Clickable Fix Audit

Base: NewtoOld_v2.8.18.3_EPG_CACHE_WINDOW_3_6_12_REBUILD_CLEAN

Scope preserved:
- Existing row/hero/focus behavior unchanged
- Existing VOD/player/cache/link switching/trickplay behavior unchanged
- Existing EPG 3/6/12 behavior unchanged

Fixes:
- Player settings dropdowns are now focusable/clickable on Android TV remotes and open on click/focus.
- Settings sidebar navigation labels now jump to relevant sections, including Player and Stremio.
- Stremio Add Source no longer blocks the UI while manifest metadata is fetched.
- Manifest name/logo enrichment still runs in the background after the source is added.

Log markers:
- DC_BUILD_MARKER: NewtoOld_v2.8.18.4_SETTINGS_CLICKABLE_FIX
- SETTINGS_PLAYER_DROPDOWNS_CLICKABLE: true
- SETTINGS_NAV_CLICKABLE: player_stremio_storage=true
