# NewtoOld v2.8.16.5 Player True Production Stack Audit

Scope: player-only upgrade from v2.8.16.4 base. Row system, focus effects, hero quality, cache-off direct playback, extra art, and layout editor paths were not intentionally changed.

Added/changed:
- Capability-aware track selector preferring Dolby Vision/HEVC/H.264 video and Atmos/DD+/AC3/DTS/TrueHD/AAC audio.
- Decoder fallback and extension renderer preference preserved.
- Direct VOD buffering increased to 20s min / 180s max while keeping cache OFF as direct playback only.
- NAS full-ahead mode preserved only when NAS cache is explicitly enabled/configured.
- Frame-rate matching hook requests selected video FPS via Android display frame-rate APIs when available.
- HDR/Dolby/audio diagnostics log selected format, color transfer, mime support, channels, sample rate, and codec strings.
- Resolver fallback now tries the selected source first, then ranked alternatives if the selected source cannot resolve/probe.
- Startup stall watchdog logs no-first-frame states without crashing or changing UI flow.

Known limits:
- Dolby Vision/HDR/audio passthrough remains device/firmware/HDMI dependent.
- Frame-rate matching is best-effort and only active on Android 11/API 30+ display APIs.
- APK compile was not run in this sandbox because Gradle is not installed; use the provided project workflow or local Gradle.
