package com.channelsdebrid.tv

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.channelsdebrid.tv.core.AppNavigationController
import com.channelsdebrid.tv.core.BuildMarkers
import com.channelsdebrid.tv.core.GuideCacheOwner
import com.channelsdebrid.tv.core.LiveTvStateMachine
import com.channelsdebrid.tv.databinding.ActivityLiveTvBinding
import com.channelsdebrid.tv.playback.PlayerActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.roundToInt

class LiveTvActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLiveTvBinding
    private lateinit var navigation: AppNavigationController
    private val state = LiveTvStateMachine()
    private val main = Handler(Looper.getMainLooper())
    private var channels: List<GuideCacheOwner.Channel> = emptyList()
    private var filtered: List<GuideCacheOwner.Channel> = emptyList()
    private var groups: List<String> = listOf("All Channels")
    private var selectedGroup = "All Channels"
    private var selectedIndex = 0
    private var launchingPlayer = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        BuildMarkers.log("LiveTvActivity")
        supportActionBar?.hide()
        binding = ActivityLiveTvBinding.inflate(layoutInflater)
        setContentView(binding.root)
        navigation = AppNavigationController(this)
        wireTopNav()
        wireRefresh()
        loadGuide()
    }

    override fun onResume() {
        super.onResume()
        launchingPlayer = false
        if (state.state == LiveTvStateMachine.State.PLAYER_LAUNCHING) state.moveTo(LiveTvStateMachine.State.PLAYER_RETURNED, "resume-from-player")
        main.postDelayed({ focusSelectedChannel() }, 180L)
    }

    override fun onDestroy() {
        state.moveTo(LiveTvStateMachine.State.DESTROYED, "destroy")
        main.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun wireTopNav() {
        binding.navResume.setOnClickListener { goMain("resume") }
        binding.navSmart.setOnClickListener { goMain("smart") }
        binding.navMovies.setOnClickListener { goMain("movies") }
        binding.navShows.setOnClickListener { goMain("shows") }
        binding.navLive.setOnClickListener { focusSelectedChannel() }
    }

    private fun goMain(reason: String) {
        navigation.launch(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP), "MainActivity:$reason", finishCurrent = true)
    }

    private fun wireRefresh() {
        binding.liveTvForceGuideButton.setOnClickListener { loadGuide(force = true) }
    }

    private fun loadGuide(force: Boolean = false) {
        state.moveTo(LiveTvStateMachine.State.LOADING_GUIDE, if (force) "force" else "startup")
        showLoading(true, if (force) "Refreshing guide" else "Loading channels", "Pulling guide data and lineup details…")
        thread(name = "v4-guide-loader") {
            val (loaded, message) = runCatching { GuideCacheOwner(applicationContext).loadChannels() }
                .getOrElse { emptyList<GuideCacheOwner.Channel>() to "Guide load error: ${it.message.orEmpty()}" }
            main.post {
                channels = loaded
                if (channels.isEmpty()) {
                    channels = fallbackChannels()
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                }
                buildGroups()
                renderGuide(message)
                showLoading(false)
                state.moveTo(LiveTvStateMachine.State.GUIDE_READY, "channels=${channels.size}")
                focusSelectedChannel()
            }
        }
    }

    private fun buildGroups() {
        groups = (listOf("All Channels") + channels.flatMap { it.groups }.filter { it.isNotBlank() }).distinct()
        if (selectedGroup !in groups) selectedGroup = "All Channels"
        filtered = filterChannels()
        if (selectedIndex >= filtered.size) selectedIndex = 0
    }

    private fun filterChannels(): List<GuideCacheOwner.Channel> = if (selectedGroup == "All Channels") channels else channels.filter { selectedGroup in it.groups }

    private fun renderGuide(message: String) {
        renderCategories()
        renderTimeline()
        renderChannels()
        binding.liveTvStatusSources.text = message
        updateInfoPanel(filtered.getOrNull(selectedIndex))
    }

    private fun renderCategories() {
        binding.liveTvCategoryRail.removeAllViews()
        groups.forEach { group ->
            val item = TextView(this).apply {
                text = group
                textSize = 16f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER_VERTICAL
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                isFocusable = true
                isClickable = true
                background = getDrawable(if (group == selectedGroup) R.drawable.guide_category_selected else R.drawable.guide_category_idle)
                setPadding(dp(16), 0, dp(12), 0)
                setOnClickListener {
                    selectedGroup = group
                    selectedIndex = 0
                    filtered = filterChannels()
                    renderCategories()
                    renderChannels()
                    updateInfoPanel(filtered.firstOrNull())
                    focusSelectedChannel()
                }
            }
            binding.liveTvCategoryRail.addView(item, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)).apply { bottomMargin = dp(8) })
        }
    }

    private fun renderTimeline() {
        binding.liveTvTimeline.removeAllViews()
        val now = SimpleDateFormat("h:mm a", Locale.US).format(Date())
        listOf(now, "+30 min", "+60 min", "+90 min", "+120 min").forEach { label ->
            binding.liveTvTimeline.addView(TextView(this).apply {
                text = label
                textSize = 13f
                setTextColor(0xCCFFFFFF.toInt())
                gravity = Gravity.CENTER_VERTICAL
                typeface = Typeface.DEFAULT_BOLD
            }, LinearLayout.LayoutParams(dp(210), LinearLayout.LayoutParams.MATCH_PARENT))
        }
    }

    private fun renderChannels() {
        binding.liveTvChannelList.removeAllViews()
        filtered = filterChannels()
        if (filtered.isEmpty()) {
            binding.liveTvChannelList.addView(TextView(this).apply {
                text = "No channels found for $selectedGroup"
                setTextColor(Color.WHITE)
                textSize = 22f
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), 0, 0, 0)
            }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(74)))
            return
        }
        filtered.forEachIndexed { index, channel ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isFocusable = true
                isClickable = true
                background = getDrawable(if (index == selectedIndex) R.drawable.guide_row_selected else R.drawable.guide_row_bg)
                setPadding(dp(10), 0, dp(10), 0)
                setOnFocusChangeListener { _, hasFocus -> if (hasFocus) { selectedIndex = index; updateInfoPanel(channel); refreshRowBackgrounds() } }
                setOnClickListener { openPlayer(index) }
            }
            row.addView(TextView(this).apply {
                text = channel.number.ifBlank { (index + 1).toString() }
                setTextColor(Color.WHITE)
                textSize = 15f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                background = getDrawable(R.drawable.guide_logo_tile)
            }, LinearLayout.LayoutParams(dp(72), dp(54)).apply { rightMargin = dp(12) })
            row.addView(TextView(this).apply {
                text = channel.name
                setTextColor(Color.WHITE)
                textSize = 17f
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(dp(210), LinearLayout.LayoutParams.MATCH_PARENT).apply { rightMargin = dp(8) })
            repeat(4) { slot ->
                row.addView(TextView(this).apply {
                    text = if (slot == 0) "Live • ${channel.source}" else "Upcoming"
                    setTextColor(if (slot == 0) Color.WHITE else 0xB8FFFFFF.toInt())
                    textSize = 14f
                    gravity = Gravity.CENTER_VERTICAL
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    background = getDrawable(if (slot == 0 && index == selectedIndex) R.drawable.guide_program_card_selected else R.drawable.guide_program_card)
                    setPadding(dp(12), 0, dp(12), 0)
                }, LinearLayout.LayoutParams(dp(210), dp(58)).apply { rightMargin = dp(8) })
            }
            binding.liveTvChannelList.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(66)).apply { bottomMargin = dp(6) })
        }
    }

    private fun refreshRowBackgrounds() {
        for (i in 0 until binding.liveTvChannelList.childCount) {
            binding.liveTvChannelList.getChildAt(i).background = getDrawable(if (i == selectedIndex) R.drawable.guide_row_selected else R.drawable.guide_row_bg)
        }
    }

    private fun updateInfoPanel(channel: GuideCacheOwner.Channel?) {
        if (channel == null) {
            binding.liveTvInfoChannel.text = "Live TV"
            binding.liveTvInfoGroup.text = selectedGroup
            binding.liveTvDescription.text = "No channels are available yet. Check your source settings."
            binding.liveTvPreviewHint.text = "No channel selected"
            return
        }
        binding.liveTvInfoChannel.text = channel.name
        binding.liveTvInfoGroup.text = channel.groups.firstOrNull().orEmpty().ifBlank { channel.source }
        binding.liveTvNowTime.text = SimpleDateFormat("EEE h:mm a", Locale.US).format(Date())
        binding.liveTvDescription.text = channel.debug.ifBlank { "${channel.source} channel${if (channel.number.isNotBlank()) " • ${channel.number}" else ""}" }
        binding.liveTvInfoLogo.text = channel.name.take(2).uppercase(Locale.US)
        binding.liveTvPreviewHint.text = "Press OK to watch"
    }

    private fun openPlayer(index: Int) {
        val channel = filtered.getOrNull(index) ?: return
        if (launchingPlayer || state.isLaunchingPlayer()) return
        launchingPlayer = true
        state.moveTo(LiveTvStateMachine.State.PLAYER_LAUNCHING, "channel=${channel.name}")
        val intent = Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_STREAM_URL, channel.url)
            putExtra(PlayerActivity.EXTRA_TITLE, channel.name)
            putExtra(PlayerActivity.EXTRA_SOURCE_LABEL, channel.source)
            putExtra(PlayerActivity.EXTRA_CHANNEL_INDEX, index)
            putExtra(PlayerActivity.EXTRA_CHANNELS_JSON, encodeChannels(filtered))
            putExtra(PlayerActivity.EXTRA_VOD_MODE, false)
        }
        navigation.launch(intent, "PlayerActivity:live:${channel.name}", finishCurrent = false, minIntervalMs = 900L)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN || !state.acceptsGuideInput()) return super.dispatchKeyEvent(event)
        when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                val focusedIndex = indexOfFocusedRow()
                openPlayer(if (focusedIndex >= 0) focusedIndex else selectedIndex)
                return true
            }
            KeyEvent.KEYCODE_DPAD_UP -> if (selectedIndex == 0) { binding.navLive.requestFocus(); return true }
            KeyEvent.KEYCODE_BACK -> { navigation.finishOnly("back-from-live"); return true }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun indexOfFocusedRow(): Int {
        val focus = currentFocus ?: return -1
        for (i in 0 until binding.liveTvChannelList.childCount) if (binding.liveTvChannelList.getChildAt(i) == focus) return i
        return -1
    }

    private fun focusSelectedChannel() {
        if (binding.liveTvLoadingOverlay.isVisible) return
        val child = binding.liveTvChannelList.getChildAt(selectedIndex.coerceAtLeast(0))
        child?.requestFocus() ?: binding.navLive.requestFocus()
    }

    private fun showLoading(show: Boolean, title: String = "Loading channels", subtitle: String = "Pulling guide data and lineup details…") {
        binding.liveTvLoadingTitle.text = title
        binding.liveTvLoadingSubtitle.text = subtitle
        binding.liveTvLoadingOverlay.visibility = if (show) View.VISIBLE else View.GONE
    }

    private fun encodeChannels(list: List<GuideCacheOwner.Channel>): String = JSONArray().also { arr ->
        list.forEach { ch ->
            arr.put(JSONObject().apply {
                put("name", ch.name); put("url", ch.url); put("source", ch.source); put("debug", ch.debug); put("number", ch.number)
            })
        }
    }.toString()

    private fun fallbackChannels(): List<GuideCacheOwner.Channel> = listOf(
        GuideCacheOwner.Channel("Configure Live Source", "", "Setup", "Open Settings > Live TV to add Channels DVR, HDHomeRun, Xtream, or M3U.", listOf("Setup"), "1")
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()
}
