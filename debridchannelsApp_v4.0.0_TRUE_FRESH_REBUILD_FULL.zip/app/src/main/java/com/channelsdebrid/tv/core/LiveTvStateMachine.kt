package com.channelsdebrid.tv.core

class LiveTvStateMachine {
    enum class State { CREATED, LOADING_GUIDE, GUIDE_READY, PLAYER_LAUNCHING, PLAYER_RETURNED, DESTROYED }
    var state: State = State.CREATED
        private set

    fun moveTo(next: State, reason: String) {
        if (state == State.DESTROYED && next != State.DESTROYED) return
        if (state != next) {
            BuildMarkers.trace("LiveTvStateMachine", "${state.name}->${next.name} reason=$reason")
            state = next
        }
    }

    fun acceptsGuideInput(): Boolean = state == State.GUIDE_READY || state == State.PLAYER_RETURNED
    fun isLaunchingPlayer(): Boolean = state == State.PLAYER_LAUNCHING
}
