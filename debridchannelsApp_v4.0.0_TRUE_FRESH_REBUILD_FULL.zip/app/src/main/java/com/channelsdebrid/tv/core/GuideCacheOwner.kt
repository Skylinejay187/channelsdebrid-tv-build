package com.channelsdebrid.tv.core

import android.content.Context
import android.util.Log
import com.channelsdebrid.tv.live.LiveSourceResolver
import com.channelsdebrid.tv.settings.SettingsRepository

class GuideCacheOwner(private val context: Context) {
    data class Channel(
        val name: String,
        val url: String,
        val source: String,
        val debug: String = "",
        val groups: List<String> = emptyList(),
        val number: String = "",
        val iconUrl: String = ""
    )

    fun loadChannels(): Pair<List<Channel>, String> {
        val settings = SettingsRepository(context)
        val messages = mutableListOf<String>()
        val out = mutableListOf<Channel>()

        runCatching {
            val dvr = settings.loadChannelsDvr()
            val base = dvr.baseUrl.ifBlank { if (dvr.autoDetect) LiveSourceResolver.discoverChannelsDvrBaseUrl().orEmpty() else "" }
            if (base.isNotBlank()) {
                val result = LiveSourceResolver.loadDvrChannels(base, dvr.deviceId)
                messages += result.message
                out += result.channels.map { it.toChannel() }
            }
        }.onFailure { messages += "Channels DVR error: ${it.message.orEmpty()}" }

        runCatching {
            val hd = LiveSourceResolver.loadHdHomeRunChannels()
            messages += hd.message
            out += hd.channels.map { it.toChannel() }
        }.onFailure { messages += "HDHomeRun error: ${it.message.orEmpty()}" }

        runCatching {
            val xtream = settings.loadXtream()
            if (xtream.enabled && xtream.m3uUrl.isNotBlank()) {
                val (channels, msg) = LiveSourceResolver.loadM3uChannels(xtream.m3uUrl)
                messages += msg
                out += channels.map { it.toChannel() }
            } else if (xtream.enabled && xtream.server.isNotBlank() && xtream.username.isNotBlank()) {
                val (channels, msg) = LiveSourceResolver.loadXtreamChannels(xtream.server, xtream.username, xtream.password)
                messages += msg
                out += channels.map { it.toChannel() }
            }
        }.onFailure { messages += "IPTV error: ${it.message.orEmpty()}" }

        val deduped = out.filter { it.url.isNotBlank() }.distinctBy { it.source + "|" + it.number + "|" + it.name + "|" + it.url }
        val message = messages.filter { it.isNotBlank() }.distinct().joinToString(" • ").ifBlank { "No configured live sources returned channels" }
        Log.i("DebridChannels", "GuideCacheOwner loaded channels=${deduped.size} message=$message")
        return deduped to message
    }

    private fun LiveSourceResolver.ChannelItem.toChannel(): Channel = Channel(name, url, source, debug, groups, number, iconUrl)
}
