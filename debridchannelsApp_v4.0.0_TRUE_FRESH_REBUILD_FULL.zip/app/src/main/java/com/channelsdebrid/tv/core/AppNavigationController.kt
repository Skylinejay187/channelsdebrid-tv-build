package com.channelsdebrid.tv.core

import android.app.Activity
import android.content.Intent
import android.os.SystemClock

class AppNavigationController(private val activity: Activity) {
    private var lastLaunchAtMs = 0L
    private var lastTarget = ""

    fun launch(intent: Intent, target: String, finishCurrent: Boolean = false, minIntervalMs: Long = 650L): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (target == lastTarget && now - lastLaunchAtMs < minIntervalMs) {
            BuildMarkers.trace("NavigationController", "blocked duplicate target=$target")
            return false
        }
        lastTarget = target
        lastLaunchAtMs = now
        BuildMarkers.trace("NavigationController", "launch target=$target finish=$finishCurrent")
        activity.startActivity(intent)
        activity.overridePendingTransition(0, 0)
        if (finishCurrent && !activity.isFinishing) activity.finish()
        return true
    }

    fun finishOnly(reason: String) {
        BuildMarkers.trace("NavigationController", "finish reason=$reason")
        if (!activity.isFinishing) activity.finish()
    }
}
