package com.channelsdebrid.tv.core

import android.util.Log
import com.channelsdebrid.tv.BuildConfig

object BuildMarkers {
    const val BUILD_MARKER = "V4_FRESH_REBUILD_START"
    const val ARCHITECTURE_MARKER = "fresh_project_shell_one_navigation_one_player_one_livetv_engine_one_guide_cache_one_timeshift_one_pro_layout"

    fun log(component: String) {
        Log.i("DebridChannels", "$BUILD_MARKER component=$component build=${BuildConfig.VERSION_NAME} code=${BuildConfig.VERSION_CODE} arch=$ARCHITECTURE_MARKER")
    }

    fun trace(component: String, message: String) {
        Log.i("DebridChannels", "$BUILD_MARKER component=$component $message")
    }
}
