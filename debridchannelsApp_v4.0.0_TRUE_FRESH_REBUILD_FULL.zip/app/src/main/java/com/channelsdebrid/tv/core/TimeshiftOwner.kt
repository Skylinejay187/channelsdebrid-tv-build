package com.channelsdebrid.tv.core

import android.content.Context
import android.os.SystemClock
import android.util.Log
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import com.channelsdebrid.tv.settings.SettingsRepository

class TimeshiftOwner(private val context: Context) {
    private var channelKey: String = ""
    private var startedAtMs = 0L
    private var enabled = false

    fun start(channelName: String, streamUrl: String) {
        enabled = SettingsRepository(context).loadPlayback().timeshiftEnabled
        channelKey = channelName + "|" + streamUrl.take(96)
        startedAtMs = SystemClock.elapsedRealtime()
        Log.i("DebridChannels", "TimeshiftOwner start enabled=$enabled channel=$channelName")
    }

    fun stop(reason: String) {
        if (channelKey.isNotBlank()) Log.i("DebridChannels", "TimeshiftOwner stop reason=$reason ageMs=${bufferAgeMs()}")
        channelKey = ""
        startedAtMs = 0L
    }

    fun bufferAgeMs(): Long = if (startedAtMs == 0L) 0L else SystemClock.elapsedRealtime() - startedAtMs

    fun seekBack(player: ExoPlayer, amountMs: Long): Boolean {
        if (!enabled) return false
        val duration = player.duration
        val seekable = player.isCurrentMediaItemSeekable && duration != C.TIME_UNSET && duration > 0
        if (!seekable) return false
        player.seekTo((player.currentPosition - amountMs).coerceAtLeast(0L))
        return true
    }

    fun seekForward(player: ExoPlayer, amountMs: Long): Boolean {
        val duration = player.duration
        if (duration == C.TIME_UNSET || duration <= 0) return false
        player.seekTo((player.currentPosition + amountMs).coerceAtMost(duration))
        return true
    }

    fun label(): String = when {
        !enabled -> "Timeshift Off"
        bufferAgeMs() < 30_000L -> "Timeshift building"
        else -> "Timeshift ready"
    }
}
