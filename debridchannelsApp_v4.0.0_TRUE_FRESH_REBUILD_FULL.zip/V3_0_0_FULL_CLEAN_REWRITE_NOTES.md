# Debrid Channels v3.0.0 Full Clean Architecture Rewrite

This zip is the v3 architecture baseline. It preserves the existing visual direction:

- Live TV guide look is intentionally kept from the working guide tree.
- VOD player artwork, rating, poster, logo, metadata, and overlay structure are preserved.
- Pro Layout Editor settings are promoted into a single owner path.

Core ownership model:

- `AppNavigationController` = one navigation/launch gate owner.
- `UnifiedPlayerManager` = one player engine owner for VOD, Live, and preview modes.
- `LiveTvStateMachine` = one Live TV state owner.
- `GuideCacheOwner` = one guide/source/cache owner.
- `TimeshiftOwner` = one timeshift owner.
- `ProLayoutManager` = one Pro Layout persistence/application owner.

Verification marker:

```bash
logcat -v time | grep V3_FULL_CLEAN_REWRITE_START
```

Expected version:

`3.0.0-full-clean-architecture`
