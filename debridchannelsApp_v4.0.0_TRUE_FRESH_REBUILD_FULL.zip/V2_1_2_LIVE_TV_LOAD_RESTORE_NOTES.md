# v2.1.2 Live TV Load Restore

Restores known-good full Live TV guide tree before v3 rewrite. Marker: TRUE_LIVETV_LOAD_FIX_START.
