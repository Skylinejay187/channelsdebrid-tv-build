# Debrid Channels v4.0.0 Fresh Rebuild

Fresh app architecture pass with unchanged backend API contract.

Log marker: V4_FRESH_REBUILD_START
