# v2.1.3 Pro Layout Menu + Artwork + Live TV Build Fix

- Fixed LiveTvActivity compile issue by importing BuildMarkers and android.util.Log.
- Updated version marker to 2.1.3-pro-layout-menu-art-livefix / versionCode 81.
- Added Pro Layout Editor controls for integrated middle-menu actions:
  - Menu composition: classic, integrated, hybrid.
  - Search icon placement: left, inside middle menu, right, hidden.
  - Settings icon placement: left, inside middle menu, right, hidden.
- Added row title visibility toggle.
- Added hero extra artwork controls:
  - Artwork enabled.
  - Artwork type: logo, clearart/character, disc/DVD art, banner, landscape, poster, studio/network, keyart thumbnail.
  - X/Y position, width/height, opacity, 3D pop depth.
- Added preview placeholders so these settings can be verified in Pro Layout Editor before v3.0.0 final architecture rewrite.

Log markers:
- TRUE_LIVETV_LOAD_FIX_START
- BuildMarkers component=LiveTvActivity_LOAD_RESTORE
