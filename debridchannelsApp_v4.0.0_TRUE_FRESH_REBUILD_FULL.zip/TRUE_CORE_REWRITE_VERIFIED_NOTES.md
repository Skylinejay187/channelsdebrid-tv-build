# Debrid Channels v2.1.1 TRUE CORE REWRITE VERIFIED

This build is a consolidation/rewrite pass, not another layered patch.

Verified ownership structure added:
- core/AppNavigationController.kt = one app navigation owner / duplicate-launch guard
- playback/UnifiedPlayerManager.kt = one player manager class for VOD, Live, and Preview modes
- core/LiveTvStateMachine.kt = one Live TV state machine
- core/GuideCacheOwner.kt = one guide/source/cache owner
- core/TimeshiftOwner.kt = one timeshift owner
- core/BuildMarkers.kt = build/version/logcat markers

Removed old layered LiveTvActivity focus/DPAD patch paths and rewrote LiveTvActivity around the state machine.
Rewrote PlayerActivity around UnifiedPlayerManager while preserving VOD poster/logo/metadata/control UI IDs.

Logcat verification marker:
TRUE_CORE_REWRITE_VERIFIED_START

Visible version:
2.1.1-true-core-rewrite-verified
