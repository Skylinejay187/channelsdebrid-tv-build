package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.5.5 LIVE TV EXACT GOOGLE STRUCTURAL REBUILD";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.5.5_live_tv_actual_layout_replacement_clean_base";
    private BuildMarkers() {}
}
