# Debrid Channels Android TV — Phase 1 Compose Import Fix 2

Built from `DebridChannels_AndroidTV_Phase1_Java17_Workflow_Fix_GITHUB.zip`.

## GitHub Actions failure fixed

The Android build reached `:app:compileDebugKotlin` and failed on exactly three Compose import errors:

1. `LiveTvCard.kt` used `Modifier.height(...)` without importing `androidx.compose.foundation.layout.height`.
2. `TopMenuBar.kt` explicitly imported `androidx.compose.foundation.layout.weight`, which resolves to an internal symbol with the selected Compose/Kotlin toolchain.
3. `DetailAndUtilityScreens.kt` had the same invalid explicit `weight` import.

## Correction

- Added the public `height` modifier import to `LiveTvCard.kt`.
- Removed both explicit `weight` imports. `Modifier.weight(...)` is used inside `Row` content lambdas, where the public `RowScope.weight` member extension is available automatically.
- Preserved the Java 17-compatible Gradle wrapper from the previous fix.
- No UI geometry, app behavior, resources, Gradle versions, modules, or workflow requirements changed.

Use the same existing `Build Android TV APK from ZIP` workflow.
