package com.debridchannels.tv.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import com.debridchannels.core.designsystem.DebridColors
import com.debridchannels.core.designsystem.FocusSurface
import com.debridchannels.core.model.LiveChannel
import com.debridchannels.core.model.MediaItem
import com.debridchannels.core.model.SourceResult
import com.debridchannels.tv.ui.artworkResource

@Composable
fun DetailScreen(item: MediaItem, onBack: () -> Unit, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize().background(DebridColors.Black)) {
        Image(
            painter = painterResource(artworkResource(item.landscapeKey)),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alpha = 0.50f,
        )
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.Black, Color.Black.copy(alpha = 0.78f), Color.Transparent))))
        Column(Modifier.fillMaxWidth(0.58f).align(Alignment.CenterStart).padding(start = 72.dp)) {
            Text(item.logoText, color = Color.White, fontSize = 52.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Text(item.year.toString(), color = Color.White.copy(alpha = 0.72f), fontSize = 16.sp)
                item.rating?.let { Text("★ $it", color = DebridColors.Orange, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                item.runtimeMinutes?.let { Text("${it}m", color = Color.White.copy(alpha = 0.72f), fontSize = 16.sp) }
            }
            Spacer(Modifier.height(14.dp))
            Text(item.description, color = Color.White.copy(alpha = 0.82f), fontSize = 18.sp)
            Spacer(Modifier.height(28.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                ActionChip("Play (Phase 3)") {}
                ActionChip("Source Intelligence") {}
                ActionChip("Back", onBack)
            }
        }
    }
}

@Composable
fun SearchScreen(onBack: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().background(DebridColors.Black).padding(64.dp)) {
        Text("Search", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Black)
        Text("Unified Movies, TV Shows and Live TV search shell", color = Color.White.copy(alpha = 0.50f), fontSize = 14.sp)
        Spacer(Modifier.height(26.dp))
        Box(Modifier.fillMaxWidth(0.72f).background(Color.White.copy(alpha = 0.09f), RoundedCornerShape(18.dp)).padding(20.dp)) {
            Text("Search wiring arrives with the standalone data-services phase.", color = Color.White.copy(alpha = 0.68f), fontSize = 16.sp)
        }
        Spacer(Modifier.height(24.dp))
        ActionChip("Back", onBack)
    }
}

@Composable
fun ChannelPreviewScreen(channel: LiveChannel, onBack: () -> Unit, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize().background(DebridColors.Black)) {
        Image(painterResource(artworkResource(channel.artworkKey)), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alpha = 0.42f)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black))))
        Column(Modifier.align(Alignment.BottomStart).padding(64.dp)) {
            Text(channel.name, color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Black)
            Text("${channel.number} • ${channel.source}", color = DebridColors.Cyan, fontSize = 16.sp)
            Text(channel.programTitle, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("Player adapter is intentionally not part of the UI foundation build.", color = Color.White.copy(alpha = 0.56f), fontSize = 14.sp)
            Spacer(Modifier.height(22.dp))
            ActionChip("Return to exact card", onBack)
        }
    }
}

@Composable
fun SourceResultsScreen(results: List<SourceResult>, limit: Int, onBack: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().background(DebridColors.Black).padding(58.dp)) {
        Text("Source Intelligence", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Black)
        Text("Best ranked links ready (${results.size}/$limit max).", color = DebridColors.Cyan, fontSize = 14.sp)
        Spacer(Modifier.height(22.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth(0.72f)) {
            items(results, key = { it.id }) { source ->
                Box(Modifier.fillMaxWidth().background(Color.White.copy(alpha = 0.07f), RoundedCornerShape(16.dp)).padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(source.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("${source.provider} • ${source.sizeLabel}", color = Color.White.copy(alpha = 0.48f), fontSize = 12.sp)
                        }
                        Text(if (source.cached) "CACHED" else "UNCACHED", color = if (source.cached) DebridColors.Green else DebridColors.Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        ActionChip("Back", onBack)
    }
}

@Composable
private fun ActionChip(text: String, onClick: () -> Unit) {
    FocusSurface(
        onClick = onClick,
        modifier = Modifier.width(220.dp).height(56.dp),
        shape = RoundedCornerShape(18.dp),
        focusedScale = 1.03f,
    ) { focused ->
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(text, color = if (focused) Color.White else Color.White.copy(alpha = 0.82f), fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}
