# Rewrite Build Audit - v0.2.3

Base used: v0.2.2 Status Hub + Pro Editor Fix clean line.

Rule: clean rewrite/consolidation from latest stable line; no broken v7.x carryover.

Rewritten/added in this build:
- Added Pro Layout Editor controls for Status Hub visibility, time, weather placeholder, favorite notifications, theme, size, and position.
- Added independent Hero Logo controls for left/right, up/down, width, and height.
- Status Hub now reads from UiStateStore and can be moved/resized/toggled from the live preview editor.
- Build markers updated to DC_V0_2_3_STATUS_HUB_HERO_LOGO_CONTROLS_ACTIVE.

Preserved:
- Working VOD playback/stream parity line.
- Working player controls from v0.1.8+ line.
- Pro Layout Editor live preview.
- Extra Artwork Slot controls.
- Stable row/card/logo visuals.
- Backend default URL http://192.168.100.55:8181.
