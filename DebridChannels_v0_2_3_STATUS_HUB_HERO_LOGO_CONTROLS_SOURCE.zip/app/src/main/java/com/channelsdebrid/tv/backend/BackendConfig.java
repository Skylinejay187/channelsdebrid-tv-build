package com.channelsdebrid.tv.backend;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Clean-core backend/resolver configuration owner.
 * All user-editable backend/catalog/live-TV/resolver endpoints persist here.
 */
public final class BackendConfig {
    private final SharedPreferences prefs;

    public BackendConfig(Context context) {
        prefs = context.getSharedPreferences("dc_v5_backend", Context.MODE_PRIVATE);
    }

    public String baseUrl() { return prefs.getString("baseUrl", "http://192.168.100.55:8181"); }
    public String m3uUrl() { return prefs.getString("m3uUrl", ""); }
    public String catalogUrl() { return prefs.getString("catalogUrl", ""); }
    public String channelsDvrUrl() { return prefs.getString("channelsDvrUrl", baseUrl()); }
    public String playbackResolverMode() { return prefs.getString("playbackResolverMode", "direct"); }
    public String realDebridApiKey() { return prefs.getString("realDebridApiKey", ""); }
    public String torboxApiKey() { return prefs.getString("torboxApiKey", ""); }

    public void saveBaseUrl(String url) { prefs.edit().putString("baseUrl", clean(url)).apply(); }
    public void saveM3uUrl(String url) { prefs.edit().putString("m3uUrl", clean(url)).apply(); }
    public void saveCatalogUrl(String url) { prefs.edit().putString("catalogUrl", clean(url)).apply(); }
    public void saveChannelsDvrUrl(String url) { prefs.edit().putString("channelsDvrUrl", clean(url)).apply(); }
    public void saveRealDebridApiKey(String key) { prefs.edit().putString("realDebridApiKey", clean(key)).apply(); }
    public void saveTorboxApiKey(String key) { prefs.edit().putString("torboxApiKey", clean(key)).apply(); }

    public void savePlaybackResolverMode(String mode) {
        String m = clean(mode).toLowerCase();
        if (!m.equals("direct") && !m.equals("auto") && !m.equals("realdebrid") && !m.equals("torbox")) m = "direct";
        prefs.edit().putString("playbackResolverMode", m).apply();
    }

    private String clean(String value) { return value == null ? "" : value.trim(); }
}
