package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.2.3 STATUS HUB + HERO LOGO CONTROLS";
    public static final String LOG_MARKER = "DC_V0_2_3_STATUS_HUB_HERO_LOGO_CONTROLS_ACTIVE";
    private BuildMarkers() {}
}
