# Debrid Channels v0.2.3

Marker: DC_V0_2_3_STATUS_HUB_HERO_LOGO_CONTROLS_ACTIVE

Adds configurable Status Hub settings and independent Hero Logo positioning/size controls in Pro Layout Editor live preview.
