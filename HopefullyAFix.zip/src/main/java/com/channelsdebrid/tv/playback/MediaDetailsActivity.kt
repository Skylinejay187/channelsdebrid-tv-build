package com.channelsdebrid.tv.playback

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.channelsdebrid.tv.R

class MediaDetailsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_media_details)

        val backdrop = intent.getStringExtra(EXTRA_BACKDROP_URL).orEmpty()
        val logo = intent.getStringExtra(EXTRA_LOGO_URL).orEmpty()
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val meta = intent.getStringExtra(EXTRA_META_LINE).orEmpty()
        val desc = intent.getStringExtra(EXTRA_DESC).orEmpty()
        val poster = intent.getStringExtra(EXTRA_POSTER_URL).orEmpty()
        val externalId = intent.getStringExtra(EXTRA_EXTERNAL_ID).orEmpty()
        val mediaType = intent.getStringExtra(EXTRA_MEDIA_TYPE).orEmpty().ifBlank { "movie" }

        // Backdrop-only details screen: no extra right-side poster layer.
        Glide.with(this).load(backdrop.ifBlank { poster }).centerCrop().into(findViewById<ImageView>(R.id.detailsBackdrop))

        val logoView = findViewById<ImageView>(R.id.detailsLogo)
        val titleView = findViewById<TextView>(R.id.detailsTitle)
        if (logo.isNotBlank()) {
            Glide.with(this).load(logo).fitCenter().into(logoView)
        } else {
            logoView.visibility = View.GONE
            titleView.text = title
            titleView.visibility = TextView.VISIBLE
        }

        findViewById<TextView>(R.id.detailsMeta).text = meta
        findViewById<TextView>(R.id.detailsDesc).text = desc

        val favoriteButton = findViewById<Button>(R.id.detailsFavorite)
        val favoriteKey = "favorite_${mediaType}_${externalId.ifBlank { title }}"
        val prefs = getSharedPreferences("debrid_channels_favorites", MODE_PRIVATE)
        fun refreshFavoriteButton() {
            favoriteButton.text = if (prefs.getBoolean(favoriteKey, false)) "Favorited" else "Add Favorite"
        }
        refreshFavoriteButton()
        favoriteButton.setOnClickListener {
            val next = !prefs.getBoolean(favoriteKey, false)
            prefs.edit().putBoolean(favoriteKey, next).apply()
            refreshFavoriteButton()
            Toast.makeText(this, if (next) "Added to favorites" else "Removed from favorites", Toast.LENGTH_SHORT).show()
        }

        buildCastRow()
        buildRelatedRow(title, poster.ifBlank { backdrop })

        findViewById<Button>(R.id.detailsPlay).setOnClickListener {
            startActivity(Intent(this, SourceSelectionActivity::class.java).apply {
                putExtra(SourceSelectionActivity.EXTRA_TITLE, title)
                putExtra(SourceSelectionActivity.EXTRA_MEDIA_TYPE, mediaType)
                putExtra(SourceSelectionActivity.EXTRA_EXTERNAL_ID, externalId)
                putExtra(SourceSelectionActivity.EXTRA_ARTWORK_URL, backdrop.ifBlank { poster })
                putExtra(SourceSelectionActivity.EXTRA_LOGO_URL, logo)
                putExtra(SourceSelectionActivity.EXTRA_POSTER_URL, poster)
                putExtra(SourceSelectionActivity.EXTRA_META_LINE, meta)
            })
        }
    }

    private fun buildCastRow() {
        val row = findViewById<LinearLayout>(R.id.detailsCastRow)
        row.removeAllViews()
        listOf("Cast", "Director", "Creator", "Similar Tone").forEach { label ->
            val chip = TextView(this).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 15f
                gravity = Gravity.CENTER
                setPadding(22, 0, 22, 0)
                background = makePillDrawable(0x33FFFFFF, 0x33FFFFFF)
            }
            row.addView(chip, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 58).apply { marginEnd = 12 })
        }
    }

    private fun buildRelatedRow(title: String, artwork: String) {
        val row = findViewById<LinearLayout>(R.id.detailsRelatedRow)
        row.removeAllViews()
        repeat(4) { index ->
            val frame = FrameLayout(this).apply {
                background = makePillDrawable(0x22000000, 0x44FFFFFF)
                isFocusable = true
            }
            val image = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            frame.addView(image, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            if (artwork.isNotBlank()) Glide.with(this).load(artwork).centerCrop().into(image)
            val label = TextView(this).apply {
                text = if (index == 0) title else "Related"
                setTextColor(Color.WHITE)
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.BOTTOM or Gravity.START
                setPadding(12, 0, 12, 12)
            }
            frame.addView(label, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            row.addView(frame, LinearLayout.LayoutParams(150, 92).apply { marginEnd = 14 })
        }
    }

    private fun makePillDrawable(fill: Int, stroke: Int): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = 18f
            setColor(fill)
            setStroke(1, stroke)
        }
    }

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_META_LINE = "meta_line"
        const val EXTRA_DESC = "desc"
        const val EXTRA_MEDIA_TYPE = "media_type"
        const val EXTRA_EXTERNAL_ID = "external_id"
        const val EXTRA_POSTER_URL = "poster_url"
        const val EXTRA_BACKDROP_URL = "backdrop_url"
        const val EXTRA_LOGO_URL = "logo_url"
    }
}
