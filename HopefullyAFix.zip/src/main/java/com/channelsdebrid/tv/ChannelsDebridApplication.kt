package com.channelsdebrid.tv

import android.app.Application
import com.bumptech.glide.Glide
import com.bumptech.glide.GlideBuilder
import com.bumptech.glide.load.engine.cache.InternalCacheDiskCacheFactory

class ChannelsDebridApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        runCatching {
            Glide.init(this, GlideBuilder().setDiskCache(InternalCacheDiskCacheFactory(this, "artwork_disk_cache", 1024L * 1024L * 768L)))
        }
    }
}
