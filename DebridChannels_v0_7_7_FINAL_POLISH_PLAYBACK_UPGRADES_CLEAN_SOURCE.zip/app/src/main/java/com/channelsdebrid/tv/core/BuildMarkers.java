package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.7.7 Final Polish + Playback Upgrades";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.7.7_final_polish_playback_upgrades_visual_pipeline_clean_base";
}
