package com.channelsdebrid.tv.settings

data class TmdbSettings(
    val apiKey: String = "",
    val region: String = "US",
    val language: String = "en-US"
)

data class CatalogSettings(
    val trendingMoviesEnabled: Boolean = true,
    val popularMoviesEnabled: Boolean = true,
    val trendingShowsEnabled: Boolean = true,
    val popularShowsEnabled: Boolean = true,
    val platformRowsEnabled: Boolean = true,
    val stremioCatalogRowsEnabled: Boolean = true
)

data class StremioAddonSettings(
    val id: String,
    val name: String,
    val manifestUrl: String,
    val enabled: Boolean = true
)

data class DebridSettings(
    val realDebridEnabled: Boolean = false,
    val realDebridApiKey: String = "",
    val torBoxEnabled: Boolean = false,
    val torBoxApiKey: String = "",
    val preferredProvider: String = "realdebrid",
    val autoFallback: Boolean = true
)

data class ChannelsDvrSettings(
    val autoDetect: Boolean = true,
    val baseUrl: String = "",
    val username: String = "",
    val password: String = ""
)

data class XtreamSettings(
    val server: String = "",
    val username: String = "",
    val password: String = "",
    val enabled: Boolean = false
)

data class StorageTarget(
    val id: String,
    val type: String,
    val label: String,
    val path: String,
    val allowTimeshift: Boolean,
    val allowVodCache: Boolean,
    val priority: Int
)

data class StorageSettings(
    val preferredTarget: String = "internal",
    val usbPath: String = "",
    val nasPath: String = "",
    val timeshiftMinutes: Int = 90,
    val movieCacheEnabled: Boolean = true
)

data class TrailerSettings(
    val enabled: Boolean = true,
    val autoplayOnFocus: Boolean = false,
    val autoplayDelayMs: Long = 1500,
    val popupMode: String = "center_modal"
)

data class PlaybackSettings(
    val frameRateMatching: Boolean = true,
    val preferExternalStorageForCache: Boolean = true,
    val timeshiftEnabled: Boolean = true,
    val autoPlayBestStream: Boolean = true,
    val fileSizeLimitGb: Int = 40
)
