package com.channelsdebrid.tv.playback

import com.channelsdebrid.tv.settings.ChannelsDvrSettings
import com.channelsdebrid.tv.settings.XtreamSettings
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class PlaybackResolver {

    data class PlaybackTarget(
        val url: String,
        val sourceLabel: String,
        val title: String
    )

    fun resolveLiveTestTarget(
        title: String,
        dvr: ChannelsDvrSettings,
        xtream: XtreamSettings
    ): PlaybackTarget? {
        return resolveChannelsDvr(title, dvr) ?: resolveXtream(title, xtream)
    }

    private fun resolveChannelsDvr(title: String, dvr: ChannelsDvrSettings): PlaybackTarget? {
        val base = dvr.baseUrl.trim().trimEnd('/')
        if (base.isBlank()) return null
        val channelsUrl = "$base/devices/ANY/channels"
        val json = getJson(channelsUrl) ?: return null
        val channels = when {
            json.trim().startsWith("[") -> JSONArray(json)
            else -> JSONObject(json).optJSONArray("channels") ?: JSONArray()
        }
        if (channels.length() == 0) return null
        val first = channels.optJSONObject(0) ?: return null
        val channelId = first.optString("id").ifBlank { first.optString("number") }
        if (channelId.isBlank()) return null
        val streamUrl = first.optString("stream_url").ifBlank {
            "$base/devices/ANY/channels/$channelId/stream.m3u8"
        }
        val label = first.optString("name").ifBlank { first.optString("channel") }.ifBlank { "Channels DVR" }
        return PlaybackTarget(streamUrl, "Channels DVR", "$label • $title")
    }

    private fun resolveXtream(title: String, xtream: XtreamSettings): PlaybackTarget? {
        if (!xtream.enabled) return null
        val server = xtream.server.trim().trimEnd('/')
        val user = xtream.username.trim()
        val pass = xtream.password.trim()
        if (server.isBlank() || user.isBlank() || pass.isBlank()) return null

        val liveJson = getJson("$server/player_api.php?username=$user&password=$pass&action=get_live_streams") ?: return null
        val streams = JSONArray(liveJson)
        if (streams.length() == 0) return null
        val first = streams.optJSONObject(0) ?: return null
        val streamId = first.optString("stream_id")
        if (streamId.isBlank()) return null
        val ext = first.optString("container_extension").ifBlank { "m3u8" }
        val streamUrl = "$server/live/$user/$pass/$streamId.$ext"
        val label = first.optString("name").ifBlank { "Xtream Live" }
        return PlaybackTarget(streamUrl, "Xtream/IPTV", "$label • $title")
    }

    private fun getJson(url: String): String? {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 6000
        connection.readTimeout = 6000
        connection.instanceFollowRedirects = true
        connection.requestMethod = "GET"
        return try {
            connection.connect()
            if (connection.responseCode !in 200..299) return null
            BufferedReader(InputStreamReader(connection.inputStream)).use { it.readText() }
        } catch (_: Exception) {
            null
        } finally {
            connection.disconnect()
        }
    }
}
