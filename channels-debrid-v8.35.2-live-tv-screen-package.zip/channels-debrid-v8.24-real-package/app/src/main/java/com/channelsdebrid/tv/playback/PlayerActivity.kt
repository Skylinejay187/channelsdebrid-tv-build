package com.channelsdebrid.tv.playback

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.channelsdebrid.tv.R

class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var titleView: TextView
    private lateinit var statusView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        playerView = findViewById(R.id.playerView)
        titleView = findViewById(R.id.playerTitle)
        statusView = findViewById(R.id.playerStatus)

        val streamUrl = intent.getStringExtra(EXTRA_STREAM_URL)
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val sourceLabel = intent.getStringExtra(EXTRA_SOURCE_LABEL).orEmpty()

        titleView.text = if (title.isBlank()) "Playback" else title
        statusView.text = if (sourceLabel.isBlank()) "Connecting…" else "Connecting to $sourceLabel…"

        if (streamUrl.isNullOrBlank()) {
            Toast.makeText(this, "No stream URL available", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        initializePlayer(streamUrl, sourceLabel)
    }

    private fun initializePlayer(streamUrl: String, sourceLabel: String) {
        val exoPlayer = ExoPlayer.Builder(this).build().also { player = it }
        playerView.player = exoPlayer
        playerView.keepScreenOn = true
        val mediaItem = MediaItem.fromUri(Uri.parse(streamUrl))
        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.addListener(object : androidx.media3.common.Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                statusView.visibility = if (playbackState == androidx.media3.common.Player.STATE_READY) View.GONE else View.VISIBLE
                if (playbackState == androidx.media3.common.Player.STATE_BUFFERING) {
                    statusView.text = if (sourceLabel.isBlank()) "Buffering…" else "Buffering $sourceLabel…"
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                statusView.visibility = View.VISIBLE
                statusView.text = "Playback error: ${error.errorCodeName}"
            }
        })
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
    }

    override fun onStart() {
        super.onStart()
        player?.playWhenReady = true
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        playerView.player = null
        player?.release()
        player = null
    }

    companion object {
        const val EXTRA_STREAM_URL = "stream_url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_SOURCE_LABEL = "source_label"
    }
}
