
const $ = (id) => document.getElementById(id);
const toBoolStr = (v) => String(!!v);
const num = (v, fallback) => { const x = Number(v); return Number.isFinite(x) ? x : fallback; };
const sourceLabel = (v) => ({channels_dvr:'Channels DVR', realdebrid:'Real-Debrid', torrentio:'Torrentio', stremio:'Stremio', trailers:'Trailers'}[v] || v || 'Source');
function serviceChip(name, state){ const color = state === 'connected' || state === 'configured' ? '#2ECC71' : state === 'disabled' ? '#888' : '#E74C3C'; return `<div class="chip"><div class="dot" style="background:${color}"></div><span>${name}: ${state}</span></div>`; }
async function apiGet(url){ const res = await fetch(url, { cache:'no-store' }); if (!res.ok) throw new Error(`HTTP ${res.status}`); return await res.json(); }
async function apiPost(url, payload){ const res = await fetch(url, { method:'POST', headers:{'Content-Type':'application/json'}, cache:'no-store', body:JSON.stringify(payload) }); const data = await res.json().catch(() => ({})); if (!res.ok || !data.ok) throw new Error(data.error || `HTTP ${res.status}`); return data; }
function setGlobal(msg){ $('globalStatus').textContent = msg; }

function fillSettings(s){
  $('performance_prewarmEverythingOnBoot').value = toBoolStr(s.performance.prewarmEverythingOnBoot);
  $('performance_prioritizeMostUsedChannels').value = toBoolStr(s.performance.prioritizeMostUsedChannels);
  $('performance_instantEverywhereMode').value = toBoolStr(s.performance.instantEverywhereMode);
  $('cache_preloadChannelsGuideOnBoot').value = toBoolStr(s.cache.preloadChannelsGuideOnBoot);
  $('cache_preloadTopChannelsOnBoot').value = toBoolStr(s.cache.preloadTopChannelsOnBoot);
  $('cache_preloadRecentMoviesOnBoot').value = toBoolStr(s.cache.preloadRecentMoviesOnBoot);
  $('cache_smartBackgroundCaching').value = toBoolStr(s.cache.smartBackgroundCaching);
  $('cache_maxWarmChannels').value = s.cache.maxWarmChannels ?? 12;
  $('cache_maxWarmMovies').value = s.cache.maxWarmMovies ?? 20;
  $('resume_enabled').value = toBoolStr(s.resume.enabled);
  $('resume_saveEverySeconds').value = s.resume.saveEverySeconds ?? 15;
  $('resume_markWatchedPercent').value = s.resume.markWatchedPercent ?? 92;
  $('resume_keepRecentItems').value = s.resume.keepRecentItems ?? 200;

  $('smartHome_enabled').value = toBoolStr(s.smartHome.enabled);
  $('smartHome_recommendationsEnabled').value = toBoolStr(s.smartHome.recommendationsEnabled);
  $('smartHome_continueWatchingFirst').value = toBoolStr(s.smartHome.continueWatchingFirst);
  $('smartHome_blendLiveAndVOD').value = toBoolStr(s.smartHome.blendLiveAndVOD);
  $('smartHome_preferCachedSources').value = toBoolStr(s.smartHome.preferCachedSources);
  $('smartHome_maxRecommendedItems').value = s.smartHome.maxRecommendedItems ?? 12;

  $('channels_enabled').value = toBoolStr(s.channelsDvr.enabled);
  $('channels_serverUrl').value = s.channelsDvr.serverUrl || '';
  $('channels_showOnHome').value = toBoolStr(s.channelsDvr.showOnHome);
  $('channels_fullGuideEnabled').value = toBoolStr(s.channelsDvr.fullGuideEnabled);
  $('channels_miniPreviewEnabled').value = toBoolStr(s.channelsDvr.miniPreviewEnabled);
  $('channels_playbackMode').value = s.channelsDvr.playbackMode || 'direct';
  $('channels_preferredStreamFormat').value = s.channelsDvr.preferredStreamFormat || 'mpeg_ts_copy';
  $('channels_fallbackDeviceOverride').value = s.channelsDvr.fallbackDeviceOverride || '';
  $('channels_gracenoteEnabled').value = toBoolStr(s.channelsDvr.gracenoteEnabled);

  $('stremio_enabled').value = toBoolStr(s.stremio.enabled);
  $('stremio_catalogEnabled').value = toBoolStr(s.stremio.catalogEnabled);
  $('stremio_addonsText').value = s.stremio.addonsText || '';
  $('torrentio_enabled').value = toBoolStr(s.torrentio.enabled);
  $('torrentio_baseUrl').value = s.torrentio.baseUrl || '';
  $('torrentio_useBuiltInConfigurator').value = toBoolStr(s.torrentio.useBuiltInConfigurator);
  $('torrentio_sortMode').value = s.torrentio.sortMode || '';
  $('torrentio_maxResults').value = s.torrentio.maxResults ?? 20;
  $('debrid_provider').value = s.debrid.provider || 'realdebrid';
  $('rd_enabled').value = toBoolStr(s.debrid.realDebrid.enabled);
  $('rd_apiKey').value = s.debrid.realDebrid.apiKey || '';
  $('torbox_enabled').value = toBoolStr(s.debrid.torbox.enabled);
  $('torbox_apiKey').value = s.debrid.torbox.apiKey || '';

  $('home_timeFormat').value = s.home.timeFormat || '12h';
  $('home_moviePosterScale').value = s.home.moviePosterScale ?? 1.08;
  $('home_posterGapPx').value = s.home.posterGapPx ?? 18;
  $('home_showChannelsDvrOnHome').value = toBoolStr(s.home.showChannelsDvrOnHome);
  $('home_showIptvOnHome').value = toBoolStr(s.home.showIptvOnHome);
  $('profiles_enabled').value = toBoolStr(s.profiles.enabled);
  $('profiles_askWhosWatchingOnStartup').value = toBoolStr(s.profiles.askWhosWatchingOnStartup);
  $('profiles_alwaysUseSameProfile').value = toBoolStr(s.profiles.alwaysUseSameProfile);
  $('profiles_defaultProfile').value = s.profiles.defaultProfile || '';
  $('profiles_lastProfile').value = s.profiles.lastProfile || '';
  $('search_enabled').value = toBoolStr(s.search.enabled);
  $('search_includeLiveTv').value = toBoolStr(s.search.includeLiveTv);
  $('search_includeMoviesShows').value = toBoolStr(s.search.includeMoviesShows);

  $('trailers_enabled').value = toBoolStr(s.trailers?.enabled);
  $('trailers_popupEnabled').value = toBoolStr(s.trailers?.popupEnabled);
  $('trailers_mutePreview').value = toBoolStr(s.trailers?.mutePreview);
  $('trailers_delayMs').value = s.trailers?.delayMs ?? 4000;
  $('trailers_mode').value = s.trailers?.mode || 'automatic';
  $('trailers_source').value = s.trailers?.source || 'youtube';
  $('tmdb_enabled').value = toBoolStr(s.tmdb?.enabled);
  $('tmdb_language').value = s.tmdb?.language || 'en-US';
  $('tmdb_apiKey').value = s.tmdb?.apiKey || '';

  $('gpu_gpuAcceleration').value = s.gpu.gpuAcceleration || 'intel_qsv';
  $('gpu_transcodingMode').value = s.gpu.transcodingMode || 'auto';
  $('gpu_preferDirectPlay').value = toBoolStr(s.gpu.preferDirectPlay);
  $('gpu_qsvDevicePath').value = s.gpu.qsvDevicePath || '';
  $('gpu_browserConversion').value = toBoolStr(s.gpu.useGpuFor.browserConversion);
  $('gpu_liveTvConversion').value = toBoolStr(s.gpu.useGpuFor.liveTvConversion);
  $('gpu_movieShowConversion').value = toBoolStr(s.gpu.useGpuFor.movieShowConversion);
  $('gpu_dvrProcessing').value = toBoolStr(s.gpu.useGpuFor.dvrProcessing);
  $('gpu_hlsSegmentLength').value = s.gpu.hlsSegmentLength ?? 4;
  $('gpu_hlsPlaylistSize').value = s.gpu.hlsPlaylistSize ?? 6;
}
async function refreshSettings(){ try{ fillSettings((await apiGet('/api/settings')).settings); setGlobal('Settings loaded.'); } catch(e){ setGlobal('Settings load failed: ' + e.message); } }
async function refreshDashboard(){
  const fill = (id, text) => { const el = $(id); if (el) el.textContent = text; };
  try{
    const [health, profile, cache, perf, services, resume, smart, tmdb] = await Promise.allSettled([
      apiGet('/health'), apiGet('/api/profile/state'), apiGet('/api/cache/status'), apiGet('/api/performance/status'),
      apiGet('/api/services/status'), apiGet('/api/resume/state'), apiGet('/api/smart-home/status'), apiGet('/api/tmdb/status')
    ]);
    const get = (r, fallback) => r.status === 'fulfilled' ? r.value : fallback;
    const h = get(health, {build:'Unavailable', port:'—', channelsDvrUrl:'Unavailable', playbackMode:'—', profilesEnabled:false, cacheEnabled:false, prewarmEverythingOnBoot:false});
    const p = get(profile, {profilesEnabled:false, autoLoginProfile:''});
    const c = get(cache, {settings:{playbackCacheEnabled:false}});
    const pf = get(perf, {settings:{prewarmEverythingOnBoot:false, prioritizeMostUsedChannels:false, instantEverywhereMode:false}, cache:{maxWarmChannels:'—', maxWarmMovies:'—'}, usage:{channels:{}}, warmState:{actions:[]}, resume:{items:[]}});
    const sv = get(services, {services:{}});
    const rs = get(resume, {items:[]});
    const sh = get(smart, {settings:{enabled:false}});
    const td = get(tmdb, {settings:{enabled:false, apiKeyConfigured:false}});

    fill('metricBuild', String(h.build || 'Ready').replace('FULL-REBUILD-',''));
    fill('metricPort', `Port ${h.port || '—'}`);
    fill('metricPlayback', String(h.playbackMode || '—').replaceAll('_',' '));
    fill('metricServer', h.channelsDvrUrl || 'No server set');
    fill('metricWarm', (pf.warmState?.actions || []).length ? 'Ready' : 'Idle');
    fill('metricWarmSub', (pf.warmState?.actions || []).length ? `${pf.warmState.actions.length} warm actions recorded` : 'No warm actions yet');
    fill('metricResume', String((rs.items || []).length));
    fill('metricResumeSub', (rs.items || []).length ? 'Continue watching available' : 'No resume items yet');
    fill('overviewHeadline', `${Object.values(sv.services || {}).filter(v => v === 'configured' || v === 'connected').length} services ready`);
    fill('overviewCopy', `Startup warming is ${pf.settings?.prewarmEverythingOnBoot ? 'on' : 'off'}, smart home is ${sh.settings?.enabled ? 'on' : 'off'}, and TMDB is ${td.settings?.enabled ? (td.settings?.apiKeyConfigured ? 'ready' : 'waiting for key') : 'off'}.`);
    fill('healthSummary', `Channels DVR ${h.channelsDvrUrl || 'not set'} with ${h.playbackMode || 'direct'} playback. Profiles are ${h.profilesEnabled ? 'enabled' : 'disabled'} and cache is ${h.cacheEnabled ? 'enabled' : 'disabled'}.`);
    if ($('healthPills')) $('healthPills').innerHTML = [`<div class="chip">Build ${h.build || 'unknown'}</div>`,`<div class="chip">Port ${h.port || '—'}</div>`,`<div class="chip">Prewarm ${h.prewarmEverythingOnBoot ? 'On' : 'Off'}</div>`,`<div class="chip">TMDB ${td.settings?.enabled ? (td.settings?.apiKeyConfigured ? 'Ready' : 'No Key') : 'Off'}</div>`].join('');
    fill('perfSummary', `Warm boot is ${pf.settings?.prewarmEverythingOnBoot ? 'enabled' : 'disabled'}, most-used channel priority is ${pf.settings?.prioritizeMostUsedChannels ? 'enabled' : 'disabled'}, and instant mode is ${pf.settings?.instantEverywhereMode ? 'enabled' : 'disabled'}.`);
    if ($('perfPills')) $('perfPills').innerHTML = [`<div class="chip">Warm channels ${pf.cache?.maxWarmChannels ?? '—'}</div>`,`<div class="chip">Warm movies ${pf.cache?.maxWarmMovies ?? '—'}</div>`,`<div class="chip">Tracked channels ${Object.keys(pf.usage?.channels || {}).length}</div>`].join('');
    const stateDot = (state) => { const color = state === 'connected' || state === 'configured' ? '#2ECC71' : state === 'disabled' ? '#888' : '#E74C3C'; return `<span class="live-dot" style="background:${color}"></span>`; };
    const statusMap = sv.services || {};
    if ($('serviceChips')) $('serviceChips').innerHTML = [
      ['Channels DVR', statusMap.channelsDvr], ['Stremio', statusMap.stremio], ['Torrentio', statusMap.torrentio], ['Real-Debrid', statusMap.realDebrid],
      ['Trailers', statusMap.trailers], ['MediaFlow', statusMap.mediaFlowProxy], ['Profiles', p.autoLoginProfile ? 'configured' : (p.profilesEnabled ? 'configured' : 'disabled')],
      ['Cache', statusMap.cache], ['GPU', statusMap.gpu], ['TMDB', td.settings?.enabled ? (td.settings?.apiKeyConfigured ? 'configured' : 'disconnected') : 'disabled']
    ].map(([name, state]) => serviceChip(name, state || 'disabled')).join('');
    if ($('connChannels')) $('connChannels').innerHTML = `${stateDot(statusMap.channelsDvr)}<span>${statusMap.channelsDvr || 'disabled'}</span>`;
    if ($('connCache')) $('connCache').innerHTML = `${stateDot(c.settings?.playbackCacheEnabled ? 'configured' : 'disabled')}<span>${c.settings?.playbackCacheEnabled ? 'active' : 'off'}</span>`;
    if ($('connResume')) $('connResume').innerHTML = `${stateDot(statusMap.resume)}<span>${(rs.items || []).length} saved</span>`;
    if ($('connGpu')) $('connGpu').innerHTML = `${stateDot(statusMap.gpu)}<span>${statusMap.gpu || 'disabled'}</span>`;
    if ($('health')) $('health').textContent = JSON.stringify(h, null, 2);
    if ($('perfStatus')) $('perfStatus').textContent = JSON.stringify(pf, null, 2);
  }catch(e){ setGlobal('Dashboard refresh failed: ' + e.message); }
}
function renderHomeRows(data){
  const rows = data.rows || {}, root = $('realHomeRoot');
  const featured = Array.isArray(rows.featured) ? rows.featured[0] : null;
  let out = '';
  if (featured) {
    out += `<div class="real-hero" style="background-image:linear-gradient(125deg,rgba(12,18,32,.92) 0%,rgba(18,36,58,.82) 55%,rgba(32,59,88,.78) 100%), url('${featured.backdrop || ''}')">
      <div class="preview-kicker">Featured tonight</div>
      <h2 class="real-hero-title">${featured.title || ''}</h2>
      <div class="real-hero-meta">${featured.subtitle || ''} ${featured.rating ? '• ' + featured.rating : ''}</div>
      <div class="real-hero-desc">${featured.description || ''}</div>
      <div class="hero-actions">
        <div class="hero-btn">▶ Play now</div>
        <div class="hero-btn secondary">＋ Add to watchlist</div>
      </div>
      <div class="hero-statbar">
        <div class="hero-stat"><div class="hero-stat-label">Recommended</div><div class="hero-stat-value">${(rows.recommendedForYou||[]).length}</div></div>
        <div class="hero-stat"><div class="hero-stat-label">Continue</div><div class="hero-stat-value">${(rows.continueWatching||[]).length}</div></div>
        <div class="hero-stat"><div class="hero-stat-label">Live Now</div><div class="hero-stat-value">${(rows.liveNow||[]).length}</div></div>
      </div>
      <div class="source-chips">${(featured.sourceBadges || []).map(x => `<div class="source-chip"><span class="live-dot" style="background:#2ECC71"></span>${x}</div>`).join('')}</div>
      <div class="spotlight-strip">
        <div class="spotlight-card"><div class="spotlight-kicker">Smart Home</div><div class="spotlight-title">${(rows.recommendedForYou||[]).length} personalized picks ready</div></div>
        <div class="spotlight-card"><div class="spotlight-kicker">Continue Watching</div><div class="spotlight-title">${(rows.continueWatching||[]).length} saved items</div></div>
        <div class="spotlight-card"><div class="spotlight-kicker">Live TV</div><div class="spotlight-title">${(rows.liveNow||[]).length} channels live now</div></div>
      </div>
    </div>`;
  }
  const order = [['recommendedForYou','Recommended For You'],['becauseYouWatched','Because You Watched'],['trendingNow','Trending Now'],['recentlyAdded','Recently Added'],['continueWatching','Continue Watching'],['liveNow','Live Now'],['trendingMovies','Trending Movies'],['popularMovies','Popular Movies'],['trendingShows','Trending Shows'],['popularOnStreaming','Popular on Streaming']];
  for (const [key, label] of order) {
    const items = Array.isArray(rows[key]) ? rows[key] : [];
    if (!items.length) continue;
    out += `<div style="margin-top:26px"><div class="row-header"><div class="row-title">${label}</div><div class="row-sub">${items.length} items</div></div><div class="real-row-grid">` +
      items.slice(0,4).map(item => `<div class="real-card">
        <div class="corner-badge">${sourceLabel(item.source)}</div>
        <div class="real-card-art" style="background-image:url('${item.backdrop || item.poster || ''}')"></div>
        <div class="real-card-body">
          <div class="real-card-name">${item.title || 'Untitled'}</div>
          <div class="real-card-sub">${item.subtitle || item.year || item.type || ''}</div>
          <div class="real-card-tags">${((item.tags || []).slice(0,2)).map(tag => `<span class="media-tag">${tag}</span>`).join('')}</div>
        </div>
      </div>`).join('') + `</div></div>`;
  }
  root.innerHTML = out || '<div class="status">No rows available.</div>';
}
async function refreshHome(){ try{ renderHomeRows(await apiGet('/api/catalog/home')); } catch(e){ $('realHomeRoot').innerHTML = `<div class="status">Failed to load real home rows: ${e.message}</div>`; } }



function bindSettingsButtons(){
  if ($('savePerformanceBtn')) $('savePerformanceBtn').onclick = () => save({ performance:{ prewarmEverythingOnBoot:$('performance_prewarmEverythingOnBoot').value==='true', prioritizeMostUsedChannels:$('performance_prioritizeMostUsedChannels').value==='true', instantEverywhereMode:$('performance_instantEverywhereMode').value==='true' }, cache:{ preloadChannelsGuideOnBoot:$('cache_preloadChannelsGuideOnBoot').value==='true', preloadTopChannelsOnBoot:$('cache_preloadTopChannelsOnBoot').value==='true', preloadRecentMoviesOnBoot:$('cache_preloadRecentMoviesOnBoot').value==='true', smartBackgroundCaching:$('cache_smartBackgroundCaching').value==='true', maxWarmChannels:num($('cache_maxWarmChannels').value,12), maxWarmMovies:num($('cache_maxWarmMovies').value,20) }, resume:{ enabled:$('resume_enabled').value==='true', saveEverySeconds:num($('resume_saveEverySeconds').value,15), markWatchedPercent:num($('resume_markWatchedPercent').value,92), keepRecentItems:num($('resume_keepRecentItems').value,200) } }, 'Performance / Resume saved.');
  if ($('runWarmBtn')) $('runWarmBtn').onclick = async () => { try{ setGlobal('Running warm-up now…'); await apiPost('/api/performance/warm', {}); setGlobal('Warm-up complete.'); await refreshDashboard(); } catch(e){ setGlobal('Warm-up failed: ' + e.message); } };
  if ($('saveSmartHomeBtn')) $('saveSmartHomeBtn').onclick = () => save({ smartHome:{ enabled:$('smartHome_enabled').value==='true', recommendationsEnabled:$('smartHome_recommendationsEnabled').value==='true', continueWatchingFirst:$('smartHome_continueWatchingFirst').value==='true', blendLiveAndVOD:$('smartHome_blendLiveAndVOD').value==='true', preferCachedSources:$('smartHome_preferCachedSources').value==='true', maxRecommendedItems:num($('smartHome_maxRecommendedItems').value,12) } }, 'Smart Home saved.');
  if ($('saveChannelsBtn')) $('saveChannelsBtn').onclick = () => save({ channelsDvr:{ enabled:$('channels_enabled').value==='true', serverUrl:$('channels_serverUrl').value, showOnHome:$('channels_showOnHome').value==='true', fullGuideEnabled:$('channels_fullGuideEnabled').value==='true', miniPreviewEnabled:$('channels_miniPreviewEnabled').value==='true', playbackMode:$('channels_playbackMode').value, preferredStreamFormat:$('channels_preferredStreamFormat').value, fallbackDeviceOverride:$('channels_fallbackDeviceOverride').value, gracenoteEnabled:$('channels_gracenoteEnabled').value==='true' } }, 'Channels DVR saved.');
  if ($('saveProvidersBtn')) $('saveProvidersBtn').onclick = () => save({ stremio:{ enabled:$('stremio_enabled').value==='true', catalogEnabled:$('stremio_catalogEnabled').value==='true', addonsText:$('stremio_addonsText').value }, torrentio:{ enabled:$('torrentio_enabled').value==='true', baseUrl:$('torrentio_baseUrl').value, useBuiltInConfigurator:$('torrentio_useBuiltInConfigurator').value==='true', sortMode:$('torrentio_sortMode').value, maxResults:num($('torrentio_maxResults').value,20) }, debrid:{ provider:$('debrid_provider').value, realDebrid:{ enabled:$('rd_enabled').value==='true', apiKey:$('rd_apiKey').value }, torbox:{ enabled:$('torbox_enabled').value==='true', apiKey:$('torbox_apiKey').value } } }, 'Providers / Debrid saved.');
  if ($('saveUiBtn')) $('saveUiBtn').onclick = () => save({ home:{ timeFormat:$('home_timeFormat').value, moviePosterScale:num($('home_moviePosterScale').value,1.08), posterGapPx:num($('home_posterGapPx').value,18), showChannelsDvrOnHome:$('home_showChannelsDvrOnHome').value==='true', showIptvOnHome:$('home_showIptvOnHome').value==='true' }, profiles:{ enabled:$('profiles_enabled').value==='true', askWhosWatchingOnStartup:$('profiles_askWhosWatchingOnStartup').value==='true', alwaysUseSameProfile:$('profiles_alwaysUseSameProfile').value==='true', defaultProfile:$('profiles_defaultProfile').value, lastProfile:$('profiles_lastProfile').value }, search:{ enabled:$('search_enabled').value==='true', includeLiveTv:$('search_includeLiveTv').value==='true', includeMoviesShows:$('search_includeMoviesShows').value==='true' } }, 'Home / Profiles / Search saved.');
  if ($('saveTrailersBtn')) $('saveTrailersBtn').onclick = () => save({ trailers:{ enabled:$('trailers_enabled').value==='true', popupEnabled:$('trailers_popupEnabled').value==='true', mutePreview:$('trailers_mutePreview').value==='true', delayMs:num($('trailers_delayMs').value,4000), mode:$('trailers_mode').value, source:$('trailers_source').value } }, 'Trailers saved.');
  if ($('saveTmdbBtn')) $('saveTmdbBtn').onclick = () => save({ tmdb:{ enabled:$('tmdb_enabled').value==='true', language:$('tmdb_language').value || 'en-US', apiKey:$('tmdb_apiKey').value } }, 'TMDB saved.');
  if ($('saveGpuBtn')) $('saveGpuBtn').onclick = () => save({ gpu:{ gpuAcceleration:$('gpu_gpuAcceleration').value, transcodingMode:$('gpu_transcodingMode').value, preferDirectPlay:$('gpu_preferDirectPlay').value==='true', qsvDevicePath:$('gpu_qsvDevicePath').value, useGpuFor:{ browserConversion:$('gpu_browserConversion').value==='true', liveTvConversion:$('gpu_liveTvConversion').value==='true', movieShowConversion:$('gpu_movieShowConversion').value==='true', dvrProcessing:$('gpu_dvrProcessing').value==='true' }, hlsSegmentLength:num($('gpu_hlsSegmentLength').value,4), hlsPlaylistSize:num($('gpu_hlsPlaylistSize').value,6) } }, 'GPU saved.');
}
function setupSettingsDrawer(){
  const tpl = document.getElementById('settingsTemplate');
  const mount = document.getElementById('drawerSections');
  if (tpl && mount && !mount.dataset.loaded){
    mount.innerHTML = tpl.innerHTML;
    mount.dataset.loaded = 'true';
    bindSettingsButtons();
  }
  const open = () => {
    $('settingsDrawer').classList.add('open');
    $('drawerBackdrop').classList.add('show');
    setTimeout(() => {
      const first = $('settingsDrawer').querySelector('.focusable, button, input, select, textarea, summary');
      if (first) first.focus();
    }, 50);
  };
  const close = () => {
    $('settingsDrawer').classList.remove('open');
    $('drawerBackdrop').classList.remove('show');
    if ($('settingsLaunch')) $('settingsLaunch').focus();
  };
  $('settingsLaunch')?.addEventListener('click', open);
  $('drawerClose')?.addEventListener('click', close);
  $('drawerBackdrop')?.addEventListener('click', close);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && $('settingsDrawer')?.classList.contains('open')) close();
  });
}


function skeletonCards(type='small', count=4){
  const w = type === 'poster' ? 348 : 232;
  const h = type === 'poster' ? 140 : 122;
  return Array.from({length: count}).map(() => `
    <div style="width:${w}px;min-width:${w}px;border-radius:20px;overflow:hidden;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.06)">
      <div style="height:${h}px;background:linear-gradient(90deg,rgba(255,255,255,.04),rgba(255,255,255,.08),rgba(255,255,255,.04));background-size:200% 100%;animation:shimmer 1.2s linear infinite"></div>
      <div style="padding:12px">
        <div style="height:16px;width:70%;border-radius:999px;background:rgba(255,255,255,.06);margin-bottom:10px"></div>
        <div style="height:12px;width:45%;border-radius:999px;background:rgba(255,255,255,.05)"></div>
      </div>
    </div>`).join('');
}
async function fetchDashboardRowsWithRetry(){
  const endpoints = ['/api/dashboard', '/api/catalog/home'];
  for (const endpoint of endpoints){
    for (let attempt = 0; attempt < 3; attempt++){
      try{
        const data = await apiGet(endpoint);
        if (data && data.rows) return data;
      }catch(e){}
      await new Promise(r => setTimeout(r, 250 * (attempt + 1)));
    }
  }
  return { rows: fallbackRows() };
}
function primeLoadingState(){
  const continueRow = $('continueRow');
  const spotlightRow = $('spotlightRow');
  const liveRow = $('liveRow');
  if (continueRow) continueRow.innerHTML = skeletonCards('poster', 3);
  if (spotlightRow) spotlightRow.innerHTML = skeletonCards('small', 4);
  if (liveRow) liveRow.innerHTML = skeletonCards('small', 5);
}





async function fetchTmdbTrailer(title){
  try{
    const settingsRes = await fetch('/api/settings', {cache:'no-store'});
    const settingsJson = await settingsRes.json();
    const apiKey = settingsJson?.settings?.tmdb?.apiKey || '';
    const language = settingsJson?.settings?.tmdb?.language || 'en-US';
    if (!apiKey) return null;

    const searchRes = await fetch(`https://api.themoviedb.org/3/search/multi?api_key=${apiKey}&language=${encodeURIComponent(language)}&query=${encodeURIComponent(title)}`);
    const searchJson = await searchRes.json();
    const first = (searchJson?.results || []).find(x => x && (x.media_type === 'movie' || x.media_type === 'tv'));
    if (!first?.id || !first?.media_type) return null;

    const typePath = first.media_type === 'tv' ? 'tv' : 'movie';
    const videoRes = await fetch(`https://api.themoviedb.org/3/${typePath}/${first.id}/videos?api_key=${apiKey}&language=${encodeURIComponent(language)}`);
    const videoJson = await videoRes.json();
    const videos = Array.isArray(videoJson?.results) ? videoJson.results : [];
    const trailer = videos.find(v => v.site === 'YouTube' && v.type === 'Trailer') ||
                    videos.find(v => v.site === 'YouTube' && (v.type === 'Teaser' || v.type === 'Clip'));
    if (!trailer?.key) return null;
    return `https://www.youtube.com/embed/${trailer.key}?autoplay=1&mute=1&controls=1&rel=0&modestbranding=1`;
  }catch(e){
    console.error('TMDB trailer fetch failed', e);
    return null;
  }
}

async function fetchYouTubeTrailer(title){
  try{
    const query = encodeURIComponent((title || '') + ' official trailer');
    const res = await fetch(`https://ytsearch.lemnoslife.com/search?q=${query}`);
    const data = await res.json();
    const items = Array.isArray(data?.items) ? data.items : [];
    const first = items.find(x => x?.id?.videoId) || items[0];
    const videoId = first?.id?.videoId;
    if (!videoId) return null;
    return `https://www.youtube.com/embed/${videoId}?autoplay=1&mute=1&controls=1&rel=0&modestbranding=1`;
  }catch(e){
    console.error('Trailer fetch failed', e);
    return null;
  }
}

let __trailerTimer = null;
let __trailerActiveKey = '';
let __lastSettings = null;

function closeTrailerPopup(){
  const overlay = document.getElementById('trailerOverlay');
  const player = document.getElementById('trailerPlayer');
  const fallback = document.getElementById('trailerFallback');
  const play = document.getElementById('trailerPlay');
  if (player) player.src = '';
  if (fallback) fallback.style.display = '';
  if (play) play.style.display = '';
  if (overlay) overlay.classList.remove('show');
}
async function openTrailerPopupFromElement(el){
  if (!el) return;
  const title = el.dataset.title || 'Selected title';
  const meta = el.dataset.meta || 'Preview ready';
  const desc = el.dataset.desc || 'Trailer popup preview while browsing.';
  const backdrop = (() => {
    const art = el.querySelector('.poster-art, .small-art');
    const bg = art?.style?.backgroundImage || '';
    return bg.replace(/^url\(["']?/, '').replace(/["']?\)$/, '');
  })();

  const fallback = document.getElementById('trailerFallback');
  const titleEl = document.getElementById('trailerTitle');
  const metaEl = document.getElementById('trailerMeta');
  const descEl = document.getElementById('trailerDesc');
  const countdown = document.getElementById('trailerCountdown');
  const overlay = document.getElementById('trailerOverlay');
  const player = document.getElementById('trailerPlayer');
  const play = document.getElementById('trailerPlay');

  if (fallback){
    fallback.style.backgroundImage = backdrop ? `url('${backdrop}')` : '';
    fallback.style.display = '';
  }
  if (play) play.style.display = '';
  if (titleEl) titleEl.textContent = title;
  if (metaEl) metaEl.textContent = meta;
  if (descEl) descEl.textContent = desc;
  const activeTrailerSource = __lastSettings?.trailers?.source || 'youtube';
  if (countdown) countdown.textContent = activeTrailerSource === 'tmdb' ? 'Loading TMDB-backed trailer…' : 'Loading YouTube trailer…';
  if (overlay) overlay.classList.add('show');

    const trailerUrl = activeTrailerSource === 'tmdb' ? await fetchTmdbTrailer(title) : await fetchYouTubeTrailer(title);
  if (player && trailerUrl){
    player.src = trailerUrl;
    player.onload = () => {
      if (fallback) fallback.style.display = 'none';
      if (play) play.style.display = 'none';
    };
    if (countdown) countdown.textContent = 'Autoplay preview started';
  } else {
    if (countdown) countdown.textContent = 'Trailer unavailable — showing preview artwork';
  }
}
function scheduleTrailerPopup(el){
  clearTimeout(__trailerTimer);
  closeTrailerPopup();
  if (!el || !__lastSettings?.trailers?.enabled || !__lastSettings?.trailers?.popupEnabled) return;
  const group = el.dataset.focusGroup || '';
  if (!['continue','spotlight'].includes(group)) return;
  const key = `${group}:${el.dataset.title || ''}`;
  __trailerActiveKey = key;
  const delay = Number(__lastSettings?.trailers?.delayMs || 4000);
  const countdown = document.getElementById('trailerCountdown');
  if (countdown) countdown.textContent = `Opens in ${Math.round(delay/1000)} seconds`;
  __trailerTimer = setTimeout(() => {
    if (__trailerActiveKey === key) openTrailerPopupFromElement(el);
  }, delay);
}

let __prefetchTimer = null;
let __prefetchSet = new Set();

function renderPrefetchRibbon(status){
  const el = document.getElementById('prefetchRibbon');
  if (!el) return;
  const cacheEntries = status?.playbackCacheEntries ?? '—';
  el.innerHTML = [
    `<div class="prefetch-chip live"><span class="prefetch-dot live"></span>focus prefetch</div>`,
    `<div class="prefetch-chip cache"><span class="prefetch-dot"></span>cache ${cacheEntries}</div>`,
    `<div class="prefetch-chip warm"><span class="prefetch-dot warm"></span>instant playback</div>`
  ].join('');
}

function markPrefetch(el){
  if (!el || !el.dataset?.title) return;
  const key = `${el.dataset.focusGroup || 'card'}:${el.dataset.title}`;
  if (__prefetchSet.has(key)) return;
  el.classList.add('prefetching');
  __prefetchTimer && clearTimeout(__prefetchTimer);
  __prefetchTimer = setTimeout(() => {
    __prefetchSet.add(key);
    el.classList.remove('prefetching');
  }, 650);
}

async function loadInstantPlaybackStatus(){
  try{
    const status = await apiGet('/api/instant-playback/status');
    renderPrefetchRibbon(status);
  }catch(e){
    renderPrefetchRibbon({playbackCacheEntries:'—'});
  }
}

function showToast(msg){
  const t = $('tvToast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(window.__tvToastTimer);
  window.__tvToastTimer = setTimeout(() => t.classList.remove('show'), 1800);
}
function showInfoFromElement(el){
  if (!el) return;
  $('popupTitle').textContent = el.dataset.title || 'Selected Title';
  $('popupMeta').textContent = el.dataset.meta || '';
  $('popupDesc').textContent = el.dataset.desc || 'Browse details here.';
  $('infoPopup').classList.add('show');
}
function collectFocusable(){
  return [...document.querySelectorAll('.focusable')].filter(el => el.offsetParent !== null);
}
function setTvFocus(el){
  collectFocusable().forEach(x => x.classList.remove('tv-focused'));
  if (!el) return;
  el.classList.add('tv-focused');
  el.focus({preventScroll:true});
  showInfoFromElement(el);
  if (el.dataset && el.dataset.prefetch === 'true') markPrefetch(el);
  scheduleTrailerPopup(el);
  try{ el.scrollIntoView({block:'nearest', inline:'nearest', behavior:'smooth'}); }catch{}
  window.__currentFocusEl = el;
}
function focusByGroup(group, index=0){
  const items = collectFocusable().filter(el => el.dataset.focusGroup === group);
  if (items.length) setTvFocus(items[Math.max(0, Math.min(index, items.length-1))]);
}
function groupOrder(){ return ['top','hero','continue','spotlight','live','side']; }
function currentGroupIndex(){
  const g = window.__currentFocusEl?.dataset?.focusGroup;
  return Math.max(0, groupOrder().indexOf(g));
}
function initTvFocus(){
  const items = collectFocusable();
  items.forEach(el => {
    el.addEventListener('mouseenter', () => setTvFocus(el));
    el.addEventListener('focus', () => setTvFocus(el));
    el.addEventListener('click', () => showToast(`${el.dataset.title || el.textContent.trim()} selected`));
  });
  if (items.length) setTvFocus(items[0]);
}
document.addEventListener('keydown', (e) => {
  const current = window.__currentFocusEl;
  const items = collectFocusable();
  if (!current || !items.length) return;
  if (['ArrowRight','ArrowLeft','ArrowUp','ArrowDown'].includes(e.key)) closeTrailerPopup();
  const group = current.dataset.focusGroup || 'top';
  const groupItems = items.filter(el => el.dataset.focusGroup === group);
  const idx = groupItems.indexOf(current);
  if (e.key === 'ArrowRight'){
    e.preventDefault();
    if (idx < groupItems.length - 1) setTvFocus(groupItems[idx + 1]);
  } else if (e.key === 'ArrowLeft'){
    e.preventDefault();
    if (idx > 0) setTvFocus(groupItems[idx - 1]);
  } else if (e.key === 'ArrowDown'){
    e.preventDefault();
    const gi = currentGroupIndex();
    const nextGroup = groupOrder()[Math.min(groupOrder().length - 1, gi + 1)];
    focusByGroup(nextGroup, idx);
  } else if (e.key === 'ArrowUp'){
    e.preventDefault();
    const gi = currentGroupIndex();
    const prevGroup = groupOrder()[Math.max(0, gi - 1)];
    focusByGroup(prevGroup, idx);
  } else if (e.key === 'Enter'){
    e.preventDefault();
    showToast(`${current.dataset.title || current.textContent.trim()} opened`);
  } else if (e.key.toLowerCase() === 'i'){
    e.preventDefault();
    $('infoPopup').classList.toggle('show');
  }
});

async function save(payload, message){ try{ await apiPost('/api/settings', payload); setGlobal(message); showToast(message); await refreshSettings(); await refreshDashboard(); await refreshHome(); } catch(e){ setGlobal('Save failed: ' + e.message); showToast('Save failed'); } }

if ($('savePerformanceBtn')) $('savePerformanceBtn').onclick = () => save({ performance:{ prewarmEverythingOnBoot:$('performance_prewarmEverythingOnBoot').value==='true', prioritizeMostUsedChannels:$('performance_prioritizeMostUsedChannels').value==='true', instantEverywhereMode:$('performance_instantEverywhereMode').value==='true' }, cache:{ preloadChannelsGuideOnBoot:$('cache_preloadChannelsGuideOnBoot').value==='true', preloadTopChannelsOnBoot:$('cache_preloadTopChannelsOnBoot').value==='true', preloadRecentMoviesOnBoot:$('cache_preloadRecentMoviesOnBoot').value==='true', smartBackgroundCaching:$('cache_smartBackgroundCaching').value==='true', maxWarmChannels:num($('cache_maxWarmChannels').value,12), maxWarmMovies:num($('cache_maxWarmMovies').value,20) }, resume:{ enabled:$('resume_enabled').value==='true', saveEverySeconds:num($('resume_saveEverySeconds').value,15), markWatchedPercent:num($('resume_markWatchedPercent').value,92), keepRecentItems:num($('resume_keepRecentItems').value,200) } }, 'Performance / Resume saved.');
if ($('runWarmBtn')) $('runWarmBtn').onclick = async () => { try{ setGlobal('Running warm-up now…'); await apiPost('/api/performance/warm', {}); setGlobal('Warm-up complete.'); await refreshDashboard(); } catch(e){ setGlobal('Warm-up failed: ' + e.message); } };
if ($('saveSmartHomeBtn')) $('saveSmartHomeBtn').onclick = () => save({ smartHome:{ enabled:$('smartHome_enabled').value==='true', recommendationsEnabled:$('smartHome_recommendationsEnabled').value==='true', continueWatchingFirst:$('smartHome_continueWatchingFirst').value==='true', blendLiveAndVOD:$('smartHome_blendLiveAndVOD').value==='true', preferCachedSources:$('smartHome_preferCachedSources').value==='true', maxRecommendedItems:num($('smartHome_maxRecommendedItems').value,12) } }, 'Smart Home saved.');
if ($('saveChannelsBtn')) $('saveChannelsBtn').onclick = () => save({ channelsDvr:{ enabled:$('channels_enabled').value==='true', serverUrl:$('channels_serverUrl').value, showOnHome:$('channels_showOnHome').value==='true', fullGuideEnabled:$('channels_fullGuideEnabled').value==='true', miniPreviewEnabled:$('channels_miniPreviewEnabled').value==='true', playbackMode:$('channels_playbackMode').value, preferredStreamFormat:$('channels_preferredStreamFormat').value, fallbackDeviceOverride:$('channels_fallbackDeviceOverride').value, gracenoteEnabled:$('channels_gracenoteEnabled').value==='true' } }, 'Channels DVR saved.');
if ($('saveProvidersBtn')) $('saveProvidersBtn').onclick = () => save({ stremio:{ enabled:$('stremio_enabled').value==='true', catalogEnabled:$('stremio_catalogEnabled').value==='true', addonsText:$('stremio_addonsText').value }, torrentio:{ enabled:$('torrentio_enabled').value==='true', baseUrl:$('torrentio_baseUrl').value, useBuiltInConfigurator:$('torrentio_useBuiltInConfigurator').value==='true', sortMode:$('torrentio_sortMode').value, maxResults:num($('torrentio_maxResults').value,20) }, debrid:{ provider:$('debrid_provider').value, realDebrid:{ enabled:$('rd_enabled').value==='true', apiKey:$('rd_apiKey').value }, torbox:{ enabled:$('torbox_enabled').value==='true', apiKey:$('torbox_apiKey').value } } }, 'Providers / Debrid saved.');
if ($('saveUiBtn')) $('saveUiBtn').onclick = () => save({ home:{ timeFormat:$('home_timeFormat').value, moviePosterScale:num($('home_moviePosterScale').value,1.08), posterGapPx:num($('home_posterGapPx').value,18), showChannelsDvrOnHome:$('home_showChannelsDvrOnHome').value==='true', showIptvOnHome:$('home_showIptvOnHome').value==='true' }, profiles:{ enabled:$('profiles_enabled').value==='true', askWhosWatchingOnStartup:$('profiles_askWhosWatchingOnStartup').value==='true', alwaysUseSameProfile:$('profiles_alwaysUseSameProfile').value==='true', defaultProfile:$('profiles_defaultProfile').value, lastProfile:$('profiles_lastProfile').value }, search:{ enabled:$('search_enabled').value==='true', includeLiveTv:$('search_includeLiveTv').value==='true', includeMoviesShows:$('search_includeMoviesShows').value==='true' } }, 'Home / Profiles / Search saved.');
if ($('saveTmdbBtn')) $('saveTmdbBtn').onclick = () => save({ tmdb:{ enabled:$('tmdb_enabled').value==='true', language:$('tmdb_language').value || 'en-US', apiKey:$('tmdb_apiKey').value } }, 'TMDB saved.');
if ($('saveGpuBtn')) $('saveGpuBtn').onclick = () => save({ gpu:{ gpuAcceleration:$('gpu_gpuAcceleration').value, transcodingMode:$('gpu_transcodingMode').value, preferDirectPlay:$('gpu_preferDirectPlay').value==='true', qsvDevicePath:$('gpu_qsvDevicePath').value, useGpuFor:{ browserConversion:$('gpu_browserConversion').value==='true', liveTvConversion:$('gpu_liveTvConversion').value==='true', movieShowConversion:$('gpu_movieShowConversion').value==='true', dvrProcessing:$('gpu_dvrProcessing').value==='true' }, hlsSegmentLength:num($('gpu_hlsSegmentLength').value,4), hlsPlaylistSize:num($('gpu_hlsPlaylistSize').value,6) } }, 'GPU saved.');




function setSignalBars(level){ return; }
function _noop(){}

function renderNetworkIcon(type){
  const host = document.getElementById('networkBars');
  if (!host) return;
  const wifiSvg = `
    <svg class="network-svg" viewBox="0 0 20 20" aria-hidden="true">
      <path d="M3 8.2c4.2-3.4 9.8-3.4 14 0" />
      <path d="M5.8 11c2.6-2.1 5.8-2.1 8.4 0" />
      <path d="M8.7 13.8c.8-.6 1.8-.6 2.6 0" />
      <circle class="fill" cx="10" cy="16.3" r="1.2"/>
    </svg>`;
  const lanSvg = `
    <svg class="network-svg" viewBox="0 0 20 20" aria-hidden="true">
      <rect x="5.2" y="3.7" width="9.6" height="6.3" rx="1.4" />
      <path d="M7 10.7v2.4M10 10.7v2.4M13 10.7v2.4" />
      <path d="M4.4 14.4h11.2" />
      <path d="M10 14.4v2.2" />
    </svg>`;
  host.innerHTML = type === 'LAN' ? lanSvg : wifiSvg;
}
function updateNetworkStatus(){
  let type = 'WiFi';
  let speedText = '-- Mbps';
  const conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;

  if (conn){
    if (conn.type){
      const raw = String(conn.type).toLowerCase();
      if (raw.includes('ethernet')) type = 'LAN';
      else if (raw.includes('wifi')) type = 'WiFi';
      else if (raw.includes('cell')) type = 'Mobile';
      else type = raw.toUpperCase();
    }
    if (typeof conn.downlink === 'number' && isFinite(conn.downlink)) {
      speedText = `${conn.downlink.toFixed(conn.downlink >= 10 ? 0 : 1)} Mbps`;
      if (typeof conn.rtt === 'number' && isFinite(conn.rtt) && conn.rtt > 0) speedText += ` • ${Math.round(conn.rtt)} ms`;
    } else if (conn.effectiveType) {
      speedText = String(conn.effectiveType).toUpperCase();
    }
  } else if (location.hostname.startsWith('192.') || location.hostname.startsWith('10.') || location.hostname.startsWith('172.')) {
    type = 'LAN';
    speedText = 'Local';
  }

  const labelEl = document.getElementById('networkLabel');
  const speedEl = document.getElementById('networkSpeed');
  if (labelEl) labelEl.textContent = type;
  if (speedEl) {
    speedEl.textContent = speedText;
    speedEl.style.display = speedText && speedText !== '-- Mbps' ? 'inline' : 'none';
  }
  renderNetworkIcon(type);
}
function updateTopClockWeather(){
  const now = new Date();
  const clock = document.getElementById('clockText');
  const weatherIcon = document.getElementById('weatherIcon');
  if (clock) clock.textContent = now.toLocaleTimeString([], {hour:'numeric', minute:'2-digit'});
  if (weatherIcon) weatherIcon.textContent = now.getHours() >= 18 || now.getHours() < 6 ? '☾' : '☀';
}


function serviceToggleRow(name, state){
  const isOn = state === 'configured' || state === 'connected';
  return `<div class="service-item"><span>${name}</span><div class="toggle ${isOn ? 'on' : ''}"></div></div>`;
}

function fallbackRows(){
  return {
    featured:[{title:'SHŌGUN', subtitle:'S1 E7: A Stick of Time • 43 min left', description:'A premium lean-back presentation for your media server, with live TV, continue watching, smart recommendations, and polished Android TV style navigation.', backdrop:'', poster:'', source:'realdebrid', rating:'IMDb 8.4', sourceBadges:['Channels DVR','Debrid','TMDB']}],
    continueWatching:[
      {title:'SHŌGUN', subtitle:'43 min left', source:'channels_dvr', backdrop:'', poster:''},
      {title:'The Batman', subtitle:'Resume', source:'stremio', backdrop:'', poster:''},
      {title:'Fallout', subtitle:'49 min left', source:'realdebrid', backdrop:'', poster:''}
    ],
    recommendedForYou:[
      {title:'Dune Part Two', subtitle:'Movie', source:'realdebrid', backdrop:'', poster:''},
      {title:'Halo', subtitle:'Series', source:'trailers', backdrop:'', poster:''},
      {title:'Wonka', subtitle:'Movie', source:'stremio', backdrop:'', poster:''},
      {title:'Mayor of Kingstown', subtitle:'Series', source:'torrentio', backdrop:'', poster:''}
    ],
    becauseYouWatched:[
      {title:'Fallout', subtitle:'Sci‑Fi • Continue', source:'realdebrid', backdrop:'', poster:''},
      {title:'The Batman', subtitle:'Dark • Resume', source:'stremio', backdrop:'', poster:''},
      {title:'Shōgun', subtitle:'Epic • Similar', source:'torrentio', backdrop:'', poster:''},
      {title:'Dune Part Two', subtitle:'Because you watched sci‑fi', source:'realdebrid', backdrop:'', poster:''}
    ],
    trendingNow:[
      {title:'Wonka', subtitle:'Trending Movie', source:'stremio', backdrop:'', poster:''},
      {title:'Halo', subtitle:'Trending Series', source:'trailers', backdrop:'', poster:''},
      {title:'Mayor of Kingstown', subtitle:'Trending Crime', source:'torrentio', backdrop:'', poster:''},
      {title:'Fallout', subtitle:'Trending Sci‑Fi', source:'realdebrid', backdrop:'', poster:''}
    ],
    recentlyAdded:[
      {title:'MSNBC', subtitle:'Live channel', number:'6001', source:'channels_dvr', backdrop:'', poster:''},
      {title:'AMC', subtitle:'The Departed', number:'6025', source:'channels_dvr', backdrop:'', poster:''},
      {title:'The Batman', subtitle:'Recently added', source:'stremio', backdrop:'', poster:''},
      {title:'Wonka', subtitle:'Recently added', source:'realdebrid', backdrop:'', poster:''}
    ],
    liveNow:[
      {title:'MSNBC', subtitle:'Inside...', number:'6001', source:'channels_dvr', backdrop:'', poster:''},
      {title:'AMC', subtitle:'The Departed', number:'6025', source:'channels_dvr', backdrop:'', poster:''},
      {title:'ESPN', subtitle:'MLB: Braves...', number:'6026', source:'channels_dvr', backdrop:'', poster:''},
      {title:'ABC', subtitle:'Mets (NYM)', number:'3563', source:'channels_dvr', backdrop:'', poster:''}
    ]
  };
}
function renderAndroidTvShell(data, servicesData, healthData, profileData){

  const rows = (data && data.rows && Object.keys(data.rows).length ? data.rows : fallbackRows());
  const featured = Array.isArray(rows.featured) ? rows.featured[0] : null;
  if (featured){
    $('androidBg').style.backgroundImage = `url('${featured.backdrop || featured.poster || ''}')`;
    $('showTitle').textContent = (featured.title || 'Featured').toUpperCase();
    $('showMeta').textContent = `${featured.subtitle || ''}${featured.rating ? ' • ' + featured.rating : ''}`;
    $('showDesc').textContent = featured.description || 'Premium Android TV style browsing with live TV, continue watching, intelligent recommendations, and dynamic home rows.';
  }
  if (healthData?.build) $('sideBuild').textContent = healthData.build;
  if (healthData?.channelsDvrUrl){
    try{
      const u = new URL(healthData.channelsDvrUrl);
      $('serverIp').textContent = u.hostname;
    }catch{}
  }
  $('profileName').textContent = profileData?.autoLoginProfile || profileData?.defaultProfile || profileData?.lastProfile || 'Max';

  const services = servicesData?.services || {};
  $('serviceList').innerHTML = [
    serviceToggleRow('Channels DVR', services.channelsDvr),
    serviceToggleRow('Debrid', services.realDebrid),
    serviceToggleRow('Cache', services.cache),
    serviceToggleRow('GPU', services.gpu),
    serviceToggleRow('TMDB', services.tmdb || 'disabled')
  ].join('');

  function card(item, focused=false){
    const runtime = item.subtitle || item.year || item.type || '';
    const brand = sourceLabel(item.source).toLowerCase();
    return `<div class="poster-card focusable ${focused ? 'hero-focus' : ''}" tabindex="0" data-focus-group="continue" data-prefetch="true" data-source="${(item.source || '').replace(/"/g,'&quot;')}" data-title="${(item.title || 'Untitled').replace(/"/g,'&quot;')}" data-meta="${runtime.replace(/"/g,'&quot;')}" data-desc="${((item.description || 'Continue watching this title on ChannelsDebrid.')).replace(/"/g,'&quot;')}"><div class="card-prefetch">preloading</div>
      <div class="poster-art" style="background-image:url('${item.backdrop || item.poster || ''}')">
        <div class="poster-overlay-gradient"></div>
        <div class="logo-chip">${brand}</div>
        <div class="runtime-chip">${runtime}</div>
      </div>
      <div class="poster-info">
        <div class="poster-title">${item.title || 'Untitled'}</div>
        <div class="progress"><span></span></div>
      </div>
      <div class="provider-mark">${(sourceLabel(item.source) || "").toLowerCase()}</div>
    </div>`;
  }
  function smallCard(item, live=false){
    const meta = item.subtitle || item.year || item.type || '';
    return `<div class="small-card focusable" tabindex="0" data-focus-group="${live ? 'live' : 'spotlight'}" data-prefetch="true" data-source="${(item.source || '').replace(/"/g,'&quot;')}" data-title="${(item.title || 'Untitled').replace(/"/g,'&quot;')}" data-meta="${meta.replace(/"/g,'&quot;')}" data-desc="${((item.description || 'Browse this title in ChannelsDebrid.')).replace(/"/g,'&quot;')}"><div class="card-prefetch">preloading</div>
      <div class="small-art" style="background-image:url('${item.backdrop || item.poster || ''}')">
        <div class="poster-overlay-gradient"></div>
        <div class="logo-chip">${sourceLabel(item.source).toLowerCase()}</div>
      </div>
      <div class="small-info">
        <div class="small-title">${item.title || 'Untitled'}</div>
        <div class="small-row-meta">${live ? `<span class="live-number">${item.number || ''}</span>` : ''}${meta}</div>
      </div>
    </div>`;
  }

  const continueItems = (rows.continueWatching || []).slice(0, 4);
  const spotlightItems = (rows.becauseYouWatched?.length ? rows.becauseYouWatched : (rows.recommendedForYou?.length ? rows.recommendedForYou : rows.trendingMovies || [])).slice(0, 4);
  const liveItems = (rows.liveNow || []).slice(0, 5);

  const smartSummary = document.getElementById('smartSummary');
  if (smartSummary){
    smartSummary.innerHTML = [
      ['Recommended', (rows.recommendedForYou || []).length],
      ['Because You Watched', (rows.becauseYouWatched || []).length],
      ['Trending Now', (rows.trendingNow || []).length],
      ['Recently Added', (rows.recentlyAdded || []).length]
    ].map(([k,v]) => `<div class="smart-pill"><div class="smart-pill-k">${k}</div><div class="smart-pill-v">${v}</div></div>`).join('');
  }

  $('continueRow').innerHTML = continueItems.length
    ? continueItems.map((item, i) => card(item, i === 0)).join('')
    : `<div class="status">No continue watching items yet.</div>`;

  $('spotlightRow').innerHTML = spotlightItems.length
    ? spotlightItems.map(item => smallCard(item)).join('')
    : `<div class="status">No spotlight items yet.</div>`;

  $('liveRow').innerHTML = liveItems.length
    ? liveItems.map(item => smallCard(item, true)).join('')
    : `<div class="status">No live TV items yet.</div>`;

  const now = new Date();
  updateTopClockWeather();
}


(async function boot(){
  try{
    primeLoadingState();
    await refreshSettings().catch(()=>null);
    await refreshDashboard().catch(()=>null);

    const [homeData, servicesData, healthData, profileData] = await Promise.all([
      fetchDashboardRowsWithRetry(),
      apiGet('/api/services/status').catch(()=>({services:{}})),
      apiGet('/health').catch(()=>({})),
      apiGet('/api/profile/state').catch(()=>({}))
    ]);

    renderHomeRows(homeData);
    renderAndroidTvShell(homeData, servicesData, healthData, profileData);
    setupSettingsDrawer();
    document.getElementById('trailerOverlay')?.addEventListener('click', closeTrailerPopup);
    initTvFocus();
    updateTopClockWeather();
    updateNetworkStatus();
    loadInstantPlaybackStatus();

    setInterval(updateTopClockWeather, 30000);
    setInterval(updateNetworkStatus, 5000);
    setInterval(async () => {
      try{
        const fresh = await fetchDashboardRowsWithRetry();
        renderHomeRows(fresh);
        renderAndroidTvShell(fresh, servicesData, healthData, profileData);
      }catch(e){}
    }, 60000);

    setGlobal('Ready.');
  }catch(e){
    console.error('Permanent pipeline boot failed', e);
    const fallback = { rows: fallbackRows() };
    renderHomeRows(fallback);
    renderAndroidTvShell(fallback, {services:{}}, {}, {});
    setupSettingsDrawer();
    document.getElementById('trailerOverlay')?.addEventListener('click', closeTrailerPopup);
    initTvFocus();
    updateTopClockWeather();
    updateNetworkStatus();
    loadInstantPlaybackStatus();
    setGlobal('Loaded fallback home layout.');
  }
})();

