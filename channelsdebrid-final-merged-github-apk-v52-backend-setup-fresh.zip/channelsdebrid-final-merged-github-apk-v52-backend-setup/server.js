const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const PORT = Number(process.env.PORT || 8418);
const DATA_DIR = path.join(__dirname, 'data');
const CACHE_DIR = path.join(__dirname, 'cache');
const PUBLIC_DIR = path.join(__dirname, 'public');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');
const PLAYBACK_CACHE_FILE = path.join(DATA_DIR, 'playback-url-cache.json');
const RESUME_FILE = path.join(DATA_DIR, 'resume-state.json');
const USAGE_FILE = path.join(DATA_DIR, 'channel-usage.json');
const WARM_FILE = path.join(DATA_DIR, 'warm-state.json');
const DEFAULTS = {
  "channelsDvr": {
    "enabled": true,
    "serverUrl": "http://192.168.100.55:8089",
    "showOnHome": true,
    "fullGuideEnabled": true,
    "miniPreviewEnabled": true,
    "playbackMode": "direct",
    "preferredStreamFormat": "mpeg_ts_copy",
    "fallbackDeviceOverride": "",
    "gracenoteEnabled": true
  },
  "iptv": {
    "enabled": false,
    "showOnHome": false,
    "sourcesText": "",
    "xtream": {
      "enabled": false,
      "server": "",
      "username": "",
      "password": ""
    }
  },
  "stremio": {
    "enabled": true,
    "addonsText": "",
    "catalogEnabled": true
  },
  "torrentio": {
    "enabled": true,
    "baseUrl": "https://torrentio.strem.fun",
    "useBuiltInConfigurator": true,
    "sortMode": "quality_then_size",
    "maxResults": 20
  },
  "debrid": {
    "provider": "realdebrid",
    "realDebrid": {
      "enabled": false,
      "apiKey": ""
    },
    "torbox": {
      "enabled": false,
      "apiKey": ""
    }
  },
  "trailers": {
    "enabled": true,
    "mode": "automatic",
    "popupEnabled": true,
    "mutePreview": true,
    "delayMs": 1200
  },
  "mediaFlowProxy": {
    "enabled": false,
    "url": "",
    "username": "",
    "password": ""
  },
  "tailscale": {
    "enabled": false,
    "localUrl": "",
    "remoteTailnetUrl": ""
  },
  "player": {
    "primary": "media3",
    "vlcFallbackEnabled": true,
    "autoPlayBestStream": true,
    "maxFileSizeGb": 80
  },
  "timeshift": {
    "enabled": true,
    "storageMode": "internal",
    "internalLimitGb": 8,
    "usbPath": "",
    "nasPath": "",
    "unlimitedExternal": true
  },
  "cache": {
    "enabled": true,
    "preferExternalForMovies": true,
    "internalLimitGb": 8,
    "usbPath": "",
    "nasPath": "",
    "continuousPreload": true,
    "imageCacheEnabled": true,
    "metadataCacheEnabled": true,
    "playbackCacheEnabled": true,
    "guideCacheTtlMinutes": 10,
    "catalogCacheTtlMinutes": 30,
    "imageCacheDays": 14,
    "preferWarmCacheOnStartup": true,
    "smartBackgroundCaching": true,
    "preloadChannelsGuideOnBoot": true,
    "preloadTopChannelsOnBoot": true,
    "preloadRecentMoviesOnBoot": true,
    "maxWarmChannels": 12,
    "maxWarmMovies": 20
  },
  "home": {
    "timeFormat": "12h",
    "moviePosterScale": 1.08,
    "posterGapPx": 18,
    "showChannelsDvrOnHome": true,
    "showIptvOnHome": false
  },
  "profiles": {
    "enabled": true,
    "askWhosWatchingOnStartup": true,
    "alwaysUseSameProfile": false,
    "defaultProfile": "",
    "lastProfile": ""
  },
  "search": {
    "enabled": true,
    "includeLiveTv": true,
    "includeMoviesShows": true
  },
  "gpu": {
    "gpuAcceleration": "intel_qsv",
    "transcodingMode": "auto",
    "preferDirectPlay": true,
    "qsvDevicePath": "/dev/dri/renderD128",
    "useGpuFor": {
      "browserConversion": true,
      "liveTvConversion": true,
      "movieShowConversion": true,
      "dvrProcessing": false
    },
    "hlsSegmentLength": 4,
    "hlsPlaylistSize": 6
  },
  "resume": {
    "enabled": true,
    "saveEverySeconds": 15,
    "markWatchedPercent": 92,
    "keepRecentItems": 200
  },
  "performance": {
    "prewarmEverythingOnBoot": true,
    "prioritizeMostUsedChannels": true,
    "instantEverywhereMode": true
  },
  "smartHome": {
    "enabled": true,
    "recommendationsEnabled": true,
    "continueWatchingFirst": true,
    "blendLiveAndVOD": true,
    "preferCachedSources": true,
    "maxRecommendedItems": 12
  },
  "tmdb": {
    "enabled": false,
    "apiKey": "",
    "language": "en-US"
  }
};

for (const dir of [DATA_DIR, path.join(CACHE_DIR, 'images'), path.join(CACHE_DIR, 'metadata'), path.join(CACHE_DIR, 'playback')]) {
  fs.mkdirSync(dir, { recursive: true });
}
function ensureFile(file, value){ if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify(value, null, 2)); }
ensureFile(SETTINGS_FILE, DEFAULTS);
ensureFile(PLAYBACK_CACHE_FILE, {});
ensureFile(RESUME_FILE, { items: [] });
ensureFile(USAGE_FILE, { channels: {} });
ensureFile(WARM_FILE, { lastWarmAt: 0, actions: [] });

function safe(v){ return String(v ?? '').trim(); }
function esc(s){ return safe(s).replace(/[<>&'"]/g, c => ({'<':'&lt;','>':'&gt;','&':'&amp;',"'":'&#39;','"':'&quot;'}[c])); }
function fmt12(ts){ return new Date(ts).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true }); }
function readJson(file, fallback){ try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJson(file, value){ fs.writeFileSync(file, JSON.stringify(value, null, 2)); }
function deepMerge(base, incoming){
  const out = Array.isArray(base) ? [...base] : { ...base };
  for (const [k, v] of Object.entries(incoming || {})) {
    if (v && typeof v === 'object' && !Array.isArray(v) && base && typeof base[k] === 'object' && !Array.isArray(base[k])) out[k] = deepMerge(base[k], v);
    else out[k] = v;
  }
  return out;
}
function loadSettings(){ return deepMerge(DEFAULTS, readJson(SETTINGS_FILE, {})); }
function saveSettings(v){ writeJson(SETTINGS_FILE, v); }
function loadPlaybackCache(){ return readJson(PLAYBACK_CACHE_FILE, {}); }
function savePlaybackCache(v){ writeJson(PLAYBACK_CACHE_FILE, v); }
function loadResume(){ return readJson(RESUME_FILE, { items: [] }); }
function saveResume(v){ writeJson(RESUME_FILE, v); }
function loadUsage(){ return readJson(USAGE_FILE, { channels: {} }); }
function saveUsage(v){ writeJson(USAGE_FILE, v); }
function loadWarm(){ return readJson(WARM_FILE, { lastWarmAt: 0, actions: [] }); }
function saveWarm(v){ writeJson(WARM_FILE, v); }

function sendJson(res, status, data){
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Allow-Headers':'*'});
  res.end(JSON.stringify(data, null, 2));
}
function sendText(res, status, body, type='text/html; charset=utf-8'){
  res.writeHead(status, {'Content-Type':type,'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Allow-Headers':'*'});
  res.end(body);
}
function serveFile(res, file){
  fs.readFile(file, (err, data) => err ? sendJson(res, 404, { ok:false, error:'Not found' }) : sendText(res, 200, data));
}

async function fetchJson(url){
  const res = await fetch(url, { headers: { Accept: 'application/json' } });
  if (!res.ok) throw new Error(`Fetch failed ${res.status}: ${url}`);
  return await res.json();
}
async function probeDetailed(url){
  try {
    let res = await fetch(url, { method:'HEAD' });
    if (res.ok) return { ok:true, status:res.status, method:'HEAD', url };
    if ([400,401,403,404,405].includes(res.status)) {
      const res2 = await fetch(url, { method:'GET' });
      return { ok:res2.ok, status:res2.status, method:'GET', url };
    }
    return { ok:false, status:res.status, method:'HEAD', url };
  } catch (e) {
    return { ok:false, status:null, method:'HEAD', url, error:String(e.message || e) };
  }
}

async function fetchTmdb(query){
  const s = loadSettings();
  const key = safe(s.tmdb?.apiKey) || safe(process.env.TMDB_API_KEY);
  const language = safe(s.tmdb?.language) || 'en-US';
  if (!s.tmdb?.enabled || !key || !query) return null;
  try {
    const url = `https://api.themoviedb.org/3/search/multi?api_key=${key}&language=${encodeURIComponent(language)}&query=${encodeURIComponent(query)}`;
    const res = await fetch(url);
    const json = await res.json();
    const item = (json.results || [])[0];
    if (!item) return null;
    return {
      poster: item.poster_path ? `https://image.tmdb.org/t/p/w500${item.poster_path}` : '',
      backdrop: item.backdrop_path ? `https://image.tmdb.org/t/p/original${item.backdrop_path}` : ''
    };
  } catch { return null; }
}
function placeholderSvg(title, subtitle='', kind='poster'){
  const w = kind === 'backdrop' ? 1280 : 600;
  const h = kind === 'backdrop' ? 720 : 900;
  const svg = `<?xml version="1.0" encoding="UTF-8"?>
  <svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">
    <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#1a2640"/><stop offset="55%" stop-color="#203b58"/><stop offset="100%" stop-color="#0c1220"/></linearGradient></defs>
    <rect width="100%" height="100%" fill="url(#g)"/>
    <text x="8%" y="18%" fill="#c7d9ff" font-family="Arial" font-size="${kind==='backdrop' ? 26 : 28}" letter-spacing="4">CHANNELSDEBRID</text>
    <text x="8%" y="${kind==='backdrop' ? '46%' : '54%'}" fill="#ffffff" font-family="Arial" font-weight="900" font-size="${kind==='backdrop' ? 76 : 54}">${esc(title).slice(0, 48)}</text>
    <text x="8%" y="${kind==='backdrop' ? '54%' : '61%'}" fill="#d6dff2" font-family="Arial" font-size="${kind==='backdrop' ? 28 : 24}">${esc(subtitle).slice(0, 64)}</text>
  </svg>`;
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
}
function mockPlayUrlForItem(item){
  const title = safe(item.title || 'Now Playing');
  if (safe(item.source) === 'channels_dvr' && safe(item.id)) return `/api/playback/live/channels-dvr/${encodeURIComponent(item.id)}`;
  return `/api/playback/mock?title=${encodeURIComponent(title)}`;
}
async function withArtwork(item, fallbackTitle, fallbackSubtitle=''){
  const title = safe(item.title || fallbackTitle || 'Untitled');
  const subtitle = safe(item.subtitle || item.year || fallbackSubtitle || '');
  const tmdb = await fetchTmdb(title);
  return {
    ...item,
    playUrl: safe(item.playUrl) || mockPlayUrlForItem(item),
    poster: safe(item.poster) || tmdb?.poster || placeholderSvg(title, subtitle, 'poster'),
    backdrop: safe(item.backdrop) || tmdb?.backdrop || placeholderSvg(title, subtitle, 'backdrop')
  };
}

function metadataFile(name){ return path.join(CACHE_DIR, 'metadata', `${name}.json`); }
function readFreshJson(file, ttlMinutes){
  try {
    const st = fs.statSync(file);
    if ((Date.now() - st.mtimeMs) > ttlMinutes * 60 * 1000) return null;
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch { return null; }
}
async function getChannels(){
  const s = loadSettings();
  const baseUrl = s.channelsDvr.serverUrl.replace(/\/$/, '');
  const cacheFile = metadataFile('channels');
  const cached = s.cache.enabled && s.cache.metadataCacheEnabled ? readFreshJson(cacheFile, s.cache.guideCacheTtlMinutes) : null;
  if (cached) return cached;
  let result = [];
  try {
    const devices = await fetchJson(`${baseUrl}/devices`);
    if (Array.isArray(devices?.devices)) {
      for (const dev of devices.devices) {
        const devName = safe(dev.Name || dev.name || dev.ID || dev.id || dev.DeviceID || dev.deviceName);
        for (const ch of (dev.channels || dev.Channels || [])) result.push({ ...ch, __deviceName: devName });
      }
    }
  } catch {}
  if (!result.length) {
    try {
      const data = await fetchJson(`${baseUrl}/devices/ANY/channels`);
      result = Array.isArray(data) ? data : (Array.isArray(data.channels) ? data.channels : []);
    } catch {}
  }
  if (s.cache.enabled && s.cache.metadataCacheEnabled) writeJson(cacheFile, result);
  return result;
}
async function getGuide(){
  const s = loadSettings();
  const baseUrl = s.channelsDvr.serverUrl.replace(/\/$/, '');
  const cacheFile = metadataFile('guide');
  const cached = s.cache.enabled && s.cache.metadataCacheEnabled ? readFreshJson(cacheFile, s.cache.guideCacheTtlMinutes) : null;
  if (cached) return cached;
  for (const u of [`${baseUrl}/guide`, `${baseUrl}/guide/grid`, `${baseUrl}/guide/channels`]) {
    try {
      const data = await fetchJson(u);
      const out = Array.isArray(data) ? data : (Array.isArray(data.items) ? data.items : (Array.isArray(data.guide) ? data.guide : []));
      if (out.length) { if (s.cache.enabled && s.cache.metadataCacheEnabled) writeJson(cacheFile, out); return out; }
    } catch {}
  }
  return [];
}
function mapChannels(rawChannels, rawGuide){
  const guideMap = new Map();
  for (const g of rawGuide) {
    const keys = [safe(g.number), safe(g.channelNumber), safe(g.guideNumber), safe(g.GuideNumber), safe(g.Station)].filter(Boolean);
    const item = { title: g.title || g.name || g.programTitle || g.seriesTitle || g.GuideName || 'Unknown Program', image: g.image || g.poster || g.thumbnail || g.art || g.Logo || '', start: Number(g.start || g.startTime || Date.now()), end: Number(g.end || g.endTime || (Date.now()+3600000)) };
    for (const key of keys) if (!guideMap.has(key)) guideMap.set(key, item);
  }
  const playbackCache = loadPlaybackCache();
  return rawChannels.map(c => {
    const id = safe(c.ID || c.id || c.slug || c.callsign || c.CallSign);
    const number = safe(c.GuideNumber || c.number || c.Number || c.guideNumber);
    const channel = safe(c.GuideName || c.name || c.Name || c.callsign || c.CallSign || id || 'Channel');
    const guide = guideMap.get(number);
    const start = guide?.start ?? Date.now(), end = guide?.end ?? (Date.now()+3600000);
    return { id: id || number, playbackId: id || number, number, channel, deviceName: safe(c.__deviceName || c.DeviceName || c.deviceName || c.Source || c.source || c.Device || c.device), title: guide?.title || channel, poster: guide?.image || c.Logo || c.logo || c.Image || '', startLabel: fmt12(start), endLabel: fmt12(end), cachedUrl: playbackCache[id || number] || '' };
  }).filter(v => v.id);
}
function buildCandidates(ch, baseUrl){
  const id = safe(ch.ID || ch.id || ch.slug || ch.callsign || ch.CallSign);
  const num = safe(ch.GuideNumber || ch.number || ch.Number || ch.guideNumber);
  const station = safe(ch.Station || ch.station);
  const name = safe(ch.GuideName || ch.name || ch.Name);
  const device = safe(ch.__deviceName || ch.DeviceName || ch.deviceName || ch.Source || ch.source || ch.Device || ch.device);
  const devices = [...new Set([device, 'ANY'].filter(Boolean))];
  const keys = [...new Set([num, id, station, name].filter(Boolean))];
  const urls = [];
  for (const d of devices) for (const k of keys) {
    urls.push(`${baseUrl}/devices/${encodeURIComponent(d)}/channels/${encodeURIComponent(k)}/stream.mpg?format=ts&codec=copy`);
    urls.push(`${baseUrl}/devices/${encodeURIComponent(d)}/channels/${encodeURIComponent(k)}/stream.m3u8`);
  }
  return urls;
}
async function resolvePlayback(ch){
  const s = loadSettings();
  const baseUrl = s.channelsDvr.serverUrl.replace(/\/$/, '');
  const cache = loadPlaybackCache();
  const key = safe(ch.ID || ch.id || ch.GuideNumber || ch.number || ch.GuideName || ch.name);
  if (s.cache.enabled && s.cache.playbackCacheEnabled && cache[key]) {
    const chk = await probeDetailed(cache[key]);
    if (chk.ok) return { directUrl: cache[key], fromCache: true };
  }
  for (const candidate of buildCandidates(ch, baseUrl)) {
    const chk = await probeDetailed(candidate);
    if (chk.ok) { cache[key] = candidate; savePlaybackCache(cache); return { directUrl: candidate, fromCache: false }; }
  }
  return { directUrl: '', fromCache: false };
}
function bumpChannelUsage(id){ const usage = loadUsage(); usage.channels[id] = (usage.channels[id] || 0) + 1; saveUsage(usage); }
function topUsedChannelIds(limit){ return Object.entries(loadUsage().channels || {}).sort((a,b)=>b[1]-a[1]).slice(0, limit).map(([id]) => id); }
async function warmStartup(){
  const s = loadSettings(), state = loadWarm(), actions = [];
  if (!s.cache.enabled || !s.performance.prewarmEverythingOnBoot) { state.actions = ['warm skipped']; state.lastWarmAt = Date.now(); saveWarm(state); return state; }
  const [rawChannels, rawGuide] = await Promise.all([getChannels(), getGuide()]);
  actions.push(`guide loaded ${rawGuide.length}`);
  const selected = [];
  for (const id of topUsedChannelIds(s.cache.maxWarmChannels)) {
    const found = rawChannels.find(c => safe(c.ID || c.id || c.GuideNumber || c.number || c.Number || c.callsign || c.CallSign || c.GuideName) === id);
    if (found) selected.push(found);
  }
  for (const item of rawChannels) {
    if (selected.length >= s.cache.maxWarmChannels) break;
    const id = safe(item.ID || item.id || item.GuideNumber || item.number || item.Number || item.callsign || item.CallSign || item.GuideName);
    if (!selected.find(x => safe(x.ID || x.id || x.GuideNumber || x.number || x.Number || x.callsign || x.CallSign || x.GuideName) === id)) selected.push(item);
  }
  for (const ch of selected) {
    const id = safe(ch.ID || ch.id || ch.GuideNumber || ch.number || ch.Number || ch.callsign || ch.CallSign || ch.GuideName);
    const resolved = await resolvePlayback(ch);
    actions.push(`warm channel ${id}: ${resolved.directUrl ? 'ok' : 'miss'}`);
  }
  state.lastWarmAt = Date.now(); state.actions = actions; saveWarm(state); return state;
}
function scoreRecommendation(item, usage, resumeStore, settings){
  let score = 0;
  const id = safe(item.id), title = safe(item.title), source = safe(item.source), tags = Array.isArray(item.tags) ? item.tags.map(safe) : [];
  const channelHits = usage.channels[id] || usage.channels[title] || 0;
  const resumeHit = (resumeStore.items || []).find(x => safe(x.id) === id || safe(x.title) === title);
  if (channelHits) score += channelHits * 8;
  if (resumeHit) score += 40;
  if (settings.smartHome.preferCachedSources && ['realdebrid','channels_dvr'].includes(source)) score += 12;
  if (source === 'channels_dvr' && settings.smartHome.blendLiveAndVOD) score += 8;
  if (tags.includes('Featured')) score += 10;
  if (tags.includes('Trending')) score += 7;
  if (tags.includes('Top')) score += 5;
  if (tags.includes('Streaming')) score += 4;
  return score;
}
function uniqById(items){ const seen = new Set(), out = []; for (const item of items || []) { const key = safe(item.id || item.title); if (!key || seen.has(key)) continue; seen.add(key); out.push(item); } return out; }

warmStartup().catch(() => null);

async function buildHomeRows(){
  const settings = loadSettings(), resume = loadResume(), usage = loadUsage();
  async function art(items){ const out = []; for (const item of items) out.push(await withArtwork(item, item.title, item.year || item.type || '')); return out; }
  let liveNow = [];
  try {
    const [rawChannels, rawGuide] = await Promise.all([getChannels(), getGuide()]);
    const mapped = mapChannels(rawChannels, rawGuide).slice(0, 8);
    liveNow = await art(mapped.map(x => ({ id:x.id, title:x.channel, subtitle:`${x.startLabel} - ${x.endLabel}`, type:'channel', tags:['Live TV'], source:'channels_dvr', poster:x.poster || '', backdrop:x.poster || '' })));
  } catch {}
  const continueWatching = [];
  for (const item of (resume.items || []).slice(0, 12)) continueWatching.push(await withArtwork(item, item.title, item.type || 'Continue watching'));
  const featured = await art([{ id:'f1', title:'The Testament of Ann Lee', subtitle:'Drama / History • 2h 17m', year:'2025', description:'Ann Lee, the founding leader of the Shaker Movement, proclaimed as the female Christ by her followers.', sourceBadges:['Channels DVR','Trailers','MediaFlow'], rating:'IMDb 7.1', source:'realdebrid', tags:['Featured'] }]);
  const trendingMovies = await art([{id:'m1',title:'The Testament of Ann Lee',type:'movie',year:'2025',tags:['Drama','Featured'],source:'realdebrid'},{id:'m2',title:'Good Luck Have Fun',type:'movie',year:'2025',tags:['New','Movie'],source:'torrentio'},{id:'m3',title:'Bride!',type:'movie',year:'2025',tags:['Popular','HD'],source:'stremio'},{id:'m4',title:'Hoppers',type:'movie',year:'2025',tags:['Trending','Fast UI'],source:'trailers'}]);
  const popularMovies = await art([{id:'m5',title:'Popular Movie 1',type:'movie',year:'2024',tags:['Top'],source:'realdebrid'},{id:'m6',title:'Popular Movie 2',type:'movie',year:'2024',tags:['Top'],source:'torrentio'},{id:'m7',title:'Popular Movie 3',type:'movie',year:'2024',tags:['Top'],source:'stremio'},{id:'m8',title:'Popular Movie 4',type:'movie',year:'2024',tags:['Top'],source:'trailers'}]);
  const trendingShows = await art([{id:'s1',title:'Trending Show 1',type:'show',year:'2025',tags:['Series','Trending'],source:'stremio'},{id:'s2',title:'Trending Show 2',type:'show',year:'2025',tags:['Series'],source:'torrentio'},{id:'s3',title:'Trending Show 3',type:'show',year:'2025',tags:['Series'],source:'realdebrid'},{id:'s4',title:'Trending Show 4',type:'show',year:'2025',tags:['Series'],source:'trailers'}]);
  const popularOnStreaming = await art([{id:'p1',title:'Popular on Streaming 1',type:'movie',year:'2025',tags:['Streaming'],source:'stremio'},{id:'p2',title:'Popular on Streaming 2',type:'show',year:'2025',tags:['Streaming'],source:'torrentio'},{id:'p3',title:'Popular on Streaming 3',type:'movie',year:'2025',tags:['Streaming'],source:'realdebrid'},{id:'p4',title:'Popular on Streaming 4',type:'show',year:'2025',tags:['Streaming'],source:'trailers'}]);
  const pool = uniqById([...(continueWatching||[]), ...(liveNow||[]), ...(trendingMovies||[]), ...(popularMovies||[]), ...(trendingShows||[]), ...(popularOnStreaming||[])]);
  const recommendedForYou = settings.smartHome.enabled && settings.smartHome.recommendationsEnabled ? pool.map(item => ({ ...item, _score: scoreRecommendation(item, usage, resume, settings) })).sort((a,b)=>b._score-a._score).slice(0, settings.smartHome.maxRecommendedItems || 12).map(({_score, ...item}) => item) : [];
  const becauseYouWatchedSeed = continueWatching[0] || trendingMovies[0] || popularOnStreaming[0] || null;
  const becauseYouWatched = becauseYouWatchedSeed
    ? uniqById(pool.filter(x => safe(x.id) !== safe(becauseYouWatchedSeed.id)).slice(0, 8))
    : [];
  const trendingNow = uniqById([...trendingMovies, ...trendingShows, ...popularOnStreaming]).slice(0, 10);
  const recentlyAdded = uniqById([...popularMovies, ...liveNow, ...trendingShows]).slice(0, 10);

  const rows = {
    ...(settings.smartHome.continueWatchingFirst ? { continueWatching } : {}),
    recommendedForYou,
    becauseYouWatched,
    trendingNow,
    recentlyAdded,
    featured,
    liveNow,
    trendingMovies,
    popularMovies,
    trendingShows,
    popularOnStreaming
  };
  if (!settings.smartHome.continueWatchingFirst) rows.continueWatching = continueWatching;
  return rows;
}

async function postJson(url, body){
  const res = await fetch(url, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
  const text = await res.text();
  let json;
  try { json = JSON.parse(text); } catch { json = { raw:text }; }
  return { ok: res.ok, status: res.status, data: json };
}
function colorFromTitle(title){
  const s = safe(title || 'title');
  let hash = 0;
  for (let i = 0; i < s.length; i++) hash = (hash * 31 + s.charCodeAt(i)) >>> 0;
  const r = 60 + (hash % 156);
  const g = 60 + ((hash >> 8) % 156);
  const b = 60 + ((hash >> 16) % 156);
  return { r, g, b };
}

function normalizedServices(){
  const s = loadSettings();
  return {
    channelsDvr: s.channelsDvr.enabled ? 'configured' : 'disabled',
    iptv: s.iptv.enabled ? ((safe(s.iptv.sourcesText) || s.iptv.xtream.enabled) ? 'configured' : 'disconnected') : 'disabled',
    xtream: s.iptv.xtream.enabled ? ((safe(s.iptv.xtream.server) && safe(s.iptv.xtream.username) && safe(s.iptv.xtream.password)) ? 'configured' : 'disconnected') : 'disabled',
    stremio: s.stremio.enabled ? 'configured' : 'disabled',
    torrentio: s.torrentio.enabled ? 'configured' : 'disabled',
    realDebrid: s.debrid.realDebrid.enabled ? (safe(s.debrid.realDebrid.apiKey) ? 'configured' : 'disconnected') : 'disabled',
    torbox: s.debrid.torbox.enabled ? (safe(s.debrid.torbox.apiKey) ? 'configured' : 'disconnected') : 'disabled',
    trailers: s.trailers.enabled ? 'configured' : 'disabled',
    mediaFlowProxy: s.mediaFlowProxy.enabled ? (safe(s.mediaFlowProxy.url) ? 'configured' : 'disconnected') : 'disabled',
    tailscale: s.tailscale.enabled ? ((safe(s.tailscale.localUrl) || safe(s.tailscale.remoteTailnetUrl)) ? 'configured' : 'disconnected') : 'disabled',
    player: 'configured',
    timeshift: s.timeshift.enabled ? 'configured' : 'disabled',
    cache: s.cache.enabled ? 'configured' : 'disabled',
    profiles: s.profiles.enabled ? 'configured' : 'disabled',
    search: s.search.enabled ? 'configured' : 'disabled',
    gpu: s.gpu.gpuAcceleration && s.gpu.gpuAcceleration !== 'off' ? 'configured' : 'disabled',
    resume: s.resume.enabled ? 'configured' : 'disabled',
    performance: s.performance.instantEverywhereMode ? 'configured' : 'disabled',
    tmdb: s.tmdb.enabled ? (safe(s.tmdb.apiKey) ? 'configured' : 'disconnected') : 'disabled'
  };
}

http.createServer((req, res) => {
  if (req.method === 'OPTIONS') return sendText(res, 204, '');
  const url = new URL(req.url, `http://${req.headers.host}`);
  (async () => {
    if (url.pathname === '/health') return sendJson(res, 200, { ok:true, build:'FULL-REBUILD-20260415', port:PORT, channelsDvrUrl: loadSettings().channelsDvr.serverUrl, playbackMode: loadSettings().channelsDvr.playbackMode, profilesEnabled: loadSettings().profiles.enabled, cacheEnabled: loadSettings().cache.enabled, prewarmEverythingOnBoot: loadSettings().performance.prewarmEverythingOnBoot });
    if (url.pathname === '/api/settings' && req.method === 'GET') return sendJson(res, 200, { ok:true, settings: loadSettings() });
    if (url.pathname === '/api/settings' && req.method === 'POST') {
      let raw=''; req.on('data', c => raw += c.toString());
      req.on('end', () => {
        try {
          const incoming = JSON.parse(raw || '{}');
          const next = deepMerge(loadSettings(), incoming);
          saveSettings(next);
          sendJson(res, 200, { ok:true, settings: next });
        } catch (e) { sendJson(res, 400, { ok:false, error: e.message }); }
      });
      return;
    }
    if (url.pathname === '/api/profile/state') {
      const s = loadSettings();
      const auto = s.profiles.enabled && s.profiles.alwaysUseSameProfile && !!(s.profiles.defaultProfile || s.profiles.lastProfile);
      return sendJson(res, 200, { ok:true, profilesEnabled:s.profiles.enabled, askWhosWatchingOnStartup:s.profiles.askWhosWatchingOnStartup, alwaysUseSameProfile:s.profiles.alwaysUseSameProfile, defaultProfile:s.profiles.defaultProfile, lastProfile:s.profiles.lastProfile, autoLoginProfile:auto ? (s.profiles.defaultProfile || s.profiles.lastProfile) : '' });
    }
    if (url.pathname === '/api/cache/status') return sendJson(res, 200, { ok:true, settings: loadSettings().cache, stats: { playbackEntries: Object.keys(loadPlaybackCache()).length, imageFiles: fs.readdirSync(path.join(CACHE_DIR,'images')).length, metadataFiles: fs.readdirSync(path.join(CACHE_DIR,'metadata')).length } });
    if (url.pathname === '/api/performance/status') return sendJson(res, 200, { ok:true, settings: loadSettings().performance, cache: loadSettings().cache, warmState: loadWarm(), usage: loadUsage(), resume: loadResume() });
    if (url.pathname === '/api/instant-playback/status') return sendJson(res, 200, { ok:true, enabled:true, focusPrefetch:true, skeletons:true, fallbackRows:true, retryPipeline:true, playbackCacheEntries:Object.keys(loadPlaybackCache()).length });
    if (url.pathname === '/api/performance/warm' && req.method === 'POST') return sendJson(res, 200, { ok:true, warmed: await warmStartup() });
    if (url.pathname === '/api/resume/state') return sendJson(res, 200, { ok:true, ...loadResume() });
    if (url.pathname === '/api/resume/update' && req.method === 'POST') {
      let raw=''; req.on('data', c => raw += c.toString());
      req.on('end', () => {
        try {
          const incoming = JSON.parse(raw || '{}'), s = loadSettings(), store = loadResume();
          const item = { id:safe(incoming.id), type:safe(incoming.type || 'video'), title:safe(incoming.title), poster:safe(incoming.poster), positionSeconds:Number(incoming.positionSeconds || 0), durationSeconds:Number(incoming.durationSeconds || 0), profile:safe(incoming.profile || s.profiles.lastProfile || s.profiles.defaultProfile), updatedAt:Date.now() };
          store.items = (store.items || []).filter(x => !(x.id === item.id && x.profile === item.profile));
          if (item.id) store.items.unshift(item);
          store.items = store.items.slice(0, s.resume.keepRecentItems || 200);
          saveResume(store);
          sendJson(res, 200, { ok:true, item });
        } catch (e) { sendJson(res, 400, { ok:false, error:e.message }); }
      });
      return;
    }
    if (url.pathname === '/api/smart-home/status') return sendJson(res, 200, { ok:true, settings: loadSettings().smartHome, usageTracked: Object.keys(loadUsage().channels || {}).length, resumeItems: (loadResume().items || []).length, intelligentHomeRows:['recommendedForYou','becauseYouWatched','trendingNow','recentlyAdded'] });
    if (url.pathname === '/api/ambient-lighting/status') {
      const s = loadSettings();
      return sendJson(res, 200, { ok:true, settings: s.ambientLighting || {}, note:'Controls and hooks ready. Real-time Govee sync transport not yet wired in this build.' });
    }
    if (url.pathname === '/api/frame-rate/status') {
      const s = loadSettings();
      return sendJson(res, 200, { ok:true, settings: s.frameRateMatching || {}, note:'Playback frame-rate matching preferences ready for player integration.' });
    }
    if (url.pathname === '/api/tmdb/status') {
      const s = loadSettings();
      return sendJson(res, 200, { ok:true, settings: { enabled: !!s.tmdb?.enabled, apiKeyConfigured: !!safe(s.tmdb?.apiKey), language: s.tmdb?.language || 'en-US' } });
    }

    if (url.pathname === '/api/ambient-lighting/test' && req.method === 'POST') {
      const s = loadSettings();
      const cfg = s.ambientLighting || {};
      const enabled = !!cfg.enabled;
      if (!enabled) return sendJson(res, 200, { ok:true, enabled:false, note:'Ambient lighting disabled in settings.' });
      const mode = safe(cfg.transport || 'lan').toLowerCase();
      if (mode !== 'lan') return sendJson(res, 200, { ok:true, enabled:true, transport:mode, note:'Transport hook saved. Direct LAN probe is only attempted for LAN mode in this build.' });
      const ip = safe(cfg.deviceIp);
      if (!ip) return sendJson(res, 400, { ok:false, error:'Missing device IP in Ambient Lighting settings.' });
      try {
        const probe = await fetch(`http://${ip}:4003/dev`, { method:'GET' });
        return sendJson(res, 200, { ok: probe.ok, enabled:true, transport:'lan', ip, status: probe.status, note: probe.ok ? 'LAN endpoint reachable.' : 'LAN endpoint did not confirm. Device may require LAN control enabled in Govee app.' });
      } catch (e) {
        return sendJson(res, 200, { ok:false, enabled:true, transport:'lan', ip, error:String(e.message || e), note:'Unable to reach LAN endpoint. Check IP, network, and Govee LAN Control.' });
      }
    }
    if (url.pathname === '/api/ambient-lighting/scene' && req.method === 'POST') {
      let raw=''; req.on('data', c => raw += c.toString());
      req.on('end', async () => {
        try{
          const body = JSON.parse(raw || '{}');
          const s = loadSettings();
          const cfg = s.ambientLighting || {};
          const transport = safe(cfg.transport || 'lan').toLowerCase();
          const title = safe(body.title || body.sceneName || cfg.sceneName || 'Movie Night');
          const color = body.color && typeof body.color === 'object' ? body.color : colorFromTitle(title);
          if (transport !== 'lan') return sendJson(res, 200, { ok:true, transport, scene:title, color, note:'Scene intent recorded. Non-LAN transport is saved for future implementation.' });
          const ip = safe(cfg.deviceIp);
          if (!ip) return sendJson(res, 400, { ok:false, error:'Missing device IP in Ambient Lighting settings.' });
          const brightness = Math.max(1, Math.min(100, Number(cfg.brightnessPercent || 70)));
          const cmd = {
            msg: {
              cmd: 'colorwc',
              data: { color: { r: color.r, g: color.g, b: color.b }, colorTemInKelvin: 0 }
            }
          };
          const result = await postJson(`http://${ip}:4003/`, cmd);
          return sendJson(res, 200, { ok: result.ok, transport:'lan', scene:title, color, brightness, deviceIp:ip, result: result.data, note: result.ok ? 'LAN color scene command sent.' : 'Scene command failed or device rejected it.' });
        } catch(e){ return sendJson(res, 400, { ok:false, error:String(e.message || e) }); }
      });
      return;
    }

    if (url.pathname === '/api/ambient-lighting/zones' && req.method === 'POST') {
      let raw=''; req.on('data', c => raw += c.toString());
      req.on('end', async () => {
        try{
          const body = JSON.parse(raw || '{}');
          const s = loadSettings();
          const cfg = s.ambientLighting || {};
          const transport = safe(cfg.transport || 'lan').toLowerCase();
          const zones = body.zones && typeof body.zones === 'object' ? body.zones : {};
          const names = Object.keys(zones);
          if (!names.length) return sendJson(res, 400, { ok:false, error:'Missing zones payload.' });

          if (transport !== 'lan') {
            return sendJson(res, 200, {
              ok:true,
              transport,
              zones,
              note:'Zone payload captured. Non-LAN transport remains a future implementation path.'
            });
          }

          const ip = safe(cfg.deviceIp);
          if (!ip) return sendJson(res, 400, { ok:false, error:'Missing device IP in Ambient Lighting settings.' });

          // First-pass compatibility: average all zones into one color for single-device Govee LAN command.
          let r=0, g=0, b=0, count=0;
          for (const z of names){
            const c = zones[z] || {};
            r += Number(c.r || 0);
            g += Number(c.g || 0);
            b += Number(c.b || 0);
            count++;
          }
          const avg = {
            r: Math.max(0, Math.min(255, Math.round(r / Math.max(1, count)))),
            g: Math.max(0, Math.min(255, Math.round(g / Math.max(1, count)))),
            b: Math.max(0, Math.min(255, Math.round(b / Math.max(1, count))))
          };

          const cmd = {
            msg: {
              cmd: 'colorwc',
              data: { color: avg, colorTemInKelvin: 0 }
            }
          };
          const result = await postJson(`http://${ip}:4003/`, cmd);
          return sendJson(res, 200, {
            ok: result.ok,
            transport:'lan',
            deviceIp:ip,
            zones,
            averagedColor: avg,
            result: result.data,
            note: result.ok
              ? 'Multi-zone payload processed. This build averages zones into one LAN color command for compatible single-zone devices.'
              : 'Zone command failed or device rejected it.'
          });
        } catch(e){ return sendJson(res, 400, { ok:false, error:String(e.message || e) }); }
      });
      return;
    }

    if (url.pathname === '/api/frame-rate/apply' && req.method === 'POST') {
      const s = loadSettings();
      const cfg = s.frameRateMatching || {};
      return sendJson(res, 200, {
        ok:true,
        settings: cfg,
        note:'Frame-rate matching preferences saved. Actual display mode switching must be implemented in the Android TV playback client, not the browser shell.',
        recommendedAction: cfg.enabled ? `Player should prefer ${cfg.preferContentFrameRate ? 'content-native frame rate' : (cfg.fallbackHz || 60) + 'Hz fallback'}.` : 'Keep current output mode.'
      });
    }

    
    if (url.pathname === '/api/iptv/test' && req.method === 'POST') {
      let raw=''; req.on('data', c => raw += c.toString());
      req.on('end', async () => {
        try{
          const s = loadSettings();
          const iptv = s.iptv || {};
          const xtream = iptv.xtream || {};
          const summary = {
            iptvEnabled: !!iptv.enabled,
            xtreamEnabled: !!xtream.enabled,
            hasSourcesText: !!safe(iptv.sourcesText),
            xtreamConfigured: !!(safe(xtream.server) && safe(xtream.username) && safe(xtream.password))
          };
          let probe = null;
          if (summary.xtreamConfigured) {
            const serverUrl = safe(xtream.server).replace(/\/$/, '');
            const candidates = [
              `${serverUrl}/player_api.php?username=${encodeURIComponent(safe(xtream.username))}&password=${encodeURIComponent(safe(xtream.password))}`,
              `${serverUrl}/panel_api.php?username=${encodeURIComponent(safe(xtream.username))}&password=${encodeURIComponent(safe(xtream.password))}`
            ];
            for (const url of candidates) {
              try {
                const res = await fetch(url);
                probe = { url, ok: res.ok, status: res.status };
                if (res.ok) break;
              } catch (e) {
                probe = { url, ok:false, error:String(e.message || e) };
              }
            }
          }
          return sendJson(res, 200, { ok:true, summary, probe, note:'This checks config presence and probes a common Xtream API endpoint when configured.' });
        }catch(e){ return sendJson(res, 400, { ok:false, error:String(e.message || e) }); }
      });
      return;
    }

    if (url.pathname === '/api/services/status') return sendJson(res, 200, { ok:true, services: normalizedServices() });
    if (url.pathname === '/api/catalog/home' || url.pathname === '/api/dashboard') return sendJson(res, 200, { ok:true, rows: await buildHomeRows() });
    if (url.pathname === '/api/playback/mock') {
      const title = safe(url.searchParams.get('title')) || 'Now Playing';
      return sendJson(res, 200, {
        ok:true,
        title,
        playback:{
          preferred:{
            url:`https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4`,
            format:'mp4',
            player:'media3'
          }
        },
        metadata:{ source:'mock', note:'Fallback playback stub for native player testing.' }
      });
    }
    if (url.pathname === '/api/catalog/search') {
      const q = safe(url.searchParams.get('q')).toLowerCase();
      const pool = [{id:'m1', title:'Popular Movie 1'}, {id:'m2', title:'Trending Movie 1'}, {id:'s1', title:'Popular Show 1'}];
      return sendJson(res, 200, { ok:true, query:q, results: pool.filter(v => v.title.toLowerCase().includes(q)) });
    }
    if (url.pathname === '/api/tv/channels-dvr/channels') {
      const [rawChannels, rawGuide] = await Promise.all([getChannels(), getGuide()]);
      return sendJson(res, 200, { ok:true, items: mapChannels(rawChannels, rawGuide) });
    }
    if (url.pathname.startsWith('/api/playback/live/channels-dvr/')) {
      const wanted = decodeURIComponent(url.pathname.split('/').pop() || '');
      const [rawChannels, rawGuide] = await Promise.all([getChannels(), getGuide()]);
      const raw = rawChannels.find(c => safe(c.ID || c.id || c.GuideNumber || c.number || c.Number || c.callsign || c.CallSign || c.GuideName) === wanted);
      if (!raw) return sendJson(res, 404, { ok:false, error:'Channel not found', wanted });
      const mapped = mapChannels([raw], rawGuide)[0];
      const resolved = await resolvePlayback(raw);
      if (!resolved.directUrl) return sendJson(res, 404, { ok:false, error:'No working direct playback URL found', wanted });
      bumpChannelUsage(mapped.playbackId);
      return sendJson(res, 200, { ok:true, type:'live_tv', title:mapped?.title || mapped?.channel || wanted, playback:{ preferred:{ url:resolved.directUrl, proxyUrl:`/api/proxy/file?url=${encodeURIComponent(resolved.directUrl)}`, format:resolved.directUrl.includes('.m3u8') ? 'hls' : 'mpeg_ts', player:'media3' }, fallbacks:[] }, metadata:{ channelNumber:mapped?.number || '', deviceName:mapped?.deviceName || '', playbackId:mapped?.playbackId || wanted, fromCache:resolved.fromCache } });
    }
    if (url.pathname === '/api/proxy/file') {
      const raw = url.searchParams.get('url');
      if (!raw) return sendJson(res, 400, { ok:false, error:'Missing url' });
      const upstream = await fetch(raw);
      const ct = upstream.headers.get('content-type') || 'application/octet-stream';
      const ab = await upstream.arrayBuffer();
      return sendText(res, upstream.status, Buffer.from(ab), ct);
    }
    if (url.pathname === '/' || url.pathname === '/app') return serveFile(res, path.join(PUBLIC_DIR, 'index.html'));
    return sendJson(res, 404, { ok:false, error:'Not found' });
  })().catch(e => sendJson(res, 500, { ok:false, error:e.message }));
}).listen(PORT, '0.0.0.0', () => console.log(`ChannelsDebrid full rebuild listening on http://0.0.0.0:${PORT}`));
