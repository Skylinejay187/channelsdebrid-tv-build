rootProject.name = "ChannelsDebridTV"
include(":app")
