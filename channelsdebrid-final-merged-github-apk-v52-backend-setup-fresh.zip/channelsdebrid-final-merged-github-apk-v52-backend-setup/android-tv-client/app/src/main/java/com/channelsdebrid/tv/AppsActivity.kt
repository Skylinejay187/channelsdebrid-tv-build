package com.channelsdebrid.tv

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AppsActivity : AppCompatActivity() {

    data class AppEntry(
        val label: String,
        val packageName: String,
        val activityName: String,
        val icon: Drawable?
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        }

        val apps = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .map {
                AppEntry(
                    label = it.loadLabel(pm).toString(),
                    packageName = it.activityInfo.packageName,
                    activityName = it.activityInfo.name,
                    icon = it.loadIcon(pm)
                )
            }
            .sortedBy { it.label.lowercase() }

        val grid = GridView(this).apply {
            numColumns = 4
            horizontalSpacing = dp(18)
            verticalSpacing = dp(18)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            clipToPadding = false
            setPadding(dp(28), dp(28), dp(28), dp(28))
            setBackgroundColor(Color.parseColor("#05070C"))
            selector = android.R.color.transparent
            adapter = AppsAdapter(apps)
            isFocusable = true
            isFocusableInTouchMode = true
        }

        grid.setOnItemClickListener { _, _, position, _ ->
            val app = apps[position]
            val launch = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
                setClassName(app.packageName, app.activityName)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(launch)
        }

        setContentView(grid)
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    inner class AppsAdapter(private val items: List<AppEntry>) : BaseAdapter() {
        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val context = this@AppsActivity
            val entry = items[position]

            val root = if (convertView == null) {
                LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    setPadding(dp(14), dp(14), dp(14), dp(14))
                    setBackgroundColor(Color.parseColor("#141923"))
                    layoutParams = GridView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(210))
                    isFocusable = true
                    isClickable = true
                }
            } else convertView as LinearLayout

            root.removeAllViews()

            val icon = ImageView(context).apply {
                layoutParams = LinearLayout.LayoutParams(dp(84), dp(84))
                setImageDrawable(entry.icon)
            }

            val label = TextView(context).apply {
                text = entry.label
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                gravity = Gravity.CENTER
                maxLines = 2
                setPadding(0, dp(12), 0, 0)
            }

            root.addView(icon)
            root.addView(label)

            root.setOnFocusChangeListener { v, hasFocus ->
                v.scaleX = if (hasFocus) 1.06f else 1.0f
                v.scaleY = if (hasFocus) 1.06f else 1.0f
                v.alpha = if (hasFocus) 1.0f else 0.96f
            }

            return root
        }
    }
}
