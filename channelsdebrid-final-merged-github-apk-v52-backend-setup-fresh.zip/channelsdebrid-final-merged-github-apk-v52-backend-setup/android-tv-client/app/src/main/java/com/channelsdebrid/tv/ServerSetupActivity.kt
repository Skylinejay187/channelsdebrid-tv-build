package com.channelsdebrid.tv

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.URL
import kotlin.concurrent.thread

class ServerSetupActivity : AppCompatActivity() {

    private lateinit var urlInput: EditText
    private lateinit var statusText: TextView

    private fun prefs() = getSharedPreferences("channelsdebrid_prefs", MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_server_setup)

        urlInput = findViewById(R.id.backendUrlInput)
        statusText = findViewById(R.id.serverStatus)

        val saved = prefs().getString("backend_url", "http://192.168.100.55:8418/app")
        urlInput.setText(saved)

        findViewById<Button>(R.id.saveServerBtn).setOnClickListener {
            val url = normalize(urlInput.text.toString())
            prefs().edit().putString("backend_url", url).apply()
            openHome()
        }

        findViewById<Button>(R.id.testServerBtn).setOnClickListener {
            val url = normalize(urlInput.text.toString())
            statusText.text = "Testing…"
            thread {
                val ok = probe(url)
                runOnUiThread {
                    statusText.text = if (ok) "Server reachable." else "Server not reachable."
                }
            }
        }

        findViewById<Button>(R.id.autoDetectBtn).setOnClickListener {
            statusText.text = "Scanning local network…"
            thread {
                val detected = autoDetect()
                runOnUiThread {
                    if (detected != null) {
                        urlInput.setText(detected)
                        statusText.text = "Found backend."
                    } else {
                        statusText.text = "No backend found automatically."
                    }
                }
            }
        }
    }

    private fun normalize(raw: String): String {
        var url = raw.trim()
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "http://$url"
        if (!url.endsWith("/app")) url = url.trimEnd('/') + "/app"
        return url
    }

    private fun probe(appUrl: String): Boolean {
        return try {
            val base = appUrl.removeSuffix("/app")
            val conn = URL("$base/health").openConnection() as HttpURLConnection
            conn.connectTimeout = 1200
            conn.readTimeout = 1200
            conn.requestMethod = "GET"
            conn.responseCode in 200..299
        } catch (_: Exception) {
            false
        }
    }

    private fun autoDetect(): String? {
        val prefix = localPrefix() ?: return null
        for (i in 1..254) {
            val candidate = "http://$prefix.$i:8418/app"
            if (probe(candidate)) return candidate
        }
        return null
    }

    private fun localPrefix(): String? {
        return try {
            val interfaces = NetworkInterface.getNetworkInterfaces().toList()
            for (iface in interfaces) {
                for (addr in iface.inetAddresses) {
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        val host = addr.hostAddress ?: continue
                        val parts = host.split(".")
                        if (parts.size == 4) return parts.take(3).joinToString(".")
                    }
                }
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun openHome() {
        startActivity(Intent(this, HomeActivity::class.java).apply {
            putExtra("startupMode", "app")
        })
        finish()
    }
}
