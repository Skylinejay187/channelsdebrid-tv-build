package com.channelsdebrid.tv

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private fun prefs(): SharedPreferences =
        getSharedPreferences("channelsdebrid_prefs", MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        Handler(Looper.getMainLooper()).postDelayed({
            val saved = prefs().getString("backend_url", null)
            val target = if (saved.isNullOrBlank()) ServerSetupActivity::class.java else HomeActivity::class.java
            startActivity(Intent(this, target).apply {
                putExtra("startupMode", "app")
            })
            finish()
        }, 350)
    }
}
