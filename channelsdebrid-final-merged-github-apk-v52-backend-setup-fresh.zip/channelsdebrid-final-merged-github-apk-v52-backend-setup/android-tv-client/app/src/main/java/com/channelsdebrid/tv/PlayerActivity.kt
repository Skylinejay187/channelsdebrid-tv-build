package com.channelsdebrid.tv

import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var titleText: TextView
    private lateinit var metaText: TextView
    private lateinit var controlsHint: TextView
    private lateinit var trackHint: TextView

    private var resumeMs: Long = 0L
    private var hintVisible = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        playerView = findViewById(R.id.playerView)
        titleText = findViewById(R.id.titleText)
        metaText = findViewById(R.id.metaText)
        controlsHint = findViewById(R.id.controlsHint)
        trackHint = findViewById(R.id.trackHint)

        val title = intent.getStringExtra(EXTRA_TITLE) ?: "Native Player"
        val url = intent.getStringExtra(EXTRA_URL) ?: ""
        val subtitle = intent.getStringExtra(EXTRA_META) ?: "Media3 / ExoPlayer playback"
        resumeMs = intent.getLongExtra(EXTRA_RESUME_MS, 0L)

        titleText.text = title
        metaText.text = subtitle
        controlsHint.text = "DPAD center: play/pause • Left/Right: seek 10s • Up/Down: show controls"
        trackHint.text = "Subtitles/audio selection scaffold ready for next pass"

        if (url.isNotBlank()) {
            initializePlayer(url, title)
        } else {
            metaText.text = "No playback URL supplied. Launch PlayerActivity with EXTRA_URL."
        }
    }

    private fun initializePlayer(url: String, title: String) {
        val exoPlayer = ExoPlayer.Builder(this).build()
        player = exoPlayer
        playerView.player = exoPlayer

        val mediaItem = MediaItem.Builder()
            .setUri(Uri.parse(url))
            .setMediaId(title)
            .build()

        exoPlayer.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                metaText.text = when (playbackState) {
                    Player.STATE_BUFFERING -> "Buffering…"
                    Player.STATE_READY -> if (resumeMs > 0L) "Playing in native Media3 player • resumed" else "Playing in native Media3 player"
                    Player.STATE_ENDED -> "Playback ended"
                    else -> metaText.text
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                metaText.text = "Playback error: ${error.errorCodeName}"
            }

            override fun onTracksChanged(tracks: Player.Tracks) {
                val hasText = tracks.groups.any { it.type == C.TRACK_TYPE_TEXT }
                val hasAudio = tracks.groups.any { it.type == C.TRACK_TYPE_AUDIO }
                trackHint.text = buildString {
                    append("Audio: ")
                    append(if (hasAudio) "available" else "none")
                    append(" • Subtitles: ")
                    append(if (hasText) "available" else "none")
                }
            }
        })

        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        if (resumeMs > 0L) exoPlayer.seekTo(resumeMs)
        exoPlayer.playWhenReady = true
    }

    private fun toggleOverlay(forceShow: Boolean? = null) {
        hintVisible = forceShow ?: !hintVisible
        val visibility = if (hintVisible) View.VISIBLE else View.GONE
        titleText.parent?.let { (it as View).visibility = visibility }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val p = player ?: return super.onKeyDown(keyCode, event)
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                if (p.isPlaying) p.pause() else p.play()
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                p.seekTo((p.currentPosition - 10_000).coerceAtLeast(0))
                return true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                p.seekTo(p.currentPosition + 10_000)
                return true
            }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> {
                toggleOverlay()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onStart() {
        super.onStart()
        player?.playWhenReady = true
    }

    override fun onStop() {
        player?.playWhenReady = false
        super.onStop()
    }

    override fun onDestroy() {
        playerView.player = null
        player?.release()
        player = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_URL = "extra_url"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_META = "extra_meta"
        const val EXTRA_RESUME_MS = "extra_resume_ms"
    }
}
