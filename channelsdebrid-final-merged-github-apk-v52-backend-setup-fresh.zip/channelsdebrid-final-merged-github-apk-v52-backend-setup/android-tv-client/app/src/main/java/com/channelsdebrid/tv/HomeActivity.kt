package com.channelsdebrid.tv

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedReader
import java.io.InputStreamReader
import org.json.JSONObject

class HomeActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var lastBackPressAt: Long = 0L

    private fun loadBackendUrl(): String {
        return try {
            val inputStream = assets.open("config.json")
            val reader = BufferedReader(InputStreamReader(inputStream))
            val json = reader.readText()
            val obj = JSONObject(json)
            obj.getString("backendUrl")
        } catch (e: Exception) {
            "http://localhost:8418/app"
        }
    }

    private inner class NativeBridge : Any() {
        @JavascriptInterface
        fun openAllApps() {
            runOnUiThread {
                startActivity(Intent(this@HomeActivity, AppsActivity::class.java))
            }
        }

        fun openPlayer(url: String, title: String?, meta: String?) {
            runOnUiThread {
                val intent = Intent(this@HomeActivity, PlayerActivity::class.java).apply {
                    putExtra(PlayerActivity.EXTRA_URL, url)
                    putExtra(PlayerActivity.EXTRA_TITLE, title ?: "Now Playing")
                    putExtra(PlayerActivity.EXTRA_META, meta ?: "Opened from web shell")
                }
                startActivity(intent)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val launcherMode = intent?.categories?.contains("android.intent.category.HOME") == true ||
            intent?.getStringExtra("startupMode") == "launcher"
        val backendUrl = loadBackendUrl()

        webView = WebView(this)
        webView.setBackgroundColor(Color.BLACK)
        webView.alpha = 0f
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.settings.loadsImagesAutomatically = true
        webView.settings.setSupportZoom(false)
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(NativeBridge(), "ChannelsDebridNative")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                webView.animate().alpha(1f).setDuration(180).start()
                super.onPageFinished(view, url)
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString().orEmpty()

                if (url.contains("/api/playback/") || url.contains("/api/playback/live/") || url.startsWith("https://commondatastorage.googleapis.com/") || url.endsWith(".m3u8") || url.endsWith(".mp4")) {
                    val intent = Intent(this@HomeActivity, PlayerActivity::class.java).apply {
                        putExtra(PlayerActivity.EXTRA_URL, url)
                        putExtra(PlayerActivity.EXTRA_TITLE, "Now Playing")
                        putExtra(PlayerActivity.EXTRA_META, "Opened from backend playback route")
                    }
                    startActivity(intent)
                    return true
                }

                if (url.startsWith("channelsdebrid-player://")) {
                    val target = request?.url
                    val streamUrl = target?.getQueryParameter("url").orEmpty()
                    val title = target?.getQueryParameter("title")
                    val meta = target?.getQueryParameter("meta")
                    val resumeMs = target?.getQueryParameter("resumeMs")?.toLongOrNull() ?: 0L
                    if (streamUrl.isNotBlank()) {
                        val intent = Intent(this@HomeActivity, PlayerActivity::class.java).apply {
                            putExtra(PlayerActivity.EXTRA_URL, streamUrl)
                            putExtra(PlayerActivity.EXTRA_TITLE, title ?: "Now Playing")
                            putExtra(PlayerActivity.EXTRA_META, meta ?: "Opened from deep link")
                            putExtra(PlayerActivity.EXTRA_RESUME_MS, resumeMs)
                        }
                        startActivity(intent)
                        return true
                    }
                }
                return false
            }
        }

        val startupUrl = backendUrl // future: preload + widgets hook + if (launcherMode) "" else ""
        webView.loadUrl(startupUrl)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Keep lean-back navigation responsive inside the WebView shell.
        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP,
            KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT,
            KeyEvent.KEYCODE_DPAD_RIGHT,
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER -> {
                super.onKeyDown(keyCode, event)
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    override fun onBackPressed() {
        val isLauncher = intent?.categories?.contains("android.intent.category.HOME") == true
        if (isLauncher) {
            // Block exit when acting as launcher
            return
        }
        if (webView.canGoBack()) {
            webView.goBack()
            return
        }

        val now = System.currentTimeMillis()
        if (now - lastBackPressAt < 1200L) {
            super.onBackPressed()
        } else {
            lastBackPressAt = now
            // Soft no-op first back press at root to reduce accidental exits on TV remotes.
        }
    }
}
