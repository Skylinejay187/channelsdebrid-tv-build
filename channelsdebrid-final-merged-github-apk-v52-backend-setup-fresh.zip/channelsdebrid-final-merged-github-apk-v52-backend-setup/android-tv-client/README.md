# ChannelsDebrid Android TV Client Shell

This is a starter Android TV client shell intended to wrap the existing backend/app behavior into a native Android TV app structure.

## Included
- MainActivity launcher
- HomeActivity WebView shell
- PlayerActivity placeholder
- SettingsActivity placeholder
- AndroidManifest
- minimal Gradle settings
- TV theme/resources

## Expected backend
Point the app at your running backend, for example:
- `http://YOUR-NAS-IP:8418/app`

## Next implementation steps
1. Replace the placeholder WebView shell with full TV navigation/state bridge.
2. Wire PlayerActivity to ExoPlayer / Media3.
3. Add frame-rate matching hooks in PlayerActivity.
4. Add ambient lighting calls from playback events.
5. Add remote-control focus memory and back-stack polish.

## Honest status
This is a starter client shell, not a finished APK.


## GitHub Actions APK build
This project now includes `.github/workflows/build-apk.yml`.

When you upload this repo to GitHub:
1. GitHub Actions will run automatically on pushes affecting `android-tv-client/**`
2. You can also run it manually from the **Actions** tab
3. When it finishes, download the APK from the workflow **Artifacts**

## First-time setup notes
- This workflow builds a **debug APK**
- Debug APKs are fine for sideload testing on Android TV / Google TV
- For a release APK later, add app signing
