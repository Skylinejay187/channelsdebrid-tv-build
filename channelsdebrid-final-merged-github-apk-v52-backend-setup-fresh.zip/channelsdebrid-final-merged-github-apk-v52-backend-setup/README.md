# ChannelsDebrid Full Rebuild

This is a full rebuilt package with:
- stable `/api/settings` saves
- independent dashboard loading
- normalized green/red/gray status chips
- Channels DVR, Debrid, Smart Home, TMDB, Profiles, Cache, GPU
- real home rows and artwork-aware cards

Run:
```bash
cd channelsdebrid-full-rebuild-v2
docker compose down --remove-orphans
docker compose build --no-cache
docker compose up -d --force-recreate
```

Verify:
- `/health` shows `FULL-REBUILD-20260415`
- settings persist in `data/settings.json`


Arvio-look pass:
- More cinematic hero layout.
- Larger TV-style cards and spotlight strip.
- Styling moved closer to a premium Android TV app feel.


TV polish pass:
- Larger home cards and stronger header hierarchy.
- Added hero stats and cleaner row presentation.
- Added source corner badges for quicker scanning.


Android TV shell pass:
- Added top-right weather/time area.
- Added right-side pop-up information panel with toggles.
- Added full-screen cinematic Android TV shell matching the mockup direction more closely.


TV focus/navigation pass:
- Added DPAD-style focus movement.
- Added pop-up information panel linked to focused item.
- Added toast feedback and stronger TV-style focus rings.


V7 null-safe dashboard fix:
- Fixed refreshDashboard crash when Android TV layout removes old dashboard chip containers.
- Added null checks before any innerHTML/textContent writes.


V8 settings drawer fix:
- Restored all missing settings fields.
- Moved full settings editor into a right-side TV-style drawer.
- Keeps Android TV home shell while preserving unified settings editing.


V9 exact-look pass:
- Tightened spacing and hierarchy to better match the provided reference.
- Added more accurate overlay chips, runtime badges, and muted glass styling.
- Refined top bar weather/time presentation and card composition.


V10 one-to-one polish:
- Tightened layout proportions to more closely match the provided Android TV reference.
- Refined top bar, hero sizing, card widths, and side glass panel.
- Improved row density and badge styling for a closer visual match.


V11 final visual tuning:
- Tightened proportions again for a closer one-to-one match.
- Refined card density, hero text scale, and side-panel spacing.
- Cleaned branding/runtime overlays for a more exact screenshot feel.


V12 micro-detail pass:
- Adjusted typography and spacing at a smaller-detail level.
- Tuned row density and card sizing one more step.
- Refined chips, metadata, and top-bar presentation.


V14 deeper network UI:
- Added signal bars for WiFi-like display.
- Added LAN icon fallback.
- Added live speed/downlink text and RTT latency when browser exposes it.


V16 native-level network icon:
- Replaced emoji WiFi/LAN with inline vector-style icons.
- Tuned spacing and opacity to feel closer to native TV UI.


V17 native status cluster pass:
- Removed pill styling from top-right cluster for a truer native TV look.
- Tightened icon/text sizing and separator opacity.
- Auto-hides speed text when unavailable.


V19 cinematic pass:
- Added cinematic grain, vignette, and glow layers.
- Increased depth and focus bloom on cards and panels.
- Refined hero presentation toward a premium streaming platform feel.


V20 permanent pipeline fix:
- Fixed the recursive clock bug that could stop the page from hydrating.
- Added /api/dashboard alias.
- Added retry-based home loading, fallback rows, and skeleton placeholders.
- Added safer boot flow so one failed fetch no longer blanks the home surface.


V22 intelligent home:
- Added Because You Watched, Trending Now, and Recently Added row generation.
- Added smart summary counters under the hero.
- Updated hidden/fallback home rows so the experience feels more like a real streaming platform.


V23 instant playback:
- Added focus-based prefetch indicators on home cards.
- Added instant playback status ribbon under the hero.
- Added backend status endpoint for playback cache visibility.


V24 trailers restored:
- Restored Trailers settings in the settings drawer.
- Added focus-triggered half-screen centered trailer popup behavior.
- Popup respects enabled, popupEnabled, mutePreview, mode, and delayMs settings.


V25 YouTube trailers:
- Upgraded trailer popup to a much larger centered cinematic window.
- Added YouTube trailer lookup and embed autoplay.
- Default trailer popup delay set to 4000ms.


V26 TMDB trailer source:
- Added trailer source setting: YouTube or TMDB-backed.
- TMDB-backed mode uses your TMDB API key to search the title, resolve videos, and play a YouTube-hosted trailer returned by TMDB.
- YouTube mode remains available as fallback/manual choice.


V27 TMDB trailer loading fix:
- Fixed duplicate JavaScript variable declaration that stopped the page from hydrating.
- Validated script syntax with node --check before packaging.


V28 cinematic trailers + new integrations:
- Added Ambient Lighting settings for Govee / Google Home style integration hooks.
- Added Frame Rate Matching settings for future playback switching integration.
- Trailer popup gets stronger cinematic dim/blur treatment and softer startup messaging.


V29 Govee LAN hooks:
- Added Ambient Lighting test and scene buttons.
- Added backend LAN probe and color scene endpoints for Govee-style devices.
- Added Frame Rate Apply test endpoint with explicit note that real display mode switching belongs in the Android TV client.


V30 focus ambient sync:
- Added focusSync and idleSceneName settings.
- Ambient scene commands now fire automatically from focused home cards when Ambient Lighting is enabled.
- Trailer popup triggers a warmer trailer scene, then returns to idle/browse after close.


V33 multi-zone lighting:
- Added multi-zone playback sync using left/center/right canvas sampling.
- Added zoneMode, zoneSmoothing, and zoneUpdateMs settings.
- Added backend zones endpoint. In this first pass, LAN output is averaged for compatible single-zone devices while preserving multi-zone payload structure.


V34 IPTV / Xtream restored:
- Restored IPTV settings section.
- Restored Xtream Codes server, username, and password fields.
- Added save handling for IPTV / Xtream config.


V35 IPTV / Xtream test tools:
- Added IPTV / Xtream test button in settings.
- Added backend probe for common Xtream API endpoints.
- Added status output panel for IPTV/Xtream diagnostics.


V37 Android TV client shell:
- Added a starter native Android TV client scaffold.
- Includes launcher, WebView-based home shell, and placeholder player/settings activities.
- Intended as the bridge into a real TV app packaging phase.


V40 native player scaffold:
- Replaced placeholder player with a real Media3 / ExoPlayer activity scaffold.
- Home shell now supports opening the native player via JS bridge or custom deep-link style URL.
- This is the correct base for real frame-rate matching, subtitles, audio tracks, and playback integration next.


V41 native player wired:
- Wired the hero Play button and row cards to launch the native player scaffold.
- Added helper JS bridge/fallback deep-link generation in the web shell.
- HomeActivity now intercepts backend playback routes more aggressively.


V42 full playback batch:
- Added stronger end-to-end playback handoff from web shell to native player.
- Backend home items now carry playUrl values.
- Frontend resolves backend playback routes before opening native playback.
- Native player scaffold now surfaces buffer/ready/error metadata more clearly.


V43 player polish batch:
- Added DPAD play/pause and seek controls in native player.
- Added resume timestamp support in PlayerActivity.
- Added clearer playback control hints in the player overlay.


V44 player controls batch:
- Added overlay toggle with DPAD up/down.
- Added resume timestamp passthrough in fallback deep links.
- Added live track availability hints for audio/subtitles.


V45 launcher mode:
- Added HOME / DEFAULT launcher intent filter to the Android TV client.
- HomeActivity can now be offered as a launcher on devices that allow launcher replacement.
- Added setup notes for trying ChannelsDebrid TV as the default launcher.


V46 startup polish batch:
- Added startup splash/router activity behavior.
- Home shell now fades in after page load to reduce WebView flash.
- Softened root back behavior for TV remotes.
- Polished launcher startup flow for app mode and launcher mode.


V47 true launcher:
- Blocks exit when acting as HOME launcher
- Auto-start on boot (BootReceiver)
- Foundation for full TV replacement experience


V48 final experience polish:
- Added Launcher Mode settings to the web settings drawer.
- Added configurable All Apps button for default-launcher use.
- Native Android TV client now exposes a simple installed-apps drawer via JS bridge.


V49 real launcher grid:
- Replaced the simple installed-apps list with a TV-style grid app drawer.
- Added focus scaling and larger app tiles for launcher use.
- Makes default-launcher mode much more practical for daily use.


V50 timeshift/cache restored:
- Restored Timeshift settings in the unified drawer.
- Restored Movie / Show Cache settings in the unified drawer.
- Added save/load handling for both blocks so they stop disappearing in later launcher builds.


V51 final merged zip:
- Latest current build line from v50.
- Includes Android TV client.
- Includes GitHub Actions APK builder.
- Includes config.json backend URL setup so you do not need to edit Kotlin.
- Includes simple GitHub upload/build instructions.


V52 backend setup in app:
- Added a native ServerSetupActivity.
- Lets the user type a backend URL in the app itself.
- Includes Test and Auto Detect buttons.
- Saved URL is stored in SharedPreferences and overrides config.json.
