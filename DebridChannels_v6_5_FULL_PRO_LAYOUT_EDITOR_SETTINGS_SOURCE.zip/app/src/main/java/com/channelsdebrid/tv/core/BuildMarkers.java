package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v6.5 FULL_PRO_LAYOUT_EDITOR_SETTINGS";
    public static final String LOG_MARKER = "DC_V6_5_FULL_PRO_LAYOUT_EDITOR_SETTINGS";
    private BuildMarkers() {}
}
