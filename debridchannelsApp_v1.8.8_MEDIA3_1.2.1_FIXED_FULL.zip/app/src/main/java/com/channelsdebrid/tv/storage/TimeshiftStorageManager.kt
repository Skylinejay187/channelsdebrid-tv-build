package com.channelsdebrid.tv.storage

import android.content.Context
import com.channelsdebrid.tv.settings.StorageSettings
import java.io.File
import java.util.UUID
import kotlin.math.min

/** Validates and resolves the storage target that app-timeshift uses. */
class TimeshiftStorageManager(private val context: Context) {
    fun status(storage: StorageSettings): String {
        return when (storage.preferredTarget.lowercase()) {
            "nas" -> validateNas(storage)
            "usb" -> validateLocalPath(storage.usbPath, "USB")
            else -> validateInternal()
        }
    }

    /**
     * ExoPlayer cache requires a real java.io.File. SMB folders are not a local filesystem on Android,
     * so NAS timeshift uses a local working buffer and mirrors the newest buffer chunks to SMB.
     */
    fun resolveLocalBufferDir(storage: StorageSettings): File {
        val base = when (storage.preferredTarget.lowercase()) {
            "usb" -> File(storage.usbPath.ifBlank { context.cacheDir.absolutePath }, "DebridChannels/timeshift")
            else -> File(context.cacheDir, "timeshift")
        }
        return base.apply { mkdirs() }
    }

    fun mirrorLocalBufferToNas(localDir: File, storage: StorageSettings): Boolean {
        if (storage.nasHost.isBlank() || storage.nasPath.isBlank() || storage.nasUsername.isBlank()) return false
        if (!localDir.exists() || !localDir.isDirectory) return false
        val browser = SmbNasBrowser(storage.nasHost, storage.nasUsername, storage.nasPassword)
        val files = localDir.walkTopDown()
            .filter { it.isFile && !it.name.startsWith(".") }
            .sortedByDescending { it.lastModified() }
            .take(12)
            .toList()
        var wroteAny = false
        files.forEach { file ->
            runCatching {
                val maxCopy = min(file.length(), 4L * 1024L * 1024L).toInt()
                if (maxCopy <= 0) return@forEach
                val bytes = file.inputStream().use { input ->
                    val buffer = ByteArray(maxCopy)
                    val read = input.read(buffer)
                    if (read <= 0) ByteArray(0) else buffer.copyOf(read)
                }
                if (bytes.isNotEmpty()) {
                    wroteAny = browser.writeFile(storage.nasPath, "timeshift_${file.name}", bytes) || wroteAny
                }
            }
        }
        val manifest = "Debrid Channels timeshift mirror\nupdatedAt=${System.currentTimeMillis()}\nfiles=${files.size}\n"
        browser.writeFile(storage.nasPath, "timeshift_session_manifest.txt", manifest.toByteArray())
        return wroteAny
    }

    private fun validateInternal(): String {
        val dir = File(context.cacheDir, "timeshift").apply { mkdirs() }
        return if (writeTest(dir)) "Timeshift storage ready: Internal" else "Internal timeshift storage is not writable"
    }

    private fun validateLocalPath(path: String, label: String): String {
        if (path.isBlank()) return "$label path is empty"
        val dir = File(path, "DebridChannels/timeshift").apply { mkdirs() }
        return if (writeTest(dir)) "Timeshift storage ready: $label" else "$label timeshift path is not writable"
    }

    private fun validateNas(storage: StorageSettings): String {
        if (storage.nasHost.isBlank() || storage.nasPath.isBlank()) return "NAS path is not locked yet"
        if (storage.nasUsername.isBlank()) return "NAS username is required"
        val browser = SmbNasBrowser(storage.nasHost, storage.nasUsername, storage.nasPassword)
        return if (browser.ensureWritable(storage.nasPath)) {
            "Timeshift storage ready: NAS ${storage.nasPath}"
        } else {
            "NAS login or write test failed. Check username/password and folder permissions."
        }
    }

    private fun writeTest(dir: File): Boolean = runCatching {
        val file = File(dir, ".debrid_channels_write_test_${UUID.randomUUID()}.tmp")
        file.writeText("ok")
        val ok = file.exists() && file.length() >= 2L
        file.delete()
        ok
    }.getOrDefault(false)
}
