import express from "express"
import { homeRouter } from "./routes/home"
import { adminRowsRouter } from "./routes/admin-rows"
import { CatalogManager } from "./catalog/catalog-manager"
import { InternalCatalogSource } from "./catalog/sources/internal-catalog-source"
import { StremioCatalogSource } from "./catalog/sources/stremio-catalog-source"
import { createTmdbClient } from "./catalog/providers/tmdb-client"
import { createAddonRegistry } from "./stremio/addon-registry"
import { trailersRouter } from "./routes/trailers"

export async function createApp() {
  const app = express()
  app.use(express.json())

  const tmdb = createTmdbClient(process.env.TMDB_API_KEY ?? "")
  const addonRegistry = createAddonRegistry()

  const catalogManager = new CatalogManager([
    new InternalCatalogSource(tmdb),
    new StremioCatalogSource(addonRegistry),
  ])

  app.use(homeRouter(catalogManager))
  app.use(adminRowsRouter())
  app.use((req, res, next) => {
    if (req.path === "/live" || req.path.startsWith("/live/") || req.path.startsWith("/api/live/")) {
      return res.status(410).json({
        ok: false,
        disabled: true,
        message: "Live TV provider handling moved to the Android app. Configure Channels DVR Direct, M3U, or Xtream/IPTV in app settings."
      })
    }
    return next()
  })
  app.use(trailersRouter())

  app.get("/health", (_req, res) => {
    res.json({ ok: true, service: "channels-debrid-foundation" })
  })

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, service: "channels-debrid-foundation" })
  })

  return app
}
