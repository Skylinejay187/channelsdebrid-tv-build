import { Router } from "express"

export function liveRouter() {
  const router = Router()
  router.use((_req, res) => {
    res.status(410).json({
      ok: false,
      disabled: true,
      message: "Live TV provider handling moved to the Android app. Configure Channels DVR Direct, M3U, or Xtream/IPTV in app settings."
    })
  })
  return router
}
