
package com.channelsdebrid.tv

import android.animation.Animator
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.graphics.Outline
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.channelsdebrid.tv.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    data class TitleCard(
        val title: String,
        val meta: String,
        val desc: String,
        val badge: String,
        val brand: String,
        val footer: String,
        val progress: Float,
        val backgroundRes: Int
    )

    private val heroTitles = listOf(
        TitleCard("SHŌGUN", "S1 E7: A Stick of Time  •  43 min left", "A premium lean-back presentation for your media center, with live TV, trending shows, smart recommendations, and instant playback.", "⚑  Instant Playback Ready", "FX", "43 min left", 0.58f, R.drawable.bg_shogun),
        TitleCard("THE BATMAN", "2h 56m  •  IMAX", "A darker detective spotlight with premium backdrop changes and clean TV-safe row alignment.", "⚑  Direct Play Ready", "PLEX", "IMAX", 0.42f, R.drawable.bg_batman),
        TitleCard("FALLOUT", "49 min left  •  Prime", "Post-apocalyptic action with large-format hero art and poster rows that stay locked in place.", "⚑  Synced to Library", "prime", "49 min left", 0.51f, R.drawable.bg_fallout),
        TitleCard("DUNE", "2h 35m  •  Max", "Expansive cinema-style focus treatment with large typography and backdrop-driven navigation.", "⚑  HDR Available", "max", "Featured", 0.46f, R.drawable.bg_dune),
        TitleCard("HALO", "Series  •  Prime", "Sci-fi recommendations rendered in the same composition language as your reference shot.", "⚑  Resume Synced", "prime", "Series", 0.33f, R.drawable.bg_halo),
        TitleCard("WONKA", "Movie  •  Max", "Bright contrast title art for spotlight and recently-added rows without breaking the layout grid.", "⚑  Trailer Ready", "max", "Movie", 0.37f, R.drawable.bg_wonka),
        TitleCard("MAYOR OF KINGSTOWN", "Series  •  Paramount+", "Grounded drama hero state with full-screen poster changes as focus moves across rows.", "⚑  Watched on Device", "P+", "Series", 0.28f, R.drawable.bg_mayor),
        TitleCard("CIVIL WAR", "Movie  •  109 min", "Poster rows line up under the hero so the screen still feels premium and intentional.", "⚑  Cache Eligible", "A24", "109 min", 0.22f, R.drawable.bg_civilwar),
        TitleCard("AVATAR", "Movie  •  Disney+", "High-contrast blockbuster art for the lower row examples and future trailer pop-up placement.", "⚑  Dolby Vision", "D+", "Featured", 0.48f, R.drawable.bg_avatar)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setHero(heroTitles[3])
        populateRows()
        wireTopControls()
        wireRowNavigation()
        binding.contentScroll.post {
            binding.contentScroll.scrollTo(0, 0)
            binding.continueButton.requestFocus()
            binding.contentScroll.post {
                binding.contentScroll.scrollTo(0, 0)
            }
        }
    }

    private fun wireTopControls() {
        val focusables = listOf(
            binding.menuButton,
            binding.homeButton,
            binding.navResume,
            binding.navSmart,
            binding.navLive,
            binding.navMovies,
            binding.continueButton,
            binding.settingsCard
        )

        focusables.forEach { v ->
            v.setOnFocusChangeListener { view, hasFocus ->
                view.animate().cancel()
                view.animate()
                    .scaleX(if (hasFocus) 1.05f else 1f)
                    .scaleY(if (hasFocus) 1.05f else 1f)
                    .alpha(if (hasFocus) 1f else 0.96f)
                    .setDuration(150)
                    .start()
            }
        }
    }


    private fun wireRowNavigation() {
        val rowOneCount = binding.rowOne.childCount
        val rowTwoCount = binding.rowTwo.childCount
        val pairCount = minOf(rowOneCount, rowTwoCount)

        for (i in 0 until pairCount) {
            val rowOneCard = binding.rowOne.getChildAt(i)
            val rowTwoCard = binding.rowTwo.getChildAt(i)
            rowOneCard.nextFocusDownId = rowTwoCard.id
            rowTwoCard.nextFocusUpId = rowOneCard.id
        }

        binding.continueButton.nextFocusDownId = binding.rowOne.getChildAt(0)?.id ?: View.NO_ID
        binding.navMovies.nextFocusDownId = binding.rowOne.getChildAt(0)?.id ?: View.NO_ID
        binding.settingsCard.nextFocusUpId = binding.rowTwo.getChildAt(0)?.id ?: View.NO_ID
    }

    private fun populateRows() {
        val rowOneItems = List(24) { index -> heroTitles[(index + 3) % heroTitles.size] }
        val rowTwoItems = List(24) { index -> heroTitles[(index + 6) % heroTitles.size] }

        rowOneItems.forEachIndexed { index, item ->
            binding.rowOne.addView(makeCard(item, binding.rowOneScroll, binding.contentScroll, index, 276, 155))
        }
        rowTwoItems.forEachIndexed { index, item ->
            binding.rowTwo.addView(makeCard(item, binding.rowTwoScroll, binding.contentScroll, index, 276, 155))
        }
    }

    private fun makeCard(item: TitleCard, scrollView: HorizontalScrollView, verticalScroll: ScrollView, index: Int, widthDp: Int, heightDp: Int): View {
        val density = resources.displayMetrics.density
        val widthPx = (widthDp * density).toInt()
        val heightPx = (heightDp * density).toInt()
        val marginEnd = (16 * density).toInt()
        val pad = (14 * density).toInt()
        val progressHeight = 3
        val progressWidth = ((widthPx - (pad * 2)) * item.progress).toInt().coerceAtLeast((40 * density).toInt())
        val pillRadius = 34f * density

        val frame = FrameLayout(this).apply {
            id = View.generateViewId()
            layoutParams = LinearLayout.LayoutParams(widthPx, heightPx).apply { rightMargin = marginEnd }
            isFocusable = true
            isClickable = true
            foreground = null
            background = (ContextCompat.getDrawable(this@MainActivity, item.backgroundRes)?.mutate() as? GradientDrawable)?.apply {
                cornerRadius = pillRadius
            } ?: ContextCompat.getDrawable(this@MainActivity, item.backgroundRes)
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, pillRadius)
                }
            }
        }

        val overlay = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            background = (ContextCompat.getDrawable(this@MainActivity, R.drawable.card_overlay)?.mutate() as? GradientDrawable)?.apply {
                cornerRadius = pillRadius
            } ?: ContextCompat.getDrawable(this@MainActivity, R.drawable.card_overlay)
        }

        val bottomWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
            setPadding(pad, 0, pad, pad)
        }

        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }

        val title = TextView(this).apply {
            text = item.title
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 13.5f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 1
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val brand = TextView(this).apply {
            text = item.brand
            setTextColor(0xFFEFE6DA.toInt())
            textSize = 8.5f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

        val progressTrack = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (progressHeight * density).toInt()).apply {
                topMargin = (6 * density).toInt()
            }
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.pill_dark)
            alpha = 0.45f
        }

        val progressBar = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(progressWidth, (progressHeight * density).toInt(), Gravity.START or Gravity.CENTER_VERTICAL)
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.button_primary)
            alpha = 0.95f
        }

        val progressFrame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (progressHeight * density).toInt()).apply {
                topMargin = (6 * density).toInt()
            }
            addView(progressTrack)
            addView(progressBar)
        }

        val footer = TextView(this).apply {
            text = item.footer
            setTextColor(0xFFE6DCCD.toInt())
            textSize = 8.5f
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = (6 * density).toInt()
            }
        }

        brandRow.addView(title)
        brandRow.addView(brand)
        bottomWrap.addView(brandRow)
        bottomWrap.addView(progressFrame)
        bottomWrap.addView(footer)

        frame.addView(overlay)
        frame.addView(bottomWrap)

        frame.cameraDistance = 12000f

        frame.setOnFocusChangeListener { view, hasFocus ->
            pulseAnimator(view, hasFocus)
            view.alpha = if (hasFocus) 1f else 0.96f
            view.translationZ = if (hasFocus) 18f * resources.displayMetrics.density else 0f
            frame.foreground = if (hasFocus) ContextCompat.getDrawable(this, R.drawable.focus_ring_pill_pulse) else null
            if (hasFocus) {
                setHero(item)
                revealFocusedCard(scrollView, verticalScroll, view, index)
            }
        }
        return frame
    }


    private fun revealFocusedCard(scrollView: HorizontalScrollView, verticalScroll: ScrollView, view: View, index: Int) {
        scrollView.post {
            val horizontalTarget = when {
                index <= 1 -> 0
                else -> (view.left - ((scrollView.width - view.width) / 2)).coerceAtLeast(0)
            }
            scrollView.smoothScrollTo(horizontalTarget, 0)

            val desiredTop = when (scrollView.id) {
                binding.rowOneScroll.id -> (binding.rowOneTitle.top - (18 * resources.displayMetrics.density)).toInt()
                binding.rowTwoScroll.id -> (binding.rowTwoTitle.top - (22 * resources.displayMetrics.density)).toInt()
                else -> view.top
            }.coerceAtLeast(0)
            verticalScroll.smoothScrollTo(0, desiredTop)
        }
    }

    private fun pulseAnimator(view: View, hasFocus: Boolean) {
        (view.getTag(R.id.tag_pulse_animator) as? Animator)?.cancel()
        if (hasFocus) {
            val pulse = ObjectAnimator.ofPropertyValuesHolder(
                view,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1.045f, 1.09f, 1.055f, 1.045f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1.045f, 1.09f, 1.055f, 1.045f),
                PropertyValuesHolder.ofFloat(View.TRANSLATION_Y, -5.5f * resources.displayMetrics.density, -10f * resources.displayMetrics.density, -7f * resources.displayMetrics.density, -5.5f * resources.displayMetrics.density),
                PropertyValuesHolder.ofFloat(View.ALPHA, 0.985f, 1f, 0.992f, 0.985f)
            ).apply {
                duration = 1180
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.RESTART
                start()
            }
            view.setTag(R.id.tag_pulse_animator, pulse)
        } else {
            view.animate().cancel()
            view.animate()
                .scaleX(1f)
                .scaleY(1f)
                .translationY(0f)
                .setDuration(140)
                .start()
            view.setTag(R.id.tag_pulse_animator, null)
        }
    }

    private fun setHero(item: TitleCard) {
        binding.heroBackdrop.setImageDrawable(safeDrawable(item.backgroundRes))
        binding.heroTitle.text = item.title
        binding.heroMeta.text = item.meta
        binding.heroDesc.text = item.desc
        binding.statusBadge.text = item.badge
    }

    private fun safeDrawable(resId: Int): Drawable? = ContextCompat.getDrawable(this, resId)
}
