# NewtoOld_v2.8.26.39_SHARP_BASE_LOW_END_PERFORMANCE_BRANDED_PREMIUM_FULL_PROJECT

Base used: user-uploaded NewtoOld_v2.8.26.39_SHARP_BASE_LOW_END_PERFORMANCE_MODE_FULL_PROJECT.zip.

Branding integration only. Preserved existing app behavior and functional paths:
- Low-end Android TV performance mode retained.
- Live TV loader/source validation/Gracenote paths retained.
- BunnyCDN/provider-direct architecture retained.
- Cutout/foreground extraction remains paused/backlogged.
- Row scrolling/focus, Pro Layout Editor, and sharp renderer base preserved.

Branding updates:
- Replaced launcher mipmap icons with finalized black/orange Debrid Channels premium branding.
- Replaced Android TV banner resource.
- Replaced splash/startup image and loading branding.
- StartupActivity now uses the branding image instead of plain text-only startup.
- Updated visible version/build/logcat markers.

DC_BUILD_MARKER: NewtoOld_v2.8.26.39_SHARP_BASE_LOW_END_PERFORMANCE_BRANDED_PREMIUM_FULL_PROJECT
