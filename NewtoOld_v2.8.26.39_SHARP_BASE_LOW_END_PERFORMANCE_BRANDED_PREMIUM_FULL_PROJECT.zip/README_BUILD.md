NewtoOld_v2.8.26.39_SHARP_BASE_LOW_END_PERFORMANCE_BRANDED_PREMIUM_FULL_PROJECT

Base: user-uploaded NewtoOld_v2.8.26.39_SHARP_BASE_LOW_END_PERFORMANCE_MODE_FULL_PROJECT.zip

Scope: branding-only app integration from approved Debrid Channels black/orange premium streaming identity.

Preserved:
- v2.8.26.39 sharp-image renderer base
- Low-end Android TV performance mode
- Live TV loader/source validation/Gracenote behavior
- Provider-direct IPTV/Xtream/M3U/HLS behavior
- BunnyCDN artwork architecture compatibility
- Pro Layout Editor, row focus/scrolling, backend compatibility
- Cutout work remains paused/backlogged

Updated:
- Android launcher mipmap icons
- Adaptive launcher foreground asset
- Android TV launcher banner
- Startup/splash branding image
- Loading branding image
- StartupActivity now shows approved branding instead of text-only splash
- Visible version/build/logcat markers updated

DC_BUILD_MARKER: NewtoOld_v2.8.26.39_SHARP_BASE_LOW_END_PERFORMANCE_BRANDED_PREMIUM_FULL_PROJECT
