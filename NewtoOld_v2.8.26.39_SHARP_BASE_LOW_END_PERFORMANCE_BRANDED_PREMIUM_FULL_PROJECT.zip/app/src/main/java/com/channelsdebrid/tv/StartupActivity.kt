package com.channelsdebrid.tv

import android.animation.ObjectAnimator
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class StartupActivity : AppCompatActivity() {
    private companion object { private const val TAG = "DebridChannels" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i(TAG, "STARTUP_BRANDING_APPLY: DebridChannelsPremiumBlackOrange logo=finalized lowEndSafe=true build=v2.8.26.39_BRANDED_LOW_END_PERFORMANCE")
        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(0, 0, 0)) }
        val logo = ImageView(this).apply {
            setImageResource(resources.getIdentifier("splash_branding", "drawable", packageName))
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            alpha = 0f
            translationY = dp(12).toFloat()
        }
        val loading = TextView(this).apply {
            text = "LOADING..."
            letterSpacing = 0.28f
            textSize = 11f
            setTextColor(0xFFBDBDBD.toInt())
            gravity = Gravity.CENTER
            alpha = 0f
        }
        val progress = ProgressBar(this).apply { isIndeterminate = true; alpha = 0f }
        root.addView(logo, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        root.addView(loading, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp(34), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(78) })
        root.addView(progress, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(34) })
        setContentView(root)
        ObjectAnimator.ofFloat(logo, "alpha", 0f, 1f).apply { duration = 520; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(logo, "translationY", dp(12).toFloat(), 0f).apply { duration = 620; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(loading, "alpha", 0f, 1f).setDuration(520).start()
        ObjectAnimator.ofFloat(progress, "alpha", 0f, 0.78f).setDuration(520).start()
        ObjectAnimator.ofFloat(progress, "rotation", 0f, 360f).apply { duration = 900; repeatCount = ObjectAnimator.INFINITE; interpolator = LinearInterpolator(); start() }
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }, 1150)
    }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
