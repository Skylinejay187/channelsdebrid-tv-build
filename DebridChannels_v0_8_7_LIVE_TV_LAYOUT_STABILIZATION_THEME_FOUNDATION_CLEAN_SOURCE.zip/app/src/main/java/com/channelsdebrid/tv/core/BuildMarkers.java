package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.8.7 Live TV Layout Stabilization + Theme Foundation";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.8.7_livetv_layout_stabilization_theme_foundation_clean_base";
}
