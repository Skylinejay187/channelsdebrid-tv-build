package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.4.0 TV SHOWS + TRAILER OVERLAY SYSTEM";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.4.0_tvshows_trailers_clean_base";
    private BuildMarkers() {}
}
