package com.channelsdebrid.tv

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.channelsdebrid.tv.core.AppNavigationController
import com.channelsdebrid.tv.core.BuildMarkers
import com.channelsdebrid.tv.core.GuideCacheOwner
import com.channelsdebrid.tv.core.LiveTvStateMachine
import com.channelsdebrid.tv.playback.PlayerActivity
import com.channelsdebrid.tv.playback.UnifiedPlayerManager
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class LiveTvActivity : AppCompatActivity() {
    private val stateMachine = LiveTvStateMachine()
    private lateinit var navigationOwner: AppNavigationController
    private lateinit var guideOwner: GuideCacheOwner
    private lateinit var previewPlayerOwner: UnifiedPlayerManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private val loader = Executors.newSingleThreadExecutor()

    private lateinit var contentRoot: LinearLayout
    private lateinit var categoryRail: LinearLayout
    private lateinit var channelList: LinearLayout
    private lateinit var timelineRow: LinearLayout
    private lateinit var horizontalScroll: HorizontalScrollView
    private lateinit var verticalScroll: ScrollView
    private lateinit var loadingOverlay: View
    private lateinit var loadingTitle: TextView
    private lateinit var loadingSubtitle: TextView
    private lateinit var forceGuideButton: Button
    private lateinit var infoLogo: TextView
    private lateinit var infoIcon: ImageView
    private lateinit var infoChannel: TextView
    private lateinit var infoGroup: TextView
    private lateinit var nowTime: TextView
    private lateinit var nowTitle: TextView
    private lateinit var description: TextView
    private lateinit var nextLine: TextView
    private lateinit var laterLine: TextView
    private lateinit var progressBar: View
    private lateinit var previewFrame: FrameLayout
    private lateinit var previewPlayerView: androidx.media3.ui.PlayerView
    private lateinit var previewImage: ImageView
    private lateinit var previewHint: TextView
    private lateinit var heroBackground: ImageView
    private lateinit var clockView: TextView
    private lateinit var channelStats: TextView
    private lateinit var statusTitle: TextView
    private lateinit var statusSources: TextView

    private var navViews: List<TextView> = emptyList()
    private var navIndex = 2
    private var categories: List<String> = emptyList()
    private var allChannels: List<GuideCacheOwner.Channel> = emptyList()
    private var visibleChannels: List<GuideCacheOwner.Channel> = emptyList()
    private var selectedCategory = 0
    private var selectedChannel = 0
    private var lastGuideState = LiveTvStateMachine.ScreenState.CATEGORY
    private var previewToken = 0
    private var fullPlayerOpen = false
    private var destroyed = false

    companion object {
        private const val PLAYER_REQUEST = 2101
        private const val BUILD_LABEL = "2.1.1-true-core-rewrite-verified"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        BuildMarkers.log("LiveTvActivity")
        Log.i("DebridChannels", "LiveTvActivity rewriteLabel=$BUILD_LABEL")
        supportActionBar?.hide()
        setContentView(R.layout.activity_live_tv)

        navigationOwner = AppNavigationController(this)
        guideOwner = GuideCacheOwner(this)
        previewPlayerOwner = UnifiedPlayerManager(this, "live-preview")
        bindViews()
        setupTopNavigation()
        setupRootKeyOwner()
        setupStaticTimeline()
        forceGuideButton.setOnClickListener { restoreGuideFocus("button") }
        loadGuide()
    }

    private fun bindViews() {
        contentRoot = findViewById(R.id.liveTvContentRoot)
        categoryRail = findViewById(R.id.liveTvCategoryRail)
        channelList = findViewById(R.id.liveTvChannelList)
        timelineRow = findViewById(R.id.liveTvTimeline)
        horizontalScroll = findViewById(R.id.liveTvHorizontalScroll)
        verticalScroll = findViewById(R.id.liveTvVerticalScroll)
        loadingOverlay = findViewById(R.id.liveTvLoadingOverlay)
        loadingTitle = findViewById(R.id.liveTvLoadingTitle)
        loadingSubtitle = findViewById(R.id.liveTvLoadingSubtitle)
        forceGuideButton = findViewById(R.id.liveTvForceGuideButton)
        infoLogo = findViewById(R.id.liveTvInfoLogo)
        infoIcon = findViewById(R.id.liveTvInfoIcon)
        infoChannel = findViewById(R.id.liveTvInfoChannel)
        infoGroup = findViewById(R.id.liveTvInfoGroup)
        nowTime = findViewById(R.id.liveTvNowTime)
        nowTitle = findViewById(R.id.liveTvNowTitle)
        description = findViewById(R.id.liveTvDescription)
        nextLine = findViewById(R.id.liveTvNextLine)
        laterLine = findViewById(R.id.liveTvLaterLine)
        progressBar = findViewById(R.id.liveTvProgressBar)
        previewFrame = findViewById(R.id.liveTvPreviewFrame)
        previewPlayerView = findViewById(R.id.liveTvPreviewPlayer)
        previewImage = findViewById(R.id.liveTvPreviewImage)
        previewHint = findViewById(R.id.liveTvPreviewHint)
        heroBackground = findViewById(R.id.liveTvHeroBackground)
        clockView = findViewById(R.id.liveTvClock)
        channelStats = findViewById(R.id.liveTvChannelStats)
        statusTitle = findViewById(R.id.liveTvStatusTitle)
        statusSources = findViewById(R.id.liveTvStatusSources)
        previewPlayerView.useController = false
        contentRoot.isFocusable = true
        contentRoot.isFocusableInTouchMode = false
        updateClock()
    }

    private fun setupTopNavigation() {
        val navResume = findViewById<TextView>(R.id.navResume)
        val navSmart = findViewById<TextView>(R.id.navSmart)
        val navLive = findViewById<TextView>(R.id.navLive)
        val navMovies = findViewById<TextView>(R.id.navMovies)
        val navShows = findViewById<TextView>(R.id.navShows)
        navViews = listOf(navResume, navSmart, navLive, navMovies, navShows)
        navIndex = navViews.indexOf(navLive).coerceAtLeast(0)
        navViews.forEachIndexed { index, view ->
            view.isFocusable = true
            view.isFocusableInTouchMode = false
            view.setOnClickListener { handleTopNavSelect(index) }
            view.setOnKeyListener { _, _, event ->
                if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                if (!stateMachine.ownsTopNavInput()) return@setOnKeyListener false
                when (event.keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> { navIndex = (navIndex - 1).coerceAtLeast(0); navViews[navIndex].requestFocus(); updateNavVisuals(); true }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> { navIndex = (navIndex + 1).coerceAtMost(navViews.lastIndex); navViews[navIndex].requestFocus(); updateNavVisuals(); true }
                    KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_BACK -> { restoreGuideFocus("top-nav-down"); true }
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { handleTopNavSelect(navIndex); true }
                    else -> false
                }
            }
        }
        updateNavVisuals()
    }

    private fun setupRootKeyOwner() {
        contentRoot.setOnKeyListener { _, _, event ->
            if (event.action != KeyEvent.ACTION_DOWN || fullPlayerOpen) return@setOnKeyListener false
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP -> {
                    focusTopNav()
                    true
                }
                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    if (stateMachine.state == LiveTvStateMachine.ScreenState.CATEGORY) moveCategory(1) else moveChannel(1)
                    true
                }
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    if (stateMachine.state == LiveTvStateMachine.ScreenState.GUIDE) focusCategory() else moveCategory(-1)
                    true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    if (stateMachine.state == LiveTvStateMachine.ScreenState.CATEGORY) focusGuide() else moveChannel(1)
                    true
                }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                    if (stateMachine.state == LiveTvStateMachine.ScreenState.CATEGORY) focusGuide() else openSelectedChannel()
                    true
                }
                KeyEvent.KEYCODE_BACK -> {
                    if (stateMachine.state == LiveTvStateMachine.ScreenState.GUIDE) { focusCategory(); true } else { finish(); true }
                }
                else -> false
            }
        }
    }

    private fun setupStaticTimeline() {
        timelineRow.removeAllViews()
        val fmt = SimpleDateFormat("h:mm a", Locale.US)
        val now = System.currentTimeMillis()
        for (i in 0 until 6) {
            val t = TextView(this)
            t.text = fmt.format(Date(now + i * 30 * 60 * 1000L))
            t.setTextColor(0xCCFFFFFF.toInt())
            t.textSize = 13f
            t.gravity = Gravity.CENTER
            timelineRow.addView(t, LinearLayout.LayoutParams(dp(190), LinearLayout.LayoutParams.MATCH_PARENT))
        }
    }

    private fun loadGuide() {
        stateMachine.moveTo(LiveTvStateMachine.ScreenState.LOADING, "load-guide")
        loadingOverlay.visibility = View.VISIBLE
        loadingTitle.text = "Loading Live TV"
        loadingSubtitle.text = "Building clean guide cache"
        loader.execute {
            val (channels, message) = guideOwner.loadChannels()
            mainHandler.post {
                if (destroyed) return@post
                allChannels = if (channels.isNotEmpty()) channels else fallbackChannels()
                statusTitle.text = "Live TV"
                statusSources.text = message
                channelStats.text = "${allChannels.size} channels"
                buildCategories()
                applyCategory(0)
                loadingOverlay.visibility = View.GONE
                restoreGuideFocus("loaded")
            }
        }
    }

    private fun fallbackChannels(): List<GuideCacheOwner.Channel> = listOf(
        GuideCacheOwner.Channel("Add Live Source", "", "Settings", "Configure Channels DVR, HDHomeRun, Xtream, or M3U in settings", listOf("Setup")),
        GuideCacheOwner.Channel("HDHomeRun / DVR scan found no playable channels", "", "Status", "Check network/source settings", listOf("Status"))
    )

    private fun buildCategories() {
        val groups = linkedSetOf("All", "Favorites")
        allChannels.flatMap { it.groups }.filter { it.isNotBlank() }.forEach { groups += it }
        groups += listOf("News", "Sports", "Movies", "Kids")
        categories = groups.toList()
        categoryRail.removeAllViews()
        categories.forEachIndexed { index, name ->
            val v = TextView(this)
            v.text = name
            v.textSize = 18f
            v.typeface = Typeface.DEFAULT_BOLD
            v.gravity = Gravity.CENTER_VERTICAL
            v.ellipsize = TextUtils.TruncateAt.END
            v.maxLines = 1
            v.setPadding(dp(16), 0, dp(10), 0)
            v.isFocusable = false
            v.setOnClickListener { selectedCategory = index; applyCategory(index); focusGuide() }
            categoryRail.addView(v, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)))
        }
        updateCategoryVisuals()
    }

    private fun applyCategory(index: Int) {
        selectedCategory = index.coerceIn(0, (categories.size - 1).coerceAtLeast(0))
        val cat = categories.getOrNull(selectedCategory).orEmpty()
        visibleChannels = when (cat.lowercase(Locale.US)) {
            "all" -> allChannels
            "favorites" -> allChannels.take(20)
            else -> allChannels.filter { channel ->
                channel.groups.any { it.equals(cat, ignoreCase = true) } || channel.name.contains(cat, ignoreCase = true) || channel.source.contains(cat, ignoreCase = true)
            }.ifEmpty { allChannels }
        }
        selectedChannel = selectedChannel.coerceIn(0, (visibleChannels.size - 1).coerceAtLeast(0))
        renderGuideRows()
        updateCategoryVisuals()
        updateInfoPanel()
    }

    private fun renderGuideRows() {
        channelList.removeAllViews()
        visibleChannels.forEachIndexed { index, channel ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.isFocusable = false
            row.setPadding(dp(8), 0, dp(8), 0)
            row.setOnClickListener { selectedChannel = index; focusGuide(); openSelectedChannel() }

            val logo = TextView(this)
            logo.text = channel.number.ifBlank { channel.name.take(3).uppercase(Locale.US) }
            logo.gravity = Gravity.CENTER
            logo.typeface = Typeface.DEFAULT_BOLD
            logo.setTextColor(0xFFFFFFFF.toInt())
            logo.textSize = 14f
            row.addView(logo, LinearLayout.LayoutParams(dp(76), dp(50)))

            val name = TextView(this)
            name.text = channel.name
            name.setTextColor(0xFFFFFFFF.toInt())
            name.textSize = 18f
            name.typeface = Typeface.DEFAULT_BOLD
            name.maxLines = 1
            name.ellipsize = TextUtils.TruncateAt.END
            row.addView(name, LinearLayout.LayoutParams(dp(250), LinearLayout.LayoutParams.MATCH_PARENT))

            val now = TextView(this)
            now.text = currentProgramTitle(channel)
            now.setTextColor(0xE6FFFFFF.toInt())
            now.textSize = 16f
            now.gravity = Gravity.CENTER_VERTICAL
            now.setPadding(dp(18), 0, dp(18), 0)
            row.addView(now, LinearLayout.LayoutParams(dp(380), LinearLayout.LayoutParams.MATCH_PARENT))

            val next = TextView(this)
            next.text = "Live programming"
            next.setTextColor(0xAAFFFFFF.toInt())
            next.textSize = 15f
            next.gravity = Gravity.CENTER_VERTICAL
            next.setPadding(dp(18), 0, dp(18), 0)
            row.addView(next, LinearLayout.LayoutParams(dp(320), LinearLayout.LayoutParams.MATCH_PARENT))

            channelList.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(58)))
        }
        updateGuideVisuals()
    }

    private fun updateCategoryVisuals() {
        for (i in 0 until categoryRail.childCount) {
            val v = categoryRail.getChildAt(i) as TextView
            val active = i == selectedCategory && stateMachine.state == LiveTvStateMachine.ScreenState.CATEGORY
            v.setTextColor(if (active) 0xFF111111.toInt() else 0xE6FFFFFF.toInt())
            v.setBackgroundResource(if (active) R.drawable.guide_category_selected else R.drawable.guide_category_idle)
            v.alpha = if (i == selectedCategory) 1f else 0.78f
        }
    }

    private fun updateGuideVisuals() {
        for (i in 0 until channelList.childCount) {
            val row = channelList.getChildAt(i)
            val active = i == selectedChannel && stateMachine.state == LiveTvStateMachine.ScreenState.GUIDE
            row.setBackgroundResource(if (active) R.drawable.guide_row_selected else R.drawable.guide_row_bg)
            row.alpha = if (i == selectedChannel) 1f else 0.82f
        }
    }

    private fun updateInfoPanel() {
        val ch = visibleChannels.getOrNull(selectedChannel)
        val cat = categories.getOrNull(selectedCategory).orEmpty().ifBlank { "All" }
        infoChannel.text = ch?.name ?: "Live TV"
        infoGroup.text = listOf(cat, ch?.source.orEmpty()).filter { it.isNotBlank() }.joinToString(" • ")
        nowTitle.text = currentProgramTitle(ch)
        nowTime.text = SimpleDateFormat("h:mm a", Locale.US).format(Date())
        description.text = ch?.debug?.ifBlank { "Clean core guide path • Press OK to open fullscreen playback" } ?: "No channel selected"
        nextLine.text = "Next: Live programming"
        laterLine.text = "Later: Guide data cache owner active"
        infoLogo.text = ch?.number?.ifBlank { ch.name.take(2).uppercase(Locale.US) } ?: "TV"
        infoIcon.visibility = View.GONE
        progressBar.visibility = View.GONE
        if (!ch?.iconUrl.isNullOrBlank()) {
            infoIcon.visibility = View.VISIBLE
            Glide.with(this).load(ch!!.iconUrl).diskCacheStrategy(DiskCacheStrategy.AUTOMATIC).into(infoIcon)
        }
        armPreview(ch)
    }

    private fun currentProgramTitle(channel: GuideCacheOwner.Channel?): String {
        if (channel == null) return "Live TV"
        return when {
            channel.debug.contains("movie", ignoreCase = true) -> "Now Playing"
            channel.source.contains("HDHomeRun", ignoreCase = true) -> "Live Channel"
            else -> "Live Programming"
        }
    }

    private fun armPreview(channel: GuideCacheOwner.Channel?) {
        previewToken++
        val token = previewToken
        previewPlayerOwner.release("preview-change")
        previewImage.visibility = View.VISIBLE
        previewHint.visibility = View.VISIBLE
        previewHint.text = if (channel?.url.isNullOrBlank()) "No stream URL" else "Preview loading"
        if (!channel?.iconUrl.isNullOrBlank()) {
            Glide.with(this).load(channel!!.iconUrl).diskCacheStrategy(DiskCacheStrategy.AUTOMATIC).into(previewImage)
        }
        if (channel?.url.isNullOrBlank()) return
        mainHandler.postDelayed({
            if (destroyed || fullPlayerOpen || token != previewToken) return@postDelayed
            runCatching {
                previewImage.visibility = View.GONE
                previewHint.text = "Press OK for fullscreen"
                previewPlayerOwner.play(previewPlayerView, channel!!.url, UnifiedPlayerManager.Mode.PREVIEW, muted = true)
            }.onFailure {
                previewImage.visibility = View.VISIBLE
                previewHint.text = "Preview protected • OK opens channel"
                Log.w("DebridChannels", "Preview protected failure ${it.message}")
            }
        }, 500L)
    }

    private fun moveCategory(delta: Int) {
        if (categories.isEmpty()) return
        selectedCategory = (selectedCategory + delta).coerceIn(0, categories.lastIndex)
        applyCategory(selectedCategory)
        verticalScroll.smoothScrollTo(0, selectedCategory * dp(52))
        focusCategory()
    }

    private fun moveChannel(delta: Int) {
        if (visibleChannels.isEmpty()) return
        selectedChannel = (selectedChannel + delta).coerceIn(0, visibleChannels.lastIndex)
        updateGuideVisuals()
        updateInfoPanel()
        verticalScroll.smoothScrollTo(0, (selectedChannel - 2).coerceAtLeast(0) * dp(58))
        focusGuide()
    }

    private fun focusCategory() {
        stateMachine.moveTo(LiveTvStateMachine.ScreenState.CATEGORY, "focus-category")
        lastGuideState = LiveTvStateMachine.ScreenState.CATEGORY
        contentRoot.requestFocus()
        updateCategoryVisuals()
        updateGuideVisuals()
        updateNavVisuals()
    }

    private fun focusGuide() {
        stateMachine.moveTo(LiveTvStateMachine.ScreenState.GUIDE, "focus-guide")
        lastGuideState = LiveTvStateMachine.ScreenState.GUIDE
        contentRoot.requestFocus()
        updateCategoryVisuals()
        updateGuideVisuals()
        updateNavVisuals()
    }

    private fun focusTopNav() {
        stateMachine.moveTo(LiveTvStateMachine.ScreenState.TOP_NAV, "focus-top-nav")
        navViews.getOrNull(navIndex)?.requestFocus()
        updateCategoryVisuals()
        updateGuideVisuals()
        updateNavVisuals()
    }

    private fun restoreGuideFocus(reason: String) {
        val target = if (lastGuideState == LiveTvStateMachine.ScreenState.GUIDE) LiveTvStateMachine.ScreenState.GUIDE else LiveTvStateMachine.ScreenState.CATEGORY
        stateMachine.moveTo(target, "restore-$reason")
        contentRoot.post {
            if (!destroyed && !fullPlayerOpen) {
                contentRoot.requestFocus()
                updateCategoryVisuals()
                updateGuideVisuals()
                updateNavVisuals()
                updateInfoPanel()
            }
        }
    }

    private fun updateNavVisuals() {
        navViews.forEachIndexed { index, view ->
            val active = stateMachine.state == LiveTvStateMachine.ScreenState.TOP_NAV && index == navIndex
            view.isSelected = active || index == 2
            view.alpha = if (active) 1f else 0.86f
            view.scaleX = if (active) 1.06f else 1f
            view.scaleY = if (active) 1.06f else 1f
        }
    }

    private fun handleTopNavSelect(index: Int) {
        navIndex = index.coerceIn(0, navViews.lastIndex)
        when (navViews[navIndex].id) {
            R.id.navLive -> restoreGuideFocus("nav-live")
            R.id.navResume -> navigationOwner.launchOnce(Intent(this, ContinueWatchingActivity::class.java), "resume")
            R.id.navSmart -> navigationOwner.launchOnce(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP), "main")
            R.id.navMovies -> navigationOwner.launchOnce(Intent(this, BrowseSectionActivity::class.java).putExtra("section", "movies"), "movies")
            R.id.navShows -> navigationOwner.launchOnce(Intent(this, BrowseSectionActivity::class.java).putExtra("section", "shows"), "shows")
        }
    }

    private fun openSelectedChannel() {
        val ch = visibleChannels.getOrNull(selectedChannel) ?: return
        if (ch.url.isBlank()) {
            Toast.makeText(this, ch.debug.ifBlank { "No stream URL available" }, Toast.LENGTH_LONG).show()
            return
        }
        if (fullPlayerOpen) return
        fullPlayerOpen = true
        stateMachine.moveTo(LiveTvStateMachine.ScreenState.FULL_PLAYER, "open-player")
        previewPlayerOwner.release("open-full-player")
        val intent = Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_STREAM_URL, ch.url)
            putExtra(PlayerActivity.EXTRA_TITLE, ch.name)
            putExtra(PlayerActivity.EXTRA_SOURCE_LABEL, ch.source)
            putExtra(PlayerActivity.EXTRA_DEBUG_LABEL, ch.debug)
            putExtra(PlayerActivity.EXTRA_CHANNEL_INDEX, selectedChannel)
            putExtra(PlayerActivity.EXTRA_CHANNELS_JSON, buildChannelsJson())
            putExtra(PlayerActivity.EXTRA_VOD_MODE, false)
            putExtra(PlayerActivity.EXTRA_LOGO_URL, ch.iconUrl)
            putExtra(PlayerActivity.EXTRA_ARTWORK_URL, ch.iconUrl)
            putExtra(PlayerActivity.EXTRA_META_LINE, infoGroup.text.toString())
            putExtra(PlayerActivity.EXTRA_OVERVIEW, description.text.toString())
        }
        Log.i("DebridChannels", "LiveTvActivity open fullscreen channel=${ch.name}")
        startActivityForResult(intent, PLAYER_REQUEST)
        overridePendingTransition(0, 0)
    }

    private fun buildChannelsJson(): String {
        val arr = JSONArray()
        visibleChannels.forEach { ch ->
            arr.put(JSONObject().apply {
                put("name", ch.name)
                put("url", ch.url)
                put("source", ch.source)
                put("debug", ch.debug)
                put("number", ch.number)
                put("iconUrl", ch.iconUrl)
                put("group", ch.groups.firstOrNull().orEmpty())
                put("nowTitle", currentProgramTitle(ch))
                put("nowTime", nowTime.text.toString())
                put("nextTitle", "Live programming")
            })
        }
        return arr.toString()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PLAYER_REQUEST) {
            fullPlayerOpen = false
            previewToken++
            navigationOwner.clearLaunchGate("player-result")
            restoreGuideFocus("player-result")
        }
    }

    override fun onResume() {
        super.onResume()
        updateClock()
        if (fullPlayerOpen) {
            fullPlayerOpen = false
            restoreGuideFocus("resume-player-closed")
        } else if (stateMachine.state != LiveTvStateMachine.ScreenState.LOADING) {
            restoreGuideFocus("resume")
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !fullPlayerOpen && !destroyed && stateMachine.state != LiveTvStateMachine.ScreenState.LOADING) {
            restoreGuideFocus("window-focus")
        }
    }

    override fun onPause() {
        previewPlayerOwner.release("activity-pause")
        super.onPause()
    }

    override fun onDestroy() {
        destroyed = true
        stateMachine.moveTo(LiveTvStateMachine.ScreenState.DESTROYED, "destroy")
        previewToken++
        mainHandler.removeCallbacksAndMessages(null)
        previewPlayerOwner.release("activity-destroy")
        loader.shutdownNow()
        super.onDestroy()
    }

    private fun updateClock() {
        clockView.text = SimpleDateFormat("h:mm a", Locale.US).format(Date())
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()
}
