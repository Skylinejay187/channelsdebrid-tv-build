package com.channelsdebrid.tv.core

import android.util.Log
import com.channelsdebrid.tv.BuildConfig

object BuildMarkers {
    const val BUILD_MARKER = "TRUE_CORE_REWRITE_VERIFIED_START"
    const val ARCHITECTURE_MARKER = "one_navigation_one_player_one_live_state_one_guide_cache_one_timeshift"

    fun log(component: String) {
        Log.i("DebridChannels", "$BUILD_MARKER component=$component build=${BuildConfig.VERSION_NAME} code=${BuildConfig.VERSION_CODE} arch=$ARCHITECTURE_MARKER")
    }
}
