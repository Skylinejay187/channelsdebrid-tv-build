package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.8.3 Live TV 1080p Layout Rebuild";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.8.3_livetv_1080p_layout_rebuild_clean_base";
}
