package com.channelsdebrid.tv

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.channelsdebrid.tv.playback.PlayerActivity
import com.channelsdebrid.tv.settings.SettingsRepository
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class LiveTvActivity : AppCompatActivity() {

    private lateinit var settingsRepository: SettingsRepository
    private lateinit var statusText: TextView
    private lateinit var channelList: LinearLayout
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_live_tv)
        settingsRepository = SettingsRepository(this)

        statusText = findViewById(R.id.liveTvStatus)
        channelList = findViewById(R.id.liveTvChannelList)

        findViewById<View>(R.id.liveTvBackButton).setOnClickListener { finish() }
        loadChannels()
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    private fun loadChannels() {
        statusText.text = "Loading channels…"
        channelList.removeAllViews()

        val dvr = settingsRepository.loadChannelsDvr()
        val xtream = settingsRepository.loadXtream()

        executor.execute {
            val channels = when {
                dvr.baseUrl.isNotBlank() -> loadDvrChannels(dvr.baseUrl)
                xtream.enabled && xtream.server.isNotBlank() && xtream.username.isNotBlank() && xtream.password.isNotBlank() ->
                    loadXtreamChannels(xtream.server, xtream.username, xtream.password)
                else -> emptyList()
            }

            runOnUiThread {
                if (channels.isEmpty()) {
                    statusText.text = "No Live TV sources available. Configure Channels DVR or Xtream in Settings."
                    Toast.makeText(this, "Configure Live TV in Settings first.", Toast.LENGTH_LONG).show()
                } else {
                    statusText.text = "Select a channel"
                    channels.take(50).forEachIndexed { index, channel ->
                        channelList.addView(makeChannelRow(index + 1, channel))
                    }
                }
            }
        }
    }

    private fun makeChannelRow(index: Int, channel: ChannelItem): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14))
            isFocusable = true
            isClickable = true
            background = getDrawable(R.drawable.pill_dark)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.bottomMargin = dp(12)
            layoutParams = lp
            setOnClickListener {
                startActivity(
                    Intent(this@LiveTvActivity, PlayerActivity::class.java)
                        .putExtra(PlayerActivity.EXTRA_STREAM_URL, channel.url)
                        .putExtra(PlayerActivity.EXTRA_TITLE, channel.name)
                        
                )
            }
            setOnFocusChangeListener { v, hasFocus ->
                v.animate().cancel()
                v.animate().scaleX(if (hasFocus) 1.03f else 1f)
                    .scaleY(if (hasFocus) 1.03f else 1f)
                    .alpha(if (hasFocus) 1f else 0.96f)
                    .setDuration(140)
                    .start()
            }
        }

        val num = TextView(this).apply {
            text = index.toString().padStart(2, '0')
            setTextColor(0xFFEDEDED.toInt())
            textSize = 15f
            setPadding(0, 0, dp(16), 0)
        }
        val name = TextView(this).apply {
            text = channel.name
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 17f
            setSingleLine(true)
            ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val source = TextView(this).apply {
            text = channel.source
            setTextColor(0xFFB7BDC6.toInt())
            textSize = 13f
        }

        row.addView(num)
        row.addView(name)
        row.addView(source)
        return row
    }

    private fun loadDvrChannels(baseUrl: String): List<ChannelItem> {
        val base = baseUrl.trim().trimEnd('/')
        val json = getJson("$base/devices/ANY/channels") ?: return emptyList()
        val arr = if (json.trim().startsWith("[")) JSONArray(json)
            else JSONObject(json).optJSONArray("channels") ?: JSONArray()
        val items = mutableListOf<ChannelItem>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val channelId = obj.optString("id").ifBlank { obj.optString("number") }
            if (channelId.isBlank()) continue
            val name = obj.optString("name").ifBlank { obj.optString("channel") }.ifBlank { "Channel $channelId" }
            val url = obj.optString("stream_url").ifBlank { "$base/devices/ANY/channels/$channelId/stream.m3u8" }
            items += ChannelItem(name, url, "Channels DVR")
        }
        return items
    }

    private fun loadXtreamChannels(server: String, user: String, pass: String): List<ChannelItem> {
        val base = server.trim().trimEnd('/')
        val json = getJson("$base/player_api.php?username=$user&password=$pass&action=get_live_streams") ?: return emptyList()
        val arr = JSONArray(json)
        val items = mutableListOf<ChannelItem>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val id = obj.optString("stream_id")
            if (id.isBlank()) continue
            val ext = obj.optString("container_extension").ifBlank { "m3u8" }
            val name = obj.optString("name").ifBlank { "Channel $id" }
            val url = "$base/live/$user/$pass/$id.$ext"
            items += ChannelItem(name, url, "Xtream/IPTV")
        }
        return items
    }

    private fun getJson(url: String): String? {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 6000
        connection.readTimeout = 6000
        connection.instanceFollowRedirects = true
        connection.requestMethod = "GET"
        return try {
            connection.connect()
            if (connection.responseCode !in 200..299) return null
            BufferedReader(InputStreamReader(connection.inputStream)).use { it.readText() }
        } catch (_: Exception) {
            null
        } finally {
            connection.disconnect()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    data class ChannelItem(
        val name: String,
        val url: String,
        val source: String
    )
}
