package com.channelsdebrid.tv

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.channelsdebrid.tv.settings.HomeLayoutSettings
import com.channelsdebrid.tv.settings.SettingsRepository
import com.channelsdebrid.tv.settings.UiPresetManager
import com.channelsdebrid.tv.settings.sanitized
import com.channelsdebrid.tv.settings.homeLayoutDecoratedRowTitle
import com.channelsdebrid.tv.settings.homeLayoutResolvedRowTitle
import com.channelsdebrid.tv.settings.homeLayoutRingColor
import com.channelsdebrid.tv.settings.homeLayoutTypeface
import com.channelsdebrid.tv.settings.homeLayoutFontName

class HomeLayoutEditorActivity : AppCompatActivity() {
    private companion object {
        const val REQ_EXPORT_UI_PRESET = 28169
        const val REQ_IMPORT_UI_PRESET = 28170
    }
    private lateinit var repository: SettingsRepository
    private lateinit var previewHero: FrameLayout
    private lateinit var previewRows: LinearLayout
    private lateinit var previewMenu: TextView
    private lateinit var previewHeroText: LinearLayout
    private lateinit var previewMeta: TextView
    private var config = HomeLayoutSettings()

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repository = SettingsRepository(this)
        config = repository.loadHomeLayout()
        buildUi()
        renderPreview()
    }

    private fun launchExportPresetPicker() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, UiPresetManager.defaultFileName())
        }
        try {
            startActivityForResult(intent, REQ_EXPORT_UI_PRESET)
        } catch (error: ActivityNotFoundException) {
            runCatching { UiPresetManager.exportUiPreset(this) }
                .onSuccess { file -> Toast.makeText(this, "Picker unavailable. Exported to app folder: ${file.absolutePath}", Toast.LENGTH_LONG).show() }
                .onFailure { Toast.makeText(this, "Export failed: ${it.message}", Toast.LENGTH_LONG).show() }
        }
    }

    private fun launchImportPresetPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
        }
        try {
            startActivityForResult(intent, REQ_IMPORT_UI_PRESET)
        } catch (error: ActivityNotFoundException) {
            runCatching { UiPresetManager.importUiPreset(this) }
                .onSuccess { count ->
                    config = repository.loadHomeLayout()
                    Toast.makeText(this, "Picker unavailable. UI preset restored ($count settings)", Toast.LENGTH_LONG).show()
                    recreate()
                }
                .onFailure { Toast.makeText(this, "Import failed: ${it.message}", Toast.LENGTH_LONG).show() }
        }
    }

    @Deprecated("Deprecated in API Activity Result replacement not needed for this legacy Java/Kotlin app shell")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        when (requestCode) {
            REQ_EXPORT_UI_PRESET -> {
                repository.saveHomeLayout(config)
                runCatching { UiPresetManager.exportUiPresetToUri(this, uri) }
                    .onSuccess { Toast.makeText(this, "UI preset exported to selected location", Toast.LENGTH_LONG).show() }
                    .onFailure { Toast.makeText(this, "Export failed: ${it.message}", Toast.LENGTH_LONG).show() }
            }
            REQ_IMPORT_UI_PRESET -> {
                runCatching { UiPresetManager.importUiPresetFromUri(this, uri) }
                    .onSuccess { count ->
                        config = repository.loadHomeLayout()
                        Toast.makeText(this, "UI preset restored ($count settings)", Toast.LENGTH_LONG).show()
                        recreate()
                    }
                    .onFailure { Toast.makeText(this, "Import failed: ${it.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFF05070D.toInt())
            setPadding(dp(18), dp(14), dp(18), dp(14))
            clipChildren = false
            clipToPadding = false
        }

        val sidePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, dp(16), 0)
            layoutParams = LinearLayout.LayoutParams(dp(390), ViewGroup.LayoutParams.MATCH_PARENT)
        }
        sidePanel.addView(TextView(this).apply {
            text = "Pro Layout Editor"
            setTextColor(Color.WHITE)
            textSize = 24f
            setTypeface(typeface, Typeface.BOLD)
        })
        sidePanel.addView(TextView(this).apply {
            text = "Full-screen controls + live preview. Save stores locally on this Android TV."
            setTextColor(0xFFA9B2C8.toInt())
            textSize = 13f
            setPadding(0, dp(4), 0, dp(10))
        })

        previewMeta = TextView(this).apply {
            text = ""
            setTextColor(0xFF76E4FF.toInt())
            textSize = 12f
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(0xCC0A101C.toInt(), 14, 0x3337D5FF, 1)
        }
        sidePanel.addView(previewMeta, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(12))
        }
        addSlider(controls, "Preview cards", 1, 8, config.previewCardCount) { config = config.copy(previewCardCount = it) }
        addSlider(controls, "Row vertical position", 300, 620, config.rowTopDp) { config = config.copy(rowTopDp = it) }
        addSlider(controls, "Row left / right", 0, 120, config.rowLeftDp) { config = config.copy(rowLeftDp = it) }
        addSlider(controls, "Card width", 190, 420, config.cardWidthDp) { config = config.copy(cardWidthDp = it) }
        addSlider(controls, "Card height", 110, 260, config.cardHeightDp) { config = config.copy(cardHeightDp = it) }
        addSlider(controls, "Card spacing", 0, 40, config.cardSpacingDp) { config = config.copy(cardSpacingDp = it) }
        addSlider(controls, "Focused card scale", 100, 120, config.focusedScalePercent) { config = config.copy(focusedScalePercent = it) }
        addSlider(controls, "Glow strength", 0, 100, config.glowStrengthPercent) { config = config.copy(glowStrengthPercent = it) }
        addSlider(controls, "Focus glow spread", 0, 100, config.focusGlowSpreadPercent) { config = config.copy(focusGlowSpreadPercent = it) }
        addSlider(controls, "Pulse effect", 0, 100, config.pulseStrengthPercent) { config = config.copy(pulseStrengthPercent = it) }
        addSlider(controls, "Focus ring on/off", 0, 1, config.focusRingEnabled) { config = config.copy(focusRingEnabled = it) }
        addSlider(controls, "Focus ring thickness", 0, 8, config.focusRingThicknessDp) { config = config.copy(focusRingThicknessDp = it) }
        addSlider(controls, "Focus ring color", 0, 5, config.focusRingColorIndex) { config = config.copy(focusRingColorIndex = it) }
        addSlider(controls, "3D tilt effect", 0, 100, config.cardTiltPercent) { config = config.copy(cardTiltPercent = it) }
        addSlider(controls, "Card lift", 0, 24, config.cardLiftDp) { config = config.copy(cardLiftDp = it) }
        addSlider(controls, "Rounded corners", 8, 44, config.cornerRadiusDp) { config = config.copy(cornerRadiusDp = it) }
        addSlider(controls, "Dim unfocused cards", 0, 70, config.dimUnfocusedPercent) { config = config.copy(dimUnfocusedPercent = it) }
        addSlider(controls, "Top menu icon style", 0, 5, config.topMenuIconStyle) { config = config.copy(topMenuIconStyle = it) }
        addSlider(controls, "Top menu font", 0, 11, config.topMenuFontIndex) { config = config.copy(topMenuFontIndex = it) }
        addSlider(controls, "Top menu scroll animation", 0, 4, config.topMenuAnimationStyle) { config = config.copy(topMenuAnimationStyle = it) }
        addSlider(controls, "Top menu theme", 0, 7, config.topMenuThemeStyle) { config = config.copy(topMenuThemeStyle = it) }
        addSlider(controls, "Navigation menu mode", 0, 1, config.navigationMenuMode) { config = config.copy(navigationMenuMode = it) }
        addSlider(controls, "Hero text font", 0, 11, config.heroFontIndex) { config = config.copy(heroFontIndex = it) }
        addSlider(controls, "Content/card font", 0, 11, config.contentFontIndex) { config = config.copy(contentFontIndex = it) }
        addSlider(controls, "Row title icons", 0, 1, config.rowTitleIconsEnabled) { config = config.copy(rowTitleIconsEnabled = it) }
        addSlider(controls, "Show row text", 0, 1, config.rowTextVisible) { config = config.copy(rowTextVisible = it) }
        addSlider(controls, "Extra artwork tilt mode", 0, 1, config.extraArtwork3dEnabled) { config = config.copy(extraArtwork3dEnabled = it) }
        addSlider(controls, "Extra artwork straight-depth amount", 0, 100, config.extraArtworkDepthPercent) { config = config.copy(extraArtworkDepthPercent = it) }
        addSlider(controls, "Extra artwork placement", 0, 3, config.extraArtworkPlacement) { config = config.copy(extraArtworkPlacement = it) }
        addSlider(controls, "Extra artwork source mode", 0, 4, config.extraArtworkSourceMode) { config = config.copy(extraArtworkSourceMode = it) }
        addSlider(controls, "Focus bounce", 0, 100, config.focusBouncePercent) { config = config.copy(focusBouncePercent = it) }
        addSlider(controls, "Glass card mode", 0, 1, config.glassCardMode) { config = config.copy(glassCardMode = it) }
        addSlider(controls, "Hover info overlay", 0, 1, config.hoverInfoOverlay) { config = config.copy(hoverInfoOverlay = it) }
        addSlider(controls, "Background dim on focus", 0, 45, config.backgroundDimOnFocusPercent) { config = config.copy(backgroundDimOnFocusPercent = it) }
        addSlider(controls, "Effect profile", 0, 4, config.effectProfileIndex) { config = applyEffectProfile(it) }
        addSlider(controls, "Hero text left / right", -80, 220, config.heroTextLeftDp) { config = config.copy(heroTextLeftDp = it) }
        addSlider(controls, "Hero text up / down", -80, 180, config.heroTextTopDp) { config = config.copy(heroTextTopDp = it) }
        addSlider(controls, "Top menu left / right", -220, 220, config.topMenuOffsetDp) { config = config.copy(topMenuOffsetDp = it) }
        addSlider(controls, "Hero top menu position", 0, 3, config.heroMenuVerticalPosition) { config = config.copy(heroMenuVerticalPosition = it) }
        addSlider(controls, "Hero quality mode", 0, 1, config.heroQualityMode) { config = config.copy(heroQualityMode = it) }
        addSlider(controls, "Hero backdrop fade style", 0, 1, config.heroBackdropStyle) { config = config.copy(heroBackdropStyle = it) }
        addSlider(controls, "Native UI resolution mode", 0, 2, config.nativeUiResolutionMode) { config = config.copy(nativeUiResolutionMode = it, uiResolutionMode = if (it == 2) 1 else 0) }
        addSlider(controls, "Hero logo artwork", 0, 1, config.heroLogoVisible) { config = config.copy(heroLogoVisible = it) }
        addSlider(controls, "Hero logo width", 160, 720, config.heroLogoWidthDp) { config = config.copy(heroLogoWidthDp = it) }
        addSlider(controls, "Hero logo height", 64, 280, config.heroLogoHeightDp) { config = config.copy(heroLogoHeightDp = it) }
        addSlider(controls, "Hero text size", 60, 160, config.heroTextSizePercent) { config = config.copy(heroTextSizePercent = it) }
        addSlider(controls, "IMDb badge on/off", 0, 1, config.imdbBadgeVisible) { config = config.copy(imdbBadgeVisible = it) }
        addSlider(controls, "TMDB badge on/off", 0, 1, config.tmdbBadgeVisible) { config = config.copy(tmdbBadgeVisible = it) }
        addSlider(controls, "Rating numbers on/off", 0, 1, config.ratingNumbersVisible) { config = config.copy(ratingNumbersVisible = it) }
        addSlider(controls, "Hero badge theme", 0, 14, config.heroBadgeTheme) { config = config.copy(heroBadgeTheme = it) }
        addSlider(controls, "Hero badge position", 0, 3, config.heroBadgePosition) { config = config.copy(heroBadgePosition = it) }
        addSlider(controls, "Stable row focus mode", 0, 1, config.stableRowFocusMode) { config = config.copy(stableRowFocusMode = it) }
        addSlider(controls, "Media info 4K UI mode", 0, 1, config.mediaInfoNative4KMode) { config = config.copy(mediaInfoNative4KMode = it) }
        addSlider(controls, "Hero poster lighting", 0, 1, config.heroLightingEnabled) { config = config.copy(heroLightingEnabled = it) }
        addSlider(controls, "Hero lighting intensity", 0, 100, config.heroLightingIntensityPercent) { config = config.copy(heroLightingIntensityPercent = it) }
        addSlider(controls, "Card center logo artwork", 0, 1, config.cardLogoVisible) { config = config.copy(cardLogoVisible = it) }
        addSlider(controls, "Extra artwork width", 80, 360, config.extraArtworkWidthDp) { config = config.copy(extraArtworkWidthDp = it) }
        addSlider(controls, "Extra artwork height", 80, 420, config.extraArtworkHeightDp) { config = config.copy(extraArtworkHeightDp = it) }
        addSlider(controls, "Extra artwork left / right", -260, 260, config.extraArtworkOffsetXDp) { config = config.copy(extraArtworkOffsetXDp = it) }
        addSlider(controls, "Extra artwork up / down", -180, 240, config.extraArtworkOffsetYDp) { config = config.copy(extraArtworkOffsetYDp = it) }
        addSlider(controls, "Status hub visible", 0, 1, config.statusHubVisible) { config = config.copy(statusHubVisible = it) }
        addSlider(controls, "Artwork source mode", 0, 3, config.artworkSourceMode) { config = config.copy(artworkSourceMode = it) }
        addSlider(controls, "Bottom safe space", 24, 160, config.bottomSafeDp) { config = config.copy(bottomSafeDp = it) }

        val scroll = ScrollView(this).apply { clipToPadding = false }
        scroll.addView(controls, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        sidePanel.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = rounded(0xDD05070D.toInt(), 16, 0x22FFFFFF, 1)
        }
        buttons.addView(Button(this).apply {
            text = "Reset"
            setOnClickListener {
                repository.resetHomeLayout()
                config = repository.loadHomeLayout()
                Toast.makeText(this@HomeLayoutEditorActivity, "Layout reset", Toast.LENGTH_SHORT).show()
                recreate()
            }
        })
        buttons.addView(Button(this).apply {
            text = "Save"
            requestFocus()
            setOnClickListener {
                repository.saveHomeLayout(config)
                Toast.makeText(this@HomeLayoutEditorActivity, "Pro layout saved locally", Toast.LENGTH_SHORT).show()
            }
        })
        buttons.addView(Button(this).apply {
            text = "Export"
            setOnClickListener {
                repository.saveHomeLayout(config)
                launchExportPresetPicker()
            }
        })
        buttons.addView(Button(this).apply {
            text = "Import"
            setOnClickListener { launchImportPresetPicker() }
        })
        buttons.addView(Button(this).apply {
            text = "View"
            setOnClickListener {
                repository.saveHomeLayout(config)
                val intent = Intent(this@HomeLayoutEditorActivity, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra("force_reload_layout", true)
                startActivity(intent)
            }
        })
        sidePanel.addView(buttons, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64)))

        val preview = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF182036.toInt(), 0xFF061018.toInt())
            )
            clipChildren = false
            clipToPadding = false
        }

        previewHero = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(430), Gravity.TOP)
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xEE000000.toInt(), 0x66159BFF, 0x33101040)
            )
        }

        previewMenu = TextView(this).apply {
            text = "RESUME     HOME     LIVE     MOVIES"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            textSize = 15f
            background = rounded(0x99000000.toInt(), 24, 0x55FFFFFF, 1)
        }

        previewHeroText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(76), 0, 0)
        }
        previewHeroText.addView(TextView(this).apply {
            text = "PROJECT\nHAIL MARY"
            setTextColor(Color.WHITE)
            textSize = 34f
            typeface = homeLayoutTypeface(config.heroFontIndex)
        })
        previewHeroText.addView(TextView(this).apply {
            text = "2026  •  FEATURED   IMDb 8.2   TMDB 7.9   •  Tilt preview enabled"
            setTextColor(0xFFFFD54A.toInt())
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
        })
        previewHeroText.addView(TextView(this).apply {
            text = "Live preview updates while you tune the row, card count, spacing, and focus scale."
            setTextColor(Color.WHITE)
            textSize = 14f
            maxLines = 2
        })

        previewRows = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipToPadding = false
            clipChildren = false
        }

        preview.addView(previewHero)
        preview.addView(previewMenu)
        preview.addView(previewHeroText)
        preview.addView(previewRows)

        root.addView(sidePanel)
        root.addView(preview)
        setContentView(root)
    }

    private fun addSlider(parent: LinearLayout, label: String, min: Int, max: Int, current: Int, onChange: (Int) -> Unit) {
        val title = TextView(this).apply {
            text = formatSliderLabel(label, current)
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(0, dp(9), 0, 0)
        }
        val sliderMax = max - min
        val bar = SeekBar(this).apply {
            isFocusable = true
            this.max = sliderMax
            progress = (current - min).coerceIn(0, sliderMax)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = min + progress
                    title.text = formatSliderLabel(label, value)
                    onChange(value)
                    config = config.sanitized()
                    renderPreview()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        parent.addView(title)
        parent.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(30)))
    }

    private fun formatSliderLabel(label: String, value: Int): String {
        val shown = when (label) {
            "Top menu theme" -> listOf("Flat text", "Transparent flat", "Minimal pill", "Cinema gold", "Neon ribbon", "Sharp block", "Blue tech", "Purple premium").getOrElse(value) { value.toString() }
            "Top menu icon style" -> listOf("Text only", "Symbols + text", "Icons only", "Uppercase", "Clean flat letters", "Hybrid icons").getOrElse(value) { value.toString() }
            "Top menu scroll animation" -> listOf("None", "Clean Glide", "Elastic Bounce", "Glass Pulse", "Underline Sweep").getOrElse(value) { value.toString() }
            "Hero top menu position" -> listOf("Top", "Center", "Lower", "Top Edge compact").getOrElse(value) { value.toString() }
            "Extra artwork placement" -> listOf("Hero top-right default", "Hero top-left", "Hero top-right", "Hero center").getOrElse(value) { value.toString() }
            "Extra artwork source mode" -> listOf("Smart all artwork", "Logo/clearart", "Backdrop/banner", "Poster/box art", "Any extra layer").getOrElse(value) { value.toString() }
            "Hero quality mode" -> if (value == 1) "4K hero artwork" else "1080p hero artwork default"
            "Media info 4K UI mode" -> if (value == 1) "4K media info layout" else "Standard media info layout"
            "Full UI resolution mode" -> if (value == 1) "4K UI enabled" else "1080p UI default"
            "Hero logo artwork" -> if (value == 1) "Show title/logo artwork" else "Use text title fallback"
            "Card center logo artwork" -> if (value == 1) "Show logos centered on row cards" else "Use row card text"
            "Status hub visible" -> if (value == 1) "Visible" else "Hidden"
            else -> if (label.contains("font", ignoreCase = true)) homeLayoutFontName(value) else value.toString()
        }
        return "$label: $shown"
    }

    private fun applyEffectProfile(profile: Int): HomeLayoutSettings {
        val base = config.copy(effectProfileIndex = profile)
        return when (profile.coerceIn(0, 4)) {
            1 -> base.copy(glowStrengthPercent = 35, focusGlowSpreadPercent = 25, pulseStrengthPercent = 0, cardTiltPercent = 0, dimUnfocusedPercent = 12, focusBouncePercent = 8, glassCardMode = 0)
            2 -> base.copy(glowStrengthPercent = 85, focusGlowSpreadPercent = 85, pulseStrengthPercent = 55, cardTiltPercent = 20, dimUnfocusedPercent = 30, focusBouncePercent = 28, glassCardMode = 1)
            3 -> base.copy(glowStrengthPercent = 55, focusGlowSpreadPercent = 55, pulseStrengthPercent = 20, cardTiltPercent = 65, dimUnfocusedPercent = 35, focusBouncePercent = 18, glassCardMode = 1)
            4 -> base.copy(glowStrengthPercent = 100, focusGlowSpreadPercent = 100, pulseStrengthPercent = 70, cardTiltPercent = 30, dimUnfocusedPercent = 42, focusBouncePercent = 35, glassCardMode = 1, hoverInfoOverlay = 1)
            else -> base
        }
    }

    private fun renderPreview() {
        if (!::previewHero.isInitialized) return
        previewHero.layoutParams = (previewHero.layoutParams as FrameLayout.LayoutParams).apply { height = dp(config.rowTopDp) }
        previewRows.removeAllViews()
        previewRows.translationX = dp(config.rowLeftDp).toFloat()
        previewRows.translationY = dp(config.rowTopDp).toFloat()
        previewMenu.layoutParams = FrameLayout.LayoutParams(dp(560), dp(42), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(12) }
        previewMenu.translationX = dp(config.topMenuOffsetDp).toFloat()
        previewMenu.typeface = homeLayoutTypeface(config.topMenuFontIndex)
        val menuThemeName = listOf("Flat text", "Transparent flat", "Minimal pill", "Cinema gold", "Neon ribbon", "Sharp block", "Blue tech", "Purple premium").getOrElse(config.topMenuThemeStyle.coerceIn(0,7)) { "Theme ${config.topMenuThemeStyle}" }
        previewMenu.background = when (config.topMenuThemeStyle.coerceIn(0, 7)) {
            0, 1 -> rounded(0x00000000, 0, 0x00000000, 0)
            3 -> rounded(0x22111111, 10, 0xFFFFD54A.toInt(), 1)
            4 -> rounded(0x55031B2A, 26, 0xFF4DFFB8.toInt(), 1)
            5 -> rounded(0xDD06080F.toInt(), 6, 0x88FFFFFF.toInt(), 1)
            6 -> rounded(0x66111A2A, 24, 0xFF76E4FF.toInt(), 1)
            7 -> rounded(0xDD050507.toInt(), 28, 0x88B46CFF.toInt(), 2)
            else -> rounded(0x99000000.toInt(), 24, 0x55FFFFFF, 1)
        }
        previewMenu.text = "Theme: $menuThemeName  •  Anim: " + (when (config.topMenuAnimationStyle.coerceIn(0, 4)) {
            0 -> "None  •  "
            1 -> "Clean Glide  •  "
            2 -> "Elastic Bounce  •  "
            3 -> "Glass Pulse  •  "
            else -> "Underline Sweep  •  "
        }) + when (config.topMenuIconStyle) {
            0 -> "RESUME     HOME     LIVE     MOVIES"
            2 -> "⏯     🏠     ▶     🎬"
            3 -> "RESUME     HOME     LIVE     MOVIES"
            else -> "RESUME     HOME     LIVE     MOVIES"
        }
        previewHeroText.translationX = dp(config.heroTextLeftDp).toFloat()
        previewHeroText.translationY = dp(config.heroTextTopDp).toFloat()
        applyTypeface(previewHeroText, homeLayoutTypeface(config.heroFontIndex))
        val badgeThemeName = listOf("Reference logo", "Compact pill", "Glass", "Flat", "Neon", "Mono", "Card block", "Logo only", "Rating only").getOrElse(config.heroBadgeTheme.coerceIn(0,8)) { "Theme ${config.heroBadgeTheme}" }
        previewMeta.text = "Cards: ${config.previewCardCount}  •  ${config.cardWidthDp}x${config.cardHeightDp}dp  •  Focus ${config.focusedScalePercent}%  •  Hero ${if (config.heroQualityMode == 1) "4K" else "1080p"}  •  Badge $badgeThemeName  •  Stable rows ${if (config.stableRowFocusMode == 1) "ON" else "OFF"}  •  Artwork ${listOf("Direct", "Hybrid", "Backend", "Offline").getOrElse(config.artworkSourceMode.coerceIn(0,3)) { "Direct" }}"

        previewRows.addView(TextView(this).apply {
            text = homeLayoutResolvedRowTitle("Trending in Movies", config.rowTitleIconsEnabled, config.rowTextVisible)
            setTextColor(Color.WHITE)
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
        })
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            clipToPadding = false
        }
        repeat(config.previewCardCount) { index ->
            val card = FrameLayout(this).apply {
                background = rounded(
                    if (config.glassCardMode == 1) 0xAA172234.toInt() else if (index == 0) 0xFF0E2230.toInt() else 0xFF151820.toInt(),
                     config.cornerRadiusDp,
                    if (index == 0 && config.focusRingEnabled == 1) homeLayoutRingColor(config.focusRingColorIndex) else 0x66FFFFFF,
                    if (index == 0 && config.focusRingEnabled == 1) config.focusRingThicknessDp.coerceAtLeast(1) else 1
                )
                elevation = if (index == 0) dp((4 + (config.focusGlowSpreadPercent.coerceIn(0, 100) * 0.20f)).toInt()).toFloat() else dp(1).toFloat()
                scaleX = if (index == 0) config.focusedScalePercent / 100f else 1f
                scaleY = scaleX
                rotationY = if (index == 0) config.cardTiltPercent * -0.10f else 0f
                translationZ = if (index == 0) dp(config.cardLiftDp).toFloat() else 0f
                alpha = if (index == 0) 1f else (100 - config.dimUnfocusedPercent).coerceIn(30, 100) / 100f
                clipChildren = false
                clipToPadding = false
            }
            card.addView(TextView(this).apply {
                text = if (index == 0) "FOCUSED" else "CARD ${index + 1}"
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                typeface = homeLayoutTypeface(config.contentFontIndex)
                textSize = 20f
            }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            row.addView(card, LinearLayout.LayoutParams(dp(config.cardWidthDp), dp(config.cardHeightDp)).apply {
                rightMargin = dp(config.cardSpacingDp)
            })
        }
        previewRows.addView(row)
    }

    private fun applyTypeface(group: ViewGroup, typeface: Typeface) {
        for (i in 0 until group.childCount) {
            val child = group.getChildAt(i)
            if (child is TextView) child.typeface = typeface
            if (child is ViewGroup) applyTypeface(child, typeface)
        }
    }

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int, strokeDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(dp(strokeDp).coerceAtLeast(1), strokeColor)
    }
}
