# NewtoOld v2.8.21.2 Cinematic Hero Fade + Side Menu + Genre Pill Audit

Base used: NewtoOld_v2.8.21.1_LEFT_SIDEBAR_ROW_SLIDEUP_GENRE_ANIMATION_FIX_FULL_PROJECT.

Changes made:
- Added real `navigationMenuMode` setting: 0=top menu, 1=left sidebar.
- Added left sidebar renderer and DPAD path; when sidebar is enabled, top menu is hidden but preserved.
- Added cinematic hero backdrop fade style: stronger left readability fade plus bottom fade into rows.
- Changed focused row card reveal so unfocused cards remain artwork-only.
- Changed focused card overlay to use bottom-left lazy logo and separate genre pill styling.
- Removed extra focused title text overlay from row cards.
- Preserved lazy logo loading, backend domain, media info fixes, XGIMI audio fixes, and current row/card navigation.

Verification notes:
- Gradle wrapper in this container reports Gradle is not installed, so a local full Gradle compile could not be completed here.
- Kotlin/XML files were modified from the latest clean base only; no stale generated code was intentionally carried forward beyond the known base.
