# v2.8.21.3 Compile Fix / Real Genre Pill Animation / Sidebar

Base: NewtoOld_v2.8.21.2_CINEMATIC_HERO_FADE_SIDE_MENU_GENRE_PILL_FIX_FULL_PROJECT.zip

Fixes applied:
- Added the missing focusedCardGenrePill(item) function referenced by MainActivity.kt.
- Genre pill now derives up to two real genre/meta tokens while filtering year, IMDb/TMDb labels, size, and quality tags.
- Preserved the focused-card bottom-left slide-up/fade/scale animation path.
- Preserved true lazy logo loading, neighbor logo prefetch, cinematic hero fade, and sidebar/top-menu switching behavior.
- Updated runtime build marker to v2.8.21.3.

Validation:
- Confirmed no remaining missing focusedCardGenrePill definition.
- XML/resource IDs for focus logo runnable and URL tags are present.
- Gradle compile could not run in this container because Gradle is not installed; this build specifically fixes the unresolved reference reported by GitHub Actions.
