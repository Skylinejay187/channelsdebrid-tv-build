package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.5.9 FULL APP 4K SYSTEM";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.5.9_full_app_4k_system_clean_base";
}
