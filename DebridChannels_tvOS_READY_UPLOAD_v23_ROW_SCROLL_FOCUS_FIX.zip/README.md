# Debrid Channels tvOS v23 Row Scroll Focus Fix

Ready-to-upload GitHub repo package. The workflow builds an unsigned tvOS IPA from the embedded source zip.

v23 changes:
- Focused row cards now auto-scroll/center as you move across the row
- Focused card lifts slightly with blue pulse glow
- Row moved slightly up
- v22 image-fit/info/settings polish preserved
