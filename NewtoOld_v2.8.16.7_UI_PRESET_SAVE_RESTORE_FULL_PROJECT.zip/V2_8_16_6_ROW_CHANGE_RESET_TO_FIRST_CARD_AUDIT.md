# NewtoOld v2.8.16.6 Row Change Reset To First Card Audit

Scope: ONLY row navigation behavior requested by user.

Preserved unchanged:
- Player true production stack from v2.8.16.5
- Cache OFF direct playback behavior and internal-cache block
- Donor one-row row/card system
- Focus scale/ring/lift effects
- Hero high-quality backdrop behavior
- Extra art / layout editor controls

Change made:
- DPAD UP/DOWN row transitions now call focusCard(targetRow, 0).
- Horizontal LEFT/RIGHT inside the same row still moves normally.
- Active row renders from first card after row change.

Verification markers:
- versionCode 281606
- versionName NewtoOld_v2.8.16.6_ROW_CHANGE_RESET_TO_FIRST_CARD
- DC_BUILD_MARKER: NewtoOld_v2.8.16.6_ROW_CHANGE_RESET_TO_FIRST_CARD
- FOCUS_GRAPH: V10_ROW_CHANGE_RESETS_COLUMN_ZERO
