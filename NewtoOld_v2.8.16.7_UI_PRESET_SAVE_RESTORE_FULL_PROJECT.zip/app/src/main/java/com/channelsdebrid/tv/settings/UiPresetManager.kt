package com.channelsdebrid.tv.settings

import android.content.Context
import android.os.Environment
import android.util.Log
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Export/import only visual UI preferences. This intentionally excludes account,
 * debrid, SMB/NAS, cache, playback credentials, and addon/link secrets.
 */
object UiPresetManager {
    private const val TAG = "DebridChannels"
    private const val PREFS_NAME = "channels_debrid_settings"
    private const val PRESET_VERSION = 1
    private const val FILE_NAME = "DebridChannels_UI_Preset.json"

    private val allowedPrefixes = listOf(
        "home_layout_"
    )

    private val deniedFragments = listOf(
        "password", "token", "api", "key", "secret", "nas", "smb", "cache", "debrid", "addon", "json", "url", "server"
    )

    fun presetFile(context: Context): File {
        val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        return if (downloads.exists() || downloads.mkdirs()) {
            File(downloads, FILE_NAME)
        } else {
            File(context.getExternalFilesDir(null), FILE_NAME)
        }
    }

    fun exportUiPreset(context: Context): File {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val values = JSONObject()
        prefs.all.forEach { (key, value) ->
            if (isAllowedUiKey(key)) {
                when (value) {
                    is Int -> values.put(key, value)
                    is Long -> values.put(key, value)
                    is Float -> values.put(key, value.toDouble())
                    is Boolean -> values.put(key, value)
                    is String -> values.put(key, value)
                }
            }
        }

        val root = JSONObject()
            .put("presetType", "DebridChannelsUiPreset")
            .put("presetVersion", PRESET_VERSION)
            .put("appBuild", "NewtoOld_v2.8.16.7_UI_PRESET_SAVE_RESTORE")
            .put("createdAt", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US).format(Date()))
            .put("settings", values)

        val out = presetFile(context)
        out.parentFile?.mkdirs()
        out.writeText(root.toString(2))
        Log.i(TAG, "UI_PRESET_EXPORT: success path=${out.absolutePath} keys=${values.length()}")
        return out
    }

    fun importUiPreset(context: Context): Int {
        val file = presetFile(context)
        if (!file.exists()) {
            Log.w(TAG, "UI_PRESET_IMPORT: missing path=${file.absolutePath}")
            throw IllegalStateException("Preset not found: ${file.absolutePath}")
        }

        val root = JSONObject(file.readText())
        require(root.optString("presetType") == "DebridChannelsUiPreset") { "Invalid UI preset file" }
        val settings = root.getJSONObject("settings")
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val edit = prefs.edit()
        var count = 0
        val keys = settings.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            if (!isAllowedUiKey(key)) continue
            when (val value = settings.get(key)) {
                is Int -> edit.putInt(key, value)
                is Long -> edit.putLong(key, value)
                is Double -> edit.putInt(key, value.toInt())
                is Boolean -> edit.putBoolean(key, value)
                is String -> edit.putString(key, value)
            }
            count++
        }
        edit.apply()
        Log.i(TAG, "UI_PRESET_IMPORT: success path=${file.absolutePath} keys=$count")
        return count
    }

    private fun isAllowedUiKey(key: String): Boolean {
        val lower = key.lowercase(Locale.US)
        return allowedPrefixes.any { lower.startsWith(it) } && deniedFragments.none { lower.contains(it) }
    }
}
