# Debrid Channels v0.3.0 — Dynamic Hero + Theme Engine

Clean rewrite/consolidation from v0.2.3 stable base.

Adds hero typography controls, dynamic hero rotation, and expanded Extra Artwork Slot options while preserving the existing playback/UI baseline.
