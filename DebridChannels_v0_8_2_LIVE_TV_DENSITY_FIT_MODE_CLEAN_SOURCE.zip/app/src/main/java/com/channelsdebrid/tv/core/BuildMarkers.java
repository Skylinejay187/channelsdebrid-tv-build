package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.8.2 Live TV Density Fit Mode";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.8.2_livetv_density_fit_mode_clean_base";
}
