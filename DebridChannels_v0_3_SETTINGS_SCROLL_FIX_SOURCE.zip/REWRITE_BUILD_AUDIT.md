# Rewrite Build Audit - v0.3 Settings Scroll Fix

Base used: v0.2.1 ANR Artwork Safe Fixed, rebuilt from the v0.1/v6.9 stable line.

Rule followed: clean rewrite/consolidation only. No broken v7.1 code path carried forward.

Fix focus: Settings screen scroll/focus chain.

Changes:
- versionCode 4
- versionName 0.3
- visible/logcat marker DC_V0_3_SETTINGS_SCROLL_FIX_ACTIVE
- Settings form now owns a ScrollView reference for auto-scroll
- Settings first option receives focus reliably
- Settings items auto-scroll into view when focused

Preserved:
- Pro Layout Editor working state
- backend default http://192.168.100.55:8181
- v6.9 hero ratings/artwork baseline
- v0.2.1 ANR-safe artwork guardrails
