package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.3 SETTINGS SCROLL FIX";
    public static final String LOG_MARKER = "DC_V0_3_SETTINGS_SCROLL_FIX_ACTIVE";
    private BuildMarkers() {}
}
