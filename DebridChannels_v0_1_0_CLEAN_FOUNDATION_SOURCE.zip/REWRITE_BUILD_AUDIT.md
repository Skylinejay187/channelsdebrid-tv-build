# Debrid Channels v0.1.0 Clean Foundation Audit

Build rule followed: clean rewrite/consolidation from the chosen stable line, not from broken later builds.

Base used:
- v0.0.5 Rating Persistence / stable visual-card line, preserving the corrected card logo/row behavior and Pro Layout Editor state.

Stabilized in this build:
- Version reset to versionName 0.1.0 / versionCode 10.
- Visible/log marker: DC_V0_1_0_CLEAN_FOUNDATION_ACTIVE.
- Playback source mode is Stremio Addons only for now.
- Backend Resolver / Auto mode is reserved for a future setting.
- Movie click opens media info, Play opens stream selection, and player opens only after selecting a stream.
- Fake/sample fallback links removed from Stremio stream selection.

Preserved:
- Working row UP/DOWN navigation.
- Active-row viewport behavior.
- Card logo/landscape visual behavior.
- Hero artwork and IMDb/TMDB rating badges.
- Pro Layout Editor and settings scroll behavior.
- Default backend URL: http://192.168.100.55:8181.
