# Debrid Channels v0.1.0 Clean Foundation

Clean stable foundation build.

- versionName: 0.1.0
- versionCode: 10
- marker: DC_V0_1_0_CLEAN_FOUNDATION_ACTIVE
- playback source mode: Stremio Addons
- future prepared mode: Backend Resolver / Auto
