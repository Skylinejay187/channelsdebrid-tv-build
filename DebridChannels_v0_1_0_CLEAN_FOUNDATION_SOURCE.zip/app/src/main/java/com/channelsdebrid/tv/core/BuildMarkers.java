package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.1.0 CLEAN FOUNDATION";
    public static final String LOG_MARKER = "DC_V0_1_0_CLEAN_FOUNDATION_ACTIVE";
    private BuildMarkers() {}
}
