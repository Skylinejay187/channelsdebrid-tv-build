# Android Restart — Phase A Functional-Core Boundary

## Authority and base

- UI/navigation base: `DebridChannels_AndroidTV_Phase1_Compose_Import_Fix_2_GITHUB.zip`
- Visual/behavior authority: Apple TV v984 blueprint already bundled in this project
- Logic donor inspected: latest full working Android lineage represented by the Phase C working-base archive
- Rule: logic may be extracted from the donor; donor presentation may not be copied.

## Why the previous branch was rejected

The previous Phase E retained the legacy Activity/XML presentation architecture. The screenshots showed the old Home/Movies/Shows/Live TV structures and old Settings behavior still driving the app. Styling those screens did not create Apple parity.

This restart keeps the fresh Compose project as the permanent application shell. There is no migration back to the donor UI later.

## Boundary added in Phase A

The clean shell now consumes a `FunctionalCore` dependency object containing separate contracts for:

- `CatalogRepository`
- `SourceRepository`
- `PlaybackController`
- `LiveTvRepository`
- `GuideRepository`
- `FavoritesRepository`
- `AppSettingsRepository`
- `AccountRepository`

The current blueprint implementations keep the clean project runnable. Real implementations will replace them independently in later phases.

## Donor audit

### Approved for extraction behind contracts

- `data/UnifiedCatalogRepository.kt`
- `playback/PlaybackResolver.kt`
- `playback/StreamingPipelineResolver.kt`
- `playback/PlayerDeviceProfileSystem.kt`
- `playback/PlayerReliabilitySystem.kt`
- `live/LiveSourceResolver.kt`
- `data/LiveGuideProgramResolver.kt`
- `data/StremioLiveLoader.kt`
- `data/TmdbLiveLoader.kt`
- `settings/AppConfigModels.kt`, excluding Home-layout/Pro-Editor presentation models
- `settings/SettingsRepository.kt`, after splitting UI-only preferences
- `storage/TimeshiftStorageManager.kt`
- `playback/DebridChannelsTimeshiftSession.kt`

### Quarantined permanently

- Donor `MainActivity`, `StartupActivity`, `BrowseSectionActivity`, `LiveTvActivity`, `SettingsActivity`
- Donor `PlayerActivity` presentation and XML overlay
- `HomeLayoutEditorActivity` / Pro Editor
- `SettingsScaffold`, `UiPresetManager`, `UIConfigManager`, and legacy menu/layout rendering
- Every donor XML screen layout, focus workaround tied to Activities, and old navigation route

The 3,829-line donor `PlayerActivity` is not safe to transplant. Media3 engine/session behavior must be extracted into a controller/service and rendered by the Compose player layer.

## Automated guard

`scripts/verify_clean_compose_boundary.sh` now fails the GitHub build when it detects:

- imports from the legacy `com.channelsdebrid.tv` package
- Pro Editor/Home Layout Editor reintroduction
- any Activity other than the single Compose launcher Activity
- XML screen layouts
- multiple manifest Activities
- missing functional-core contracts

## Restart phases

### Phase A — Clean-shell lock and donor audit — complete in this archive

No visual redesign and no donor runtime copied. Contracts and enforcement are established.

### Phase B — Persistent settings, accounts, catalogs, favorites and source intelligence

Port non-UI configuration, authentication, Stremio/catalog networking, resolver aggregation, search, favorites/history, and Source Intelligence behind the new contracts. Home, Movies, and TV Shows continue to render only through Compose catalog rows.

### Phase C — VOD playback engine

Extract Media3 playback, headers/cookies, resume, audio/subtitle selection, lifecycle cleanup, source switching, error recovery, decoder policy and frame-rate matching into the clean `PlaybackController`. No donor Player Activity or XML overlay.

### Phase D — Live TV, guide and Gracenote

Port HDHomeRun, Channels DVR, M3U/XMLTV, Xtream, guide/Gracenote resolution, Live TV playback profile, timeshift and exact-card focus identity behind `LiveTvRepository`, `GuideRepository`, and `PlaybackController`.

### Phase E — Apple v984 interaction parity and real Settings wiring

Finish exact catalog geometry, details, Search, Favorites, Apple-style Settings categories and playback panels while binding every control to the protected core. Pro Editor remains absent.

### Phase F — Hardening and blueprint-data removal

Remove local sample data only after real providers have safe empty/error states. Run focus, playback, lifecycle, guide, persistence and low-end device validation before production cleanup.
