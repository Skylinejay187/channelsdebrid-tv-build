# Build versions

- Android Gradle Plugin: 8.13.2
- Gradle wrapper: 8.13
- Kotlin: 2.3.21
- Compose BOM: 2026.06.00
- Compose for TV material: 1.1.0
- Compile SDK: 36
- Target SDK: 36
- Minimum SDK: 23
- Java toolchain: 17

## Restart Phase A.1 application marker

- Version code: 3
- Version name: 0.2.1-restart-phase-a-ui-precision
- GitHub artifact: DebridChannels-AndroidTV-Restart-PhaseA1-UI-Precision
