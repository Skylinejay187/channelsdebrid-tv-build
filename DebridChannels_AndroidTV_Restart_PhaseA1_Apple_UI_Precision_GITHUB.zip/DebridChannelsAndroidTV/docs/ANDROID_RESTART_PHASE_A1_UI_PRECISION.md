# Android Restart Phase A.1 — Apple UI Precision

Base: `0.2.0-restart-phase-a`
Build: `0.2.1-restart-phase-a-ui-precision`

This is a visual correction checkpoint on the clean Compose branch. No donor
Activity, XML screen, Pro Editor, playback engine, resolver, Live TV provider,
or guide implementation has been imported.

## Corrected from device screenshots

- Restored Settings to the production top navigation.
- Removed Membership from the visible top row so Settings cannot be pushed
  outside the TV safe area.
- Reduced the Debrid Channels wordmark while preserving its lettering and
  white/orange colors.
- Pinned the wordmark to the true top-left safe position.
- Rebuilt top-menu typography with a smaller serif treatment matching the
  Apple reference.
- Reduced the menu bar height and aligned search/clock to the Apple geometry.
- Removed the Android-only Live TV heading and instruction copy.
- Moved the four-column Live TV grid directly under the global menu.
- Recalculated grid padding and spacing for three visible rows.
- Rebuilt cards as responsive 16:9 cells with tighter corners.
- Replaced the orange focus frame with the required white/light-gray dual ring.
- Reduced guide metadata typography and added a compact lower glass label area.
- Added a subtle focused program-progress line.

## Boundary status

The clean-shell enforcement script remains active. This phase changes only the
fresh Compose presentation and shared design-system parameters.
