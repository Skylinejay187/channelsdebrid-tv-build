# Controlled Android TV Restart Phases

The prior legacy-UI migration branch is retired. The clean Compose project is now the permanent application shell.

## Phase A — Clean-shell lock and functional-core audit

Included in this ZIP.

- Split functional contracts
- Composition root for swappable implementations
- Donor allowlist/quarantine map
- Build guard against legacy Activities, XML screens and Pro Editor

## Phase B — Persistent data services

- Settings persistence
- Debrid/TorBox accounts
- Stremio catalog manifests
- Metadata/artwork providers
- Search
- Favorites, history and Continue Watching
- Source Intelligence aggregation with 25/50 cap

## Phase C — VOD playback engine

- Protected Media3 ExoPlayer controller
- Headers, cookies and resolved URLs
- Audio/subtitle tracks
- Resume and seeking
- Error recovery and lifecycle cleanup
- Frame-rate matching
- Compose Apple-style VOD overlay

## Phase D — Live TV, guide and Gracenote

- HDHomeRun discovery
- Channels DVR discovery
- M3U/XMLTV and Xtream
- Guide/Gracenote repository
- Live playback profile and timeshift
- Exact card focus restoration
- Quick Guide

## Phase E — Apple v984 parity and Settings wiring

- Exact Home/Movies/TV Shows catalog-row behavior
- Search, Favorites and details parity
- Apple-style Settings bound to real repositories
- Audio/subtitle/source panels
- No Pro Editor or donor presentation

## Phase F — Hardening

- Remove blueprint sample data after real-provider empty states exist
- Focus, lifecycle, playback and guide regression tests
- Low-end Android TV validation
- Production cleanup
