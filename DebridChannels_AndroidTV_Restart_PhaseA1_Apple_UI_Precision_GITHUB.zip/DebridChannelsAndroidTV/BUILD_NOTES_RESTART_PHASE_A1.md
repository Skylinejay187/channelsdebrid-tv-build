# Build Notes — Restart Phase A.1

Version: `0.2.1-restart-phase-a-ui-precision`

Run the GitHub workflow supplied in `.github/workflows/build-apk.yml`.

Primary device checks:

1. Settings is visible after Live TV in the top menu.
2. Wordmark is small and close to the top-left corner.
3. Menu uses compact serif typography and fits within the safe area.
4. Live TV opens directly to the four-column card wall with no page heading.
5. Three rows are visible at 1080p.
6. Focused channel uses a subtle white/light-gray ring, not orange.
7. Card labels remain readable without covering the artwork.
