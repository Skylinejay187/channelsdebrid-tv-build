package com.debridchannels.tv.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.debridchannels.core.designsystem.DebridColors
import com.debridchannels.core.model.LiveChannel
import com.debridchannels.tv.ui.components.LiveTvCard

@Composable
fun LiveTvScreen(
    channels: List<LiveChannel>,
    onChannelSelected: (LiveChannel) -> Unit,
    modifier: Modifier = Modifier,
) {
    // Apple v984 presents the channel wall immediately below the global menu.
    // The oversized Android-only title/instruction block is intentionally gone.
    LazyVerticalGrid(
        modifier = modifier
            .fillMaxSize()
            .background(DebridColors.Black),
        columns = GridCells.Fixed(4),
        contentPadding = PaddingValues(
            start = 38.dp,
            top = 26.dp,
            end = 38.dp,
            bottom = 32.dp,
        ),
        horizontalArrangement = Arrangement.spacedBy(18.dp),
        verticalArrangement = Arrangement.spacedBy(42.dp),
    ) {
        items(channels, key = { it.id }) { channel ->
            LiveTvCard(
                channel = channel,
                onClick = { onChannelSelected(channel) },
            )
        }
    }
}
