package com.debridchannels.tv.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import com.debridchannels.core.designsystem.DebridColors
import com.debridchannels.core.model.AppTab
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * The Apple-parity menu is intentionally explicit. Membership is not part of
 * the production top row, so it cannot push Settings beyond the TV safe area.
 */
private val primaryTabs = listOf(
    AppTab.HOME,
    AppTab.MOVIES,
    AppTab.SHOWS,
    AppTab.SPORTS,
    AppTab.FAVORITES,
    AppTab.LIVE_TV,
    AppTab.SETTINGS,
)

@Composable
fun TopMenuBar(
    selectedTab: AppTab,
    onTabSelected: (AppTab) -> Unit,
    onSearch: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(62.dp),
    ) {
        DebridWordmark(
            Modifier
                .align(Alignment.TopStart)
                .padding(start = 7.dp, top = 6.dp),
        )

        Row(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 21.dp)
                .offset(x = (-37).dp)
                .width(530.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top,
        ) {
            primaryTabs.forEach { tab ->
                TopMenuItem(
                    tab = tab,
                    selected = selectedTab == tab,
                    onClick = { onTabSelected(tab) },
                )
            }
        }

        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 20.dp, end = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            SearchChip(onClick = onSearch)
            Spacer(Modifier.width(18.dp))
            LiveClock()
        }
    }
}

@Composable
private fun DebridWordmark(modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "DEBRID",
            color = Color.White.copy(alpha = 0.86f),
            fontSize = 7.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 1.5.sp,
        )
        Text(
            text = "CHANNELS",
            color = DebridColors.Orange,
            fontSize = 6.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.15.sp,
        )
    }
}

@Composable
private fun TopMenuItem(tab: AppTab, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val textColor by animateColorAsState(
        targetValue = when {
            focused || selected -> Color.White
            else -> Color.White.copy(alpha = 0.48f)
        },
        label = "menuText",
    )
    val interaction = remember { MutableInteractionSource() }

    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (focused) Color.White.copy(alpha = 0.08f) else Color.Transparent)
            .onFocusChanged { focused = it.isFocused }
            .focusable()
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(horizontal = 5.dp, vertical = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = tab.label,
            color = textColor,
            fontSize = 13.sp,
            fontFamily = FontFamily.Serif,
            fontWeight = if (selected || focused) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1,
        )
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier
                .width(28.dp)
                .height(2.dp)
                .background(
                    color = if (selected) DebridColors.Cyan else Color.Transparent,
                    shape = RoundedCornerShape(50),
                ),
        )
    }
}

@Composable
private fun SearchChip(onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val interaction = remember { MutableInteractionSource() }
    Box(
        modifier = Modifier
            .size(24.dp)
            .clip(CircleShape)
            .background(if (focused) Color.White.copy(alpha = 0.12f) else Color.Transparent)
            .onFocusChanged { focused = it.isFocused }
            .focusable()
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        val iconColor = if (focused) Color.White else Color.White.copy(alpha = 0.78f)
        Canvas(Modifier.size(15.dp)) {
            val stroke = 1.45.dp.toPx()
            drawCircle(
                color = iconColor,
                radius = size.minDimension * 0.31f,
                center = Offset(size.width * 0.43f, size.height * 0.42f),
                style = Stroke(width = stroke),
            )
            drawLine(
                color = iconColor,
                start = Offset(size.width * 0.65f, size.height * 0.64f),
                end = Offset(size.width * 0.91f, size.height * 0.90f),
                strokeWidth = stroke,
            )
        }
    }
}

@Composable
private fun LiveClock() {
    var label by remember { mutableStateOf(currentTimeLabel()) }
    LaunchedEffect(Unit) {
        while (true) {
            label = currentTimeLabel()
            delay(15_000)
        }
    }
    Text(
        text = label,
        color = Color.White.copy(alpha = 0.66f),
        fontSize = 10.sp,
        fontFamily = FontFamily.Serif,
        fontWeight = FontWeight.Medium,
        maxLines = 1,
    )
}

private fun currentTimeLabel(): String = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
