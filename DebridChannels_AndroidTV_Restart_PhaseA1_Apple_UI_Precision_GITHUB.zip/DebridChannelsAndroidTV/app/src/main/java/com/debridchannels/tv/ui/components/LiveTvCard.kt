package com.debridchannels.tv.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import com.debridchannels.core.designsystem.DebridColors
import com.debridchannels.core.designsystem.FocusSurface
import com.debridchannels.core.model.LiveChannel
import com.debridchannels.tv.ui.artworkResource

@Composable
fun LiveTvCard(channel: LiveChannel, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(10.dp)
    FocusSurface(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f),
        shape = shape,
        focusedScale = 1.04f,
        focusedBorderColor = Color.Transparent,
        unfocusedBorderColor = Color.Transparent,
        focusedBorderWidth = 0.dp,
        unfocusedBorderWidth = 0.dp,
        focusedContainerColor = Color.Black,
        unfocusedContainerColor = Color.Black,
    ) { focused ->
        Box(Modifier.fillMaxSize()) {
            Image(
                painter = painterResource(artworkResource(channel.artworkKey)),
                contentDescription = channel.programTitle,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )

            // Subtle edge treatment mirrors the Apple card's soft side panels
            // without importing the donor app's legacy card renderer.
            Box(
                Modifier
                    .align(Alignment.CenterStart)
                    .fillMaxHeight()
                    .width(24.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color.Black.copy(alpha = 0.30f), Color.Transparent),
                        ),
                    ),
            )
            Box(
                Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxHeight()
                    .width(24.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color.Transparent, Color.Black.copy(alpha = 0.30f)),
                        ),
                    ),
            )

            // The opaque lower glass hides presentation text embedded in the
            // temporary blueprint art and gives real guide art a stable label area.
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(34.dp)
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Black.copy(alpha = 0.42f), Color.Black.copy(alpha = 0.92f)),
                        ),
                    ),
            )

            Row(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .padding(start = 9.dp, end = 9.dp, bottom = 7.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                Column(Modifier.width(42.dp)) {
                    Text(
                        text = channel.logoText,
                        color = Color.White.copy(alpha = 0.86f),
                        fontWeight = FontWeight.Bold,
                        fontSize = 7.sp,
                        maxLines = 1,
                    )
                    Text(
                        text = channel.number,
                        color = Color.White.copy(alpha = 0.54f),
                        fontSize = 6.sp,
                        maxLines = 1,
                    )
                }
                Spacer(Modifier.width(6.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        text = channel.programTitle,
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 9.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = channel.name,
                        color = Color.White.copy(alpha = 0.62f),
                        fontSize = 6.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(2.dp)
                    .background(Color.White.copy(alpha = if (focused) 0.18f else 0.08f)),
            ) {
                if (focused) {
                    Box(
                        Modifier
                            .fillMaxWidth(0.58f)
                            .fillMaxHeight()
                            .background(DebridColors.Orange.copy(alpha = 0.86f)),
                    )
                }
            }

            if (focused) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .border(2.dp, Color.White.copy(alpha = 0.72f), shape),
                )
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(3.dp)
                        .border(1.dp, Color.White.copy(alpha = 0.24f), RoundedCornerShape(8.dp)),
                )
            }
        }
    }
}
