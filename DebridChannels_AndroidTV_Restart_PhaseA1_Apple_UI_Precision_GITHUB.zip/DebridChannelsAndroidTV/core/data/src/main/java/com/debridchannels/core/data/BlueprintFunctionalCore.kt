package com.debridchannels.core.data

import com.debridchannels.core.model.AccountSnapshot
import com.debridchannels.core.model.AppSettingsSnapshot
import com.debridchannels.core.model.GuideProgram
import com.debridchannels.core.model.LivePlaybackRequest
import com.debridchannels.core.model.PlaybackLaunchResult
import com.debridchannels.core.model.PlaybackRequest

/**
 * Phase A composition root. It keeps the existing local blueprint data visible
 * while every real donor subsystem is ported behind the same contracts.
 */
object BlueprintFunctionalCoreFactory {
    fun create(): FunctionalCore {
        val repository = StandaloneBlueprintRepository()
        return FunctionalCore(
            catalogs = repository,
            sources = repository,
            playback = BlueprintPlaybackController,
            liveTv = repository,
            guide = BlueprintGuideRepository,
            favorites = repository,
            settings = InMemoryAppSettingsRepository(),
            accounts = BlueprintAccountRepository,
        )
    }
}

private object BlueprintPlaybackController : PlaybackController {
    override fun openVod(request: PlaybackRequest): PlaybackLaunchResult =
        PlaybackLaunchResult(accepted = false, message = "VOD engine is scheduled for the protected playback port phase.")

    override fun openLive(request: LivePlaybackRequest): PlaybackLaunchResult =
        PlaybackLaunchResult(accepted = false, message = "Live playback is scheduled for the protected Live TV port phase.")

    override fun release() = Unit
}

private object BlueprintGuideRepository : GuideRepository {
    override fun programs(channelIds: Set<String>): List<GuideProgram> = emptyList()
    override fun refresh(force: Boolean): Result<Unit> = Result.success(Unit)
}

private class InMemoryAppSettingsRepository : AppSettingsRepository {
    private var current = AppSettingsSnapshot()

    override fun read(): AppSettingsSnapshot = current

    override fun update(transform: (AppSettingsSnapshot) -> AppSettingsSnapshot): AppSettingsSnapshot {
        current = transform(current).sanitized()
        return current
    }
}

private object BlueprintAccountRepository : AccountRepository {
    override fun snapshot(): AccountSnapshot = AccountSnapshot()
}
