package com.debridchannels.core.data

import com.debridchannels.core.model.AppTab
import com.debridchannels.core.model.CatalogRow
import com.debridchannels.core.model.LiveChannel
import com.debridchannels.core.model.MediaItem
import com.debridchannels.core.model.MediaType
import com.debridchannels.core.model.SourceResult

class StandaloneBlueprintRepository : DebridRepository {
    private val movies = listOf(
        media("movie-1", "The Last Signal", MediaType.MOVIE, 2026, "Science Fiction", "A deep-space rescue crew follows a transmission that should not exist.", "poster_01", "landscape_01", 8.2, 124),
        media("movie-2", "Night Run", MediaType.MOVIE, 2025, "Action Thriller", "A courier has one night to cross a city that has turned against him.", "poster_02", "landscape_02", 7.8, 108),
        media("movie-3", "Northern Lights", MediaType.MOVIE, 2024, "Drama", "A family returns home and uncovers the story their town tried to forget.", "poster_03", "landscape_03", 8.0, 117),
        media("movie-4", "Orbit", MediaType.MOVIE, 2026, "Adventure", "A damaged research station becomes humanity's last way home.", "poster_04", "landscape_04", 8.5, 136),
        media("movie-5", "The Archive", MediaType.MOVIE, 2025, "Mystery", "A curator discovers that one missing film can rewrite a life.", "poster_05", "landscape_05", 7.6, 101),
        media("movie-6", "Red Horizon", MediaType.MOVIE, 2023, "Epic", "Two rivals race across a desert where every map is wrong.", "poster_06", "landscape_06", 7.9, 142),
        media("movie-7", "Quiet Water", MediaType.MOVIE, 2025, "Suspense", "A remote lake keeps returning objects that were never lost.", "poster_07", "landscape_07", 7.4, 96),
        media("movie-8", "After Midnight", MediaType.MOVIE, 2026, "Crime", "A radio host receives calls from crimes that have not happened yet.", "poster_08", "landscape_08", 8.1, 113),
    )

    private val shows = listOf(
        media("show-1", "Signal House", MediaType.SHOW, 2026, "Season 1", "A coastal family discovers the lighthouse is broadcasting memories.", "poster_09", "landscape_09", 8.7, null),
        media("show-2", "Metro Division", MediaType.SHOW, 2025, "Season 3", "An elite transit unit investigates crimes hidden beneath the city.", "poster_10", "landscape_10", 8.3, null),
        media("show-3", "Second Sun", MediaType.SHOW, 2024, "Season 2", "A new star appears in the sky and changes one small town forever.", "poster_11", "landscape_11", 8.0, null),
        media("show-4", "The Long Weekend", MediaType.SHOW, 2026, "Limited Series", "Eight guests arrive at a hotel that has no record of their booking.", "poster_12", "landscape_12", 8.4, null),
        media("show-5", "Black Harbor", MediaType.SHOW, 2025, "Season 4", "A port investigator follows a conspiracy through the shipping lanes.", "poster_13", "landscape_13", 7.9, null),
        media("show-6", "Legacy Code", MediaType.SHOW, 2023, "Season 3", "A forgotten software system starts predicting real-world events.", "poster_14", "landscape_14", 8.2, null),
    )

    private val channels = listOf(
        channel("23.1", "QVC", "QVC", "Minute to Win It", "Game show • Live", "live_01", "Entertainment"),
        channel("23.2", "HSN", "HSN", "Someone They Knew", "Court TV • Live", "live_02", "Entertainment"),
        channel("23.3", "CBS", "WKBN-HD", "Jail", "Reality • Live", "live_03", "Local"),
        channel("23.4", "FOX", "WYFX-HD", "FIFA World Cup Live", "Sports • Live", "live_04", "Sports", isSports = true),
        channel("27.1", "ABC", "WYTV-HD", "World News Tonight", "News • Live", "live_05", "News"),
        channel("27.2", "FOX", "WYFX-HD", "The Karate Kid Part III", "Movie • Live", "live_06", "Movies"),
        channel("33.1", "myTV", "MyYTV", "Last Man Standing", "Comedy • Live", "live_07", "Entertainment"),
        channel("33.2", "PBS", "WNEO HD", "Pioneers of Television", "Documentary • Live", "live_08", "Local"),
        channel("45.1", "PBS", "WNEO HD", "Wild Game", "Outdoors • Live", "live_09", "Sports", isSports = true),
        channel("45.2", "ION", "ION", "NCIS", "Drama • Live", "live_10", "Entertainment"),
        channel("62.1", "ESPN", "ESPN", "WNBA Basketball", "Live sports", "live_11", "Sports", isSports = true),
        channel("62.2", "FS1", "FS1", "Horse Racing", "Live sports", "live_12", "Sports", isSports = true),
    )

    override fun catalogRows(tab: AppTab): List<CatalogRow> = when (tab) {
        AppTab.MOVIES -> listOf(
            CatalogRow("popular-movies", "Popular Movies", "Trending now", movies),
            CatalogRow("new-movies", "New Releases", "Recently added", movies.reversed()),
            CatalogRow("movie-night", "Movie Night", "A daily rotating collection", movies.shuffledStable()),
        )
        AppTab.SHOWS -> listOf(
            CatalogRow("popular-shows", "Popular TV Shows", "Trending series", shows),
            CatalogRow("new-episodes", "New Episodes", "Recently aired", shows.reversed()),
            CatalogRow("binge", "Binge-Worthy", "Complete seasons", shows.shuffledStable()),
        )
        else -> listOf(
            CatalogRow("continue", "Continue Watching", "Pick up where you left off", (movies.take(4) + shows.take(3))),
            CatalogRow("watchable", "Watchable Today", "Movies and shows selected for today", (movies + shows).shuffledStable()),
            CatalogRow("popular", "Popular on Debrid Channels", "What everyone is watching", movies + shows),
        )
    }

    override fun favorites(): List<MediaItem> = listOf(movies[0], shows[0], movies[3], shows[3])

    override fun liveChannels(): List<LiveChannel> = channels

    override fun sourceResults(limit: Int): List<SourceResult> {
        val safeLimit = if (limit == 50) 50 else 25
        return (1..safeLimit).map { index ->
            SourceResult(
                id = "source-$index",
                provider = listOf("Comet", "Torrentio", "MediaFusion", "TorBox")[index % 4],
                title = "${if (index % 3 == 0) "4K" else "1080p"} source $index",
                quality = if (index % 3 == 0) "2160p" else "1080p",
                sizeLabel = "${2 + (index % 18)}.${index % 10} GB",
                cached = index % 4 != 0,
            )
        }
    }

    private fun media(
        id: String,
        title: String,
        type: MediaType,
        year: Int,
        subtitle: String,
        description: String,
        poster: String,
        landscape: String,
        rating: Double,
        runtime: Int?,
    ) = MediaItem(
        id = id,
        title = title,
        type = type,
        year = year,
        subtitle = subtitle,
        description = description,
        posterKey = poster,
        landscapeKey = landscape,
        genres = listOf(subtitle.substringBefore(" "), "Drama"),
        rating = rating,
        runtimeMinutes = runtime,
        isFavorite = id in setOf("movie-1", "movie-4", "show-1", "show-4"),
    )

    private fun channel(
        number: String,
        logo: String,
        name: String,
        program: String,
        subtitle: String,
        art: String,
        category: String,
        isSports: Boolean = false,
    ) = LiveChannel(
        id = "channel-$number",
        number = number,
        name = name,
        source = "HDHomeRun",
        logoText = logo,
        programTitle = program,
        programSubtitle = subtitle,
        artworkKey = art,
        category = category,
        isFavorite = number in setOf("23.3", "27.2"),
        isSports = isSports,
    )

    private fun <T> List<T>.shuffledStable(): List<T> {
        if (size < 2) return this
        val pivot = size / 3
        return drop(pivot) + take(pivot)
    }
}
