package com.debridchannels.core.data

import com.debridchannels.core.model.AppTab
import com.debridchannels.core.model.CatalogRow
import com.debridchannels.core.model.LiveChannel
import com.debridchannels.core.model.MediaItem
import com.debridchannels.core.model.SourceResult

/**
 * Small presentation-independent repository contracts.
 *
 * The fresh Compose shell depends on these contracts only. The protected donor
 * implementation may be ported behind them one subsystem at a time, but donor
 * Activities, XML layouts and navigation classes must never cross this boundary.
 */
interface CatalogRepository {
    fun catalogRows(tab: AppTab): List<CatalogRow>
}

interface FavoritesRepository {
    fun favorites(): List<MediaItem>
}

interface LiveTvRepository {
    fun liveChannels(): List<LiveChannel>
}

interface SourceRepository {
    fun sourceResults(limit: Int): List<SourceResult>
}

/** Compatibility aggregate retained for the Phase 1 blueprint repository. */
interface DebridRepository :
    CatalogRepository,
    FavoritesRepository,
    LiveTvRepository,
    SourceRepository

class ServerConnectionRepository(
    private val fallback: DebridRepository = StandaloneBlueprintRepository(),
) : DebridRepository {
    override fun catalogRows(tab: AppTab): List<CatalogRow> = fallback.catalogRows(tab)
    override fun favorites(): List<MediaItem> = fallback.favorites()
    override fun liveChannels(): List<LiveChannel> = fallback.liveChannels()
    override fun sourceResults(limit: Int): List<SourceResult> = fallback.sourceResults(limit)
}
