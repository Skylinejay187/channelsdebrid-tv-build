package com.debridchannels.core.data

import com.debridchannels.core.model.AccountSnapshot
import com.debridchannels.core.model.AppSettingsSnapshot
import com.debridchannels.core.model.GuideProgram
import com.debridchannels.core.model.LivePlaybackRequest
import com.debridchannels.core.model.PlaybackLaunchResult
import com.debridchannels.core.model.PlaybackRequest

/** Playback engine boundary. No Activity, View or Compose type is allowed here. */
interface PlaybackController {
    fun openVod(request: PlaybackRequest): PlaybackLaunchResult
    fun openLive(request: LivePlaybackRequest): PlaybackLaunchResult
    fun release()
}

/** Guide/Gracenote boundary used by the Compose Live TV screen and future guide. */
interface GuideRepository {
    fun programs(channelIds: Set<String>): List<GuideProgram>
    fun refresh(force: Boolean = false): Result<Unit>
}

/** Device-local settings boundary. UI rendering does not own persistence. */
interface AppSettingsRepository {
    fun read(): AppSettingsSnapshot
    fun update(transform: (AppSettingsSnapshot) -> AppSettingsSnapshot): AppSettingsSnapshot
}

/** Debrid/provider account boundary. Credentials never live in composables. */
interface AccountRepository {
    fun snapshot(): AccountSnapshot
}

/**
 * Single dependency object consumed by the clean Compose application shell.
 * Each property can later be replaced independently by a protected donor adapter.
 */
data class FunctionalCore(
    val catalogs: CatalogRepository,
    val sources: SourceRepository,
    val playback: PlaybackController,
    val liveTv: LiveTvRepository,
    val guide: GuideRepository,
    val favorites: FavoritesRepository,
    val settings: AppSettingsRepository,
    val accounts: AccountRepository,
)
