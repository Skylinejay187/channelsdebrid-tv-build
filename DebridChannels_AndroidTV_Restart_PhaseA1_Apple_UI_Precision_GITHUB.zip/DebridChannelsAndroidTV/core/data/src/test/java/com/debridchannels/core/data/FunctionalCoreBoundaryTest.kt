package com.debridchannels.core.data

import com.debridchannels.core.model.AppTab
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FunctionalCoreBoundaryTest {
    @Test
    fun cleanShellUsesSplitContractsWithoutChangingBlueprintRows() {
        val core = BlueprintFunctionalCoreFactory.create()

        assertTrue(core.catalogs.catalogRows(AppTab.HOME).isNotEmpty())
        assertTrue(core.catalogs.catalogRows(AppTab.MOVIES).isNotEmpty())
        assertTrue(core.catalogs.catalogRows(AppTab.SHOWS).isNotEmpty())
        assertTrue(core.liveTv.liveChannels().isNotEmpty())
        assertTrue(core.favorites.favorites().isNotEmpty())
        assertEquals(25, core.sources.sourceResults(25).size)
        assertEquals(50, core.sources.sourceResults(50).size)
        assertNotNull(core.settings.read())
        assertNotNull(core.accounts.snapshot())
    }

    @Test
    fun placeholderPlaybackCannotPretendThatDonorEngineIsAlreadyWired() {
        val core = BlueprintFunctionalCoreFactory.create()
        val result = core.playback.openVod(
            com.debridchannels.core.model.PlaybackRequest(
                mediaId = "movie-1",
                mediaType = com.debridchannels.core.model.MediaType.MOVIE,
                title = "The Last Signal",
            ),
        )

        assertFalse(result.accepted)
        assertTrue(result.message.orEmpty().isNotBlank())
    }
}
