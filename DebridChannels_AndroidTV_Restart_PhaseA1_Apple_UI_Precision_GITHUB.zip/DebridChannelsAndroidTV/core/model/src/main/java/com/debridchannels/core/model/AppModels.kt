package com.debridchannels.core.model

enum class AppTab(val label: String) {
    HOME("Home"),
    MOVIES("Movies"),
    SHOWS("TV Shows"),
    SPORTS("Sports"),
    FAVORITES("Favorites"),
    LIVE_TV("Live TV"),
    MEMBERSHIP("Membership"),
    SETTINGS("Settings"),
}

enum class MediaType { MOVIE, SHOW, EPISODE, LIVE_CHANNEL }

enum class ConnectionMode(val label: String) {
    STANDALONE("Standalone"),
    HOME_SERVER("Home Server"),
    AUTOMATIC("Automatic"),
}

data class MediaItem(
    val id: String,
    val title: String,
    val type: MediaType,
    val year: Int,
    val subtitle: String,
    val description: String,
    val posterKey: String,
    val landscapeKey: String,
    val logoText: String = title,
    val genres: List<String> = emptyList(),
    val rating: Double? = null,
    val runtimeMinutes: Int? = null,
    val isFavorite: Boolean = false,
)

data class CatalogRow(
    val id: String,
    val title: String,
    val subtitle: String = "",
    val items: List<MediaItem>,
)

data class LiveChannel(
    val id: String,
    val number: String,
    val name: String,
    val source: String,
    val logoText: String,
    val programTitle: String,
    val programSubtitle: String,
    val artworkKey: String,
    val category: String,
    val isFavorite: Boolean = false,
    val isSports: Boolean = false,
)

data class GuideProgram(
    val channelId: String,
    val title: String,
    val startLabel: String,
    val endLabel: String,
    val description: String,
)

data class SourceResult(
    val id: String,
    val provider: String,
    val title: String,
    val quality: String,
    val sizeLabel: String,
    val cached: Boolean,
)

/** Presentation-neutral request passed to the future protected VOD engine. */
data class PlaybackRequest(
    val mediaId: String,
    val mediaType: MediaType,
    val title: String,
    val sourceUrl: String? = null,
    val headers: Map<String, String> = emptyMap(),
    val resumePositionMs: Long = 0L,
)

/** Presentation-neutral request passed to the future protected Live TV engine. */
data class LivePlaybackRequest(
    val channelId: String,
    val channelName: String,
    val sourceUrl: String? = null,
    val headers: Map<String, String> = emptyMap(),
)

data class PlaybackLaunchResult(
    val accepted: Boolean,
    val message: String? = null,
)

data class AppSettingsSnapshot(
    val connectionMode: ConnectionMode = ConnectionMode.STANDALONE,
    val sourceResultLimit: Int = 25,
    val frameRateMatchingEnabled: Boolean = true,
    val preferredAudioLanguage: String = "en",
    val preferredSubtitleLanguage: String = "en",
) {
    fun sanitized(): AppSettingsSnapshot = copy(
        sourceResultLimit = if (sourceResultLimit == 50) 50 else 25,
        preferredAudioLanguage = preferredAudioLanguage.ifBlank { "en" },
        preferredSubtitleLanguage = preferredSubtitleLanguage.ifBlank { "en" },
    )
}

data class AccountSnapshot(
    val realDebridConnected: Boolean = false,
    val torBoxConnected: Boolean = false,
    val configuredStremioAddons: Int = 0,
)
