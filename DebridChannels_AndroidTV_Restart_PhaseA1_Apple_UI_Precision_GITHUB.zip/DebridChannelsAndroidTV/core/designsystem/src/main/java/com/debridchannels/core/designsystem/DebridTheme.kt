package com.debridchannels.core.designsystem

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.darkColorScheme

object DebridColors {
    val Black = Color(0xFF000000)
    val NearBlack = Color(0xFF090909)
    val Panel = Color(0xE6121212)
    val Card = Color(0xFF171717)
    val CardSoft = Color(0xFF202020)
    val White = Color(0xFFF8F8F8)
    val Muted = Color(0xFF9B9B9B)
    val Orange = Color(0xFFFF922E)
    val OrangeDark = Color(0xFF8E4316)
    val Cyan = Color(0xFF7EDBFF)
    val Green = Color(0xFF58D68D)
    val Red = Color(0xFFFF5A5F)
}

object DebridDimensions {
    const val BlueprintWidth = 1920f
    const val BlueprintHeight = 1080f
    val TopBarHeight = 62.dp
    val ScreenHorizontalPadding = 38.dp
    val CardRadius = 10.dp
    val FocusedCardRadius = 12.dp
}

@Composable
fun DebridChannelsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = DebridColors.Orange,
            secondary = DebridColors.Cyan,
            background = DebridColors.Black,
            surface = DebridColors.Panel,
            onPrimary = DebridColors.Black,
            onBackground = DebridColors.White,
            onSurface = DebridColors.White,
        ),
        content = content,
    )
}

@Composable
fun FocusSurface(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(20.dp),
    focusedScale: Float = 1.04f,
    contentPadding: PaddingValues = PaddingValues(0.dp),
    focusedBorderColor: Color = DebridColors.Orange,
    unfocusedBorderColor: Color = Color.White.copy(alpha = 0.10f),
    focusedBorderWidth: Dp = 3.dp,
    unfocusedBorderWidth: Dp = 1.dp,
    focusedContainerColor: Color = DebridColors.CardSoft,
    unfocusedContainerColor: Color = DebridColors.Card,
    onFocusChanged: (Boolean) -> Unit = {},
    content: @Composable BoxScope.(focused: Boolean) -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) focusedScale else 1f, label = "focusScale")
    val interactionSource = remember { MutableInteractionSource() }

    Box(
        modifier = modifier
            .scale(scale)
            .clip(shape)
            .background(if (focused) focusedContainerColor else unfocusedContainerColor)
            .border(
                BorderStroke(
                    width = if (focused) focusedBorderWidth else unfocusedBorderWidth,
                    color = if (focused) focusedBorderColor else unfocusedBorderColor,
                ),
                shape,
            )
            .onFocusChanged {
                focused = it.isFocused
                onFocusChanged(focused)
            }
            .focusable()
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick,
            )
            .padding(contentPadding),
    ) {
        content(focused)
    }
}

fun cinematicScrim(): Brush = Brush.verticalGradient(
    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.18f), Color.Black.copy(alpha = 0.92f)),
)
