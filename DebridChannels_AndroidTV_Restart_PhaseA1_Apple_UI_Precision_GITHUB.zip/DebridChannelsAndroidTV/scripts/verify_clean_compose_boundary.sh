#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP_SRC="$ROOT/app/src/main"

fail() {
  echo "CLEAN COMPOSE BOUNDARY FAILED: $1" >&2
  exit 1
}

if grep -R --line-number --include='*.kt' --include='*.kts' 'com\.channelsdebrid\.tv' "$ROOT/app" "$ROOT/core"; then
  fail "legacy donor package imported into the clean project"
fi

if grep -R -i --line-number --exclude='verify_clean_compose_boundary.sh' --exclude='*.md' 'pro[[:space:]_-]*editor\|HomeLayoutEditorActivity' "$APP_SRC" "$ROOT/core"; then
  fail "Pro Editor or its legacy Activity was reintroduced"
fi

if find "$APP_SRC" -type f \( -name '*Activity.kt' -o -name '*Activity.java' \) ! -name 'MainActivity.kt' | grep -q .; then
  find "$APP_SRC" -type f \( -name '*Activity.kt' -o -name '*Activity.java' \) ! -name 'MainActivity.kt' >&2
  fail "legacy screen Activity found; Compose shell must keep a single launcher Activity"
fi

if [ -d "$APP_SRC/res/layout" ] && find "$APP_SRC/res/layout" -type f | grep -q .; then
  find "$APP_SRC/res/layout" -type f >&2
  fail "legacy XML screen layouts found in clean Compose shell"
fi

activity_count="$(grep -c '<activity' "$APP_SRC/AndroidManifest.xml" || true)"
[ "$activity_count" -eq 1 ] || fail "manifest must expose exactly one Activity during clean-shell migration"

grep -q 'com.debridchannels.tv' "$ROOT/app/build.gradle.kts" || fail "clean application namespace missing"
grep -q 'FunctionalCore' "$ROOT/core/data/src/main/java/com/debridchannels/core/data/FunctionalCoreContracts.kt" || fail "functional-core contracts missing"

echo "Clean Compose boundary verified."
