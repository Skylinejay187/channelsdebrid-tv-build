# Build Notes — Android Restart Phase A

Version: `0.2.0-restart-phase-a`

This archive restarts the Android crossover from the clean Compose foundation. It does not contain the legacy Android UI, Pro Editor, old Settings Activity, old catalog Activities, old Live TV Activity, or donor Player Activity.

Phase A adds the functional-core contract boundary and a GitHub build guard. Visible Compose screens and bundled blueprint artwork are intentionally unchanged in this phase.
