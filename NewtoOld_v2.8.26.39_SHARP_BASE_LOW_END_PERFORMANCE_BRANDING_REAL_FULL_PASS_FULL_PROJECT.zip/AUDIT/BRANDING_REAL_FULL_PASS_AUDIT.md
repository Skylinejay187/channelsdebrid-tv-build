# Branding Real Full Pass Audit

Base: `NewtoOld_v2.8.26.39_SHARP_BASE_LOW_END_PERFORMANCE_MODE_FULL_PROJECT.zip`

Scope:
- Branding/assets only.
- Preserved low-end Android TV performance mode.
- Preserved Live TV, BunnyCDN artwork acceleration, provider-direct playback, Gracenote, row/focus behavior, and sharp renderer base.

Fixes:
- Replaced all mipmap launcher icons (`mdpi`, `hdpi`, `xhdpi`, `xxhdpi`, `xxxhdpi`).
- Replaced round launcher icons.
- Replaced Android adaptive icon foreground/background layers.
- Replaced Android TV Leanback banner.
- Rebuilt splash/loading artwork as a true 16:9 no-crop asset instead of using a full brand sheet/cropped mockup.
- Updated StartupActivity to use `FIT_CENTER` full-screen splash image.
- Updated version/build marker for verification.

Install note:
- If launcher still shows the old icon after installing over the old APK, uninstall the previous app or clear the Android TV launcher cache. Android TV launchers may cache app icons/banners aggressively.
