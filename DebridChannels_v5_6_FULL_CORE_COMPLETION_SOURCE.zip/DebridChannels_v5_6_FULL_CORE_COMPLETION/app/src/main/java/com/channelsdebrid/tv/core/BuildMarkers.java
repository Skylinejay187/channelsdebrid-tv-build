package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v5.6 FULL CORE COMPLETION";
    public static final String LOG_MARKER = "DC_V5_6_FULL_CORE_COMPLETION";
    private BuildMarkers() {}
}
