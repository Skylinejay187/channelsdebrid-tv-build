# App v2.8.26.71 Performance Baked Logo Audit

Preserved protected baseline:
- Launcher/banner untouched.
- Startup untouched.
- Live TV untouched.
- Sharp/high-quality row poster behavior not downgraded.
- Hero cutout remains backlogged; no new cutout experiments.

Fixes in this build:
- Performance mode suppresses editable focused-card logo overlays when a baked poster+logo image is used, eliminating double logos.
- Performance mode suppresses separate hero logo overlay when a baked poster+logo image is available, so hero poster/extra-art uses the baked logo path instead of double layering.
- Hero extra-art/poster uses backend poster+logo composite in Performance mode.
- Row/focused card baked composite requests include card dimensions and safe logo-fit params.
- Baked composite images use FIT_CENTER in-app to avoid cropping built-in logos.
- Premium mode keeps editable separate logos.
- Auto mode still chooses based on the existing device profile rules.
