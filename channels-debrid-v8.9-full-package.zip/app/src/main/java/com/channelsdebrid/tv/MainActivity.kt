package com.channelsdebrid.tv

import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.channelsdebrid.tv.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    data class TitleCard(
        val title: String,
        val meta: String,
        val desc: String,
        val badge: String,
        val brand: String,
        val footer: String,
        val progress: Float,
        val backgroundRes: Int
    )

    private val heroTitles = listOf(
        TitleCard("SHŌGUN", "S1 E7: A Stick of Time  •  43 min left", "A premium lean-back presentation for your media center, with live TV, trending shows, smart recommendations, and instant playback.", "⚑  Instant Playback Ready", "FX", "43 min left", 0.58f, R.drawable.bg_shogun),
        TitleCard("THE BATMAN", "2h 56m  •  IMAX", "A darker detective spotlight with premium backdrop changes and clean TV-safe row alignment.", "⚑  Direct Play Ready", "PLEX", "IMAX", 0.42f, R.drawable.bg_batman),
        TitleCard("FALLOUT", "49 min left  •  Prime", "Post-apocalyptic action with large-format hero art and poster rows that stay locked in place.", "⚑  Synced to Library", "prime", "49 min left", 0.51f, R.drawable.bg_fallout),
        TitleCard("DUNE", "2h 35m  •  Max", "Expansive cinema-style focus treatment with large typography and backdrop-driven navigation.", "⚑  HDR Available", "max", "Featured", 0.46f, R.drawable.bg_dune),
        TitleCard("HALO", "Series  •  Prime", "Sci-fi recommendations rendered in the same composition language as your reference shot.", "⚑  Resume Synced", "prime", "Series", 0.33f, R.drawable.bg_halo),
        TitleCard("WONKA", "Movie  •  Max", "Bright contrast title art for spotlight and recently-added rows without breaking the layout grid.", "⚑  Trailer Ready", "max", "Movie", 0.37f, R.drawable.bg_wonka),
        TitleCard("MAYOR OF KINGSTOWN", "Series  •  Paramount+", "Grounded drama hero state with full-screen poster changes as focus moves across rows.", "⚑  Watched on Device", "P+", "Series", 0.28f, R.drawable.bg_mayor),
        TitleCard("CIVIL WAR", "Movie  •  109 min", "Poster rows line up under the hero so the screen still feels premium and intentional.", "⚑  Cache Eligible", "A24", "109 min", 0.22f, R.drawable.bg_civilwar),
        TitleCard("AVATAR", "Movie  •  Disney+", "High-contrast blockbuster art for the lower row examples and future trailer pop-up placement.", "⚑  Dolby Vision", "D+", "Featured", 0.48f, R.drawable.bg_avatar)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setHero(heroTitles.first())
        populateRows()
        wireTopControls()
    }

    private fun wireTopControls() {
        val focusables = listOf(
            binding.menuButton,
            binding.homeButton,
            binding.navResume,
            binding.navSmart,
            binding.navLive,
            binding.navMovies,
            binding.continueButton,
            binding.settingsCard
        )

        focusables.forEach { view ->
            view.setOnFocusChangeListener { v, hasFocus ->
                v.animate()
                    .scaleX(if (hasFocus) 1.05f else 1f)
                    .scaleY(if (hasFocus) 1.05f else 1f)
                    .alpha(if (hasFocus) 1f else 0.96f)
                    .setDuration(140)
                    .start()
            }
        }
    }

    private fun populateRows() {
        val rowOneItems = buildRailItems(offset = 0, total = 24)
        val rowTwoItems = buildRailItems(offset = 3, total = 24)

        binding.rowOne.removeAllViews()
        binding.rowTwo.removeAllViews()

        rowOneItems.forEachIndexed { index, item ->
            binding.rowOne.addView(makeCard(item = item, index = index, totalItems = rowOneItems.size))
        }
        rowTwoItems.forEachIndexed { index, item ->
            binding.rowTwo.addView(makeCard(item = item, index = index, totalItems = rowTwoItems.size))
        }
    }

    private fun buildRailItems(offset: Int, total: Int): List<TitleCard> {
        return List(total) { idx -> heroTitles[(idx + offset) % heroTitles.size] }
    }

    private fun makeCard(item: TitleCard, index: Int, totalItems: Int): View {
        val density = resources.displayMetrics.density
        val widthPx = (320 * density).toInt()
        val heightPx = (180 * density).toInt()
        val marginEnd = (24 * density).toInt()
        val pad = (14 * density).toInt()
        val progressHeightPx = (4 * density).toInt()
        val progressWidth = ((widthPx - (pad * 2)) * item.progress).toInt().coerceAtLeast((64 * density).toInt())

        val frame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(widthPx, heightPx).apply {
                rightMargin = if (index == totalItems - 1) 0 else marginEnd
            }
            isFocusable = true
            isClickable = true
            foreground = ContextCompat.getDrawable(this@MainActivity, R.drawable.focus_ring)
            background = ContextCompat.getDrawable(this@MainActivity, item.backgroundRes)
            clipToOutline = true
            alpha = 0.84f
        }

        val overlay = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.card_overlay)
        }

        val bottomWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            )
            setPadding(pad, 0, pad, pad)
        }

        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val title = TextView(this).apply {
            text = item.title
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val brand = TextView(this).apply {
            text = item.brand
            setTextColor(0xFFEFE6DA.toInt())
            textSize = 10f
            setTypeface(typeface, Typeface.BOLD)
        }

        val progressTrack = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                progressHeightPx
            ).apply {
                topMargin = (8 * density).toInt()
            }
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.pill_dark)
            alpha = 0.45f
        }

        val progressBar = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(progressWidth, progressHeightPx, Gravity.START or Gravity.CENTER_VERTICAL)
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.button_primary)
            alpha = 0.95f
        }

        val progressFrame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                progressHeightPx
            ).apply {
                topMargin = (8 * density).toInt()
            }
            addView(progressTrack)
            addView(progressBar)
        }

        val footer = TextView(this).apply {
            text = item.footer
            setTextColor(0xFFE6DCCD.toInt())
            textSize = 10f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = (8 * density).toInt()
            }
        }

        brandRow.addView(title)
        brandRow.addView(brand)
        bottomWrap.addView(brandRow)
        bottomWrap.addView(progressFrame)
        bottomWrap.addView(footer)

        frame.addView(overlay)
        frame.addView(bottomWrap)

        frame.setOnClickListener { setHero(item) }
        frame.setOnFocusChangeListener { view, hasFocus ->
            view.animate()
                .scaleX(if (hasFocus) 1.06f else 1f)
                .scaleY(if (hasFocus) 1.06f else 1f)
                .translationY(if (hasFocus) (-8 * density) else 0f)
                .alpha(if (hasFocus) 1f else 0.84f)
                .setDuration(150)
                .start()
            if (hasFocus) {
                setHero(item)
                scrollCardIntoView(view)
            }
        }

        return frame
    }

    private fun scrollCardIntoView(card: View) {
        val scrollView = findHorizontalScrollParent(card) ?: return
        scrollView.post {
            val cardLeft = card.left
            val cardRight = card.right
            val viewportStart = scrollView.scrollX
            val viewportWidth = scrollView.width
            val targetPadding = (24 * resources.displayMetrics.density).toInt()
            val viewportEnd = viewportStart + viewportWidth

            val targetScroll = when {
                cardRight > viewportEnd - targetPadding -> cardRight - viewportWidth + targetPadding
                cardLeft < viewportStart + targetPadding -> cardLeft - targetPadding
                else -> viewportStart
            }.coerceAtLeast(0)

            scrollView.smoothScrollTo(targetScroll, 0)
        }
    }

    private fun findHorizontalScrollParent(view: View): HorizontalScrollView? {
        var current: View? = view
        while (current?.parent is ViewGroup) {
            val parent = current.parent as ViewGroup
            if (parent is HorizontalScrollView) return parent
            current = parent
        }
        return null
    }

    private fun setHero(item: TitleCard) {
        binding.heroBackdrop.setImageDrawable(safeDrawable(item.backgroundRes))
        binding.heroTitle.text = item.title
        binding.heroMeta.text = item.meta
        binding.heroDesc.text = item.desc
        binding.statusBadge.text = item.badge
        binding.rowOneSubtitle.text = "More like ${item.title}"
    }

    private fun safeDrawable(resId: Int): Drawable? = ContextCompat.getDrawable(this, resId)
}
