package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.7.5 Deep Home UI Rebuild + Pro Editor Theme Binding";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.7.5_deep_home_ui_rebuild_pro_editor_theme_binding_clean_base";
}
