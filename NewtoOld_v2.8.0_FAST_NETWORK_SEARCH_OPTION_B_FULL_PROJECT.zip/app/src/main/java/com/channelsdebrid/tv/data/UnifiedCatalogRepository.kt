package com.channelsdebrid.tv.data

import android.content.Context
import android.util.Log
import com.channelsdebrid.tv.settings.SettingsRepository
import com.channelsdebrid.tv.settings.StremioAddonSettings
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

class UnifiedCatalogRepository(private val context: Context) {
    data class MediaItem(
        val title: String,
        val type: String,
        val meta: String,
        val overview: String,
        val externalId: String,
        val posterUrl: String = "",
        val backdropUrl: String = "",
        val logoUrl: String = "",
        val progress: Float = 0f,
        val streamUrl: String = ""
    )

    private val prefs = context.getSharedPreferences("continue_watching", Context.MODE_PRIVATE)
    private val cachePrefs = context.getSharedPreferences("unified_catalog_cache", Context.MODE_PRIVATE)
    private val settingsRepository = SettingsRepository(context)
    private val memoryJsonCache = linkedMapOf<String, JSONObject?>()
    private val tmdbEnhancementCache = linkedMapOf<String, MediaItem?>()
    private val instantSearchCache = linkedMapOf<String, List<MediaItem>>()

    fun section(section: String): List<MediaItem> {
        val normalized = when (section.lowercase(Locale.US)) {
            "shows", "tv", "series" -> "shows"
            else -> "movies"
        }
        val tmdbItems = tmdbSection(normalized)
        val stremioItems = enrichWithTmdb(stremioSection(normalized), normalized)
        val merged = (tmdbItems + stremioItems)
            .dedupeMedia()
            .filter { if (normalized == "shows") it.type.equals("series", true) || it.type.equals("tv", true) else it.type.equals("movie", true) }
        return merged.ifEmpty { fallback(normalized) }.take(160)
    }

    fun search(query: String): List<MediaItem> {
        val q = query.trim()
        val cacheKey = q.lowercase(Locale.US)
        instantSearchCache[cacheKey]?.let { return it }
        if (q.isBlank()) return section("movies").take(20) + section("shows").take(20)
        val tmdb = tmdbSearch(q)
        val stremioRaw = stremioSearch(q)
        val stremio = enrichWithTmdb(stremioRaw.take(36), "search") + stremioRaw.drop(36)
        val live = liveChannelResults(q)
        val guide = liveProgramResults(q)
        val merged = (tmdb + stremio + live + guide)
            .dedupeMedia()
            .ifEmpty { fallback("search").filter { it.title.contains(q, true) || it.type.contains(q, true) } }
            .take(140)
        rememberSearch(cacheKey, merged)
        return merged
    }


    fun fastNetworkSearch(query: String): List<MediaItem> {
        val q = query.trim()
        if (q.isBlank()) return emptyList()
        val tmdbItems = tmdbSearch(q)
            .dedupeMedia()
            .sortedWith(compareByDescending<MediaItem> { it.title.equals(q, ignoreCase = true) }
                .thenByDescending { it.title.lowercase(Locale.US).startsWith(q.lowercase(Locale.US)) }
                .thenBy { it.title.length })
            .take(30)
        rememberSearch(q.lowercase(Locale.US), tmdbItems)
        return tmdbItems
    }

    fun instantSearch(query: String): List<MediaItem> {
        val q = query.trim()
        val cacheKey = q.lowercase(Locale.US)
        instantSearchCache[cacheKey]?.let { return it.take(40) }
        if (q.isBlank()) return fallback("movies").take(10) + fallback("shows").take(10)
        val cached = cachedCatalogMatches(q)
        val live = runCatching { liveChannelResults(q).take(20) }.getOrDefault(emptyList())
        val guide = runCatching { liveProgramResults(q).take(10) }.getOrDefault(emptyList())
        return (cached + live + guide).dedupeMedia().take(40)
    }

    fun warmSearchIndex() {
        runCatching { section("movies").take(80) + section("shows").take(80) }
    }

    private fun rememberSearch(cacheKey: String, items: List<MediaItem>) {
        if (cacheKey.isBlank()) return
        if (instantSearchCache.size > 40) instantSearchCache.remove(instantSearchCache.keys.first())
        instantSearchCache[cacheKey] = items
    }

    private fun cachedCatalogMatches(query: String): List<MediaItem> {
        val q = query.lowercase(Locale.US)
        val cachedLists = instantSearchCache.values.flatten()
        val fallbackHits = (fallback("movies") + fallback("shows")).filter {
            it.title.lowercase(Locale.US).contains(q) || it.meta.lowercase(Locale.US).contains(q)
        }
        return (cachedLists + fallbackHits).filter {
            it.title.lowercase(Locale.US).contains(q) || it.meta.lowercase(Locale.US).contains(q) || it.overview.lowercase(Locale.US).contains(q)
        }.dedupeMedia().take(40)
    }

    fun continueWatching(): List<MediaItem> {
        val arr = JSONArray(prefs.getString("items", "[]") ?: "[]")
        val out = mutableListOf<MediaItem>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val progress = obj.optDouble("progress", 0.0).toFloat().coerceIn(0f, 1f)
            if (progress <= 0.02f || progress >= 0.92f) continue
            out += MediaItem(
                title = obj.optString("title").ifBlank { "Continue Watching" },
                type = obj.optString("type").ifBlank { "movie" },
                meta = obj.optString("meta").ifBlank { "${(progress * 100).toInt()}% watched" },
                overview = obj.optString("overview").ifBlank { "Resume from where you left off." },
                externalId = obj.optString("externalId").ifBlank { obj.optString("streamUrl") },
                posterUrl = obj.optString("posterUrl"),
                backdropUrl = obj.optString("backdropUrl"),
                logoUrl = obj.optString("logoUrl"),
                progress = progress,
                streamUrl = obj.optString("streamUrl")
            )
        }
        return out.sortedByDescending { it.progress }.ifEmpty { fallback("resume") }
    }

    private fun tmdbSection(section: String): List<MediaItem> {
        val tmdb = settingsRepository.loadTmdb()
        if (tmdb.apiKey.isBlank()) return emptyList()
        val endpoints = if (section == "shows") {
            listOf("/trending/tv/week", "/tv/popular", "/tv/top_rated")
        } else {
            listOf("/trending/movie/week", "/movie/popular", "/movie/top_rated")
        }
        return endpoints.flatMap { endpoint -> tmdbFetchResults(endpoint, section, tmdb.apiKey, tmdb.language, tmdb.region) }.dedupeMedia()
    }

    private fun tmdbSearch(query: String): List<MediaItem> {
        val tmdb = settingsRepository.loadTmdb()
        if (tmdb.apiKey.isBlank() || query.isBlank()) return emptyList()
        val encoded = URLEncoder.encode(query, "UTF-8")
        return tmdbFetchResults("/search/multi?query=$encoded&include_adult=false", "multi", tmdb.apiKey, tmdb.language, tmdb.region)
    }

    private fun tmdbFetchResults(endpoint: String, forcedSection: String, apiKey: String, language: String, region: String): List<MediaItem> {
        val sep = if (endpoint.contains("?")) "&" else "?"
        val url = "https://api.themoviedb.org/3$endpoint${sep}api_key=${URLEncoder.encode(apiKey, "UTF-8")}&language=${URLEncoder.encode(language.ifBlank { "en-US" }, "UTF-8")}&region=${URLEncoder.encode(region.ifBlank { "US" }, "UTF-8")}".replace("+", "%20")
        val root = fetchJson(url, cacheMinutes = 60) ?: return emptyList()
        val arr = root.optJSONArray("results") ?: return emptyList()
        val out = mutableListOf<MediaItem>()
        for (i in 0 until minOf(arr.length(), 36)) {
            val obj = arr.optJSONObject(i) ?: continue
            val mediaType = obj.optString("media_type").ifBlank { if (forcedSection == "shows") "tv" else if (forcedSection == "movies") "movie" else "" }
            if (mediaType !in listOf("movie", "tv")) continue
            val title = if (mediaType == "tv") obj.optString("name") else obj.optString("title")
            if (title.isBlank()) continue
            val tmdbId = obj.optInt("id", 0)
            val stremioType = if (mediaType == "tv") "series" else "movie"
            val date = if (mediaType == "tv") obj.optString("first_air_date") else obj.optString("release_date")
            val year = date.takeIf { it.length >= 4 }?.substring(0, 4).orEmpty()
            val rating = obj.optDouble("vote_average", 0.0).takeIf { it > 0.0 }?.let { "TMDB ${String.format(Locale.US, "%.1f", it)}" }.orEmpty()
            val poster = tmdbImage(obj.optString("poster_path"), "w780")
            val backdrop = tmdbImage(obj.optString("backdrop_path"), "original")
            out += MediaItem(
                title = title,
                type = stremioType,
                meta = listOf(year, rating).filter { it.isNotBlank() }.joinToString(" • "),
                overview = obj.optString("overview"),
                externalId = if (tmdbId > 0) "tmdb:$tmdbId" else title,
                posterUrl = poster,
                backdropUrl = backdrop.ifBlank { poster }
            )
        }
        return out
    }

    private fun stremioSection(section: String): List<MediaItem> {
        val type = if (section == "shows") "series" else "movie"
        val catalogs = listOf("top", "popular", "trending", "year", "imdbRating", "new")
        return activeStremioAddons()
            .flatMap { addon -> catalogs.flatMap { catalog -> stremioCatalogItems(addon, type, catalog, "") } }
            .dedupeMedia()
            .take(120)
    }

    private fun stremioSearch(query: String): List<MediaItem> {
        if (query.isBlank()) return emptyList()
        val catalogs = listOf("top", "popular", "trending", "year", "imdbRating", "new")
        return activeStremioAddons()
            .flatMap { addon ->
                catalogs.flatMap { catalog ->
                    stremioCatalogItems(addon, "movie", catalog, query) + stremioCatalogItems(addon, "series", catalog, query)
                }
            }
            .dedupeMedia()
            .take(100)
    }

    private fun activeStremioAddons(): List<StremioAddonSettings> {
        val configured = settingsRepository.loadStremioAddons().filter { it.enabled && it.manifestUrl.isNotBlank() }
        val cinemeta = StremioAddonSettings("cinemeta", "Cinemeta", "https://v3-cinemeta.strem.io/manifest.json", true)
        return (configured + cinemeta).distinctBy { it.manifestUrl.trim().lowercase(Locale.US) }
    }

    private fun stremioCatalogItems(addon: StremioAddonSettings, type: String, catalogId: String, query: String): List<MediaItem> {
        val base = addon.manifestUrl.removeSuffix("/manifest.json").trimEnd('/')
        val searchPart = if (query.isNotBlank()) "/search=${URLEncoder.encode(query, "UTF-8").replace("+", "%20")}" else ""
        val url = "$base/catalog/$type/$catalogId$searchPart.json"
        val root = fetchJson(url, cacheMinutes = if (query.isBlank()) 45 else 5) ?: return emptyList()
        val arr = root.optJSONArray("metas") ?: root.optJSONArray("items") ?: return emptyList()
        val out = mutableListOf<MediaItem>()
        for (i in 0 until minOf(arr.length(), 30)) {
            val obj = arr.optJSONObject(i) ?: continue
            val title = obj.optString("name").ifBlank { obj.optString("title") }
            if (title.isBlank()) continue
            val id = obj.optString("imdb_id").ifBlank { obj.optString("imdbId") }.ifBlank { obj.optString("id") }
            out += MediaItem(
                title = title,
                type = if (type == "series") "series" else "movie",
                meta = listOf(addon.name.ifBlank { "Stremio" }, obj.optString("releaseInfo").ifBlank { obj.optString("year") }).filter { it.isNotBlank() }.joinToString(" • "),
                overview = obj.optString("description"),
                externalId = id,
                posterUrl = highQualityStremioImage(obj.optString("poster")),
                backdropUrl = highQualityStremioImage(obj.optString("background")).ifBlank { highQualityStremioImage(obj.optString("poster")) },
                logoUrl = highQualityStremioImage(obj.optString("logo"))
            )
        }
        return out
    }

    private fun enrichWithTmdb(items: List<MediaItem>, section: String): List<MediaItem> {
        val tmdb = settingsRepository.loadTmdb()
        if (tmdb.apiKey.isBlank() || items.isEmpty()) return items
        return items.mapIndexed { index, item ->
            if (index >= 48) item
            else if (!item.type.equals("movie", true) && !item.type.equals("series", true) && !item.type.equals("tv", true)) item
            else runCatching { enrichOneWithTmdb(item, tmdb.apiKey, tmdb.language, tmdb.region, section) }.getOrDefault(item)
        }
    }

    private fun enrichOneWithTmdb(item: MediaItem, apiKey: String, language: String, region: String, section: String): MediaItem {
        val cacheKey = listOf(item.type, item.externalId, item.title, language, region).joinToString("|").lowercase(Locale.US)
        if (tmdbEnhancementCache.containsKey(cacheKey)) return tmdbEnhancementCache[cacheKey] ?: item
        val mediaType = if (item.type.equals("series", true) || item.type.equals("tv", true) || section == "shows") "tv" else "movie"
        val obj = when {
            item.externalId.startsWith("tmdb:") -> tmdbDetails(apiKey, mediaType, item.externalId.removePrefix("tmdb:").toIntOrNull() ?: 0, language)
            item.externalId.startsWith("tt") -> tmdbFindByImdb(apiKey, item.externalId, mediaType, language)
            else -> tmdbSearchBest(apiKey, mediaType, item.title, language, region)
        } ?: run { tmdbEnhancementCache[cacheKey] = null; return item }
        val tmdbId = obj.optInt("id", 0)
        val title = if (mediaType == "tv") obj.optString("name") else obj.optString("title")
        val date = if (mediaType == "tv") obj.optString("first_air_date") else obj.optString("release_date")
        val year = date.takeIf { it.length >= 4 }?.substring(0, 4).orEmpty()
        val rating = obj.optDouble("vote_average", 0.0).takeIf { it > 0.0 }?.let { "TMDB ${String.format(Locale.US, "%.1f", it)}" }.orEmpty()
        val poster = tmdbImage(obj.optString("poster_path"), "w780").ifBlank { item.posterUrl }
        val backdrop = tmdbImage(obj.optString("backdrop_path"), "original").ifBlank { item.backdropUrl.ifBlank { poster } }
        val enhanced = item.copy(
            title = title.ifBlank { item.title },
            meta = listOf(year, rating, item.meta.substringBefore(" • ").takeIf { it.isNotBlank() && !it.startsWith("TMDB") }).filterNotNull().filter { it.isNotBlank() }.joinToString(" • ").ifBlank { item.meta },
            overview = obj.optString("overview").ifBlank { item.overview },
            externalId = item.externalId.ifBlank { if (tmdbId > 0) "tmdb:$tmdbId" else item.title },
            posterUrl = poster,
            backdropUrl = backdrop
        )
        tmdbEnhancementCache[cacheKey] = enhanced
        return enhanced
    }

    private fun tmdbFindByImdb(apiKey: String, imdbId: String, preferredMediaType: String, language: String): JSONObject? {
        val url = "https://api.themoviedb.org/3/find/${URLEncoder.encode(imdbId, "UTF-8")}?api_key=${URLEncoder.encode(apiKey, "UTF-8")}&external_source=imdb_id&language=${URLEncoder.encode(language.ifBlank { "en-US" }, "UTF-8")}".replace("+", "%20")
        val root = fetchJson(url, cacheMinutes = 60) ?: return null
        return if (preferredMediaType == "tv") root.optJSONArray("tv_results")?.optJSONObject(0) ?: root.optJSONArray("movie_results")?.optJSONObject(0) else root.optJSONArray("movie_results")?.optJSONObject(0) ?: root.optJSONArray("tv_results")?.optJSONObject(0)
    }

    private fun tmdbDetails(apiKey: String, mediaType: String, tmdbId: Int, language: String): JSONObject? {
        if (tmdbId <= 0) return null
        val endpointType = if (mediaType == "tv") "tv" else "movie"
        val url = "https://api.themoviedb.org/3/$endpointType/$tmdbId?api_key=${URLEncoder.encode(apiKey, "UTF-8")}&language=${URLEncoder.encode(language.ifBlank { "en-US" }, "UTF-8")}".replace("+", "%20")
        return fetchJson(url, cacheMinutes = 60)
    }

    private fun tmdbSearchBest(apiKey: String, mediaType: String, title: String, language: String, region: String): JSONObject? {
        if (title.isBlank()) return null
        val endpointType = if (mediaType == "tv") "tv" else "movie"
        val url = "https://api.themoviedb.org/3/search/$endpointType?api_key=${URLEncoder.encode(apiKey, "UTF-8")}&query=${URLEncoder.encode(title, "UTF-8")}&include_adult=false&language=${URLEncoder.encode(language.ifBlank { "en-US" }, "UTF-8")}&region=${URLEncoder.encode(region.ifBlank { "US" }, "UTF-8")}".replace("+", "%20")
        val arr = fetchJson(url, cacheMinutes = 60)?.optJSONArray("results") ?: return null
        return arr.optJSONObject(0)
    }

    private fun tmdbImage(path: String, size: String): String {
        val clean = path.trim()
        return if (clean.isBlank()) "" else if (clean.startsWith("http")) clean else "https://image.tmdb.org/t/p/$size$clean"
    }

    private fun highQualityStremioImage(url: String): String {
        val clean = url.trim()
        if (clean.isBlank()) return ""
        return clean.replace("/w342/", "/original/").replace("/w500/", "/original/").replace("/w780/", "/original/")
    }

    private fun liveChannelResults(query: String): List<MediaItem> {
        val raw = context.getSharedPreferences("live_tv_cache", Context.MODE_PRIVATE).getString("channels_json", "[]").orEmpty()
        val arr = JSONArray(raw.ifBlank { "[]" })
        val out = mutableListOf<MediaItem>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val name = obj.optString("name")
            val groups = groupsLabel(obj)
            if (query.isNotBlank() && !name.contains(query, true) && !groups.contains(query, true) && !obj.optString("source").contains(query, true)) continue
            out += MediaItem(name, "live", listOf(obj.optString("source").ifBlank { "Live TV Channel" }, groups).filter { it.isNotBlank() }.joinToString(" • "), "Live TV channel from your synced lineup.", "live:${obj.optString("url")}", obj.optString("iconUrl"), obj.optString("iconUrl"), obj.optString("iconUrl"), streamUrl = obj.optString("url"))
        }
        return out.take(80)
    }

    private fun liveProgramResults(query: String): List<MediaItem> {
        val rawChannels = context.getSharedPreferences("live_tv_cache", Context.MODE_PRIVATE).getString("channels_json", "[]").orEmpty()
        val rawEpg = context.getSharedPreferences("live_tv_epg_cache", Context.MODE_PRIVATE).getString("epg_programs_json", "").orEmpty()
        if (rawEpg.isBlank()) return emptyList()
        val channelByUrl = linkedMapOf<String, JSONObject>()
        runCatching {
            val channels = JSONArray(rawChannels.ifBlank { "[]" })
            for (i in 0 until channels.length()) channels.optJSONObject(i)?.let { obj -> obj.optString("url").takeIf { it.isNotBlank() }?.let { channelByUrl[it] = obj } }
        }
        val root = JSONObject(rawEpg)
        val out = mutableListOf<MediaItem>()
        val keys = root.keys()
        while (keys.hasNext()) {
            val streamUrl = keys.next()
            val channel = channelByUrl[streamUrl]
            val channelName = channel?.optString("name").orEmpty()
            val icon = channel?.optString("iconUrl").orEmpty()
            val source = channel?.optString("source").orEmpty()
            val programs = root.optJSONArray(streamUrl) ?: continue
            for (i in 0 until programs.length()) {
                val p = programs.optJSONObject(i) ?: continue
                val title = p.optString("title")
                val desc = p.optString("description")
                if (title.isBlank() || title.equals("No information", true)) continue
                val haystack = "$title $desc $channelName $source"
                if (query.isNotBlank() && !haystack.contains(query, true)) continue
                out += MediaItem(title, "live", listOf("Live Program", channelName, p.optString("startLabel"), p.optString("endLabel")).filter { it.isNotBlank() }.joinToString(" • "), desc.ifBlank { "Airing on $channelName" }, "live-program:$streamUrl:$i", p.optString("imageUrl").ifBlank { icon }, p.optString("imageUrl"), icon, streamUrl = streamUrl)
            }
        }
        return out.take(80)
    }

    private fun groupsLabel(obj: JSONObject): String {
        val arr = obj.optJSONArray("groups") ?: return ""
        val values = mutableListOf<String>()
        for (i in 0 until arr.length()) arr.optString(i).takeIf { it.isNotBlank() }?.let(values::add)
        return values.take(3).joinToString(", ")
    }

    private fun fetchText(url: String, cacheMinutes: Int = 0): String {
        val key = "url:" + url.hashCode()
        if (cacheMinutes > 0) {
            val timestamp = cachePrefs.getLong("$key:time", 0L)
            val cached = cachePrefs.getString("$key:body", "").orEmpty()
            if (cached.isNotBlank() && System.currentTimeMillis() - timestamp < cacheMinutes * 60_000L) return cached
        }
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 1600
            readTimeout = 2600
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "DebridChannelsTV/2.6.6")
        }
        return try {
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (cacheMinutes > 0 && body.isNotBlank() && conn.responseCode in 200..299) {
                cachePrefs.edit().putString("$key:body", body).putLong("$key:time", System.currentTimeMillis()).apply()
            }
            body
        } catch (e: Exception) {
            Log.w("DebridChannels", "catalog fetch failed: $url ${e.message}")
            cachePrefs.getString("$key:body", "").orEmpty()
        } finally { conn.disconnect() }
    }

    private fun fetchJson(url: String, cacheMinutes: Int = 0): JSONObject? {
        memoryJsonCache[url]?.let { return it }
        return runCatching { JSONObject(fetchText(url, cacheMinutes)) }.getOrNull().also { memoryJsonCache[url] = it }
    }

    private fun List<MediaItem>.dedupeMedia(): List<MediaItem> {
        val seen = linkedSetOf<String>()
        val out = mutableListOf<MediaItem>()
        for (item in this) {
            val idPart = item.externalId.ifBlank { item.streamUrl }.ifBlank { item.title.lowercase(Locale.US) }
            val key = "${item.type.lowercase(Locale.US)}|$idPart|${item.title.lowercase(Locale.US)}"
            if (seen.add(key)) out += item
        }
        return out
    }

    private fun fallback(section: String): List<MediaItem> {
        val shows = listOf("Shōgun", "Fallout", "Halo", "Mayor of Kingstown", "The Last of Us", "Silo")
        val movies = listOf("Dune: Part Two", "The Batman", "Civil War", "Avatar", "Wonka", "The Martian")
        val titles = when (section.lowercase(Locale.US)) {
            "shows", "tv", "series" -> shows
            "resume" -> listOf("No saved progress yet")
            else -> movies
        }
        return titles.mapIndexed { index, title -> MediaItem(title, if (section.lowercase(Locale.US) in listOf("shows", "tv", "series")) "series" else "movie", if (section == "resume") "Continue Watching" else if (index % 2 == 0) "Popular" else "Trending", if (section == "resume") "Paused movies and shows will appear here after playback progress is saved." else "Add a Stremio catalog or TMDB key in Settings to populate this row.", "fallback:$section:$index") }
    }
}
