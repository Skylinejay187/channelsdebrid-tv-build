# Debrid Channels Android TV — Phase 1 Clean Foundation

Built from a new empty Android project. No previous Android source tree was reused.

Apple visual blueprint:

- File: DebridChannels_v984_V983_BASE_SOURCE_INTELLIGENCE_25_50_LIMIT_FIX_GITHUB.zip
- SHA-256: abec9beb6a7f1e54ae95b6414b7b070f896f807d4b0cac5fc3cfed7ee2f85681

## Scope completed

- Kotlin/Compose for TV project foundation
- Android TV launcher manifest and branded banner
- Multi-module model/data/design-system structure
- Apple v984 top navigation and screen hierarchy
- Catalog hero, landscape rows and poster rows
- Four-column Live TV grid
- Details/search/channel-preview shells
- Settings rail and Source Intelligence 25/50 UI
- Standalone/Home Server/Automatic mode contract
- GitHub Actions test/lint/APK/AAB workflow
- Self-contained sample artwork and no required API keys

## Validation completed in this environment

- All XML parsed
- GitHub Actions YAML parsed
- Version catalog TOML parsed
- All Kotlin sources passed structural delimiter checks
- Pure Kotlin model and repository modules compiled with local kotlinc
- Resource references verified
- Custom Gradle bootstrap wrapper compiled into gradle-wrapper.jar
- ZIP integrity test

The container does not include an Android SDK or cached Google Maven artifacts, so the complete Android/Compose compile is intentionally delegated to the included GitHub Actions workflow.
