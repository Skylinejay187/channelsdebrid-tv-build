package com.debridchannels.core.model

enum class AppTab(val label: String) {
    HOME("Home"),
    MOVIES("Movies"),
    SHOWS("TV Shows"),
    SPORTS("Sports"),
    FAVORITES("Favorites"),
    LIVE_TV("Live TV"),
    MEMBERSHIP("Membership"),
    SETTINGS("Settings"),
}

enum class MediaType { MOVIE, SHOW, EPISODE, LIVE_CHANNEL }

enum class ConnectionMode(val label: String) {
    STANDALONE("Standalone"),
    HOME_SERVER("Home Server"),
    AUTOMATIC("Automatic"),
}

data class MediaItem(
    val id: String,
    val title: String,
    val type: MediaType,
    val year: Int,
    val subtitle: String,
    val description: String,
    val posterKey: String,
    val landscapeKey: String,
    val logoText: String = title,
    val genres: List<String> = emptyList(),
    val rating: Double? = null,
    val runtimeMinutes: Int? = null,
    val isFavorite: Boolean = false,
)

data class CatalogRow(
    val id: String,
    val title: String,
    val subtitle: String = "",
    val items: List<MediaItem>,
)

data class LiveChannel(
    val id: String,
    val number: String,
    val name: String,
    val source: String,
    val logoText: String,
    val programTitle: String,
    val programSubtitle: String,
    val artworkKey: String,
    val category: String,
    val isFavorite: Boolean = false,
    val isSports: Boolean = false,
)

data class GuideProgram(
    val channelId: String,
    val title: String,
    val startLabel: String,
    val endLabel: String,
    val description: String,
)

data class SourceResult(
    val id: String,
    val provider: String,
    val title: String,
    val quality: String,
    val sizeLabel: String,
    val cached: Boolean,
)
