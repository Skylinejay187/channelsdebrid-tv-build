package com.debridchannels.core.data

import com.debridchannels.core.model.AppTab
import com.debridchannels.core.model.CatalogRow
import com.debridchannels.core.model.LiveChannel
import com.debridchannels.core.model.MediaItem
import com.debridchannels.core.model.SourceResult

interface DebridRepository {
    fun catalogRows(tab: AppTab): List<CatalogRow>
    fun favorites(): List<MediaItem>
    fun liveChannels(): List<LiveChannel>
    fun sourceResults(limit: Int): List<SourceResult>
}

class ServerConnectionRepository(
    private val fallback: DebridRepository = StandaloneBlueprintRepository(),
) : DebridRepository {
    override fun catalogRows(tab: AppTab): List<CatalogRow> = fallback.catalogRows(tab)
    override fun favorites(): List<MediaItem> = fallback.favorites()
    override fun liveChannels(): List<LiveChannel> = fallback.liveChannels()
    override fun sourceResults(limit: Int): List<SourceResult> = fallback.sourceResults(limit)
}
