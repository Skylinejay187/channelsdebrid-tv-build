package com.debridchannels.core.data

import org.junit.Assert.assertEquals
import org.junit.Test

class SourceLimitTest {
    private val repository = StandaloneBlueprintRepository()

    @Test fun recommendedLimitIsTwentyFive() {
        assertEquals(25, repository.sourceResults(25).size)
    }

    @Test fun expandedLimitIsFifty() {
        assertEquals(50, repository.sourceResults(50).size)
    }

    @Test fun invalidLimitFallsBackToTwentyFive() {
        assertEquals(25, repository.sourceResults(300).size)
    }
}
