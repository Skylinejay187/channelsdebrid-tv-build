# Server Mode Contract Foundation

The same Android UI uses either a standalone or server-backed repository.

```kotlin
interface DebridRepository {
    fun catalogRows(tab: AppTab): List<CatalogRow>
    fun favorites(): List<MediaItem>
    fun liveChannels(): List<LiveChannel>
    fun sourceResults(limit: Int): List<SourceResult>
}
```

Phase 1 contains `StandaloneBlueprintRepository` and a server repository adapter placeholder. Later networking can replace the adapter without duplicating any screen.
