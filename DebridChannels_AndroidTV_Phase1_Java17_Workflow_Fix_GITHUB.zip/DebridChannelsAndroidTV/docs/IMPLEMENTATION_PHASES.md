# Controlled Android TV Implementation Phases

## Phase 1 — Clean UI and workflow foundation

Included in this ZIP.

## Phase 2 — Standalone data services

- Settings persistence
- Stremio catalog manifests
- Metadata/artwork providers
- Search
- Favorites and Continue Watching
- Source Intelligence aggregation with 25/50 cap

## Phase 3 — Playback parity

- Media3 ExoPlayer VOD engine
- Separate Live TV profile
- Audio and subtitle track selection
- Resume and seeking
- Custom VOD overlay
- Cast Wall sleep/wake lifecycle
- Frame-rate matching where the device supports it

## Phase 4 — Live TV

- HDHomeRun discovery
- Channels DVR discovery
- M3U/XMLTV and Xtream
- Full guide
- Exact card focus restoration
- Quick Guide
- Favorites/Sports hold actions

## Phase 5 — Home Server Mode

- Android NSD discovery
- Manual IP fallback
- Pairing and device tokens
- Capability handshake
- Repository mode routing without changing the UI
- Profiles and sync

## Phase 6 — Server plugins and DVR

- Native Debrid Channels catalog plugins
- User-defined catalogs
- EPG and recording scheduler
- Local library imports
- Authorized future TVE adapters
