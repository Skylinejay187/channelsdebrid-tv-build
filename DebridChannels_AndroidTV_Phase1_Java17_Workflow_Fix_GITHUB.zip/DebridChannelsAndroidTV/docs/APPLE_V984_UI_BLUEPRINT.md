# Apple v984 UI Blueprint Mapping

Source reference: `DebridChannels_v984_V983_BASE_SOURCE_INTELLIGENCE_25_50_LIMIT_FIX_GITHUB.zip`.

The Apple source remains untouched and is used only as the design and behavior reference.

## Global shell

- 1920×1080 design baseline
- Pure black application background
- Small Debrid Channels wordmark at the absolute top-left
- Centered top navigation
- Search and live clock on the top-right
- Selected tab underline
- Orange/copper primary accent with optional cyan secondary highlight

## Tabs

1. Home
2. Movies
3. TV Shows
4. Sports
5. Favorites
6. Live TV
7. Membership
8. Settings

The Android shell defaults to Live TV, matching the Apple `CatalogStore` default.

## Top menu mapping

Apple v984:

- 25-point menu typography
- 18-point focused rounded background
- 54-point underline, 64 for Settings
- 4-point underline thickness
- Search icon and clock at the right edge

Android Phase 1 uses proportional TV-safe dp values while preserving the same hierarchy and focus intent.

## Catalog cards

Apple search/catalog reference:

- Landscape card ratio approximately 16:9
- Rounded corners around 20–24
- Focus border and glow instead of uncontrolled card growth
- Title/year/catalog metadata over a lower cinematic gradient

Android Phase 1:

- 318×180 landscape cards
- 178×267 poster cards
- 1.045–1.055 focus scale
- Orange focus border
- Cinematic lower scrim

## Live TV

Apple v984 uses a four-column grid and stores exact channel identity for focus restoration. Phase 1 recreates the four-column visual grid and channel card model. Stateful playback return is implemented with the player phase, not faked in the initial shell.

## Settings

The Apple categories are represented in the same order and visual structure, including:

- Live TV
- Streaming Catalogs
- VOD Player
- Source Intelligence
- New Episode Alerts
- Sports
- Backup / Restore
- Server Connection foundation

## Shared-contract rule

Apple remains SwiftUI/KSPlayer. Android remains Kotlin/Compose for TV/Media3. The shared foundation is the model and API contract, not one cross-platform UI runtime.
