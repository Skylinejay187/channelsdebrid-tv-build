package com.debridchannels.tv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import com.debridchannels.core.designsystem.DebridChannelsTheme
import com.debridchannels.tv.ui.DebridChannelsApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            DebridChannelsTheme {
                DebridChannelsApp()
            }
        }
    }
}
