package com.debridchannels.tv.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import com.debridchannels.core.designsystem.DebridColors
import com.debridchannels.core.model.AppTab
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TopMenuBar(
    selectedTab: AppTab,
    onTabSelected: (AppTab) -> Unit,
    onSearch: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(112.dp)
            .padding(horizontal = 34.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        DebridWordmark()
        Spacer(Modifier.width(112.dp))
        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AppTab.entries.forEach { tab ->
                TopMenuItem(
                    tab = tab,
                    selected = selectedTab == tab,
                    onClick = { onTabSelected(tab) },
                )
            }
        }
        SearchChip(onClick = onSearch)
        Spacer(Modifier.width(22.dp))
        LiveClock()
    }
}

@Composable
private fun DebridWordmark() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "DEBRID",
            color = Color.White.copy(alpha = 0.88f),
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 2.sp,
        )
        Text(
            text = "CHANNELS",
            color = DebridColors.Orange,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.4.sp,
        )
    }
}

@Composable
private fun TopMenuItem(tab: AppTab, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val textColor by animateColorAsState(
        when {
            focused -> Color.Black
            selected -> Color.White
            else -> Color.White.copy(alpha = 0.58f)
        },
        label = "menuText",
    )
    val interaction = remember { MutableInteractionSource() }

    Column(
        modifier = Modifier
            .padding(horizontal = 3.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(if (focused) DebridColors.Orange else Color.Transparent)
            .onFocusChanged { focused = it.isFocused }
            .focusable()
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(horizontal = if (focused) 18.dp else 12.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = tab.label,
            color = textColor,
            fontSize = 18.sp,
            fontWeight = if (selected || focused) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1,
        )
        Spacer(Modifier.height(7.dp))
        Box(
            Modifier
                .width(if (tab == AppTab.SETTINGS) 52.dp else 44.dp)
                .height(3.dp)
                .background(if (selected) DebridColors.Cyan else Color.Transparent, RoundedCornerShape(50)),
        )
    }
}

@Composable
private fun SearchChip(onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val interaction = remember { MutableInteractionSource() }
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(if (focused) DebridColors.Orange else Color.Transparent)
            .onFocusChanged { focused = it.isFocused }
            .focusable()
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text("⌕", fontSize = 27.sp, color = if (focused) Color.Black else Color.White.copy(alpha = 0.78f), textAlign = TextAlign.Center)
    }
}

@Composable
private fun LiveClock() {
    var label by remember { mutableStateOf(currentTimeLabel()) }
    LaunchedEffect(Unit) {
        while (true) {
            label = currentTimeLabel()
            delay(15_000)
        }
    }
    Text(label, color = Color.White.copy(alpha = 0.66f), fontSize = 16.sp, fontWeight = FontWeight.Medium)
}

private fun currentTimeLabel(): String = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
