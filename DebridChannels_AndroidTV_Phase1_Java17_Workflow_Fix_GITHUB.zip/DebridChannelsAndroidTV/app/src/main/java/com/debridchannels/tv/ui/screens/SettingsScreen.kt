package com.debridchannels.tv.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import com.debridchannels.core.designsystem.DebridColors
import com.debridchannels.core.designsystem.FocusSurface
import com.debridchannels.core.model.ConnectionMode

private data class SettingsCategory(val title: String, val subtitle: String)

@Composable
fun SettingsScreen(modifier: Modifier = Modifier) {
    val categories = remember {
        listOf(
            SettingsCategory("Live TV", "DVR, HDHomeRun, M3U"),
            SettingsCategory("Streaming Catalogs", "Stremio JSON catalog URLs"),
            SettingsCategory("VOD Player", "Player and overlay"),
            SettingsCategory("Source Intelligence", "Link limits and providers"),
            SettingsCategory("New Episode Alerts", "Follow Center and banners"),
            SettingsCategory("Sports", "Sources, teams and channels"),
            SettingsCategory("Backup / Restore", "Profile backup codes"),
            SettingsCategory("Server Connection", "Standalone or Home Server"),
        )
    }
    var selectedCategory by remember { mutableIntStateOf(3) }

    Column(modifier.fillMaxSize().background(DebridColors.Black).padding(horizontal = 58.dp, vertical = 20.dp)) {
        Text("Settings", color = Color.White, fontSize = 42.sp, fontWeight = FontWeight.Black)
        Text("Choose a category, then press down to work inside that category.", color = Color.White.copy(alpha = 0.52f), fontSize = 14.sp)
        Spacer(Modifier.height(28.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(categories.indices.toList()) { index ->
                val category = categories[index]
                FocusSurface(
                    onClick = { selectedCategory = index },
                    modifier = Modifier.width(205.dp).height(74.dp),
                    shape = RoundedCornerShape(16.dp),
                    focusedScale = 1.03f,
                ) { focused ->
                    Column(Modifier.padding(horizontal = 18.dp, vertical = 13.dp), verticalArrangement = Arrangement.Center) {
                        Text(category.title, color = if (selectedCategory == index || focused) Color.White else Color.White.copy(alpha = 0.72f), fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text(category.subtitle, color = Color.White.copy(alpha = 0.38f), fontSize = 10.sp, maxLines = 1)
                    }
                }
            }
        }
        Spacer(Modifier.height(34.dp))
        when (selectedCategory) {
            3 -> SourceIntelligenceSettings()
            7 -> ServerConnectionSettings()
            else -> PlaceholderSettings(categories[selectedCategory])
        }
    }
}

@Composable
private fun SourceIntelligenceSettings() {
    var linkLimit by remember { mutableIntStateOf(25) }
    SettingsPanel(title = "Source Intelligence", subtitle = "Link search limits and artwork provider keys") {
        Text("Source Intelligence", color = DebridColors.Cyan, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Text("Choose how many ranked links Source Intelligence should keep per search.", color = Color.White.copy(alpha = 0.66f), fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SettingChoice("✓ 25 Links / Recommended", selected = linkLimit == 25) { linkLimit = 25 }
            SettingChoice("50 Links", selected = linkLimit == 50) { linkLimit = 50 }
        }
        Spacer(Modifier.height(24.dp))
        Text("Artwork Provider Keys", color = DebridColors.Cyan, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Text("Optional keys improve posters, clearlogos, banners, landscapes and Live TV artwork.", color = Color.White.copy(alpha = 0.66f), fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        listOf("TMDB API Key", "Fanart.tv API Key", "OMDb API Key").forEach { label ->
            Box(
                Modifier.fillMaxWidth(0.56f).padding(vertical = 5.dp).background(Color.White.copy(alpha = 0.08f), RoundedCornerShape(14.dp)).padding(16.dp),
            ) {
                Text(label, color = Color.White.copy(alpha = 0.48f), fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun ServerConnectionSettings() {
    var mode by remember { mutableStateOf(ConnectionMode.STANDALONE) }
    SettingsPanel(title = "Debrid Channels Mode", subtitle = "The UI stays identical; only the data source changes") {
        ConnectionMode.entries.forEach { option ->
            SettingChoice(
                text = if (mode == option) "● ${option.label}" else "○ ${option.label}",
                selected = mode == option,
                onClick = { mode = option },
            )
            Spacer(Modifier.height(10.dp))
        }
        Spacer(Modifier.height(14.dp))
        Text(
            if (mode == ConnectionMode.STANDALONE) "Accounts, add-ons, catalogs and Live TV are stored on this device."
            else "Phase 1 includes the server-mode contract and routing foundation; discovery and pairing are implemented in a later phase.",
            color = Color.White.copy(alpha = 0.60f),
            fontSize = 13.sp,
        )
    }
}

@Composable
private fun PlaceholderSettings(category: SettingsCategory) {
    SettingsPanel(category.title, category.subtitle) {
        Text("This category is visually mapped from Apple TV v984 and ready for feature wiring.", color = Color.White.copy(alpha = 0.64f), fontSize = 14.sp)
    }
}

@Composable
private fun SettingsPanel(title: String, subtitle: String, content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth(0.70f).background(Color.Black.copy(alpha = 0.62f), RoundedCornerShape(28.dp)).padding(24.dp),
    ) {
        Text(title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
        Text(subtitle, color = Color.White.copy(alpha = 0.42f), fontSize = 12.sp)
        Spacer(Modifier.height(18.dp))
        content()
    }
}

@Composable
private fun SettingChoice(text: String, selected: Boolean, onClick: () -> Unit) {
    FocusSurface(
        onClick = onClick,
        modifier = Modifier.width(290.dp).height(56.dp),
        shape = RoundedCornerShape(16.dp),
        focusedScale = 1.02f,
    ) { focused ->
        Box(Modifier.fillMaxSize().background(if (selected) DebridColors.Orange.copy(alpha = 0.28f) else Color.Transparent), contentAlignment = Alignment.CenterStart) {
            Text(text, modifier = Modifier.padding(horizontal = 18.dp), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}
