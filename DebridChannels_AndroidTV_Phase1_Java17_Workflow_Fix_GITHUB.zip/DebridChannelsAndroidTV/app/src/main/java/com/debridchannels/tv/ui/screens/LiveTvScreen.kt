package com.debridchannels.tv.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import com.debridchannels.core.designsystem.DebridColors
import com.debridchannels.core.model.LiveChannel
import com.debridchannels.tv.ui.components.LiveTvCard

@Composable
fun LiveTvScreen(
    channels: List<LiveChannel>,
    onChannelSelected: (LiveChannel) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier.fillMaxSize().background(DebridColors.Black).padding(horizontal = 58.dp, vertical = 24.dp)) {
        Text("Live TV", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Text("RIGHT opens the guide • LEFT opens channel tools", color = Color.White.copy(alpha = 0.44f), fontSize = 13.sp)
        Box(Modifier.padding(top = 26.dp)) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                horizontalArrangement = Arrangement.spacedBy(26.dp),
                verticalArrangement = Arrangement.spacedBy(34.dp),
            ) {
                items(channels, key = { it.id }) { channel ->
                    LiveTvCard(channel, onClick = { onChannelSelected(channel) })
                }
            }
        }
    }
}
