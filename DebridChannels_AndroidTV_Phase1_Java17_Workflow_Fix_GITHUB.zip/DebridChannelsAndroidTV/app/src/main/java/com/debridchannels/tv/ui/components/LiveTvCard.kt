package com.debridchannels.tv.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import com.debridchannels.core.designsystem.DebridColors
import com.debridchannels.core.designsystem.FocusSurface
import com.debridchannels.core.designsystem.cinematicScrim
import com.debridchannels.core.model.LiveChannel
import com.debridchannels.tv.ui.artworkResource

@Composable
fun LiveTvCard(channel: LiveChannel, onClick: () -> Unit, modifier: Modifier = Modifier) {
    FocusSurface(
        onClick = onClick,
        modifier = modifier.width(340.dp).height(191.dp),
        shape = RoundedCornerShape(20.dp),
        focusedScale = 1.04f,
    ) { focused ->
        Box(Modifier.fillMaxSize()) {
            Image(
                painter = painterResource(artworkResource(channel.artworkKey)),
                contentDescription = channel.programTitle,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
            Box(Modifier.fillMaxSize().background(cinematicScrim()))
            Column(Modifier.align(Alignment.BottomStart).padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .background(Color.Black.copy(alpha = 0.58f), RoundedCornerShape(10.dp))
                            .padding(horizontal = 8.dp, vertical = 5.dp),
                    ) {
                        Text(channel.logoText, color = DebridColors.Cyan, fontWeight = FontWeight.Black, fontSize = 11.sp)
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(channel.number, color = Color.White.copy(alpha = 0.66f), fontSize = 11.sp)
                }
                Text(
                    channel.programTitle,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = if (focused) 18.sp else 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    channel.name,
                    color = Color.White.copy(alpha = 0.62f),
                    fontSize = 11.sp,
                    maxLines = 1,
                )
            }
        }
    }
}
