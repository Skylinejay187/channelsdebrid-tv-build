package com.debridchannels.tv.ui

import com.debridchannels.tv.R

fun artworkResource(key: String): Int = when (key) {
    "poster_01" -> R.drawable.poster_01
    "poster_02" -> R.drawable.poster_02
    "poster_03" -> R.drawable.poster_03
    "poster_04" -> R.drawable.poster_04
    "poster_05" -> R.drawable.poster_05
    "poster_06" -> R.drawable.poster_06
    "poster_07" -> R.drawable.poster_07
    "poster_08" -> R.drawable.poster_08
    "poster_09" -> R.drawable.poster_09
    "poster_10" -> R.drawable.poster_10
    "poster_11" -> R.drawable.poster_11
    "poster_12" -> R.drawable.poster_12
    "poster_13" -> R.drawable.poster_13
    "poster_14" -> R.drawable.poster_14
    "landscape_01" -> R.drawable.landscape_01
    "landscape_02" -> R.drawable.landscape_02
    "landscape_03" -> R.drawable.landscape_03
    "landscape_04" -> R.drawable.landscape_04
    "landscape_05" -> R.drawable.landscape_05
    "landscape_06" -> R.drawable.landscape_06
    "landscape_07" -> R.drawable.landscape_07
    "landscape_08" -> R.drawable.landscape_08
    "landscape_09" -> R.drawable.landscape_09
    "landscape_10" -> R.drawable.landscape_10
    "landscape_11" -> R.drawable.landscape_11
    "landscape_12" -> R.drawable.landscape_12
    "landscape_13" -> R.drawable.landscape_13
    "landscape_14" -> R.drawable.landscape_14
    else -> R.drawable.landscape_01
}
