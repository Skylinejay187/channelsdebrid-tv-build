package com.debridchannels.tv.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import com.debridchannels.core.designsystem.DebridColors
import com.debridchannels.core.model.CatalogRow
import com.debridchannels.core.model.MediaItem
import com.debridchannels.tv.ui.artworkResource
import com.debridchannels.tv.ui.components.MediaCard
import com.debridchannels.tv.ui.components.PosterCard

@Composable
fun CatalogScreen(
    title: String,
    rows: List<CatalogRow>,
    onItemSelected: (MediaItem) -> Unit,
    modifier: Modifier = Modifier,
    showHero: Boolean = true,
) {
    val hero = rows.firstOrNull()?.items?.firstOrNull()
    Box(modifier.fillMaxSize().background(DebridColors.Black)) {
        if (showHero && hero != null) {
            Image(
                painter = painterResource(artworkResource(hero.landscapeKey)),
                contentDescription = null,
                modifier = Modifier.fillMaxWidth().height(420.dp).align(Alignment.TopCenter),
                contentScale = ContentScale.Crop,
                alpha = 0.54f,
            )
            Box(
                Modifier.fillMaxWidth().height(460.dp).background(
                    Brush.verticalGradient(listOf(Color.Transparent, DebridColors.Black.copy(alpha = 0.55f), DebridColors.Black)),
                ),
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 58.dp, end = 58.dp, top = 26.dp, bottom = 72.dp),
            verticalArrangement = Arrangement.spacedBy(28.dp),
        ) {
            item {
                if (hero != null && showHero) HeroInfo(hero)
                else Text(title, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            }
            items(rows, key = { it.id }) { row ->
                CatalogRowSection(row = row, onItemSelected = onItemSelected)
            }
        }
    }
}

@Composable
private fun HeroInfo(item: MediaItem) {
    Column(Modifier.padding(top = 42.dp).fillMaxWidth(0.56f)) {
        Text(item.logoText, color = Color.White, fontSize = 42.sp, fontWeight = FontWeight.Black, maxLines = 2)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(item.year.toString(), color = Color.White.copy(alpha = 0.70f), fontSize = 15.sp)
            item.rating?.let { Text("★ $it", color = DebridColors.Orange, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
            item.runtimeMinutes?.let { Text("${it}m", color = Color.White.copy(alpha = 0.70f), fontSize = 15.sp) }
        }
        Spacer(Modifier.height(9.dp))
        Text(
            item.description,
            color = Color.White.copy(alpha = 0.78f),
            fontSize = 16.sp,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun CatalogRowSection(row: CatalogRow, onItemSelected: (MediaItem) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(row.title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        if (row.subtitle.isNotBlank()) Text(row.subtitle, color = Color.White.copy(alpha = 0.45f), fontSize = 13.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            items(row.items, key = { it.id }) { item ->
                if (row.id == "watchable") PosterCard(item, onClick = { onItemSelected(item) })
                else MediaCard(item, onClick = { onItemSelected(item) })
            }
        }
    }
}
