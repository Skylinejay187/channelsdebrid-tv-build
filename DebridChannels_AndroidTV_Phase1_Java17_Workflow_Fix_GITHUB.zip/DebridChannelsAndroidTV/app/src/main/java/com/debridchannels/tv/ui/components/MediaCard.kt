package com.debridchannels.tv.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import com.debridchannels.core.designsystem.DebridColors
import com.debridchannels.core.designsystem.FocusSurface
import com.debridchannels.core.designsystem.cinematicScrim
import com.debridchannels.core.model.MediaItem
import com.debridchannels.tv.ui.artworkResource

@Composable
fun MediaCard(item: MediaItem, onClick: () -> Unit, modifier: Modifier = Modifier) {
    FocusSurface(
        onClick = onClick,
        modifier = modifier.width(318.dp).height(180.dp),
        shape = RoundedCornerShape(20.dp),
        focusedScale = 1.045f,
    ) { focused ->
        Box(Modifier.fillMaxSize()) {
            Image(
                painter = painterResource(artworkResource(item.landscapeKey)),
                contentDescription = item.title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
            Box(Modifier.fillMaxSize().background(cinematicScrim()))
            Column(
                modifier = Modifier.align(Alignment.BottomStart).padding(15.dp),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                Text(
                    text = item.title,
                    color = Color.White,
                    fontSize = if (focused) 20.sp else 17.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(item.year.toString(), color = Color.White.copy(alpha = 0.70f), fontSize = 12.sp)
                    Spacer(Modifier.width(7.dp))
                    Text("•", color = DebridColors.Orange, fontSize = 12.sp)
                    Spacer(Modifier.width(7.dp))
                    Text(item.subtitle, color = Color.White.copy(alpha = 0.66f), fontSize = 12.sp, maxLines = 1)
                }
            }
        }
    }
}

@Composable
fun PosterCard(item: MediaItem, onClick: () -> Unit, modifier: Modifier = Modifier) {
    FocusSurface(
        onClick = onClick,
        modifier = modifier.width(178.dp).height(267.dp),
        shape = RoundedCornerShape(20.dp),
        focusedScale = 1.055f,
    ) { focused ->
        Box(Modifier.fillMaxSize()) {
            Image(
                painter = painterResource(artworkResource(item.posterKey)),
                contentDescription = item.title,
                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(20.dp)),
                contentScale = ContentScale.Crop,
            )
            Box(Modifier.fillMaxSize().background(cinematicScrim()))
            Column(Modifier.align(Alignment.BottomStart).padding(13.dp)) {
                Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = if (focused) 17.sp else 15.sp, maxLines = 2)
                Spacer(Modifier.height(3.dp))
                Text(item.year.toString(), color = Color.White.copy(alpha = 0.62f), fontSize = 11.sp)
            }
        }
    }
}
