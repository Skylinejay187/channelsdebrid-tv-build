package com.debridchannels.tv.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.debridchannels.core.data.StandaloneBlueprintRepository
import com.debridchannels.core.designsystem.DebridColors
import com.debridchannels.core.model.AppTab
import com.debridchannels.core.model.LiveChannel
import com.debridchannels.core.model.MediaItem
import com.debridchannels.tv.ui.components.TopMenuBar
import com.debridchannels.tv.ui.screens.CatalogScreen
import com.debridchannels.tv.ui.screens.ChannelPreviewScreen
import com.debridchannels.tv.ui.screens.DetailScreen
import com.debridchannels.tv.ui.screens.LiveTvScreen
import com.debridchannels.tv.ui.screens.SearchScreen
import com.debridchannels.tv.ui.screens.SettingsScreen
import com.debridchannels.tv.ui.screens.SourceResultsScreen

private sealed interface OverlayDestination {
    data class Detail(val item: MediaItem) : OverlayDestination
    data class Channel(val channel: LiveChannel) : OverlayDestination
    data object Search : OverlayDestination
    data class Sources(val item: MediaItem, val limit: Int) : OverlayDestination
}

@Composable
fun DebridChannelsApp() {
    val repository = remember { StandaloneBlueprintRepository() }
    var selectedTab by remember { mutableStateOf(AppTab.LIVE_TV) }
    var overlay by remember { mutableStateOf<OverlayDestination?>(null) }
    var sourceLimit by remember { mutableIntStateOf(25) }

    BackHandler(enabled = overlay != null) { overlay = null }

    Box(Modifier.fillMaxSize().background(DebridColors.Black)) {
        Column(Modifier.fillMaxSize()) {
            TopMenuBar(
                selectedTab = selectedTab,
                onTabSelected = {
                    overlay = null
                    selectedTab = it
                },
                onSearch = { overlay = OverlayDestination.Search },
            )
            Box(Modifier.fillMaxSize().padding(top = 0.dp)) {
                when (selectedTab) {
                    AppTab.HOME -> CatalogScreen("Home", repository.catalogRows(AppTab.HOME), onItemSelected = { overlay = OverlayDestination.Detail(it) })
                    AppTab.MOVIES -> CatalogScreen("Movies", repository.catalogRows(AppTab.MOVIES), onItemSelected = { overlay = OverlayDestination.Detail(it) })
                    AppTab.SHOWS -> CatalogScreen("TV Shows", repository.catalogRows(AppTab.SHOWS), onItemSelected = { overlay = OverlayDestination.Detail(it) })
                    AppTab.SPORTS -> CatalogScreen("Sports", repository.catalogRows(AppTab.HOME), onItemSelected = { overlay = OverlayDestination.Detail(it) }, showHero = false)
                    AppTab.FAVORITES -> CatalogScreen("Favorites", listOf(com.debridchannels.core.model.CatalogRow("favorites", "My Favorites", items = repository.favorites())), onItemSelected = { overlay = OverlayDestination.Detail(it) }, showHero = false)
                    AppTab.LIVE_TV -> LiveTvScreen(repository.liveChannels(), onChannelSelected = { overlay = OverlayDestination.Channel(it) })
                    AppTab.MEMBERSHIP -> CatalogScreen("Membership", repository.catalogRows(AppTab.HOME).take(1), onItemSelected = { overlay = OverlayDestination.Detail(it) }, showHero = false)
                    AppTab.SETTINGS -> SettingsScreen()
                }
            }
        }

        when (val destination = overlay) {
            is OverlayDestination.Detail -> DetailScreen(destination.item, onBack = { overlay = null })
            is OverlayDestination.Channel -> ChannelPreviewScreen(destination.channel, onBack = { overlay = null })
            OverlayDestination.Search -> SearchScreen(onBack = { overlay = null })
            is OverlayDestination.Sources -> SourceResultsScreen(repository.sourceResults(destination.limit), destination.limit, onBack = { overlay = null })
            null -> Unit
        }
    }
}
