# Phase 1 UI foundation has no reflection-based runtime libraries.
