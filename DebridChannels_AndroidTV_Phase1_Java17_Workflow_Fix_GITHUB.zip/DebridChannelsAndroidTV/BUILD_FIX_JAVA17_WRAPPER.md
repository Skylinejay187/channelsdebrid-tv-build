# Android TV Phase 1 — Existing Workflow Compatibility Fix

The GitHub Actions log failed before Gradle started:

- Workflow Java runtime: Java 17 (class version 61)
- Previous bundled wrapper bootstrap: Java 21 (class version 65)

This package recompiles only `gradle/wrapper/gradle-wrapper.jar` for Java 17.

No UI, Kotlin source, Android resources, Gradle dependency versions, application behavior, or Apple-v984 parity work changed.

The existing repository workflow named **Build Android TV APK from ZIP** can be used unchanged.
The wrapper will download and run Gradle 8.13 from `gradle-wrapper.properties`.
