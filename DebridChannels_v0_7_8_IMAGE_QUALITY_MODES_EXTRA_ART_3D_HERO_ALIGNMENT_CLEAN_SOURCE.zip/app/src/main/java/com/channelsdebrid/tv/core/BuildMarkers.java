package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.7.8 Image Quality Modes + Hero Alignment";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.7.8_image_quality_modes_extra_art_3d_focus_hero_alignment_clean_base";
}
