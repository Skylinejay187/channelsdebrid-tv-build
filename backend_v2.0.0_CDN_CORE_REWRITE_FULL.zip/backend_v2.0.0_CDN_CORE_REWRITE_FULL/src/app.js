
const http = require('http');
const fs = require('fs');
const path = require('path');
const { sendJson, sendText, notFound, badRequest, serverError, readJsonBody, parseRequestUrl } = require('./utils/http');
const { MemoryCache, ensureDir } = require('./services/cacheService');
const { proxyImage } = require('./services/imageService');
const { normalizeStream, normalizeCatalogItem, fetchJson, joinAddonUrl } = require('./services/addonService');

const PORT = Number(process.env.PORT || 8181);
const PUBLIC_BASE_URL = process.env.PUBLIC_BASE_URL || `http://localhost:${PORT}`;
const CACHE_DIR = path.resolve(process.env.CACHE_DIR || path.join(process.cwd(), 'cache'));
const responseCache = new MemoryCache();
ensureDir(CACHE_DIR);
ensureDir(path.join(CACHE_DIR, 'images'));

const TTL = {
  image: Number(process.env.IMAGE_CACHE_TTL_SECONDS || 2592000),
  metadata: Number(process.env.METADATA_CACHE_TTL_SECONDS || 21600),
  addon: Number(process.env.ADDON_CACHE_TTL_SECONDS || 900),
  stream: Number(process.env.STREAM_CACHE_TTL_SECONDS || 120)
};

function cdnHeaders(kind = 'metadata') {
  const seconds = TTL[kind] || TTL.metadata;
  return {
    'Cache-Control': `public, max-age=${seconds}, s-maxage=${seconds}, stale-while-revalidate=60`,
    'X-Debrid-Channels-Backend': 'v2.0.0-cdn-core'
  };
}

function noStoreHeaders() { return { 'Cache-Control': 'no-store', 'X-Debrid-Channels-Backend': 'v2.0.0-cdn-core' }; }

function cachedJson(res, key, ttl, producer, headers) {
  const cached = responseCache.get(key);
  if (cached) return sendJson(res, 200, { ...cached, cache: 'hit' }, headers);
  producer().then(body => {
    responseCache.set(key, body, ttl);
    sendJson(res, 200, { ...body, cache: 'miss' }, headers);
  }).catch(err => serverError(res, err));
}

function rewriteArtwork(value) {
  if (!value || !/^https?:\/\//i.test(value)) return value || '';
  return `${PUBLIC_BASE_URL}/api/image?url=${encodeURIComponent(value)}`;
}

async function handleAddonManifest(url, res) {
  const manifestUrl = url.searchParams.get('url');
  if (!manifestUrl) return badRequest(res, 'missing_url');
  cachedJson(res, `manifest:${manifestUrl}`, TTL.addon, async () => {
    const manifest = await fetchJson(manifestUrl);
    return { ok: true, manifestUrl, manifest };
  }, cdnHeaders('addon'));
}

async function handleAddonCatalog(url, res) {
  const manifestUrl = url.searchParams.get('url');
  const type = url.searchParams.get('type') || 'movie';
  const id = url.searchParams.get('id') || 'top';
  const extra = url.searchParams.get('extra') || '';
  if (!manifestUrl) return badRequest(res, 'missing_url');
  const route = `catalog/${encodeURIComponent(type)}/${encodeURIComponent(id)}${extra ? '/' + extra : ''}.json`;
  const target = joinAddonUrl(manifestUrl, route);
  cachedJson(res, `catalog:${target}`, TTL.metadata, async () => {
    const data = await fetchJson(target);
    const metas = (data.metas || data.items || []).map(normalizeCatalogItem).map(item => ({
      ...item,
      poster: rewriteArtwork(item.poster),
      background: rewriteArtwork(item.background),
      logo: rewriteArtwork(item.logo)
    }));
    return { ok: true, target, metas, raw: data };
  }, cdnHeaders('metadata'));
}

async function handleAddonMeta(url, res) {
  const manifestUrl = url.searchParams.get('url');
  const type = url.searchParams.get('type') || 'movie';
  const id = url.searchParams.get('id');
  if (!manifestUrl || !id) return badRequest(res, 'missing_url_or_id');
  const target = joinAddonUrl(manifestUrl, `meta/${encodeURIComponent(type)}/${encodeURIComponent(id)}.json`);
  cachedJson(res, `meta:${target}`, TTL.metadata, async () => {
    const data = await fetchJson(target);
    const meta = data.meta || data;
    const normalized = normalizeCatalogItem(meta);
    normalized.poster = rewriteArtwork(normalized.poster);
    normalized.background = rewriteArtwork(normalized.background);
    normalized.logo = rewriteArtwork(normalized.logo);
    return { ok: true, target, meta: normalized, raw: data };
  }, cdnHeaders('metadata'));
}

async function handleAddonStreams(url, res) {
  const manifestUrl = url.searchParams.get('url');
  const type = url.searchParams.get('type') || 'movie';
  const id = url.searchParams.get('id');
  if (!manifestUrl || !id) return badRequest(res, 'missing_url_or_id');
  const target = joinAddonUrl(manifestUrl, `stream/${encodeURIComponent(type)}/${encodeURIComponent(id)}.json`);
  cachedJson(res, `streams:${target}`, TTL.stream, async () => {
    const manifest = await fetchJson(manifestUrl).catch(() => ({}));
    const addonName = manifest.name || '';
    const data = await fetchJson(target);
    const streams = (data.streams || []).map(s => normalizeStream(s, addonName));
    const grouped = streams.reduce((acc, s) => {
      const key = s.provider || 'Other';
      if (!acc[key]) acc[key] = [];
      acc[key].push(s);
      return acc;
    }, {});
    return { ok: true, target, addonName, streams, grouped, all: streams, raw: data };
  }, cdnHeaders('stream'));
}

async function handleImage(url, res) {
  const raw = url.searchParams.get('url');
  if (!raw) return badRequest(res, 'missing_url');
  try {
    const image = await proxyImage(raw, { cacheDir: CACHE_DIR, timeoutMs: 15000 });
    res.writeHead(200, {
      'Content-Type': image.contentType,
      'Content-Length': image.bytes,
      'Cache-Control': `public, max-age=${TTL.image}, s-maxage=${TTL.image}, immutable`,
      'Access-Control-Allow-Origin': '*',
      'X-Image-Cache': image.cache,
      'X-Debrid-Channels-Backend': 'v2.0.0-cdn-core'
    });
    fs.createReadStream(image.filePath).pipe(res);
  } catch (err) { serverError(res, err); }
}

function handleRoot(res) {
  sendJson(res, 200, {
    ok: true,
    name: 'Debrid Channels Backend',
    version: '2.0.0_CDN_CORE_REWRITE',
    publicBaseUrl: PUBLIC_BASE_URL,
    endpoints: [
      '/api/health',
      '/api/image?url=<encoded-image-url>',
      '/api/addon/manifest?url=<manifest-url>',
      '/api/addon/catalog?url=<manifest-url>&type=movie&id=top',
      '/api/addon/meta?url=<manifest-url>&type=movie&id=tt1234567',
      '/api/addon/streams?url=<manifest-url>&type=movie&id=tt1234567',
      '/api/cache/status'
    ]
  }, cdnHeaders('metadata'));
}

const server = http.createServer(async (req, res) => {
  const url = parseRequestUrl(req, PUBLIC_BASE_URL);
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type,Authorization' });
    return res.end();
  }
  try {
    if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/api')) return handleRoot(res);
    if (req.method === 'GET' && (url.pathname === '/health' || url.pathname === '/api/health')) return sendJson(res, 200, { ok: true, version: '2.0.0_CDN_CORE_REWRITE', time: new Date().toISOString() }, noStoreHeaders());
    if (req.method === 'GET' && url.pathname === '/api/cache/status') return sendJson(res, 200, { ok: true, memory: responseCache.stats(), cacheDir: CACHE_DIR, ttl: TTL }, noStoreHeaders());
    if (req.method === 'GET' && url.pathname === '/api/image') return handleImage(url, res);
    if (req.method === 'GET' && url.pathname === '/api/addon/manifest') return handleAddonManifest(url, res);
    if (req.method === 'GET' && url.pathname === '/api/addon/catalog') return handleAddonCatalog(url, res);
    if (req.method === 'GET' && url.pathname === '/api/addon/meta') return handleAddonMeta(url, res);
    if (req.method === 'GET' && (url.pathname === '/api/addon/streams' || url.pathname === '/api/streams')) return handleAddonStreams(url, res);
    if (req.method === 'POST' && url.pathname === '/api/cache/clear') { responseCache.items.clear(); return sendJson(res, 200, { ok: true, cleared: true }, noStoreHeaders()); }
    return notFound(res);
  } catch (err) { return serverError(res, err); }
});

server.listen(PORT, () => {
  console.log(`[DebridChannelsBackend] v2.0.0_CDN_CORE_REWRITE listening on ${PORT}`);
  console.log(`[DebridChannelsBackend] PUBLIC_BASE_URL=${PUBLIC_BASE_URL}`);
});
