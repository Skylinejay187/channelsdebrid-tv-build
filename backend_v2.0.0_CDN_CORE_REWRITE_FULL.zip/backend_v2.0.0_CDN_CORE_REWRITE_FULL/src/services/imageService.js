
const fs = require('fs');
const path = require('path');
const { stableKey, ensureDir } = require('./cacheService');

const MIME_EXT = {
  'image/jpeg': '.jpg',
  'image/jpg': '.jpg',
  'image/png': '.png',
  'image/webp': '.webp',
  'image/avif': '.avif'
};

function isAllowedUrl(rawUrl) {
  let u;
  try { u = new URL(rawUrl); } catch { return false; }
  const allowed = String(process.env.ALLOWED_PROXY_PROTOCOLS || 'http:,https:').split(',').map(s => s.trim());
  return allowed.includes(u.protocol);
}

async function proxyImage(rawUrl, options) {
  if (!rawUrl || !isAllowedUrl(rawUrl)) throw new Error('invalid_or_disallowed_image_url');
  const cacheDir = options.cacheDir;
  const imageDir = path.join(cacheDir, 'images');
  ensureDir(imageDir);
  const key = stableKey(rawUrl);
  const metaPath = path.join(imageDir, `${key}.json`);
  if (fs.existsSync(metaPath)) {
    const meta = JSON.parse(fs.readFileSync(metaPath, 'utf8'));
    const filePath = path.join(imageDir, meta.fileName);
    if (fs.existsSync(filePath)) return { ...meta, filePath, cache: 'hit' };
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), options.timeoutMs || 15000);
  let response;
  try {
    response = await fetch(rawUrl, { signal: controller.signal, headers: { 'User-Agent': 'DebridChannelsBackend/2.0 image-proxy' } });
  } finally { clearTimeout(timeout); }
  if (!response.ok) throw new Error(`image_fetch_failed_${response.status}`);
  const contentType = (response.headers.get('content-type') || 'application/octet-stream').split(';')[0].trim().toLowerCase();
  if (!contentType.startsWith('image/')) throw new Error(`not_an_image_${contentType}`);
  const maxBytes = Number(process.env.MAX_IMAGE_BYTES || 15 * 1024 * 1024);
  const arr = new Uint8Array(await response.arrayBuffer());
  if (arr.byteLength > maxBytes) throw new Error('image_too_large');
  const ext = MIME_EXT[contentType] || '.img';
  const fileName = `${key}${ext}`;
  const filePath = path.join(imageDir, fileName);
  fs.writeFileSync(filePath, Buffer.from(arr));
  const meta = { fileName, contentType, bytes: arr.byteLength, sourceUrl: rawUrl, cachedAt: new Date().toISOString() };
  fs.writeFileSync(metaPath, JSON.stringify(meta, null, 2));
  return { ...meta, filePath, cache: 'miss' };
}

module.exports = { proxyImage };
