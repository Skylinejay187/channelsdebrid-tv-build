
function detectProvider(text) {
  const value = String(text || '').toLowerCase();
  if (value.includes('mediafusion')) return 'MediaFusion';
  if (value.includes('torbox')) return 'Torbox';
  if (value.includes('torrentio')) return 'Torrentio';
  if (value.includes('comet')) return 'Comet';
  if (value.includes('cinemeta')) return 'Cinemeta';
  return 'Other';
}

function detectQuality(text) {
  const value = String(text || '').toLowerCase();
  if (/2160|4k|uhd/.test(value)) return '4K';
  if (/1080/.test(value)) return '1080p';
  if (/720/.test(value)) return '720p';
  if (/480/.test(value)) return '480p';
  return 'Unknown';
}

function detectHdr(text) {
  const value = String(text || '').toLowerCase();
  if (value.includes('dolby vision') || value.includes('dv')) return 'Dolby Vision';
  if (value.includes('hdr10+')) return 'HDR10+';
  if (value.includes('hdr')) return 'HDR';
  return '';
}

function normalizeStream(stream, addonName = '') {
  const title = stream.title || stream.name || stream.description || '';
  const combined = `${addonName} ${stream.name || ''} ${stream.title || ''}`;
  return {
    provider: detectProvider(combined),
    addon: addonName || detectProvider(combined),
    name: stream.name || stream.title || 'Stream',
    title,
    quality: detectQuality(combined),
    hdr: detectHdr(combined),
    size: stream.size || stream.sizeText || '',
    behaviorHints: stream.behaviorHints || null,
    url: stream.url || stream.externalUrl || '',
    externalUrl: stream.externalUrl || '',
    raw: stream
  };
}

function normalizeCatalogItem(item) {
  return {
    id: item.id || item.imdb_id || item.slug || item.name,
    type: item.type || '',
    title: item.name || item.title || '',
    poster: item.poster || '',
    background: item.background || item.backdrop || '',
    logo: item.logo || item.clearLogo || '',
    description: item.description || '',
    releaseInfo: item.releaseInfo || item.year || '',
    raw: item
  };
}

async function fetchJson(url, ttlMs = 15000) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), ttlMs);
  try {
    const res = await fetch(url, { signal: controller.signal, headers: { 'User-Agent': 'DebridChannelsBackend/2.0 addon-proxy' } });
    if (!res.ok) throw new Error(`fetch_failed_${res.status}`);
    return await res.json();
  } finally { clearTimeout(timeout); }
}

function addonBaseFromManifestUrl(manifestUrl) {
  const u = new URL(manifestUrl);
  const parts = u.pathname.split('/').filter(Boolean);
  if (parts[parts.length - 1] === 'manifest.json') parts.pop();
  u.pathname = '/' + parts.join('/');
  if (!u.pathname.endsWith('/')) u.pathname += '/';
  u.search = '';
  u.hash = '';
  return u.toString();
}

function joinAddonUrl(manifestUrl, route) {
  return new URL(route.replace(/^\/+/, ''), addonBaseFromManifestUrl(manifestUrl)).toString();
}

module.exports = { detectProvider, detectQuality, normalizeStream, normalizeCatalogItem, fetchJson, joinAddonUrl };
