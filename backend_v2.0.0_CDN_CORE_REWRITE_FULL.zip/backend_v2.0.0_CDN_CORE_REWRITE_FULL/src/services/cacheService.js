
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class MemoryCache {
  constructor() { this.items = new Map(); }
  get(key) {
    const item = this.items.get(key);
    if (!item) return null;
    if (item.expiresAt && item.expiresAt < Date.now()) { this.items.delete(key); return null; }
    return item.value;
  }
  set(key, value, ttlSeconds) {
    this.items.set(key, { value, expiresAt: ttlSeconds ? Date.now() + ttlSeconds * 1000 : 0 });
  }
  delete(key) { this.items.delete(key); }
  stats() { return { entries: this.items.size }; }
}

function stableKey(value) {
  return crypto.createHash('sha256').update(String(value)).digest('hex');
}

function ensureDir(dir) { fs.mkdirSync(dir, { recursive: true }); }

function cacheFilePath(cacheDir, namespace, key, ext = '.json') {
  const dir = path.join(cacheDir, namespace);
  ensureDir(dir);
  return path.join(dir, `${stableKey(key)}${ext}`);
}

module.exports = { MemoryCache, stableKey, ensureDir, cacheFilePath };
