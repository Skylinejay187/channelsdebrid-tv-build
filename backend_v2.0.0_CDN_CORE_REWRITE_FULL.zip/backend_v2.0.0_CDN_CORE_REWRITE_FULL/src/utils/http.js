
const { URL } = require('url');

function sendJson(res, status, body, headers = {}) {
  const data = Buffer.from(JSON.stringify(body, null, 2));
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': data.length,
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    ...headers
  });
  res.end(data);
}

function sendText(res, status, body, headers = {}) {
  const data = Buffer.from(String(body));
  res.writeHead(status, {
    'Content-Type': 'text/plain; charset=utf-8',
    'Content-Length': data.length,
    'Access-Control-Allow-Origin': '*',
    ...headers
  });
  res.end(data);
}

function notFound(res) { sendJson(res, 404, { ok: false, error: 'not_found' }, { 'Cache-Control': 'no-store' }); }
function badRequest(res, error) { sendJson(res, 400, { ok: false, error }, { 'Cache-Control': 'no-store' }); }
function serverError(res, error) { sendJson(res, 500, { ok: false, error: error && error.message ? error.message : String(error) }, { 'Cache-Control': 'no-store' }); }

async function readJsonBody(req, limit = 1024 * 1024) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > limit) throw new Error('request_body_too_large');
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}

function parseRequestUrl(req, publicBaseUrl) {
  return new URL(req.url, publicBaseUrl || 'http://localhost');
}

module.exports = { sendJson, sendText, notFound, badRequest, serverError, readJsonBody, parseRequestUrl };
