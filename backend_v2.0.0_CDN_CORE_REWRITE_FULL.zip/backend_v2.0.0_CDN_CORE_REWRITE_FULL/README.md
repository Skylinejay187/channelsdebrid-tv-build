# Debrid Channels Backend v2.0.0 - CDN Core Rewrite

This is a clean CDN-ready backend for Debrid Channels. It is designed to run on your NAS first, then sit behind Cloudflare later.

## What this backend does

- `/api/image?url=` image proxy with local disk cache and CDN headers
- Stremio addon proxy endpoints for manifest, catalog, meta, and streams
- Normalized stream provider tagging for MediaFusion, Torbox, Torrentio, Comet, Cinemeta, and Other
- In-memory response cache with safe TTLs
- CDN-ready `Cache-Control` headers
- Preserves v1.8.2 legacy source as `legacy-server-v1.8.2.js` and `legacy-lib-v1.8.2.js` for reference

## What this backend does NOT do

- It does not CDN/cache actual debrid/video playback URLs.
- It does not rewrite protected streaming URLs.
- It does not store user credentials.

## Quick start

```bash
npm run check
npm start
```

Default URL:

```text
http://192.168.100.55:8181
```

Override with:

```bash
PORT=8181 PUBLIC_BASE_URL=http://192.168.100.55:8181 npm start
```

## Docker

```bash
docker compose up -d --build
```

## Test endpoints

Health:

```text
/api/health
```

Image proxy:

```text
/api/image?url=https%3A%2F%2Fexample.com%2Fposter.jpg
```

Addon manifest:

```text
/api/addon/manifest?url=<encoded_manifest_url>
```

Addon streams:

```text
/api/addon/streams?url=<encoded_manifest_url>&type=movie&id=tt1234567
```

## Cloudflare cache rules to add later

Cache aggressively:

```text
/api/image*
```

Cache short/medium:

```text
/api/addon/catalog*
/api/addon/meta*
/api/addon/manifest*
```

Cache very short or bypass if needed:

```text
/api/addon/streams*
```

Never cache future auth/profile routes.
