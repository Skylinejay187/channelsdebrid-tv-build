
const http = require('http');
const { URL } = require('url');
const { execFile } = require('child_process');
const {
  loadHomeRows,
  loadState,
  refreshCatalogs,
  DEFAULT_SOURCES
} = require('./lib');

const port = Number(process.env.PORT || 8181);
const publicBaseUrl = process.env.PUBLIC_BASE_URL || `http://localhost:${port}`;

function liveDisabled(res) {
  return json(res, 410, {
    ok: false,
    disabled: true,
    message: 'Live TV provider handling was moved to the Android app. Configure Channels DVR Direct, M3U, or Xtream/IPTV in app settings.'
  });
}



const trailerCache = new Map();
const inflightTrailerResolves = new Map();
const TRAILER_CACHE_TTL_MS = Number(process.env.TRAILER_CACHE_TTL_MS || 6 * 60 * 60 * 1000);
const YTDLP_TIMEOUT_MS = Number(process.env.YTDLP_TIMEOUT_MS || 30000);


function ytDlpCandidates() {
  const raw = [
    process.env.YTDLP_BIN,
    '/usr/local/bin/yt-dlp',
    '/usr/bin/yt-dlp',
    'yt-dlp'
  ].filter(Boolean);
  return [...new Set(raw)];
}

function execYtDlp(args, timeoutMs = 60000) {
  return new Promise((resolve, reject) => {
    const candidates = ytDlpCandidates();
    let index = 0;
    const tryNext = (lastError) => {
      if (index >= candidates.length) {
        const err = lastError || new Error('yt-dlp not found');
        err.message = `yt-dlp failed. Tried: ${candidates.join(', ')}\n${err.message}`;
        return reject(err);
      }
      const bin = candidates[index++];
      execFile(bin, args, {
        timeout: timeoutMs,
        maxBuffer: 1024 * 1024 * 25,
        env: { ...process.env, PATH: `/usr/local/bin:/usr/bin:/bin:${process.env.PATH || ''}` }
      }, (err, stdout, stderr) => {
        if (err) {
          err.message = [err.message, stderr].filter(Boolean).join('\n');
          if (err.code === 'ENOENT') return tryNext(err);
          return reject(err);
        }
        resolve({ stdout, stderr, bin });
      });
    };
    tryNext();
  });
}

async function execYtDlpStdout(args, timeoutMs = 60000) {
  const result = await execYtDlp(args, timeoutMs);
  return result.stdout;
}


function cleanTitleForTrailer(title) {
  return String(title || '')
    .replace(/\s*[•|-]\s*(S\d+|Season\s+\d+|Episode\s+\d+|E\d+).*$/i, '')
    .replace(/\s*\((19|20)\d{2}\)\s*$/i, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function trailerSearchQuery(title, year) {
  const clean = cleanTitleForTrailer(title);
  return [clean, year, 'official trailer'].filter(Boolean).join(' ');
}

function normalizeQualityLabel(height, fallback = 'best') {
  if (!height) return fallback;
  if (height >= 2160) return '2160p 4K';
  if (height >= 1440) return '1440p';
  if (height >= 1080) return '1080p';
  return `${height}p`;
}

function titleTokens(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9 ]+/g, ' ')
    .split(/\s+/)
    .filter(t => t.length > 1 && !['the','and','official','trailer','teaser','movie','film','series','season','clip','hd','4k','uhd'].includes(t));
}

function scoreTrailerCandidate(entry, requestedTitle, requestedYear) {
  const reqTokens = titleTokens(cleanTitleForTrailer(requestedTitle));
  const haystack = `${entry.title || ''} ${entry.channel || ''} ${entry.uploader || ''} ${entry.description || ''}`.toLowerCase();
  let score = 0;
  for (const token of reqTokens) {
    if (haystack.includes(token)) score += 12;
    else score -= 18;
  }
  if (/official trailer/i.test(entry.title || '')) score += 40;
  if (/trailer/i.test(entry.title || '')) score += 15;
  if (/teaser/i.test(entry.title || '')) score -= 8;
  if (/fan\s*made|concept|reaction|review|breakdown|explained|clip|scene|music video/i.test(entry.title || '')) score -= 80;
  if (/official/i.test(`${entry.channel || ''} ${entry.uploader || ''}`)) score += 20;
  if (/warner|universal|paramount|marvel|disney|pixar|netflix|prime video|hulu|hbo|max|20th century|sony pictures|lionsgate|a24/i.test(`${entry.channel || ''} ${entry.uploader || ''}`)) score += 16;
  if (requestedYear && haystack.includes(String(requestedYear))) score += 12;
  const duration = Number(entry.duration || 0);
  if (duration > 0) {
    if (duration >= 45 && duration <= 240) score += 10;
    if (duration > 420) score -= 30;
  }
  return score;
}

function bestTrailerEntry(info, requestedTitle, requestedYear) {
  const entries = Array.isArray(info.entries) ? info.entries.filter(Boolean) : [info].filter(Boolean);
  if (!entries.length) throw new Error('No trailer results found');
  return entries
    .map(entry => ({ entry, score: scoreTrailerCandidate(entry, requestedTitle, requestedYear) }))
    .sort((a, b) => b.score - a.score)[0].entry;
}

function bestMuxedFormat(formats, prefer4k) {
  const withAudioVideo = (formats || []).filter(f => f.url && f.vcodec && f.vcodec !== 'none' && f.acodec && f.acodec !== 'none');
  const maxHeight = prefer4k ? 2160 : 1080;
  const minPreferredHeight = prefer4k ? 1080 : 720;
  return withAudioVideo
    .filter(f => !f.height || f.height <= maxHeight)
    .sort((a, b) => {
      const ah = a.height || 0;
      const bh = b.height || 0;
      const aPreferred = ah >= minPreferredHeight ? 1 : 0;
      const bPreferred = bh >= minPreferredHeight ? 1 : 0;
      return bPreferred - aPreferred || bh - ah || (b.tbr || 0) - (a.tbr || 0);
    })[0] || null;
}

function pickTrailerInfo(info, prefer4k, requestedTitle, requestedYear) {
  const chosen = bestTrailerEntry(info, requestedTitle, requestedYear);
  if (!chosen) throw new Error('No trailer results found');

  const formats = Array.isArray(chosen.formats) ? chosen.formats : [];
  const heights = formats.map(f => Number(f.height || 0)).filter(Boolean);
  const maxAvailableHeight = heights.length ? Math.max(...heights) : 0;
  const has4k = maxAvailableHeight >= 2160;
  const has1080 = maxAvailableHeight >= 1080;

  const manifestUrl = chosen.dash_url || chosen.manifest_url || chosen.hls_url || '';
  if (manifestUrl && (prefer4k || has1080)) {
    return {
      videoId: chosen.id || '',
      title: chosen.title || '',
      channel: chosen.channel || chosen.uploader || '',
      duration: chosen.duration || 0,
      playbackUrl: manifestUrl,
      mimeType: manifestUrl.includes('.m3u8') ? 'application/x-mpegURL' : 'application/dash+xml',
      quality: has4k && prefer4k ? '2160p 4K adaptive' : (has1080 ? '1080p adaptive' : normalizeQualityLabel(maxAvailableHeight, 'adaptive')),
      maxHeight: maxAvailableHeight,
      fallbackUsed: prefer4k && !has4k,
      source: 'yt-dlp-adaptive-manifest'
    };
  }

  const muxed = bestMuxedFormat(chosen.formats || [], prefer4k);
  if (muxed) {
    return {
      videoId: chosen.id || '',
      title: chosen.title || '',
      channel: chosen.channel || chosen.uploader || '',
      duration: chosen.duration || 0,
      playbackUrl: muxed.url,
      mimeType: muxed.ext === 'm3u8' ? 'application/x-mpegURL' : 'video/mp4',
      quality: muxed.format_note || normalizeQualityLabel(muxed.height, 'best'),
      maxHeight: muxed.height || 0,
      fallbackUsed: prefer4k && (muxed.height || 0) < 2160,
      source: 'yt-dlp-direct-muxed'
    };
  }

  if (chosen.url) {
    return {
      videoId: chosen.id || '',
      title: chosen.title || '',
      channel: chosen.channel || chosen.uploader || '',
      duration: chosen.duration || 0,
      playbackUrl: chosen.url,
      mimeType: 'video/mp4',
      quality: chosen.format_note || 'best',
      source: 'yt-dlp-direct'
    };
  }
  throw new Error('No playable trailer stream found');
}


function pickBestVideoAudioFormats(formats, prefer4k) {
  const maxHeight = prefer4k ? 2160 : 1080;
  const minHeight = prefer4k ? 1080 : 720;
  const videoOnly = (formats || []).filter(f =>
    f && f.url && f.vcodec && f.vcodec !== 'none' && (!f.acodec || f.acodec === 'none') && Number(f.height || 0) <= maxHeight
  ).sort((a, b) => {
    const ah = Number(a.height || 0), bh = Number(b.height || 0);
    const ap = ah >= minHeight ? 1 : 0, bp = bh >= minHeight ? 1 : 0;
    const aMp4 = String(a.ext || '').toLowerCase() === 'mp4' ? 1 : 0;
    const bMp4 = String(b.ext || '').toLowerCase() === 'mp4' ? 1 : 0;
    return bp - ap || bh - ah || bMp4 - aMp4 || Number(b.tbr || 0) - Number(a.tbr || 0);
  });
  const audioOnly = (formats || []).filter(f =>
    f && f.url && (!f.vcodec || f.vcodec === 'none') && f.acodec && f.acodec !== 'none'
  ).sort((a, b) => {
    const aM4a = String(a.ext || '').toLowerCase() === 'm4a' ? 1 : 0;
    const bM4a = String(b.ext || '').toLowerCase() === 'm4a' ? 1 : 0;
    return bM4a - aM4a || Number(b.abr || b.tbr || 0) - Number(a.abr || a.tbr || 0);
  });
  const progressive = bestMuxedFormat(formats || [], prefer4k);
  return { video: videoOnly[0] || null, audio: audioOnly[0] || null, progressive };
}

function formatPayloadFromInfo(info, prefer4k, originalUrl) {
  const requestedFormats = Array.isArray(info.requested_formats) ? info.requested_formats : [];
  const formats = requestedFormats.length ? requestedFormats : (Array.isArray(info.formats) ? info.formats : []);
  const { video, audio, progressive } = pickBestVideoAudioFormats(formats, prefer4k);
  const height = Number((video && video.height) || (progressive && progressive.height) || info.height || 0);
  const payload = {
    ok: true,
    extractor: 'yt-dlp',
    id: info.id || '',
    title: info.title || '',
    webpageUrl: info.webpage_url || originalUrl,
    requestedUrl: originalUrl,
    quality: normalizeQualityLabel(height, prefer4k ? 'best up to 4K' : 'best up to 1080p'),
    height,
    maxHeight: height,
    source: video && audio ? 'yt-dlp-split-dash' : 'yt-dlp-progressive',
    expiresAt: new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString()
  };
  if (video && audio) {
    payload.videoUrl = video.url;
    payload.audioUrl = audio.url;
    payload.video_url = video.url;
    payload.audio_url = audio.url;
    payload.videoMimeType = video.ext === 'webm' ? 'video/webm' : 'video/mp4';
    payload.audioMimeType = audio.ext === 'webm' ? 'audio/webm' : 'audio/mp4';
    payload.playbackUrl = video.url;
    payload.mimeType = payload.videoMimeType;
    payload.format = {
      video: { id: video.format_id, ext: video.ext, height: video.height, fps: video.fps, vcodec: video.vcodec, tbr: video.tbr },
      audio: { id: audio.format_id, ext: audio.ext, acodec: audio.acodec, abr: audio.abr, tbr: audio.tbr }
    };
    return payload;
  }
  if (progressive && progressive.url) {
    payload.playbackUrl = progressive.url;
    payload.url = progressive.url;
    payload.merged = progressive.url;
    payload.mergedUrl = progressive.url;
    payload.mimeType = progressive.ext === 'm3u8' ? 'application/x-mpegURL' : 'video/mp4';
    payload.format = { progressive: { id: progressive.format_id, ext: progressive.ext, height: progressive.height, vcodec: progressive.vcodec, acodec: progressive.acodec, tbr: progressive.tbr } };
    return payload;
  }
  if (info.url) {
    payload.playbackUrl = info.url;
    payload.url = info.url;
    payload.merged = info.url;
    payload.mergedUrl = info.url;
    payload.mimeType = inferMimeFromUrl(info.url);
    return payload;
  }
  throw new Error('No playable trailer URLs found in yt-dlp response');
}

async function extractTrailerStreams(videoUrl, prefer4k) {
  const cacheKey = ['extract-v182', videoUrl, prefer4k ? '4k' : '1080'].join('|');
  const cached = trailerCache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) return { ...cached.value, cached: true };

  // IMPORTANT: do NOT force the Android YouTube client here. On many videos that
  // client only exposes itag 18 / 360p progressive to yt-dlp, even when `yt-dlp -F`
  // shows 1080p/4K DASH formats. Use the normal web extractor and force split
  // DASH first so the app can merge video+audio with Media3.
  const maxHeight = prefer4k ? 2160 : 1080;
  const format = [
    `bestvideo[height<=${maxHeight}][height>=1080][ext=mp4]+bestaudio[ext=m4a]`,
    `bestvideo[height<=${maxHeight}][height>=1080]+bestaudio`,
    `bestvideo[height<=${maxHeight}]+bestaudio`,
    `best[height<=${maxHeight}][height>=720]`,
    `best[height<=${maxHeight}]`,
    'best'
  ].join('/');

  const stdout = await execYtDlpStdout([
    '--dump-single-json', '--no-playlist', '--no-warnings', '--skip-download', '--force-ipv4',
    '--format', format,
    '--format-sort', 'res,ext:mp4:m4a',
    videoUrl
  ], YTDLP_TIMEOUT_MS);
  const info = JSON.parse(stdout);
  const payload = formatPayloadFromInfo(info, prefer4k, videoUrl);

  // Hard guard: if a 1080p/4K video still resolves as 360p progressive, tell the
  // client/backend log the truth instead of silently pretending this is HD.
  if ((payload.height || 0) < 720 && payload.source === 'yt-dlp-progressive') {
    payload.warning = 'yt-dlp returned only low progressive from this extractor response; check cookies/age/region restrictions or run yt-dlp -F on the same host.';
  }
  const value = {
    ...payload,
    trailer: {
      playbackUrl: payload.playbackUrl,
      videoUrl: payload.videoUrl,
      audioUrl: payload.audioUrl,
      video_url: payload.video_url,
      audio_url: payload.audio_url,
      mimeType: payload.mimeType,
      videoMimeType: payload.videoMimeType,
      audioMimeType: payload.audioMimeType,
      quality: payload.quality,
      maxHeight: payload.maxHeight,
      height: payload.height,
      title: payload.title,
      source: payload.source
    }
  };
  trailerCache.set(cacheKey, { value, expiresAt: Date.now() + TRAILER_CACHE_TTL_MS });
  return value;
}

function candidateVideoId(entry) {
  return entry && (entry.id || entry.url || entry.webpage_url || '');
}

async function resolveTrailer({ title, year, prefer4k, mediaId, mediaType }) {
  const cleanTitle = cleanTitleForTrailer(title);
  const scopedId = String(mediaId || '').trim();
  const scopedType = String(mediaType || '').trim();
  const cacheKey = [scopedType, scopedId, cleanTitle, year, prefer4k].join('|').toLowerCase();
  const cached = trailerCache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) return { ...cached.value, cached: true };
  if (inflightTrailerResolves.has(cacheKey)) return await inflightTrailerResolves.get(cacheKey);

  const promise = (async () => {
    const query = trailerSearchQuery(cleanTitle, year);
    let chosenTitle = '';
    let videoUrl = `ytsearch1:${query}`;

    // Real HD path: score a trailer candidate, then extract split DASH video+audio.
    let value;
    try {
      const searchStdout = await execYtDlpStdout([
        '--dump-single-json',
        '--no-playlist',
        '--no-warnings',
        '--skip-download',
        '--force-ipv4',
        '--extractor-args', 'youtube:player_client=android,web,tv_embedded',
        'ytsearch5:' + query
      ], YTDLP_TIMEOUT_MS);
      const searchInfo = JSON.parse(searchStdout);
      const chosen = bestTrailerEntry(searchInfo, cleanTitle, year);
      chosenTitle = chosen.title || '';
      const id = candidateVideoId(chosen);
      if (id) videoUrl = String(id).startsWith('http') ? id : `https://www.youtube.com/watch?v=${id}`;
    } catch (err) {
      chosenTitle = '';
      videoUrl = `ytsearch1:${query}`;
    }
    value = await extractTrailerStreams(videoUrl, prefer4k);

    value.searchTitle = chosenTitle || value.title || query;
    value.query = query;
    value.resolvedAt = new Date().toISOString();
    trailerCache.set(cacheKey, { value, expiresAt: Date.now() + TRAILER_CACHE_TTL_MS });
    return value;
  })().finally(() => inflightTrailerResolves.delete(cacheKey));


  inflightTrailerResolves.set(cacheKey, promise);
  return await promise;
}
function json(res, statusCode, payload, options = {}) {
  const body = JSON.stringify(payload, null, 2);
  const cacheControl = options.cacheControl || 'no-store';
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': cacheControl
  });
  res.end(body);
}

function notFound(res, url) {
  return json(res, 404, {
    ok: false,
    error: 'Not found',
    path: url.pathname
  });
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 1024 * 1024) {
        reject(new Error('Request body too large'));
        req.destroy();
      }
    });
    req.on('end', () => {
      if (!body) return resolve({});
      try {
        resolve(JSON.parse(body));
      } catch (err) {
        reject(new Error('Invalid JSON body'));
      }
    });
    req.on('error', reject);
  });
}

function getUserId(url, req) {
  return url.searchParams.get('user_id') || url.searchParams.get('userId') || req.headers['x-user-id'] || '';
}

const epgSettings = { refreshEveryHours: Number(process.env.EPG_REFRESH_EVERY_HOURS || 6), durationHours: 12, backgroundDurationHours: Number(process.env.EPG_BACKGROUND_DURATION_HOURS || 48) };
const iconCache = new Map();
function channelIconUrlFor(userId, channelId) {
  const view = getLiveUserView(userId || 'demo');
  const wanted = normalizeKey(channelId);
  const channel = (view.channels || []).find(ch => [ch.id, ch.externalId, ch.name, ch.number].map(normalizeKey).includes(wanted));
  return channel && (channel.logo || channel.icon || channel.image || '');
}
function proxyChannelIcon(res, userId, channelId) {
  const sourceUrl = channelIconUrlFor(userId, channelId);
  if (!sourceUrl) return json(res, 404, { ok: false, error: 'Icon not found' });
  const cached = iconCache.get(sourceUrl);
  if (cached && cached.expiresAt > Date.now()) {
    res.writeHead(200, { 'Content-Type': cached.contentType || 'image/png', 'Cache-Control': 'public, max-age=86400' });
    return res.end(cached.buffer);
  }
  const client = sourceUrl.startsWith('https:') ? require('https') : require('http');
  client.get(sourceUrl, upstream => {
    const chunks = [];
    upstream.on('data', chunk => chunks.push(chunk));
    upstream.on('end', () => {
      const buffer = Buffer.concat(chunks);
      const contentType = upstream.headers['content-type'] || 'image/png';
      if (upstream.statusCode === 200 && buffer.length) iconCache.set(sourceUrl, { buffer, contentType, expiresAt: Date.now() + 24 * 60 * 60 * 1000 });
      res.writeHead(upstream.statusCode || 200, { 'Content-Type': contentType, 'Cache-Control': 'public, max-age=86400' });
      res.end(buffer);
    });
  }).on('error', err => json(res, 502, { ok: false, error: err.message }));
}
const epgJobs = new Map();
function epgProgress(userId) { const key = userId || 'demo'; if (!epgJobs.has(key)) epgJobs.set(key, { ok: true, running: false, userId: key, stage: 'idle', message: 'Guide refresh idle', percent: 0, startedAt: null, finishedAt: null, error: null }); return epgJobs.get(key); }
function setEpgProgress(userId, patch) { const current = epgProgress(userId); Object.assign(current, patch, { userId: userId || 'demo', updatedAt: new Date().toISOString() }); return current; }
function startEpgRefresh(userId, durationHours, force) { const uid = userId || 'demo'; setEpgProgress(uid, { ok: false, running: false, stage: 'disabled', percent: 100, message: 'Live TV guide refresh moved to Android app local provider cache.', finishedAt: new Date().toISOString(), durationHours: Number(durationHours || epgSettings.durationHours || 12) }); return epgProgress(uid); }


function normalizeKey(value) {
  return String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
}
function programFromNowNext(entry, fallbackTitle) {
  if (!entry) return null;
  const title = entry.title || entry.name || fallbackTitle || 'No information';
  return { title, name: title, description: entry.description || '', start: entry.start || entry.startLabel || '', end: entry.end || entry.endLabel || '', startLabel: entry.start || entry.startLabel || '', endLabel: entry.end || entry.endLabel || '', imageUrl: entry.image || entry.poster || entry.backdrop || '', poster: entry.poster || entry.image || '', backdrop: entry.backdrop || '' };
}
function guidePayloadForRequest(url, userId) {
  const channelId = url.searchParams.get('channel_id') || url.searchParams.get('channelId') || '';
  const channelName = url.searchParams.get('channelName') || url.searchParams.get('name') || '';
  const channelNumber = url.searchParams.get('channelNumber') || url.searchParams.get('number') || '';
  const tvgId = url.searchParams.get('tvgId') || url.searchParams.get('tvg_id') || '';
  const view = getLiveUserView(userId);
  const wanted = [channelId, channelName, channelNumber, tvgId].map(normalizeKey).filter(Boolean);
  let channels = view.channels || [];
  let selected = null;
  if (wanted.length) {
    selected = channels.find(ch => [ch.id, ch.externalId, ch.name, ch.number].map(normalizeKey).some(v => v && wanted.includes(v))) || null;
    channels = selected ? [selected] : [];
  }
  let programs = [];
  if (selected) {
    if (Array.isArray(selected.programs) && selected.programs.length) {
      programs = selected.programs.slice(0, 12);
    } else {
      const now = programFromNowNext(selected.current, selected.name);
      const next = programFromNowNext(selected.next, 'Upcoming');
      if (now) programs.push(now);
      if (next) programs.push(next);
    }
  }
  return { view, channels, selected, programs };
}


function mediaItemsFromHomeRows(typeFilter) {
  const home = loadHomeRows();
  const rails = Array.isArray(home.rails) ? home.rails : [];
  const out = [];
  for (const rail of rails) {
    const items = Array.isArray(rail.items) ? rail.items : [];
    for (const item of items) {
      const type = item.type === "series" || item.streamLookupType === "series" ? "series" : "movie";
      if (typeFilter && type !== typeFilter) continue;
      out.push({
        id: item.id || item.streamLookupId || item.imdbId || item.title,
        externalId: item.imdbId || item.streamLookupId || item.id || "",
        type,
        title: item.title || item.name || "Untitled",
        name: item.title || item.name || "Untitled",
        meta: [item.source || rail.source || "Stremio Catalog", item.year || ""].filter(Boolean).join(" • "),
        overview: item.overview || item.description || "",
        description: item.overview || item.description || "",
        poster: item.poster || item.posterUrl || "",
        posterUrl: item.poster || item.posterUrl || "",
        background: item.backdrop || item.background || item.poster || "",
        backdropUrl: item.backdrop || item.background || item.poster || "",
        logo: item.logo || item.logoUrl || ""
      });
    }
  }
  const seen = new Set();
  return out.filter(item => {
    const key = `${item.type}|${item.externalId || item.title}`.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function searchMediaItems(query) {
  const q = String(query || '').trim().toLowerCase();
  const all = mediaItemsFromHomeRows(null);
  if (!q) return all.slice(0, 120);
  const tokens = q.split(/\s+/).filter(Boolean);
  return all.map(item => {
    const haystack = `${item.title} ${item.meta} ${item.overview}`.toLowerCase();
    const score = tokens.reduce((acc, token) => acc + (haystack.includes(token) ? 1 : 0), 0) + (item.title.toLowerCase().includes(q) ? 5 : 0);
    return { item, score };
  }).filter(x => x.score > 0).sort((a, b) => b.score - a.score).map(x => x.item).slice(0, 120);
}

async function handle(req, res) {
  const url = new URL(req.url, publicBaseUrl);
  if (url.pathname === '/live' || url.pathname.startsWith('/live/') || url.pathname === '/guide' || url.pathname.startsWith('/epg') || url.pathname.startsWith('/api/live/')) {
    return liveDisabled(res);
  }


  if (req.method === 'GET' && (url.pathname === '/health' || url.pathname === '/api/health')) {
    return json(res, 200, {
      ok: true,
      service: 'channels-debrid-backend',
      port,
      publicBaseUrl,
      lastRefreshAt: loadState().lastRefreshAt
    });
  }

  if (req.method === 'GET' && url.pathname === '/api/home') {
    return json(res, 200, loadHomeRows(), { cacheControl: 'public, max-age=60' });
  }

  if (req.method === 'GET' && url.pathname === '/api/catalog/movies') {
    return json(res, 200, { ok: true, items: mediaItemsFromHomeRows('movie') }, { cacheControl: 'public, max-age=120' });
  }

  if (req.method === 'GET' && url.pathname === '/api/catalog/shows') {
    return json(res, 200, { ok: true, items: mediaItemsFromHomeRows('series') }, { cacheControl: 'public, max-age=120' });
  }

  if (req.method === 'GET' && url.pathname === '/api/search') {
    return json(res, 200, { ok: true, items: searchMediaItems(url.searchParams.get('q') || '') }, { cacheControl: 'public, max-age=60' });
  }

  if (req.method === 'GET' && (url.pathname === '/performance/status' || url.pathname === '/api/performance/status')) {
    const userId = getUserId(url, req) || 'demo';
    const view = getLiveUserView(userId);
    return json(res, 200, {
      ok: true,
      engine: 'channels-debrid-performance-engine-v9',
      userId,
      modules: {
        liveTv: { enabled: true, channels: (view.channels || []).length, groups: (view.groups || []).length, epg: epgProgress(userId) },
        posters: { enabled: true, source: 'backend-catalog-cache' },
        trailers: { enabled: true, cacheEntries: trailerCache.size, inflight: inflightTrailerResolves.size, playback: 'media3-nuvio-style-client' },
        icons: { enabled: true, cacheEntries: iconCache.size }
      },
      settings: epgSettings,
      generatedAt: view.generatedAt
    });
  }

  if (req.method === 'GET' && (url.pathname.startsWith('/icons/') || url.pathname.startsWith('/live/icons/') || url.pathname.startsWith('/api/live/icons/'))) {
    const userId = getUserId(url, req) || 'demo';
    const channelId = decodeURIComponent(url.pathname.split('/').pop() || '');
    return proxyChannelIcon(res, userId, channelId);
  }

  if (req.method === 'GET' && url.pathname === '/api/sources') {
    return json(res, 200, {
      configuredSources: DEFAULT_SOURCES.map(({ preferredCatalogs, maxRails, ...rest }) => ({ ...rest, preferredCatalogs, maxRails })),
      state: loadState()
    });
  }

  if (req.method === 'POST' && url.pathname === '/api/refresh') {
    try {
      const result = await refreshCatalogs();
      return json(res, 200, { ok: true, ...result });
    } catch (err) {
      return json(res, 500, { ok: false, error: err.message });
    }
  }

  if (req.method === 'GET' && url.pathname === '/live/sources') {
    const userId = getUserId(url, req);
    if (!userId) return json(res, 400, { ok: false, error: 'user_id is required' });
    return json(res, 200, { ok: true, userId, sources: listLiveSources(userId) });
  }

  if (req.method === 'POST' && url.pathname === '/live/sources/connect') {
    try {
      const body = await readBody(req);
      const userId = body.userId || body.user_id;
      const sources = upsertLiveSource(userId, body);
      await refreshLiveData({ userId });
      return json(res, 200, { ok: true, userId, sources });
    } catch (err) {
      return json(res, 400, { ok: false, error: err.message });
    }
  }


  if (req.method === 'POST' && (url.pathname === '/live/epg/settings' || url.pathname === '/api/live/epg/settings')) {
    try {
      const body = await readBody(req).catch(() => ({}));
      epgSettings.refreshEveryHours = Number(body.refreshEveryHours ?? epgSettings.refreshEveryHours ?? 6);
      epgSettings.durationHours = Number(body.durationHours ?? epgSettings.durationHours ?? 12);
      return json(res, 200, { ok: true, settings: epgSettings });
    } catch (err) {
      return json(res, 400, { ok: false, error: err.message });
    }
  }

  if (req.method === 'POST' && (url.pathname === '/live/epg/refresh' || url.pathname === '/api/live/epg/refresh' || url.pathname === '/epg/refresh' || url.pathname === '/api/epg/refresh')) {
    try {
      const body = await readBody(req).catch(() => ({}));
      const userId = body.userId || body.user_id || getUserId(url, req) || 'demo';
      const durationHours = Number(body.durationHours || url.searchParams.get('durationHours') || epgSettings.durationHours || 12);
      const force = body.force !== false;
      const job = startEpgRefresh(userId, durationHours, force);
      return json(res, 202, { ok: true, accepted: true, userId, progress: job });
    } catch (err) {
      return json(res, 500, { ok: false, error: err.message });
    }
  }

  if (req.method === 'GET' && (url.pathname === '/live/epg/status' || url.pathname === '/live/epg/progress' || url.pathname === '/api/live/epg/status' || url.pathname === '/api/live/epg/progress' || url.pathname === '/epg/status' || url.pathname === '/api/epg/status')) {
    const userId = getUserId(url, req) || 'demo';
    return json(res, 200, { ok: true, settings: epgSettings, progress: epgProgress(userId) });
  }

  if (req.method === 'GET' && (url.pathname === '/live/epg' || url.pathname === '/api/live/epg' || url.pathname === '/api/live/guide' || url.pathname === '/api/guide' || url.pathname === '/guide' || url.pathname === '/epg/guide' || url.pathname === '/api/epg/guide')) {
    const userId = getUserId(url, req) || 'demo';
    const { view, channels, selected, programs } = guidePayloadForRequest(url, userId);
    return json(res, 200, { ok: true, userId, generatedAt: view.generatedAt, progress: epgProgress(userId), channel: selected, programs, guide: programs, channels: channels.map(channel => ({ id: channel.id, externalId: channel.externalId, number: channel.number, name: channel.name, group: channel.group, groups: channel.groups || (channel.group ? [channel.group] : []), current: channel.current, next: channel.next, logo: channel.logo, icon: channel.logo ? '/icons/' + encodeURIComponent(channel.id) + '.png' : '', poster: channel.poster, backdrop: channel.backdrop })) });
  }

  if (req.method === 'GET' && url.pathname === '/live/channels') {
    const userId = getUserId(url, req);
    if (!userId) return json(res, 400, { ok: false, error: 'user_id is required' });
    const view = getLiveUserView(userId);
    return json(res, 200, {
      ok: true,
      userId,
      generatedAt: view.generatedAt,
      source: 'live-control-plane',
      channels: view.channels,
      groups: view.groups
    });
  }

  if (req.method === 'GET' && url.pathname === '/live/guide') {
    const userId = getUserId(url, req) || 'demo';
    let cachedView = getLiveUserView(userId);
    if (url.searchParams.get('refresh') === '1' || !(cachedView.channels || []).length) {
      try { await refreshLiveData({ userId }); } catch (err) { setEpgProgress(userId, { ok: false, running: false, stage: 'failed', error: err.message, message: 'Guide refresh failed' }); }
    }
    const { view, channels, selected, programs } = guidePayloadForRequest(url, userId);
    return json(res, 200, { ok: true, userId, generatedAt: view.generatedAt, channel: selected, programs, guide: programs, channels: channels.map(channel => ({ id: channel.id, externalId: channel.externalId, number: channel.number, name: channel.name, group: channel.group, groups: channel.groups || (channel.group ? [channel.group] : []), streamUrl: channel.streamUrl, programs: channel.programs || [], current: channel.current, next: channel.next, logo: channel.logo, icon: channel.logo ? '/icons/' + encodeURIComponent(channel.id) + '.png' : '', poster: channel.poster, backdrop: channel.backdrop })) });
  }

  if (req.method === 'GET' && url.pathname.startsWith('/live/channel/')) {
    const userId = getUserId(url, req);
    if (!userId) return json(res, 400, { ok: false, error: 'user_id is required' });
    const channelId = decodeURIComponent(url.pathname.split('/').pop() || '');
    const channel = getChannelById(userId, channelId);
    if (!channel) return json(res, 404, { ok: false, error: 'Channel not found' });
    return json(res, 200, { ok: true, userId, channel });
  }

  if (req.method === 'GET' && url.pathname === '/live/quick-guide') {
    const userId = getUserId(url, req);
    if (!userId) return json(res, 400, { ok: false, error: 'user_id is required' });
    const channelId = url.searchParams.get('channel_id') || '';
    const view = getLiveUserView(userId);
    return json(res, 200, {
      ok: true,
      userId,
      source: 'live-control-plane',
      quickGuide: buildQuickGuide(view.channels, channelId)
    });
  }

  if (req.method === 'POST' && url.pathname === '/live/playback/resolve') {
    try {
      const body = await readBody(req);
      const userId = body.userId || body.user_id;
      const channelId = body.channelId || body.channel_id;
      if (!userId || !channelId) return json(res, 400, { ok: false, error: 'userId and channelId are required' });
      return json(res, 200, { ok: true, playback: resolvePlayback(userId, channelId) });
    } catch (err) {
      return json(res, 400, { ok: false, error: err.message });
    }
  }

  if (req.method === 'POST' && url.pathname === '/live/refresh') {
    try {
      const body = await readBody(req).catch(() => ({}));
      const userId = body.userId || body.user_id || getUserId(url, req) || undefined;
      const result = await refreshLiveData({ userId });
      return json(res, 200, { ok: true, generatedAt: result.generatedAt, users: userId ? [userId] : Object.keys(result.users) });
    } catch (err) {
      return json(res, 500, { ok: false, error: err.message });
    }
  }


  if (req.method === 'GET' && (
    url.pathname === '/trailers/extractor/status' ||
    url.pathname === '/api/trailers/extractor/status' ||
    url.pathname === '/api/trailer/extractor/status'
  )) {
    try {
      const result = await execYtDlp(['--version'], 10000);
      return json(res, 200, {
        ok: true,
        extractor: 'yt-dlp',
        installed: true,
        bin: result.bin,
        version: String(result.stdout || '').trim(),
        candidates: ytDlpCandidates(),
        timeoutMs: YTDLP_TIMEOUT_MS,
        path: process.env.PATH || '',
        ytdlpBinEnv: process.env.YTDLP_BIN || '',
        checkedAt: new Date().toISOString()
      }, { cacheControl: 'no-store' });
    } catch (err) {
      return json(res, 500, {
        ok: false,
        extractor: 'yt-dlp',
        installed: false,
        error: err.message,
        candidates: ytDlpCandidates(),
        path: process.env.PATH || '',
        ytdlpBinEnv: process.env.YTDLP_BIN || '',
        checkedAt: new Date().toISOString()
      }, { cacheControl: 'no-store' });
    }
  }


  if (req.method === 'GET' && (
    url.pathname === '/trailers/extract' ||
    url.pathname === '/api/trailers/extract' ||
    url.pathname === '/trailer/extract' ||
    url.pathname === '/api/trailer/extract'
  )) {
    try {
      const videoUrl = (url.searchParams.get('url') || '').trim();
      if (!videoUrl) return json(res, 400, { ok: false, error: 'url is required' }, { cacheControl: 'no-store' });
      const prefer4k = url.searchParams.get('quality') === '4k' || url.searchParams.get('prefer4k') === '1';
      const extracted = await extractTrailerStreams(videoUrl, prefer4k);
      return json(res, 200, extracted, { cacheControl: 'private, max-age=300' });
    } catch (err) {
      return json(res, 502, { ok: false, error: err.message, path: url.pathname }, { cacheControl: 'no-store' });
    }
  }

  if (req.method === 'GET' && (
    url.pathname === '/trailers/extractor/resolve' ||
    url.pathname === '/api/trailers/extractor/resolve'
  )) {
    try {
      const videoUrl = (url.searchParams.get('url') || '').trim();
      if (!videoUrl) return json(res, 400, { ok: false, error: 'url is required' });
      const prefer4k = url.searchParams.get('quality') === '4k' || url.searchParams.get('prefer4k') === '1';
      const trailer = await resolveTrailerUrlDirect(videoUrl, prefer4k);
      return json(res, 200, { ok: true, trailer }, { cacheControl: 'private, max-age=300' });
    } catch (err) {
      return json(res, 502, { ok: false, error: err.message }, { cacheControl: 'no-store' });
    }
  }

  if (req.method === 'POST' && url.pathname === '/trailers/prewarm') {
    try {
      const body = await readBody(req);
      const items = Array.isArray(body.items) ? body.items.slice(0, 24) : [];
      const prefer4k = false;
      for (const item of items) {
        const title = String(item.title || '').trim();
        if (!title) continue;
        const year = String(item.year || '').trim();
        resolveTrailer({ title, year, prefer4k, mediaId: item.id || item.externalId || item.tmdbId || item.imdbId || title, mediaType: item.type || item.mediaType || "movie" }).catch(() => {});
      }
      return json(res, 202, { ok: true, queued: items.length }, { cacheControl: 'no-store' });
    } catch (err) {
      return json(res, 400, { ok: false, error: err.message || 'Invalid prewarm request' });
    }
  }

  if (req.method === 'GET' && url.pathname.startsWith('/api/trailer/')) {
    try {
      const id = decodeURIComponent(url.pathname.split('/').pop() || '');
      const title = (url.searchParams.get('title') || id || '').trim();
      const year = (url.searchParams.get('year') || '').trim();
      const prefer4k = false;
      const mediaType = (url.searchParams.get('mediaType') || url.searchParams.get('type') || 'movie').trim();
      if (!title) return json(res, 400, { ok: false, error: 'title is required' });
      const trailer = await resolveTrailer({ title, year, prefer4k, mediaId: id, mediaType });
      return json(res, 200, { ok: true, trailer }, { cacheControl: 'private, max-age=600' });
    } catch (err) {
      return json(res, 502, { ok: false, error: err.message });
    }
  }

  if (req.method === 'GET' && url.pathname === '/trailers/resolve') {
    try {
      const title = (url.searchParams.get('title') || '').trim();
      const year = (url.searchParams.get('year') || '').trim();
      const prefer4k = false;
      const mediaId = (url.searchParams.get('mediaId') || url.searchParams.get('id') || '').trim();
      const mediaType = (url.searchParams.get('mediaType') || url.searchParams.get('type') || '').trim();
      if (!title) return json(res, 400, { ok: false, error: 'title is required' });
      const trailer = await resolveTrailer({ title, year, prefer4k, mediaId, mediaType });
      return json(res, 200, { ok: true, trailer }, { cacheControl: 'private, max-age=600' });
    } catch (err) {
      return json(res, 502, { ok: false, error: err.message });
    }
  }

  if (req.method === 'GET' && url.pathname === '/') {
    return json(res, 200, {
      ok: true,
      message: 'Channels Debrid backend is running',
      endpoints: [
        '/health',
        '/api/health',
        '/api/home',
        '/api/sources',
        '/api/refresh',
        '/live/sources',
        '/live/channels',
        '/live/guide',
        '/live/quick-guide',
        '/live/playback/resolve',
        '/live/refresh',
        '/trailers/extractor/status',
        '/trailers/extract',
        '/trailers/resolve',
        '/trailers/prewarm',
        '/api/trailer/:id'
      ]
    });
  }

  return notFound(res, url);
}

function inferMimeFromUrl(url) {
  const lower = String(url || '').toLowerCase();
  if (lower.includes('.m3u8')) return 'application/x-mpegURL';
  if (lower.includes('.mpd')) return 'application/dash+xml';
  if (lower.includes('mime=video%2fmp4') || lower.includes('mime=video/mp4')) return 'video/mp4';
  return 'video/mp4';
}

function firstPlayableUrl(stdout) {
  return String(stdout || '')
    .split(/\r?\n/)
    .map(s => s.trim())
    .filter(Boolean)
    .find(s => /^https?:\/\//i.test(s)) || '';
}

async function resolveTrailerUrlDirect(videoUrl, prefer4k) {
  const format = prefer4k
    ? 'b[height<=2160][height>=1080][ext=mp4]/b[height<=2160][height>=1080]/22/b[height<=1080][height>=720]/best[height<=2160][height>=720]/best[height<=2160]/best'
    : 'b[height<=1080][height>=720][ext=mp4]/b[height<=1080][height>=720]/22/best[height<=1080][height>=720]/best[height<=1080]/best';
  const stdout = await execYtDlpStdout([
    '--no-playlist',
    '--no-warnings',
    '--force-ipv4',
    '--format', format,
    '--extractor-args', 'youtube:player_client=android,web,tv_embedded',
    '--get-url',
    videoUrl
  ], YTDLP_TIMEOUT_MS);
  const playbackUrl = firstPlayableUrl(stdout);
  if (!playbackUrl) throw new Error('yt-dlp did not return a playable URL');
  return {
    videoId: videoUrl,
    title: '',
    channel: '',
    duration: 0,
    playbackUrl,
    mimeType: inferMimeFromUrl(playbackUrl),
    quality: prefer4k ? 'best up to 4K direct' : 'best up to 1080p direct',
    maxHeight: prefer4k ? 2160 : 1080,
    fallbackUsed: true,
    source: 'yt-dlp-get-url-direct'
  };
}

const server = http.createServer((req, res) => {
  handle(req, res).catch((err) => {
    json(res, 500, { ok: false, error: err.message });
  });
});

server.listen(port, '0.0.0.0', () => {
  console.log(`Channels Debrid backend listening on 0.0.0.0:${port}`);
  refreshCatalogs().then((result) => {
    console.log('Warm catalog refresh complete', result.generatedAt || 'ok');
  }).catch((err) => {
    console.warn('Warm catalog refresh failed:', err.message);
  });
});
