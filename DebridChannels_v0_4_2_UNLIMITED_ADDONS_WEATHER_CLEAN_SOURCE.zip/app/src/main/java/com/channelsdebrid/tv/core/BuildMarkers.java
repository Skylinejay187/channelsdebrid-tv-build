package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.4.2 UNLIMITED ADDONS + WEATHER HUB";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.4.2_unlimited_stremio_addons_weather_hub_clean_base";
    private BuildMarkers() {}
}
