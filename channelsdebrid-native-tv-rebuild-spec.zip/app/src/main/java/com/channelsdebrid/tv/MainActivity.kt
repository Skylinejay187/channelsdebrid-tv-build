package com.channelsdebrid.tv

import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.channelsdebrid.tv.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    data class TitleCard(
        val title: String,
        val meta: String,
        val desc: String,
        val badge: String,
        val backgroundRes: Int
    )

    private val heroTitles = listOf(
        TitleCard("SHŌGUN", "S1 E7: A Stick of Time  •  43 min left", "A premium lean-back presentation for your media center, with live TV, trending shows, smart recommendations, and instant playback.", "⚑  Instant Playback Ready", R.drawable.bg_shogun),
        TitleCard("THE BATMAN", "2h 56m  •  IMAX", "A darker detective spotlight with premium backdrop changes and clean TV-safe row alignment.", "⚑  Direct Play Ready", R.drawable.bg_batman),
        TitleCard("FALLOUT", "49 min left  •  Prime", "Post-apocalyptic action with large-format hero art and poster rows that stay locked in place.", "⚑  Synced to Library", R.drawable.bg_fallout),
        TitleCard("DUNE", "2h 35m  •  Max", "Expansive cinema-style focus treatment with large typography and backdrop-driven navigation.", "⚑  HDR Available", R.drawable.bg_dune),
        TitleCard("HALO", "Series  •  Prime", "Sci-fi recommendations rendered in the same composition language as your reference shot.", "⚑  Resume Synced", R.drawable.bg_halo),
        TitleCard("WONKA", "Movie  •  Max", "Bright contrast title art for spotlight and recently-added rows without breaking the layout grid.", "⚑  Trailer Ready", R.drawable.bg_wonka),
        TitleCard("MAYOR OF KINGSTOWN", "Series  •  Paramount+", "Grounded drama hero state with full-screen poster changes as focus moves across rows.", "⚑  Watched on Device", R.drawable.bg_mayor),
        TitleCard("CIVIL WAR", "Movie  •  109 min", "Poster rows line up under the hero exactly so the screen still feels premium and intentional.", "⚑  Cache Eligible", R.drawable.bg_civilwar),
        TitleCard("AVATAR", "Movie  •  Disney+", "High-contrast blockbuster art for the lower row examples and future trailer pop-up placement.", "⚑  Dolby Vision", R.drawable.bg_avatar)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setHero(heroTitles.first())
        populateRows()
        wireTopControls()
    }

    private fun wireTopControls() {
        val focusables = listOf(
            binding.menuButton,
            binding.homeButton,
            binding.navResume,
            binding.navSmart,
            binding.navLive,
            binding.navMovies,
            binding.continueButton,
            binding.settingsCard
        )

        focusables.forEach { v ->
            v.setOnFocusChangeListener { view, hasFocus ->
                view.scaleX = if (hasFocus) 1.05f else 1f
                view.scaleY = if (hasFocus) 1.05f else 1f
                view.alpha = if (hasFocus) 1f else 0.96f
            }
        }
    }

    private fun populateRows() {
        val rowOneItems = listOf(heroTitles[0], heroTitles[1], heroTitles[2], heroTitles[3], heroTitles[4])
        val rowTwoItems = listOf(heroTitles[7], heroTitles[2], heroTitles[3], heroTitles[5], heroTitles[6], heroTitles[8])

        rowOneItems.forEach { binding.rowOne.addView(makeCard(it, 178, 132)) }
        rowTwoItems.forEach { binding.rowTwo.addView(makeCard(it, 166, 118)) }
    }

    private fun makeCard(item: TitleCard, widthDp: Int, heightDp: Int): View {
        val density = resources.displayMetrics.density
        val widthPx = (widthDp * density).toInt()
        val heightPx = (heightDp * density).toInt()
        val radiusPad = (14 * density).toInt()
        val marginEnd = (14 * density).toInt()
        val titlePad = (10 * density).toInt()

        val frame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(widthPx, heightPx).apply {
                rightMargin = marginEnd
            }
            isFocusable = true
            isClickable = true
            foreground = ContextCompat.getDrawable(this@MainActivity, R.drawable.focus_ring)
            background = ContextCompat.getDrawable(this@MainActivity, item.backgroundRes)
            setPadding(0,0,0,0)
        }

        val overlay = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.card_overlay)
        }

        val title = TextView(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START).apply {
                leftMargin = titlePad
                bottomMargin = titlePad
            }
            text = item.title
            setTextColor(0xFFFFFFFF.toInt())
            textSize = if (widthDp >= 178) 20f else 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

        frame.addView(overlay)
        frame.addView(title)

        frame.setOnFocusChangeListener { view, hasFocus ->
            view.scaleX = if (hasFocus) 1.035f else 1f
            view.scaleY = if (hasFocus) 1.035f else 1f
            view.alpha = if (hasFocus) 1f else 0.97f
            if (hasFocus) setHero(item)
        }

        return frame
    }

    private fun setHero(item: TitleCard) {
        binding.heroBackdrop.setImageDrawable(safeDrawable(item.backgroundRes))
        binding.heroTitle.text = item.title
        binding.heroMeta.text = item.meta
        binding.heroDesc.text = item.desc
        binding.statusBadge.text = item.badge
    }

    private fun safeDrawable(resId: Int): Drawable? = ContextCompat.getDrawable(this, resId)
}
