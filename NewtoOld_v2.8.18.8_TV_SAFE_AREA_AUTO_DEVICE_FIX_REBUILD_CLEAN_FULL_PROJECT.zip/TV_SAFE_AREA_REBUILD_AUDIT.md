# NewtoOld v2.8.18.8 TV Safe Area Auto Device Fix - Rebuild Audit

Base used: latest available clean v2.8.18.7 VOD settings/focus/ghost fix project in sandbox.

Scope preserved:
- Donor one-row home system untouched
- Hero quality untouched
- VOD player settings/scrubbing/letterbox options untouched
- Stremio add-source behavior untouched
- EPG 3/6/12 behavior untouched
- Cast/media details behavior preserved

Rebuild changes:
- Added TvSafeAreaHelper with auto Android TV / Leanback / projector detection
- Applies extra safe margins only on TV/projector-style devices
- Keeps tablet/phone layout unchanged
- Applies TV-safe padding to media details, season/episode selector, source selector, and VOD overlay controls
- Added log marker: TV_SAFE_AREA_MODE

Verification note:
- Gradle is not installed in this sandbox, so APK compilation must be done by CI or your build workflow.
