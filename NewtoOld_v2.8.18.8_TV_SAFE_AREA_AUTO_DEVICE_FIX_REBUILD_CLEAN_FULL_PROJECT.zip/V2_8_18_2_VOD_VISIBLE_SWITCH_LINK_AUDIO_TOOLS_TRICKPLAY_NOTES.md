# v2.8.18.2 VOD Visible Switch Link + Audio Tools + Trickplay

Scope: VOD player only. Rows, hero, layout editor, presets, HDHomeRun, cast, trailer controls, and cache rules untouched.

Added:
- Visible Switch Link button on VOD player control bar.
- Adjustable VOD seek step: 5s, 10s, 30s, 60s.
- DPAD LEFT/RIGHT seeks while in VOD mode instead of only opening controls.
- Trickplay timestamp preview overlay while seeking. Thumbnail image support remains source-dependent; timestamp fallback is always available.
- Audio boost selector.
- Voice sync/audio delay selector.
- Subtitle delay selector.
- Playback speed shortcut.
- Audio/subtitle track selector shortcuts.
- Zoom/aspect shortcut.
- HDR/audio debug info panel.

Verification log markers:
- VOD_TRICKPLAY_SEEK
- VOD_SEEK_STEP_APPLY
- VOD_AUDIO_BOOST_APPLY
- VOD_AUDIO_DELAY_SET
- VOD_SUBTITLE_DELAY_SET
