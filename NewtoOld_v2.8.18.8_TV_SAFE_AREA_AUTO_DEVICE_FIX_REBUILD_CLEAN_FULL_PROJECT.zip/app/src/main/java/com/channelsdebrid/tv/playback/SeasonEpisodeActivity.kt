package com.channelsdebrid.tv.playback

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.channelsdebrid.tv.R
import com.channelsdebrid.tv.TvSafeAreaHelper
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.channelsdebrid.tv.settings.SettingsRepository
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors

class SeasonEpisodeActivity : AppCompatActivity() {

    data class EpisodeEntry(
        val season: Int,
        val episode: Int,
        val title: String,
        val stremioId: String,
        val thumbnailUrl: String? = null,
        val overview: String? = null,
        val released: String? = null,
        val runtime: String? = null,
        val rating: String? = null
    )

    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var settingsRepository: SettingsRepository
    private lateinit var titleView: TextView
    private lateinit var metaView: TextView
    private lateinit var seasonList: LinearLayout
    private lateinit var episodeList: RecyclerView
    private lateinit var emptyView: TextView
    private lateinit var previewImage: ImageView
    private lateinit var previewTitle: TextView
    private lateinit var previewMeta: TextView
    private lateinit var previewOverview: TextView
    private val previewHandler = Handler(Looper.getMainLooper())
    private var pendingPreviewRunnable: Runnable? = null

    private var title: String = ""
    private var externalId: String = ""
    private var mediaType: String = "series"
    private var posterUrl: String? = null
    private var backdropUrl: String? = null
    private var logoUrl: String? = null
    private var itemMeta: String? = null
    private var desc: String? = null
    private var episodes: List<EpisodeEntry> = emptyList()
    private var selectedSeason: Int = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_episode_selection)
        TvSafeAreaHelper.applyIfTv(this, (findViewById(android.R.id.content) as? ViewGroup)?.getChildAt(0), "season_episode", TvSafeAreaHelper.InsetsDp(40, 32, 40, 54))

        settingsRepository = SettingsRepository(this)
        titleView = findViewById(R.id.episodeTitle)
        metaView = findViewById(R.id.episodeMeta)
        seasonList = findViewById(R.id.seasonList)
        episodeList = findViewById(R.id.episodeList)
        emptyView = findViewById(R.id.episodeEmpty)
        previewImage = findViewById(R.id.episodePreviewImage)
        previewTitle = findViewById(R.id.episodePreviewTitle)
        previewMeta = findViewById(R.id.episodePreviewMeta)
        previewOverview = findViewById(R.id.episodePreviewOverview)

        title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        externalId = intent.getStringExtra(EXTRA_EXTERNAL_ID).orEmpty()
        mediaType = intent.getStringExtra(EXTRA_MEDIA_TYPE).orEmpty().ifBlank { "series" }
        posterUrl = intent.getStringExtra(EXTRA_POSTER_URL)
        backdropUrl = intent.getStringExtra(EXTRA_BACKDROP_URL)
        logoUrl = intent.getStringExtra(EXTRA_LOGO_URL)
        itemMeta = intent.getStringExtra(EXTRA_ITEM_META)
        desc = intent.getStringExtra(EXTRA_DESC)

        titleView.text = title
        metaView.text = itemMeta ?: "Pick an episode before choosing a stream"
        episodeList.layoutManager = LinearLayoutManager(this)
        episodeList.isFocusable = true
        episodeList.isFocusableInTouchMode = true
        episodeList.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        episodeList.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_UP && (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER)) {
                episodeList.findFocus()?.performClick() ?: episodeList.findChildViewUnder(24f, 24f)?.performClick()
                true
            } else {
                false
            }
        }

        loadEpisodes()
    }

    private fun loadEpisodes() {
        val manifestUrls = settingsRepository.loadStremioAddons()
            .filter { it.enabled && it.manifestUrl.isNotBlank() }
            .map { it.manifestUrl.trim() }
            .let { listOf(CINEMETA_MANIFEST_URL) + it }
            .distinctBy { it.lowercase(Locale.US) }

        emptyView.visibility = View.VISIBLE
        emptyView.text = "Loading seasons…"

        executor.execute {
            val idCandidates = buildSeriesIdCandidates(externalId, title)
            val loaded = idCandidates.asSequence()
                .mapNotNull { candidateId ->
                    manifestUrls.asSequence()
                        .mapNotNull { manifestUrl -> fetchEpisodes(manifestUrl, candidateId) }
                        .firstOrNull { it.isNotEmpty() }
                }
                .firstOrNull { it.isNotEmpty() }
                .orEmpty()
            runOnUiThread {
                episodes = loaded.sortedWith(compareBy<EpisodeEntry> { it.season }.thenBy { it.episode })
                if (episodes.isEmpty()) {
                    seasonList.removeAllViews()
                    episodeList.adapter = EpisodeAdapter(emptyList())
                    emptyView.visibility = View.VISIBLE
                    emptyView.text = if (idCandidates.isEmpty()) "No series ID found for this show" else "No episode data available from Stremio/Cinemeta"
                } else {
                    emptyView.visibility = View.GONE
                    selectedSeason = episodes.firstOrNull()?.season ?: 1
                    renderSeasons()
                    renderEpisodesForSeason(selectedSeason)
                    updatePreview(episodes.first())
                }
            }
        }
    }

    private fun renderSeasons() {
        seasonList.removeAllViews()
        val seasons = episodes.map { it.season }.distinct().sorted()
        seasons.forEach { season ->
            val chip = TextView(this).apply {
                text = "Season $season"
                textSize = 18f
                setPadding(28, 18, 28, 18)
                setTextColor(ContextCompat.getColor(context, android.R.color.white))
                background = ContextCompat.getDrawable(context, if (season == selectedSeason) R.drawable.guide_category_selected else R.drawable.guide_category_idle)
                isFocusable = true
                isFocusableInTouchMode = true
                isClickable = true
                setOnFocusChangeListener { _, hasFocus ->
                    background = ContextCompat.getDrawable(context, if (hasFocus || season == selectedSeason) R.drawable.guide_category_selected else R.drawable.guide_category_idle)
                    animate().scaleX(if (hasFocus) 1.06f else 1.0f).scaleY(if (hasFocus) 1.06f else 1.0f).setDuration(90).start()
                }
                setOnKeyListener { v, keyCode, event ->
                    if (event.action == KeyEvent.ACTION_UP && (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER)) {
                        v.performClick()
                        true
                    } else false
                }
                setOnClickListener {
                    selectedSeason = season
                    renderSeasons()
                    renderEpisodesForSeason(season)
                    episodeList.post { episodeList.requestFocus() }
                }
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = 18
            seasonList.addView(chip, lp)
        }
    }

    private fun renderEpisodesForSeason(season: Int) {
        val seasonEpisodes = episodes.filter { it.season == season }
        episodeList.adapter = EpisodeAdapter(seasonEpisodes)
        episodeList.post {
            episodeList.requestFocus()
            if (seasonEpisodes.isNotEmpty()) {
                episodeList.layoutManager?.findViewByPosition(0)?.requestFocus()
            }
        }
    }

    private inner class EpisodeAdapter(private val items: List<EpisodeEntry>) : RecyclerView.Adapter<EpisodeHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EpisodeHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_episode_option, parent, false)
            return EpisodeHolder(view)
        }
        override fun getItemCount(): Int = items.size
        override fun onBindViewHolder(holder: EpisodeHolder, position: Int) {
            val item = items[position]
            holder.title.text = String.format(Locale.US, "S%02dE%02d  •  %s", item.season, item.episode, item.title.ifBlank { "Episode ${item.episode}" })
            holder.subtitle.text = buildEpisodeMeta(item)
            holder.overview.text = item.overview?.takeIf { it.isNotBlank() } ?: "Episode information will appear here when provided by the catalog."
            val thumb = highQualityEpisodeImage(item.thumbnailUrl) ?: backdropUrl ?: posterUrl
            if (!thumb.isNullOrBlank()) {
                Glide.with(holder.image.context)
                    .load(thumb)
                    .override(960, 540)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .centerCrop()
                    .into(holder.image)
            } else {
                holder.image.setImageDrawable(null)
            }
            holder.itemView.isFocusable = true
            holder.itemView.isFocusableInTouchMode = true
            holder.itemView.isClickable = true
            holder.itemView.setOnFocusChangeListener { view, hasFocus ->
                view.isSelected = hasFocus
                view.animate().scaleX(if (hasFocus) 1.035f else 1.0f).scaleY(if (hasFocus) 1.035f else 1.0f).setDuration(110).start()
                if (hasFocus) schedulePreview(item)
            }
            holder.itemView.setOnKeyListener { v, keyCode, event ->
                if (event.action == KeyEvent.ACTION_UP && (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER)) {
                    v.performClick()
                    true
                } else false
            }
            holder.itemView.setOnClickListener {
                openEpisode(item)
            }
        }
    }

    private fun schedulePreview(item: EpisodeEntry) {
        pendingPreviewRunnable?.let { previewHandler.removeCallbacks(it) }
        val runnable = Runnable { updatePreview(item) }
        pendingPreviewRunnable = runnable
        previewHandler.postDelayed(runnable, 350)
    }

    private fun updatePreview(item: EpisodeEntry) {
        previewTitle.text = item.title.ifBlank { "Episode ${item.episode}" }
        previewMeta.text = buildEpisodeMeta(item)
        previewOverview.text = item.overview?.takeIf { it.isNotBlank() } ?: desc?.takeIf { it.isNotBlank() } ?: "No episode description was provided by the selected catalog."
        val image = highQualityEpisodeImage(item.thumbnailUrl) ?: backdropUrl ?: posterUrl
        if (!image.isNullOrBlank()) {
            Glide.with(this)
                .load(image)
                .override(1280, 720)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .centerCrop()
                .into(previewImage)
        } else {
            previewImage.setImageDrawable(null)
        }
    }

    private fun buildEpisodeMeta(item: EpisodeEntry): String {
        val parts = mutableListOf(String.format(Locale.US, "Season %d", item.season), String.format(Locale.US, "Episode %d", item.episode))
        item.runtime?.takeIf { it.isNotBlank() }?.let { parts.add(it) }
        item.rating?.takeIf { it.isNotBlank() }?.let { parts.add("★ $it") }
        item.released?.takeIf { it.isNotBlank() }?.let { parts.add(it.take(10)) }
        return parts.joinToString("  •  ")
    }

    private fun highQualityEpisodeImage(value: String?): String? {
        val raw = value?.trim()?.takeIf { it.isNotBlank() } ?: return null
        return raw
            .replace("/w92/", "/original/")
            .replace("/w154/", "/original/")
            .replace("/w185/", "/original/")
            .replace("/w300/", "/original/")
            .replace("/w342/", "/original/")
            .replace("/w500/", "/original/")
            .replace("/w780/", "/original/")
    }

    private fun openEpisode(item: EpisodeEntry) {
        startActivity(Intent(this@SeasonEpisodeActivity, SourceSelectionActivity::class.java)
                    .putExtra(SourceSelectionActivity.EXTRA_TITLE, if (item.title.isBlank()) title else "$title • ${item.title}")
                    .putExtra(SourceSelectionActivity.EXTRA_EXTERNAL_ID, item.stremioId)
                    .putExtra(SourceSelectionActivity.EXTRA_MEDIA_TYPE, mediaType)
                    .putExtra(SourceSelectionActivity.EXTRA_POSTER_URL, posterUrl)
                    .putExtra(SourceSelectionActivity.EXTRA_BACKDROP_URL, highQualityEpisodeImage(item.thumbnailUrl) ?: backdropUrl)
                    .putExtra(SourceSelectionActivity.EXTRA_ARTWORK_URL, highQualityEpisodeImage(item.thumbnailUrl) ?: backdropUrl ?: posterUrl.orEmpty())
                    .putExtra(SourceSelectionActivity.EXTRA_LOGO_URL, logoUrl)
                    .putExtra(SourceSelectionActivity.EXTRA_META_LINE, "S${item.season} E${item.episode}")
                    .putExtra(SourceSelectionActivity.EXTRA_DESC, item.overview?.takeIf { it.isNotBlank() } ?: desc.orEmpty())
                    .putExtra(SourceSelectionActivity.EXTRA_ITEM_META, itemMeta)
                    .putExtra(SourceSelectionActivity.EXTRA_SERIES_EXTERNAL_ID, externalId)
                    .putExtra(SourceSelectionActivity.EXTRA_SERIES_TITLE, title)
                )
    }

    private class EpisodeHolder(view: View) : RecyclerView.ViewHolder(view) {
        val image: ImageView = view.findViewById(R.id.episodeOptionImage)
        val title: TextView = view.findViewById(R.id.episodeOptionTitle)
        val subtitle: TextView = view.findViewById(R.id.episodeOptionSubtitle)
        val overview: TextView = view.findViewById(R.id.episodeOptionOverview)
    }


    private fun buildSeriesIdCandidates(externalId: String, queryTitle: String): List<String> {
        val candidates = mutableListOf<String>()
        fun addCandidate(value: String) {
            val cleaned = value.trim()
            if (cleaned.isNotBlank() && candidates.none { it.equals(cleaned, ignoreCase = true) }) {
                candidates.add(cleaned)
            }
        }
        addCandidate(externalId)
        if (externalId.startsWith("tt") && !externalId.contains(':')) {
            addCandidate("$externalId:1:1")
        }
        val resolved = resolveSeriesIdFromCinemeta(queryTitle)
        addCandidate(resolved)
        if (resolved.startsWith("tt") && !resolved.contains(':')) {
            addCandidate("$resolved:1:1")
        }
        return candidates
    }

    private fun resolveSeriesIdFromCinemeta(queryTitle: String): String {
        val cleanedTitle = queryTitle.trim()
        if (cleanedTitle.isBlank()) return ""
        return runCatching {
            val encoded = URLEncoder.encode(cleanedTitle, "UTF-8").replace("+", "%20")
            val urlValue = "https://v3-cinemeta.strem.io/catalog/series/top/search=$encoded.json"
            val connection = (URL(urlValue).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5000
                readTimeout = 8000
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "ChannelsDebridTV/1.0")
            }
            val body = try {
                val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
                stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            } finally {
                connection.disconnect()
            }
            val metas = JSONObject(body).optJSONArray("metas") ?: JSONArray()
            for (i in 0 until metas.length()) {
                val meta = metas.optJSONObject(i) ?: continue
                val name = meta.optString("name").ifBlank { meta.optString("title") }
                val id = meta.optString("id").trim()
                val imdbId = meta.optString("imdb_id").trim().ifBlank { meta.optString("imdbId").trim() }
                if ((id.isNotBlank() || imdbId.isNotBlank()) && titlesLooselyMatch(cleanedTitle, name)) {
                    return@runCatching imdbId.ifBlank { id }
                }
            }
            ""
        }.getOrDefault("")
    }

    private fun titlesLooselyMatch(a: String, b: String): Boolean {
        fun normalize(value: String): String = value.lowercase(Locale.US)
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()
        val left = normalize(a)
        val right = normalize(b)
        if (left.isBlank() || right.isBlank()) return false
        return left == right || left.contains(right) || right.contains(left)
    }

    private fun fetchEpisodes(manifestUrl: String, externalId: String): List<EpisodeEntry>? {
        val base = manifestUrl.removeSuffix("/manifest.json").trimEnd('/')
        val idCandidates = buildList {
            val cleaned = externalId.trim()
            if (cleaned.isNotBlank()) {
                add(cleaned)
                if (cleaned.contains(':')) {
                    add(cleaned.substringBefore(':'))
                }
            }
        }.distinct()
        for (candidate in idCandidates) {
            val loaded = fetchEpisodesForId(base, candidate, externalId)
            if (!loaded.isNullOrEmpty()) return loaded
        }
        return null
    }

    private fun fetchEpisodesForId(base: String, stremioMetaId: String, seriesExternalId: String): List<EpisodeEntry>? {
        return runCatching {
            val safeBase = base.trimEnd('/')
            val encodedId = URLEncoder.encode(stremioMetaId, "UTF-8").replace("+", "%20")
            val urls = listOf(
                "$safeBase/meta/series/${stremioMetaId}.json",
                "$safeBase/meta/series/${encodedId}.json"
            ).distinct()
            for (urlValue in urls) {
                val connection = (URL(urlValue).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 5000
                    readTimeout = 8000
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("User-Agent", "ChannelsDebridTV/1.0")
                }
                val body = try {
                    val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
                    stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                } finally {
                    connection.disconnect()
                }
                if (body.isBlank()) continue
                val json = JSONObject(body)
                val meta = json.optJSONObject("meta") ?: continue
                val videos = meta.optJSONArray("videos") ?: JSONArray()
                val parsed = buildList {
                    for (i in 0 until videos.length()) {
                        val video = videos.optJSONObject(i) ?: continue
                        val season = video.optInt("season", 0)
                        val episode = video.optInt("episode", 0)
                        if (season <= 0 || episode <= 0) continue
                        val id = video.optString("id")
                            .ifBlank { "$seriesExternalId:$season:$episode" }
                        val episodeTitle = video.optString("title")
                            .ifBlank { video.optString("name") }
                            .ifBlank { "Episode $episode" }
                        val thumbnail = video.optString("thumbnail")
                            .ifBlank { video.optString("image") }
                            .ifBlank { video.optString("still") }
                            .ifBlank { video.optString("poster") }
                        val overview = video.optString("overview")
                            .ifBlank { video.optString("description") }
                            .ifBlank { video.optString("summary") }
                        val released = video.optString("released")
                            .ifBlank { video.optString("firstAired") }
                        val runtime = video.optString("runtime")
                            .ifBlank { video.optString("duration") }
                        val rating = video.optString("imdbRating")
                            .ifBlank { video.optString("rating") }
                        add(EpisodeEntry(season, episode, episodeTitle, id, thumbnail, overview, released, runtime, rating))
                    }
                }
                if (parsed.isNotEmpty()) return@runCatching parsed
            }
            null
        }.getOrNull()
    }

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_EXTERNAL_ID = "external_id"
        const val EXTRA_MEDIA_TYPE = "media_type"
        const val EXTRA_POSTER_URL = "poster_url"
        const val EXTRA_BACKDROP_URL = "backdrop_url"
        const val EXTRA_LOGO_URL = "logo_url"
        const val EXTRA_ITEM_META = "item_meta"
        const val EXTRA_DESC = "desc"
        private const val CINEMETA_MANIFEST_URL = "https://v3-cinemeta.strem.io/manifest.json"
    }
}
