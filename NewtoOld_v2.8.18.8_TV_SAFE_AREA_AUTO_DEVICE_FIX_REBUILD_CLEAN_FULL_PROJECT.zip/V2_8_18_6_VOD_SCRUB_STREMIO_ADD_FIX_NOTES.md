# v2.8.18.6 VOD Scrub + Stremio Add Fix

Scoped fixes only.

- VOD LEFT/RIGHT hidden scrubbing now suppresses the player overlay and consumes key-up events.
- Trickplay timestamp preview still appears while hidden controls remain hidden.
- Stremio Add Source button is no longer disabled during add/manifest refresh and is rearmed after render updates.
- No row, hero, cache, EPG, player settings, trailer, cast, or layout-editor changes.
