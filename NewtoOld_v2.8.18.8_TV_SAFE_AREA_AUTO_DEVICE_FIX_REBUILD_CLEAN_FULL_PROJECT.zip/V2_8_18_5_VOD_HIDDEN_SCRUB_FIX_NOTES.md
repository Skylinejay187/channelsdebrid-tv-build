# v2.8.18.5 VOD Hidden Scrub Fix

Scope: VOD player input routing only.

## Fixed
- DPAD LEFT/RIGHT while VOD controls are hidden now seeks/scrubs directly.
- Hidden scrubbing shows the trickplay timestamp preview without opening the full VOD controls menu.
- If controls are already visible, LEFT/RIGHT still behaves normally for focused controls/navigation.
- Rewind/forward buttons and media rewind/fast-forward remain unchanged.

## Preserved
- Player settings visibility/clickable fix.
- Stremio Add Source clickable fix.
- EPG 3/6/12 hour cache window.
- Row/hero/focus systems.
- Cache rules.
