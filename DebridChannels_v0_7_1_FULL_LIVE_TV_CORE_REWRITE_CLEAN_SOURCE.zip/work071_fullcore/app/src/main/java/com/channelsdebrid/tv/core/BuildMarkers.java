package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.7.1 Full Live TV Core Rewrite";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.7.1_full_livetv_core_rewrite_preview_player_guide_clean_base";
}
