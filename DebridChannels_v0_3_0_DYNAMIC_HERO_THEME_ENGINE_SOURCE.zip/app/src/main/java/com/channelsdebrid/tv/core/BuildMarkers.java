package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.3.0 DYNAMIC HERO + THEME ENGINE";
    public static final String LOG_MARKER = "DC_V0_3_0_DYNAMIC_HERO_THEME_ENGINE_ACTIVE";
    private BuildMarkers() {}
}
