# Debrid Channels v0.2.1 Rewrite Build Audit

Base used: v0.2.0 working playback/settings line.
Build rule followed: clean consolidation/rewrite from the latest known-good line; no broken v7.x code path used.

Updated version:
- versionCode: 21
- versionName: 0.2.1
- visible/logcat marker: DC_V0_2_1_PRO_EDITOR_LIVE_PREVIEW_ACTIVE

What was rewritten:
- Pro Layout Editor settings surface rebuilt as a fresh organized editor instead of a patched mixed list.
- Live preview mode restored: Home screen is rendered behind the editor panel and most changes apply immediately.
- Extra Artwork Slot controls restored and made explicit.

Extra Artwork Slot controls added:
- On/off
- Type selector: Hidden, Auto, Banner/Landscape, Clearlogo, Poster, Backdrop, Disc/DVD box, 3D character art
- X/Y placement
- Width/height
- Opacity
- Depth/3D pop value
- Reset extra artwork slot

Preserved systems:
- Working playback stream parity and player controls from the latest working line
- Card/logo visuals
- Row navigation
- Hero artwork and ratings
- Backend default URL
