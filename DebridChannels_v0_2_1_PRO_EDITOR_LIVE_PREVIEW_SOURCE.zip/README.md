# Debrid Channels Android TV — v0.1.7 Player Overlay Input Fix

Clean rewrite/consolidation from the stable v0.0.1 visual baseline.

Version: 0.1.7
Marker: DC_V0_1_7_PLAYER_OVERLAY_INPUT_FIX_ACTIVE

Core VOD flow:
Home -> Media Info -> Styled Stream List -> Select Stream -> Media3 ExoPlayer + cinematic overlay.
