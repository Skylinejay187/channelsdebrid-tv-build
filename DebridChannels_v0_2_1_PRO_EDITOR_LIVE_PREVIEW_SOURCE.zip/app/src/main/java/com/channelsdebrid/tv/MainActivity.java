package com.channelsdebrid.tv;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import android.widget.*;
import android.net.Uri;
import android.text.InputType;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

import com.channelsdebrid.tv.core.*;
import com.channelsdebrid.tv.player.*;
import com.channelsdebrid.tv.livetv.*;
import com.channelsdebrid.tv.cache.*;
import com.channelsdebrid.tv.layout.*;
import com.channelsdebrid.tv.backend.*;
import com.channelsdebrid.tv.stremio.*;
import androidx.media3.common.MediaItem;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.Tracks;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.Player;
import androidx.media3.common.PlaybackException;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.ui.PlayerView;
import androidx.media3.ui.AspectRatioFrameLayout;

public class MainActivity extends Activity {
    FrameLayout root;
    NavigationController nav;
    PlayerManager player;
    LiveTvStateMachine live;
    GuideCacheOwner guideCache;
    TimeshiftEngine timeshift;
    UiStateStore ui;
    BackendConfig backend;
    StremioAddonRegistry stremio;
    LinearLayout heroMenu;
    final ArrayList<View> menuItems = new ArrayList<>();
    final ArrayList<HomeRow> homeRows = new ArrayList<>();
    final ArrayList<LinearLayout> rowLists = new ArrayList<>();
    final ArrayList<HorizontalScrollView> rowScrolls = new ArrayList<>();
    final ArrayList<TextView> rowTitleViews = new ArrayList<>();
    final ArrayList<Movie> movies = new ArrayList<>();
    final ArrayList<Channel> channels = new ArrayList<>();
    ImageView heroBackdropImage, heroLogoImage, heroBannerImage;
    ScrollView editorScroll;
    TextView heroTitle, heroDesc, heroMeta;
    LinearLayout heroRatingRow;
    boolean suppressRowAutoFocus = false;
    int activeRowIndex = 0;
    final Handler heroHandler = new Handler(Looper.getMainLooper());
    Runnable pendingHeroRunnable;
    final Map<String, Bitmap> imageCache = Collections.synchronizedMap(new LinkedHashMap<String, Bitmap>(64, .75f, true){protected boolean removeEldestEntry(Map.Entry<String,Bitmap> e){return size()>80;}});
    final ExecutorService imageExecutor = Executors.newFixedThreadPool(3);
    final Set<String> failedArtworkUrls = Collections.synchronizedSet(new HashSet<String>());
    final Map<String, String[]> ratingCache = Collections.synchronizedMap(new HashMap<String, String[]>());
    ExoPlayer exoPlayer;
    PlayerView activePlayerView;
    int activeZoomMode = 0;
    SelectedMedia selectedMedia;
    FrameLayout activePlayerOverlay;
    TextView activePlayerPlayPause;
    TextView activePlayerTime;
    ProgressBar activePlayerProgress;
    Movie activePlayerMovie;
    final Handler playerOverlayHandler = new Handler(Looper.getMainLooper());
    final Handler playerProgressHandler = new Handler(Looper.getMainLooper());
    Runnable playerOverlayHideRunnable;
    Runnable playerProgressRunnable;
    FrameLayout activePlayerOptionPanel;

    static class Movie {
        String id = "", type = "movie", title = "Untitled", meta = "", url = "";
        String poster = "", background = "", logo = "", banner = "", overview = "", year = "", tag = "FEATURED", imdbRating = "", tmdbRating = "";
        Movie(String title, String meta, String url) { this.title = title; this.meta = meta; this.url = url; }
    }
    static class SelectedMedia { Movie movie; ArrayList<StreamLink> streams = new ArrayList<>(); SelectedMedia(Movie m){movie=m;} }
    static class StreamLink {
        String name="Stream", title="", description="", quality="", size="", source="Stremio", url="";
        String magnet="", infoHash=""; int fileIdx=-1; long sizeBytes=0; int qualityScore=0;
        boolean external=false, dolbyVision=false, hdr10Plus=false, hdr=false;
        boolean playable(){return url!=null && (url.startsWith("http://")||url.startsWith("https://"));}
        boolean hasResolverPayload(){return (magnet!=null&&!magnet.isEmpty()) || (infoHash!=null&&!infoHash.isEmpty()) || (url!=null && (url.startsWith("magnet:")||url.startsWith("torrent:")||url.endsWith(".torrent")));}
        boolean needsResolver(){ if(url==null)return true; String u=url.toLowerCase(Locale.US); return u.startsWith("magnet:")||u.startsWith("torrent:")||u.endsWith(".torrent")||external; }
    }
    static class HomeRow { String id = "", title = "Catalog"; ArrayList<Movie> items = new ArrayList<>(); HomeRow(String title){this.title=title;} }
    static class Channel { String name, group, url, logo; Channel(String n,String g,String u,String l){name=n;group=g;url=u;logo=l;} }

    class CardFrame extends FrameLayout {
        final Path clipPath = new Path();
        final RectF rect = new RectF();
        float radius;
        CardFrame(Context context, float r) { super(context); radius = r; setWillNotDraw(false); }
         protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            clipPath.reset(); rect.set(0, 0, w, h);
            clipPath.addRoundRect(rect, radius, radius, Path.Direction.CW); clipPath.close();
        }
         public void draw(Canvas canvas) {
            int save = canvas.save();
            canvas.clipPath(clipPath);
            super.draw(canvas);
            canvas.restoreToCount(save);
        }
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (activePlayerOverlay != null && event.getAction() == KeyEvent.ACTION_DOWN) {
            if (handlePlayerKey(event.getKeyCode())) return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        nav = new NavigationController();
        player = new PlayerManager(this);
        live = new LiveTvStateMachine();
        guideCache = new GuideCacheOwner(this);
        timeshift = new TimeshiftEngine(this);
        ui = new UiStateStore(this);
        backend = new BackendConfig(this);
        stremio = new StremioAddonRegistry(this);
        seedFallback();
        root = new FrameLayout(this);
        setContentView(root);
        AppLogger.mark("BOOT " + BuildMarkers.LOG_MARKER + " backend=" + backend.baseUrl());
        showHome();
        loadBackendHomeRows();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        try { if(exoPlayer!=null){exoPlayer.release();exoPlayer=null;} } catch(Exception ignored) {}
        try { imageExecutor.shutdownNow(); } catch(Exception ignored) {}
    }

    void seedFallback() {
        movies.clear(); homeRows.clear(); channels.clear();
        Movie a = new Movie("Project Hail Mary", "2026 • FEATURED • IMDB 8.2 • TMDB 7.0", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4");
        a.year="2026"; a.imdbRating="8.2"; a.tmdbRating="7.0"; a.overview="Focus a card to update the cinematic background, logo/title layer, metadata, poster row and future banner/3D art slot."; movies.add(a);
        Movie b = new Movie("The Mummy", "1999 • 4K • Adventure • 7.1", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4");
        b.year="1999"; b.imdbRating="7.1"; b.tmdbRating="7.2"; b.overview="Artwork comes from the backend first: poster, background, logo and banner fields. The app does not require a TMDB key."; movies.add(b);
        Movie c = new Movie("The Super Mario Galaxy Movie", "2026 • Family • 8.0", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4");
        c.year="2026"; c.imdbRating="8.0"; c.tmdbRating="7.6"; c.overview="Each Stremio addon catalog can become a row. Settings will control hide, rename and reorder without changing the clean core."; movies.add(c);
        Movie d = new Movie("Avatar", "2009 • 4K • Sci-Fi", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4");
        d.year="2009"; d.overview="The right-side Banner area is preserved as the extra artwork layer for clearlogo, disc/DVD, character and future 3D pop art."; movies.add(d);
        HomeRow row = new HomeRow("Trending Movies"); row.items.addAll(movies); homeRows.add(row);
        channels.add(new Channel("Sample Live Channel", "Favorites", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4", ""));
        channels.add(new Channel("Movies 24/7", "Movies", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4", ""));
        channels.add(new Channel("Demo Sports", "Sports", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4", ""));
    }

    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);} 
    void clear(){
        if(playerOverlayHideRunnable!=null)playerOverlayHandler.removeCallbacks(playerOverlayHideRunnable);
        if(playerProgressRunnable!=null)playerProgressHandler.removeCallbacks(playerProgressRunnable);
        activePlayerOverlay=null;activePlayerPlayPause=null;activePlayerProgress=null;activePlayerTime=null;activePlayerView=null;
        root.removeAllViews();menuItems.clear();rowLists.clear();rowScrolls.clear();rowTitleViews.clear();
    }
    GradientDrawable bg(int c,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    GradientDrawable stroke(int c,int s){GradientDrawable g=bg(c,26);g.setStroke(dp(1),s);return g;}
    TextView tv(String x,int sp,int style){TextView t=new TextView(this);t.setText(x);t.setTextColor(Color.WHITE);t.setTextSize(sp);t.setTypeface(Typeface.DEFAULT,style);t.setGravity(Gravity.CENTER);return t;}
    Typeface editorTypeface(int index,int style){String[] families={"sans-serif","sans-serif-medium","sans-serif-condensed","sans-serif-light","serif","monospace","casual","cursive","sans-serif-smallcaps","sans-serif-black","sans-serif-thin","sans-serif"};int safe=Math.max(0,Math.min(index,families.length-1));return Typeface.create(families[safe],style);}
    String fontName(int index){String[] names={"Default","Medium","Condensed","Light","Serif","Monospace","Casual","Cursive","Small caps","Black","Thin","Default alt"};return names[Math.max(0,Math.min(index,names.length-1))];}
    String onOff(int v){return v==1?"On":"Off";}
    String placementName(int v){return v==0?"Hidden":v==1?"Inline":v==2?"Left":"Right";}
    String menuCompositionName(int v){return v==0?"Classic":v==1?"Pill":v==2?"Glass":"Pill";}
    String effectProfileName(int v){String[] n={"Custom","Subtle","Cinematic glow","3D pop","Premium glass"};return n[Math.max(0,Math.min(v,n.length-1))];}
    String extraArtworkName(int v){String[] n={"Hidden","Auto","Banner / landscape","Clearlogo","Poster","Backdrop","Disc / DVD box","3D character art"};return n[Math.max(0,Math.min(v,n.length-1))];}
    int focusRingColor(int index,int alpha){int i=Math.max(0,Math.min(5,index));int[] c={Color.WHITE,Color.rgb(73,160,255),Color.rgb(0,220,200),Color.rgb(255,210,64),Color.rgb(255,78,120),Color.rgb(180,110,255)};return Color.argb(alpha,Color.red(c[i]),Color.green(c[i]),Color.blue(c[i]));}
    void applyFont(TextView t,int index,int style){if(t!=null)t.setTypeface(editorTypeface(index,style));}

    void backdrop(){
        heroBackdropImage = new ImageView(this);
        heroBackdropImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        heroBackdropImage.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(115,80,28),Color.rgb(23,28,42),Color.rgb(1,3,8)}));
        root.addView(heroBackdropImage,new FrameLayout.LayoutParams(-1,-1));
        View tone = new View(this); tone.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.argb(120,120,72,14),Color.argb(70,20,28,46),Color.argb(155,0,0,0)})); root.addView(tone,new FrameLayout.LayoutParams(-1,-1));
        View side = new View(this); side.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.argb(240,0,0,0),Color.argb(155,0,0,0),Color.argb(35,0,0,0)})); root.addView(side,new FrameLayout.LayoutParams(-1,-1));
        View bottom = new View(this); bottom.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,new int[]{Color.argb(245,0,0,0),Color.TRANSPARENT})); root.addView(bottom,new FrameLayout.LayoutParams(-1,dp(400),Gravity.BOTTOM));
    }

    TextView btn(String x){TextView v=tv(x,16,Typeface.BOLD);applyFont(v,ui==null?0:ui.topMenuFontIndex(),Typeface.BOLD);v.setFocusable(true);v.setPadding(dp(18),0,dp(18),0);v.setBackground(bg(Color.argb(0,0,0,0),18));v.setOnFocusChangeListener((a,h)->focus((TextView)a,h));return v;}
    void focus(TextView a,boolean h){a.animate().scaleX(h?1.08f:1f).scaleY(h?1.08f:1f).setDuration(130).start();a.setBackground(h?bg(Color.argb(165,21,57,88),0):bg(Color.argb(0,0,0,0),0));}

    void addMenu(){
        heroMenu=new LinearLayout(this);heroMenu.setGravity(Gravity.CENTER);heroMenu.setPadding(dp(8),0,dp(8),0); if(ui.menuCompositionMode()>0)heroMenu.setBackground(stroke(ui.menuCompositionMode()==2?Color.argb(112,20,28,40):Color.argb(70,10,14,24),Color.argb(80,255,255,255)));
        String ip=ui.iconPlacement();ArrayList<String> labels=new ArrayList<>();
        String searchIcon=ui.topMenuIconStyle()==2?"Search":"⌕";
        String settingsIcon=ui.topMenuIconStyle()==2?"Settings":"⚙";
        if(ip.equals("left")){labels.add(searchIcon);labels.add(settingsIcon);}
        if(ip.equals("inline"))Collections.addAll(labels,"Home","Live TV","Movies","Shows","Settings",searchIcon,settingsIcon); else Collections.addAll(labels,"Home","Live TV","Movies","Shows","Settings");
        if(ip.equals("right")){labels.add(searchIcon);labels.add(settingsIcon);}
        for(String s:labels){
            TextView m=btn(s);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(48));lp.setMargins(dp(5),0,dp(5),0);heroMenu.addView(m,lp);menuItems.add(m);
            m.setOnClickListener(v->{String z=((TextView)v).getText().toString();if(z.equals("Live TV"))showLiveTv();else if(z.equals("Movies")||z.equals("Shows"))showCatalogs(z);else if(z.equals("Settings")||z.equals("⚙"))showSettings();else if(z.equals("⌕")||z.equals("Search"))showSearch();else showHome();});
            m.setOnKeyListener((v,key,event)->{if(event.getAction()!=KeyEvent.ACTION_DOWN)return false;int pos=menuItems.indexOf(v);if(key==KeyEvent.KEYCODE_DPAD_RIGHT){menuItems.get((pos+1)%menuItems.size()).requestFocus();return true;}if(key==KeyEvent.KEYCODE_DPAD_LEFT){menuItems.get((pos-1+menuItems.size())%menuItems.size()).requestFocus();return true;}if(key==KeyEvent.KEYCODE_DPAD_DOWN){focusRowCard(0,0);return true;}return false;});
        }
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(dp(650),dp(58));hp.topMargin=dp(20);hp.leftMargin=dp(ui.topMenuOffsetDp());String pos=ui.menuPosition();hp.gravity=Gravity.TOP|(pos.equals("left")?Gravity.LEFT:pos.equals("right")?Gravity.RIGHT:Gravity.CENTER_HORIZONTAL);root.addView(heroMenu,hp);
    }

    void showHome(){
        clear();nav.go(NavigationController.Screen.HOME);backdrop();addMenu();
        heroLogoImage=new ImageView(this);heroLogoImage.setScaleType(ImageView.ScaleType.FIT_CENTER);heroLogoImage.setAdjustViewBounds(true);FrameLayout.LayoutParams lpLogo=new FrameLayout.LayoutParams(dp(430),dp(96));lpLogo.leftMargin=dp(22+ui.heroTextLeftDp());lpLogo.topMargin=dp(86+ui.heroTextTopDp());root.addView(heroLogoImage,lpLogo);
        heroTitle=tv("Debrid\nChannels",42,Typeface.BOLD);applyFont(heroTitle,ui.heroFontIndex(),Typeface.BOLD);heroTitle.setGravity(Gravity.LEFT);heroTitle.setIncludeFontPadding(false);FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(dp(680),dp(112));tp.leftMargin=dp(22+ui.heroTextLeftDp());tp.topMargin=dp(92+ui.heroTextTopDp());root.addView(heroTitle,tp);
        heroMeta=tv("",17,Typeface.BOLD);applyFont(heroMeta,ui.heroFontIndex(),Typeface.BOLD);heroMeta.setVisibility(View.GONE);heroRatingRow=new LinearLayout(this);heroRatingRow.setOrientation(LinearLayout.HORIZONTAL);heroRatingRow.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(dp(760),dp(42));mp.leftMargin=dp(22+ui.heroTextLeftDp());mp.topMargin=dp(184+ui.heroTextTopDp());root.addView(heroRatingRow,mp);
        heroDesc=tv("Backend catalog artwork is loading. Focus a row card to update the full-screen background, logo/title layer, metadata and extra-art slot.",18,Typeface.BOLD);applyFont(heroDesc,ui.heroFontIndex(),Typeface.BOLD);heroDesc.setGravity(Gravity.LEFT);FrameLayout.LayoutParams dpv=new FrameLayout.LayoutParams(dp(780),dp(120));dpv.leftMargin=dp(22+ui.heroTextLeftDp());dpv.topMargin=dp(222+ui.heroTextTopDp());root.addView(heroDesc,dpv);
        heroBannerImage=new ImageView(this);heroBannerImage.setScaleType(ImageView.ScaleType.FIT_CENTER);heroBannerImage.setBackground(bg(Color.argb(0,0,0,0),0));heroBannerImage.setAlpha(ui.extraArtworkOpacityPercent()/100f);FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(ui.extraArtworkWidthDp()),dp(ui.extraArtworkHeightDp()));bp.leftMargin=dp(ui.extraArtworkXdp());bp.topMargin=dp(ui.extraArtworkYdp());root.addView(heroBannerImage,bp);
        addHeroRows(); addBuildMarker(); if(!movies.isEmpty())updateHero(movies.get(0));
    }
    void addBuildMarker(){TextView marker=tv("DC_V0_2_1_PRO_EDITOR_LIVE_PREVIEW_ACTIVE",11,Typeface.BOLD);marker.setTextColor(Color.argb(150,255,255,255));marker.setGravity(Gravity.RIGHT|Gravity.BOTTOM);FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(dp(360),dp(28),Gravity.RIGHT|Gravity.BOTTOM);mp.rightMargin=dp(18);mp.bottomMargin=dp(10);root.addView(marker,mp);}

    GradientDrawable cardBg(int a){
        int base=ui.glassCardMode()==1?92:55;
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.argb(base,18,26,36),Color.argb(Math.max(base,70),5,8,14)});
        g.setCornerRadius(dp(ui.cornerRadiusDp()));
        g.setStroke(ui.glassCardMode()==1?dp(1):0,ui.glassCardMode()==1?Color.argb(70,255,255,255):Color.TRANSPARENT);
        return g;
    }
    GradientDrawable focusedCardBg(){
        int glowAlpha=Math.max(0,Math.min(230,50+(ui.glowStrengthPercent()*180/100)));
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.argb(ui.glassCardMode()==1?118:76,25,32,44),Color.argb(ui.glassCardMode()==1?125:90,6,10,18)});
        g.setCornerRadius(dp(ui.cornerRadiusDp()));
        int stroke=(ui.focusRingEnabled()==1&&ui.focusRingThicknessDp()>0)?dp(Math.max(1,ui.focusRingThicknessDp())):0;
        g.setStroke(stroke,focusRingColor(ui.focusRingColorIndex(),glowAlpha));
        return g;
    }
    void addHeroRows(){
        rowLists.clear();rowScrolls.clear();rowTitleViews.clear();
        int top=ui.rowTopDp();
        int max=Math.min(6,homeRows.size());
        activeRowIndex=Math.max(0,Math.min(activeRowIndex,Math.max(0,max-1)));
        for(int ri=0;ri<max;ri++)addHeroRow(homeRows.get(ri),top);
        updateActiveRowViewport(false);
    }
    void addHeroRow(HomeRow sourceRow,int topDp){
        TextView rt=null;
        if(ui.rowTitleVisibility()==1){rt=tv((ui.rowTitleIconsEnabled()==1?"▸ ":"")+sourceRow.title,22,Typeface.BOLD);applyFont(rt,ui.contentFontIndex(),Typeface.BOLD);rt.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);FrameLayout.LayoutParams rtp=new FrameLayout.LayoutParams(dp(700),dp(44));rtp.leftMargin=dp(38+ui.rowLeftDp());rtp.topMargin=dp(topDp-45);root.addView(rt,rtp);}        
        final HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);hsv.setClipToPadding(false);hsv.setSmoothScrollingEnabled(true);hsv.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);int sidePad=dp(28+ui.rowLeftDp());hsv.setPadding(sidePad,0,dp(320),0);FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(Math.max(190, ui.cardHeightDp()+78)));hp.topMargin=dp(topDp);root.addView(hsv,hp);
        final LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);hsv.addView(row,new HorizontalScrollView.LayoutParams(-2,-1));
        final int rowIndex=rowLists.size();rowLists.add(row);rowScrolls.add(hsv);rowTitleViews.add(rt);
        int maxCards=Math.min(sourceRow.items.size(), Math.max(12, ui.previewCardCount()*4));
        for(int i=0;i<maxCards;i++){final Movie movie=sourceRow.items.get(i);CardFrame card=new CardFrame(this,dp(ui.cornerRadiusDp()));card.setFocusable(true);card.setPadding(0,0,0,0);card.setBackground(cardBg(215));if(Build.VERSION.SDK_INT>=21)card.setElevation(dp(3));
            ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);img.setBackgroundColor(Color.TRANSPARENT);card.addView(img,new FrameLayout.LayoutParams(-1,-1));String art=rowArtwork(movie);if(!art.isEmpty())loadImage(art,img,false);else img.setImageDrawable(null);
            ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);logo.setAdjustViewBounds(true);logo.setAlpha(.98f);logo.setBackgroundColor(Color.TRANSPARENT);FrameLayout.LayoutParams lpLogoCard=new FrameLayout.LayoutParams(dp(Math.max(120,ui.cardWidthDp()-86)),dp(Math.max(48,ui.cardHeightDp()/2)),Gravity.CENTER);card.addView(logo,lpLogoCard);String cardLogoUrl=cardLogoArtwork(movie);if(isSafeCardLogo(cardLogoUrl)){logo.setVisibility(View.VISIBLE);loadImage(cardLogoUrl,logo,false);}else {logo.setImageDrawable(null);logo.setVisibility(View.GONE);}
            card.setOnKeyListener((v,key,event)->{if(event.getAction()!=KeyEvent.ACTION_DOWN)return false;int pos=Math.max(0,row.indexOfChild(v));if(key==KeyEvent.KEYCODE_DPAD_RIGHT&&pos<row.getChildCount()-1){View next=row.getChildAt(pos+1);next.requestFocus();centerSnap(hsv,next);AppLogger.mark("ROW_NAV right row="+rowIndex+" col="+(pos+1));return true;}if(key==KeyEvent.KEYCODE_DPAD_LEFT&&pos>0){View prev=row.getChildAt(pos-1);prev.requestFocus();centerSnap(hsv,prev);AppLogger.mark("ROW_NAV left row="+rowIndex+" col="+(pos-1));return true;}if(key==KeyEvent.KEYCODE_DPAD_DOWN){focusRowCard(rowIndex+1,pos);return true;}if(key==KeyEvent.KEYCODE_DPAD_UP){focusRowCard(rowIndex-1,pos);return true;}return false;});
            card.setOnFocusChangeListener((v,h)->{
                float scale=h?Math.max(1f,ui.focusedScalePercent()/100f):1f;
                if(h&&ui.focusBouncePercent()>0)scale+=Math.min(.08f,ui.focusBouncePercent()/1000f);
                float lift=h?-dp(10+ui.cardLiftDp()):0;
                v.animate().scaleX(scale).scaleY(scale).translationY(lift).rotationY(h?Math.min(8f,ui.cardTiltPercent()/10f):0f).setDuration(h?190:140).start();
                float dim=1f-(Math.max(0,Math.min(70,ui.dimUnfocusedPercent()))/100f)*.55f;
                v.setAlpha(h?1f:dim);
                if(Build.VERSION.SDK_INT>=21)v.setElevation(h?dp(8+ui.glowStrengthPercent()/6+ui.cardLiftDp()):dp(3));
                v.setBackground(h?focusedCardBg():cardBg(215));
                if(h){activeRowIndex=rowIndex;updateActiveRowViewport(false);scheduleHeroUpdate(movie);v.postDelayed(()->centerSnap(hsv,v),40);}
            });
            card.setOnClickListener(v->showMovieDetails(movie));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(ui.cardWidthDp()),dp(ui.cardHeightDp()));cp.setMargins(0,dp(18),dp(ui.cardSpacingDp()),0);row.addView(card,cp);
        }
        hsv.postDelayed(()->{if(!suppressRowAutoFocus && rowIndex==0 && row.getChildCount()>0){View start=row.getChildAt(0);start.requestFocus();centerSnap(hsv,start);}},140);
    }
    void focusRowCard(int rowIndex,int colIndex){
        AppLogger.mark("ROW_NAV request row="+rowIndex+" col="+colIndex+" rows="+rowLists.size());
        if(rowIndex<0){ if(!menuItems.isEmpty())menuItems.get(0).requestFocus(); return; }
        if(rowIndex>=rowLists.size()){ AppLogger.mark("ROW_NAV ignored: no target row"); return; }
        LinearLayout row=rowLists.get(rowIndex);
        if(row==null||row.getChildCount()==0){ AppLogger.mark("ROW_NAV ignored: empty row "+rowIndex); return; }
        int target=Math.max(0,Math.min(colIndex,row.getChildCount()-1));
        View card=row.getChildAt(target);
        activeRowIndex=rowIndex;
        updateActiveRowViewport(true);
        card.postDelayed(()->{ card.requestFocus(); if(rowIndex<rowScrolls.size())centerSnap(rowScrolls.get(rowIndex),card); AppLogger.mark("ROW_NAV focused row="+rowIndex+" col="+target); },70);
    }
    void updateActiveRowViewport(boolean animate){
        for(int i=0;i<rowScrolls.size();i++){
            boolean active=(i==activeRowIndex);
            HorizontalScrollView hsv=rowScrolls.get(i);
            TextView title=i<rowTitleViews.size()?rowTitleViews.get(i):null;
            hsv.setVisibility(active?View.VISIBLE:View.INVISIBLE);
            hsv.setFocusable(active);
            hsv.setFocusableInTouchMode(active);
            hsv.setEnabled(active);
            hsv.setAlpha(active?1f:0f);
            hsv.setTranslationY(0f);
            if(title!=null){title.setVisibility(active?View.VISIBLE:View.INVISIBLE);title.setAlpha(active?1f:0f);}
        }
    }
    void centerSnap(HorizontalScrollView hsv,View card){int target=card.getLeft()+card.getWidth()/2-getResources().getDisplayMetrics().widthPixels/2;hsv.smoothScrollTo(Math.max(0,target),0);}
    void scheduleHeroUpdate(Movie m){
        if(pendingHeroRunnable!=null)heroHandler.removeCallbacks(pendingHeroRunnable);
        pendingHeroRunnable=()->updateHero(m);
        heroHandler.postDelayed(pendingHeroRunnable,210);
    }


    TextView metaText(String text,int color,int style){TextView t=tv(text,16,style);t.setGravity(Gravity.CENTER_VERTICAL);t.setTextColor(color);t.setIncludeFontPadding(false);return t;}
    TextView badge(String text,int bgColor,int textColor){TextView t=tv(text,14,Typeface.BOLD);t.setTextColor(textColor);t.setIncludeFontPadding(false);t.setGravity(Gravity.CENTER);t.setPadding(dp(9),0,dp(9),0);t.setBackground(bg(bgColor,7));return t;}
    void addMetaPiece(LinearLayout row,View v,int w,int h,int leftMargin){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(w<0?w:dp(w),dp(h));lp.setMargins(dp(leftMargin),0,0,0);row.addView(v,lp);}
    void buildHeroRatingRow(Movie m){
        if(heroRatingRow==null)return; heroRatingRow.removeAllViews();
        String y=first(m.year,extractYear(m.meta));
        if(!y.isEmpty())addMetaPiece(heroRatingRow,metaText(y,Color.rgb(255,220,56),Typeface.BOLD),-2,30,0);
        addMetaPiece(heroRatingRow,metaText("•",Color.WHITE,Typeface.BOLD),-2,30,12);
        addMetaPiece(heroRatingRow,metaText(first(m.tag,"FEATURED").toUpperCase(Locale.US),Color.WHITE,Typeface.BOLD),-2,30,12);
        String imdb=first(m.imdbRating,extractRating(m.meta,"IMDB"),extractRating(m.meta,"IMDb"));
        if(!imdb.isEmpty()){addMetaPiece(heroRatingRow,badge("IMDb",Color.rgb(245,197,24),Color.BLACK),58,24,20);addMetaPiece(heroRatingRow,metaText(imdb,Color.WHITE,Typeface.NORMAL),-2,30,8);}
        String tmdb=first(m.tmdbRating,extractRating(m.meta,"TMDB"));
        if(!tmdb.isEmpty()){addMetaPiece(heroRatingRow,metaText("|",Color.argb(210,255,255,255),Typeface.NORMAL),-2,30,14);addMetaPiece(heroRatingRow,badge("TMDB",Color.rgb(1,180,228),Color.WHITE),62,24,14);addMetaPiece(heroRatingRow,metaText(tmdb,Color.WHITE,Typeface.NORMAL),-2,30,8);}
    }
    String extractYear(String meta){if(meta==null)return "";java.util.regex.Matcher m=java.util.regex.Pattern.compile("(19|20)\\d{2}").matcher(meta);return m.find()?m.group():"";}
    String extractRating(String meta,String key){if(meta==null)return "";int i=meta.toUpperCase(Locale.US).indexOf(key.toUpperCase(Locale.US));if(i<0)return "";java.util.regex.Matcher m=java.util.regex.Pattern.compile("([0-9](?:\\.[0-9])?)").matcher(meta.substring(i));return m.find()?m.group(1):"";}


    void lockRatings(Movie m){
        if(m==null)return;
        String imdbId=first(m.id,extractImdbId(m.meta));
        String key=first(imdbId,m.title);
        String imdb=first(m.imdbRating,extractRating(m.meta,"IMDB"),extractRating(m.meta,"IMDb"));
        String tmdb=first(m.tmdbRating,extractRating(m.meta,"TMDB"),extractRating(m.meta,"TMDb"));
        String[] cached=ratingCache.get(key);
        if(imdb.isEmpty()&&cached!=null)imdb=cached[0];
        if(tmdb.isEmpty()&&cached!=null)tmdb=cached[1];
        if(!imdb.isEmpty()||!tmdb.isEmpty())ratingCache.put(key,new String[]{imdb,tmdb});
        m.imdbRating=imdb==null?"":imdb;
        m.tmdbRating=tmdb==null?"":tmdb;
        if((m.id==null||m.id.isEmpty())&&!imdbId.isEmpty())m.id=imdbId;
    }

    void updateHero(Movie m){
        lockRatings(m);
        fetchMissingRatingsOnce(m);
        if(heroTitle!=null){heroTitle.setText(m.title.replace(" ","\n"));heroTitle.setVisibility((m.logo!=null&&!m.logo.isEmpty())?View.INVISIBLE:View.VISIBLE);} 
        if(heroMeta!=null)heroMeta.setText((m.meta==null||m.meta.isEmpty()?m.year:m.meta));
        buildHeroRatingRow(m);
        if(heroDesc!=null)heroDesc.setText(m.overview==null||m.overview.isEmpty()?"Focused card updates background, logo, banner and metadata from backend artwork fields.":m.overview);
        if(heroBackdropImage!=null)loadImage(first(m.background,m.poster),heroBackdropImage,true);
        if(heroLogoImage!=null){ if(m.logo!=null&&!m.logo.isEmpty())loadImage(m.logo,heroLogoImage,true); else heroLogoImage.setImageDrawable(null);}
        if(heroBannerImage!=null){FrameLayout.LayoutParams bp=(FrameLayout.LayoutParams)heroBannerImage.getLayoutParams(); bp.leftMargin=dp(ui.extraArtworkXdp()); bp.topMargin=dp(ui.extraArtworkYdp()); bp.width=dp(ui.extraArtworkWidthDp()); bp.height=dp(ui.extraArtworkHeightDp()); heroBannerImage.setLayoutParams(bp); String extra=extraArtworkFor(m); if(ui.extraArtworkEnabled()==0||extra.isEmpty()){heroBannerImage.setImageDrawable(null);heroBannerImage.setAlpha(0f);} else {heroBannerImage.setAlpha(ui.extraArtworkOpacityPercent()/100f);loadImage(extra,heroBannerImage,true);}}
    }
    String first(String...v){for(String x:v)if(x!=null&&!x.trim().isEmpty())return x.trim();return "";}
    boolean looksPortraitOrLogo(String u){
        if(u==null)return true;
        String x=u.trim().toLowerCase(Locale.US);
        if(x.isEmpty())return true;
        return x.contains("/poster/")||x.contains("poster")||x.contains("portrait")||x.contains("thumbnail")||x.contains("thumb")||x.contains("/logo/")||x.contains("clearlogo")||x.contains("clear_logo")||x.contains("clear-logo");
    }
    boolean isSafeCardLogo(String u){
        if(u==null)return false;
        String x=u.trim().toLowerCase(Locale.US);
        if(x.isEmpty())return false;
        if(x.contains("poster")||x.contains("background")||x.contains("backdrop")||x.contains("thumbnail")||x.contains("thumb")||x.contains("portrait")||x.contains("landscape")||x.contains("banner"))return false;
        return x.contains("/logo/")||x.contains("clearlogo")||x.contains("clear_logo")||x.contains("clear-logo")||x.contains("fanart.tv/fanart/");
    }
    String cardLogoArtwork(Movie m){
        if(m==null)return "";
        if(isSafeCardLogo(m.logo))return m.logo.trim();
        if(m.id!=null && m.id.trim().startsWith("tt"))return "https://images.metahub.space/logo/medium/"+m.id.trim()+"/img";
        return "";
    }
    String rowArtwork(Movie m){
        if(m==null)return "";
        if(m.banner!=null&&!m.banner.trim().isEmpty()&&!looksPortraitOrLogo(m.banner))return m.banner.trim();
        if(m.background!=null&&!m.background.trim().isEmpty()&&!looksPortraitOrLogo(m.background))return m.background.trim();
        return "";
    }

    final Set<String> ratingFetchInFlight = Collections.synchronizedSet(new HashSet<String>());
    void fetchMissingRatingsOnce(Movie m){
        if(m==null)return;
        if(!first(m.imdbRating,m.tmdbRating).isEmpty())return;
        String id=first(m.id,extractImdbId(m.meta));
        if(id.isEmpty()||!id.startsWith("tt")||ratingFetchInFlight.contains(id))return;
        ratingFetchInFlight.add(id);
        new Thread(()->{
            try{
                String txt=httpGet("https://v3-cinemeta.strem.io/meta/movie/"+URLEncoder.encode(id,"UTF-8")+".json");
                JSONObject obj=new JSONObject(txt).optJSONObject("meta");
                if(obj==null)return;
                String imdb=ratingFrom(obj,"imdbRating","imdb_rating","imdbScore","imdb");
                String tmdb=ratingFrom(obj,"tmdbRating","tmdb_rating","tmdbScore","tmdb","vote_average");
                if(!imdb.isEmpty()||!tmdb.isEmpty()){
                    runOnUiThread(()->{
                        if(m.imdbRating.isEmpty())m.imdbRating=imdb;
                        if(m.tmdbRating.isEmpty())m.tmdbRating=tmdb;
                        lockRatings(m);
                        if(heroRatingRow!=null)buildHeroRatingRow(m);
                    });
                }
            }catch(Exception e){AppLogger.mark("Cinemeta rating fill skipped: "+e.getMessage());}
        }).start();
    }

    void showCatalogs(String type){suppressRowAutoFocus=false;clear();nav.go(NavigationController.Screen.VOD);backdrop();addMenu();TextView h=tv(type,38,Typeface.BOLD);h.setGravity(Gravity.LEFT);FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(dp(500),dp(60));hp.leftMargin=dp(55);hp.topMargin=dp(115);root.addView(h,hp);addHeroRows();}

    void showMovieDetails(Movie m){
        suppressRowAutoFocus=false; lockRatings(m); selectedMedia = new SelectedMedia(m);
        clear();backdrop();addMenu();updateHero(m);
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.HORIZONTAL);panel.setGravity(Gravity.CENTER_VERTICAL);panel.setPadding(dp(56),dp(110),dp(56),dp(40));
        FrameLayout.LayoutParams ppnl=new FrameLayout.LayoutParams(-1,dp(520));ppnl.topMargin=dp(80);root.addView(panel,ppnl);
        CardFrame posterFrame=new CardFrame(this,dp(18));posterFrame.setBackground(cardBg(230));
        ImageView poster=new ImageView(this);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);posterFrame.addView(poster,new FrameLayout.LayoutParams(-1,-1));String posterUrl=first(m.poster,m.background);if(!posterUrl.isEmpty())loadImage(posterUrl,poster,false);
        LinearLayout.LayoutParams pflp=new LinearLayout.LayoutParams(dp(250),dp(370));pflp.setMargins(0,0,dp(38),0);panel.addView(posterFrame,pflp);
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);panel.addView(info,new LinearLayout.LayoutParams(0,-1,1));
        ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);String lg=cardLogoArtwork(m);if(isSafeCardLogo(lg)){loadImage(lg,logo,false);info.addView(logo,new LinearLayout.LayoutParams(dp(520),dp(120)));}else{TextView title=tv(m.title,42,Typeface.BOLD);title.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);info.addView(title,new LinearLayout.LayoutParams(-1,dp(90)));}
        LinearLayout ratings=new LinearLayout(this);ratings.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);ratings.setOrientation(LinearLayout.HORIZONTAL);info.addView(ratings,new LinearLayout.LayoutParams(-1,dp(42)));buildRatingRowInto(ratings,m,true);
        TextView desc=tv(first(m.overview,"Select Play to load Stremio addon streams for this title."),18,Typeface.NORMAL);desc.setGravity(Gravity.LEFT|Gravity.TOP);desc.setLineSpacing(dp(2),1.02f);desc.setAlpha(.92f);info.addView(desc,new LinearLayout.LayoutParams(dp(720),dp(130)));
        LinearLayout buttons=new LinearLayout(this);buttons.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);info.addView(buttons,new LinearLayout.LayoutParams(-1,dp(76)));
        TextView play=btn("▶ Play / Select Streams");TextView back=btn("Back");buttons.addView(play,new LinearLayout.LayoutParams(dp(310),dp(58)));LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(dp(150),dp(58));blp.setMargins(dp(16),0,0,0);buttons.addView(back,blp);
        play.setOnClickListener(v->showStreamList(m));back.setOnClickListener(v->showHome());play.requestFocus();
    }

    void buildRatingRowInto(LinearLayout row, Movie m, boolean includeTag){
        row.removeAllViews(); String y=first(m.year,extractYear(m.meta));
        if(!y.isEmpty())addMetaPiece(row,metaText(y,Color.rgb(255,220,56),Typeface.BOLD),-2,30,0);
        if(includeTag){addMetaPiece(row,metaText("•",Color.WHITE,Typeface.BOLD),-2,30,12);addMetaPiece(row,metaText(first(m.tag,"FEATURED").toUpperCase(Locale.US),Color.WHITE,Typeface.BOLD),-2,30,12);}
        String imdb=first(m.imdbRating,extractRating(m.meta,"IMDB"),extractRating(m.meta,"IMDb"));
        if(!imdb.isEmpty()){addMetaPiece(row,badge("IMDb",Color.rgb(245,197,24),Color.BLACK),58,24,20);addMetaPiece(row,metaText(imdb,Color.WHITE,Typeface.NORMAL),-2,30,8);}
        String tmdb=first(m.tmdbRating,extractRating(m.meta,"TMDB"));
        if(!tmdb.isEmpty()){addMetaPiece(row,metaText("|",Color.argb(210,255,255,255),Typeface.NORMAL),-2,30,14);addMetaPiece(row,badge("TMDB",Color.rgb(1,180,228),Color.WHITE),62,24,14);addMetaPiece(row,metaText(tmdb,Color.WHITE,Typeface.NORMAL),-2,30,8);}
    }

    void showStreamList(Movie m){
        lockRatings(m); selectedMedia = new SelectedMedia(m); clear();backdrop();addMenu();updateHero(m);
        LinearLayout p=form("Select stream"); TextView sub=tv("Loading Stremio addon links for " + m.title + "…",18,Typeface.NORMAL);sub.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);p.addView(sub,new LinearLayout.LayoutParams(-1,dp(54)));
        new Thread(()->{ArrayList<StreamLink> links=loadStremioStreams(m);runOnUiThread(()->renderStreamList(m,links));}).start();
    }

    void renderStreamList(Movie m, ArrayList<StreamLink> links){
        lockRatings(m); selectedMedia = new SelectedMedia(m); selectedMedia.streams.addAll(links); clear();backdrop();addMenu();updateHero(m);
        LinearLayout p=form("Select stream"); LinearLayout head=new LinearLayout(this);head.setOrientation(LinearLayout.VERTICAL);head.setPadding(0,0,0,dp(8));p.addView(head,new LinearLayout.LayoutParams(-1,dp(112)));
        TextView title=tv(m.title,28,Typeface.BOLD);title.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);head.addView(title,new LinearLayout.LayoutParams(-1,dp(48)));
        LinearLayout ratingLine=new LinearLayout(this);ratingLine.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);head.addView(ratingLine,new LinearLayout.LayoutParams(-1,dp(38)));buildRatingRowInto(ratingLine,m,true);
        if(links.isEmpty()){TextView none=tv("No playable streams found. Make sure the Stremio addon provides stream links, not just catalogs.",20,Typeface.BOLD);none.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);none.setPadding(dp(18),0,dp(18),0);none.setBackground(bg(Color.argb(130,70,24,24),18));p.addView(none,new LinearLayout.LayoutParams(dp(980),dp(86)));none.requestFocus();return;}
        for(StreamLink link:links){TextView row=streamButton(link);row.setOnClickListener(v->showMedia3Player(m,link));p.addView(row,new LinearLayout.LayoutParams(dp(1040),dp(78)));}
        if(p.getChildCount()>2)p.getChildAt(2).requestFocus();
    }

    TextView streamButton(StreamLink l){
        String label="  ▶  "+first(l.name,l.title,"Stream"); if(l.needsResolver())label+="    [Resolver]"; else if(l.external)label+="    [Try Direct]"; if(!l.quality.isEmpty())label+="    ["+l.quality+"]"; if(!l.size.isEmpty())label+="    "+l.size; if(!l.source.isEmpty())label+="    • "+l.source;
        String second=first(l.description,l.url); if(second.length()>120)second=second.substring(0,117)+"…";
        TextView b=btn(label+"\n     "+second);b.setTextSize(17);b.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);b.setPadding(dp(18),0,dp(18),0);b.setBackground(stroke(Color.argb(140,12,18,30),Color.argb(72,255,255,255)));return b;
    }

    ArrayList<StreamLink> loadStremioStreams(Movie m){
        ArrayList<StreamLink> out=new ArrayList<>();
        String links=stremio.getJsonLinks();
        if(links==null||links.trim().isEmpty())return out;
        String[] parts=links.split("[\\n, ]+");
        for(String raw:parts){
            String manifest=raw.trim();
            if(manifest.isEmpty()||!manifest.startsWith("http"))continue;
            try{
                String base=manifest;
                int ix=base.indexOf("/manifest.json");
                if(ix>=0)base=base.substring(0,ix);
                while(base.endsWith("/"))base=base.substring(0,base.length()-1);
                String type=first(m.type,"movie").toLowerCase(Locale.US);
                if(type.equals("show")||type.equals("tv"))type="series";
                if(!type.equals("series"))type="movie";
                String id=first(m.id,extractImdbId(m.meta));
                if(id.isEmpty())continue;
                String endpoint=base+"/stream/"+type+"/"+URLEncoder.encode(id,"UTF-8").replace("+","%20")+".json";
                String txt=httpGet(endpoint);
                JSONObject obj=new JSONObject(txt);
                JSONArray arr=obj.optJSONArray("streams");
                if(arr==null)continue;
                for(int i=0;i<arr.length();i++){
                    JSONObject so=arr.optJSONObject(i); if(so==null)continue;
                    JSONObject hints=so.optJSONObject("behaviorHints");
                    String name=first(so.optString("name",""),so.optString("title",""),"Stream");
                    String desc=first(so.optString("description",""),so.optString("title",""),name);
                    String text=(name+" "+desc+" "+so.optString("title","")).trim();
                    String url=so.optString("url","").trim();
                    boolean external=false;
                    String ext=so.optString("externalUrl","").trim();
                    String infoHash=so.optString("infoHash","").trim();
                    if(infoHash.isEmpty() && hints!=null) infoHash=hints.optString("infoHash","").trim();
                    String magnet="";
                    if(ext.startsWith("magnet:")) magnet=ext;
                    else if(hints!=null && hints.optString("magnet","").startsWith("magnet:")) magnet=hints.optString("magnet","");
                    else if(!infoHash.isEmpty()) magnet="magnet:?xt=urn:btih:"+infoHash;
                    if(url.isEmpty()){
                        url=ext;
                        external=!url.isEmpty();
                    }
                    if(url.isEmpty() && !magnet.isEmpty()) url=magnet;
                    if(url.isEmpty() && infoHash.isEmpty() && magnet.isEmpty()) continue;
                    StreamLink sl=new StreamLink();
                    sl.url=url; sl.magnet=magnet; sl.infoHash=infoHash; sl.external=external || looksLikeExternalPage(url);
                    sl.name=name; sl.title=so.optString("title",""); sl.description=desc; sl.source=hostLabel(base);
                    sl.quality=inferQuality(text+" "+url); sl.size=inferSize(text); sl.sizeBytes=parseSizeBytes(text); sl.qualityScore=scoreQuality(text);
                    sl.dolbyVision=looksDolbyVision(text); sl.hdr10Plus=looksHdr10Plus(text); sl.hdr=sl.dolbyVision||sl.hdr10Plus||looksHdr(text);
                    if(so.has("fileIdx")) sl.fileIdx=so.optInt("fileIdx",-1); else if(hints!=null&&hints.has("fileIdx"))sl.fileIdx=hints.optInt("fileIdx",-1);
                    out.add(sl);
                }
            }catch(Exception e){AppLogger.mark("Stremio stream load failed: "+e.getMessage()+" manifest="+manifest);}
        }
        Collections.sort(out,(a,b)->Integer.compare(b.qualityScore,a.qualityScore));
        return out;
    }

    String extractImdbId(String meta){if(meta==null)return "";java.util.regex.Matcher m=java.util.regex.Pattern.compile("tt\\d+").matcher(meta);return m.find()?m.group():"";}
    String inferQuality(String s){String u=s==null?"":s.toUpperCase(Locale.US);if(u.contains("2160")||u.contains("4K")||u.contains("UHD"))return "4K";if(u.contains("1080"))return "1080p";if(u.contains("720"))return "720p";if(u.contains("HDR10+"))return "HDR10+";if(u.contains("HDR"))return "HDR";return "";}
    String inferSize(String s){if(s==null)return "";java.util.regex.Matcher m=java.util.regex.Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(GB|GIB|MB|MIB)",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(s);return m.find()?m.group(1)+" "+m.group(2).toUpperCase(Locale.US).replace("GIB","GB").replace("MIB","MB"):"";}
    long parseSizeBytes(String text){try{java.util.regex.Matcher m=java.util.regex.Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(GB|GIB|MB|MIB)",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(text==null?"":text);if(!m.find())return 0;double v=Double.parseDouble(m.group(1));String unit=m.group(2).toLowerCase(Locale.US);return (long)(v*(unit.startsWith("g")?1024d*1024d*1024d:1024d*1024d));}catch(Exception e){return 0;}}
    int scoreQuality(String text){String u=text==null?"":text.toLowerCase(Locale.US);int q=(u.contains("2160")||u.contains("4k")||u.contains("uhd"))?400:(u.contains("1080")?300:(u.contains("720")?200:100));if(u.contains("remux"))q+=40;else if(u.contains("bluray")||u.contains("blu-ray"))q+=30;else if(u.contains("web-dl")||u.contains("webdl")||u.contains("webrip"))q+=20;return q;}
    boolean looksDolbyVision(String text){String u=(text==null?"":text).toLowerCase(Locale.US);return u.contains("dolby vision")||u.contains("dovi")||u.contains(" dv ")||u.contains(".dv.")||u.contains("-dv-");}
    boolean looksHdr10Plus(String text){String u=(text==null?"":text).toLowerCase(Locale.US);return u.contains("hdr10+")||u.contains("hdr10plus")||u.contains("hdr 10+");}
    boolean looksHdr(String text){String u=(text==null?"":text).toLowerCase(Locale.US);return u.contains("hdr")||u.contains("hlg")||u.contains("bt2020")||u.contains("bt.2020");}
    boolean isLikelyVideoFile(String path){String u=(path==null?"":path).toLowerCase(Locale.US);return u.contains(".mkv")||u.contains(".mp4")||u.contains(".avi")||u.contains(".ts")||u.contains(".m2ts")||u.contains(".mov")||u.contains(".wmv");}
    String hostLabel(String url){try{return new URL(url).getHost().replace("www.","");}catch(Exception e){return "Stremio";}}
    boolean looksLikeExternalPage(String url){if(url==null||url.isEmpty())return false;String u=url.toLowerCase(Locale.US);if(u.startsWith("magnet:"))return false;if(!(u.startsWith("http://")||u.startsWith("https://")))return true;if(u.contains("youtube.com")||u.contains("youtu.be")||u.contains("imdb.com")||u.contains("stremio.com"))return true;return false;}

    String resolverMode(){ return backend.playbackResolverMode(); }
    ArrayList<String> resolverOrder(){ArrayList<String> order=new ArrayList<>();String mode=resolverMode();if(mode.equals("realdebrid")){order.add("realdebrid");order.add("direct");}else if(mode.equals("torbox")){order.add("torbox");order.add("direct");}else if(mode.equals("auto")){order.add("realdebrid");order.add("torbox");order.add("direct");}else{order.add("direct");order.add("realdebrid");order.add("torbox");}return order;}
    String resolvePlayableUrl(StreamLink link){if(link==null)return "";String url=link.url==null?"":link.url.trim();for(String provider:resolverOrder()){String resolved="";if(provider.equals("direct"))resolved=resolveDirect(link);else if(provider.equals("realdebrid"))resolved=resolveWithRealDebrid(link);else if(provider.equals("torbox"))resolved=resolveWithTorbox(link);if(resolved!=null&&!resolved.isEmpty()){AppLogger.mark("STREAM_RESOLVE provider="+provider+" host="+hostLabel(resolved));return resolved;}}if(url.startsWith("http://")||url.startsWith("https://"))return url;return "";}
    String resolveDirect(StreamLink link){String url=link.url==null?"":link.url.trim();return (url.startsWith("http://")||url.startsWith("https://"))?url:"";}
    String resolveWithRealDebrid(StreamLink link){String api=backend.realDebridApiKey();if(api==null||api.trim().isEmpty())return "";String direct=resolveDirect(link);if(!direct.isEmpty()&&!link.hasResolverPayload())return realDebridUnrestrict(api,direct);if(!direct.isEmpty()&&!direct.startsWith("magnet:")){String u=realDebridUnrestrict(api,direct);if(!u.isEmpty())return u;}String magnet=first(link.magnet,link.infoHash==null||link.infoHash.isEmpty()?"":"magnet:?xt=urn:btih:"+link.infoHash,link.url!=null&&link.url.startsWith("magnet:")?link.url:"");if(magnet.isEmpty())return "";String torrentId=realDebridAddMagnet(api,magnet);if(torrentId.isEmpty())return "";JSONObject before=realDebridTorrentInfo(api,torrentId);String files=chooseRealDebridFiles(before,link.fileIdx);if(!realDebridSelectFiles(api,torrentId,files))return "";for(int attempt=0;attempt<6;attempt++){try{Thread.sleep(attempt==0?1200:2000);}catch(Exception ignored){}JSONObject info=realDebridTorrentInfo(api,torrentId);if(info==null)continue;JSONArray links=info.optJSONArray("links");if(links==null)continue;for(int i=0;i<links.length();i++){String l=links.optString(i,"");if(l.startsWith("http")){String unr=realDebridUnrestrict(api,l);if(!unr.isEmpty())return unr;}}}return "";}
    String chooseRealDebridFiles(JSONObject info,int desired){if(info==null)return "all";JSONArray files=info.optJSONArray("files");if(files==null||files.length()==0)return "all";if(desired>=0&&desired<files.length()){JSONObject f=files.optJSONObject(desired);int id=f==null?0:f.optInt("id",0);if(id>0)return String.valueOf(id);}for(int i=0;i<files.length();i++){JSONObject f=files.optJSONObject(i);if(f!=null&&isLikelyVideoFile(f.optString("path"))){int id=f.optInt("id",0);if(id>0)return String.valueOf(id);}}return "all";}
    String realDebridAddMagnet(String api,String magnet){JSONObject j=httpFormJsonObj("https://api.real-debrid.com/rest/1.0/torrents/addMagnet","POST",mapAuth(api),linkedForm("magnet",magnet));return j==null?"":j.optString("id","");}
    boolean realDebridSelectFiles(String api,String torrentId,String files){HttpURLConnection c=null;try{c=openFormConnection("https://api.real-debrid.com/rest/1.0/torrents/selectFiles/"+torrentId,"POST",mapAuth(api),linkedForm("files",files));int code=c.getResponseCode();return code>=200&&code<300||code==202;}catch(Exception e){AppLogger.mark("RD select files failed: "+e.getMessage());return false;}finally{if(c!=null)c.disconnect();}}
    JSONObject realDebridTorrentInfo(String api,String torrentId){return httpGetJsonObj("https://api.real-debrid.com/rest/1.0/torrents/info/"+torrentId,mapAuth(api));}
    String realDebridUnrestrict(String api,String link){JSONObject j=httpFormJsonObj("https://api.real-debrid.com/rest/1.0/unrestrict/link","POST",mapAuth(api),linkedForm("link",link));if(j==null)return "";return first(j.optString("download",""),j.optString("link",""));}
    String resolveWithTorbox(StreamLink link){String api=backend.torboxApiKey();if(api==null||api.trim().isEmpty())return "";String direct=resolveDirect(link);if(!direct.isEmpty()&&!link.hasResolverPayload())return direct;String magnet=first(link.magnet,link.infoHash==null||link.infoHash.isEmpty()?"":"magnet:?xt=urn:btih:"+link.infoHash,link.url!=null&&link.url.startsWith("magnet:")?link.url:"");if(magnet.isEmpty())return direct;int tid=torboxCreateTorrent(api,magnet);if(tid<=0)return direct;for(int a=0;a<6;a++){try{Thread.sleep(a==0?1200:2000);}catch(Exception ignored){}JSONObject info=torboxTorrentInfo(api,tid);if(info==null)continue;int fileId=chooseTorboxFileId(info,link.fileIdx);String dl=torboxRequestDl(api,tid,fileId);if(!dl.isEmpty())return dl;}return direct;}
    int torboxCreateTorrent(String api,String magnet){JSONObject j=httpFormJsonObj("https://api.torbox.app/v1/api/torrents/createtorrent","POST",mapAuth(api),linkedForm("magnet",magnet,"seed","1","allow_zip","true","as_queued","false"));if(j==null)return 0;JSONObject d=j.optJSONObject("data");return d!=null?Math.max(d.optInt("torrent_id",0),d.optInt("id",0)):Math.max(j.optInt("torrent_id",0),j.optInt("id",0));}
    JSONObject torboxTorrentInfo(String api,int tid){JSONObject j=httpGetJsonObj("https://api.torbox.app/v1/api/torrents/mylist?id="+tid+"&bypass_cache=true",mapAuth(api));if(j==null)return null;Object d=j.opt("data");if(d instanceof JSONObject)return (JSONObject)d;if(d instanceof JSONArray)return ((JSONArray)d).optJSONObject(0);return null;}
    int chooseTorboxFileId(JSONObject info,int desired){JSONArray[] arrays=new JSONArray[]{info.optJSONArray("files"),info.optJSONArray("download_files"),info.optJSONArray("file_list")};for(JSONArray files:arrays){if(files==null)continue;if(desired>=0&&desired<files.length()){JSONObject f=files.optJSONObject(desired);int id=f==null?0:Math.max(f.optInt("id",0),f.optInt("file_id",0));if(id>0)return id;}for(int i=0;i<files.length();i++){JSONObject f=files.optJSONObject(i);if(f!=null&&isLikelyVideoFile(first(f.optString("short_name",""),f.optString("name",""),f.optString("path","")))){int id=Math.max(f.optInt("id",0),f.optInt("file_id",0));if(id>0)return id;}}}return 0;}
    String torboxRequestDl(String api,int tid,int fileId){try{String suffix="token="+URLEncoder.encode(api,"UTF-8")+"&torrent_id="+tid+"&file_id="+fileId+"&zip_link=false&redirect=false";JSONObject j=httpGetJsonObj("https://api.torbox.app/v1/api/torrents/requestdl?"+suffix,new HashMap<String,String>());if(j==null)return "";Object d=j.opt("data");if(d instanceof String)return (String)d;if(d instanceof JSONObject){JSONObject o=(JSONObject)d;return first(o.optString("download",""),o.optString("url",""),o.optString("link",""));}}catch(Exception e){AppLogger.mark("Torbox requestdl failed: "+e.getMessage());}return "";}
    Map<String,String> mapAuth(String api){HashMap<String,String> h=new HashMap<>();h.put("Authorization","Bearer "+api);return h;}
    LinkedHashMap<String,String> linkedForm(String...kv){LinkedHashMap<String,String> m=new LinkedHashMap<>();for(int i=0;i+1<kv.length;i+=2)m.put(kv[i],kv[i+1]);return m;}
    JSONObject httpGetJsonObj(String url,Map<String,String> headers){HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod("GET");c.setConnectTimeout(12000);c.setReadTimeout(20000);c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","ChannelsDebridTV/0.1.9");for(Map.Entry<String,String> e:headers.entrySet())c.setRequestProperty(e.getKey(),e.getValue());String body=readHttpBody(c);if(c.getResponseCode()<200||c.getResponseCode()>=300||body.isEmpty())return null;return new JSONObject(body);}catch(Exception e){AppLogger.mark("HTTP JSON get failed: "+e.getMessage()+" url="+url);return null;}finally{if(c!=null)c.disconnect();}}
    JSONObject httpFormJsonObj(String url,String method,Map<String,String> headers,LinkedHashMap<String,String> form){HttpURLConnection c=null;try{c=openFormConnection(url,method,headers,form);String body=readHttpBody(c);if(c.getResponseCode()<200||c.getResponseCode()>=300||body.isEmpty())return null;return new JSONObject(body);}catch(Exception e){AppLogger.mark("HTTP form failed: "+e.getMessage()+" url="+url);return null;}finally{if(c!=null)c.disconnect();}}
    HttpURLConnection openFormConnection(String url,String method,Map<String,String> headers,LinkedHashMap<String,String> form)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod(method);c.setDoOutput(true);c.setConnectTimeout(12000);c.setReadTimeout(30000);c.setRequestProperty("Accept","application/json");c.setRequestProperty("Content-Type","application/x-www-form-urlencoded");c.setRequestProperty("User-Agent","ChannelsDebridTV/0.1.9");for(Map.Entry<String,String> e:headers.entrySet())c.setRequestProperty(e.getKey(),e.getValue());StringBuilder body=new StringBuilder();for(Map.Entry<String,String> e:form.entrySet()){if(body.length()>0)body.append('&');body.append(URLEncoder.encode(e.getKey(),"UTF-8")).append('=').append(URLEncoder.encode(e.getValue(),"UTF-8"));}try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes("UTF-8"));}return c;}
    String readHttpBody(HttpURLConnection c)throws Exception{InputStream in=(c.getResponseCode()>=200&&c.getResponseCode()<300)?c.getInputStream():c.getErrorStream();if(in==null)return "";try(InputStream stream=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n;while((n=stream.read(buf))>0)out.write(buf,0,n);return out.toString("UTF-8");}}
    String inferMime(String url){String u=url==null?"":url.substring(0, url.indexOf('?')>=0?url.indexOf('?'):url.length()).toLowerCase(Locale.US);if(u.endsWith(".m3u8")||u.contains("m3u8"))return MimeTypes.APPLICATION_M3U8;if(u.endsWith(".mpd"))return MimeTypes.APPLICATION_MPD;if(u.endsWith(".ts")||u.contains("/auto/v"))return MimeTypes.VIDEO_MP2T;if(u.endsWith(".mp4"))return MimeTypes.VIDEO_MP4;return null;}

    void showMedia3Player(Movie m, StreamLink link){
        lockRatings(m);
        if(selectedMedia==null) selectedMedia = new SelectedMedia(m);
        clear();backdrop();addMenu();updateHero(m);
        LinearLayout p=form("Resolving stream");
        TextView msg=tv("Resolving source through Stremio / Real-Debrid / Torbox…",20,Typeface.BOLD);
        msg.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);msg.setPadding(dp(18),0,dp(18),0);
        msg.setBackground(bg(Color.argb(150,12,18,30),18));
        p.addView(msg,new LinearLayout.LayoutParams(dp(1060),dp(78)));msg.requestFocus();
        new Thread(()->{String playUrl=resolvePlayableUrl(link);runOnUiThread(()->{if(playUrl==null||playUrl.isEmpty()){Toast.makeText(this,"This stream needs a resolver or could not be resolved.",Toast.LENGTH_LONG).show();renderPlaybackErrorStreamList(m, link, "RESOLVE_FAILED");return;}startResolvedMedia3Player(m, link, playUrl);});}).start();
    }

    void startResolvedMedia3Player(Movie m, StreamLink link, String playUrl){
        lockRatings(m); clear();
        if(exoPlayer!=null){try{exoPlayer.release();}catch(Exception ignored){} exoPlayer=null;}
        PlayerView pv=new PlayerView(this);pv.setUseController(false);pv.setFocusable(false);pv.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);activePlayerView=pv;activeZoomMode=0;root.addView(pv,new FrameLayout.LayoutParams(-1,-1));
        TextView loading=tv("Loading stream…",22,Typeface.BOLD);loading.setGravity(Gravity.CENTER);loading.setBackgroundColor(Color.argb(110,0,0,0));root.addView(loading,new FrameLayout.LayoutParams(-1,-1));
        try{
            DefaultHttpDataSource.Factory httpFactory=new DefaultHttpDataSource.Factory().setUserAgent("DebridChannelsTV/0.1.9").setAllowCrossProtocolRedirects(true).setConnectTimeoutMs(10000).setReadTimeoutMs(15000);
            DefaultLoadControl loadControl=new DefaultLoadControl.Builder().setBufferDurationsMs(5000,30000,1000,2500).setBackBuffer(0,true).setPrioritizeTimeOverSizeThresholds(true).build();
            DefaultRenderersFactory renderersFactory=new DefaultRenderersFactory(this).setEnableDecoderFallback(true).setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER);
            exoPlayer=new ExoPlayer.Builder(this,renderersFactory).setMediaSourceFactory(new DefaultMediaSourceFactory(httpFactory)).setLoadControl(loadControl).setSeekBackIncrementMs(10000).setSeekForwardIncrementMs(10000).build();
            pv.setPlayer(exoPlayer);
            exoPlayer.addListener(new Player.Listener(){
                @Override public void onPlaybackStateChanged(int state){AppLogger.mark("Media3 state="+state+" url="+playUrl);if(state==Player.STATE_READY){loading.setVisibility(View.GONE);}else if(state==Player.STATE_BUFFERING){loading.setText("Buffering stream…");loading.setVisibility(View.VISIBLE);}else if(state==Player.STATE_ENDED){loading.setText("Playback ended");loading.setVisibility(View.VISIBLE);}}
                @Override public void onPlayerError(PlaybackException error){AppLogger.mark("Media3 playback error: "+error.getErrorCodeName()+" "+error.getMessage()+" url="+playUrl);Toast.makeText(MainActivity.this,"Playback failed: "+error.getErrorCodeName(),Toast.LENGTH_LONG).show();try{if(exoPlayer!=null){exoPlayer.release();exoPlayer=null;}}catch(Exception ignored){}renderPlaybackErrorStreamList(m, link, error.getErrorCodeName());}
            });
            MediaItem.Builder item=new MediaItem.Builder().setUri(Uri.parse(playUrl));String mime=inferMime(playUrl);if(mime!=null)item.setMimeType(mime);exoPlayer.setMediaItem(item.build(),true);exoPlayer.prepare();exoPlayer.setPlayWhenReady(true);exoPlayer.play();
        }catch(Exception e){AppLogger.mark("Media3 start failed: "+e.getMessage());Toast.makeText(this,"Playback failed: "+e.getMessage(),Toast.LENGTH_LONG).show();renderPlaybackErrorStreamList(m, link, "START_FAILED");return;}
        buildCinematicPlayerOverlay(m,link);
        startPlayerProgressUpdates();
    }

    void renderPlaybackErrorStreamList(Movie m, StreamLink failed, String code){
        clear();backdrop();addMenu();updateHero(m);
        LinearLayout p=form("Select stream");
        TextView warn=tv("Playback failed: "+code+". Try another stream, or use Real-Debrid/Torbox resolver mode for protected links.",18,Typeface.BOLD);
        warn.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);warn.setPadding(dp(18),0,dp(18),0);warn.setBackground(bg(Color.argb(160,90,28,20),18));
        p.addView(warn,new LinearLayout.LayoutParams(dp(1060),dp(76)));
        ArrayList<StreamLink> links = selectedMedia!=null ? selectedMedia.streams : new ArrayList<>();
        if(links.isEmpty() && failed!=null)links.add(failed);
        for(StreamLink sl:links){TextView row=streamButton(sl);row.setOnClickListener(v->showMedia3Player(m,sl));p.addView(row,new LinearLayout.LayoutParams(dp(1040),dp(78)));}
        if(p.getChildCount()>1)p.getChildAt(1).requestFocus(); else warn.requestFocus();
    }

    void buildCinematicPlayerOverlay(Movie m, StreamLink link){
        FrameLayout overlay=new FrameLayout(this);overlay.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,new int[]{Color.argb(235,0,0,0),Color.argb(110,0,0,0),Color.TRANSPARENT}));root.addView(overlay,new FrameLayout.LayoutParams(-1,-1));
        overlay.setFocusable(true); overlay.setFocusableInTouchMode(true);
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.HORIZONTAL);info.setGravity(Gravity.BOTTOM|Gravity.LEFT);info.setPadding(dp(46),0,dp(46),dp(98));overlay.addView(info,new FrameLayout.LayoutParams(-1,-1));
        CardFrame posterFrame=new CardFrame(this,dp(16));posterFrame.setBackground(cardBg(230));ImageView poster=new ImageView(this);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);posterFrame.addView(poster,new FrameLayout.LayoutParams(-1,-1));String posterUrl=first(m.poster,m.background);if(!posterUrl.isEmpty())loadImage(posterUrl,poster,false);LinearLayout.LayoutParams plp=new LinearLayout.LayoutParams(dp(160),dp(238));plp.setMargins(0,0,dp(26),0);info.addView(posterFrame,plp);
        LinearLayout text=new LinearLayout(this);text.setOrientation(LinearLayout.VERTICAL);text.setGravity(Gravity.BOTTOM|Gravity.LEFT);info.addView(text,new LinearLayout.LayoutParams(0,dp(260),1));
        ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);String lg=cardLogoArtwork(m);if(isSafeCardLogo(lg)){text.addView(logo,new LinearLayout.LayoutParams(dp(430),dp(78)));loadImage(lg,logo,false);}else{TextView title=tv(m.title,34,Typeface.BOLD);title.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);text.addView(title,new LinearLayout.LayoutParams(-1,dp(70)));}
        LinearLayout ratingLine=new LinearLayout(this);ratingLine.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);text.addView(ratingLine,new LinearLayout.LayoutParams(-1,dp(36)));buildRatingRowInto(ratingLine,m,true);
        TextView desc=tv(first(m.overview,link.description),16,Typeface.NORMAL);desc.setGravity(Gravity.LEFT|Gravity.TOP);desc.setAlpha(.9f);text.addView(desc,new LinearLayout.LayoutParams(dp(760),dp(76)));
        LinearLayout progressWrap=new LinearLayout(this);progressWrap.setOrientation(LinearLayout.HORIZONTAL);progressWrap.setGravity(Gravity.CENTER_VERTICAL);text.addView(progressWrap,new LinearLayout.LayoutParams(dp(900),dp(34)));
        activePlayerProgress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);activePlayerProgress.setMax(1000);progressWrap.addView(activePlayerProgress,new LinearLayout.LayoutParams(0,dp(10),1));
        activePlayerTime=tv("0:00 / 0:00",14,Typeface.NORMAL);activePlayerTime.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(dp(150),dp(32));tlp.setMargins(dp(16),0,0,0);progressWrap.addView(activePlayerTime,tlp);
        LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.HORIZONTAL);controls.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);text.addView(controls,new LinearLayout.LayoutParams(-1,dp(62)));
        TextView playPause=btn("Pause");playPause.setOnClickListener(v->{togglePlayerPlayPause();schedulePlayerOverlayHide(overlay);});controls.addView(playPause,new LinearLayout.LayoutParams(dp(118),dp(54)));
        TextView rw=btn("-10");rw.setOnClickListener(v->{seekBy(-10000);schedulePlayerOverlayHide(overlay);});controls.addView(rw,new LinearLayout.LayoutParams(dp(92),dp(54)));
        TextView ff=btn("+10");ff.setOnClickListener(v->{seekBy(10000);schedulePlayerOverlayHide(overlay);});controls.addView(ff,new LinearLayout.LayoutParams(dp(92),dp(54)));
        TextView audio=btn("Audio");audio.setOnClickListener(v->{showAudioTrackPanel();});controls.addView(audio,new LinearLayout.LayoutParams(dp(118),dp(54)));
        TextView sub=btn("Subtitles");sub.setOnClickListener(v->{showSubtitleTrackPanel();});controls.addView(sub,new LinearLayout.LayoutParams(dp(150),dp(54)));
        TextView eps=btn("Episodes");eps.setOnClickListener(v->{showEpisodePanel();});controls.addView(eps,new LinearLayout.LayoutParams(dp(142),dp(54)));
        TextView zoom=btn("Zoom");zoom.setOnClickListener(v->{cycleZoomMode();schedulePlayerOverlayHide(overlay);});controls.addView(zoom,new LinearLayout.LayoutParams(dp(105),dp(54)));
        TextView settings=btn("Settings");settings.setOnClickListener(v->{showPlayerSettingsPanel();});controls.addView(settings,new LinearLayout.LayoutParams(dp(130),dp(54)));
        TextView back=btn("Back");back.setOnClickListener(v->{exitPlayerToDetails();});FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(150),dp(56),Gravity.RIGHT|Gravity.BOTTOM);bp.rightMargin=dp(42);bp.bottomMargin=dp(42);overlay.addView(back,bp);
        activePlayerOverlay = overlay;
        activePlayerPlayPause = playPause;
        activePlayerMovie = m;
        overlay.setOnKeyListener((v,keyCode,event)-> event.getAction()==KeyEvent.ACTION_DOWN && handlePlayerKey(keyCode));
        playPause.requestFocus();
        showPlayerOverlay(overlay);
        schedulePlayerOverlayHide(overlay);
    }

    boolean handlePlayerKey(int keyCode){
        if(activePlayerOverlay==null) return false;
        if(activePlayerOptionPanel!=null && activePlayerOptionPanel.getParent()!=null){
            if(keyCode==KeyEvent.KEYCODE_BACK){closePlayerOptionPanel();return true;}
            schedulePlayerOverlayHide(activePlayerOverlay);
            return false;
        }
        boolean hidden = activePlayerOverlay.getVisibility()!=View.VISIBLE || activePlayerOverlay.getAlpha() < 0.15f;
        if(hidden){
            showPlayerOverlay(activePlayerOverlay);
            if(activePlayerPlayPause!=null) activePlayerPlayPause.requestFocus();
            schedulePlayerOverlayHide(activePlayerOverlay);
            AppLogger.mark("Player overlay restored by key="+keyCode);
            return true;
        }
        showPlayerOverlay(activePlayerOverlay);
        if(keyCode==KeyEvent.KEYCODE_BACK){
            exitPlayerToDetails();
            return true;
        }
        if(keyCode==KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE){
            togglePlayerPlayPause(); schedulePlayerOverlayHide(activePlayerOverlay); return true;
        }
        if(keyCode==KeyEvent.KEYCODE_MEDIA_REWIND){
            seekBy(-10000); schedulePlayerOverlayHide(activePlayerOverlay); return true;
        }
        if(keyCode==KeyEvent.KEYCODE_MEDIA_FAST_FORWARD){
            seekBy(10000); schedulePlayerOverlayHide(activePlayerOverlay); return true;
        }
        // While controls are visible, DPAD arrows and OK are for moving/selecting buttons.
        if(keyCode==KeyEvent.KEYCODE_DPAD_LEFT || keyCode==KeyEvent.KEYCODE_DPAD_RIGHT || keyCode==KeyEvent.KEYCODE_DPAD_UP || keyCode==KeyEvent.KEYCODE_DPAD_DOWN || keyCode==KeyEvent.KEYCODE_DPAD_CENTER || keyCode==KeyEvent.KEYCODE_ENTER){
            schedulePlayerOverlayHide(activePlayerOverlay);
            return false;
        }
        schedulePlayerOverlayHide(activePlayerOverlay);
        return false;
    }


    void closePlayerOptionPanel(){
        try{ if(activePlayerOptionPanel!=null){ root.removeView(activePlayerOptionPanel); } }catch(Exception ignored){}
        activePlayerOptionPanel=null;
    }

    TextView playerOptionButton(String label, View.OnClickListener click){
        TextView b=btn(label);
        b.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);
        b.setPadding(dp(22),0,dp(22),0);
        b.setOnClickListener(v->{ click.onClick(v); closePlayerOptionPanel(); if(activePlayerOverlay!=null){activePlayerOverlay.setVisibility(View.VISIBLE);activePlayerOverlay.setAlpha(1f); schedulePlayerOverlayHide(activePlayerOverlay);} });
        return b;
    }

    void showPlayerOptionPanel(String title, ArrayList<TextView> buttons){
        if(activePlayerOverlay==null)return;
        closePlayerOptionPanel();
        activePlayerOverlay.setVisibility(View.VISIBLE);activePlayerOverlay.setAlpha(1f);
        FrameLayout panel=new FrameLayout(this);panel.setFocusable(false);panel.setBackground(bg(Color.argb(232,8,12,22),28));
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(dp(24),dp(18),dp(24),dp(24));panel.addView(p,new FrameLayout.LayoutParams(-1,-1));
        TextView h=tv(title,22,Typeface.BOLD);h.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);p.addView(h,new LinearLayout.LayoutParams(-1,dp(48)));
        if(buttons.isEmpty())buttons.add(playerOptionButton("No options available",v->{}));
        for(TextView b:buttons){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.setMargins(0,dp(5),0,dp(5));p.addView(b,lp);}
        TextView close=playerOptionButton("Close",v->{});p.addView(close,new LinearLayout.LayoutParams(-1,dp(52)));
        FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(dp(520),dp(Math.min(560,120+buttons.size()*62)),Gravity.RIGHT|Gravity.BOTTOM);fp.rightMargin=dp(44);fp.bottomMargin=dp(128);activePlayerOverlay.addView(panel,fp);activePlayerOptionPanel=panel;
        if(p.getChildCount()>1)p.getChildAt(1).requestFocus(); else close.requestFocus();
        if(playerOverlayHideRunnable!=null)playerOverlayHandler.removeCallbacks(playerOverlayHideRunnable);
    }

    void showAudioTrackPanel(){
        ArrayList<TextView> options=new ArrayList<>();
        options.add(playerOptionButton("Auto / Default audio",v->{try{if(exoPlayer!=null){TrackSelectionParameters p=exoPlayer.getTrackSelectionParameters().buildUpon().clearOverridesOfType(C.TRACK_TYPE_AUDIO).build();exoPlayer.setTrackSelectionParameters(p);Toast.makeText(this,"Audio: Auto",Toast.LENGTH_SHORT).show();}}catch(Exception e){Toast.makeText(this,"Audio change failed",Toast.LENGTH_SHORT).show();}}));
        try{
            if(exoPlayer!=null){Tracks tracks=exoPlayer.getCurrentTracks();int count=0;for(Tracks.Group g:tracks.getGroups()){if(g.getType()!=C.TRACK_TYPE_AUDIO)continue;for(int i=0;i<g.length;i++){final Tracks.Group fg=g;final int fi=i;Format f=g.getTrackFormat(i);String lang=(f.language==null||f.language.isEmpty())?"Unknown":f.language;String label=first(f.label,"");String text="Audio "+(++count)+" • "+lang+(label.isEmpty()?"":" • "+label);options.add(playerOptionButton(text,v->{try{TrackSelectionOverride o=new TrackSelectionOverride(fg.getMediaTrackGroup(),fi);TrackSelectionParameters p=exoPlayer.getTrackSelectionParameters().buildUpon().setOverrideForType(o).setTrackTypeDisabled(C.TRACK_TYPE_AUDIO,false).build();exoPlayer.setTrackSelectionParameters(p);Toast.makeText(this,text,Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Audio track failed",Toast.LENGTH_SHORT).show();}}));}}}
        }catch(Exception e){AppLogger.mark("Audio panel failed: "+e.getMessage());}
        showPlayerOptionPanel("Audio Tracks",options);
    }

    void showSubtitleTrackPanel(){
        ArrayList<TextView> options=new ArrayList<>();
        options.add(playerOptionButton("Subtitles Off",v->{try{if(exoPlayer!=null){TrackSelectionParameters p=exoPlayer.getTrackSelectionParameters().buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT,true).clearOverridesOfType(C.TRACK_TYPE_TEXT).build();exoPlayer.setTrackSelectionParameters(p);Toast.makeText(this,"Subtitles Off",Toast.LENGTH_SHORT).show();}}catch(Exception e){Toast.makeText(this,"Subtitle change failed",Toast.LENGTH_SHORT).show();}}));
        try{
            if(exoPlayer!=null){Tracks tracks=exoPlayer.getCurrentTracks();int count=0;for(Tracks.Group g:tracks.getGroups()){if(g.getType()!=C.TRACK_TYPE_TEXT)continue;for(int i=0;i<g.length;i++){final Tracks.Group fg=g;final int fi=i;Format f=g.getTrackFormat(i);String lang=(f.language==null||f.language.isEmpty())?"Unknown":f.language;String label=first(f.label,"");String text="Subtitle "+(++count)+" • "+lang+(label.isEmpty()?"":" • "+label);options.add(playerOptionButton(text,v->{try{TrackSelectionOverride o=new TrackSelectionOverride(fg.getMediaTrackGroup(),fi);TrackSelectionParameters p=exoPlayer.getTrackSelectionParameters().buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT,false).setOverrideForType(o).build();exoPlayer.setTrackSelectionParameters(p);Toast.makeText(this,text,Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Subtitle track failed",Toast.LENGTH_SHORT).show();}}));}}}
        }catch(Exception e){AppLogger.mark("Subtitle panel failed: "+e.getMessage());}
        showPlayerOptionPanel("Subtitles",options);
    }

    void showEpisodePanel(){
        ArrayList<TextView> options=new ArrayList<>();
        options.add(playerOptionButton("Current: "+(activePlayerMovie==null?"Movie":activePlayerMovie.title),v->{}));
        options.add(playerOptionButton("Episode selector will populate for series metadata",v->{}));
        showPlayerOptionPanel("Episodes",options);
    }

    void showPlayerSettingsPanel(){
        ArrayList<TextView> options=new ArrayList<>();
        options.add(playerOptionButton("Playback speed: 0.75x",v->{if(exoPlayer!=null)exoPlayer.setPlaybackSpeed(.75f);}));
        options.add(playerOptionButton("Playback speed: 1.0x",v->{if(exoPlayer!=null)exoPlayer.setPlaybackSpeed(1f);}));
        options.add(playerOptionButton("Playback speed: 1.25x",v->{if(exoPlayer!=null)exoPlayer.setPlaybackSpeed(1.25f);}));
        options.add(playerOptionButton("Restart from beginning",v->{if(exoPlayer!=null){exoPlayer.seekTo(0);exoPlayer.play();}}));
        showPlayerOptionPanel("Player Settings",options);
    }

    void seekBy(long deltaMs){
        if(exoPlayer==null) return;
        long duration=exoPlayer.getDuration();
        long next=Math.max(0, exoPlayer.getCurrentPosition()+deltaMs);
        if(duration>0) next=Math.min(duration, next);
        exoPlayer.seekTo(next);
        updatePlayerProgress();
    }

    void cycleZoomMode(){
        if(activePlayerView==null) return;
        activeZoomMode=(activeZoomMode+1)%3;
        if(activeZoomMode==0){ activePlayerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT); Toast.makeText(this,"Zoom: Fit",Toast.LENGTH_SHORT).show(); }
        else if(activeZoomMode==1){ activePlayerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_ZOOM); Toast.makeText(this,"Zoom: Fill",Toast.LENGTH_SHORT).show(); }
        else { activePlayerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL); Toast.makeText(this,"Zoom: Stretch",Toast.LENGTH_SHORT).show(); }
        AppLogger.mark("Player zoom mode="+activeZoomMode);
    }

    void exitPlayerToDetails(){
        try{ if(playerOverlayHideRunnable!=null)playerOverlayHandler.removeCallbacks(playerOverlayHideRunnable); }catch(Exception ignored){}
        try{ if(playerProgressRunnable!=null)playerProgressHandler.removeCallbacks(playerProgressRunnable); }catch(Exception ignored){}
        try{ if(exoPlayer!=null){exoPlayer.release();exoPlayer=null;} }catch(Exception ignored){}
        Movie m=activePlayerMovie;
        activePlayerOverlay=null;activePlayerPlayPause=null;activePlayerProgress=null;activePlayerTime=null;activePlayerView=null;
        AppLogger.mark("PLAYER_BACK_TO_DETAILS");
        if(m!=null) showMovieDetails(m); else showHome();
    }

    String fmtTime(long ms){
        if(ms<0) ms=0;
        long total=ms/1000, h=total/3600, min=(total%3600)/60, sec=total%60;
        if(h>0) return String.format(java.util.Locale.US,"%d:%02d:%02d",h,min,sec);
        return String.format(java.util.Locale.US,"%d:%02d",min,sec);
    }

    void updatePlayerProgress(){
        if(exoPlayer==null || activePlayerProgress==null || activePlayerTime==null) return;
        long pos=exoPlayer.getCurrentPosition(); long dur=exoPlayer.getDuration();
        if(dur>0){ activePlayerProgress.setProgress((int)Math.max(0,Math.min(1000,(pos*1000)/dur))); activePlayerTime.setText(fmtTime(pos)+" / "+fmtTime(dur)); }
        else { activePlayerProgress.setProgress(0); activePlayerTime.setText(fmtTime(pos)+" / --:--"); }
    }

    void startPlayerProgressUpdates(){
        if(playerProgressRunnable!=null) playerProgressHandler.removeCallbacks(playerProgressRunnable);
        playerProgressRunnable=()->{ updatePlayerProgress(); if(activePlayerOverlay!=null && exoPlayer!=null) playerProgressHandler.postDelayed(playerProgressRunnable,500); };
        playerProgressHandler.post(playerProgressRunnable);
    }

    void togglePlayerPlayPause(){
        if(exoPlayer==null) return;
        if(exoPlayer.isPlaying()){ exoPlayer.pause(); if(activePlayerPlayPause!=null) activePlayerPlayPause.setText("Play"); }
        else { exoPlayer.play(); if(activePlayerPlayPause!=null) activePlayerPlayPause.setText("Pause"); }
    }

    void showPlayerOverlay(FrameLayout overlay){
        if(overlay==null) return;
        overlay.animate().cancel();
        overlay.setVisibility(View.VISIBLE);
        overlay.setAlpha(1f);
        overlay.setFocusable(true);
        overlay.setFocusableInTouchMode(true);
    }
    void hidePlayerOverlay(FrameLayout overlay){
        if(overlay==null) return;
        overlay.animate().cancel();
        overlay.animate().alpha(0f).setDuration(220).start();
    }
    void schedulePlayerOverlayHide(FrameLayout overlay){
        if(overlay==null) return;
        if(playerOverlayHideRunnable!=null) playerOverlayHandler.removeCallbacks(playerOverlayHideRunnable);
        playerOverlayHideRunnable=()->{
            if(overlay==activePlayerOverlay && exoPlayer!=null && exoPlayer.isPlaying()){
                hidePlayerOverlay(overlay);
                AppLogger.mark("Player overlay auto-hidden");
            }
        };
        playerOverlayHandler.postDelayed(playerOverlayHideRunnable,5000);
    }

    void playChannel(Channel c){showVideo(c.name,c.url,"LIVE TV PLAYER • single PlayerManager owner");}
    void showVideo(String title,String url,String overlay){clear();backdrop();VideoView vv=new VideoView(this);vv.setFocusable(false);root.addView(vv,new FrameLayout.LayoutParams(-1,-1));TextView top=tv(title+"\n"+overlay,24,Typeface.BOLD);top.setGravity(Gravity.LEFT|Gravity.TOP);top.setPadding(dp(32),dp(28),0,0);top.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{Color.argb(190,0,0,0),Color.TRANSPARENT}));root.addView(top,new FrameLayout.LayoutParams(-1,dp(160)));TextView back=btn("Back");back.setOnClickListener(v->showHome());FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(160),dp(55),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);bp.bottomMargin=dp(45);root.addView(back,bp);try{vv.setVideoURI(android.net.Uri.parse(url));vv.setOnPreparedListener(mp->{mp.setLooping(true);vv.start();});}catch(Exception e){}back.requestFocus();}

    void showLiveTv(){suppressRowAutoFocus=false;clear();nav.go(NavigationController.Screen.LIVE_TV);backdrop();addMenu();TextView title=tv("Live TV Guide",34,Typeface.BOLD);title.setGravity(Gravity.LEFT);FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(dp(430),dp(60));tp.leftMargin=dp(52);tp.topMargin=dp(112);root.addView(title,tp);LinearLayout guide=new LinearLayout(this);guide.setOrientation(LinearLayout.VERTICAL);guide.setBackground(bg(Color.argb(145,5,8,16),20));FrameLayout.LayoutParams gp=new FrameLayout.LayoutParams(dp(1120),dp(500));gp.leftMargin=dp(55);gp.topMargin=dp(185);root.addView(guide,gp);TextView th=tv("CHANNEL        NOW              2:30 PM              3:00 PM              3:30 PM",16,Typeface.BOLD);guide.addView(th,new LinearLayout.LayoutParams(-1,dp(50)));for(int i=0;i<8;i++){Channel ch=channels.get(i%channels.size());TextView r=btn("  "+(101+i)+"  "+ch.name+"        Playing Now              Up Next              Later");r.setGravity(Gravity.CENTER_VERTICAL);final Channel fc=ch;r.setOnClickListener(v->playChannel(fc));guide.addView(r,new LinearLayout.LayoutParams(-1,dp(56)));}guide.getChildAt(1).requestFocus();}

    LinearLayout form(String title){
        ScrollView sv=new ScrollView(this);sv.setFillViewport(false);sv.setFocusable(false);sv.setFocusableInTouchMode(false);sv.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);sv.setSmoothScrollingEnabled(true);sv.setClipToPadding(false);sv.setPadding(0,0,0,dp(120));editorScroll=sv;
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(dp(72),dp(100),dp(72),dp(110));
        sv.addView(p,new ScrollView.LayoutParams(-1,-2));root.addView(sv,new FrameLayout.LayoutParams(-1,-1));
        TextView h=tv(title,34,Typeface.BOLD);h.setGravity(Gravity.LEFT);p.addView(h,new LinearLayout.LayoutParams(-1,dp(70)));return p;
    }
    LinearLayout overlayForm(String title){
        View dim=new View(this);dim.setBackgroundColor(Color.argb(132,0,0,0));root.addView(dim,new FrameLayout.LayoutParams(-1,-1));
        ScrollView sv=new ScrollView(this);
        editorScroll=sv;
        sv.setFillViewport(false);
        sv.setFocusable(false);
        sv.setFocusableInTouchMode(false);
        sv.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        sv.setSmoothScrollingEnabled(true);
        sv.setClipToPadding(false);
        sv.setPadding(0,0,0,dp(80));
        sv.setBackground(bg(Color.argb(232,9,13,22),28));
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(dp(28),dp(24),dp(28),dp(140));sv.addView(p,new ScrollView.LayoutParams(-1,-2));
        FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(dp(870),-1,Gravity.RIGHT|Gravity.TOP);sp.setMargins(0,dp(78),dp(22),dp(30));root.addView(sv,sp);
        TextView h=tv(title,30,Typeface.BOLD);h.setGravity(Gravity.LEFT);p.addView(h,new LinearLayout.LayoutParams(-1,dp(62)));return p;
    }
    void settingButton(LinearLayout p,String text,View.OnClickListener l){
        TextView b=tv(text,17,Typeface.BOLD);applyFont(b,ui==null?0:ui.contentFontIndex(),Typeface.BOLD);
        b.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);b.setSingleLine(true);b.setFocusable(true);b.setFocusableInTouchMode(true);b.setPadding(dp(28),0,dp(28),0);b.setTextColor(Color.WHITE);
        b.setBackground(stroke(Color.argb(88,18,27,42),Color.argb(46,255,255,255)));b.setOnClickListener(l);
        b.setOnFocusChangeListener((v,has)->{b.setBackground(has?stroke(Color.argb(205,20,72,120),Color.argb(230,73,160,255)):stroke(Color.argb(88,18,27,42),Color.argb(46,255,255,255)));b.animate().scaleX(has?1.012f:1f).scaleY(has?1.012f:1f).setDuration(110).start();if(has)ensureEditorVisible(v);});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(68));lp.setMargins(0,dp(6),0,dp(10));p.addView(b,lp);
    }
    void ensureEditorVisible(View v){ if(editorScroll==null||v==null)return; editorScroll.postDelayed(()->{try{Rect r=new Rect();v.getDrawingRect(r);editorScroll.offsetDescendantRectToMyCoords(v,r);int pad=dp(90);int top=r.top-pad;int bottom=r.bottom+pad;int sy=editorScroll.getScrollY();int sh=editorScroll.getHeight();if(top<sy)editorScroll.smoothScrollTo(0,Math.max(0,top));else if(bottom>sy+sh)editorScroll.smoothScrollTo(0,bottom-sh);}catch(Exception ignored){}},40); }
    String maskKey(String key){ if(key==null||key.trim().isEmpty())return "Not set"; String k=key.trim(); return k.length()<=6?"••••••":k.substring(0,3)+"••••"+k.substring(k.length()-3); }
    void cycleResolverMode(){ String m=backend.playbackResolverMode(); backend.savePlaybackResolverMode(m.equals("direct")?"auto":m.equals("auto")?"realdebrid":m.equals("realdebrid")?"torbox":"direct"); }
    void showSettings(){suppressRowAutoFocus=false;clear();nav.go(NavigationController.Screen.SETTINGS);backdrop();addMenu();LinearLayout p=form("Settings");settingButton(p,"Pro Layout Editor",v->showLayoutEditor());settingButton(p,"Stremio Addon JSON Manager",v->editTextScreen("Stremio addon JSON links",stremio.getJsonLinks(),s->stremio.saveJsonLinks(s)));settingButton(p,"Playback Resolver Mode: "+backend.playbackResolverMode(),v->{cycleResolverMode();showSettings();});settingButton(p,"Real-Debrid API Key: "+maskKey(backend.realDebridApiKey()),v->editTextScreen("Real-Debrid API Key",backend.realDebridApiKey(),s->backend.saveRealDebridApiKey(s)));settingButton(p,"Torbox API Key: "+maskKey(backend.torboxApiKey()),v->editTextScreen("Torbox API Key",backend.torboxApiKey(),s->backend.saveTorboxApiKey(s)));settingButton(p,"Backend Base URL: "+backend.baseUrl(),v->editTextScreen("Backend Base URL",backend.baseUrl(),s->{backend.saveBaseUrl(s);loadBackendHomeRows();}));settingButton(p,"Live TV M3U / Channels DVR URL",v->editTextScreen("Live TV M3U URL",backend.m3uUrl(),s->{backend.saveM3uUrl(s);loadM3u(s);}));settingButton(p,"Refresh Backend Catalog Rows",v->{loadBackendHomeRows();Toast.makeText(this,"Refreshing backend rows",Toast.LENGTH_SHORT).show();});settingButton(p,"4K UI: "+(ui.ui4k()?"Enabled":"Disabled"),v->{ui.save4k(!ui.ui4k());showSettings();});settingButton(p,"Build: DC_V0_2_1_PRO_EDITOR_LIVE_PREVIEW",v->Toast.makeText(this,BuildMarkers.LOG_MARKER,Toast.LENGTH_SHORT).show());if(p.getChildCount()>1)p.getChildAt(1).requestFocus();}
    interface SaveText{void save(String s);} void editTextScreen(String title,String current,SaveText save){clear();backdrop();addMenu();LinearLayout p=form(title);EditText e=new EditText(this);e.setText(current);e.setSingleLine(false);e.setMinLines(3);e.setTextColor(Color.WHITE);e.setHintTextColor(Color.GRAY);e.setTextSize(18);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);e.setBackground(stroke(Color.argb(120,20,25,35),Color.argb(100,255,255,255)));p.addView(e,new LinearLayout.LayoutParams(-1,dp(160)));TextView done=btn("Save");done.setOnClickListener(v->{save.save(e.getText().toString());showSettings();});p.addView(done,new LinearLayout.LayoutParams(dp(180),dp(60)));e.requestFocus();}

    void editorHeader(LinearLayout p,String text){TextView h=tv(text.toUpperCase(Locale.US),13,Typeface.BOLD);h.setTextColor(Color.argb(210,150,205,255));h.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);h.setPadding(dp(8),dp(10),0,0);p.addView(h,new LinearLayout.LayoutParams(-1,dp(42)));}

    void showLayoutEditor(){
        suppressRowAutoFocus=true;
        showHome();
        nav.go(NavigationController.Screen.LAYOUT_EDITOR);
        LinearLayout p=overlayForm("Pro Layout Editor • Live Preview");
        settingButton(p,"✅ Live preview is ON — changes apply behind this panel",v->Toast.makeText(this,"Use arrows/OK. View Home closes editor.",Toast.LENGTH_SHORT).show());
        settingButton(p,"Save layout",v->{ui.saveLayoutSnapshot();Toast.makeText(this,"Layout saved",Toast.LENGTH_SHORT).show();});
        settingButton(p,"Reset all layout settings",v->{ui.resetLayoutDefaults();Toast.makeText(this,"Layout reset",Toast.LENGTH_SHORT).show();showLayoutEditor();});
        settingButton(p,"Reset card size only",v->{ui.resetCardSizeDefaults();Toast.makeText(this,"Card size reset",Toast.LENGTH_SHORT).show();showLayoutEditor();});
        settingButton(p,"View Home",v->{ui.saveLayoutSnapshot();suppressRowAutoFocus=false;showHome();});

        editorHeader(p,"Menu + Navigation");
        settingButton(p,"Menu position: "+ui.menuPosition(),v->{cycleMenuPosition();showLayoutEditor();});
        settingButton(p,"Search / Settings icons: "+ui.iconPlacement(),v->{cycleIconPlacement();showLayoutEditor();});
        settingButton(p,"Menu style: "+menuCompositionName(ui.menuCompositionMode()),v->{ui.saveValue("menuCompositionMode",(ui.menuCompositionMode()+1)%3);showLayoutEditor();});
        settingButton(p,"Search icon placement: "+placementName(ui.searchItemPlacement()),v->{ui.saveValue("searchItemPlacement",(ui.searchItemPlacement()+1)%4);showLayoutEditor();});
        settingButton(p,"Settings icon placement: "+placementName(ui.settingsItemPlacement()),v->{ui.saveValue("settingsItemPlacement",(ui.settingsItemPlacement()+1)%4);showLayoutEditor();});
        addSlider(p,"Top menu left / right","topMenuOffsetDp",-220,220,ui.topMenuOffsetDp());

        editorHeader(p,"Rows + Cards");
        settingButton(p,"Row title text: "+(ui.rowTitles()?"Shown":"Hidden"),v->{boolean next=!ui.rowTitles();ui.saveRowTitles(next);ui.saveValue("rowTitleVisibility",next?1:0);showLayoutEditor();});
        settingButton(p,"Row title icons: "+onOff(ui.rowTitleIconsEnabled()),v->{ui.saveValue("rowTitleIconsEnabled",ui.rowTitleIconsEnabled()==1?0:1);showLayoutEditor();});
        addSlider(p,"Preview cards","previewCardCount",1,8,ui.previewCardCount());
        addSlider(p,"Row vertical position","rowTopDp",300,620,ui.rowTopDp());
        addSlider(p,"Row left / right","rowLeftDp",0,120,ui.rowLeftDp());
        addSlider(p,"Card width","cardWidthDp",190,420,ui.cardWidthDp());
        addSlider(p,"Card height","cardHeightDp",110,260,ui.cardHeightDp());
        addSlider(p,"Card spacing","cardSpacingDp",0,40,ui.cardSpacingDp());
        addSlider(p,"Rounded corners","cornerRadiusDp",8,44,ui.cornerRadiusDp());
        addSlider(p,"Dim unfocused cards","dimUnfocusedPercent",0,70,ui.dimUnfocusedPercent());

        editorHeader(p,"Focus Effects");
        settingButton(p,"Effect profile: "+effectProfileName(ui.effectProfileIndex()),v->{ui.saveValue("effectProfileIndex",(ui.effectProfileIndex()+1)%5);showLayoutEditor();});
        addSlider(p,"Focused card scale","focusedScalePercent",100,120,ui.focusedScalePercent());
        addSlider(p,"Glow strength","glowStrengthPercent",0,100,ui.glowStrengthPercent());
        addSlider(p,"Pulse effect","pulseStrengthPercent",0,100,ui.pulseStrengthPercent());
        addSlider(p,"Focus ring on/off","focusRingEnabled",0,1,ui.focusRingEnabled());
        addSlider(p,"Focus ring thickness","focusRingThicknessDp",0,8,ui.focusRingThicknessDp());
        addSlider(p,"Focus ring color","focusRingColorIndex",0,5,ui.focusRingColorIndex());
        addSlider(p,"3D tilt effect","cardTiltPercent",0,100,ui.cardTiltPercent());
        addSlider(p,"Card lift","cardLiftDp",0,24,ui.cardLiftDp());
        addSlider(p,"Focus bounce","focusBouncePercent",0,100,ui.focusBouncePercent());
        settingButton(p,"Glass card mode: "+onOff(ui.glassCardMode()),v->{ui.saveValue("glassCardMode",ui.glassCardMode()==1?0:1);showLayoutEditor();});
        settingButton(p,"Hover info overlay: "+onOff(ui.hoverInfoOverlay()),v->{ui.saveValue("hoverInfoOverlay",ui.hoverInfoOverlay()==1?0:1);showLayoutEditor();});

        editorHeader(p,"Hero Text + Fonts");
        settingButton(p,"Top menu font: "+fontName(ui.topMenuFontIndex()),v->{ui.saveValue("topMenuFontIndex",(ui.topMenuFontIndex()+1)%12);showLayoutEditor();});
        settingButton(p,"Hero font: "+fontName(ui.heroFontIndex()),v->{ui.saveValue("heroFontIndex",(ui.heroFontIndex()+1)%12);showLayoutEditor();});
        settingButton(p,"Content/card font: "+fontName(ui.contentFontIndex()),v->{ui.saveValue("contentFontIndex",(ui.contentFontIndex()+1)%12);showLayoutEditor();});
        addSlider(p,"Hero text left / right","heroTextLeftDp",-80,220,ui.heroTextLeftDp());
        addSlider(p,"Hero text up / down","heroTextTopDp",-80,180,ui.heroTextTopDp());
        addSlider(p,"Background dim on focus","backgroundDimOnFocusPercent",0,45,ui.backgroundDimOnFocusPercent());
        addSlider(p,"Bottom safe space","bottomSafeDp",24,160,ui.bottomSafeDp());
        settingButton(p,"4K UI: "+(ui.ui4k()?"Enabled":"Disabled"),v->{ui.save4k(!ui.ui4k());showLayoutEditor();});

        editorHeader(p,"Extra Artwork Slot");
        settingButton(p,"Extra artwork slot: "+onOff(ui.extraArtworkEnabled()),v->{ui.saveValue("extraArtworkEnabled",ui.extraArtworkEnabled()==1?0:1);showLayoutEditor();});
        settingButton(p,"Extra artwork type: "+extraArtworkName(ui.extraArtworkType()),v->{ui.saveValue("extraArtworkType",(ui.extraArtworkType()+1)%8);showLayoutEditor();});
        addSlider(p,"Extra artwork X","extraArtworkXdp",0,1200,ui.extraArtworkXdp());
        addSlider(p,"Extra artwork Y","extraArtworkYdp",0,620,ui.extraArtworkYdp());
        addSlider(p,"Extra artwork width","extraArtworkWidthDp",80,620,ui.extraArtworkWidthDp());
        addSlider(p,"Extra artwork height","extraArtworkHeightDp",60,420,ui.extraArtworkHeightDp());
        addSlider(p,"Extra artwork opacity","extraArtworkOpacityPercent",0,100,ui.extraArtworkOpacityPercent());
        addSlider(p,"Extra artwork depth / 3D pop","extraArtworkDepthPercent",0,100,ui.extraArtworkDepthPercent());
        settingButton(p,"Reset extra artwork slot",v->{ui.saveValue("extraArtworkEnabled",1);ui.saveValue("extraArtworkType",1);ui.saveValue("extraArtworkXdp",760);ui.saveValue("extraArtworkYdp",120);ui.saveValue("extraArtworkWidthDp",240);ui.saveValue("extraArtworkHeightDp",160);ui.saveValue("extraArtworkOpacityPercent",95);showLayoutEditor();});
        if(p.getChildCount()>1)p.getChildAt(1).requestFocus();
    }
    void cycleMenuPosition(){String m=ui.menuPosition();ui.saveMenuPosition(m.equals("left")?"center":m.equals("center")?"right":"left");}
    void cycleIconPlacement(){String m=ui.iconPlacement();ui.saveIconPlacement(m.equals("right")?"inline":m.equals("inline")?"left":m.equals("left")?"hidden":"right");}
    void addSlider(LinearLayout parent,String label,String key,int min,int max,int current){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setFocusable(true);
        box.setFocusableInTouchMode(true);
        box.setPadding(dp(16),dp(6),dp(16),dp(8));
        box.setBackground(stroke(Color.argb(54,20,25,35),Color.argb(45,255,255,255)));
        TextView title=tv(label+": "+current,15,Typeface.BOLD);
        title.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        TextView hint=tv("◀ / ▶ adjust    OK save preview",11,Typeface.NORMAL);
        hint.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        hint.setTextColor(Color.argb(185,255,255,255));
        ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        bar.setMax(max-min);
        bar.setProgress(Math.max(0,Math.min(max-min,current-min)));
        box.addView(title,new LinearLayout.LayoutParams(-1,dp(30)));
        box.addView(bar,new LinearLayout.LayoutParams(-1,dp(22)));
        box.addView(hint,new LinearLayout.LayoutParams(-1,dp(24)));
        final int[] val=new int[]{Math.max(min,Math.min(max,current))};
        Runnable apply=()->{ title.setText(label+": "+val[0]); bar.setProgress(val[0]-min); ui.saveValue(key,val[0]); };
        box.setOnFocusChangeListener((v,has)->{ box.animate().scaleX(has?1.018f:1f).scaleY(has?1.018f:1f).setDuration(100).start(); box.setBackground(has?stroke(Color.argb(120,18,72,126),Color.argb(210,64,160,255)):stroke(Color.argb(54,20,25,35),Color.argb(45,255,255,255))); if(has)ensureEditorVisible(box); });
        box.setOnKeyListener((v,k,e)->{ if(e.getAction()!=KeyEvent.ACTION_DOWN)return false; int step=(max-min)>500?25:(max-min)>120?10:1; if(k==KeyEvent.KEYCODE_DPAD_LEFT){val[0]=Math.max(min,val[0]-step);apply.run();return true;} if(k==KeyEvent.KEYCODE_DPAD_RIGHT){val[0]=Math.min(max,val[0]+step);apply.run();return true;} if(k==KeyEvent.KEYCODE_DPAD_CENTER||k==KeyEvent.KEYCODE_ENTER){ui.saveLayoutSnapshot();Toast.makeText(this,label+" saved",Toast.LENGTH_SHORT).show();return true;} return false; });
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(94));lp.setMargins(0,dp(5),0,dp(10));parent.addView(box,lp);
    }

    void showSearch(){suppressRowAutoFocus=false;clear();backdrop();addMenu();LinearLayout p=form("Search");EditText e=new EditText(this);e.setHint("Search movies, shows, channels");e.setTextColor(Color.WHITE);e.setHintTextColor(Color.GRAY);e.setTextSize(22);e.setSingleLine(true);e.setBackground(stroke(Color.argb(110,20,25,35),Color.argb(100,255,255,255)));p.addView(e,new LinearLayout.LayoutParams(-1,dp(70)));e.requestFocus();}
    void loadM3u(String url){new Thread(()->{try{ArrayList<Channel> out=new ArrayList<>();BufferedReader br=new BufferedReader(new InputStreamReader(new URL(url).openStream()));String line,name="Channel",group="Other",logo="";while((line=br.readLine())!=null){if(line.startsWith("#EXTINF")){int ix=line.lastIndexOf(',');name=ix>=0?line.substring(ix+1).trim():"Channel";group=grab(line,"group-title=\"");logo=grab(line,"tvg-logo=\"");}else if(line.startsWith("http")){out.add(new Channel(name,group,line.trim(),logo));}}if(!out.isEmpty())runOnUiThread(()->{channels.clear();channels.addAll(out);Toast.makeText(this,"Loaded "+out.size()+" channels",Toast.LENGTH_LONG).show();});}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"M3U load failed: "+e.getMessage(),Toast.LENGTH_LONG).show());}}).start();}
    String grab(String line,String key){int s=line.indexOf(key);if(s<0)return "";s+=key.length();int e=line.indexOf('"',s);return e>s?line.substring(s,e):"";}

    void loadBackendHomeRowsLegacy(){new Thread(()->{try{String txt=httpGet(joinUrl(backend.baseUrl(),"/api/home"));JSONObject rootObj=new JSONObject(txt);JSONArray rails=rootObj.optJSONArray("rails");if(rails==null||rails.length()==0)return;ArrayList<HomeRow> loaded=new ArrayList<>();ArrayList<Movie> flat=new ArrayList<>();for(int r=0;r<rails.length();r++){JSONObject ro=rails.optJSONObject(r);if(ro==null)continue;HomeRow row=new HomeRow(ro.optString("title",ro.optString("name","Catalog")));row.id=ro.optString("slug",ro.optString("id",""));JSONArray items=ro.optJSONArray("items");if(items==null)continue;for(int i=0;i<items.length();i++){JSONObject it=items.optJSONObject(i);if(it==null)continue;Movie m=new Movie(it.optString("title",it.optString("name","Untitled")),metaFrom(it,ro),"");m.id=it.optString("id",it.optString("externalId",it.optString("imdbId","")));m.type=it.optString("type",it.optString("streamLookupType","movie"));m.poster=abs(it.optString("poster",it.optString("posterUrl","")));m.background=abs(it.optString("background",it.optString("backdrop",it.optString("backdropUrl",m.poster))));m.logo=abs(it.optString("logo",it.optString("clearlogo",it.optString("logoUrl",""))));m.banner=abs(it.optString("banner",it.optString("thumb",m.logo)));m.overview=it.optString("overview",it.optString("description",""));m.year=it.optString("year","");row.items.add(m);flat.add(m);}if(!row.items.isEmpty())loaded.add(row);}if(!loaded.isEmpty())runOnUiThread(()->{homeRows.clear();homeRows.addAll(loaded);movies.clear();movies.addAll(flat);showHome();Toast.makeText(this,"Loaded backend artwork rows: "+flat.size(),Toast.LENGTH_SHORT).show();});}catch(Exception e){AppLogger.mark("Backend home load failed: "+e.getMessage());}}).start();}
    void loadBackendHomeRows(){new Thread(()->{try{if(!loadBackendHomeRowsFresh()){try{httpPost(joinUrl(backend.baseUrl(),"/api/refresh"),"{}");}catch(Exception re){AppLogger.mark("Backend refresh failed: "+re.getMessage());}loadBackendHomeRowsFresh();}}catch(Exception e){AppLogger.mark("Backend artwork load failed: "+e.getMessage());runOnUiThread(()->Toast.makeText(this,"Backend artwork load failed: "+e.getMessage(),Toast.LENGTH_LONG).show());}}).start();}
    boolean loadBackendHomeRowsFresh()throws Exception{String txt=httpGet(joinUrl(backend.baseUrl(),"/api/home"));JSONObject rootObj=new JSONObject(txt);JSONArray rails=rootObj.optJSONArray("rails");if(rails==null||rails.length()==0)return false;ArrayList<HomeRow> loaded=new ArrayList<>();ArrayList<Movie> flat=new ArrayList<>();for(int r=0;r<rails.length();r++){JSONObject ro=rails.optJSONObject(r);if(ro==null)continue;HomeRow row=new HomeRow(ro.optString("title",ro.optString("name","Catalog")));row.id=ro.optString("slug",ro.optString("id",""));JSONArray items=ro.optJSONArray("items");if(items==null)continue;for(int i=0;i<items.length();i++){JSONObject it=items.optJSONObject(i);if(it==null)continue;Movie m=new Movie(it.optString("title",it.optString("name","Untitled")),metaFrom(it,ro),"");m.id=it.optString("id",it.optString("externalId",it.optString("imdbId",it.optString("imdb_id",""))));m.type=it.optString("type",it.optString("streamLookupType","movie"));m.poster=artUrl(it,"poster","posterUrl","poster_url","thumbnail","thumb","image");m.background=artUrl(it,"background","backdrop","backdropUrl","backgroundUrl","fanart","fanartUrl");if(m.background.isEmpty())m.background=m.poster;m.logo=artUrl(it,"logo","clearlogo","clearLogo","clear_logo","clearlogoUrl","logoUrl");m.banner=artUrl(it,"banner","landscape","landscapeUrl","landscape_url","card","cardUrl","card_url","horizontal","horizontalUrl");m.overview=it.optString("overview",it.optString("description",it.optString("summary","")));m.year=it.optString("year","");m.tag=it.optString("tag",it.optString("label",ro.optString("title","FEATURED")));m.imdbRating=ratingFrom(it,"imdbRating","imdb_rating","imdbScore","imdb","imdb_vote_average");m.tmdbRating=ratingFrom(it,"tmdbRating","tmdb_rating","tmdbScore","tmdb","vote_average");row.items.add(m);flat.add(m);}if(!row.items.isEmpty())loaded.add(row);}if(loaded.isEmpty())return false;runOnUiThread(()->{homeRows.clear();homeRows.addAll(loaded);movies.clear();movies.addAll(flat);showHome();Toast.makeText(this,"Loaded backend artwork rows: "+flat.size(),Toast.LENGTH_SHORT).show();});return true;}
    String ratingFrom(JSONObject it,String...keys){for(String k:keys){String v=it.optString(k,"");if(v!=null&&!v.trim().isEmpty()&&!v.equals("0")&&!v.equals("0.0"))return normalizeRating(v);}JSONObject ratings=it.optJSONObject("ratings");if(ratings!=null){for(String k:keys){String v=ratings.optString(k,"");if(v!=null&&!v.trim().isEmpty()&&!v.equals("0")&&!v.equals("0.0"))return normalizeRating(v);}}return "";}
    String normalizeRating(String v){try{String cleaned=v.replaceAll("[^0-9.]","");double d=Double.parseDouble(cleaned);if(d>10)d=d/10.0;return String.format(Locale.US,"%.1f",d);}catch(Exception e){return v.replaceAll("[^0-9.]","");}}
    String artUrl(JSONObject it,String... keys){for(String k:keys){String v=it.optString(k,"");if(v!=null&&!v.trim().isEmpty())return abs(v);}JSONObject art=it.optJSONObject("artwork");if(art!=null){for(String k:keys){String v=art.optString(k,"");if(v!=null&&!v.trim().isEmpty())return abs(v);}}JSONObject images=it.optJSONObject("images");if(images!=null){for(String k:keys){String v=images.optString(k,"");if(v!=null&&!v.trim().isEmpty())return abs(v);}}return "";}
    String httpPost(String u,String body)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(45000);c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Accept","application/json");try(OutputStream os=c.getOutputStream()){os.write(body.getBytes("UTF-8"));}try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);return out.toString("UTF-8");}}

    String metaFrom(JSONObject it,JSONObject ro){String y=it.optString("year","");String source=it.optString("source",ro.optString("source","Stremio Catalog"));return (y.isEmpty()?source:(y+" • "+source));}
    String joinUrl(String base,String path){if(base==null||base.trim().isEmpty())base="http://192.168.100.55:8181";base=base.trim();while(base.endsWith("/"))base=base.substring(0,base.length()-1);return base+path;}
    String abs(String u){if(u==null)return "";u=u.trim();if(u.isEmpty())return "";if(u.startsWith("http://")||u.startsWith("https://"))return u;if(u.startsWith("/"))return joinUrl(backend.baseUrl(),u);return u;}
    String httpGet(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);c.setRequestProperty("Accept","application/json");try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);return out.toString("UTF-8");}}
    void loadImage(String url,ImageView target,boolean cinematic){
        url=abs(url);
        if(target==null)return;
        if(url.isEmpty()){target.setImageDrawable(null);return;}
        final String fu=url;
        target.setTag(fu);
        Bitmap cached=imageCache.get(fu);
        if(cached!=null){target.setImageBitmap(cached);target.setAlpha(1f);return;}
        if(failedArtworkUrls.contains(fu))return;
        imageExecutor.execute(()->{
            try{
                HttpURLConnection c=(HttpURLConnection)new URL(fu).openConnection();
                c.setConnectTimeout(3500);
                c.setReadTimeout(6500);
                c.setRequestProperty("User-Agent","DebridChannelsAndroidTV/0.1.9");
                c.setInstanceFollowRedirects(true);
                int code=c.getResponseCode();
                if(code<200||code>=300){failedArtworkUrls.add(fu);AppLogger.mark("Artwork HTTP "+code+" url="+fu);return;}
                BitmapFactory.Options opts=new BitmapFactory.Options();
                opts.inPreferredConfig=Bitmap.Config.RGB_565;
                Bitmap bm=BitmapFactory.decodeStream(c.getInputStream(),null,opts);
                if(bm!=null){
                    imageCache.put(fu,bm);
                    runOnUiThread(()->{
                        if(!fu.equals(String.valueOf(target.getTag())))return;
                        if(cinematic){
                            target.animate().alpha(.18f).setDuration(90).withEndAction(()->{
                                target.setImageBitmap(bm);
                                target.animate().alpha(1f).setDuration(360).start();
                            }).start();
                        } else {
                            target.setImageBitmap(bm);
                            target.setAlpha(1f);
                        }
                    });
                } else failedArtworkUrls.add(fu);
            }catch(Exception e){failedArtworkUrls.add(fu);AppLogger.mark("Artwork load failed: "+e.getClass().getSimpleName()+": "+e.getMessage()+" url="+fu);}
        });
    }


}
