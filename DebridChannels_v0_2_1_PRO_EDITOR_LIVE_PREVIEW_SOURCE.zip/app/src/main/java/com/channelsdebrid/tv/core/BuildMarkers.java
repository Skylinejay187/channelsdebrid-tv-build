package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.2.1 PRO EDITOR LIVE PREVIEW";
    public static final String LOG_MARKER = "DC_V0_2_1_PRO_EDITOR_LIVE_PREVIEW_ACTIVE";
    private BuildMarkers() {}
}
