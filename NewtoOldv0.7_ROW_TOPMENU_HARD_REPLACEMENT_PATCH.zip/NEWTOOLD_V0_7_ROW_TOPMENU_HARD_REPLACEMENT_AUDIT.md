# NewtoOldv0.7 - Row + Top Menu Hard Replacement Audit

Base: NewtoOldv0.6_LIVE_TV_LOGIC_PORT_IPTV_XMLTV_FIX
Donor/reference: DebridChannels_v0_9_8_3_CI_JSON_EXCEPTION_FIX_CLEAN_SOURCE

## Purpose
The previous row/menu passes were bridge/stub style and did not actually replace the renderer paths. This pass bypasses the old MainActivity row card creation/bind path and the old XML top navigation child structure.

## Row system replacement
- `MainActivity.RowAdapter` now creates `makeNewToOldCardHolder(...)` only.
- `MainActivity.RowAdapter` now binds through `bindNewToOldCard(...)` only.
- Old `makeCleanCardHolder(...)` / `bindCleanCard(...)` references are removed from the active adapter path.
- New cards are scratch-built landscape cards with:
  - backdrop-first artwork
  - bottom gradient metadata layer
  - title/meta overlay
  - centered logo layer
  - row text toggle applied inside the actual card bind path
  - 3D artwork focus effect preserved through existing settings

## Top menu replacement
- Runtime menu now clears `topNav` XML children and re-adds the existing bound menu views into a new scratch-built glass navigation bar.
- Existing XML/static top menu layout is bypassed after startup.
- Search is visible in the rebuilt menu.
- Existing DPAD/click callbacks remain wired to the same bound views so navigation does not break.

## Preserved
- Live TV UI/layout untouched.
- Live TV player untouched.
- Live TV source logic from v0.6 preserved.
- Backend/artwork loading preserved.
- Media-info trailers preserved.
- Hero trailers remain disabled from previous removal pass.

## Verification log markers
- `DC_BUILD_MARKER: NewtoOldv0.7_ROW_TOPMENU_HARD_REPLACEMENT`
- `ROW_SYSTEM: SCRATCH_BUILT_V07_ACTIVE_OLD_ROW_CODE_BYPASSED`
- `TOP_MENU: SCRATCH_BUILT_V07_ACTIVE_OLD_MENU_CODE_BYPASSED`
- `NEWTOOLD_ROW_SYSTEM_V07_ACTIVE`
- `NEWTOOLD_ROW_TEXT_V07_APPLY`
- `NEWTOOLD_TOP_MENU_V07_ACTIVE`
- `TOP_MENU_OLD_CODE_DELETED`
