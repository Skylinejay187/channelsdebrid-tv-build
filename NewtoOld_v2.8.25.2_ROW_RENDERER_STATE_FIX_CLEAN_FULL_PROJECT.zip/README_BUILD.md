NewtoOld_v2.8.23.2_FINAL_PLAYBACK_HARDENING

versionCode: 282150
versionName: NewtoOld_v2.8.25.0_PRO_EDITOR_FULL_WIRING_AUDIT_EXTRA_ART_TOGGLE

Final playback hardening build with adaptive buffering, safe watchdog, silent rebuffer, decoder/source reliability memory, audio-route debounce, and session stability mode.

Verify logcat marker:
DC_BUILD_MARKER: NewtoOld_v2.8.24.2_VLC_ARM_DUAL_ABI_INSTALL_FIX
