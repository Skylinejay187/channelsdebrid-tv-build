
package com.channelsdebrid.tv

import android.animation.Animator
import android.animation.AnimatorSet
import android.content.Intent
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.graphics.Outline
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.KeyEvent
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.RequestBuilder
import com.bumptech.glide.RequestManager
import com.channelsdebrid.tv.databinding.ActivityMainBinding
import com.channelsdebrid.tv.settings.SettingsRepository
import com.channelsdebrid.tv.data.TmdbLiveLoader
import com.channelsdebrid.tv.data.StremioLiveLoader
import com.channelsdebrid.tv.data.SourceProbe
import com.channelsdebrid.tv.data.BackendHomeLoader
import com.channelsdebrid.tv.BuildConfig
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors
import java.util.concurrent.ConcurrentHashMap
import android.widget.Toast
import com.channelsdebrid.tv.playback.PlayerActivity
import com.channelsdebrid.tv.playback.PlaybackResolver
import com.channelsdebrid.tv.LiveTvActivity

class MainActivity : AppCompatActivity() {

    private companion object {
        private const val BACKEND_BASE_URL = "http://192.168.100.55:8181"
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var settingsRepository: SettingsRepository
    private val tmdbLiveLoader = TmdbLiveLoader()
    private val stremioLiveLoader = StremioLiveLoader()
    private val sourceProbe = SourceProbe()
    private val backendHomeLoader = BackendHomeLoader()
    private val playbackResolver = PlaybackResolver()
    private val liveExecutor = Executors.newSingleThreadExecutor()
    private val heroLogoExecutor = Executors.newSingleThreadExecutor()
    private val inFlightHeroBackdropRequests = java.util.Collections.newSetFromMap(java.util.concurrent.ConcurrentHashMap<String, Boolean>())
    private val inFlightHeroLogoRequests = java.util.Collections.newSetFromMap(java.util.concurrent.ConcurrentHashMap<String, Boolean>())
    private var tmdbRequestVersion = 0
    private var stremioRequestVersion = 0
    private var backendRequestVersion = 0
    private var startupFocusLocked = true
    @Volatile private var pendingHeroLogoRequestKey: String? = null
    private val resolvedHeroLogoCache = ConcurrentHashMap<String, String>()
    private val resolvedHeroBackdropCache = ConcurrentHashMap<String, String>()
    private val loadedCardArtworkRequests = ConcurrentHashMap<Int, String>()
    private val loadedCardLogoRequests = ConcurrentHashMap<Int, String>()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var pendingHeroCommitRunnable: Runnable? = null
    private var committedHeroRequestKey: String? = null
    private var pendingRevealRunnable: Runnable? = null
    private var pendingRowSettleRunnable: Runnable? = null
    private var pendingNavigationIdleRunnable: Runnable? = null
    private var pendingBottomHudHideRunnable: Runnable? = null
    private var bottomHudDismissedForSession = false
    private var lastFocusedCardId: Int = View.NO_ID
    private var lastTopMenuFocusId: Int = View.NO_ID
    private var activeRowSection: RowSection? = null
    private var rowSettleInProgress = false
    private var navigationInFlight = false
    private var motionIdleDeadlineMs: Long = 0L
    private var pendingLiveRowsRunnable: Runnable? = null
    private var pendingLiveStremioRunnable: Runnable? = null
    private var liveRowsAppliedOnce = false
    private var initialWindowFocusHandled = false
    private var lastDirectionalKeyCode: Int = KeyEvent.KEYCODE_UNKNOWN
    private var lastDirectionalKeyAtMs: Long = 0L

    private enum class RowSection {
        FIRST,
        SECOND,
        THIRD,
        FOURTH,
        FIFTH,
        SIXTH,
        SEVENTH
    }

    private data class RowSlot(
        val section: RowSection,
        val titleView: TextView,
        val subtitleView: TextView,
        val container: ViewGroup,
        val recyclerView: RecyclerView
    )

    private inner class RowAdapter(
        private val rowSlot: RowSlot,
        private val items: List<TitleCard>
    ) : RecyclerView.Adapter<RowAdapter.CardHolder>() {

        inner class CardHolder(val cardView: View) : RecyclerView.ViewHolder(cardView)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardHolder {
            val card = makeCard(items[viewType], rowSlot.recyclerView, binding.contentScroll, viewType, 286, 160)
            return CardHolder(card)
        }

        override fun onBindViewHolder(holder: CardHolder, position: Int) {
            // card is position-specific by construction
        }

        override fun getItemCount(): Int = items.size

        override fun getItemViewType(position: Int): Int = position
    }

    private data class HomeRowSpec(
        val title: String,
        val subtitle: String,
        val section: RowSection,
        val items: List<TitleCard>
    )

    data class TitleCard(
        val title: String,
        val meta: String,
        val desc: String,
        val badge: String,
        val brand: String,
        val footer: String,
        val progress: Float,
        val backgroundRes: Int,
        val posterUrl: String? = null,
        val backdropUrl: String? = null,
        val logoUrl: String? = null,
        val mediaType: String? = null,
        val tmdbId: Int = 0,
        val sourceKey: String? = null,
        val externalId: String? = null
    )

    private val heroTitles = listOf(
        TitleCard("SHŌGUN", "S1 E7: A Stick of Time  •  43 min left", "A premium lean-back presentation for your media center, with live TV, trending shows, smart recommendations, and instant playback.", "⚑  Instant Playback Ready", "FX", "43 min left", 0.58f, R.drawable.bg_shogun),
        TitleCard("THE BATMAN", "2h 56m  •  IMAX", "A darker detective spotlight with premium backdrop changes and clean TV-safe row alignment.", "⚑  Direct Play Ready", "PLEX", "IMAX", 0.42f, R.drawable.bg_batman),
        TitleCard("FALLOUT", "49 min left  •  Prime", "Post-apocalyptic action with large-format hero art and poster rows that stay locked in place.", "⚑  Synced to Library", "prime", "49 min left", 0.51f, R.drawable.bg_fallout),
        TitleCard("DUNE", "2h 35m  •  Max", "Expansive cinema-style focus treatment with large typography and backdrop-driven navigation.", "⚑  HDR Available", "max", "Featured", 0.46f, R.drawable.bg_dune),
        TitleCard("HALO", "Series  •  Prime", "Sci-fi recommendations rendered in the same composition language as your reference shot.", "⚑  Resume Synced", "prime", "Series", 0.33f, R.drawable.bg_halo),
        TitleCard("WONKA", "Movie  •  Max", "Bright contrast title art for spotlight and recently-added rows without breaking the layout grid.", "⚑  Trailer Ready", "max", "Movie", 0.37f, R.drawable.bg_wonka),
        TitleCard("MAYOR OF KINGSTOWN", "Series  •  Paramount+", "Grounded drama hero state with full-screen poster changes as focus moves across rows.", "⚑  Watched on Device", "P+", "Series", 0.28f, R.drawable.bg_mayor),
        TitleCard("CIVIL WAR", "Movie  •  109 min", "Poster rows line up under the hero so the screen still feels premium and intentional.", "⚑  Cache Eligible", "A24", "109 min", 0.22f, R.drawable.bg_civilwar),
        TitleCard("AVATAR", "Movie  •  Disney+", "High-contrast blockbuster art for the lower row examples and future trailer pop-up placement.", "⚑  Dolby Vision", "D+", "Featured", 0.48f, R.drawable.bg_avatar)
    )

    private fun rowSlots(): List<RowSlot> = listOf(
        RowSlot(RowSection.FIRST, binding.rowOneTitle, binding.rowOneSubtitle, binding.rowOneScroll, binding.rowOne),
        RowSlot(RowSection.SECOND, binding.rowTwoTitle, binding.rowTwoSubtitle, binding.rowTwoScroll, binding.rowTwo),
        RowSlot(RowSection.THIRD, binding.rowThreeTitle, binding.rowThreeSubtitle, binding.rowThreeScroll, binding.rowThree),
        RowSlot(RowSection.FOURTH, binding.rowFourTitle, binding.rowFourSubtitle, binding.rowFourScroll, binding.rowFour),
        RowSlot(RowSection.FIFTH, binding.rowFiveTitle, binding.rowFiveSubtitle, binding.rowFiveScroll, binding.rowFive),
        RowSlot(RowSection.SIXTH, binding.rowSixTitle, binding.rowSixSubtitle, binding.rowSixScroll, binding.rowSix),
        RowSlot(RowSection.SEVENTH, binding.rowSevenTitle, binding.rowSevenSubtitle, binding.rowSevenScroll, binding.rowSeven)
    )

    private fun rowFirstCard(rowSlot: RowSlot?): View? = rowSlot?.recyclerView?.layoutManager?.findViewByPosition(0)

    private fun firstVisibleRowSlot(): RowSlot? = rowSlots().firstOrNull { it.container.visibility == View.VISIBLE && (it.recyclerView.adapter?.itemCount ?: 0) > 0 }

    private fun lastVisibleRowSlot(): RowSlot? = rowSlots().lastOrNull { it.container.visibility == View.VISIBLE && (it.recyclerView.adapter?.itemCount ?: 0) > 0 }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        settingsRepository = SettingsRepository(this)
        heroTitles.forEach { preloadArtworkBundle(it) }
        binding.contentScroll.clipToPadding = false
        binding.contentScroll.clipChildren = false
        rowSlots().forEach {
            it.container.clipToPadding = false
            it.container.clipChildren = false
            it.recyclerView.clipToPadding = false
            it.recyclerView.clipChildren = false
            it.recyclerView.itemAnimator = null
            it.recyclerView.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
            it.recyclerView.setHasFixedSize(true)
            it.recyclerView.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        }

        commitHero(heroTitles[3])
        applySettingsToHome()
        lockRowsForStartup()
        wireTopControls()
        wireRowNavigation()
        showBottomHudTemporarily()
        binding.contentScroll.post {
            binding.contentScroll.scrollTo(0, 0)
            binding.contentScroll.postDelayed({
                unlockRowsAfterStartup()
                binding.contentScroll.scrollTo(0, 0)
                requestInitialRowFocus()
            }, 90)
            binding.contentScroll.postDelayed({
                binding.contentScroll.scrollTo(0, 0)
                requestInitialRowFocus()
            }, 220)
            binding.contentScroll.postDelayed({
                binding.contentScroll.scrollTo(0, 0)
                requestInitialRowFocus()
            }, 520)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        pendingHeroCommitRunnable?.let(mainHandler::removeCallbacks)
        pendingRevealRunnable?.let(mainHandler::removeCallbacks)
        pendingRowSettleRunnable?.let(mainHandler::removeCallbacks)
        pendingNavigationIdleRunnable?.let(mainHandler::removeCallbacks)
        pendingBottomHudHideRunnable?.let(mainHandler::removeCallbacks)
        pendingLiveRowsRunnable?.let(mainHandler::removeCallbacks)
        pendingLiveStremioRunnable?.let(mainHandler::removeCallbacks)
        liveExecutor.shutdownNow()
        heroLogoExecutor.shutdownNow()
    }

    override fun onResume() {
        super.onResume()
        applySettingsToHome()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || initialWindowFocusHandled) return
        initialWindowFocusHandled = true
        binding.contentScroll.post {
            unlockRowsAfterStartup()
            binding.contentScroll.scrollTo(0, 0)
            requestInitialRowFocus()
        }
        binding.contentScroll.postDelayed({
            if (!isFinishing && !isDestroyed) {
                binding.contentScroll.scrollTo(0, 0)
                requestInitialRowFocus()
            }
        }, 180L)
    }

    private fun applySettingsToHome() {
        val catalogs = settingsRepository.loadCatalogs()
        val tmdb = settingsRepository.loadTmdb()
        val stremioAddons = settingsRepository.loadStremioAddons()
        val debrid = settingsRepository.loadDebrid()
        val dvr = settingsRepository.loadChannelsDvr()
        val xtream = settingsRepository.loadXtream()
        val trailers = settingsRepository.loadTrailers()
        val playback = settingsRepository.loadPlayback()
        val storage = settingsRepository.loadStorage()
        val sourceSummary = buildInitialSourceSummary(stremioAddons.count { it.enabled }, dvr, xtream, debrid)

        val sectionOrder = RowSection.values().toList()
        val rowSpecs = mutableListOf<HomeRowSpec>()
        fun addRow(title: String, subtitle: String, itemOffset: Int) {
            if (rowSpecs.size >= sectionOrder.size) return
            rowSpecs += HomeRowSpec(
                title = title,
                subtitle = subtitle,
                section = sectionOrder[rowSpecs.size],
                items = List(24) { index -> heroTitles[(index + itemOffset) % heroTitles.size] }
            )
        }

        if (catalogs.trendingMoviesEnabled) addRow("Popular Movies", "Backend catalog • cached artwork", 3)
        if (catalogs.popularMoviesEnabled) addRow("Popular Shows", "Backend catalog • cached artwork", 5)
        if (catalogs.trendingShowsEnabled) addRow("Featured Movies", "Backend catalog • cached artwork", 6)
        if (catalogs.popularShowsEnabled) addRow("Featured Series", "Backend catalog • cached artwork", 1)
        if (catalogs.platformRowsEnabled) addRow("Streaming Catalogs", "Backend merged sources", 2)
        addRow("Catalog Picks", "Backend • primary artwork source", 7)
        if (catalogs.stremioCatalogRowsEnabled) {
            stremioAddons.take(2).forEachIndexed { index, addon ->
                val addonName = addon.name.ifBlank { if (index == 0) "Cinemeta" else "Stremio" }
                addRow(
                    "$addonName Catalog",
                    if (addon.enabled) "Manifest ready • custom rows" else "Manifest configured • currently disabled",
                    4 + index
                )
            }
        }
        while (rowSpecs.size < sectionOrder.size) {
            addRow("Featured Picks ${rowSpecs.size + 1}", "Fallback catalog • browse ready", rowSpecs.size + 2)
        }

        rowSlots().forEachIndexed { index, slot ->
            bindRowSpec(rowSpecs.getOrNull(index), slot.titleView, slot.subtitleView, slot.container, slot.recyclerView)
        }

        binding.infoChip.text = buildInfoChipText(trailers.enabled, playback.autoPlayBestStream, storage.movieCacheEnabled, sourceSummary)
        binding.statusBadge.text = buildStatusBadgeText(debrid.realDebridEnabled, debrid.torBoxEnabled, playback.timeshiftEnabled)
        binding.heroMeta.text = "Backend catalog • ${if (trailers.enabled) "Trailers On" else "Trailers Off"}"
        binding.weatherPill.text = buildWeatherPill(playback.frameRateMatching)
        wireRowNavigation()
        binding.contentScroll.post {
            snapToRow(RowSection.FIRST, smooth = false)
        }
        scheduleLiveCatalogRefresh(catalogs, tmdb, stremioAddons)
        scheduleBackendHomeRefresh()
    }

    private fun scheduleBackendHomeRefresh() {
        if (BACKEND_BASE_URL.isBlank()) return
        val requestVersion = ++backendRequestVersion
        liveExecutor.execute {
            val rows = runCatching { backendHomeLoader.loadRows(BACKEND_BASE_URL) }.getOrDefault(emptyList())
            if (rows.isEmpty()) return@execute
            runOnUiThread {
                if (isFinishing || isDestroyed || requestVersion != backendRequestVersion) return@runOnUiThread
                applyBackendRows(rows)
            }
        }
    }

    private fun applyBackendRows(rows: List<BackendHomeLoader.BackendRow>) {
        val slots = rowSlots()
        if (rows.isEmpty()) return
        liveRowsAppliedOnce = true
        slots.forEachIndexed { index, slot ->
            val row = rows.getOrNull(index)
            if (row == null) {
                bindLiveRow(null, slot.section, slot.titleView, slot.subtitleView, slot.container, slot.recyclerView)
            } else {
                titleFromBackendRow(row, slot)
            }
        }
        val firstItem = rows.firstOrNull()?.items?.firstOrNull()
        if (firstItem != null) {
            val card = mapBackendItemToTitleCard(firstItem, 0)
            commitHero(card)
            binding.heroMeta.text = "Backend catalog • ${rows.size} row${if (rows.size == 1) "" else "s"} loaded"
        }
        binding.infoChip.text = buildInfoChipText(
            trailersEnabled = settingsRepository.loadTrailers().enabled,
            autoBest = settingsRepository.loadPlayback().autoPlayBestStream,
            movieCacheEnabled = settingsRepository.loadStorage().movieCacheEnabled,
            sourceSummary = "Backend Ready  •  $BACKEND_BASE_URL"
        )
        wireRowNavigation()
        binding.contentScroll.post {
            unlockRowsAfterStartup()
            requestInitialRowFocus()
        }
    }

    private fun titleFromBackendRow(row: BackendHomeLoader.BackendRow, slot: RowSlot) {
        slot.titleView.visibility = View.VISIBLE
        slot.subtitleView.visibility = View.VISIBLE
        slot.container.visibility = View.VISIBLE
        slot.titleView.text = row.title
        slot.subtitleView.text = "Backend catalog • ${row.items.size} items"
        val mapped = row.items.mapIndexed { index, item -> mapBackendItemToTitleCard(item, index) }
        slot.recyclerView.adapter = RowAdapter(slot, mapped)
        slot.recyclerView.scrollToPosition(0)
    }

    private fun mapBackendItemToTitleCard(item: BackendHomeLoader.BackendItem, index: Int): TitleCard {
        val meta = buildString {
            if (item.year > 0) append(item.year)
            if (item.genre.isNotBlank()) {
                if (isNotEmpty()) append("  •  ")
                append(item.genre)
            }
        }.ifBlank { item.type.replaceFirstChar { it.uppercase() } }
        return TitleCard(
            title = item.title,
            meta = meta,
            desc = item.overview.ifBlank { "Backend catalog item" },
            badge = "⚑  Backend Ready",
            brand = item.source.ifBlank { "Backend" },
            footer = if (item.genre.isNotBlank()) item.genre else item.type.replaceFirstChar { it.uppercase() },
            progress = (0.18f + (index % 5) * 0.12f).coerceAtMost(0.86f),
            backgroundRes = heroTitles[index % heroTitles.size].backgroundRes,
            posterUrl = item.poster,
            backdropUrl = item.backdrop ?: item.poster,
            logoUrl = null,
            mediaType = item.type,
            tmdbId = 0,
            sourceKey = "backend",
            externalId = item.id
        )
    }



    private fun bindRowSpec(
        spec: HomeRowSpec?,
        titleView: TextView,
        subtitleView: TextView,
        container: ViewGroup,
        recyclerView: RecyclerView
    ) {
        if (spec == null) {
            titleView.visibility = View.GONE
            subtitleView.visibility = View.GONE
            container.visibility = View.GONE
            recyclerView.adapter = null
            return
        }
        titleView.visibility = View.VISIBLE
        subtitleView.visibility = View.VISIBLE
        container.visibility = View.VISIBLE
        titleView.text = spec.title
        subtitleView.text = spec.subtitle
        val slot = rowSlots().first { it.recyclerView.id == recyclerView.id }
        recyclerView.adapter = RowAdapter(slot, spec.items)
        recyclerView.scrollToPosition(0)
    }

    private fun buildInfoChipText(
        trailersEnabled: Boolean,
        autoBest: Boolean,
        movieCacheEnabled: Boolean,
        sourceSummary: String? = null
    ): String {
        val parts = mutableListOf<String>()
        parts += if (trailersEnabled) "Trailers On" else "Trailers Off"
        parts += if (autoBest) "Auto Best Stream" else "Manual Source Select"
        parts += if (movieCacheEnabled) "Movie Cache Ready" else "Cache Limited"
        sourceSummary?.takeIf { it.isNotBlank() }?.let { parts += it }
        return parts.joinToString("  •  ")
    }

    private fun buildStatusBadgeText(
        rdEnabled: Boolean,
        torBoxEnabled: Boolean,
        timeshiftEnabled: Boolean
    ): String {
        return when {
            rdEnabled -> "⚑  Real-Debrid Ready"
            torBoxEnabled -> "⚑  TorBox Ready"
            timeshiftEnabled -> "⚑  Timeshift Ready"
            else -> "⚑  Instant Playback Ready"
        }
    }

    private fun buildWeatherPill(frameRateMatchingEnabled: Boolean): String {
        return if (frameRateMatchingEnabled) {
            "1:33  •  Frame Match On"
        } else {
            "1:33  •  Frame Match Off"
        }
    }

    private fun buildInitialSourceSummary(
        enabledAddonCount: Int,
        dvr: com.channelsdebrid.tv.settings.ChannelsDvrSettings,
        xtream: com.channelsdebrid.tv.settings.XtreamSettings,
        debrid: com.channelsdebrid.tv.settings.DebridSettings
    ): String {
        val parts = mutableListOf<String>()
        if (enabledAddonCount > 0) {
            parts += if (enabledAddonCount == 1) "1 Catalog Source" else "$enabledAddonCount Catalog Sources"
        }
        if (debrid.realDebridEnabled) parts += "Real-Debrid Armed"
        if (debrid.torBoxEnabled) parts += "TorBox Armed"
        if (dvr.autoDetect || dvr.baseUrl.isNotBlank()) parts += "Channels DVR Ready"
        if (xtream.enabled) parts += "Xtream Ready"
        return parts.take(2).joinToString("  •  ")
    }



    private fun scheduleLiveCatalogRefresh(
        catalogs: com.channelsdebrid.tv.settings.CatalogSettings,
        tmdb: com.channelsdebrid.tv.settings.TmdbSettings,
        stremioAddons: List<com.channelsdebrid.tv.settings.StremioAddonSettings>
    ) {
        pendingLiveRowsRunnable?.let(mainHandler::removeCallbacks)
        pendingLiveStremioRunnable?.let(mainHandler::removeCallbacks)
        if (BACKEND_BASE_URL.isNotBlank()) return
        pendingLiveStremioRunnable = Runnable {
            maybeLoadLiveStremioRows(catalogs, stremioAddons)
        }.also { mainHandler.postDelayed(it, if (liveRowsAppliedOnce) 180L else 320L) }
        pendingLiveRowsRunnable = Runnable {
            maybeLoadLiveTmdbRows(catalogs, tmdb)
        }.also { mainHandler.postDelayed(it, if (liveRowsAppliedOnce) 1200L else 2200L) }
    }

    private fun maybeLoadLiveTmdbRows(catalogs: com.channelsdebrid.tv.settings.CatalogSettings, tmdb: com.channelsdebrid.tv.settings.TmdbSettings) {
        if (liveRowsAppliedOnce || tmdb.apiKey.isBlank()) return

        val enabledKeys = mutableListOf<String>().apply {
            if (catalogs.trendingMoviesEnabled) add("trending_movies")
            if (catalogs.popularMoviesEnabled) add("popular_movies")
            if (catalogs.trendingShowsEnabled) add("trending_shows")
            if (catalogs.popularShowsEnabled) add("popular_shows")
            if (catalogs.platformRowsEnabled) add("platform_rows")
            add("top_rated_movies")
        }.take(6)

        if (enabledKeys.isEmpty()) return
        val requestVersion = ++tmdbRequestVersion

        liveExecutor.execute {
            val rows = runCatching {
                tmdbLiveLoader.loadRows(
                    apiKey = tmdb.apiKey,
                    region = tmdb.region.ifBlank { "US" },
                    language = tmdb.language.ifBlank { "en-US" },
                    enabledKeys = enabledKeys,
                    fanartApiKey = BuildConfig.FANART_API_KEY,
                    fanartClientKey = BuildConfig.FANART_CLIENT_KEY,
                    limit = 12
                )
            }.getOrDefault(emptyList())

            if (rows.isEmpty()) return@execute
            runOnUiThread {
                if (isFinishing || requestVersion != tmdbRequestVersion) return@runOnUiThread
                applyLiveRows(rows)
            }
        }
    }

    private fun applyLiveRows(rows: List<TmdbLiveLoader.LiveRow>) {
        val slots = rowSlots()
        if (rows.isEmpty()) return
        liveRowsAppliedOnce = true

        val firstChunk = rows.take(2)
        slots.forEachIndexed { index, slot ->
            bindLiveRow(firstChunk.getOrNull(index), slot.section, slot.titleView, slot.subtitleView, slot.container, slot.recyclerView)
        }
        prefetchHeroAssets(firstChunk.flatMap { it.items }.take(4).mapIndexed { index, item -> mapLiveItemToTitleCard(item, index) })
        wireRowNavigation()

        if (lastFocusedCardId == View.NO_ID) {
            firstChunk.firstOrNull()?.items?.firstOrNull()?.let { commitHero(mapLiveItemToTitleCard(it, 0)) }
        }
        if (startupFocusLocked || currentFocus == null || isTopMenuView(currentFocus)) {
            binding.contentScroll.post {
                unlockRowsAfterStartup()
                requestInitialRowFocus()
            }
            binding.contentScroll.postDelayed({
                if (!isFinishing && !isDestroyed) requestInitialRowFocus()
            }, 140L)
        }

        val remaining = rows.drop(2)
        if (remaining.isEmpty()) {
            binding.contentScroll.post { snapToRow(RowSection.FIRST, smooth = false) }
            return
        }

        mainHandler.postDelayed({
            if (isFinishing || isDestroyed) return@postDelayed
            slots.forEachIndexed { index, slot ->
                bindLiveRow(rows.getOrNull(index), slot.section, slot.titleView, slot.subtitleView, slot.container, slot.recyclerView)
            }
            prefetchHeroAssets(rows.flatMap { it.items }.take(6).mapIndexed { index, item -> mapLiveItemToTitleCard(item, index) })
            wireRowNavigation()
        }, 180L)
    }

    private fun bindLiveRow(
        row: TmdbLiveLoader.LiveRow?,
        section: RowSection,
        titleView: TextView,
        subtitleView: TextView,
        container: ViewGroup,
        recyclerView: RecyclerView
    ) {
        if (row == null) {
            titleView.visibility = View.GONE
            subtitleView.visibility = View.GONE
            container.visibility = View.GONE
            recyclerView.adapter = null
            return
        }
        titleView.visibility = View.VISIBLE
        subtitleView.visibility = View.VISIBLE
        container.visibility = View.VISIBLE
        titleView.text = row.title
        subtitleView.text = row.subtitle
        val mappedItems = row.items.mapIndexed { index, item -> mapLiveItemToTitleCard(item, index) }
        val slot = rowSlots().first { it.section == section }
        recyclerView.adapter = RowAdapter(slot, mappedItems)
        recyclerView.scrollToPosition(0)
        prefetchHeroAssets(mappedItems.take(2))
        prefetchCardArtwork(mappedItems)
    }

    private fun mapLiveItemToTitleCard(item: TmdbLiveLoader.LiveCatalogItem, index: Int): TitleCard {
        val fallback = heroTitles[index % heroTitles.size]
        return TitleCard(
            title = item.title,
            meta = item.meta,
            desc = item.desc,
            badge = item.badge,
            brand = item.brand,
            footer = item.footer,
            progress = item.progress.coerceIn(0.12f, 0.94f),
            backgroundRes = fallback.backgroundRes,
            posterUrl = item.posterUrl,
            backdropUrl = item.backdropUrl,
            logoUrl = item.logoUrl,
            mediaType = item.mediaType,
            tmdbId = item.tmdbId,
            sourceKey = "tmdb",
            externalId = item.externalId
        )
    }
    private fun maybeLoadLiveStremioRows(
        catalogs: com.channelsdebrid.tv.settings.CatalogSettings,
        stremioAddons: List<com.channelsdebrid.tv.settings.StremioAddonSettings>
    ) {
        if (!catalogs.stremioCatalogRowsEnabled) return
        val enabledAddons = stremioAddons.filter { it.enabled && it.manifestUrl.isNotBlank() }
        if (enabledAddons.isEmpty()) return
        val requestVersion = ++stremioRequestVersion
        liveExecutor.execute {
            val rowLimit = rowSlots().size
            val rows = buildList {
                enabledAddons.forEach { addon ->
                    val loaded = runCatching {
                        stremioLiveLoader.loadRows(addon.name.ifBlank { "Stremio" }, addon.manifestUrl, 12)
                    }.getOrDefault(emptyList())
                    addAll(loaded)
                    if (size >= rowLimit) return@forEach
                }
            }.take(rowLimit)
            if (rows.isEmpty()) return@execute
            runOnUiThread {
                if (isFinishing || requestVersion != stremioRequestVersion) return@runOnUiThread
                applyStremioRows(rows)
            }
        }
    }

    private fun applyStremioRows(rows: List<com.channelsdebrid.tv.data.StremioLiveLoader.LiveRow>) {
        val slots = rowSlots()
        if (rows.isEmpty()) return
        liveRowsAppliedOnce = true

        val firstChunk = rows.take(2)
        slots.forEachIndexed { index, slot ->
            bindStremioRowInto(slot.titleView, slot.subtitleView, slot.container, slot.recyclerView, firstChunk.getOrNull(index))
        }
        prefetchHeroAssets(firstChunk.flatMap { it.items }.take(4).mapIndexed { index, item -> mapStremioItemToTitleCard(item, index) })
        wireRowNavigation()

        if (lastFocusedCardId == View.NO_ID) {
            firstChunk.firstOrNull()?.items?.firstOrNull()?.let { commitHero(mapStremioItemToTitleCard(it, 0)) }
        }
        if (startupFocusLocked || currentFocus == null || isTopMenuView(currentFocus)) {
            binding.contentScroll.post {
                unlockRowsAfterStartup()
                requestInitialRowFocus()
            }
            binding.contentScroll.postDelayed({
                if (!isFinishing && !isDestroyed) requestInitialRowFocus()
            }, 140L)
        }

        val remaining = rows.drop(2)
        if (remaining.isEmpty()) {
            binding.contentScroll.post { snapToRow(RowSection.FIRST, smooth = false) }
            return
        }

        mainHandler.postDelayed({
            if (isFinishing || isDestroyed) return@postDelayed
            slots.forEachIndexed { index, slot ->
                bindStremioRowInto(slot.titleView, slot.subtitleView, slot.container, slot.recyclerView, rows.getOrNull(index))
            }
            prefetchHeroAssets(rows.flatMap { it.items }.take(6).mapIndexed { index, item -> mapStremioItemToTitleCard(item, index) })
            wireRowNavigation()
        }, 180L)
    }

    private fun bindStremioRowInto(
        titleView: TextView,
        subtitleView: TextView,
        container: ViewGroup,
        recyclerView: RecyclerView,
        row: com.channelsdebrid.tv.data.StremioLiveLoader.LiveRow?
    ) {
        if (row == null) {
            titleView.visibility = View.GONE
            subtitleView.visibility = View.GONE
            container.visibility = View.GONE
            recyclerView.adapter = null
            return
        }
        titleView.visibility = View.VISIBLE
        subtitleView.visibility = View.VISIBLE
        container.visibility = View.VISIBLE
        titleView.text = row.title
        subtitleView.text = row.subtitle
        val mappedItems = row.items.mapIndexed { index, item -> mapStremioItemToTitleCard(item, index) }
        val slot = rowSlots().first { it.recyclerView.id == recyclerView.id }
        recyclerView.adapter = RowAdapter(slot, mappedItems)
        recyclerView.scrollToPosition(0)
        prefetchCardArtwork(mappedItems)
    }

    private fun mapStremioItemToTitleCard(item: com.channelsdebrid.tv.data.StremioLiveLoader.LiveCatalogItem, index: Int): TitleCard {
        val fallback = heroTitles[index % heroTitles.size]
        return TitleCard(
            title = item.title,
            meta = item.meta,
            desc = item.desc,
            badge = item.badge,
            brand = item.brand,
            footer = item.footer,
            progress = item.progress.coerceIn(0.12f, 0.92f),
            backgroundRes = fallback.backgroundRes,
            posterUrl = item.posterUrl,
            backdropUrl = item.backdropUrl,
            logoUrl = item.logoUrl,
            mediaType = null,
            tmdbId = 0,
            sourceKey = "stremio",
            externalId = item.externalId
        )
    }

    private fun probeSourceStatuses(
        stremio: com.channelsdebrid.tv.settings.StremioAddonSettings,
        dvr: com.channelsdebrid.tv.settings.ChannelsDvrSettings,
        xtream: com.channelsdebrid.tv.settings.XtreamSettings,
        debrid: com.channelsdebrid.tv.settings.DebridSettings,
        trailers: com.channelsdebrid.tv.settings.TrailerSettings,
        playback: com.channelsdebrid.tv.settings.PlaybackSettings,
        storage: com.channelsdebrid.tv.settings.StorageSettings
    ) {
        liveExecutor.execute {
            val parts = mutableListOf<String>()
            settingsRepository.loadStremioAddons()
                .filter { it.enabled && it.manifestUrl.isNotBlank() }
                .take(3)
                .forEach { addon ->
                    sourceProbe.probeStremio(addon.manifestUrl)?.let { parts += it }
                }
            sourceProbe.probeChannelsDvr(dvr.autoDetect, dvr.baseUrl)?.let { parts += it }
            if (xtream.enabled) {
                sourceProbe.probeXtream(xtream.server, xtream.username, xtream.password, xtream.m3uUrl)?.let { parts += it }
            }
            val summary = parts.take(2).joinToString("  •  ")
            if (summary.isBlank()) return@execute
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                binding.infoChip.text = buildInfoChipText(trailers.enabled, playback.autoPlayBestStream, storage.movieCacheEnabled, summary)
                if (!debrid.realDebridEnabled && !debrid.torBoxEnabled) {
                    binding.statusBadge.text = "⚑  $summary"
                }
            }
        }
    }

    private fun lockRowsForStartup() {
        startupFocusLocked = true
        rowSlots().forEach { blockRowFocus(it.recyclerView) }
    }

    private fun unlockRowsAfterStartup() {
        startupFocusLocked = false
        rowSlots().forEach { allowRowFocus(it.recyclerView) }
    }

    private fun blockRowFocus(row: RecyclerView) {
        row.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        row.isFocusable = false
        row.isFocusableInTouchMode = false
        for (i in 0 until row.childCount) {
            row.getChildAt(i).apply {
                isFocusable = false
                isFocusableInTouchMode = false
            }
        }
    }

    private fun allowRowFocus(row: RecyclerView) {
        row.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        row.isFocusable = true
        row.isFocusableInTouchMode = true
        for (i in 0 until row.childCount) {
            row.getChildAt(i).apply {
                isFocusable = true
                isFocusableInTouchMode = true
            }
        }
    }

    private fun markNavigationBusy(durationMs: Long = 170L) {
        navigationInFlight = true
        motionIdleDeadlineMs = android.os.SystemClock.uptimeMillis() + durationMs
        pendingNavigationIdleRunnable?.let(mainHandler::removeCallbacks)
        pendingNavigationIdleRunnable = Runnable {
            if (android.os.SystemClock.uptimeMillis() >= motionIdleDeadlineMs) {
                navigationInFlight = false
            } else {
                pendingNavigationIdleRunnable = this.pendingNavigationIdleRunnable
            }
        }.also { mainHandler.postDelayed(it, durationMs) }
    }

    private fun isMotionBusy(): Boolean {
        val now = android.os.SystemClock.uptimeMillis()
        val verticalBusy = kotlin.math.abs(binding.contentScroll.scrollY - (binding.contentScroll.getTag(R.id.tag_last_stable_scroll_y) as? Int ?: binding.contentScroll.scrollY)) > 2
        if (!verticalBusy) {
            binding.contentScroll.setTag(R.id.tag_last_stable_scroll_y, binding.contentScroll.scrollY)
        }
        return rowSettleInProgress || navigationInFlight || now < motionIdleDeadlineMs || binding.contentScroll.isPressed || verticalBusy
    }

        private fun openLiveTv() {
        startActivity(Intent(this, LiveTvActivity::class.java))
    }

private fun wireTopControls() {
        val focusables = listOf(
            binding.menuButton,
            binding.homeButton,
            binding.navResume,
            binding.navSmart,
            binding.navLive,
            binding.navMovies
        )
        if (lastTopMenuFocusId == View.NO_ID) {
            lastTopMenuFocusId = binding.menuButton.id
        }
        binding.navLive.isClickable = true
        binding.navLive.isFocusable = true
        binding.navLive.setOnClickListener { openLiveTv() }
        binding.navLive.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_UP &&
                (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER)
            ) {
                openLiveTv()
                true
            } else {
                false
            }
        }
        binding.menuButton.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.menuButton.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_UP &&
                (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER)
            ) {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            } else {
                false
            }
        }

        binding.homeButton.setOnClickListener {
            binding.contentScroll.smoothScrollTo(0, 0)
            binding.navSmart.requestFocus()
        }

        focusables.forEach { v ->
            v.setOnFocusChangeListener { view, hasFocus ->
                if (hasFocus) {
                    lastTopMenuFocusId = view.id
                }
                view.animate().cancel()
                view.animate()
                    .scaleX(if (hasFocus) 1.05f else 1f)
                    .scaleY(if (hasFocus) 1.05f else 1f)
                    .alpha(if (hasFocus) 1f else 0.96f)
                    .setDuration(150)
                    .start()
            }
        }
    }


    private fun preferredTopMenuFocusId(): Int {
        val candidateIds = listOf(
            binding.menuButton.id,
            binding.homeButton.id,
            binding.navResume.id,
            binding.navSmart.id,
            binding.navLive.id,
            binding.navMovies.id
        )
        return if (candidateIds.contains(lastTopMenuFocusId)) lastTopMenuFocusId else binding.menuButton.id
    }

    private fun isTopMenuView(view: View?): Boolean {
        val id = view?.id ?: return false
        return id == binding.menuButton.id ||
            id == binding.homeButton.id ||
            id == binding.navResume.id ||
            id == binding.navSmart.id ||
            id == binding.navLive.id ||
            id == binding.navMovies.id
    }

    private fun centerRowOnPosition(recyclerView: RecyclerView, position: Int, requestFocus: Boolean = false) {
        val lm = recyclerView.layoutManager as? LinearLayoutManager ?: return
        recyclerView.post {
            val roughOffset = ((recyclerView.width - recyclerView.paddingLeft - recyclerView.paddingRight) / 2f).toInt()
            lm.scrollToPositionWithOffset(position, roughOffset)
            recyclerView.post {
                val child = lm.findViewByPosition(position)
                if (child != null) {
                    val exactOffset = ((recyclerView.width - recyclerView.paddingLeft - recyclerView.paddingRight - child.width) / 2f).toInt()
                    lm.scrollToPositionWithOffset(position, exactOffset)
                    if (requestFocus) {
                        child.isFocusable = true
                        child.isFocusableInTouchMode = true
                        child.requestFocus()
                    }
                }
            }
        }
    }

    private fun requestInitialRowFocus() {
        val firstRow = firstVisibleRowSlot() ?: return
        binding.contentScroll.scrollTo(0, 0)
        activeRowSection = firstRow.section
        centerRowOnPosition(firstRow.recyclerView, 0, requestFocus = true)
        firstRow.recyclerView.post {
            val firstCard = rowFirstCard(firstRow) ?: return@post
            lastFocusedCardId = firstCard.id
        }
    }

    private fun showBottomHudTemporarily() {
        if (bottomHudDismissedForSession) return
        pendingBottomHudHideRunnable?.let(mainHandler::removeCallbacks)
        binding.weatherPill.animate().cancel()
        binding.weatherPill.alpha = 0f
        binding.weatherPill.visibility = View.GONE
        val hud = binding.infoChip
        if (hud.visibility != View.VISIBLE) {
            hud.alpha = 0f
            hud.visibility = View.VISIBLE
        }
        hud.animate().cancel()
        hud.animate().alpha(1f).setDuration(160L).start()
        pendingBottomHudHideRunnable = Runnable {
            hideBottomHud(permanentForSession = true)
        }.also { mainHandler.postDelayed(it, 8000L) }
    }

    private fun hideBottomHud(permanentForSession: Boolean = false) {
        if (permanentForSession) {
            bottomHudDismissedForSession = true
        }
        listOf(binding.weatherPill, binding.infoChip).forEach { hud ->
            hud.animate().cancel()
            hud.animate()
                .alpha(0f)
                .setDuration(180L)
                .withEndAction {
                    hud.visibility = View.GONE
                }
                .start()
        }
    }

    private fun shouldConsumeDirectionalRepeat(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode !in setOf(
                KeyEvent.KEYCODE_DPAD_LEFT,
                KeyEvent.KEYCODE_DPAD_RIGHT,
                KeyEvent.KEYCODE_DPAD_UP,
                KeyEvent.KEYCODE_DPAD_DOWN
            )
        ) return false
        if (event.action != KeyEvent.ACTION_DOWN) return false
        if (event.repeatCount > 0) return true
        val now = android.os.SystemClock.uptimeMillis()
        val tooSoon = keyCode == lastDirectionalKeyCode && (now - lastDirectionalKeyAtMs) < 110L
        if (tooSoon || rowSettleInProgress || navigationInFlight) return true
        lastDirectionalKeyCode = keyCode
        lastDirectionalKeyAtMs = now
        markNavigationBusy(if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) 110L else 140L)
        return false
    }

    private fun wireRowNavigation() {
        val visibleRows = rowSlots().filter { it.container.visibility == View.VISIBLE && (it.recyclerView.adapter?.itemCount ?: 0) > 0 }
        if (visibleRows.isEmpty()) {
            return
        }

        val firstRowFirstCardId = rowFirstCard(visibleRows.first())?.id ?: View.NO_ID
        binding.homeButton.nextFocusDownId = firstRowFirstCardId
        binding.navResume.nextFocusDownId = firstRowFirstCardId
        binding.navSmart.nextFocusDownId = firstRowFirstCardId
        binding.navLive.nextFocusDownId = firstRowFirstCardId
        binding.navMovies.nextFocusDownId = firstRowFirstCardId

        binding.menuButton.nextFocusRightId = binding.homeButton.id
        binding.homeButton.nextFocusLeftId = binding.menuButton.id
        binding.homeButton.nextFocusRightId = binding.navResume.id
        binding.navResume.nextFocusLeftId = binding.homeButton.id
        binding.navResume.nextFocusRightId = binding.navSmart.id
        binding.navSmart.nextFocusLeftId = binding.navResume.id
        binding.navSmart.nextFocusRightId = binding.navLive.id
        binding.navLive.nextFocusLeftId = binding.navSmart.id
        binding.navLive.nextFocusRightId = binding.navMovies.id
        binding.navMovies.nextFocusLeftId = binding.navLive.id
        binding.navMovies.nextFocusRightId = binding.navMovies.id

        visibleRows.forEachIndexed { rowIndex, current ->
            val prev = visibleRows.getOrNull(rowIndex - 1)
            val next = visibleRows.getOrNull(rowIndex + 1)
            val childCount = current.recyclerView.childCount
            for (childIndex in 0 until childCount) {
                val card = current.recyclerView.getChildAt(childIndex) ?: continue
                card.nextFocusUpId = rowFirstCard(prev)?.id ?: preferredTopMenuFocusId()
                card.nextFocusDownId = rowFirstCard(next)?.id ?: card.id
                card.setOnKeyListener { _, keyCode, event ->
                    if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                    if (shouldConsumeDirectionalRepeat(keyCode, event)) return@setOnKeyListener true
                    when (keyCode) {
                        KeyEvent.KEYCODE_DPAD_UP -> {
                            if (prev != null) {
                                moveFocusToRowStart(prev)
                            } else {
                                moveFocusToTopMenu()
                            }
                            true
                        }
                        KeyEvent.KEYCODE_DPAD_DOWN -> {
                            if (next != null) {
                                moveFocusToRowStart(next)
                                true
                            } else {
                                true
                            }
                        }
                        else -> false
                    }
                }
            }
        }
    }

    private fun moveFocusToTopMenu() {
        val targetId = preferredTopMenuFocusId()
        val targetView = findViewById<View>(targetId) ?: binding.navSmart
        rowSettleInProgress = false
        pendingRowSettleRunnable?.let(mainHandler::removeCallbacks)
        activeRowSection = null
        lastTopMenuFocusId = targetView.id
        markNavigationBusy(120L)
        binding.contentScroll.post {
            binding.contentScroll.scrollTo(0, 0)
            targetView.requestFocus()
        }
    }

    private fun moveFocusToRowStart(targetRow: RowSlot?) {
        if (targetRow == null) return
        rowSettleInProgress = true
        pendingRowSettleRunnable?.let(mainHandler::removeCallbacks)
        activeRowSection = targetRow.section
        snapToRow(targetRow.section, smooth = false)
        markNavigationBusy(180L)
        centerRowOnPosition(targetRow.recyclerView, 0, requestFocus = true)
        targetRow.recyclerView.post {
            val targetCard = rowFirstCard(targetRow) ?: run { rowSettleInProgress = false; return@post }
            lastFocusedCardId = targetCard.id
            pendingRowSettleRunnable?.let(mainHandler::removeCallbacks)
            pendingRowSettleRunnable = Runnable {
                rowSettleInProgress = false
            }.also { mainHandler.postDelayed(it, 140L) }
        }
    }

    private fun populateRows() {
        applySettingsToHome()
    }

    private fun makeCard(item: TitleCard, recyclerView: RecyclerView, verticalScroll: ScrollView, index: Int, widthDp: Int, heightDp: Int): View {
        val density = resources.displayMetrics.density
        val widthPx = (widthDp * density).toInt()
        val heightPx = (heightDp * density).toInt()
        val marginEnd = (16 * density).toInt()
        val pad = (14 * density).toInt()
        val pillRadius = 34f * density

        val frame = FrameLayout(this).apply {
            id = View.generateViewId()
            layoutParams = RecyclerView.LayoutParams(widthPx, heightPx).apply { rightMargin = marginEnd }
            isFocusable = true
            isClickable = true
            foreground = null
            background = (ContextCompat.getDrawable(this@MainActivity, item.backgroundRes)?.mutate() as? GradientDrawable)?.apply {
                cornerRadius = pillRadius
            } ?: ContextCompat.getDrawable(this@MainActivity, item.backgroundRes)
            clipToOutline = true
            clipChildren = false
            clipToPadding = false
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, pillRadius)
                }
            }
        }

        val posterBackdropImage = ImageView(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.94f
            setBackgroundColor(0xFF0B0F18.toInt())
        }
        loadCardBackdropLayerInto(posterBackdropImage, item, highQuality = false)

        val posterImage = ImageView(this).apply {
            layoutParams = FrameLayout.LayoutParams(1, 1, Gravity.CENTER)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            alpha = 1f
            visibility = View.VISIBLE
        }

        val overlay = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            background = (ContextCompat.getDrawable(this@MainActivity, R.drawable.card_overlay)?.mutate() as? GradientDrawable)?.apply {
                cornerRadius = pillRadius
            } ?: ContextCompat.getDrawable(this@MainActivity, R.drawable.card_overlay)
            alpha = 0.40f
        }

        val focusBloom = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            background = makeFocusGlowDrawable(pillRadius)
            alpha = 0f
        }

        val cardLogo = ImageView(this).apply {
            layoutParams = FrameLayout.LayoutParams((widthPx * 0.66f).toInt(), (heightPx * 0.28f).toInt(), Gravity.CENTER)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            alpha = 0f
            visibility = View.GONE
            elevation = 12f * resources.displayMetrics.density
        }
        bindCardLogo(cardLogo, item, highQuality = false)
        val shouldPreferLogoOnCard = preferredHeroLogoUrl(item, null) != null || resolveHeroLogoRes(item.title) != 0 || !item.logoUrl.isNullOrBlank()

        val bottomWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
            setPadding(pad, 0, pad, pad)
            alpha = 0f
            visibility = View.GONE
        }

        val title = TextView(this).apply {
            text = item.title
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 22f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 2
            setShadowLayer(10f * density, 0f, 3f * density, 0xCC000000.toInt())
        }

        val meta = TextView(this).apply {
            text = item.meta
            setTextColor(0xFFF0E6D7.toInt())
            textSize = 12.8f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 1
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = (4 * density).toInt()
            }
        }

        val footer = TextView(this).apply {
            text = item.desc
            setTextColor(0xFFF5EFE6.toInt())
            textSize = 11.6f
            maxLines = 4
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setLineSpacing(0f, 1.08f)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = (6 * density).toInt()
            }
        }

        bottomWrap.addView(title)
        bottomWrap.addView(meta)
        bottomWrap.addView(footer)

        frame.addView(posterBackdropImage)
        frame.addView(focusBloom)
        frame.addView(overlay)
        frame.addView(cardLogo)
        frame.addView(bottomWrap)

        frame.cameraDistance = 12000f
        frame.elevation = 6f * resources.displayMetrics.density
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
            frame.outlineAmbientShadowColor = 0x99FFB84D.toInt()
            frame.outlineSpotShadowColor = 0xCCFFD36E.toInt()
        }

        frame.setOnFocusChangeListener { view, hasFocus ->
            pendingRevealRunnable?.let(mainHandler::removeCallbacks)
            if (hasFocus) markNavigationBusy()
            view.animate().cancel()
            cardLogo.animate().cancel()
            bottomWrap.animate().cancel()
            overlay.animate().cancel()
            focusBloom.animate().cancel()
            val section = rowSlots().firstOrNull { it.recyclerView.id == recyclerView.id }?.section
            val verticalRowChange = hasFocus && section != null && activeRowSection != null && activeRowSection != section
            if (hasFocus && section != null) {
                activeRowSection = section
            }
            view.alpha = if (hasFocus) 1f else 0.992f
            view.translationZ = if (hasFocus) 24f * resources.displayMetrics.density else 0f
            view.scaleX = if (hasFocus) 1.028f else 1f
            view.scaleY = if (hasFocus) 1.028f else 1f
            overlay.animate().alpha(if (hasFocus) 0.14f else 0.30f).setDuration(140L).start()
            bottomWrap.alpha = 0f
            bottomWrap.visibility = View.GONE
            focusBloom.animate().alpha(if (hasFocus) 1f else 0f).setDuration(if (hasFocus) 120L else 160L).start()
            cardLogo.visibility = if (shouldPreferLogoOnCard) View.VISIBLE else View.GONE
            cardLogo.alpha = if (shouldPreferLogoOnCard) 1f else 0f
            title.alpha = 0f
            frame.foreground = null
            glowAnimator(view, focusBloom, hasFocus)
            posterBackdropImage.setLayerType(if (hasFocus) View.LAYER_TYPE_HARDWARE else View.LAYER_TYPE_NONE, null)
            posterImage.setLayerType(if (hasFocus) View.LAYER_TYPE_HARDWARE else View.LAYER_TYPE_NONE, null)
            cardLogo.setLayerType(if (hasFocus) View.LAYER_TYPE_HARDWARE else View.LAYER_TYPE_NONE, null)
            if (hasFocus) {
                lastFocusedCardId = view.id
                if (section != null && section == lastVisibleRowSlot()?.section) {
                    // bottom-right settings button removed; keep focus within content
                }
                previewHeroForFocus(item)
                scheduleHeroCommit(item, if (startupFocusLocked) 150L else if (verticalRowChange) 210L else 110L)
                if (!startupFocusLocked) {
                    pendingRevealRunnable = Runnable {
                        if (view.isFocused && lastFocusedCardId == view.id) {
                            revealFocusedCard(recyclerView, verticalScroll, view, index, verticalRowChange)
                        }
                    }.also { mainHandler.postDelayed(it, if (verticalRowChange) 190L else 130L) }
                }
            }
        }
        frame.setOnClickListener {
            launchPlaybackFor(item)
        }
        return frame
    }



    private fun launchPlaybackFor(item: TitleCard) {
        val dvr = settingsRepository.loadChannelsDvr()
        val xtream = settingsRepository.loadXtream()
        val addons = settingsRepository.loadStremioAddons()
        val debrid = settingsRepository.loadDebrid()
        val playback = settingsRepository.loadPlayback()
        binding.statusBadge.text = if (!item.externalId.isNullOrBlank()) "Resolving addon stream…" else "Resolving live stream…"
        liveExecutor.execute {
            val target = playbackResolver.resolvePreferredTarget(
                title = item.title,
                externalId = item.externalId,
                mediaType = item.mediaType,
                addons = addons,
                debrid = debrid,
                playback = playback,
                dvr = dvr,
                xtream = xtream
            )
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (target == null) {
                    binding.statusBadge.text = if (!item.externalId.isNullOrBlank()) "No addon stream" else "No live test source"
                    Toast.makeText(
                        this,
                        if (!item.externalId.isNullOrBlank()) {
                            "No playable Stremio/Debrid stream was resolved. Check your addon URLs and Debrid settings."
                        } else {
                            "Configure Channels DVR or Xtream/IPTV in Settings to test playback."
                        },
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    binding.statusBadge.text = "Launching ${target.sourceLabel}"
                    val intent = Intent(this, PlayerActivity::class.java)
                        .putExtra(PlayerActivity.EXTRA_STREAM_URL, target.url)
                        .putExtra(PlayerActivity.EXTRA_TITLE, target.title)
                        .putExtra(PlayerActivity.EXTRA_DEBUG_LABEL, target.debugLabel)
                        .putExtra(PlayerActivity.EXTRA_SOURCE_LABEL, target.sourceLabel)
                    startActivity(intent)
                }
            }
        }
    }

    private fun revealFocusedCard(recyclerView: RecyclerView, verticalScroll: ScrollView, view: View, index: Int, verticalRowChange: Boolean = false) {
        val section = rowSlots().firstOrNull { it.recyclerView.id == recyclerView.id }?.section
        val performHorizontalReveal = Runnable {
            val lm = recyclerView.layoutManager as? LinearLayoutManager ?: return@Runnable
            if (verticalRowChange || index <= 0) {
                val targetPos = 0
                val offset = ((recyclerView.width - recyclerView.paddingLeft - recyclerView.paddingRight - view.width) / 2f).toInt()
                lm.scrollToPositionWithOffset(targetPos, offset)
            } else {
                recyclerView.smoothScrollToPosition(index)
            }
        }
        recyclerView.postOnAnimation {
            if (section != null) {
                if (verticalRowChange) {
                    rowSettleInProgress = true
                    pendingRowSettleRunnable?.let(mainHandler::removeCallbacks)
                    markNavigationBusy(220L)
                    snapToRow(section, smooth = false)
                    pendingRowSettleRunnable = Runnable {
                        if (view.isFocused && lastFocusedCardId == view.id) {
                            centerRowOnPosition(recyclerView, 0, requestFocus = true)
                        }
                        rowSettleInProgress = false
                    }.also { mainHandler.postDelayed(it, 90L) }
                } else {
                    performHorizontalReveal.run()
                    markNavigationBusy(160L)
                    snapToRow(section, smooth = false)
                }
            } else {
                verticalScroll.scrollTo(0, view.top)
                performHorizontalReveal.run()
            }
        }
    }

    private fun snapToRow(section: RowSection, smooth: Boolean) {
        val density = resources.displayMetrics.density
        val slot = rowSlots().firstOrNull { it.section == section } ?: return
        val rowTop = slot.titleView.top
        val target = if (section == RowSection.FIRST) 0 else (rowTop - (22f * density).toInt()).coerceAtLeast(0)
        binding.contentScroll.post {
            if (smooth) binding.contentScroll.smoothScrollTo(0, target)
            else binding.contentScroll.scrollTo(0, target)
        }
    }

    private fun glowAnimator(view: View, bloomView: View, hasFocus: Boolean) {
        (view.getTag(R.id.tag_pulse_animator) as? Animator)?.cancel()
        view.setTag(R.id.tag_pulse_animator, null)
        view.animate().cancel()
        bloomView.animate().cancel()
        if (!hasFocus) {
            view.scaleX = 1f
            view.scaleY = 1f
            view.translationY = 0f
            view.translationZ = 0f
            view.elevation = 0f
            view.alpha = 1f
            bloomView.alpha = 0f
            return
        }
        view.scaleX = 1.02f
        view.scaleY = 1.02f
        view.translationZ = 10f * resources.displayMetrics.density
        view.elevation = 0f
        view.alpha = 1f
        bloomView.alpha = 1f
    }

    private fun makeFocusGlowDrawable(radius: Float): Drawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius + (2f * resources.displayMetrics.density)
            setColor(0x00000000)
            setStroke((3f * resources.displayMetrics.density).toInt(), 0xFFFFB253.toInt())
        }
    }

    private fun makeFocusRing(radius: Float): Drawable {
        return LayerDrawable(arrayOf(
            GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = radius + (3f * resources.displayMetrics.density)
                setColor(0x00000000)
                setStroke((5f * resources.displayMetrics.density).toInt(), 0xFFF8F6F0.toInt())
            },
            GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = radius
                setColor(0x00000000)
                setStroke((2f * resources.displayMetrics.density).toInt(), 0xFFFFD27A.toInt())
            }
        ))
    }


    private fun animateHeroContentEntrance() {
        val targets = listOf(binding.heroTitleArtwork, binding.heroTitle, binding.heroMeta, binding.heroDesc, binding.statusBadge)
        targets.forEach { view ->
            view.animate().cancel()
            view.alpha = 1f
            view.translationY = 0f
        }
    }

    private fun previewHeroForFocus(item: TitleCard) {
        loadHeroBackdrop(item)
        applyHeroTitleVisual(item)
        binding.heroMeta.text = item.meta
        binding.heroDesc.text = item.desc
        binding.statusBadge.text = item.badge
    }

    private fun applyHeroTitleVisual(item: TitleCard) {
        val requestKey = heroRequestKey(item)
        pendingHeroLogoRequestKey = requestKey
        val cachedResolvedLogo = resolvedHeroLogoCache[requestKey]
        val logoUrl = preferredHeroLogoUrl(item, cachedResolvedLogo)
        val logoRes = resolveHeroLogoRes(item.title)
        binding.heroTitleArtwork.animate().cancel()
        binding.heroTitle.animate().cancel()
        Glide.with(this).clear(binding.heroTitleArtwork)
        binding.heroTitleArtwork.setImageDrawable(null)
        when {
            logoUrl != null -> {
                binding.heroTitleArtwork.visibility = View.VISIBLE
                binding.heroTitle.visibility = View.GONE
                imageRequest(Glide.with(this), logoUrl)
                    ?.apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).dontTransform())
                    ?.diskCacheStrategy(DiskCacheStrategy.ALL)
                    ?.override(1400, 560)
                    ?.dontAnimate()
                    ?.into(binding.heroTitleArtwork)
            }
            logoRes != 0 -> {
                binding.heroTitleArtwork.visibility = View.VISIBLE
                binding.heroTitleArtwork.setImageResource(logoRes)
                binding.heroTitle.visibility = View.GONE
            }
            else -> {
                binding.heroTitleArtwork.visibility = View.GONE
                binding.heroTitle.visibility = View.VISIBLE
                binding.heroTitle.text = item.title
            }
        }
    }

    private fun loadHeroBackdrop(item: TitleCard) {
        loadBackdropInto(
            imageView = binding.heroBackdrop,
            item = item,
            fallbackRes = item.backgroundRes
        )
    }

    private fun scheduleHeroCommit(item: TitleCard, delayMs: Long = 140L) {
        val requestKey = heroRequestKey(item)
        if (requestKey == committedHeroRequestKey) return
        pendingHeroCommitRunnable?.let(mainHandler::removeCallbacks)
        pendingHeroCommitRunnable = Runnable {
            if (isMotionBusy()) {
                scheduleHeroCommit(item, 160L)
            } else {
                commitHero(item)
            }
        }.also { mainHandler.postDelayed(it, delayMs) }
    }

    private fun commitHero(item: TitleCard) {
        if (isMotionBusy()) {
            scheduleHeroCommit(item, 180L)
            return
        }
        pendingHeroCommitRunnable?.let(mainHandler::removeCallbacks)
        pendingHeroCommitRunnable = null
        committedHeroRequestKey = heroRequestKey(item)
        preloadArtworkBundle(item)
        loadHeroBackdrop(item)
        binding.heroMeta.animate().cancel()
        binding.heroDesc.animate().cancel()
        binding.statusBadge.animate().cancel()
        applyHeroTitleVisual(item)
        maybeResolveHeroBackdropAsync(item)
        maybeResolveHeroLogoAsync(item)
        binding.heroMeta.text = item.meta
        binding.heroDesc.text = item.desc
        binding.statusBadge.text = item.badge
        animateHeroContentEntrance()
    }

    private fun maybeResolveHeroLogoAsync(item: TitleCard) {
        val requestKey = heroRequestKey(item)
        val tmdb = settingsRepository.loadTmdb()
        resolvedHeroLogoCache[requestKey]?.takeIf { it.isNotBlank() }?.let { resolved ->
            if (pendingHeroLogoRequestKey == requestKey) {
                binding.heroTitleArtwork.visibility = View.VISIBLE
                binding.heroTitle.visibility = View.GONE
                Glide.with(this).clear(binding.heroTitleArtwork)
                binding.heroTitleArtwork.setImageDrawable(null)
                imageRequest(Glide.with(this), resolved)
                    ?.apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).dontTransform())
                    ?.diskCacheStrategy(DiskCacheStrategy.ALL)
                    ?.override(1600, 640)
                    ?.dontAnimate()
                    ?.into(binding.heroTitleArtwork)
            }
            return
        }
        val imdbId = item.externalId?.takeIf { it.startsWith("tt") }
        val canResolveTmdbItem = item.sourceKey == "tmdb" && item.tmdbId > 0 && !item.mediaType.isNullOrBlank() && tmdb.apiKey.isNotBlank()
        val canResolveImdbItem = !imdbId.isNullOrBlank() && tmdb.apiKey.isNotBlank()
        if (!canResolveTmdbItem && !canResolveImdbItem) return
        if (!inFlightHeroLogoRequests.add(requestKey)) return
        heroLogoExecutor.execute {
            try {
                val resolved = if (canResolveTmdbItem) {
                    runCatching {
                        tmdbLiveLoader.resolveLogoForItem(
                            apiKey = tmdb.apiKey,
                            type = item.mediaType!!,
                            tmdbId = item.tmdbId,
                            language = tmdb.language.ifBlank { "en-US" },
                            fanartApiKey = BuildConfig.FANART_API_KEY,
                            fanartClientKey = BuildConfig.FANART_CLIENT_KEY
                        )
                    }.getOrNull()
                } else {
                    runCatching {
                        tmdbLiveLoader.resolveHeroArtForExternalId(
                            apiKey = tmdb.apiKey,
                            externalId = imdbId!!,
                            language = tmdb.language.ifBlank { "en-US" },
                            fanartApiKey = BuildConfig.FANART_API_KEY,
                            fanartClientKey = BuildConfig.FANART_CLIENT_KEY
                        )?.logoUrl
                    }.getOrNull()
                }
                if (resolved.isNullOrBlank()) return@execute
                resolvedHeroLogoCache[requestKey] = resolved
                runOnUiThread {
                    if (isFinishing || pendingHeroLogoRequestKey != requestKey) return@runOnUiThread
                    binding.heroTitleArtwork.visibility = View.VISIBLE
                    binding.heroTitle.visibility = View.GONE
                    Glide.with(this).clear(binding.heroTitleArtwork)
                    binding.heroTitleArtwork.setImageDrawable(null)
                    imageRequest(Glide.with(this), resolved)
                        ?.apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).dontTransform())
                        ?.diskCacheStrategy(DiskCacheStrategy.ALL)
                        ?.override(1600, 640)
                        ?.dontAnimate()
                        ?.into(binding.heroTitleArtwork)
                }
            } finally {
                inFlightHeroLogoRequests.remove(requestKey)
            }
        }
    }

    private fun maybeResolveHeroBackdropAsync(item: TitleCard) {
        val tmdb = settingsRepository.loadTmdb()
        val imdbId = item.externalId?.takeIf { it.startsWith("tt") } ?: return
        if (tmdb.apiKey.isBlank()) return
        val requestKey = heroRequestKey(item)
        if (resolvedHeroBackdropCache[requestKey].isNullOrBlank().not()) {
            if (committedHeroRequestKey == requestKey || pendingHeroLogoRequestKey == requestKey) {
                loadHeroBackdrop(item)
            }
            return
        }
        if (!inFlightHeroBackdropRequests.add(requestKey)) return
        heroLogoExecutor.execute {
            try {
                val resolved = runCatching {
                    tmdbLiveLoader.resolveHeroArtForExternalId(
                        apiKey = tmdb.apiKey,
                        externalId = imdbId,
                        language = tmdb.language.ifBlank { "en-US" },
                        fanartApiKey = BuildConfig.FANART_API_KEY,
                        fanartClientKey = BuildConfig.FANART_CLIENT_KEY
                    )
                }.getOrNull() ?: return@execute
                resolved.backdropUrl?.takeIf { it.isNotBlank() }?.let { resolvedHeroBackdropCache[requestKey] = it }
                resolved.logoUrl?.takeIf { it.isNotBlank() }?.let { resolvedHeroLogoCache[requestKey] = it }
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    val activeRequestKey = committedHeroRequestKey
                    if (activeRequestKey != requestKey && pendingHeroLogoRequestKey != requestKey) return@runOnUiThread
                    loadHeroBackdrop(item)
                    applyHeroTitleVisual(item)
                }
            } finally {
                inFlightHeroBackdropRequests.remove(requestKey)
            }
        }
    }

    private fun heroRequestKey(item: TitleCard): String = "${item.sourceKey}:${item.mediaType}:${item.tmdbId}:${item.externalId}:${item.title}"

    private fun prefetchHeroAssets(items: List<TitleCard>) {
        if (items.isEmpty()) return
        items.take(6).forEach { item ->
            preloadArtworkBundle(item)
        }
    }

    private fun resolveHeroLogoRes(title: String): Int {
        val normalized = buildString {
            title.toLowerCase(java.util.Locale.ROOT).forEach { ch ->
                when {
                    ch.isLetterOrDigit() -> append(ch)
                    ch == ' ' || ch == '-' || ch == '–' || ch == '—' || ch == ':' || ch == '/' -> append('_')
                }
            }
        }.replace(Regex("_+"), "_").trim('_')
        if (normalized.isBlank()) return 0
        return resources.getIdentifier("logo_${normalized}", "drawable", packageName)
    }


    private fun bindCardLogo(imageView: ImageView, item: TitleCard, highQuality: Boolean) {
        val requestKey = heroRequestKey(item)
        val logoUrl = resolvedHeroLogoCache[requestKey]?.takeIf { it.isNotBlank() }
            ?: item.logoUrl?.takeIf { it.isNotBlank() }
            ?: preferredHeroLogoUrl(item, null)?.takeIf { it.isNotBlank() }
        val cacheKey = requestKey + ":" + highQuality + ":" + (logoUrl ?: "none")
        val viewKey = System.identityHashCode(imageView)
        if (loadedCardLogoRequests[viewKey] == cacheKey) return
        loadedCardLogoRequests[viewKey] = cacheKey

        imageView.tag = heroRequestKey(item)
        Glide.with(this).clear(imageView)
        imageView.setImageDrawable(null)
        imageView.scaleType = ImageView.ScaleType.FIT_CENTER

        if (logoUrl != null) {
            imageView.visibility = View.VISIBLE
            imageRequest(Glide.with(this), logoUrl)
                ?.apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).disallowHardwareConfig().dontTransform())
                ?.diskCacheStrategy(DiskCacheStrategy.ALL)
                ?.override(if (highQuality) 900 else 680, if (highQuality) 340 else 260)
                ?.dontAnimate()
                ?.into(imageView)
        } else {
            imageView.visibility = View.GONE
        }
    }

    private fun backendImageProxyCandidates(url: String?): List<String> {
        val normalized = url?.trim()?.takeIf { it.isNotBlank() } ?: return emptyList()
        if (!normalized.startsWith("http://") && !normalized.startsWith("https://")) return listOf(normalized)
        val encoded = runCatching { URLEncoder.encode(normalized, Charsets.UTF_8.name()) }.getOrElse { return listOf(normalized) }
        return listOf(
            "$BACKEND_BASE_URL/api/image/fetch?url=$encoded",
            "$BACKEND_BASE_URL/api/image?url=$encoded",
            "$BACKEND_BASE_URL/image?url=$encoded",
            "$BACKEND_BASE_URL/proxy/image?url=$encoded",
            normalized
        ).distinct()
    }

    private fun imageRequest(requestManager: RequestManager, url: String?): RequestBuilder<Drawable>? {
        val candidates = backendImageProxyCandidates(url)
        if (candidates.isEmpty()) return null
        var request: RequestBuilder<Drawable>? = null
        for (candidate in candidates.asReversed()) {
            request = if (request == null) requestManager.load(candidate) else requestManager.load(candidate).error(request)
        }
        return request
    }

    private fun preloadImageUrl(url: String?, width: Int, height: Int) {
        val requestManager = Glide.with(this)
        imageRequest(requestManager, url)
            ?.diskCacheStrategy(DiskCacheStrategy.ALL)
            ?.skipMemoryCache(false)
            ?.preload(width, height)
    }

    private fun preloadArtworkBundle(item: TitleCard) {
        preloadImageUrl(preferredHeroBackdropUrl(item), 1920, 1080)
        preloadImageUrl(preferredHeroPosterUrl(item), 560, 840)
        preloadImageUrl(preferredHeroLogoUrl(item, resolvedHeroLogoCache[heroRequestKey(item)]), 900, 340)
        preloadImageUrl(item.backdropUrl, 1280, 720)
        preloadImageUrl(item.posterUrl, 520, 780)
        preloadImageUrl(item.logoUrl, 680, 260)
    }

    private fun maybeResolveCardLogoAsync(item: TitleCard, imageView: ImageView, highQuality: Boolean) {
        val tmdb = settingsRepository.loadTmdb()
        if (item.sourceKey != "tmdb" || item.tmdbId <= 0 || item.mediaType.isNullOrBlank() || tmdb.apiKey.isBlank()) return
        val requestKey = heroRequestKey(item)
        resolvedHeroLogoCache[requestKey]?.takeIf { it.isNotBlank() }?.let { resolved ->
            if (isMotionBusy()) return
            imageView.visibility = View.VISIBLE
            imageRequest(Glide.with(this), resolved)
                ?.apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).disallowHardwareConfig().dontTransform())
                ?.diskCacheStrategy(DiskCacheStrategy.ALL)
                ?.override(if (highQuality) 900 else 680, if (highQuality) 340 else 260)
                ?.dontAnimate()
                ?.into(imageView)
            return
        }
        val expectedTag = imageView.tag?.toString()
        liveExecutor.execute {
            val resolved = runCatching {
                tmdbLiveLoader.resolveLogoForItem(
                    apiKey = tmdb.apiKey,
                    type = item.mediaType,
                    tmdbId = item.tmdbId,
                    language = tmdb.language.ifBlank { "en-US" },
                    fanartApiKey = BuildConfig.FANART_API_KEY,
                    fanartClientKey = BuildConfig.FANART_CLIENT_KEY
                )
            }.getOrNull() ?: return@execute
            resolvedHeroLogoCache[requestKey] = resolved
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (imageView.tag?.toString() != expectedTag) return@runOnUiThread
                imageView.visibility = View.VISIBLE
                imageRequest(Glide.with(this), resolved)
                    ?.apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).disallowHardwareConfig().dontTransform())
                    ?.diskCacheStrategy(DiskCacheStrategy.ALL)
                    ?.override(if (highQuality) 900 else 680, if (highQuality) 340 else 260)
                    ?.dontAnimate()
                    ?.into(imageView)
            }
        }
    }

    private fun prefetchCardArtwork(items: List<TitleCard>) {
        items.take(18).forEach { item ->
            preloadArtworkBundle(item)
        }
    }

    private fun loadCardBackdropLayerInto(imageView: ImageView, item: TitleCard, highQuality: Boolean) {
        val posterUrl = item.posterUrl?.takeIf { it.isNotBlank() }
        val wideUrl = item.backdropUrl?.takeIf { it.isNotBlank() }
        val backgroundUrl = if (wideUrl != null && wideUrl != posterUrl) wideUrl else posterUrl
        val fallbackUrl = if (backgroundUrl == wideUrl) posterUrl else wideUrl
        val requestTag = "bg:${item.sourceKey}:${item.mediaType}:${item.tmdbId}:${item.title}:$highQuality:$backgroundUrl:$fallbackUrl"
        val viewKey = System.identityHashCode(imageView)
        if (loadedCardArtworkRequests[viewKey] == requestTag) return
        loadedCardArtworkRequests[viewKey] = requestTag

        Glide.with(this).clear(imageView)
        imageView.animate().cancel()
        imageView.tag = requestTag
        imageView.scaleType = ImageView.ScaleType.CENTER_CROP
        imageView.alpha = 0.94f
        imageView.setImageResource(item.backgroundRes)

        if (backgroundUrl == null) return

        val reqWidth = if (highQuality) 980 else 560
        val reqHeight = if (highQuality) 560 else 320
        val baseOptions = RequestOptions()
            .format(DecodeFormat.PREFER_ARGB_8888)
            .disallowHardwareConfig()
            .override(reqWidth, reqHeight)
            .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
            .skipMemoryCache(false)
            .centerCrop()

        val requestManager = Glide.with(this)
        val fallbackRequest = fallbackUrl?.let {
            imageRequest(requestManager, it)
                ?.apply(baseOptions)
                ?.transition(DrawableTransitionOptions.withCrossFade(140))
        }

        imageRequest(requestManager, backgroundUrl)
            ?.apply(baseOptions)
            ?.thumbnail(imageRequest(requestManager, backgroundUrl)?.apply(baseOptions.override(180, 104)))
            ?.transition(DrawableTransitionOptions.withCrossFade(140))
            ?.error(fallbackRequest ?: requestManager.load(item.backgroundRes).apply(baseOptions))
            ?.into(imageView)
    }

    private fun loadCardPosterLayerInto(imageView: ImageView, item: TitleCard, highQuality: Boolean) {
        val posterUrl = item.posterUrl?.takeIf { it.isNotBlank() }
        val wideUrl = item.backdropUrl?.takeIf { it.isNotBlank() }
        val usePosterLayer = posterUrl != null
        val requestTag = "poster:${item.sourceKey}:${item.mediaType}:${item.tmdbId}:${item.title}:$highQuality:$posterUrl:$wideUrl"
        val viewKey = System.identityHashCode(imageView)
        if (loadedCardArtworkRequests[viewKey] == requestTag) return
        loadedCardArtworkRequests[viewKey] = requestTag

        Glide.with(this).clear(imageView)
        imageView.animate().cancel()
        imageView.tag = requestTag
        imageView.scaleType = ImageView.ScaleType.FIT_CENTER
        imageView.setImageDrawable(null)
        imageView.visibility = if (usePosterLayer) View.VISIBLE else View.GONE
        imageView.alpha = if (usePosterLayer) 1f else 0f

        if (!usePosterLayer) return

        val reqWidth = if (highQuality) 720 else 420
        val reqHeight = if (highQuality) 1080 else 620
        val baseOptions = RequestOptions()
            .format(DecodeFormat.PREFER_ARGB_8888)
            .disallowHardwareConfig()
            .override(reqWidth, reqHeight)
            .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
            .skipMemoryCache(false)
            .fitCenter()

        val requestManager = Glide.with(this)
        imageRequest(requestManager, posterUrl)
            ?.apply(baseOptions)
            ?.thumbnail(imageRequest(requestManager, posterUrl)?.apply(baseOptions.override(140, 210)))
            ?.transition(DrawableTransitionOptions.withCrossFade(120))
            ?.error(requestManager.load(android.R.color.transparent).apply(baseOptions))
            ?.into(imageView)
    }

    private fun loadBackdropInto(
        imageView: ImageView,
        item: TitleCard,
        fallbackRes: Int
    ) {
        val backdrop = preferredHeroBackdropUrl(item)
        val poster = preferredHeroPosterUrl(item)
        val targetUrl = backdrop ?: poster
        val requestTag = "hero:${targetUrl ?: fallbackRes}:${itemHash(backdrop, poster)}"
        imageView.tag = requestTag
        Glide.with(this).clear(imageView)
        imageView.animate().cancel()
        imageView.setImageDrawable(null)
        imageView.setBackgroundColor(0xFF06080F.toInt())
        imageView.scaleType = ImageView.ScaleType.CENTER_CROP
        if (targetUrl.isNullOrBlank()) {
            imageView.setImageDrawable(safeDrawable(fallbackRes))
            return
        }
        val requestManager = Glide.with(this)
        val requestOptions = RequestOptions()
            .format(DecodeFormat.PREFER_ARGB_8888)
            .disallowHardwareConfig()
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .skipMemoryCache(false)

        val fullSizeOptions = requestOptions.centerCrop().override(3840, 2160)
        val largeFallbackOptions = requestOptions.centerCrop().override(2560, 1440)
        val thumb = imageRequest(requestManager, targetUrl)?.apply(
            requestOptions.override(1920, 1080).centerCrop()
        )
        val largeFallback = imageRequest(requestManager, targetUrl)
            ?.apply(largeFallbackOptions)
            ?.thumbnail(thumb)

        imageRequest(requestManager, targetUrl)
            ?.apply(fullSizeOptions)
            ?.thumbnail(thumb)
            ?.transition(DrawableTransitionOptions.withCrossFade(180))
            ?.placeholder(fallbackRes)
            ?.error(largeFallback)
            ?.into(imageView)
    }

    private fun preferredHeroBackdropUrl(item: TitleCard): String? {
        val requestKey = heroRequestKey(item)
        val cached = normalizeHeroBackdropUrl(resolvedHeroBackdropCache[requestKey])
        if (!cached.isNullOrBlank()) return cached
        val directBackdrop = normalizeHeroBackdropUrl(item.backdropUrl)
        if (!directBackdrop.isNullOrBlank()) return directBackdrop
        val derivedBackdrop = normalizeHeroBackdropUrl(metahubBackdropUrlFor(item.externalId))
        if (!derivedBackdrop.isNullOrBlank()) return derivedBackdrop
        return preferredHeroPosterUrl(item)
    }

    private fun preferredHeroPosterUrl(item: TitleCard): String? {
        val directPoster = normalizeHeroPosterUrl(item.posterUrl)
        if (!directPoster.isNullOrBlank()) return directPoster
        return normalizeHeroPosterUrl(metahubPosterUrlFor(item.externalId))
    }

    private fun preferredHeroLogoUrl(item: TitleCard, cachedLogo: String? = null): String? {
        return cachedLogo?.takeIf { it.isNotBlank() }
            ?: item.logoUrl?.takeIf { it.isNotBlank() }
            ?: metahubLogoUrlFor(item.externalId)
    }

    private fun metahubBackdropUrlFor(externalId: String?): String? =
        externalId?.takeIf { it.startsWith("tt") }?.let { "https://images.metahub.space/background/large/$it/img" }

    private fun metahubPosterUrlFor(externalId: String?): String? =
        externalId?.takeIf { it.startsWith("tt") }?.let { "https://images.metahub.space/poster/large/$it/img" }

    private fun metahubLogoUrlFor(externalId: String?): String? =
        externalId?.takeIf { it.startsWith("tt") }?.let { "https://images.metahub.space/logo/large/$it/img" }

    private fun normalizeHeroBackdropUrl(url: String?): String? =
        url?.takeIf { it.isNotBlank() }
            ?.replace("/background/small/", "/background/large/")
            ?.replace("/background/medium/", "/background/large/")
            ?.replace("/poster/small/", "/background/large/")
            ?.replace("/poster/medium/", "/background/large/")
            ?.replace("/w300/", "/original/")
            ?.replace("/w500/", "/original/")
            ?.replace("/w780/", "/original/")
            ?.replace("/w1280/", "/original/")

    private fun normalizeHeroPosterUrl(url: String?): String? =
        url?.takeIf { it.isNotBlank() }
            ?.replace("/poster/small/", "/poster/large/")
            ?.replace("/poster/medium/", "/poster/large/")
            ?.replace("/w300/", "/original/")
            ?.replace("/w500/", "/original/")
            ?.replace("/w780/", "/original/")

    private fun itemHash(backdrop: String?, poster: String?): String = listOfNotNull(backdrop, poster).joinToString("|")

    private fun safeDrawable(resId: Int): Drawable? = ContextCompat.getDrawable(this, resId)
}
