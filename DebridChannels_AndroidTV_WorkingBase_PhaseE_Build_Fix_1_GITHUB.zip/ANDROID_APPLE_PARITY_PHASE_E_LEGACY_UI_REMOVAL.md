# Android / Apple UI Parity — Phase E Legacy UI Removal

**Build:** `NewtoOld_v2.8.26.82_APPLE_PARITY_PHASE_E_BUILD_FIX_1`
**Base:** Phase D playback-presentation project (`v2.8.26.80`).

## Phase E result

Phase E removes the superseded Android presentation routes after the Phase B–D replacements and locks the app to the Apple-parity shell. The working Android functional core remains the production foundation.

### Removed rather than hidden

- `HomeLayoutEditorActivity` source and Android manifest entry.
- Pro Editor control and listener from Settings.
- Legacy left-side Home menu renderer and configurable menu-theme helpers.
- Legacy Home status-hub overlay.
- Unused `ContinueWatchingActivity` source and manifest route.
- Unused legacy `activity_main.xml` layout.
- Runtime marker assets that advertised the removed Pro Editor.

The full setup import/export utility remains because it protects account, add-on, IPTV, playback, and storage settings; it is now presented through the redesigned Settings screen and no longer references the removed editor.

## Apple-style Settings rebuild

- Fixed dark TV shell with Debrid Channels wordmark.
- Centered Settings title and warm-copper accent.
- Left category rail for General, Live TV, Catalogs, Add-ons, Playback, Trailers, Appearance, and Storage.
- Large black-glass content panel with existing functional controls preserved.
- DPAD category-to-content focus routing retained.
- Live TV category routes to the real channel-source controls.
- Appearance keeps supported runtime options only; there is no Pro Editor route.

## Catalog menu contract

- **Home** displays the protected Home catalog-row engine.
- **Movies** opens landscape movie catalog rows from the protected `UnifiedCatalogRepository`.
- **TV Shows** opens landscape show catalog rows from the same repository.
- Movies and TV Shows use cache-first rendering, progressive discovery refresh, artwork preload, horizontal rails, hero updates, and the fixed Apple-style top navigation.
- Only the first catalog row routes DPAD UP to the top menu; lower rows retain vertical row navigation.
- Live TV and Settings continue through their Phase C and Phase E shells.

## Functional-core protection

Not rewritten or replaced:

- Media3/ExoPlayer and VLC playback engines.
- Resolver, debrid, source grouping, headers, cookies, and link selection.
- Catalog repository and installed add-on discovery.
- Live TV providers, XMLTV/guide, HDHomeRun, Channels DVR, Xtream, and M3U paths.
- Favorites/history persistence, resume state, storage, cache, networking, and account settings.
- Phase D player overlay and its track/cast/quick-guide wiring.

## Device test checklist

1. Launch and confirm Home immediately renders cached/fallback catalog rows, then refreshes real rows.
2. Move UP from the first Home row to the fixed top menu and DOWN back into content.
3. Open Movies and confirm multiple landscape catalog rails render, focus, scroll, and open details.
4. Switch from Movies to TV Shows without returning to a legacy browser.
5. In lower Movies/TV Shows rails, verify UP moves to the previous rail rather than jumping directly to navigation.
6. Open Settings and test every left category, right-panel entry, Save, Cancel, and Back.
7. Confirm no Pro Editor entry exists anywhere and no removed Activity can be launched.
8. Test normal VOD playback, Phase D controls, audio/subtitles, Cast Wall, resume, and source switching.
9. Test Live TV grid, guide, tune, playback exit, and exact-card focus restoration.
10. Verify existing accounts, add-ons, favorites, history, IPTV inputs, and storage settings remain present.

## Validation before packaging

- Kotlin PSI syntax parsing across all remaining Kotlin sources.
- XML parsing across all resource and manifest XML files.
- Settings resource-ID cross-check.
- Manifest Activity-to-source cross-check.
- Search confirming no Pro Editor or removed Activity runtime references under `app/src/main`.
- Protected-core diff audit: changes limited to shell Activities, Settings presentation/resources, manifest cleanup, version markers, and documentation.

The included GitHub workflow remains the authoritative Android SDK build path: Java 17, Gradle 8.7, `clean assembleDebug`, and `bundleRelease`.
## Build Fix 1 — Android resource linker

The first Phase E GitHub build stopped in `:app:processDebugResources` before Kotlin compilation. `activity_player.xml` contained the unsupported XML attribute `android:horizontalScrollBarEnabled` on two `HorizontalScrollView` elements inherited from the Phase D presentation layer. Both uses are replaced with the valid framework attribute `android:scrollbars="none"`. No playback behavior, focus logic, or functional-core implementation changed.

