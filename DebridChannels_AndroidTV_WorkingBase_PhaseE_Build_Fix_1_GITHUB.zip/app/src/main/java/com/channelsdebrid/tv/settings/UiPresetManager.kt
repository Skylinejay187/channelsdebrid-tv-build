package com.channelsdebrid.tv.settings

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.util.Log
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Export/import the user's complete Debrid Channels setup from Apple-parity Settings.
 * v2.8.25.7 intentionally includes user-entered addon, TMDB, IPTV, playback, live backend,
 * and storage/source settings so a preset restore brings the whole app back, not just visuals.
 */
object UiPresetManager {
    private const val TAG = "DebridChannels"
    private const val PREFS_NAME = "channels_debrid_settings"
    private const val PRESET_VERSION = 2
    private const val FILE_NAME = "DebridChannels_Full_Preset.json"

    private val allowedPrefixes = listOf(
        "home_layout_",
        "tmdb_",
        "catalog_",
        "stremio_",
        "xtream_",
        "dvr_",
        "hdhomerun_",
        "live_backend_",
        "playback_",
        "live_guide_",
        "trailers_",
        "storage_",
        "profile_",
        "qr_"
    )

    private val deniedFragments = emptyList<String>()

    fun defaultFileName(): String = FILE_NAME

    fun presetFile(context: Context): File {
        // Fallback only. User-selected SAF export/import is preferred because Android TV
        // scoped storage blocks direct /Download writes on many devices.
        val dir = context.getExternalFilesDir("ui-presets") ?: context.filesDir
        return File(dir, FILE_NAME)
    }



    fun applyBundledDefaultPresetIfNeeded(context: Context): Int {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val marker = "bundled_full_preset_applied_phase_e_apple_parity_settings"
        if (prefs.getBoolean(marker, false)) return 0
        return try {
            val text = context.assets.open(FILE_NAME).bufferedReader(Charsets.UTF_8).use { it.readText() }
            val imported = importUiPresetText(context, text, preserveLiveSources = true)
            prefs.edit()
                .putBoolean(marker, true)
                .putString("live_backend_base_url", "http://192.168.100.55:8181")
                .apply()
            Log.i(TAG, "UI_PRESET_BUNDLED_DEFAULT_APPLIED: build=NewtoOld_v2.8.26.82_APPLE_PARITY_PHASE_E_BUILD_FIX_1 preserveLiveSources=true keys=" + imported)
            imported
        } catch (t: Throwable) {
            prefs.edit().putBoolean(marker, true).apply()
            Log.w(TAG, "UI_PRESET_BUNDLED_DEFAULT_FAILED: " + t.message)
            0
        }
    }

    fun buildPresetJson(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val values = JSONObject()
        prefs.all.forEach { (key, value) ->
            if (isAllowedUiKey(key)) {
                when (value) {
                    is Int -> values.put(key, value)
                    is Long -> values.put(key, value)
                    is Float -> values.put(key, value.toDouble())
                    is Boolean -> values.put(key, value)
                    is String -> values.put(key, value)
                }
            }
        }

        val root = JSONObject()
            .put("presetType", "DebridChannelsFullPreset")
            .put("presetVersion", PRESET_VERSION)
            .put("appBuild", "NewtoOld_v2.8.26.82_APPLE_PARITY_PHASE_E_BUILD_FIX_1")
            .put("containsFullUserSetup", true)
            .put("includes", "ui,tmdb,addons,iptv,live,playback,trailers,storage,profiles,qr")
            .put("createdAt", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US).format(Date()))
            .put("settings", values)
        return root.toString(2)
    }

    fun exportUiPreset(context: Context): File {
        val out = presetFile(context)
        out.parentFile?.mkdirs()
        out.writeText(buildPresetJson(context))
        Log.i(TAG, "UI_PRESET_EXPORT_FALLBACK: success path=${out.absolutePath}")
        return out
    }

    fun exportUiPresetToUri(context: Context, uri: Uri) {
        context.contentResolver.openOutputStream(uri, "wt")?.use { stream ->
            stream.write(buildPresetJson(context).toByteArray(Charsets.UTF_8))
            stream.flush()
        } ?: throw IllegalStateException("Unable to open selected export location")
        Log.i(TAG, "UI_PRESET_EXPORT_PICKER: success uri=$uri")
    }

    fun importUiPreset(context: Context): Int {
        val file = presetFile(context)
        if (!file.exists()) {
            Log.w(TAG, "UI_PRESET_IMPORT_FALLBACK: missing path=${file.absolutePath}")
            throw IllegalStateException("Preset not found: ${file.absolutePath}")
        }
        return importUiPresetText(context, file.readText()).also {
            Log.i(TAG, "UI_PRESET_IMPORT_FALLBACK: success path=${file.absolutePath} keys=$it")
        }
    }

    fun importUiPresetFromUri(context: Context, uri: Uri): Int {
        val text = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            ?: throw IllegalStateException("Unable to open selected preset")
        return importUiPresetText(context, text).also {
            Log.i(TAG, "UI_PRESET_IMPORT_PICKER: success uri=$uri keys=$it")
        }
    }

    private fun importUiPresetText(context: Context, text: String, preserveLiveSources: Boolean = false): Int {
        val root = JSONObject(text)
        val presetType = root.optString("presetType")
        require(presetType == "DebridChannelsFullPreset" || presetType == "DebridChannelsUiPreset") { "Invalid Debrid Channels preset file" }
        val settings = root.getJSONObject("settings")
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val edit = prefs.edit()
        var count = 0
        val keys = settings.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            if (!isAllowedUiKey(key)) continue
            // Bundled defaults must never wipe user-entered Live TV source information.
            // Manual preset import/export still restores the full setup, but first-run bundled
            // visual presets skip DVR/HDHomeRun/IPTV/XMLTV source keys so Live TV keeps working.
            if (preserveLiveSources && isLiveSourceKey(key)) continue
            when (val value = settings.get(key)) {
                is Int -> edit.putInt(key, value)
                is Long -> edit.putLong(key, value)
                is Double -> edit.putInt(key, value.toInt())
                is Boolean -> edit.putBoolean(key, value)
                is String -> edit.putString(key, value)
            }
            count++
        }
        edit.apply()
        return count
    }

    private fun isAllowedUiKey(key: String): Boolean {
        val lower = key.lowercase(Locale.US)
        return allowedPrefixes.any { lower.startsWith(it) } && deniedFragments.none { lower.contains(it) }
    }

    private fun isLiveSourceKey(key: String): Boolean {
        val lower = key.lowercase(Locale.US)
        return lower.startsWith("xtream_") ||
            lower.startsWith("dvr_") ||
            lower.startsWith("hdhomerun_") ||
            lower == "live_backend_xmltv_guide_url" ||
            lower == "live_backend_user_id"
    }
}
