Debrid Channels Android TV

Current checkpoint: Phase E legacy UI removal
Build marker: NewtoOld_v2.8.26.82_APPLE_PARITY_PHASE_E_BUILD_FIX_1

Home, Movies, and TV Shows use catalog rows. Settings uses the fixed premium TV shell. The removed Pro Editor and unused legacy activities are no longer part of the runtime app.

See README_PHASE_E.txt and ANDROID_APPLE_PARITY_PHASE_E_LEGACY_UI_REMOVAL.md.
