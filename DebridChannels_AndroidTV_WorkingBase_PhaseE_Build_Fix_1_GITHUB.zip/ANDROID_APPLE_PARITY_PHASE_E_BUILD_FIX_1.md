# Android / Apple UI Parity — Phase E Build Fix 1

**Build:** `NewtoOld_v2.8.26.82_APPLE_PARITY_PHASE_E_BUILD_FIX_1`  
**Base:** Failed Phase E source build `v2.8.26.81`.

## GitHub failure diagnosed

The uploaded Actions log failed in `:app:processDebugResources`. AAPT2 reported two invalid attributes in `app/src/main/res/layout/activity_player.xml`:

- Phase D VOD control dock `HorizontalScrollView`
- Live TV Quick Guide `HorizontalScrollView`

Both used `android:horizontalScrollBarEnabled="false"`, which is a view API property rather than a supported Android XML resource attribute.

## Correction

Both entries now use:

```xml
android:scrollbars="none"
```

This preserves the intended hidden-scrollbar appearance. The change does not modify Media3/VLC playback, resolver behavior, audio/subtitle handling, Cast Wall behavior, quick-guide data, focus routing, or any Phase E legacy-removal/catalog/settings work.

## Validation

- No remaining `horizontalScrollBarEnabled` or `verticalScrollBarEnabled` resource attributes.
- All resource and manifest XML parses successfully.
- Required player IDs remain present.
- Pro Editor and removed legacy activities remain absent.
- Build marker/version advanced so this archive cannot be confused with the failed `.81` ZIP.
