# Debrid Channels Android TV build

**Current build:** `NewtoOld_v2.8.26.82_APPLE_PARITY_PHASE_E_BUILD_FIX_1`
**Version code:** `282198`
**Functional base:** latest working Android TV project, advanced through Apple-parity Phases A–E.

Phase E locks the fixed top navigation, Home/Movie/TV Show catalog-row routes, redesigned TV Settings shell, Phase C Live TV grid, and Phase D playback presentation. The player, resolver, debrid, guide, provider, networking, persistence, and storage systems remain the working Android implementations.

Build through `build-apk.yml` or run `./gradlew clean assembleDebug bundleRelease` with Java 17 and Android SDK 35.
