package com.channelsdebrid.tv.playback

import android.content.Context
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import com.channelsdebrid.tv.settings.StorageSettings
import com.channelsdebrid.tv.storage.TimeshiftStorageManager
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.max

/**
 * TIF-inspired app-level timeshift session.
 *
 * This is intentionally not a full TvInputService. It mirrors the Android TV TIF model by keeping
 * a per-tune session with a known start/live-edge/current position and a temporary rolling buffer
 * directory. ExoPlayer still handles stream playback; this class owns the session state, safe seek
 * window, and optional NAS mirroring. Local storage remains primary so SMB hiccups cannot break play.
 */
class DebridChannelsTimeshiftSession(
    private val context: Context,
    private val rootDir: File,
    private val storage: StorageSettings,
    private val streamUrl: String,
    private val sourceLabel: String
) {
    private val sessionId: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + "_" + UUID.randomUUID().toString().take(8)
    val sessionDir: File = File(rootDir, "session_$sessionId")
    private val startedAtMs: Long = System.currentTimeMillis()
    private var lastMirrorAtMs: Long = 0L
    private var lastManifestAtMs: Long = 0L
    private var lastKnownLiveEdgeMs: Long = 0L
    private var lastKnownPositionMs: Long = 0L
    private var lastSeekable: Boolean = false
    private val liveBackend = com.channelsdebrid.tv.settings.SettingsRepository(context).loadLiveBackend()
    private var backendSessionUrl: String = ""

    fun start() {
        runCatching {
            rootDir.mkdirs()
            sessionDir.mkdirs()
            registerBackendSession()
            writeManifest(force = true)
        }
    }

    fun updateFromPlayer(player: ExoPlayer) {
        val duration = player.duration
        val position = player.currentPosition.coerceAtLeast(0L)
        val elapsed = (System.currentTimeMillis() - startedAtMs).coerceAtLeast(0L)
        lastKnownLiveEdgeMs = when {
            duration != C.TIME_UNSET && duration > 0L -> duration
            elapsed > 0L -> elapsed
            else -> max(lastKnownLiveEdgeMs, position)
        }
        lastKnownPositionMs = position
        lastSeekable = player.isCurrentMediaItemSeekable || (duration != C.TIME_UNSET && duration > 0L)
        writeManifest(force = false)
        mirrorToNasIfNeeded()
    }

    fun seekBack(player: ExoPlayer, amountMs: Long = 30_000L): Boolean {
        updateFromPlayer(player)
        val windowStart = bufferedWindowStartMs()
        val target = (lastKnownPositionMs - amountMs).coerceAtLeast(windowStart)
        return runCatching {
            if (lastSeekable || player.isCurrentMediaItemSeekable) {
                player.seekTo(target)
                true
            } else {
                false
            }
        }.getOrDefault(false)
    }

    fun seekForward(player: ExoPlayer, amountMs: Long = 30_000L): Boolean {
        updateFromPlayer(player)
        val liveEdge = bufferedLiveEdgeMs()
        val target = (lastKnownPositionMs + amountMs).coerceAtMost(liveEdge)
        return runCatching {
            if (lastSeekable || player.isCurrentMediaItemSeekable) {
                player.seekTo(target)
                true
            } else {
                false
            }
        }.getOrDefault(false)
    }

    fun statusLabel(): String {
        val target = when (storage.preferredTarget.lowercase(Locale.US)) {
            "usb" -> "USB"
            "nas" -> "NAS mirror"
            else -> "Internal"
        }
        val behindMs = (bufferedLiveEdgeMs() - lastKnownPositionMs).coerceAtLeast(0L)
        val behindLabel = if (behindMs > 2500L) " • -${formatDuration(behindMs)}" else " • live edge"
        return "Timeshift: $target$behindLabel"
    }

    fun close() {
        writeManifest(force = true)
        mirrorToNasIfNeeded(force = true)
    }

    private fun bufferedWindowStartMs(): Long {
        val minutes = storage.timeshiftMinutes.coerceIn(15, 240)
        val maxWindowMs = minutes.toLong() * 60_000L
        return (bufferedLiveEdgeMs() - maxWindowMs).coerceAtLeast(0L)
    }

    private fun bufferedLiveEdgeMs(): Long {
        val elapsed = (System.currentTimeMillis() - startedAtMs).coerceAtLeast(0L)
        return max(lastKnownLiveEdgeMs, elapsed)
    }

    private fun writeManifest(force: Boolean) {
        val now = System.currentTimeMillis()
        if (!force && now - lastManifestAtMs < 2_000L) return
        lastManifestAtMs = now
        runCatching {
            sessionDir.mkdirs()
            File(sessionDir, "timeshift_state.properties").writeText(
                "sessionId=$sessionId\n" +
                    "source=${sourceLabel.replace('\n', ' ')}\n" +
                    "streamUrl=${streamUrl.replace('\n', ' ')}\n" +
                    "startedAtMs=$startedAtMs\n" +
                    "updatedAtMs=$now\n" +
                    "positionMs=$lastKnownPositionMs\n" +
                    "liveEdgeMs=${bufferedLiveEdgeMs()}\n" +
                    "windowStartMs=${bufferedWindowStartMs()}\n" +
                    "seekable=$lastSeekable\n" +
                    "storage=${storage.preferredTarget}\n" +
                    "backendSessionUrl=$backendSessionUrl\n"
            )
        }
    }

    private fun registerBackendSession() {
        val base = liveBackend.baseUrl.trim().trimEnd('/').ifBlank { return }
        val userId = liveBackend.userId.ifBlank { "demo" }
        runCatching {
            val body = "{\"userId\":\"$userId\",\"minutes\":${storage.timeshiftMinutes.coerceIn(15, 240)}}"
            val conn = (URL("$base/live/timeshift/session").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 1200
                readTimeout = 1500
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
            conn.outputStream.use { it.write(body.toByteArray()) }
            if (conn.responseCode in 200..299) backendSessionUrl = "$base/live/cache/status?userId=$userId"
            conn.disconnect()
        }
    }

    private fun mirrorToNasIfNeeded(force: Boolean = false) {
        if (!storage.preferredTarget.equals("nas", ignoreCase = true)) return
        val now = System.currentTimeMillis()
        if (!force && now - lastMirrorAtMs < 5_000L) return
        lastMirrorAtMs = now
        runCatching { TimeshiftStorageManager(context).mirrorLocalBufferToNas(rootDir, storage) }
    }

    private fun formatDuration(ms: Long): String {
        val totalSeconds = (ms / 1000L).coerceAtLeast(0L)
        val minutes = totalSeconds / 60L
        val seconds = totalSeconds % 60L
        return String.format(Locale.US, "%d:%02d", minutes, seconds)
    }
}
