package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v6.9 EXACT_HERO_RATING_BADGES";
    public static final String LOG_MARKER = "DC_V6_9_EXACT_HERO_RATING_BADGES";
    private BuildMarkers() {}
}
