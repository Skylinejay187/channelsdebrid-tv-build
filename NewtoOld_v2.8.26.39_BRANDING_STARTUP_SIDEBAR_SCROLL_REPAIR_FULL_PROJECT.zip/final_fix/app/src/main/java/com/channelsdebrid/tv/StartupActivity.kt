package com.channelsdebrid.tv

import android.animation.ObjectAnimator
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class StartupActivity : AppCompatActivity() {
    private companion object { private const val TAG = "DebridChannels" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i(TAG, "STARTUP_CINEMATIC_FINAL: no_category_text=true no_loading_text=true orange_bar_animated=true fit_center=true")
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val bg = ImageView(this).apply {
            setImageResource(R.drawable.startup_splash_black)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = false
            alpha = 0f
        }
        root.addView(bg, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        val track = View(this).apply { background = rounded(0xFF171719.toInt(), 6); alpha = 0.78f }
        val bar = View(this).apply { background = rounded(0xFFFF8700.toInt(), 6); pivotX = 0f; scaleX = 0.02f }
        val glint = View(this).apply { background = rounded(0xFFFFD27A.toInt(), 8); alpha = 0f }
        val barWidth = dp(620)
        val barHeight = dp(5)
        val lp = FrameLayout.LayoutParams(barWidth, barHeight, Gravity.CENTER).apply { topMargin = dp(322) }
        root.addView(track, lp)
        root.addView(bar, FrameLayout.LayoutParams(barWidth, barHeight, Gravity.CENTER).apply { topMargin = dp(322) })
        root.addView(glint, FrameLayout.LayoutParams(dp(56), dp(7), Gravity.CENTER).apply { topMargin = dp(322); leftMargin = -barWidth / 2 })
        setContentView(root)
        ObjectAnimator.ofFloat(bg, "alpha", 0f, 1f).apply { duration = 420; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(bg, "scaleX", 0.992f, 1.0f).apply { duration = 1300; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(bg, "scaleY", 0.992f, 1.0f).apply { duration = 1300; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(bar, "scaleX", 0.02f, 1f).apply { duration = 1500; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(glint, "translationX", -barWidth / 2f, barWidth / 2f).apply { duration = 1500; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(glint, "alpha", 0f, 1f, 0f).apply { duration = 1500; interpolator = AccelerateDecelerateInterpolator(); start() }
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }, 1600)
    }
    private fun rounded(color: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = dp(radiusDp).toFloat() }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
