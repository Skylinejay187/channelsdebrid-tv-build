# Debrid Channels v1.8.8 dependency fix

Fixed GitHub Actions dependency resolution failure:

- Replaced invalid Media3 version `1.4.1` with `1.3.1` in `app/build.gradle` for:
  - media3-exoplayer
  - media3-exoplayer-dash
  - media3-exoplayer-hls
  - media3-ui
  - media3-datasource-cache
  - media3-database

No app behavior was changed in this repack. This is a full project zip for GitHub workflow upload.
