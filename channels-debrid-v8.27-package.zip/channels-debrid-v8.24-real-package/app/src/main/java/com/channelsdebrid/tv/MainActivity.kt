
package com.channelsdebrid.tv

import android.animation.Animator
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.graphics.Outline
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.view.ViewGroup
import android.text.TextUtils
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.channelsdebrid.tv.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var startupFocusLocked = true

    private enum class RowSection {
        FIRST,
        SECOND
    }

    data class TitleCard(
        val title: String,
        val meta: String,
        val desc: String,
        val badge: String,
        val brand: String,
        val footer: String,
        val progress: Float,
        val backgroundRes: Int
    )

    private val heroTitles = listOf(
        TitleCard("SHŌGUN", "S1 E7: A Stick of Time  •  43 min left", "A premium lean-back presentation for your media center, with live TV, trending shows, smart recommendations, and instant playback.", "⚑  Instant Playback Ready", "FX", "43 min left", 0.58f, R.drawable.bg_shogun),
        TitleCard("THE BATMAN", "2h 56m  •  IMAX", "A darker detective spotlight with premium backdrop changes and clean TV-safe row alignment.", "⚑  Direct Play Ready", "PLEX", "IMAX", 0.42f, R.drawable.bg_batman),
        TitleCard("FALLOUT", "49 min left  •  Prime", "Post-apocalyptic action with large-format hero art and poster rows that stay locked in place.", "⚑  Synced to Library", "prime", "49 min left", 0.51f, R.drawable.bg_fallout),
        TitleCard("DUNE", "2h 35m  •  Max", "Expansive cinema-style focus treatment with large typography and backdrop-driven navigation.", "⚑  HDR Available", "max", "Featured", 0.46f, R.drawable.bg_dune),
        TitleCard("HALO", "Series  •  Prime", "Sci-fi recommendations rendered in the same composition language as your reference shot.", "⚑  Resume Synced", "prime", "Series", 0.33f, R.drawable.bg_halo),
        TitleCard("WONKA", "Movie  •  Max", "Bright contrast title art for spotlight and recently-added rows without breaking the layout grid.", "⚑  Trailer Ready", "max", "Movie", 0.37f, R.drawable.bg_wonka),
        TitleCard("MAYOR OF KINGSTOWN", "Series  •  Paramount+", "Grounded drama hero state with full-screen poster changes as focus moves across rows.", "⚑  Watched on Device", "P+", "Series", 0.28f, R.drawable.bg_mayor),
        TitleCard("CIVIL WAR", "Movie  •  109 min", "Poster rows line up under the hero so the screen still feels premium and intentional.", "⚑  Cache Eligible", "A24", "109 min", 0.22f, R.drawable.bg_civilwar),
        TitleCard("AVATAR", "Movie  •  Disney+", "High-contrast blockbuster art for the lower row examples and future trailer pop-up placement.", "⚑  Dolby Vision", "D+", "Featured", 0.48f, R.drawable.bg_avatar)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setHero(heroTitles[3])
        populateRows()
        lockRowsForStartup()
        wireTopControls()
        wireRowNavigation()
        binding.contentScroll.post {
            binding.contentScroll.scrollTo(0, 0)
            binding.continueButton.isFocusableInTouchMode = true
            binding.continueButton.requestFocus()
            binding.contentScroll.postDelayed({
                binding.contentScroll.scrollTo(0, 0)
                binding.continueButton.requestFocus()
            }, 120)
            binding.contentScroll.postDelayed({
                unlockRowsAfterStartup()
                binding.contentScroll.scrollTo(0, 0)
            }, 420)
        }
    }

    private fun lockRowsForStartup() {
        startupFocusLocked = true
        blockRowFocus(binding.rowOne)
        blockRowFocus(binding.rowTwo)
    }

    private fun unlockRowsAfterStartup() {
        startupFocusLocked = false
        allowRowFocus(binding.rowOne)
        allowRowFocus(binding.rowTwo)
    }

    private fun blockRowFocus(row: LinearLayout) {
        row.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        for (i in 0 until row.childCount) {
            row.getChildAt(i).apply {
                isFocusable = false
                isFocusableInTouchMode = false
            }
        }
    }

    private fun allowRowFocus(row: LinearLayout) {
        row.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        for (i in 0 until row.childCount) {
            row.getChildAt(i).apply {
                isFocusable = true
                isFocusableInTouchMode = true
            }
        }
    }

    private fun wireTopControls() {
        val focusables = listOf(
            binding.menuButton,
            binding.homeButton,
            binding.navResume,
            binding.navSmart,
            binding.navLive,
            binding.navMovies,
            binding.continueButton,
            binding.settingsCard
        )

        focusables.forEach { v ->
            v.setOnFocusChangeListener { view, hasFocus ->
                view.animate().cancel()
                view.animate()
                    .scaleX(if (hasFocus) 1.05f else 1f)
                    .scaleY(if (hasFocus) 1.05f else 1f)
                    .alpha(if (hasFocus) 1f else 0.96f)
                    .setDuration(150)
                    .start()
            }
        }
    }


    private fun wireRowNavigation() {
        val rowOneCount = binding.rowOne.childCount
        val rowTwoCount = binding.rowTwo.childCount
        val pairCount = minOf(rowOneCount, rowTwoCount)

        for (i in 0 until pairCount) {
            val rowOneCard = binding.rowOne.getChildAt(i)
            val rowTwoCard = binding.rowTwo.getChildAt(i)
            rowOneCard.nextFocusDownId = rowTwoCard.id
            rowTwoCard.nextFocusUpId = rowOneCard.id
        }

        binding.continueButton.nextFocusDownId = binding.rowOne.getChildAt(0)?.id ?: View.NO_ID
        binding.navMovies.nextFocusDownId = binding.rowOne.getChildAt(0)?.id ?: View.NO_ID
        binding.settingsCard.nextFocusUpId = binding.rowTwo.getChildAt(0)?.id ?: View.NO_ID
    }

    private fun populateRows() {
        val rowOneItems = List(24) { index -> heroTitles[(index + 3) % heroTitles.size] }
        val rowTwoItems = List(24) { index -> heroTitles[(index + 6) % heroTitles.size] }

        binding.rowOne.removeAllViews()
        binding.rowTwo.removeAllViews()

        rowOneItems.forEachIndexed { index, item ->
            binding.rowOne.addView(makeCard(item, binding.rowOneScroll, binding.contentScroll, index, 276, 155))
        }
        rowTwoItems.forEachIndexed { index, item ->
            binding.rowTwo.addView(makeCard(item, binding.rowTwoScroll, binding.contentScroll, index, 276, 155))
        }
    }

    private fun makeCard(item: TitleCard, scrollView: HorizontalScrollView, verticalScroll: ScrollView, index: Int, widthDp: Int, heightDp: Int): View {
        val density = resources.displayMetrics.density
        val widthPx = (widthDp * density).toInt()
        val heightPx = (heightDp * density).toInt()
        val marginEnd = (16 * density).toInt()
        val pad = (14 * density).toInt()
        val progressHeight = 3
        val progressWidth = ((widthPx - (pad * 2)) * item.progress).toInt().coerceAtLeast((40 * density).toInt())
        val pillRadius = 34f * density

        val frame = FrameLayout(this).apply {
            id = View.generateViewId()
            layoutParams = LinearLayout.LayoutParams(widthPx, heightPx).apply { rightMargin = marginEnd }
            isFocusable = true
            isClickable = true
            foreground = null
            background = (ContextCompat.getDrawable(this@MainActivity, item.backgroundRes)?.mutate() as? GradientDrawable)?.apply {
                cornerRadius = pillRadius
            } ?: ContextCompat.getDrawable(this@MainActivity, item.backgroundRes)
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, pillRadius)
                }
            }
        }

        val overlay = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            background = (ContextCompat.getDrawable(this@MainActivity, R.drawable.card_overlay)?.mutate() as? GradientDrawable)?.apply {
                cornerRadius = pillRadius
            } ?: ContextCompat.getDrawable(this@MainActivity, R.drawable.card_overlay)
        }

        val bottomWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
            setPadding(pad, 0, pad, pad)
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (40 * density).toInt())
        }

        val title = TextView(this).apply {
            text = item.title
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 13.5f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            includeFontPadding = false
            lineSpacingExtra = 0f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
            gravity = Gravity.BOTTOM
        }

        val brand = TextView(this).apply {
            text = item.brand
            setTextColor(0xFFEFE6DA.toInt())
            textSize = 8.5f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            includeFontPadding = false
            gravity = Gravity.END or Gravity.BOTTOM
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams((44 * density).toInt(), LinearLayout.LayoutParams.MATCH_PARENT).apply {
                leftMargin = (8 * density).toInt()
            }
        }

        val progressTrack = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (progressHeight * density).toInt()).apply {
                topMargin = (6 * density).toInt()
            }
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.pill_dark)
            alpha = 0.45f
        }

        val progressBar = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(progressWidth, (progressHeight * density).toInt(), Gravity.START or Gravity.CENTER_VERTICAL)
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.button_primary)
            alpha = 0.95f
        }

        val progressFrame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (progressHeight * density).toInt()).apply {
                topMargin = (6 * density).toInt()
            }
            addView(progressTrack)
            addView(progressBar)
        }

        val footer = TextView(this).apply {
            text = item.footer
            setTextColor(0xFFE6DCCD.toInt())
            textSize = 8.5f
            includeFontPadding = false
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (12 * density).toInt()).apply {
                topMargin = (6 * density).toInt()
            }
        }

        titleRow.addView(title)
        titleRow.addView(brand)
        bottomWrap.addView(titleRow)
        bottomWrap.addView(progressFrame)
        bottomWrap.addView(footer)

        frame.addView(overlay)
        frame.addView(bottomWrap)

        frame.cameraDistance = 12000f

        frame.setOnFocusChangeListener { view, hasFocus ->
            pulseAnimator(view, hasFocus)
            view.alpha = if (hasFocus) 1f else 0.96f
            view.translationZ = if (hasFocus) 18f * resources.displayMetrics.density else 0f
            frame.foreground = if (hasFocus) ContextCompat.getDrawable(this, R.drawable.focus_ring_pill_pulse) else null
            if (hasFocus) {
                setHero(item)
                if (!startupFocusLocked) {
                    revealFocusedCard(scrollView, verticalScroll, view, index)
                }
            }
        }
        return frame
    }


    private fun revealFocusedCard(scrollView: HorizontalScrollView, verticalScroll: ScrollView, view: View, index: Int) {
        scrollView.post {
            val leftAnchorPx = (40f * resources.displayMetrics.density).toInt()
            val horizontalTarget = when {
                index <= 0 -> 0
                else -> (view.left - leftAnchorPx).coerceAtLeast(0)
            }
            scrollView.smoothScrollTo(horizontalTarget, 0)

            val section = when (scrollView.id) {
                binding.rowOneScroll.id -> RowSection.FIRST
                binding.rowTwoScroll.id -> RowSection.SECOND
                else -> null
            }
            if (section != null) {
                snapToRow(section, smooth = true)
            } else {
                verticalScroll.smoothScrollTo(0, view.top)
            }
        }
    }

    private fun snapToRow(section: RowSection, smooth: Boolean) {
        val density = resources.displayMetrics.density

        // Keep a persistent hero zone visible while allowing only one dominant active row.
        // Smaller anchor values scroll farther down, which pushes the previous row mostly away.
        val activeRowTopPx = when (section) {
            RowSection.FIRST -> (286f * density).toInt()
            RowSection.SECOND -> (214f * density).toInt()
        }

        val sectionTop = when (section) {
            RowSection.FIRST -> binding.rowOneScroll.top
            RowSection.SECOND -> binding.rowTwoScroll.top
        }

        val unclampedTarget = (sectionTop - activeRowTopPx).coerceAtLeast(0)

        // Prevent landing in a weak in-between state where two full rows remain on screen.
        val maxTarget = (binding.rowTwoScroll.top - (214f * density).toInt()).coerceAtLeast(0)
        val topTarget = when (section) {
            RowSection.FIRST -> unclampedTarget.coerceAtMost((32f * density).toInt())
            RowSection.SECOND -> unclampedTarget.coerceAtMost(maxTarget)
        }

        binding.contentScroll.post {
            if (smooth) binding.contentScroll.smoothScrollTo(0, topTarget)
            else binding.contentScroll.scrollTo(0, topTarget)
        }
    }

    private fun pulseAnimator(view: View, hasFocus: Boolean) {
        (view.getTag(R.id.tag_pulse_animator) as? Animator)?.cancel()
        if (hasFocus) {
            val pulse = ObjectAnimator.ofPropertyValuesHolder(
                view,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1.038f, 1.055f, 1.046f, 1.038f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1.038f, 1.055f, 1.046f, 1.038f),
                PropertyValuesHolder.ofFloat(View.TRANSLATION_Y, -4f * resources.displayMetrics.density, -6.5f * resources.displayMetrics.density, -5f * resources.displayMetrics.density, -4f * resources.displayMetrics.density),
                PropertyValuesHolder.ofFloat(View.ALPHA, 0.99f, 1f, 0.994f, 0.99f)
            ).apply {
                duration = 5200
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.RESTART
                start()
            }
            view.setTag(R.id.tag_pulse_animator, pulse)
        } else {
            view.animate().cancel()
            view.animate()
                .scaleX(1f)
                .scaleY(1f)
                .translationY(0f)
                .setDuration(260)
                .start()
            view.setTag(R.id.tag_pulse_animator, null)
        }
    }

    private fun setHero(item: TitleCard) {
        binding.heroBackdrop.setImageDrawable(safeDrawable(item.backgroundRes))
        binding.heroTitle.text = item.title
        binding.heroMeta.text = item.meta
        binding.heroDesc.text = item.desc
        binding.statusBadge.text = item.badge
    }

    private fun safeDrawable(resId: Int): Drawable? = ContextCompat.getDrawable(this, resId)
}
