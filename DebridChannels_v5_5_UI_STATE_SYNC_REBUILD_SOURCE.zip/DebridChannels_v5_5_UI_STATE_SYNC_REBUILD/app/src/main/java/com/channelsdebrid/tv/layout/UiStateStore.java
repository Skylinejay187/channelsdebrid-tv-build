package com.channelsdebrid.tv.layout;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * v5 clean-core UI state owner.
 * Persistent single source for hero/menu/layout-editor settings.
 * No legacy storage code is carried over.
 */
public final class UiStateStore {
    private static final String PREFS = "dc_v5_ui_state";

    private static final String KEY_MENU_POSITION = "menuPosition";
    private static final String KEY_ICON_PLACEMENT = "iconPlacement";
    private static final String KEY_ROW_TITLES = "rowTitles";
    private static final String KEY_UI_4K = "ui4k";
    private static final String KEY_HERO_LOGO_X = "heroLogoX";
    private static final String KEY_HERO_LOGO_Y = "heroLogoY";
    private static final String KEY_ARTWORK_SIZE = "artworkSize";
    private static final String KEY_HERO_LAYOUT = "heroLayout";
    private static final String KEY_ARTWORK_LAYER = "artworkLayer";

    private final SharedPreferences p;

    public UiStateStore(Context c) {
        p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public String menuPosition() { return p.getString(KEY_MENU_POSITION, "center"); }
    public String iconPlacement() { return p.getString(KEY_ICON_PLACEMENT, "right"); }
    public boolean rowTitles() { return p.getBoolean(KEY_ROW_TITLES, true); }
    public boolean ui4k() { return p.getBoolean(KEY_UI_4K, true); }
    public int heroLogoX() { return p.getInt(KEY_HERO_LOGO_X, 80); }
    public int heroLogoY() { return p.getInt(KEY_HERO_LOGO_Y, 170); }
    public int artworkSize() { return p.getInt(KEY_ARTWORK_SIZE, 220); }
    public String heroLayout() { return p.getString(KEY_HERO_LAYOUT, "cinematic"); }
    public String artworkLayer() { return p.getString(KEY_ARTWORK_LAYER, "poster,banner,clearlogo,disc,character"); }

    public void saveMenuPosition(String v) { p.edit().putString(KEY_MENU_POSITION, safe(v, "center")).apply(); }
    public void saveIconPlacement(String v) { p.edit().putString(KEY_ICON_PLACEMENT, safe(v, "right")).apply(); }
    public void saveRowTitles(boolean v) { p.edit().putBoolean(KEY_ROW_TITLES, v).apply(); }
    public void save4k(boolean v) { p.edit().putBoolean(KEY_UI_4K, v).apply(); }
    public void saveHeroLayout(String v) { p.edit().putString(KEY_HERO_LAYOUT, safe(v, "cinematic")).apply(); }
    public void saveArtworkLayer(String v) { p.edit().putString(KEY_ARTWORK_LAYER, safe(v, "poster,banner,clearlogo,disc,character")).apply(); }
    public void saveArtwork(int x, int y, int size) {
        p.edit()
                .putInt(KEY_HERO_LOGO_X, x)
                .putInt(KEY_HERO_LOGO_Y, y)
                .putInt(KEY_ARTWORK_SIZE, size)
                .apply();
    }

    public void resetLayoutDefaults() {
        p.edit()
                .putString(KEY_MENU_POSITION, "center")
                .putString(KEY_ICON_PLACEMENT, "right")
                .putBoolean(KEY_ROW_TITLES, true)
                .putBoolean(KEY_UI_4K, true)
                .putInt(KEY_HERO_LOGO_X, 80)
                .putInt(KEY_HERO_LOGO_Y, 170)
                .putInt(KEY_ARTWORK_SIZE, 220)
                .putString(KEY_HERO_LAYOUT, "cinematic")
                .putString(KEY_ARTWORK_LAYER, "poster,banner,clearlogo,disc,character")
                .apply();
    }

    private static String safe(String v, String fallback) {
        return v == null || v.trim().isEmpty() ? fallback : v.trim();
    }
}
