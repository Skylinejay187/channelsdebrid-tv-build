# v5.4 TRUE VISUAL PARITY NEW CORE Audit

Starting point: `DebridChannels_v5_1_FEATURE_REWIRE_CLEAN_CORE_SOURCE.zip`.

Visual reference only: `debridchannelsApp_v2.1.3_PRO_LAYOUT_MENU_ART_LIVEFIX_FULL.zip`.

Rules followed:
- The v2.1.3 project was not used as the source base.
- The v2.1.3 visual style was used only as a reference for hero layout, pill menu, cinematic metadata, row cards, focus scaling, and Live TV guide feel.
- App code remains built from the v5.1 clean-core structure.
- Marker: `DC_V5_5_UI_STATE_SYNC`.

Visual parity work included:
- Replaced plain text home screen with cinematic hero backdrop/gradient.
- Added title/logo-style hero block, metadata badges, description, right-side banner slot.
- Added large landscape row cards with rounded corners and DPAD focus scale.
- Preserved Settings, Pro Layout Editor entry, Stremio JSON manager, backend URL, M3U URL, catalog URL, 4K toggle.
- Preserved Live TV guide surface on new core.

Known next pass:
- Replace generated gradient card placeholders with real loaded artwork once backend/Stremio images are connected.
- Tune exact spacing against the v2.1.3 screenshots after APK testing.

## v5.5 UI State Sync
- Added complete clean-core UiStateStore methods required by visual parity UI.
- Persistent icon placement, menu position, row-title, 4K, hero layout, and artwork state are now owned by UiStateStore.
- v2.1.3 remains visual reference only; base remains v5.1 clean core lineage.
