# Rewrite Build Audit — v0.0.1 Stable Full Fixed Source v3

Base used: v0.0.1 stable line from the v6.9 known-good source.

Rule followed: clean consolidation from the chosen stable base. Broken v7.x builds were not used as a source base.

This rebuild fixes the card artwork issue without removing the centered logo layer:
- Restored the centered card logo overlay.
- Strictly blocks poster/background/thumb/portrait/landscape/banner artwork from the logo layer.
- Allows real logo sources such as `/logo/`, `clearlogo`, and Fanart clearlogo paths.
- Adds a Metahub `/logo/medium/<imdbId>/img` fallback when the backend item has an IMDb id but no logo field.
- Prevents wide card background from falling back to portrait poster art. Cards use only banner/landscape/backdrop-safe artwork.
- Preserves the working active-row UP/DOWN navigation.

Version:
- versionName: 0.0.1
- versionCode: 1
- visible marker: DC_V0_0_1_STABLE_BASE
- logcat marker: DC_V0_0_1_ACTIVE
