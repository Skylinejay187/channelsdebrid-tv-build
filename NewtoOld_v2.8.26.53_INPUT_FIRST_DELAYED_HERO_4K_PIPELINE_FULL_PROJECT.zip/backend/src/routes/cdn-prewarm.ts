import { Router } from "express"

const DISABLED_MESSAGE = "Bunny artwork auto-prewarm is disabled by default. Normal poster/logo/backdrop loading, app Glide cache, focused preview on-demand resolving, and manual artwork loading are preserved. Set ENABLE_BUNNY_ARTWORK_AUTO_PREWARM=true only if you intentionally want to re-enable broad CDN prewarm jobs."

export function cdnPrewarmRouter() {
  const router = Router()

  const autoPrewarmEnabled = () => String(process.env.ENABLE_BUNNY_ARTWORK_AUTO_PREWARM ?? "false").toLowerCase() === "true"

  router.get("/api/prewarm", (_req, res) => {
    res.json({
      ok: true,
      accepted: false,
      disabled: !autoPrewarmEnabled(),
      version: "backend_v1.8.13.8_BUNNY_ARTWORK_AUTO_PREWARM_DISABLED_BY_DEFAULT",
      message: DISABLED_MESSAGE,
      preserved: [
        "normal artwork loading",
        "app-side poster/logo/backdrop cache",
        "focused-card preview resolver",
        "Live TV",
        "provider-direct IPTV"
      ]
    })
  })

  router.get("/api/cdn/prewarm/status", (_req, res) => {
    res.json({
      ok: true,
      enabled: autoPrewarmEnabled(),
      accepted: false,
      queued: 0,
      running: false,
      version: "backend_v1.8.13.8_BUNNY_ARTWORK_AUTO_PREWARM_DISABLED_BY_DEFAULT",
      message: autoPrewarmEnabled()
        ? "Auto-prewarm flag is enabled, but this clean repair build does not start broad prewarm queues from the app."
        : DISABLED_MESSAGE
    })
  })

  router.get("/api/cdn/prewarm/:scope", (req, res) => {
    res.json({
      ok: true,
      accepted: false,
      disabled: !autoPrewarmEnabled(),
      version: "backend_v1.8.13.8_BUNNY_ARTWORK_AUTO_PREWARM_DISABLED_BY_DEFAULT",
      message: DISABLED_MESSAGE,
      scope: req.params.scope,
      limit: req.query.limit ?? null,
      force: req.query.force ?? null
    })
  })

  router.post("/api/cdn/prewarm/:scope", (req, res) => {
    res.json({
      ok: true,
      accepted: false,
      disabled: !autoPrewarmEnabled(),
      version: "backend_v1.8.13.8_BUNNY_ARTWORK_AUTO_PREWARM_DISABLED_BY_DEFAULT",
      message: DISABLED_MESSAGE,
      scope: req.params.scope,
      receivedItems: Array.isArray(req.body?.items) ? req.body.items.length : 0
    })
  })

  return router
}
