# NewtoOld_v2.8.26.39_SHARP_BASE_LIVE_TV_GRACENOTE_SETTINGS_RESTORE_FULL_PROJECT

Base: NewtoOld_v2.8.26.39 sharp renderer + restored Live TV working loader.

Changes:
- Preserves existing Live TV loader/source validation behavior.
- Does not hardcode DVR/IPTV addresses.
- Cutout work remains paused/backlogged.
- Restores user setting for Live TV program thumbnails instead of forcing it off.
- Keeps RenderThread-safe behavior: no eager guide-art prewarm during boot; artwork is lazy only after XMLTV/Gracenote program rows are attached.
- Queues a visible Gracenote/XMLTV refresh when XMLTV/Gracenote is configured and thumbnails are enabled, even if a stale/saved EPG cache exists.
- Updates visible version/build markers.
