# Settings Control Center XML Fix Audit

Base: NewtoOld_v2.8.26.39_SHARP_BASE_LOW_END_PERFORMANCE_SETTINGS_CONTROL_CENTER_FULL_PROJECT.zip

Fixes applied:
- Fixed malformed Android XML in `app/src/main/res/layout/activity_settings.xml`.
- Replaced raw `Artwork & CDN` text with XML-safe `Artwork &amp; CDN`.
- Scanned all `app/src/main/res/**/*.xml` files for raw ampersands that would break Android resource merging.
- Parsed all XML resource files locally with Python ElementTree successfully.

Preserved:
- v2.8.26.39 sharp base behavior.
- Low-end Android TV performance mode.
- Live TV loader/Gracenote/provider-direct behavior.
- BunnyCDN artwork/prewarm integration expectations.
- Settings Control Center layout.

Note:
- This environment does not include a real Gradle distribution; the project includes a minimal wrapper stub that tells the GitHub Action to build with Gradle. Local XML resource validation passed before packaging.
