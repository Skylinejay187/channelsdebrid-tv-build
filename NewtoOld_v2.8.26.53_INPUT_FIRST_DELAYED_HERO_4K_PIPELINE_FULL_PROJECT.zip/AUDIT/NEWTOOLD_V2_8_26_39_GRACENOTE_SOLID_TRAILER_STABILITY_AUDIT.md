# NewtoOld v2.8.26.39 Gracenote Solid Thumbnail + Trailer Stability Audit

Base: v2.8.26.39 sharp app base with restored Live TV loader and Gracenote settings.

Changes:
- Preserved Live TV loader/source validation behavior.
- Removed ghosted Gracenote thumbnail alpha from guide program art chips.
- Removed duplicate guide-card foreground overlay from program art chips.
- Loads guide program art center-crop and opaque for sharper Gracenote thumbnails.
- Added trailer player buffer tuning and longer trailer HTTP read timeout.
- Kept cutout/foreground extraction paused/backlogged.

No hardcoded DVR IP. No Live TV source overwrite.
