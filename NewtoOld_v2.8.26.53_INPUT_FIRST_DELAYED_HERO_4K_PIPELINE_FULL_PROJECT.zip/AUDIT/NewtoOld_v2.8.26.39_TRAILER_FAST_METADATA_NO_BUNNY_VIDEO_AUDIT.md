# NewtoOld_v2.8.26.39_SHARP_BASE_TRAILER_FAST_METADATA_NO_BUNNY_VIDEO

Base: v2.8.26.39 sharp app base with Live TV category focus/editor fixes preserved.

Purpose:
- Make trailer resolving faster on slower Android TV devices without using BunnyCDN for trailer video bytes.

Changes:
- Visible app version/build marker updated.
- Trailer prewarm payload now uses `cacheVideo=false`, `metadataOnly=true`, `bunnyVideoProxy=false`, and `prefer4k=false`.
- Default trailer quality preference changed to non-4K for Xgimi stability.
- Trailer resolve requests add `progressiveFirst=true`, `metadataOnly=true`, `bunnyVideoProxy=false`, and `maxHeight=1080`.
- Backend trailer request timeout reduced so unavailable trailers fail faster instead of hanging.

Preserved:
- v2.8.26.39 sharp renderer.
- Live TV loader, Gracenote restore, category focus/editor behavior.
- Provider-direct IPTV streams.
- Bunny artwork-only routing.
- Cutouts remain paused/backlogged.

Note:
- This is source zip only in this environment; APK compile must be done on the laptop/Android Studio setup.
