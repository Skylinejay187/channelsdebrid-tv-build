NewtoOld v2.8.26.50

This build disables only the broad backend Bunny artwork auto-prewarm queue/job while preserving normal artwork loading/cache and focused-card preview behavior.

Do not confuse this with disabling normal poster/logo/backdrop loading. Those remain on.

Backend check:
/api/cdn/prewarm/status should return enabled=false, accepted=false, queued=0 by default.
