# NewtoOld v2.8.26.39 — Backend Cutout Asset Pipeline + Opacity Fix

Base: v2.8.26.37, not v2.8.26.38.

Changes:
- Reverted away from v2.8.26.38 right-side crop behavior.
- Preserved v37 no-global-glow behavior.
- Added backend cutout asset fields to Android model parsing:
  - hero_backdrop / heroBackdropUrl
  - hero_foreground_cutout / heroForegroundCutoutUrl
  - hero_palette / heroPaletteUrl
  - hero_mask_quality / heroMaskQualityUrl
- Android now prefers a real transparent backend foreground cutout when available.
- If no cutout exists, Android falls back safely to v37 backdrop behavior without fake whole-poster opacity pop.
- Opacity fix: fallback backdrops stay softer; only real cutout assets get near-full alpha and depth transform.
- Version markers updated in build.gradle and runtime log marker.

Important:
- This app build supports the real pipeline contract, but true subject separation requires backend-provided transparent cutout assets.
- No Live TV, row scrolling, guide, or backend URL behavior was intentionally changed.
