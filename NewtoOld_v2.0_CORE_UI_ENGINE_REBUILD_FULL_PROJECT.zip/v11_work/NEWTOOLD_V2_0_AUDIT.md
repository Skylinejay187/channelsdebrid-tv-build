# NewtoOld v2.0 Core UI Engine Rebuild Audit

Base: NewtoOld v1.1 full project.

Changes in this pass:
- Added hard DPAD focus graph interception for row UP/DOWN so old row focus recovery cannot bounce back to the previous row.
- Added hero-section Extra Artwork layer (`heroExtraArtwork`) for poster/banner/logo-style art with placement controls.
- Added hero quality mode to the Layout Editor: 0 = 1080p default, 1 = 4K hero mode.
- Expanded top menu icon/lettering themes and menu shell themes, including no-glass styles.
- Real-Debrid/TorBox runtime is hard-disabled: settings save is no-op, load is disabled/direct, resolver bypasses debrid providers.
- Live TV logic/player were not intentionally touched.

Verification markers:
- DC_BUILD_MARKER: NewtoOld_v2.0_CORE_UI_ENGINE_REBUILD
- FOCUS_GRAPH: ACTIVE
- HERO_ARTWORK_ENGINE: ACTIVE
- HERO_QUALITY_MODE_APPLY: 1080p/4K
- TOP_MENU_ENGINE: ACTIVE
- DEBRID_STATUS: NOT_PRESENT
