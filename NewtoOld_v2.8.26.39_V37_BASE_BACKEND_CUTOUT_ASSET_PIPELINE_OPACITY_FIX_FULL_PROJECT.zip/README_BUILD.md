NewtoOld_v2.8.26.1_FULL_BRAND_PURGE_QR_PROFILES_STARTUP_ICON

versionCode: 282179
versionName: NewtoOld_v2.8.26.37_V18_BASE_CUTOUT_NO_GLOBAL_GLOW_SUBJECT_DEPTH_REBALANCE

Final playback hardening build with adaptive buffering, safe watchdog, silent rebuffer, decoder/source reliability memory, audio-route debounce, and session stability mode.

Verify logcat marker:
DC_BUILD_MARKER: NewtoOld_v2.8.26.37_V18_BASE_CUTOUT_NO_GLOBAL_GLOW_SUBJECT_DEPTH_REBALANCE
