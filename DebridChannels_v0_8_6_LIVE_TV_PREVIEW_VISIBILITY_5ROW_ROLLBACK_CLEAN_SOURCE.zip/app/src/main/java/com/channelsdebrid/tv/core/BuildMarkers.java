package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.8.6 Live TV Preview Visibility Rollback Fix";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.8.6_livetv_preview_visibility_5row_rollback_clean_base";
}
