package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.5.7 LIVE TV GOOGLE REFERENCE REAL LAYOUT";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.5.7_old_app_live_tv_layout_port_clean_base";
    private BuildMarkers() {}
}
