NewtoOld v2.8.6.2 — VOD Cache / Trailer Focus / Advisory Correction

Corrections:
- Added visible VOD cache status text directly under the Infuse-style progress bar so cache state is no longer silent.
- Kept solid progress as playback progress and secondary progress as cached/buffered amount.
- Reworked advisory tag fallback so it does not default to generic "Mature Themes" for weak metadata.
- Added more specific advisory labels: TV-MA, Rated R, NC-17, Nudity, Language, Violence, Substances, Graphic Images.
- Trailer popup PlayerView/WebView no longer steals DPAD focus from popup buttons.
- Popup now focuses Fullscreen first so Fullscreen/Mute/Close are selectable while trailer plays.

Notes:
- Full cached percentage still requires direct-file Content-Length/range support.
- Unknown-size streams show buffered cache state instead of hiding the cache layer.
