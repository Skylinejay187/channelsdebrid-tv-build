package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.6.5 LIVE TV PLAYBACK + GUIDE PERF FIX";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.6.5_livetv_hls_dash_guide_perf_clean_base";
    private BuildMarkers() {}
}
