package com.channelsdebrid.tv.layout;

import android.content.Context;
import android.content.SharedPreferences;

public final class UiStateStore {
    public static final int DEFAULT_CARD_WIDTH_DP = 286;
    public static final int DEFAULT_CARD_HEIGHT_DP = 160;
    public static final int MIN_CARD_WIDTH_DP = 120;
    public static final int MAX_CARD_WIDTH_DP = 560;
    public static final int MIN_CARD_HEIGHT_DP = 68;
    public static final int MAX_CARD_HEIGHT_DP = 320;
    private static final String PREFS = "dc_v5_ui_state";
    private final SharedPreferences p;
    public UiStateStore(Context c) { p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
    private int i(String k,int d){ return p.getInt(k,d); }
    private boolean b(String k,boolean d){ return p.getBoolean(k,d); }
    private String s(String k,String d){ return p.getString(k,d); }
    private void putI(String k,int v){ p.edit().putInt(k,v).apply(); }
    private void putB(String k,boolean v){ p.edit().putBoolean(k,v).apply(); }
    private void putS(String k,String v){ p.edit().putString(k,(v==null||v.trim().isEmpty())?"":v.trim()).apply(); }
    public String menuPosition() { return s("menuPosition", "center"); }
    public String iconPlacement() { return s("iconPlacement", "right"); }
    public boolean rowTitles() { return b("rowTitles", true); }
    public boolean ui4k() { return b("ui4k", true); }
    public int heroLogoX() { return i("heroLogoX", 80); }
    public int heroLogoY() { return i("heroLogoY", 170); }
    public int artworkSize() { return i("artworkSize", 220); }
    public String heroLayout() { return s("heroLayout", "cinematic"); }
    public String artworkLayer() { return s("artworkLayer", "poster,banner,clearlogo,disc,character"); }
    public void saveMenuPosition(String v) { putS("menuPosition", v); }
    public void saveIconPlacement(String v) { putS("iconPlacement", v); }
    public void saveRowTitles(boolean v) { putB("rowTitles", v); }
    public void save4k(boolean v) { putB("ui4k", v); }
    public void saveHeroLayout(String v) { putS("heroLayout", v); }
    public void saveArtworkLayer(String v) { putS("artworkLayer", v); }
    public void saveArtwork(int x, int y, int size) { putI("heroLogoX",x); putI("heroLogoY",y); putI("artworkSize",size); }
    public int statusHubEnabled(){return i("statusHubEnabled",1);} public int statusHubTimeEnabled(){return i("statusHubTimeEnabled",1);} public int statusHubWeatherEnabled(){return i("statusHubWeatherEnabled",0);} public int statusHubNotificationsEnabled(){return i("statusHubNotificationsEnabled",1);} public int statusHubTheme(){return i("statusHubTheme",0);} public int statusHubRightDp(){return i("statusHubRightDp",18);} public int statusHubBottomDp(){return i("statusHubBottomDp",10);} public int statusHubWidthDp(){return i("statusHubWidthDp",315);} public int statusHubHeightDp(){return i("statusHubHeightDp",46);} public int statusHubTextSizeSp(){return i("statusHubTextSizeSp",18);} public int heroLogoLeftDp(){return i("heroLogoLeftDp",0);} public int heroLogoTopDp(){return i("heroLogoTopDp",0);} public int heroLogoWidthDp(){return i("heroLogoWidthDp",430);} public int heroLogoHeightDp(){return i("heroLogoHeightDp",96);} public int previewCardCount(){return i("previewCardCount",4);} public int rowTopDp(){return i("rowTopDp",430);} public int rowLeftDp(){return i("rowLeftDp",6);} public int cardWidthDp(){return i("cardWidthDp",DEFAULT_CARD_WIDTH_DP);} public int cardHeightDp(){return i("cardHeightDp",DEFAULT_CARD_HEIGHT_DP);} public int cardSpacingDp(){return i("cardSpacingDp",12);} public int focusedScalePercent(){return i("focusedScalePercent",100);} public int glowStrengthPercent(){return i("glowStrengthPercent",70);} public int pulseStrengthPercent(){return i("pulseStrengthPercent",0);} public int focusRingEnabled(){return i("focusRingEnabled",0);} public int focusRingThicknessDp(){return i("focusRingThicknessDp",2);} public int focusRingColorIndex(){return i("focusRingColorIndex",0);} public int cardTiltPercent(){return i("cardTiltPercent",0);} public int cardLiftDp(){return i("cardLiftDp",0);} public int cornerRadiusDp(){return i("cornerRadiusDp",28);} public int dimUnfocusedPercent(){return i("dimUnfocusedPercent",0);} public int topMenuIconStyle(){return i("topMenuIconStyle",1);} public int menuCompositionMode(){return i("menuCompositionMode",1);} public int searchItemPlacement(){return i("searchItemPlacement",1);} public int settingsItemPlacement(){return i("settingsItemPlacement",1);} public int rowTitleVisibility(){return i("rowTitleVisibility",1);} public int extraArtworkEnabled(){return i("extraArtworkEnabled",1);} public int extraArtworkType(){return i("extraArtworkType",1);} public int extraArtworkXdp(){return i("extraArtworkXdp",760);} public int extraArtworkYdp(){return i("extraArtworkYdp",120);} public int extraArtworkWidthDp(){return i("extraArtworkWidthDp",240);} public int extraArtworkHeightDp(){return i("extraArtworkHeightDp",160);} public int extraArtworkOpacityPercent(){return i("extraArtworkOpacityPercent",95);} public int extraArtworkDepthPercent(){return i("extraArtworkDepthPercent",35);} public int topMenuFontIndex(){return i("topMenuFontIndex",0);} public int heroFontIndex(){return i("heroFontIndex",0);} public int contentFontIndex(){return i("contentFontIndex",0);} public int rowTitleIconsEnabled(){return i("rowTitleIconsEnabled",1);} public int focusBouncePercent(){return i("focusBouncePercent",0);} public int glassCardMode(){return i("glassCardMode",0);} public int hoverInfoOverlay(){return i("hoverInfoOverlay",1);} public int backgroundDimOnFocusPercent(){return i("backgroundDimOnFocusPercent",10);} public int effectProfileIndex(){return i("effectProfileIndex",0);} public int heroTextLeftDp(){return i("heroTextLeftDp",0);} public int heroTextTopDp(){return i("heroTextTopDp",0);} public int topMenuOffsetDp(){return i("topMenuOffsetDp",0);} public int bottomSafeDp(){return i("bottomSafeDp",72);}
    public void applyV095StartupDefaults(){ if(!p.getBoolean("v095Hero1080DefaultApplied",false)){ p.edit().putInt("heroDensityMode",0).putBoolean("v095Hero1080DefaultApplied",true).apply(); } } public int value(String key,int fallback){return i(key,fallback);} public void saveValue(String key,int value){putI(key,value); if("rowTitleVisibility".equals(key))saveRowTitles(value==1); if("searchItemPlacement".equals(key)||"settingsItemPlacement".equals(key))syncIconPlacement(); if("effectProfileIndex".equals(key))applyEffectProfile(value);} 
    private void syncIconPlacement(){int a=searchItemPlacement(),b=settingsItemPlacement(); if(a==1&&b==1)saveIconPlacement("inline"); else if(a==2||b==2)saveIconPlacement("left"); else if(a==3||b==3)saveIconPlacement("right"); else saveIconPlacement("hidden");}
    private void applyEffectProfile(int profile){switch(Math.max(0,Math.min(4,profile))){case 1:putI("glowStrengthPercent",35);putI("pulseStrengthPercent",0);putI("cardTiltPercent",0);putI("dimUnfocusedPercent",12);putI("focusBouncePercent",8);putI("glassCardMode",0);break;case 2:putI("glowStrengthPercent",85);putI("pulseStrengthPercent",55);putI("cardTiltPercent",20);putI("dimUnfocusedPercent",30);putI("focusBouncePercent",28);putI("glassCardMode",1);break;case 3:putI("glowStrengthPercent",55);putI("pulseStrengthPercent",20);putI("cardTiltPercent",65);putI("dimUnfocusedPercent",35);putI("focusBouncePercent",18);putI("glassCardMode",1);break;case 4:putI("glowStrengthPercent",100);putI("pulseStrengthPercent",70);putI("cardTiltPercent",30);putI("dimUnfocusedPercent",42);putI("focusBouncePercent",35);putI("glassCardMode",1);putI("hoverInfoOverlay",1);break;}}
    public void saveLayoutSnapshot(){ p.edit().putLong("layoutSavedAt", System.currentTimeMillis()).apply(); }
    public long layoutSavedAt(){ return p.getLong("layoutSavedAt", 0L); }
    public void resetLayoutDefaults(){p.edit().clear().apply();}
    public void resetCardSizeDefaults(){ p.edit().putInt("cardWidthDp", DEFAULT_CARD_WIDTH_DP).putInt("cardHeightDp", DEFAULT_CARD_HEIGHT_DP).apply(); }
}
