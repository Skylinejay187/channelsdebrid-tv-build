package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.9.7 Live TV Reference Layout Rewrite";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.9.7_live_tv_reference_layout_rewrite_clean_consolidation";
}
