# v0.9.7 Live TV Reference Layout Rewrite Audit

Base: v0.9.6 Advanced Live TV Layout Editor clean source.

Clean consolidation rule followed:
- This pass rewrites the Live TV view renderer from the v0.9.6 clean source layer.
- Player startup/playback logic is preserved: `playChannel`, preview ExoPlayer setup, media-source creation, playback hints, and existing channel loading remain untouched.
- The old Live TV visual shell is replaced with a Google Free TV / Arvio-style reference layout.

Implemented:
- Left category rail visually matches the provided reference direction: circular icons, large white focused pill, channel counts, no app top menu artifacts.
- Full guide mode is entered from DPAD RIGHT on the category rail and hides the category rail.
- Full guide mode keeps the Live TV preview visible top-right and the guide bottom anchored.
- Force Refresh Guide is not rendered in the Live TV guide view.
- Current-time red guide line and timeline labels are present.
- Existing Live TV player code remains separated from layout rendering.
- Existing v0.9.6 advanced Live TV editor source remains in the tree for future re-binding after the visual rewrite stabilizes.

Debug markers preserved/added:
- `DC_BUILD_MARKER: v0.9.7_live_tv_reference_layout_rewrite`
- `LIVE_TV_REFERENCE_LAYOUT_REWRITE`
- `LIVE_TV_THEME_APPLIED_RENDERER`
- `THEME_APPLY: categoryRail=...`
- `THEME_APPLY: guide=...`
- `THEME_APPLY: preview=...`
- `THEME_APPLY: timeline=...`

Hard locks:
- No Force Refresh button in full guide.
- Preview uses RESIZE_MODE_FIT so it stays fully visible.
- Guide remains bottom anchored.
- Default visible row count is held at 5+ rows.
- No profile/menu artifacts added.

Backlog preserved, not implemented:
- Dolby Vision support.
- Dolby/DTS audio handling.
- Frame-rate matching.
- Resolution matching.
