import { Router } from "express"
import fs from "node:fs/promises"
import path from "node:path"

interface LiveSource {
  id: string
  userId: string
  type: "m3u" | "xtream" | "channels_dvr"
  name: string
  url: string
  username?: string
  password?: string
  updatedAt: string
}

const DATA_DIR = path.join(process.cwd(), "backend", "data")
const SOURCES_PATH = path.join(DATA_DIR, "live-sources.json")

async function loadSources(): Promise<LiveSource[]> {
  try {
    const raw = await fs.readFile(SOURCES_PATH, "utf8")
    return JSON.parse(raw) as LiveSource[]
  } catch {
    return []
  }
}

async function saveSources(sources: LiveSource[]): Promise<void> {
  await fs.mkdir(DATA_DIR, { recursive: true })
  await fs.writeFile(SOURCES_PATH, JSON.stringify(sources, null, 2), "utf8")
}

export function liveRouter() {
  const router = Router()

  router.get("/live/sources", async (req, res, next) => {
    try {
      const userId = String(req.query.user_id ?? req.query.userId ?? "demo")
      const sources = (await loadSources()).filter(s => s.userId === userId)
      res.json({ ok: true, sources })
    } catch (err) {
      next(err)
    }
  })

  router.post("/live/sources/connect", async (req, res, next) => {
    try {
      const body = req.body ?? {}
      const userId = String(body.userId ?? body.user_id ?? "demo").trim() || "demo"
      const type = String(body.type ?? "").trim() as LiveSource["type"]
      const url = String(body.url ?? "").trim()
      const name = String(body.name ?? type.toUpperCase()).trim() || type.toUpperCase()
      if (!["m3u", "xtream", "channels_dvr"].includes(type)) {
        res.status(400).json({ ok: false, error: "Unsupported live source type" })
        return
      }
      if (!url) {
        res.status(400).json({ ok: false, error: "Live source URL missing" })
        return
      }
      const sources = await loadSources()
      const id = `${userId}_${type}_${Buffer.from(url).toString("base64url").slice(0, 16)}`
      const nextSource: LiveSource = {
        id,
        userId,
        type,
        name,
        url,
        username: body.username ? String(body.username) : undefined,
        password: body.password ? String(body.password) : undefined,
        updatedAt: new Date().toISOString(),
      }
      const withoutOld = sources.filter(s => s.id !== id)
      withoutOld.push(nextSource)
      await saveSources(withoutOld)
      res.json({ ok: true, source: { ...nextSource, password: nextSource.password ? "***" : undefined } })
    } catch (err) {
      next(err)
    }
  })

  router.post("/live/refresh", async (req, res) => {
    const userId = String(req.body?.userId ?? req.body?.user_id ?? "demo")
    res.json({ ok: true, userId, refreshedAt: new Date().toISOString() })
  })

  return router
}
