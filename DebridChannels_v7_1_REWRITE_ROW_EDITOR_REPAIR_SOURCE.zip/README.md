# Debrid Channels v6.3

Clean-core Android TV source.

Build marker: `DC_V6_3_STABLE_INTERACTIVE_HERO_EDITOR_RESTORE`

Default backend: `http://192.168.100.55:8181`

Highlights:
- Stable interactive Pro Layout Editor overlay
- Scrollable Settings / editor controls
- Card rows remain snap-scrollable
- Focused card drives cinematic hero background/logo/banner
- Backend `/api/home` artwork row loading preserved


## v7.1 rewrite row/editor repair
Marker: `DC_V7_1_REWRITE_ROW_EDITOR_REPAIR`

This build follows the rewrite/consolidation rule and fixes stale marker carryover, HOME row UP/DOWN focus movement, Pro Layout Editor consolidation, and wide-card artwork selection.
