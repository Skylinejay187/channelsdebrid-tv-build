# CLEAN CORE AUDIT - v6.3

Marker: `DC_V6_4_EDITOR_SCROLL_FOCUS_FIX`

Base lineage: v6.2 clean-core line, with v6.0 row snap and v6.2 backend artwork work preserved.

Locked restores in this build:
- Pro Layout Editor restored as a fast overlay panel.
- Save / Reset / View Home controls preserved.
- Card width/height defaults remain 286 x 160 and are adjustable.
- Menu position, icon placement, row title visibility, 4K toggle, focused scale, glow, corner radius, row offsets, hero text offsets, top menu offset, extra artwork slot sizing/position/opacity, effect profile, and hover overlay controls exposed.
- Settings and editor lists are scrollable.
- DPAD left/right on sliders changes values directly.
- Top menu wrap containment remains locked.
- Focused card drives hero background/logo/banner with cinematic delayed update.

Legacy rule:
- v2.1.3 remains visual/feature reference only.
- No legacy Activity stack or old LiveTvActivity restored.

## v6.9 Exact Hero Rating Badges
- Preserved v6.8 logo-only row cards and backend artwork behavior.
- Added inline hero metadata badges matching the reference: year, featured/source tag, IMDb yellow pill + rating, TMDB teal pill + rating.
- Added backend field binding for imdbRating/tmdbRating and fallback parsing from metadata strings.

## v7.0
Preserved agreed features. Fixed landscape card art priority and vertical DPAD row-to-row focus without reusing old legacy code.
