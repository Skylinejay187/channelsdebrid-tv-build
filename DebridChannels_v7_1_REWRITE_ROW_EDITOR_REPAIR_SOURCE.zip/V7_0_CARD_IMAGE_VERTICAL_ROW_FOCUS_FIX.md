# v7.0 Card Image + Vertical Row Focus Fix

- Row cards now avoid thumbnail-as-banner mapping, so square thumbnails are not promoted into wide cards.
- Card artwork priority remains landscape/banner -> background/backdrop -> poster fallback.
- DPAD DOWN moves from the current card row to the next row at the matching card index.
- DPAD UP moves to the previous row, or back to the hero menu from the first row.
- Only the first row auto-focuses on home load, preventing later rows from stealing focus.
- Preserves Pro Layout Editor, backend artwork loading, logo-only cards, ratings badges, and carousel behavior.

Marker: DC_V7_0_CARD_IMAGE_VERTICAL_ROW_FOCUS_FIX
