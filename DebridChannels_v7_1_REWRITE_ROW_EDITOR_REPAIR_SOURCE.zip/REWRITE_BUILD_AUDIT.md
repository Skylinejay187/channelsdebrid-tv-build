# Rewrite Build Audit — v7.1

Build marker: `DC_V7_1_REWRITE_ROW_EDITOR_REPAIR`

Priority rule for this project:
- Every new upgrade/fix is a rewrite/consolidation from the latest known-good clean line.
- No stale version/build marker carryover is allowed.
- Previously agreed features must be preserved unless explicitly removed.

Base used:
- Latest clean generated line: `DebridChannels_v7_0_CARD_IMAGE_VERTICAL_ROW_FOCUS_FIX_SOURCE.zip`
- Old v2.1.3 zip is not used as source code. It remains visual/settings reference only.

Rewritten/Consolidated in this build:
- Build identity fully updated in `BuildMarkers.java` and `app/build.gradle`.
- Added visible on-screen v7.1 marker.
- Added global HOME DPAD up/down row navigation interception so row vertical movement uses the active row engine.
- Tracks focused row/card index during focus changes.
- Preserves top menu wrap behavior.
- Preserves Pro Layout Editor overlay and slider DPAD behavior.
- Adds missing editor controls for card label mode, hero rating badges, theme preset, and background fade speed.
- Fixes artwork selection so wide cards prefer banner/background and do not promote portrait poster art as the primary wide image unless no wide art exists.
- Keeps backend default URL: `http://192.168.100.55:8181`.

Regression fixes targeted:
- Cannot move UP/DOWN between rows.
- Version/build marker showing stale older build.
- Pro Layout Editor settings not staying consolidated.
- Row cards showing portrait/square art in wide card slots.
