package com.channelsdebrid.tv.backend;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * v5 clean-core backend configuration owner.
 * All user-editable backend/catalog/live-TV endpoints persist here.
 */
public final class BackendConfig {
    private final SharedPreferences prefs;

    public BackendConfig(Context context) {
        prefs = context.getSharedPreferences("dc_v5_backend", Context.MODE_PRIVATE);
    }

    public String baseUrl() {
        return prefs.getString("baseUrl", "http://192.168.100.55:8181");
    }

    public String m3uUrl() {
        return prefs.getString("m3uUrl", "");
    }

    public String catalogUrl() {
        return prefs.getString("catalogUrl", "");
    }

    public String channelsDvrUrl() {
        return prefs.getString("channelsDvrUrl", baseUrl());
    }

    public void saveBaseUrl(String url) {
        prefs.edit().putString("baseUrl", clean(url)).apply();
    }

    public void saveM3uUrl(String url) {
        prefs.edit().putString("m3uUrl", clean(url)).apply();
    }

    public void saveCatalogUrl(String url) {
        prefs.edit().putString("catalogUrl", clean(url)).apply();
    }

    public void saveChannelsDvrUrl(String url) {
        prefs.edit().putString("channelsDvrUrl", clean(url)).apply();
    }

    private String clean(String value) {
        return value == null ? "" : value.trim();
    }
}
