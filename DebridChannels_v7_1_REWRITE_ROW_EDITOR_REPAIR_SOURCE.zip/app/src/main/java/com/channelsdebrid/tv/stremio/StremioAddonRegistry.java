package com.channelsdebrid.tv.stremio;
import android.content.Context;import android.content.SharedPreferences;import java.util.*;
public final class StremioAddonRegistry {
    private final SharedPreferences p;
    public StremioAddonRegistry(Context c){ p=c.getSharedPreferences("dc_v5_stremio",Context.MODE_PRIVATE); }
    public String getJsonLinks(){ return p.getString("jsonLinks",""); }
    public void saveJsonLinks(String links){ p.edit().putString("jsonLinks", links == null ? "" : links).apply(); }
}
