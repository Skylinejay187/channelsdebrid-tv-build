package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v7.1 REWRITE_ROW_EDITOR_REPAIR";
    public static final String LOG_MARKER = "DC_V7_1_REWRITE_ROW_EDITOR_REPAIR";
    private BuildMarkers() {}
}
