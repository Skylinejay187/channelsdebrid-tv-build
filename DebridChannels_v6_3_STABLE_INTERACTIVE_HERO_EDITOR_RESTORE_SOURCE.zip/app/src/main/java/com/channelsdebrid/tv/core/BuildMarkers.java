package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v6.3 STABLE_INTERACTIVE_HERO_EDITOR_RESTORE";
    public static final String LOG_MARKER = "DC_V6_3_STABLE_INTERACTIVE_HERO_EDITOR_RESTORE";
    private BuildMarkers() {}
}
