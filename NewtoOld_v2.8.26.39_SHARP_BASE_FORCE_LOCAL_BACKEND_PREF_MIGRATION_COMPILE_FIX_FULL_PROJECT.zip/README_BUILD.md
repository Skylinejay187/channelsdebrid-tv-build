NewtoOld_v2.8.26.39_SHARP_BASE_FORCE_LOCAL_BACKEND_PREF_MIGRATION

Base: user-uploaded NewtoOld_v2.8.26.39_V37_BASE_BACKEND_CUTOUT_ASSET_PIPELINE_OPACITY_FIX_FULL_PROJECT.zip

Purpose:
- Sharp-image rollback app base preserved.
- Bundled DebridChannels_Full_Preset.json as default app settings.
- Runtime backend defaults corrected to http://192.168.100.55:8181 for local testing.
- Future app updates should build forward from this v2.8.26.39 sharp base unless the user requests a different base.
- SharedPreferences long reads hardened to accept Int/Long/String for trailer delays.
- Version/build markers updated to avoid stale build labels.

DC_BUILD_MARKER: NewtoOld_v2.8.26.39_SHARP_BASE_FORCE_LOCAL_BACKEND_PREF_MIGRATION
VERSION_CODE: 282183
VERSION_NAME: NewtoOld_v2.8.26.39_SHARP_BASE_FORCE_LOCAL_BACKEND_PREF_MIGRATION
