Build notes:
- Unzip this package and commit the folder contents to your GitHub repo root.
- The workflow file is already included at .github/workflows/build-apk.yml.
- GitHub Actions will build the debug APK artifact automatically on push or workflow_dispatch.


## NewtoOld_v2.8.23.0_PLAYER_HARDENING_REWRITE_MAX_STABILITY
Maximum-stability VOD player hardening rewrite. Verify logcat marker: DC_BUILD_MARKER: NewtoOld_v2.8.23.0_PLAYER_HARDENING_REWRITE_MAX_STABILITY
