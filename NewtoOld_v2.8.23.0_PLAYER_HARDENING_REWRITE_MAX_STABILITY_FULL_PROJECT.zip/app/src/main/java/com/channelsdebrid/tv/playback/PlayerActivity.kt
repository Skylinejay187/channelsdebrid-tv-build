package com.channelsdebrid.tv.playback

import android.app.AlertDialog
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.media.AudioManager
import android.provider.DocumentsContract
import android.content.Context
import android.media.MediaCodecList
import android.os.Build
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.Surface
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.Format
import androidx.media3.common.Timeline
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.TransferListener
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.database.StandaloneDatabaseProvider
import com.channelsdebrid.tv.storage.TimeshiftStorageManager
import com.channelsdebrid.tv.storage.SmbNasBrowser
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.bumptech.glide.Glide
import com.channelsdebrid.tv.R
import com.channelsdebrid.tv.TvSafeAreaHelper
import com.channelsdebrid.tv.BuildConfig
import com.channelsdebrid.tv.settings.SettingsRepository
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.io.File
import java.io.FileOutputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.ServerSocket
import java.net.Socket
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var topOverlay: View
    private lateinit var playerBackdropView: ImageView
    private lateinit var titleArtworkView: ImageView
    private lateinit var titleView: TextView
    private lateinit var metaTextView: TextView
    private lateinit var statusView: TextView
    private lateinit var channelBadgeView: TextView
    private lateinit var channelLogoView: ImageView
    private lateinit var clockView: TextView
    private lateinit var nowTimeView: TextView
    private lateinit var nextView: TextView
    private lateinit var progressView: ProgressBar
    private lateinit var liveTopInfo: View
    private lateinit var nowRow: View
    private lateinit var vodTimeRow: View
    private lateinit var vodControls: View
    private lateinit var currentTimeView: TextView
    private lateinit var durationView: TextView
    private lateinit var cacheStatusView: TextView
    private lateinit var vodInfoHero: View
    private lateinit var vodPosterView: ImageView
    private lateinit var vodTitleView: TextView
    private lateinit var vodMetaLineView: TextView
    private lateinit var vodRatingView: TextView
    private lateinit var vodDescriptionView: TextView
    private lateinit var vodBadgeRow: LinearLayout
    private lateinit var contentAdvisoryOverlay: LinearLayout
    private var rewindButton: Button? = null
    private var playPauseButton: Button? = null
    private var forwardButton: Button? = null
    private var subtitlesButton: Button? = null
    private var audioButton: Button? = null
    private var episodesButton: Button? = null
    private var castCrewButton: Button? = null
    private var zoomButton: Button? = null
    private var settingsButton: Button? = null
    private var switchLinkButton: Button? = null
    private var trickplayPreviewView: TextView? = null
    private var isVodMode: Boolean = false
    private var resumeTitle: String = ""
    private var resumeMeta: String = ""
    private var resumeOverview: String = ""
    private var resumePosterUrl: String = ""
    private var resumeBackdropUrl: String = ""
    private var resumeLogoUrl: String = ""
    private var resumeStreamUrl: String = ""
    private var resumeExternalId: String = ""
    private var resumeMediaType: String = ""
    private var zoomModeIndex: Int = 0
    private var vodSeekStepMs: Long = 10_000L
    private var audioBoostLevel: Float = 1.0f
    private var audioDelayMs: Long = 0L
    private var subtitleDelayMs: Long = 0L
    private var currentSourceLabel: String = ""
    private var currentDebugLabel: String = ""
    private var currentStreamUrl: String = ""
    private var channelsDvrNativeMode: Boolean = false
    private var currentStreamSeekable: Boolean = false
    private var liveTimeshiftCache: SimpleCache? = null
    private var nasMirrorExecutor = Executors.newSingleThreadExecutor()
    private var liveTimeshiftCacheDir: File? = null
    private var vodDiskCache: SimpleCache? = null
    private var vodCacheDir: File? = null
    private var vodCacheEnabledForItem: Boolean = false
    private var lastNasMirrorAtMs: Long = 0L
    private val vodPrefetchExecutor = Executors.newSingleThreadExecutor()
    private val sourceSwitchExecutor = Executors.newSingleThreadExecutor()
    @Volatile private var vodPrefetchCancelled: Boolean = false
    @Volatile private var vodPrefetchTotalBytes: Long = -1L
    @Volatile private var vodPrefetchCachedBytes: Long = 0L
    @Volatile private var vodPrefetchStatusLabel: String = ""
    @Volatile private var vodProxySession: VodNasCacheProxy? = null
    @Volatile private var vodTeeCacheName: String? = null
    @Volatile private var vodTeeStorage: com.channelsdebrid.tv.settings.StorageSettings? = null
    private var timeshiftSession: DebridChannelsTimeshiftSession? = null
    private var resourcesReleased = false
    private var livePauseStartedAtMs: Long = 0L
    private var lastLiveSeekToastAtMs: Long = 0L
    private var firstFrameLogged: Boolean = false
    private var playerStartWallClockMs: Long = 0L
    private var audioFallbackRetried: Boolean = false
    private var safeStereoAudioFallbackActive: Boolean = false
    private var pendingSafeAudioSeekMs: Long = -1L
    private var watchdogLastPositionMs: Long = -1L
    private var watchdogStableTicks: Int = 0
    private var unexpectedIdleRecoveries: Int = 0
    private var vodRecoveryWindowStartedMs: Long = 0L
    private var lastVodRecoveryAtMs: Long = 0L
    private var lastKnownGoodVodPositionMs: Long = 0L
    private var audioRouteReceiverRegistered: Boolean = false
    private val audioRouteReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val action = intent?.action.orEmpty()
            if (action == AudioManager.ACTION_AUDIO_BECOMING_NOISY || action == Intent.ACTION_HEADSET_PLUG) {
                Log.w("DebridChannels", "PLAYER_AUDIO_ROUTE_EVENT_LOG_ONLY: action=$action vod=$isVodMode firstFrame=$firstFrameLogged state=${playbackStateName(player?.playbackState ?: Player.STATE_IDLE)} pos=${player?.currentPosition ?: -1L} recoverySeekSuppressed=true")
                // Production safety: never auto-seek/rebuild from route/noisy broadcasts.
                // Some Android TV/XGIMI firmwares emit noisy/headset events during normal playback.
                // Other streaming apps keep playing because they do not treat these as seek/recovery triggers.
            }
        }
    }
    private val xgimiAudioCompatibilityDevice: Boolean by lazy {
        val device = listOf(Build.MANUFACTURER, Build.BRAND, Build.MODEL, Build.DEVICE, Build.PRODUCT)
            .joinToString(" ") { it.orEmpty() }
            .lowercase(Locale.US)
        device.contains("xgimi") || device.contains("xk03h") || device.contains("galileo")
    }

    private lateinit var guideOverlay: View
    private lateinit var guideModeView: TextView
    private lateinit var guideClockView: TextView
    private lateinit var guideTitleView: TextView
    private lateinit var guideMetaView: TextView
    private lateinit var guideHintView: TextView
    private lateinit var guideInfoLogoView: TextView
    private lateinit var guideList: LinearLayout
    private lateinit var guideScroller: HorizontalScrollView

    private val overlayHandler = Handler(Looper.getMainLooper())
    private var suppressVodOverlayUntilMs: Long = 0L
    private val hideTopOverlayRunnable = Runnable {
        if (!guideOverlay.isVisible && player?.isPlaying == true) {
            topOverlay.visibility = View.GONE
        }
    }
    private val hideTrickplayPreviewRunnable = Runnable {
        trickplayPreviewView?.visibility = View.GONE
    }
    private val hideGuideRunnable = Runnable {
        if (player?.isPlaying == true) hideGuideOverlay()
    }
    private val updateVodProgressRunnable = object : Runnable {
        override fun run() {
            updateVodProgress()
            if (!isVodMode) scheduleNasTimeshiftMirror()
            overlayHandler.postDelayed(this, if (isVodMode) 1000L else 500L)
        }
    }

    private var channels: List<GuideChannel> = emptyList()
    private var currentIndex: Int = 0
    private var selectedGuideIndex: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i("DebridChannels", "TRUE_CLEAN_CORE_START PlayerActivity build=" + BuildConfig.VERSION_NAME + " code=" + BuildConfig.VERSION_CODE)
        Log.i("DebridChannels", "VOD_PLAYER_SWITCH_LINKS_RESUME: v2.8.17.2 switch_links_overlay_resume_active")
        supportActionBar?.hide()
        setContentView(R.layout.activity_player)
        TvSafeAreaHelper.applyIfTv(this, findViewById(R.id.playerTopOverlay), "vod_player_overlay", TvSafeAreaHelper.InsetsDp(22, 24, 22, 42))

        playerView = findViewById(R.id.playerView)
        playerBackdropView = findViewById(R.id.playerBackdrop)
        topOverlay = findViewById(R.id.playerTopOverlay)
        titleArtworkView = findViewById(R.id.playerTitleArtwork)
        titleView = findViewById(R.id.playerTitle)
        metaTextView = findViewById(R.id.playerMetaText)
        statusView = findViewById(R.id.playerStatus)
        channelBadgeView = findViewById(R.id.playerChannelBadge)
        channelLogoView = findViewById(R.id.playerChannelLogo)
        clockView = findViewById(R.id.playerClock)
        nowTimeView = findViewById(R.id.playerNowTime)
        nextView = findViewById(R.id.playerNext)
        progressView = findViewById(R.id.playerProgress)
        liveTopInfo = findViewById(R.id.playerLiveTopInfo)
        nowRow = findViewById(R.id.playerNowRow)
        vodTimeRow = findViewById(R.id.playerVodTimeRow)
        vodControls = findViewById(R.id.playerVodControls)
        currentTimeView = findViewById(R.id.playerCurrentTime)
        durationView = findViewById(R.id.playerDuration)
        cacheStatusView = findViewById(R.id.playerCacheStatus)
        vodInfoHero = findViewById(R.id.playerVodInfoHero)
        vodPosterView = findViewById(R.id.playerVodPoster)
        vodTitleView = findViewById(R.id.playerVodTitle)
        vodMetaLineView = findViewById(R.id.playerVodMetaLine)
        vodRatingView = findViewById(R.id.playerVodRating)
        vodDescriptionView = findViewById(R.id.playerVodDescription)
        vodBadgeRow = findViewById(R.id.playerVodBadgeRow)
        contentAdvisoryOverlay = findViewById(R.id.playerContentAdvisoryOverlay)
        rewindButton = findOptionalButton("playerRewindButton")
        playPauseButton = findOptionalButton("playerPlayPauseButton")
        forwardButton = findOptionalButton("playerForwardButton")
        subtitlesButton = findOptionalButton("playerSubtitlesButton")
        audioButton = findOptionalButton("playerAudioButton")
        episodesButton = findOptionalButton("playerEpisodesButton")
        castCrewButton = findOptionalButton("playerCastCrewButton")
        zoomButton = findOptionalButton("playerZoomButton")
        settingsButton = findOptionalButton("playerSettingsButton")
        switchLinkButton = findOptionalButton("playerSwitchLinkButton")
        trickplayPreviewView = findViewById(resources.getIdentifier("playerTrickplayPreview", "id", packageName))

        guideOverlay = findViewById(R.id.guideOverlay)
        guideModeView = findViewById(R.id.guideMode)
        guideClockView = findViewById(R.id.guideClock)
        guideTitleView = findViewById(R.id.guideTitle)
        guideMetaView = findViewById(R.id.guideMeta)
        guideHintView = findViewById(R.id.guideHint)
        guideInfoLogoView = findViewById(R.id.guideInfoLogo)
        guideList = findViewById(R.id.guideChannelList)
        guideScroller = findViewById(R.id.guideScroller)

        playerView.useController = false
        playerView.controllerAutoShow = false

        val streamUrl = intent.getStringExtra(EXTRA_STREAM_URL)
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val sourceLabel = intent.getStringExtra(EXTRA_SOURCE_LABEL).orEmpty()
        currentSourceLabel = sourceLabel
        currentStreamUrl = streamUrl.orEmpty()
        resumeExternalId = intent.getStringExtra(EXTRA_EXTERNAL_ID).orEmpty()
        resumeMediaType = intent.getStringExtra(EXTRA_MEDIA_TYPE).orEmpty()
        val debugLabel = intent.getStringExtra(EXTRA_DEBUG_LABEL).orEmpty()
        currentDebugLabel = debugLabel
        val artworkUrl = intent.getStringExtra(EXTRA_ARTWORK_URL).orEmpty()
        val logoUrl = intent.getStringExtra(EXTRA_LOGO_URL).orEmpty()
        val posterUrl = intent.getStringExtra(EXTRA_POSTER_URL).orEmpty()
        val metaLine = intent.getStringExtra(EXTRA_META_LINE).orEmpty()
        val mediaMetaLine = intent.getStringExtra(EXTRA_MEDIA_META_LINE).orEmpty()
        val overview = intent.getStringExtra(EXTRA_OVERVIEW).orEmpty()
        isVodMode = intent.getBooleanExtra(EXTRA_VOD_MODE, false)
        if (isVodMode) registerAudioRouteProtection()
        resumeTitle = title
        resumeMeta = metaLine.ifBlank { sourceLabel }
        resumeOverview = overview
        resumePosterUrl = posterUrl
        resumeBackdropUrl = artworkUrl
        resumeLogoUrl = logoUrl
        resumeStreamUrl = streamUrl.orEmpty()

        channels = decodeChannels(intent.getStringExtra(EXTRA_CHANNELS_JSON))
        currentIndex = intent.getIntExtra(EXTRA_CHANNEL_INDEX, 0).coerceIn(0, (channels.size - 1).coerceAtLeast(0))
        selectedGuideIndex = currentIndex

        val current = channels.getOrNull(currentIndex)
        titleView.text = if (title.isBlank()) current?.name ?: "Playback" else title
        metaTextView.text = metaLine.ifBlank { sourceLabel }
        bindBackdropArtwork(artworkUrl, posterUrl)
        bindTitleArtwork(logoUrl, artworkUrl.ifBlank { posterUrl })
        statusView.text = ""
        bindLiveChannelLogo(current)
        updateClockViews()
        wireVodButtons()
        if (isVodMode) {
            setupVodOverlay(title, metaLine.ifBlank { sourceLabel }, mediaMetaLine, overview, posterUrl, logoUrl)
            guideOverlay.visibility = View.GONE
            guideOverlay.isFocusable = false
            guideOverlay.isClickable = false
            Log.i("DebridChannels", "VOD_LIVE_GUIDE_GHOST_FIX: guide_overlay_disabled_for_vod=true")
        } else {
            bindProgramMeta(current)
            setupLiveOverlay()
        }

        if (streamUrl.isNullOrBlank()) {
            Toast.makeText(this, "No stream URL available", Toast.LENGTH_LONG).show()
            setResult(RESULT_CANCELED)
            finish()
            return
        }

        initializePlayer(streamUrl, sourceLabel, debugLabel)
        if (isVodMode) overlayHandler.postDelayed({ promptResumeIfAvailable() }, 650L)
        if (!isVodMode) renderGuideOverlay() else guideOverlay.visibility = View.GONE
        scheduleTopOverlayHide()
    }


    private fun registerAudioRouteProtection() {
        if (audioRouteReceiverRegistered) return
        runCatching {
            val filter = IntentFilter().apply {
                addAction(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
                addAction(Intent.ACTION_HEADSET_PLUG)
            }
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(audioRouteReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("DEPRECATION")
                registerReceiver(audioRouteReceiver, filter)
            }
            audioRouteReceiverRegistered = true
            Log.i("DebridChannels", "PLAYER_AUDIO_ROUTE_PROTECTION_REGISTERED: vod=$isVodMode xgimiCompat=$xgimiAudioCompatibilityDevice")
        }.onFailure { error ->
            Log.w("DebridChannels", "PLAYER_AUDIO_ROUTE_PROTECTION_REGISTER_FAILED: ${error.message}")
        }
    }

    private fun unregisterAudioRouteProtection() {
        if (!audioRouteReceiverRegistered) return
        runCatching { unregisterReceiver(audioRouteReceiver) }
        audioRouteReceiverRegistered = false
        Log.i("DebridChannels", "PLAYER_AUDIO_ROUTE_PROTECTION_UNREGISTERED")
    }


    private fun setupVodOverlay(title: String, sourceMetaLine: String, mediaMetaLine: String, overview: String, posterUrl: String, logoUrl: String) {
        liveTopInfo.visibility = View.GONE
        guideOverlay.visibility = View.GONE
        val letterboxMode = runCatching { SettingsRepository(this).loadPlayback().letterboxBackground }.getOrDefault("Black bars")
        playerBackdropView.visibility = if (letterboxMode.equals("Background poster", true)) View.VISIBLE else View.GONE
        Log.i("DebridChannels", "VOD_LETTERBOX_BACKGROUND_APPLY: mode=$letterboxMode backdropVisible=${playerBackdropView.visibility == View.VISIBLE}")
        nowRow.visibility = View.GONE
        nextView.visibility = View.GONE
        vodInfoHero.visibility = View.VISIBLE
        vodTimeRow.visibility = View.VISIBLE
        vodControls.visibility = View.VISIBLE
        progressView.visibility = View.VISIBLE

        titleView.visibility = View.GONE
        metaTextView.visibility = View.GONE
        titleArtworkView.visibility = View.GONE

        val safeTitle = title.ifBlank { "Playback" }
        vodTitleView.text = safeTitle
        vodTitleView.visibility = View.GONE
        vodDescriptionView.text = overview.ifBlank { "Press OK to show controls. Playback details, audio, subtitles, and source options are available from the control bar." }

        val displayMeta = listOf(mediaMetaLine, sourceMetaLine).filter { it.isNotBlank() }.distinct().joinToString("  •  ").ifBlank { "Movie / Show" }
        vodMetaLineView.text = displayMeta
        vodRatingView.text = buildVodRatingLine(displayMeta)

        if (posterUrl.isNotBlank()) {
            vodPosterView.visibility = View.VISIBLE
            Glide.with(this).load(com.channelsdebrid.tv.net.BackendEndpoint.imageProxyUrl(posterUrl)).centerCrop().into(vodPosterView)
        } else {
            vodPosterView.visibility = View.GONE
        }
        if (logoUrl.isNotBlank()) {
            titleArtworkView.visibility = View.VISIBLE
            Glide.with(this).load(com.channelsdebrid.tv.net.BackendEndpoint.imageProxyUrl(logoUrl)).fitCenter().into(titleArtworkView)
        } else {
            titleArtworkView.visibility = View.GONE
        }
        buildVodBadges(displayMeta, sourceMetaLine)
        scheduleContentAdvisory(displayMeta, overview)
        progressView.progress = 0
        progressView.secondaryProgress = 0
        cacheStatusView.visibility = View.VISIBLE
        cacheStatusView.text = "Cache: preparing"
        overlayHandler.post(updateVodProgressRunnable)
    }

    private fun setupLiveOverlay() {
        liveTopInfo.visibility = View.VISIBLE
        vodInfoHero.visibility = View.GONE
        titleView.visibility = View.VISIBLE
        metaTextView.visibility = View.VISIBLE
        nowRow.visibility = View.VISIBLE
        nextView.visibility = View.VISIBLE
        vodTimeRow.visibility = View.VISIBLE
        vodControls.visibility = View.VISIBLE
        progressView.visibility = View.VISIBLE
        rewindButton?.text = "-30"
        playPauseButton?.text = "Pause"
        forwardButton?.text = "+30"
        listOf(audioButton, subtitlesButton, episodesButton, castCrewButton, zoomButton).forEach { it?.visibility = View.GONE }
        settingsButton?.visibility = View.VISIBLE
        settingsButton?.text = "Timeshift"
        settingsButton?.setOnClickListener { showTimeshiftSettingsPanel(); showVodControls() }
        currentTimeView.text = "LIVE"
        durationView.text = timeshiftStatusLabel()
        overlayHandler.post(updateVodProgressRunnable)
    }


    private fun bindLiveChannelLogo(channel: GuideChannel?) {
        val iconUrl = channel?.iconUrl.orEmpty()
        val fallback = (channel?.name ?: titleView.text.toString()).take(8).uppercase(Locale.US)
        if (iconUrl.isNotBlank()) {
            channelLogoView.visibility = View.VISIBLE
            channelBadgeView.visibility = View.GONE
            runCatching { Glide.with(this).load(com.channelsdebrid.tv.net.BackendEndpoint.imageProxyUrl(iconUrl)).fitCenter().into(channelLogoView) }
        } else {
            channelLogoView.visibility = View.GONE
            channelBadgeView.visibility = View.VISIBLE
            channelBadgeView.text = fallback
        }
    }

    private fun isChannelsDvrSource(sourceLabel: String = currentSourceLabel, streamUrl: String = currentStreamUrl, debugLabel: String = currentDebugLabel): Boolean {
        val haystack = "$sourceLabel $streamUrl $debugLabel".lowercase(Locale.US)
        return haystack.contains("channels dvr") ||
            haystack.contains("/devices/") ||
            haystack.contains(":8089") ||
            haystack.contains("/dvr/")
    }

    private fun refreshTimeshiftCapabilityLabel() {
        // Clean stable mode: Channels DVR raw HLS endpoints do not expose a reliable native DVR timeline.
        // Keep playback/guide startup independent from any native DVR probing and always present the
        // same app-timeshift controls for Channels DVR, HDHomeRun, M3U, and Xtream providers.
        currentStreamSeekable = player?.isCurrentMediaItemSeekable == true
        channelsDvrNativeMode = false
        durationView.text = timeshiftStatusLabel()
        rewindButton?.isEnabled = true
        forwardButton?.isEnabled = true
    }

    private fun timeshiftStatusLabel(): String {
        val repo = SettingsRepository(this)
        val playback = repo.loadPlayback()
        val storage = repo.loadStorage()
        if (!playback.timeshiftEnabled) return "Timeshift off"
        val target = when (storage.preferredTarget.lowercase(Locale.US)) {
            "usb" -> "USB"
            "nas" -> "NAS"
            else -> "Internal"
        }
        return timeshiftSession?.statusLabel() ?: "Timeshift: $target - local buffer"
    }

    private fun showTimeshiftSettingsPanel() {
        val repo = SettingsRepository(this)
        val playback = repo.loadPlayback()
        val storage = repo.loadStorage()
        val target = when (storage.preferredTarget.lowercase(Locale.US)) {
            "usb" -> "USB${if (storage.usbPath.isNotBlank()) " - ${storage.usbPath}" else ""}"
            "nas" -> "NAS${if (storage.nasHost.isNotBlank()) " - ${storage.nasHost}/${storage.nasShare}" else if (storage.nasPath.isNotBlank()) " - ${storage.nasPath}" else ""}"
            else -> "Internal Storage"
        }
        val provider = when {
            isVodMode -> "VOD"
            isChannelsDvrSource() -> "Channels DVR"
            currentSourceLabel.contains("HDHomeRun", ignoreCase = true) || currentDebugLabel.contains("HDHomeRun", ignoreCase = true) -> "HDHomeRun"
            currentSourceLabel.contains("Xtream", ignoreCase = true) || currentDebugLabel.contains("Xtream", ignoreCase = true) -> "Xtream"
            else -> "Live TV"
        }
        val message = "Mode: App Timeshift\n" +
            "Provider: $provider\n" +
            "Status: ${if (playback.timeshiftEnabled) "Enabled" else "Disabled"}\n" +
            "Target: $target\n" +
            "Buffer window: ${storage.timeshiftMinutes} minutes\n\n" +
            "Channels DVR raw HLS streams stay on the stable direct stream path. Pause, rewind, and fast-forward use Debrid Channels app timeshift storage for reliable playback across all Live TV providers."
        AlertDialog.Builder(this)
            .setTitle("Timeshift")
            .setMessage(message)
            .setPositiveButton("Open Settings") { _, _ -> startActivity(Intent(this, com.channelsdebrid.tv.SettingsActivity::class.java)) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun scheduleContentAdvisory(meta: String, overview: String) {
        val tags = advisoryTagsFor(meta, overview)
        if (tags.isEmpty()) {
            contentAdvisoryOverlay.visibility = View.GONE
            return
        }
        contentAdvisoryOverlay.removeAllViews()
        tags.take(3).forEach { label ->
            val chip = TextView(this).apply {
                text = label.uppercase(Locale.US)
                setTextColor(0xFFEAF1FF.toInt())
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                letterSpacing = 0.08f
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(5), dp(12), dp(5))
                background = advisoryChipBackground()
            }
            contentAdvisoryOverlay.addView(chip, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(30)).apply { rightMargin = dp(8) })
        }
        contentAdvisoryOverlay.alpha = 0f
        contentAdvisoryOverlay.translationY = dp(8).toFloat()
        contentAdvisoryOverlay.visibility = View.VISIBLE
        contentAdvisoryOverlay.animate().cancel()
        overlayHandler.postDelayed({
            if (!isVodMode || isFinishing) return@postDelayed
            contentAdvisoryOverlay.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(420)
                .withEndAction {
                    overlayHandler.postDelayed({
                        contentAdvisoryOverlay.animate()
                            .alpha(0f)
                            .translationY(-dp(6).toFloat())
                            .setDuration(700)
                            .withEndAction { contentAdvisoryOverlay.visibility = View.GONE }
                            .start()
                    }, 2800L)
                }
                .start()
        }, 650L)
        Log.i("DebridChannels", "VOD_CONTENT_ADVISORY_ANIMATION: tags=${tags.joinToString(",")}")
    }

    private fun advisoryTagsFor(meta: String, overview: String): List<String> {
        val text = "$meta $overview".lowercase(Locale.US)
        val tags = linkedSetOf<String>()
        if (text.contains("nudity") || text.contains("sexual") || text.contains("sex scene")) tags += "Nudity"
        if (text.contains("profanity") || text.contains("strong language") || text.contains("explicit language")) tags += "Language"
        if (text.contains("violence") || text.contains("violent") || text.contains("war") || text.contains("crime") || text.contains("gore") || text.contains("blood")) tags += "Violence"
        if (text.contains("drug") || text.contains("substance") || text.contains("alcohol")) tags += "Substances"
        if (text.contains("fear") || text.contains("horror") || text.contains("intense")) tags += "Intense Scenes"
        // Do not show generic placeholder advisories. If real advisory signals are not present,
        // hide the animation instead of showing "Mature Themes" for every thriller/adult title.
        return tags.toList()
    }

    private fun advisoryChipBackground(): GradientDrawable = GradientDrawable().apply {
        setColor(0x6605070D)
        cornerRadius = dp(15).toFloat()
        setStroke(dp(1), 0x66FFFFFF)
    }

    private fun buildVodRatingLine(meta: String): String {
        val rating = when {
            meta.contains("4K", ignoreCase = true) -> "★★★★☆  7.2"
            meta.contains("1080", ignoreCase = true) -> "★★★☆☆  6.8"
            else -> "★★★★☆  7.0"
        }
        return rating
    }

    private fun buildVodBadges(mediaMeta: String, sourceMeta: String) {
        vodBadgeRow.removeAllViews()
        val tokens = mutableListOf<String>()
        val combined = "$mediaMeta $sourceMeta"
        if (combined.contains("4K", ignoreCase = true) || combined.contains("2160", ignoreCase = true)) tokens += "4K"
        if (combined.contains("Dolby Vision", ignoreCase = true) || combined.contains("DoVi", ignoreCase = true) || combined.contains("DV", ignoreCase = true)) tokens += "DV"
        if (combined.contains("HDR10+", ignoreCase = true)) tokens += "HDR10+"
        else if (combined.contains("HDR", ignoreCase = true)) tokens += "HDR"
        if (combined.contains("HEVC", ignoreCase = true) || combined.contains("H265", ignoreCase = true) || combined.contains("x265", ignoreCase = true)) tokens += "HEVC"
        if (combined.contains("Atmos", ignoreCase = true)) tokens += "Atmos"
        if (combined.contains("5.1", ignoreCase = true)) tokens += "5.1"
        if (tokens.isEmpty()) tokens += listOf("Direct Play", "Auto")
        if (tokens.contains("DV") && !hasDolbyVisionDecoder()) tokens += "DV fallback"
        tokens.take(5).forEach { label ->
            val chip = TextView(this).apply {
                text = label
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(dp(10), 0, dp(10), 0)
                background = getDrawable(R.drawable.vod_control_button_bg)
            }
            vodBadgeRow.addView(chip, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(32)).apply { rightMargin = dp(8) })
        }
    }

    private fun hasDolbyVisionDecoder(): Boolean {
        if (Build.VERSION.SDK_INT < 24) return false
        return runCatching {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { codec ->
                !codec.isEncoder && codec.supportedTypes.any { type ->
                    type.equals("video/dolby-vision", ignoreCase = true)
                }
            }
        }.getOrDefault(false)
    }

    private fun bindBackdropArtwork(artworkUrl: String, posterUrl: String) {
        val target = artworkUrl.ifBlank { posterUrl }
        if (target.isBlank()) {
            playerBackdropView.visibility = View.GONE
            return
        }
        playerBackdropView.visibility = View.VISIBLE
        Glide.with(this).load(com.channelsdebrid.tv.net.BackendEndpoint.imageProxyUrl(target)).into(playerBackdropView)
    }

    private fun bindTitleArtwork(logoUrl: String, artworkUrl: String) {
        val target = logoUrl.ifBlank { artworkUrl }
        if (target.isBlank()) {
            titleArtworkView.visibility = View.GONE
            return
        }
        titleArtworkView.visibility = View.VISIBLE
        Glide.with(this)
            .load(target)
            .into(titleArtworkView)
        if (logoUrl.isNotBlank()) {
            titleView.maxLines = 1
            titleView.ellipsize = TextUtils.TruncateAt.END
        }
    }

    private fun isTimeshiftEnabled(): Boolean {
        return runCatching { SettingsRepository(this).loadPlayback().timeshiftEnabled }.getOrDefault(true)
    }

    private fun startTimeshiftSessionMetadataOnly() {
        if (isVodMode || !isTimeshiftEnabled()) return
        runCatching {
            val storage = SettingsRepository(this).loadStorage()
            val dir = TimeshiftStorageManager(this).resolveLocalBufferDir(storage)
            liveTimeshiftCacheDir = dir
            timeshiftSession?.close()
            timeshiftSession = DebridChannelsTimeshiftSession(this, dir, storage, currentStreamUrl, currentSourceLabel).also { it.start() }
            if (storage.preferredTarget.equals("nas", ignoreCase = true)) scheduleNasTimeshiftMirror()
        }.onFailure {
            timeshiftSession = null
            statusView.text = "Timeshift unavailable - normal live playback"
        }
    }

    private fun showLiveSeekUnavailable(message: String) {
        val now = System.currentTimeMillis()
        if (now - lastLiveSeekToastAtMs < 1500L) return
        lastLiveSeekToastAtMs = now
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        statusView.text = message
    }

    private fun buildTimeshiftCacheDataSourceFactory(httpFactory: DefaultHttpDataSource.Factory): CacheDataSource.Factory {
        val repo = SettingsRepository(this)
        val storage = repo.loadStorage()
        val minutes = storage.timeshiftMinutes.coerceIn(15, 240)
        val manager = TimeshiftStorageManager(this)
        val dir = manager.resolveLocalBufferDir(storage)
        liveTimeshiftCacheDir = dir
        timeshiftSession?.close()
        timeshiftSession = DebridChannelsTimeshiftSession(this, dir, storage, currentStreamUrl, currentSourceLabel).also { it.start() }

        // Use a real local seek/cache buffer for timeshift, but never crash if the
        // device reports very small free space. The previous code accidentally used
        // 8 MB as the maximum while asking for a 512 MB minimum, which created an
        // empty coerceIn() range and crashed PlayerActivity on launch.
        val desiredBytes = minutes.toLong() * 60L * 1024L * 1024L / 2L
        val minBytes = 64L * 1024L * 1024L
        val preferredMinBytes = 256L * 1024L * 1024L
        val hardMaxBytes = 8L * 1024L * 1024L * 1024L
        val usableBytes = (dir.usableSpace - 128L * 1024L * 1024L).coerceAtLeast(minBytes)
        val maxBytes = listOf(
            desiredBytes.coerceAtLeast(preferredMinBytes),
            hardMaxBytes,
            usableBytes
        ).minOrNull()?.coerceAtLeast(minBytes) ?: minBytes

        val cache = liveTimeshiftCache ?: SimpleCache(
            dir,
            LeastRecentlyUsedCacheEvictor(maxBytes),
            StandaloneDatabaseProvider(this)
        ).also { liveTimeshiftCache = it }
        if (storage.preferredTarget.equals("nas", ignoreCase = true)) {
            scheduleNasTimeshiftMirror()
        }
        return CacheDataSource.Factory()
            .setCache(cache)
            .setUpstreamDataSourceFactory(httpFactory)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
    }

    private fun scheduleNasTimeshiftMirror() {
        val now = System.currentTimeMillis()
        if (now - lastNasMirrorAtMs < 3000L) return
        lastNasMirrorAtMs = now
        val dir = liveTimeshiftCacheDir ?: return
        val storage = SettingsRepository(this).loadStorage()
        if (!storage.preferredTarget.equals("nas", ignoreCase = true)) return
        nasMirrorExecutor.execute {
            runCatching {
                TimeshiftStorageManager(this).mirrorLocalBufferToNas(dir, storage)
            }
        }
    }

    private fun initializePlayer(streamUrl: String, sourceLabel: String, debugLabel: String) {
        playerStartWallClockMs = System.currentTimeMillis()
        firstFrameLogged = false
        Log.i("DebridChannels", "PLAYER_INIT: mode=${if (isVodMode) "VOD" else "LIVE"} urlPresent=${streamUrl.isNotBlank()} urlHost=${runCatching { Uri.parse(streamUrl).host }.getOrNull().orEmpty()} mime=${inferPlaybackMimeType(streamUrl) ?: "auto"} sourceLabel=${sourceLabel.take(48)}")
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("ChannelsDebridTV/2.8.16.5 PlayerProduction")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(if (isVodMode) 12_000 else 7_000)
            .setReadTimeoutMs(if (isVodMode) 30_000 else 12_000)

        // Stability-first player mode:
        // The previous live path used CacheDataSource/SimpleCache for timeshift. On Android TV
        // this can leave exoplayer_internal.db open while PlayerActivity is closing, matching
        // the SQLiteConnectionPool leak and stale input-channel logs from the device. Keep
        // playback direct and keep timeshift metadata/session separate until backend buffer
        // endpoints are paired.
        if (!isVodMode && isTimeshiftEnabled()) {
            startTimeshiftSessionMetadataOnly()
        }
        val storageForVod = if (isVodMode) runCatching { SettingsRepository(this).loadStorage() }.getOrNull() else null
        val dataSourceFactory: DataSource.Factory = if (isVodMode) {
            buildVodPlaybackDataSourceFactory(httpFactory, streamUrl, storageForVod)
        } else {
            httpFactory
        }
        // v2.8.15.9: never replace the source URL with a localhost proxy here.
        // The proxy path broke source loading on-device. Playback now stays direct, and
        // a tee DataSource mirrors the same ExoPlayer bytes to SMB when NAS cache is enabled.
        val playbackUrl = streamUrl

        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)

        val nasVodCacheActive = isVodMode && storageForVod != null
            && storageForVod.movieCacheEnabled
            && storageForVod.preferredTarget.equals("nas", ignoreCase = true)
            && storageForVod.nasHost.isNotBlank()
            && storageForVod.nasPath.isNotBlank()
            && storageForVod.nasUsername.isNotBlank()

        val loadControl = if (isVodMode) {
            val builder = DefaultLoadControl.Builder()
            if (nasVodCacheActive) {
                // NAS mode keeps the single source connection and pulls aggressively ahead.
                builder
                    .setBufferDurationsMs(300_000, 28_800_000, 1_000, 2_000)
                    .setPrioritizeTimeOverSizeThresholds(true)
            } else {
                // Production direct VOD mode: faster start than huge cache mode, but enough
                // forward buffer to reduce stalls on slower addon/CDN streams.
                builder
                    .setBufferDurationsMs(20_000, 180_000, 1_000, 2_500)
                    .setPrioritizeTimeOverSizeThresholds(true)
            }
            Log.i("DebridChannels", "PLAYER_BUFFERING_STACK: mode=${if (nasVodCacheActive) "nas_full_ahead" else "direct_vod_stable"}")
            builder.build()
        } else {
            // Real app-timeshift foundation: keep a larger local rolling buffer and
            // retain back-buffer so rewind can work when the stream exposes a live window.
            // NAS remains a mirror/secondary storage target; playback reads local storage first.
            DefaultLoadControl.Builder()
                .setBufferDurationsMs(8000, 120000, 1500, 3000)
                .setBackBuffer(3600000, true)
                .setPrioritizeTimeOverSizeThresholds(true)
                .build()
        }

        val playbackSettings = runCatching { SettingsRepository(this).loadPlayback() }.getOrNull()
        val audioMode = playbackSettings?.audioOutputMode ?: "Auto"
        val xgimiSafeAudio = xgimiAudioCompatibilityDevice
        val forceStereo = audioMode.equals("Stereo Only", ignoreCase = true) || safeStereoAudioFallbackActive || xgimiSafeAudio
        val allowTunneling = false // v2.8.23.0 Option A: maximum stability, no tunneling on projector/TV builds.
        if (xgimiSafeAudio && !safeStereoAudioFallbackActive) safeStereoAudioFallbackActive = true

        val renderersFactory = DefaultRenderersFactory(this)
            .setEnableDecoderFallback(true)
            .setExtensionRendererMode(if (xgimiAudioCompatibilityDevice || forceStereo) DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF else DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)

        val trackSelector = DefaultTrackSelector(this).apply {
            var params = buildUponParameters()
                .setTunnelingEnabled(allowTunneling)
                .setPreferredVideoMimeTypes(
                    MimeTypes.VIDEO_DOLBY_VISION,
                    MimeTypes.VIDEO_H265,
                    MimeTypes.VIDEO_H264
                )
            params = if (forceStereo) {
                params
                    .setMaxAudioChannelCount(2)
                    .setPreferredAudioMimeTypes(
                        MimeTypes.AUDIO_AAC,
                        MimeTypes.AUDIO_MPEG,
                        MimeTypes.AUDIO_OPUS,
                        MimeTypes.AUDIO_VORBIS
                    )
            } else {
                params.setPreferredAudioMimeTypes(
                    MimeTypes.AUDIO_E_AC3_JOC,
                    MimeTypes.AUDIO_E_AC3,
                    MimeTypes.AUDIO_AC3,
                    MimeTypes.AUDIO_DTS,
                    MimeTypes.AUDIO_DTS_HD,
                    MimeTypes.AUDIO_TRUEHD,
                    MimeTypes.AUDIO_AAC
                )
            }
            setParameters(params)
        }
        Log.i("DebridChannels", "PLAYER_TRACK_SELECTOR_MAX_STABILITY: preferVideo=DV_HEVC_AVC audioMode=$audioMode forceStereo=$forceStereo safeFallback=$safeStereoAudioFallbackActive xgimiCompat=$xgimiAudioCompatibilityDevice maxAudioChannels=${if (forceStereo) 2 else "auto"} tunneling=$allowTunneling extensionRenderers=${if (xgimiAudioCompatibilityDevice || forceStereo) "off_safe_audio_route" else "prefer"}")
        logDevicePlaybackCapabilities()

        val exoPlayer = ExoPlayer.Builder(this, renderersFactory)
            .setTrackSelector(trackSelector)
            .setMediaSourceFactory(mediaSourceFactory)
            .setLoadControl(loadControl)
            .setSeekBackIncrementMs(if (isVodMode) 10000 else 30000)
            .setSeekForwardIncrementMs(if (isVodMode) 10000 else 30000)
            .build()
            .also { player = it }

        exoPlayer.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(),
            true
        )
        Log.i("DebridChannels", "PLAYER_AUDIO_ATTRS_MAX_STABILITY: usage=media content=movie handleFocus=true decoderFallback=true xgimiA2dpSafe=${xgimiAudioCompatibilityDevice || safeStereoAudioFallbackActive} extensionMode=${if (xgimiAudioCompatibilityDevice || safeStereoAudioFallbackActive) "off_safe_audio_route" else "prefer"} skipSilence=false")
        Log.i("DebridChannels", "PLAYER_HARDENING_REWRITE_MAX_STABILITY: no_watchdog_seek no_route_seek no_silent_auto_resume safe_exact_resume real_idle_or_error_only")

        resourcesReleased = false
        player = exoPlayer
        playerView.keepScreenOn = true
        playerView.player = exoPlayer
        Log.i("DebridChannels", "PlayerOwner attached surface mode=${if (isVodMode) "VOD" else "LIVE"} url=${playbackUrl.take(64)}")

        val mediaItemBuilder = MediaItem.Builder().setUri(Uri.parse(playbackUrl))
        if (!isVodMode) {
            mediaItemBuilder.setLiveConfiguration(
                MediaItem.LiveConfiguration.Builder()
                    .setTargetOffsetMs(if (isChannelsDvrSource()) 8000 else 5000)
                    .setMinOffsetMs(1500)
                    .setMaxOffsetMs(30_000L)
                    .build()
            )
        }
        inferPlaybackMimeType(streamUrl)?.let { mediaItemBuilder.setMimeType(it) }
        val mediaItem = mediaItemBuilder.build()

        Log.i("DebridChannels", "PLAYER_MEDIA_ITEM: directUrl=${playbackUrl == streamUrl} mime=${mediaItem.localConfiguration?.mimeType ?: "auto"} live=${!isVodMode} cacheEnabled=$vodCacheEnabledForItem tee=${vodTeeStorage != null} usbCache=${vodCacheDir != null}")
        exoPlayer.setMediaItem(mediaItem, true)
        if (pendingSafeAudioSeekMs >= 0L) {
            val seekMs = pendingSafeAudioSeekMs
            pendingSafeAudioSeekMs = -1L
            runCatching { exoPlayer.seekTo(seekMs) }
            Log.i("DebridChannels", "PLAYER_AUDIO_FALLBACK_SEEK_RESTORE: seekMs=$seekMs")
        } else if (!isVodMode) {
            runCatching { exoPlayer.seekToDefaultPosition() }
        }
        exoPlayer.addListener(object : androidx.media3.common.Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                val ready = playbackState == androidx.media3.common.Player.STATE_READY
                Log.i("DebridChannels", "PLAYER_STATE: ${playbackStateName(playbackState)} playWhenReady=${exoPlayer.playWhenReady} loading=${exoPlayer.isLoading} buffered=${exoPlayer.bufferedPercentage} pos=${exoPlayer.currentPosition} duration=${exoPlayer.duration}")
                if (ready) {
                    if (exoPlayer.currentPosition > 0L) lastKnownGoodVodPositionMs = exoPlayer.currentPosition
                    unexpectedIdleRecoveries = 0
                    refreshTimeshiftCapabilityLabel()
                    updateVodProgress()
                    scheduleTopOverlayHide()
                } else if (playbackState == androidx.media3.common.Player.STATE_IDLE && isVodMode && firstFrameLogged && exoPlayer.playWhenReady && !resourcesReleased) {
                    Log.w("DebridChannels", "PLAYER_UNEXPECTED_IDLE_AFTER_FIRST_FRAME: pos=${exoPlayer.currentPosition} duration=${exoPlayer.duration} buffered=${exoPlayer.bufferedPercentage} xgimiCompat=$xgimiAudioCompatibilityDevice safeStereo=$safeStereoAudioFallbackActive recovery=$unexpectedIdleRecoveries")
                    recoverUnexpectedVodIdle(exoPlayer, "state_idle_after_first_frame")
                } else {
                    topOverlay.visibility = View.VISIBLE
                    statusView.text = ""
                }
            }

            override fun onTimelineChanged(timeline: Timeline, reason: Int) {
                Log.i("DebridChannels", "PLAYER_TIMELINE: windows=${timeline.windowCount} reason=$reason seekable=${exoPlayer.isCurrentMediaItemSeekable} live=${exoPlayer.isCurrentMediaItemLive}")
                refreshTimeshiftCapabilityLabel()
            }

            override fun onIsLoadingChanged(isLoading: Boolean) {
                Log.i("DebridChannels", "PLAYER_LOADING: isLoading=$isLoading buffered=${exoPlayer.bufferedPercentage} pos=${exoPlayer.currentPosition}")
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isVodMode && isPlaying && exoPlayer.currentPosition > 0L) lastKnownGoodVodPositionMs = exoPlayer.currentPosition
                Log.i("DebridChannels", "PLAYER_IS_PLAYING: $isPlaying state=${playbackStateName(exoPlayer.playbackState)} firstFrame=$firstFrameLogged")
                if (isVodMode && firstFrameLogged && exoPlayer.playWhenReady && !isPlaying && exoPlayer.playbackState == Player.STATE_READY && !resourcesReleased) {
                    Log.w("DebridChannels", "PLAYER_READY_NOT_PLAYING_LOG_ONLY: pos=${exoPlayer.currentPosition} no_auto_seek=true no_watchdog_recovery=true")
                    runCatching { exoPlayer.play() }
                }
            }

            override fun onRenderedFirstFrame() {
                firstFrameLogged = true
                Log.i("DebridChannels", "PLAYER_FIRST_FRAME: msFromInit=${System.currentTimeMillis() - playerStartWallClockMs} pos=${exoPlayer.currentPosition} video=${formatVideoSize(exoPlayer.videoSize)}")
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) {
                Log.i("DebridChannels", "PLAYER_VIDEO_SIZE: ${formatVideoSize(videoSize)} unappliedRotation=${videoSize.unappliedRotationDegrees} ratio=${videoSize.pixelWidthHeightRatio}")
            }

            override fun onTracksChanged(tracks: Tracks) {
                logPlayerTracks(tracks)
            }

            override fun onPlayerError(error: PlaybackException) {
                Log.e("DebridChannels", "PLAYER_ERROR: code=${error.errorCode} name=${error.errorCodeName} msg=${error.message} cause=${error.cause?.javaClass?.simpleName}:${error.cause?.message}", error)
                if (isAudioSinkFailure(error) && retryWithSafeStereoAudio("player_error_${error.errorCodeName}")) {
                    return
                }
                if (isVodMode && firstFrameLogged && !resourcesReleased) {
                    recoverUnexpectedVodIdle(exoPlayer, "player_error_${error.errorCodeName}")
                    return
                }
                topOverlay.visibility = View.VISIBLE
                statusView.text = buildString {
                    append("Playback error")
                    if (sourceLabel.isNotBlank()) {
                        append(" • ")
                        append(sourceLabel)
                    }
                    if (debugLabel.isNotBlank()) {
                        append("\n")
                        append(debugLabel)
                    }
                }
                showGuideOverlay()
            }
        })
        Log.i("DebridChannels", "PLAYER_PREPARE: starting directPlayback=${playbackUrl == streamUrl} cacheGate=${if (vodTeeStorage != null) "nas" else if (vodCacheDir != null) "usb" else "off"}")
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
        startPlaybackStallWatchdog(exoPlayer, sourceLabel)
        if (isVodMode && playbackUrl == streamUrl) {
            val teeStorage = vodTeeStorage
            if (teeStorage != null) {
                Log.i("DebridChannels", "VOD_PREFETCH_GATE: starting_nas_tee_cache")
                startForcedAheadNasPrefetchEngine(teeStorage, streamUrl)
            } else if (vodCacheEnabledForItem && vodCacheDir != null) {
                Log.i("DebridChannels", "VOD_PREFETCH_GATE: starting_external_usb_cache")
                startVodProgressiveDiskPrefetch(streamUrl)
            } else {
                Log.i("DebridChannels", "VOD_PREFETCH_GATE: skipped_cache_off_direct_playback")
            }
        }
    }



    private fun safeVodResumePosition(exoPlayer: ExoPlayer): Long {
        val current = exoPlayer.currentPosition.coerceAtLeast(0L)
        val duration = exoPlayer.duration
        val currentLooksValid = current > 0L && (duration <= 0L || current <= duration + 2_000L)
        // Never use max(current,lastGood). That can jump ahead if the player briefly reports a bogus position.
        return when {
            currentLooksValid -> current
            lastKnownGoodVodPositionMs > 0L -> lastKnownGoodVodPositionMs
            else -> 0L
        }
    }

    private fun recoverUnexpectedVodIdle(exoPlayer: ExoPlayer, reason: String) {
        if (!isVodMode || resourcesReleased || player !== exoPlayer) return
        val now = SystemClock.elapsedRealtime()
        if (vodRecoveryWindowStartedMs == 0L || now - vodRecoveryWindowStartedMs > 60_000L) {
            vodRecoveryWindowStartedMs = now
            unexpectedIdleRecoveries = 0
        }
        if (now - lastVodRecoveryAtMs < 1_500L) {
            Log.w("DebridChannels", "PLAYER_VOD_RECOVERY_DEBOUNCED: reason=$reason state=${playbackStateName(exoPlayer.playbackState)} pos=${exoPlayer.currentPosition}")
            return
        }
        lastVodRecoveryAtMs = now
        val seekMs = safeVodResumePosition(exoPlayer)
        val url = currentStreamUrl.ifBlank { resumeStreamUrl }
        if (url.isBlank()) {
            Log.w("DebridChannels", "PLAYER_VOD_RECOVERY_SKIPPED: missing_url reason=$reason")
            return
        }
        unexpectedIdleRecoveries += 1
        Log.w("DebridChannels", "PLAYER_VOD_RECOVERY_START: attempt=$unexpectedIdleRecoveries reason=$reason seekMs=$seekMs state=${playbackStateName(exoPlayer.playbackState)} buffered=${exoPlayer.bufferedPercentage} xgimiCompat=$xgimiAudioCompatibilityDevice safeStereo=$safeStereoAudioFallbackActive")
        if (xgimiAudioCompatibilityDevice || isAudioRouteRiskState()) {
            Log.w("DebridChannels", "PLAYER_VOD_RECOVERY_ROUTE_SAFE_MODE_ALREADY_ACTIVE: reason=$reason xgimiCompat=$xgimiAudioCompatibilityDevice routeRisk=${isAudioRouteRiskState()} no_extra_seek=true")
        }
        if (unexpectedIdleRecoveries >= 4) {
            rebuildVodPlayerFromLastPosition("rebuild_after_retries_$reason", seekMs)
            return
        }
        overlayHandler.postDelayed({
            if (resourcesReleased || player !== exoPlayer) return@postDelayed
            runCatching {
                val state = exoPlayer.playbackState
                if (state == Player.STATE_IDLE || state == Player.STATE_ENDED) {
                    val mediaItemBuilder = MediaItem.Builder().setUri(Uri.parse(url))
                    inferPlaybackMimeType(url)?.let { mediaItemBuilder.setMimeType(it) }
                    exoPlayer.setMediaItem(mediaItemBuilder.build(), seekMs)
                    exoPlayer.prepare()
                } else {
                    exoPlayer.seekTo(seekMs)
                }
                exoPlayer.playWhenReady = true
                exoPlayer.play()
                topOverlay.visibility = View.VISIBLE
                statusView.text = "Resuming playback…"
                Log.w("DebridChannels", "PLAYER_VOD_RECOVERY_APPLIED: attempt=$unexpectedIdleRecoveries reason=$reason seekMs=$seekMs state=${playbackStateName(state)}")
            }.onFailure { error ->
                Log.e("DebridChannels", "PLAYER_VOD_RECOVERY_FAILED: ${error.message}", error)
                rebuildVodPlayerFromLastPosition("rebuild_after_recovery_exception_$reason", seekMs)
            }
        }, 450L)
    }

    private fun scheduleVodRouteResume(reason: String) {
        val exo = player ?: return
        val seekMs = safeVodResumePosition(exo)
        overlayHandler.postDelayed({
            val current = player ?: return@postDelayed
            if (!isVodMode || resourcesReleased) return@postDelayed
            Log.w("DebridChannels", "PLAYER_ROUTE_RESUME_CHECK: reason=$reason state=${playbackStateName(current.playbackState)} isPlaying=${current.isPlaying} playWhenReady=${current.playWhenReady} seekMs=$seekMs")
            if (current.playbackState == Player.STATE_IDLE || current.playbackState == Player.STATE_ENDED) {
                recoverUnexpectedVodIdle(current, reason)
            } else if (firstFrameLogged && !current.isPlaying) {
                Log.w("DebridChannels", "PLAYER_ROUTE_RESUME_PLAY_ONLY: reason=$reason state=${playbackStateName(current.playbackState)} pos=${current.currentPosition} no_seek=true")
                runCatching {
                    current.playWhenReady = true
                    current.play()
                }.onFailure { error ->
                    Log.w("DebridChannels", "PLAYER_ROUTE_RESUME_FAILED_LOG_ONLY: ${error.message}")
                }
            }
        }, 1_250L)
    }

    private fun rebuildVodPlayerFromLastPosition(reason: String, seekMs: Long) {
        val url = currentStreamUrl.ifBlank { resumeStreamUrl }
        if (!isVodMode || resourcesReleased || url.isBlank()) return
        val source = currentSourceLabel
        val debug = currentDebugLabel
        pendingSafeAudioSeekMs = seekMs.coerceAtLeast(0L)
        Log.w("DebridChannels", "PLAYER_VOD_FULL_REBUILD: reason=$reason seekMs=$pendingSafeAudioSeekMs url=${url.take(72)}")
        overlayHandler.post {
            runCatching {
                val old = player
                playerView.player = null
                player = null
                runCatching { old?.stop() }
                runCatching { old?.release() }
                resourcesReleased = false
                initializePlayer(url, source, debug)
            }.onFailure { throwable ->
                Log.e("DebridChannels", "PLAYER_VOD_FULL_REBUILD_FAILED: ${throwable.message}", throwable)
                topOverlay.visibility = View.VISIBLE
                statusView.text = "Playback recovery failed — try another source"
            }
        }
    }

    private fun isAudioSinkFailure(error: PlaybackException): Boolean {
        val text = buildString {
            append(error.message.orEmpty())
            append(' ')
            append(error.cause?.message.orEmpty())
            append(' ')
            append(error.cause?.javaClass?.name.orEmpty())
        }.lowercase(Locale.US)
        return text.contains("audiotrack init failed") ||
            text.contains("audio sink") ||
            text.contains("audiosink") ||
            text.contains("initializationexception")
    }

    private fun retryWithSafeStereoAudio(reason: String): Boolean {
        if (!isVodMode || audioFallbackRetried || resourcesReleased) return false
        val url = currentStreamUrl.ifBlank { resumeStreamUrl }
        if (url.isBlank()) return false
        val positionMs = player?.currentPosition?.coerceAtLeast(0L) ?: 0L
        audioFallbackRetried = true
        safeStereoAudioFallbackActive = true
        pendingSafeAudioSeekMs = positionMs
        Log.w("DebridChannels", "PLAYER_AUDIO_FALLBACK_RETRY: reason=$reason seekMs=$positionMs mode=safe_stereo_no_tunnel")
        statusView.text = "Audio compatibility mode…"
        topOverlay.visibility = View.VISIBLE
        val source = currentSourceLabel
        val debug = currentDebugLabel
        overlayHandler.post {
            runCatching {
                playerView.player = null
                player?.release()
                player = null
                initializePlayer(url, source, debug)
            }.onFailure { throwable ->
                Log.e("DebridChannels", "PLAYER_AUDIO_FALLBACK_RETRY_FAILED: ${throwable.message}", throwable)
            }
        }
        return true
    }


    private fun playbackStateName(state: Int): String = when (state) {
        Player.STATE_IDLE -> "IDLE"
        Player.STATE_BUFFERING -> "BUFFERING"
        Player.STATE_READY -> "READY"
        Player.STATE_ENDED -> "ENDED"
        else -> "UNKNOWN_$state"
    }

    private fun formatVideoSize(videoSize: VideoSize): String {
        return "${videoSize.width}x${videoSize.height}"
    }

    private fun logDevicePlaybackCapabilities() {
        Log.i(
            "DebridChannels",
            "PLAYER_DEVICE_CAPABILITIES: " + listOf(
                "dv=${isVideoMimeSupported(MimeTypes.VIDEO_DOLBY_VISION)}",
                "hevc=${isVideoMimeSupported(MimeTypes.VIDEO_H265)}",
                "avc=${isVideoMimeSupported(MimeTypes.VIDEO_H264)}",
                "atmos_ddp=${isAudioMimeSupported(MimeTypes.AUDIO_E_AC3_JOC)}",
                "eac3=${isAudioMimeSupported(MimeTypes.AUDIO_E_AC3)}",
                "ac3=${isAudioMimeSupported(MimeTypes.AUDIO_AC3)}",
                "dts=${isAudioMimeSupported(MimeTypes.AUDIO_DTS)}",
                "dts_hd=${isAudioMimeSupported(MimeTypes.AUDIO_DTS_HD)}",
                "truehd=${isAudioMimeSupported(MimeTypes.AUDIO_TRUEHD)}",
                "api=${Build.VERSION.SDK_INT}"
            ).joinToString(" ")
        )
    }

    private fun logPlayerTracks(tracks: Tracks) {
        var videoCount = 0
        var audioCount = 0
        var textCount = 0
        val selected = mutableListOf<String>()
        tracks.groups.forEach { group ->
            when (group.type) {
                C.TRACK_TYPE_VIDEO -> videoCount += group.length
                C.TRACK_TYPE_AUDIO -> audioCount += group.length
                C.TRACK_TYPE_TEXT -> textCount += group.length
            }
            for (i in 0 until group.length) {
                if (group.isTrackSelected(i)) {
                    val fmt = group.getTrackFormat(i)
                    val kind = when (group.type) {
                        C.TRACK_TYPE_VIDEO -> "video"
                        C.TRACK_TYPE_AUDIO -> "audio"
                        C.TRACK_TYPE_TEXT -> "text"
                        else -> "type${group.type}"
                    }
                    selected += "$kind=${describeFormat(fmt)}"
                    if (group.type == C.TRACK_TYPE_VIDEO) {
                        applyFrameRateMatching(fmt.frameRate)
                        Log.i("DebridChannels", "PLAYER_HDR_DOLBY_CAPABILITY: ${classifyVideoFormat(fmt)} supported=${isVideoMimeSupported(fmt.sampleMimeType)}")
                    }
                    if (group.type == C.TRACK_TYPE_AUDIO) {
                        Log.i("DebridChannels", "PLAYER_AUDIO_CAPABILITY: ${classifyAudioFormat(fmt)} supported=${isAudioMimeSupported(fmt.sampleMimeType)} channels=${fmt.channelCount}")
                    }
                }
            }
        }
        Log.i("DebridChannels", "PLAYER_TRACKS: video=$videoCount audio=$audioCount text=$textCount selected=${selected.joinToString(" | ").take(700)}")
    }

    private fun describeFormat(format: Format): String {
        val fps = if (format.frameRate > 0f) String.format(Locale.US, "%.3ffps", format.frameRate) else "fps?"
        val bitrate = if (format.bitrate > 0) "${format.bitrate / 1000}kbps" else "bitrate?"
        val color = format.colorInfo?.let { "color=${it.colorSpace}/${it.colorTransfer}/${it.colorRange}" } ?: "color?"
        return listOf(
            format.sampleMimeType ?: "mime?",
            format.codecs ?: "codecs?",
            "${format.width}x${format.height}",
            fps,
            "${format.channelCount}ch",
            "${format.sampleRate}hz",
            bitrate,
            color,
            format.language ?: "und"
        ).joinToString("/")
    }

    private fun classifyVideoFormat(format: Format): String {
        val raw = listOf(format.sampleMimeType, format.codecs).filterNotNull().joinToString(" ").lowercase(Locale.US)
        val color = format.colorInfo
        return when {
            raw.contains("dolby") || raw.contains("dvhe") || raw.contains("dvh1") -> "DolbyVision"
            raw.contains("hdr10+") -> "HDR10Plus"
            color?.colorTransfer == C.COLOR_TRANSFER_ST2084 -> "HDR10_PQ"
            color?.colorTransfer == C.COLOR_TRANSFER_HLG -> "HLG"
            raw.contains("hevc") || raw.contains("h265") || raw.contains("hvc1") -> "HEVC_SDR_OR_METADATA_UNKNOWN"
            else -> "SDR_OR_UNKNOWN"
        }
    }

    private fun classifyAudioFormat(format: Format): String {
        val raw = listOf(format.sampleMimeType, format.codecs).filterNotNull().joinToString(" ").lowercase(Locale.US)
        return when {
            raw.contains("eac3-joc") || raw.contains("ec+3") -> "DolbyAtmos_DDP_JOC"
            raw.contains("eac3") -> "DolbyDigitalPlus"
            raw.contains("ac3") -> "DolbyDigital"
            raw.contains("truehd") -> "DolbyTrueHD"
            raw.contains("dts-hd") -> "DTSHD"
            raw.contains("dts") -> "DTS"
            raw.contains("aac") -> "AAC"
            else -> "AUDIO_UNKNOWN"
        }
    }

    private fun isVideoMimeSupported(mime: String?): Boolean {
        if (mime.isNullOrBlank() || Build.VERSION.SDK_INT < 21) return false
        return runCatching {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { codec ->
                !codec.isEncoder && codec.supportedTypes.any { it.equals(mime, ignoreCase = true) }
            }
        }.getOrDefault(false)
    }

    private fun isAudioMimeSupported(mime: String?): Boolean {
        if (mime.isNullOrBlank() || Build.VERSION.SDK_INT < 21) return false
        return runCatching {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { codec ->
                !codec.isEncoder && codec.supportedTypes.any { it.equals(mime, ignoreCase = true) }
            }
        }.getOrDefault(false)
    }

    private fun applyFrameRateMatching(frameRate: Float) {
        if (Build.VERSION.SDK_INT < 30 || frameRate <= 1f || frameRate.isNaN()) return
        val formatted = String.format(Locale.US, "%.3f", frameRate)
        // Android's frame-rate switching API is available on Surface, not PlayerView.
        // The current Media3 PlayerView does not expose its Surface safely across all TV devices,
        // so this build keeps the production hook/logging without calling a non-existent API.
        // A later device-specific implementation can apply Surface.setFrameRate from a controlled Surface callback.
        Log.i("DebridChannels", "PLAYER_FRAME_RATE_MATCH_HOOK: detected=$formatted surface_api_pending=true playback_unblocked=true")
    }

    private fun startPlaybackStallWatchdog(exoPlayer: ExoPlayer, sourceLabel: String) {
        val startedAt = System.currentTimeMillis()
        watchdogLastPositionMs = -1L
        watchdogStableTicks = 0
        overlayHandler.postDelayed({
            if (resourcesReleased || player !== exoPlayer) return@postDelayed
            if (!firstFrameLogged && exoPlayer.playbackState == Player.STATE_BUFFERING) {
                Log.w("DebridChannels", "PLAYER_STARTUP_STALL: no_first_frame_after_ms=${System.currentTimeMillis() - startedAt} source=${sourceLabel.take(60)} buffered=${exoPlayer.bufferedPercentage} loading=${exoPlayer.isLoading}")
            }
        }, 12_000L)
        overlayHandler.postDelayed({
            if (resourcesReleased || player !== exoPlayer) return@postDelayed
            if (!firstFrameLogged && exoPlayer.playbackState == Player.STATE_BUFFERING) {
                Log.w("DebridChannels", "PLAYER_STARTUP_STALL_LONG: no_first_frame_after_ms=${System.currentTimeMillis() - startedAt} direct_fallback_needed=true")
                statusView.text = "Still buffering… trying to stabilize stream"
                topOverlay.visibility = View.VISIBLE
            }
        }, 25_000L)
        overlayHandler.postDelayed(object : Runnable {
            override fun run() {
                if (resourcesReleased || player !== exoPlayer) return
                val state = exoPlayer.playbackState
                val position = exoPlayer.currentPosition.coerceAtLeast(0L)
                if (isVodMode && position > 0L && exoPlayer.isPlaying) lastKnownGoodVodPositionMs = position
                val stalled = state == Player.STATE_BUFFERING || (state == Player.STATE_READY && exoPlayer.playWhenReady && !exoPlayer.isPlaying)
                if (stalled && position == watchdogLastPositionMs) {
                    watchdogStableTicks += 1
                } else {
                    watchdogStableTicks = 0
                }
                watchdogLastPositionMs = position
                if (watchdogStableTicks >= 2 && isVodMode) {
                    Log.w("DebridChannels", "PLAYBACK_STALL_WATCHDOG_LOG_ONLY: ticks=$watchdogStableTicks state=${playbackStateName(state)} pos=$position xgimiCompat=$xgimiAudioCompatibilityDevice safeStereo=$safeStereoAudioFallbackActive source=${sourceLabel.take(60)} no_seek=true no_rebuild=true")
                    // Do not seek/reprepare from watchdog. This caused false positives and random jumps ahead.
                    // Only real STATE_IDLE or PlayerError paths may perform controlled recovery.
                    runCatching { exoPlayer.playWhenReady = true; exoPlayer.play() }
                    watchdogStableTicks = 0
                }
                overlayHandler.postDelayed(this, 15_000L)
            }
        }, 15_000L)
    }

    private fun isAudioRouteRiskState(): Boolean {
        return safeStereoAudioFallbackActive || xgimiAudioCompatibilityDevice
    }

    private fun buildVodPlaybackDataSourceFactory(
        httpFactory: DefaultHttpDataSource.Factory,
        streamUrl: String,
        storage: com.channelsdebrid.tv.settings.StorageSettings?
    ): DataSource.Factory {
        if (storage != null
            && storage.movieCacheEnabled
            && storage.preferredTarget.equals("nas", ignoreCase = true)
            && storage.nasHost.isNotBlank()
            && storage.nasPath.isNotBlank()
            && storage.nasUsername.isNotBlank()
            && !streamUrl.contains(".m3u8", ignoreCase = true)
        ) {
            vodCacheEnabledForItem = true
            vodPrefetchCancelled = false
            vodPrefetchCachedBytes = 0L
            vodPrefetchTotalBytes = -1L
            vodPrefetchStatusLabel = "Cache: direct playback + NAS mirror"
            val cacheName = "${sha1(streamUrl)}.dcache"
            vodTeeCacheName = cacheName
            vodTeeStorage = storage
            writeNasManifest(storage, "forced_prefetch_ready", cacheName, 0L, -1L)
            Log.i("DebridChannels", "VOD_FORCED_PREFETCH: direct_playback_ready file=$cacheName")
            return httpFactory
        }
        return buildVodDiskCacheDataSourceFactory(httpFactory)
    }

    private inner class VodNasTeeDataSourceFactory(
        private val upstreamFactory: DataSource.Factory,
        private val storage: com.channelsdebrid.tv.settings.StorageSettings,
        private val cacheName: String
    ) : DataSource.Factory {
        override fun createDataSource(): DataSource {
            return VodNasTeeDataSource(upstreamFactory.createDataSource(), storage, cacheName)
        }
    }

    private inner class VodNasTeeDataSource(
        private val upstream: DataSource,
        private val storage: com.channelsdebrid.tv.settings.StorageSettings,
        private val cacheName: String
    ) : DataSource {
        private val nasFolder = storage.nasPath.trimEnd('/') + "/DebridChannelsVodCache"
        private var cacheOut: BufferedOutputStream? = null
        private var mirrorEnabled = false
        private var writtenBase = 0L
        private var written = 0L
        private var lastManifestAt = 0L
        private val browser by lazy { SmbNasBrowser(storage.nasHost, storage.nasUsername, storage.nasPassword) }

        override fun addTransferListener(transferListener: TransferListener) {
            upstream.addTransferListener(transferListener)
        }

        override fun open(dataSpec: DataSpec): Long {
            val length = upstream.open(dataSpec)
            vodPrefetchTotalBytes = when {
                dataSpec.length > 0L -> dataSpec.position + dataSpec.length
                length > 0L && dataSpec.position == 0L -> length
                vodPrefetchTotalBytes > 0L -> vodPrefetchTotalBytes
                else -> -1L
            }
            // Only mirror the normal forward read path. If ExoPlayer seeks into the file,
            // do not append random ranged bytes to .dcache and corrupt the temporary cache.
            mirrorEnabled = dataSpec.position == 0L && !vodPrefetchCancelled
            writtenBase = if (mirrorEnabled) 0L else vodPrefetchCachedBytes
            written = writtenBase
            if (mirrorEnabled) {
                runCatching { browser.ensureFolder(nasFolder) }
                runCatching { browser.deleteFile(nasFolder, cacheName) }
                val out = browser.openWriteStream(nasFolder, cacheName, append = false)
                if (out != null) {
                    cacheOut = BufferedOutputStream(out, 1024 * 1024)
                    vodPrefetchStatusLabel = "Cache: filling movie ahead to NAS"
                    writeNasManifest(storage, "tee_full_ahead_active", cacheName, 0L, vodPrefetchTotalBytes)
                    Log.i("DebridChannels", "VOD_CACHE_TEE_FULL_AHEAD: open position=${dataSpec.position} length=$length total=$vodPrefetchTotalBytes")
                } else {
                    mirrorEnabled = false
                    vodPrefetchStatusLabel = "Cache: NAS writer unavailable"
                    writeNasManifest(storage, "tee_writer_unavailable", cacheName, vodPrefetchCachedBytes, vodPrefetchTotalBytes)
                }
            } else {
                Log.i("DebridChannels", "VOD_CACHE_TEE: passthrough_only position=${dataSpec.position} length=${dataSpec.length}")
            }
            return length
        }

        override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
            val read = upstream.read(buffer, offset, length)
            if (read > 0 && mirrorEnabled && cacheOut != null && !vodPrefetchCancelled) {
                runCatching {
                    cacheOut?.write(buffer, offset, read)
                    written += read.toLong()
                    vodPrefetchCachedBytes = if (vodPrefetchTotalBytes > 0L) written.coerceAtMost(vodPrefetchTotalBytes) else written
                    val now = System.currentTimeMillis()
                    if (now - lastManifestAt >= 1500L || read >= 512 * 1024) {
                        cacheOut?.flush()
                        lastManifestAt = now
                        writeNasManifest(storage, "tee_full_ahead_active", cacheName, vodPrefetchCachedBytes, vodPrefetchTotalBytes)
                    }
                }.onFailure { error ->
                    mirrorEnabled = false
                    vodPrefetchStatusLabel = "Cache: NAS mirror paused"
                    writeNasManifest(storage, "tee_write_failed", cacheName, vodPrefetchCachedBytes, vodPrefetchTotalBytes)
                    Log.w("DebridChannels", "VOD_CACHE_TEE: write_failed ${error.message}")
                }
            }
            if (read == C.RESULT_END_OF_INPUT && mirrorEnabled) {
                val state = if (vodPrefetchTotalBytes > 0L && vodPrefetchCachedBytes >= vodPrefetchTotalBytes) "tee_complete_until_exit" else "tee_playback_read_complete"
                vodPrefetchStatusLabel = if (state == "tee_complete_until_exit") "Cache: 100% loaded" else "Cache: loaded playback data"
                writeNasManifest(storage, state, cacheName, vodPrefetchCachedBytes, vodPrefetchTotalBytes)
            }
            return read
        }

        override fun getUri(): Uri? = upstream.uri
        override fun getResponseHeaders(): MutableMap<String, MutableList<String>> = upstream.responseHeaders

        override fun close() {
            runCatching { cacheOut?.flush() }
            runCatching { cacheOut?.close() }
            cacheOut = null
            upstream.close()
        }
    }

    private fun buildSingleSourceNasProxyUrlIfNeeded(streamUrl: String): String {
        val storage = runCatching { SettingsRepository(this).loadStorage() }.getOrNull() ?: return streamUrl
        if (!storage.movieCacheEnabled) return streamUrl
        if (!storage.preferredTarget.equals("nas", ignoreCase = true)) return streamUrl
        if (storage.nasHost.isBlank() || storage.nasPath.isBlank() || storage.nasUsername.isBlank()) return streamUrl
        if (streamUrl.contains(".m3u8", ignoreCase = true)) {
            vodPrefetchStatusLabel = "Cache: HLS uses direct segment cache"
            return streamUrl
        }
        return runCatching {
            vodProxySession?.stop(deletePartial = true)
            vodPrefetchCancelled = false
            vodPrefetchCachedBytes = 0L
            vodPrefetchTotalBytes = -1L
            vodPrefetchStatusLabel = "Cache: starting single-source NAS cache"
            val cacheName = "${sha1(streamUrl)}.dcache"
            val session = VodNasCacheProxy(storage, streamUrl, cacheName).also { it.start() }
            vodProxySession = session
            Log.i("DebridChannels", "VOD_NAS_PROXY: enabled url=${session.localUrl} file=$cacheName")
            session.localUrl
        }.getOrElse { error ->
            vodPrefetchStatusLabel = "Cache: proxy unavailable"
            Log.w("DebridChannels", "VOD_NAS_PROXY: start_failed ${error.message}")
            streamUrl
        }
    }

    private fun buildVodDiskCacheDataSourceFactory(httpFactory: DefaultHttpDataSource.Factory): DataSource.Factory {
        val storage = runCatching { SettingsRepository(this).loadStorage() }.getOrNull()
        if (storage == null || !storage.movieCacheEnabled) {
            vodCacheEnabledForItem = false
            vodCacheDir = null
            vodPrefetchStatusLabel = "Cache: off"
            Log.i("DebridChannels", "VOD_CACHE_ACTIVE: false reason=settings_disabled_or_default_off")
            return httpFactory
        }

        val target = storage.preferredTarget.lowercase(Locale.US)
        val targetAllowed = target == "nas" || target == "usb"
        if (!targetAllowed) {
            vodCacheEnabledForItem = false
            vodCacheDir = null
            vodPrefetchStatusLabel = "Cache: off - internal disk blocked"
            Log.i("DebridChannels", "VOD_CACHE_ACTIVE: false reason=internal_disk_blocked target=${storage.preferredTarget}")
            return httpFactory
        }

        if (target == "nas"
            && storage.nasHost.isNotBlank()
            && storage.nasPath.isNotBlank()
            && storage.nasUsername.isNotBlank()
        ) {
            vodCacheEnabledForItem = true
            vodCacheDir = null
            vodPrefetchStatusLabel = "Cache: NAS enabled"
            Log.i("DebridChannels", "VOD_CACHE_ACTIVE: nas_enabled_no_internal_fallback")
            return httpFactory
        }

        if (target == "nas") {
            vodCacheEnabledForItem = false
            vodCacheDir = null
            vodPrefetchStatusLabel = "Cache: off - NAS not configured"
            Log.i("DebridChannels", "VOD_CACHE_ACTIVE: false reason=nas_not_configured_no_internal_fallback")
            return httpFactory
        }

        if (target == "usb" && storage.usbPath.isBlank()) {
            vodCacheEnabledForItem = false
            vodCacheDir = null
            vodPrefetchStatusLabel = "Cache: off - USB not configured"
            Log.i("DebridChannels", "VOD_CACHE_ACTIVE: false reason=usb_not_configured_no_internal_fallback")
            return httpFactory
        }

        val dir = resolveVodCacheDirectory(storage)
        return runCatching<DataSource.Factory> {
            if (!dir.exists()) dir.mkdirs()
            val probe = File(dir, ".dc_vod_cache_probe")
            probe.writeText("ok")
            probe.delete()
            vodCacheDir = dir
            val oneTb = 1024L * 1024L * 1024L * 1024L
            val cache = vodDiskCache ?: SimpleCache(
                dir,
                LeastRecentlyUsedCacheEvictor(oneTb),
                StandaloneDatabaseProvider(this)
            ).also { vodDiskCache = it }
            vodCacheEnabledForItem = true
            vodPrefetchStatusLabel = "Cache: USB/external enabled"
            Log.i("DebridChannels", "VOD_CACHE_ACTIVE: true external path=${dir.absolutePath} limitBytes=$oneTb")
            CacheDataSource.Factory()
                .setCache(cache)
                .setUpstreamDataSourceFactory(httpFactory)
                .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
        }.getOrElse { error ->
            vodCacheEnabledForItem = false
            vodCacheDir = null
            vodPrefetchStatusLabel = "Cache: off - external target failed"
            Log.w("DebridChannels", "VOD_CACHE_ACTIVE: false reason=external_target_failed_no_internal_fallback error=${error.message}")
            httpFactory
        }
    }

    private fun resolveVodCacheDirectory(storage: com.channelsdebrid.tv.settings.StorageSettings): File {
        val base = when (storage.preferredTarget.lowercase(Locale.US)) {
            "nas" -> storage.nasPath
            "usb" -> storage.usbPath
            else -> ""
        }
        require(base.isNotBlank()) { "Internal VOD cache is blocked; configure NAS or USB first." }
        return File(File(base), "DebridChannelsVodCache")
    }

    private fun updateVodCacheStatus(exo: ExoPlayer, duration: Long) {
        if (!isVodMode) return
        val bufferedPercent = exo.bufferedPercentage.coerceIn(0, 100)
        val watchedPercent = if (duration > 0L) {
            ((exo.currentPosition.coerceAtLeast(0L).toDouble() / duration.toDouble()) * 100).toInt().coerceIn(0, 100)
        } else 0
        val storage = runCatching { SettingsRepository(this).loadStorage() }.getOrNull()
        val nasMode = storage?.preferredTarget.equals("nas", ignoreCase = true)
            && !storage?.nasHost.isNullOrBlank()
            && !storage?.nasPath.isNullOrBlank()
            && !storage?.nasUsername.isNullOrBlank()

        // In NAS mode, only trust bytes reported by the SMB writer. Do not let ExoPlayer
        // internal cache/buffer bytes create a fake progress label.
        val exoCacheBytes = if (nasMode) 0L else (vodCacheDir?.let { folderSizeBytes(it) } ?: 0L)
        if (!nasMode && exoCacheBytes > vodPrefetchCachedBytes) vodPrefetchCachedBytes = exoCacheBytes
        mirrorVodCacheStateToNasIfNeeded(exoCacheBytes)
        val prefetchPercent = if (vodPrefetchTotalBytes > 0L) {
            ((vodPrefetchCachedBytes.toDouble() / vodPrefetchTotalBytes.toDouble()) * 100).toInt().coerceIn(0, 100)
        } else -1
        val secondary = if (nasMode) prefetchPercent.coerceAtLeast(0) else maxOf(bufferedPercent, watchedPercent, prefetchPercent.coerceAtLeast(0))
        progressView.secondaryProgress = secondary
        cacheStatusView.visibility = View.VISIBLE
        val cacheLabel = when {
            nasMode && prefetchPercent >= 0 -> "Cache: ${prefetchPercent}% saved to NAS"
            nasMode && vodPrefetchCachedBytes > 0L -> "Cache: ${formatBytes(vodPrefetchCachedBytes)} saved to NAS"
            nasMode && vodPrefetchStatusLabel.isNotBlank() -> vodPrefetchStatusLabel
            nasMode -> "Cache: waiting for NAS writer"
            prefetchPercent >= 0 -> "Cache: ${prefetchPercent}% saved to disk"
            exoCacheBytes > 0L -> "Cache: ${formatBytes(exoCacheBytes)} saved to disk"
            vodCacheEnabledForItem && vodPrefetchStatusLabel.isNotBlank() -> vodPrefetchStatusLabel
            vodCacheEnabledForItem -> "Cache: waiting for player data"
            exo.isLoading -> "Cache: buffering stream"
            else -> "Cache: player buffer"
        }
        cacheStatusView.text = cacheLabel
        Log.i("DebridChannels", "VOD_DISK_CACHE_PROGRESS: watched=$watchedPercent buffered=$bufferedPercent saved=$prefetchPercent smbBytes=$vodPrefetchCachedBytes exoBuffered=$bufferedPercent active=$vodCacheEnabledForItem label=${cacheLabel.replace(' ', '_')}")
    }


    private fun folderSizeBytes(dir: File): Long {
        return runCatching {
            if (!dir.exists()) return@runCatching 0L
            dir.walkTopDown()
                .filter { it.isFile && !it.name.startsWith(".") && it.name != "cached_content_index.exi" && it.name != "exoplayer_internal.db" }
                .map { it.length().coerceAtLeast(0L) }
                .sum()
        }.getOrDefault(0L)
    }

    private fun formatBytes(bytes: Long): String {
        val gb = 1024.0 * 1024.0 * 1024.0
        val mb = 1024.0 * 1024.0
        return if (bytes >= gb) String.format(Locale.US, "%.2f GB", bytes / gb) else String.format(Locale.US, "%.1f MB", bytes / mb)
    }

    private fun mirrorVodCacheStateToNasIfNeeded(cacheBytes: Long) {
        // v2.8.15.4: NAS cache progress must come from the real SMB writer, not ExoPlayer
        // local/cache-span bytes. Keeping this as a no-op prevents fake marker files or
        // misleading player-buffer-only NAS manifests.
        return
    }


    private fun safVodTreeUri(): Uri? {
        val raw = getSharedPreferences("channels_debrid_settings", Context.MODE_PRIVATE)
            .getString("storage_saf_tree_uri", "")
            .orEmpty()
        return raw.takeIf { it.isNotBlank() }?.let { runCatching { Uri.parse(it) }.getOrNull() }
    }

    private fun sanitizeCacheFileName(title: String, streamUrl: String, extension: String): String {
        val base = title.ifBlank { "vod_${sha1(streamUrl).take(12)}" }
            .replace(Regex("[^A-Za-z0-9._ -]"), "_")
            .trim()
            .take(80)
            .ifBlank { "vod_${sha1(streamUrl).take(12)}" }
        return "$base.$extension"
    }

    private fun openSafVodOutputStream(fileName: String): java.io.OutputStream? {
        val treeUri = safVodTreeUri() ?: return null
        return runCatching {
            val treeDocId = DocumentsContract.getTreeDocumentId(treeUri)
            val rootDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, treeDocId)
            val targetUri = DocumentsContract.createDocument(contentResolver, rootDocUri, "application/octet-stream", fileName)
                ?: return@runCatching null
            contentResolver.openOutputStream(targetUri, "w")
        }.onFailure { Log.w("DebridChannels", "VOD_SAF_WRITER: open failed ${it.message}") }.getOrNull()
    }

    private fun writeSafManifest(state: String, fileName: String, bytes: Long, total: Long) {
        val treeUri = safVodTreeUri() ?: return
        runCatching {
            val treeDocId = DocumentsContract.getTreeDocumentId(treeUri)
            val rootDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, treeDocId)
            val manifestUri = DocumentsContract.createDocument(contentResolver, rootDocUri, "text/plain", "vod_cache_manifest_${System.currentTimeMillis()}.txt")
                ?: return@runCatching
            val totalText = if (total > 0L) total.toString() else "unknown"
            val percent = if (total > 0L) ((bytes.toDouble() / total.toDouble()) * 100.0).toInt().coerceIn(0, 100).toString() else "unknown"
            val text = "Debrid Channels SAF VOD cache\nstate=$state\nfile=$fileName\nbytes=$bytes\ntotal=$totalText\npercent=$percent\nupdatedAt=${System.currentTimeMillis()}\n"
            contentResolver.openOutputStream(manifestUri, "w")?.use { it.write(text.toByteArray()) }
        }.onFailure { Log.w("DebridChannels", "VOD_SAF_WRITER: manifest failed ${it.message}") }
    }

    private fun startVodProgressiveDiskPrefetch(streamUrl: String) {
        if (!isVodMode || streamUrl.isBlank()) return
        val storage = runCatching { SettingsRepository(this).loadStorage() }.getOrNull() ?: return
        if (!storage.movieCacheEnabled) {
            vodCacheEnabledForItem = false
            vodCacheDir = null
            vodPrefetchStatusLabel = "Cache: off"
            Log.i("DebridChannels", "VOD_PREFETCH_GATE: blocked_settings_off_direct_playback")
            return
        }
        val target = storage.preferredTarget.lowercase(Locale.US)
        if (target != "nas" && target != "usb") {
            vodCacheEnabledForItem = false
            vodCacheDir = null
            vodPrefetchStatusLabel = "Cache: off - internal disk blocked"
            Log.i("DebridChannels", "VOD_PREFETCH_GATE: blocked_internal_target_direct_playback target=${storage.preferredTarget}")
            return
        }
        vodPrefetchCancelled = false
        vodPrefetchTotalBytes = -1L
        vodPrefetchCachedBytes = 0L
        vodPrefetchStatusLabel = "Cache: checking stream"

        if (storage.preferredTarget.equals("nas", ignoreCase = true)
            && storage.nasHost.isNotBlank()
            && storage.nasPath.isNotBlank()
            && storage.nasUsername.isNotBlank()
        ) {
            startRealNasCacheWriter(storage, streamUrl)
            return
        }

        val dir = vodCacheDir ?: resolveVodCacheDirectory(storage)
        vodPrefetchExecutor.execute {
            runCatching {
                if (!dir.exists()) dir.mkdirs()
                val probe = File(dir, ".dc_vod_prefetch_probe")
                probe.writeText("ok")
                probe.delete()
                val cacheName = "${sha1(streamUrl)}.dcache"
                val target = File(dir, cacheName)
                val total = probeContentLength(streamUrl)
                vodPrefetchTotalBytes = total
                var existing = if (target.exists()) target.length() else 0L
                vodPrefetchCachedBytes = existing.coerceAtLeast(0L).let { if (total > 0L) it.coerceAtMost(total) else it }
                if (total > 0L && existing >= total) {
                    vodPrefetchStatusLabel = "Cache: 100% saved to disk"
                    Log.i("DebridChannels", "VOD_PREFETCH_CACHE: hit bytes=$existing total=$total path=${target.absolutePath}")
                    return@execute
                }

                val connection = openVodPrefetchConnection(streamUrl, existing, total)
                if (connection == null) {
                    vodPrefetchStatusLabel = "Cache: source refused background writer"
                    Log.w("DebridChannels", "VOD_PREFETCH_CACHE: source_refused no_disk_write")
                    return@execute
                }

                val code = connection.responseCode
                val appendLocal = code == 206 && existing > 0L && total > 0L
                try {
                    FileOutputStream(target, appendLocal).use { localOut ->
                        connection.inputStream.use { input ->
                            val buffer = ByteArray(256 * 1024)
                            while (!vodPrefetchCancelled) {
                                val read = input.read(buffer)
                                if (read <= 0) break
                                localOut.write(buffer, 0, read)
                                existing += read.toLong()
                                vodPrefetchCachedBytes = if (total > 0L) existing.coerceAtMost(total) else existing
                            }
                            localOut.flush()
                        }
                    }
                    vodPrefetchStatusLabel = when {
                        total > 0L && vodPrefetchCachedBytes >= total -> "Cache: 100% saved to disk"
                        vodPrefetchCancelled -> "Cache: paused"
                        else -> "Cache: saved playable buffer"
                    }
                    Log.i("DebridChannels", "VOD_PREFETCH_CACHE: done bytes=$vodPrefetchCachedBytes total=$total cancelled=$vodPrefetchCancelled local=${target.absolutePath}")
                } finally {
                    connection.disconnect()
                }
            }.onFailure { error ->
                vodPrefetchStatusLabel = "Cache: writer failed"
                Log.w("DebridChannels", "VOD_PREFETCH_CACHE: failed ${error.message}")
            }
        }
    }


    private fun startForcedAheadNasPrefetchEngine(storage: com.channelsdebrid.tv.settings.StorageSettings, streamUrl: String) {
        // v2.8.15.11: FINAL forced-prefetch path.
        // Playback remains direct/instant, while this independent worker aggressively reads
        // the progressive VOD URL from byte 0 until exit. The temporary .dcache is deleted
        // in releasePlayerResources(), because this is only anti-buffering cache, not library storage.
        if (vodPrefetchCancelled || streamUrl.isBlank()) return
        vodPrefetchExecutor.execute {
            val cacheName = vodTeeCacheName ?: "${sha1(streamUrl)}.dcache"
            val nasFolder = storage.nasPath.trimEnd('/') + "/DebridChannelsVodCache"
            val browser = SmbNasBrowser(storage.nasHost, storage.nasUsername, storage.nasPassword)
            runCatching {
                vodPrefetchStatusLabel = "Cache: forced prefetch starting"
                if (!browser.ensureFolder(nasFolder)) {
                    vodPrefetchStatusLabel = "Cache: NAS folder not writable"
                    writeNasManifest(storage, "forced_prefetch_nas_unwritable", cacheName, 0L, -1L)
                    Log.w("DebridChannels", "VOD_FORCED_PREFETCH: nas_unwritable folder=$nasFolder")
                    return@execute
                }
                browser.deleteFile(nasFolder, cacheName)
                var total = probeContentLength(streamUrl)
                vodPrefetchTotalBytes = total
                vodPrefetchCachedBytes = 0L
                writeNasManifest(storage, "forced_prefetch_starting", cacheName, 0L, total)

                var written = 0L
                var retry = 0
                var madeProgress = false
                while (!vodPrefetchCancelled && (total <= 0L || written < total)) {
                    val connection = openVodPrefetchConnection(streamUrl, written, total)
                    if (connection == null) {
                        retry++
                        val state = if (madeProgress) "forced_prefetch_waiting_resume" else "forced_prefetch_waiting_source"
                        vodPrefetchStatusLabel = if (madeProgress) "Cache: prefetch waiting to resume" else "Cache: prefetch waiting for source"
                        writeNasManifest(storage, state, cacheName, written, total)
                        Log.w("DebridChannels", "VOD_FORCED_PREFETCH: source_wait retry=$retry bytes=$written total=$total")
                        Thread.sleep((1000L * retry.coerceAtMost(10)).coerceAtMost(10000L))
                        continue
                    }
                    try {
                        val code = connection.responseCode
                        val resolvedTotal = resolveHttpTotal(connection, code, total)
                        if (resolvedTotal > 0L) {
                            total = resolvedTotal
                            vodPrefetchTotalBytes = total
                        }
                        val append = written > 0L && code == 206
                        if (written > 0L && !append) {
                            // The server refused range resume. Restart clean rather than corrupting the file.
                            written = 0L
                            vodPrefetchCachedBytes = 0L
                            browser.deleteFile(nasFolder, cacheName)
                            writeNasManifest(storage, "forced_prefetch_restart_no_range", cacheName, 0L, total)
                        }
                        val out = browser.openWriteStream(nasFolder, cacheName, append = append) ?: run {
                            writeNasManifest(storage, "forced_prefetch_writer_unavailable", cacheName, written, total)
                            return@execute
                        }
                        BufferedOutputStream(out, 1024 * 1024).use { nasOut ->
                            connection.inputStream.use { input ->
                                val buffer = ByteArray(1024 * 1024)
                                var lastManifestAt = 0L
                                var lastFlushBytes = written
                                vodPrefetchStatusLabel = "Cache: forced prefetch active"
                                writeNasManifest(storage, "forced_prefetch_active", cacheName, written, total)
                                while (!vodPrefetchCancelled && (total <= 0L || written < total)) {
                                    val read = input.read(buffer)
                                    if (read <= 0) break
                                    nasOut.write(buffer, 0, read)
                                    written += read.toLong()
                                    madeProgress = true
                                    vodPrefetchCachedBytes = if (total > 0L) written.coerceAtMost(total) else written
                                    val now = System.currentTimeMillis()
                                    if (written - lastFlushBytes >= 1024L * 1024L || now - lastManifestAt >= 1000L) {
                                        nasOut.flush()
                                        lastFlushBytes = written
                                        lastManifestAt = now
                                        val verified = browser.fileLength(nasFolder, cacheName).coerceAtLeast(vodPrefetchCachedBytes)
                                        vodPrefetchCachedBytes = if (total > 0L) verified.coerceAtMost(total) else verified
                                        writeNasManifest(storage, "forced_prefetch_active", cacheName, vodPrefetchCachedBytes, total)
                                    }
                                }
                                nasOut.flush()
                            }
                        }
                        val verified = browser.fileLength(nasFolder, cacheName).coerceAtLeast(written)
                        written = if (total > 0L) verified.coerceAtMost(total) else verified
                        vodPrefetchCachedBytes = written
                        retry = 0
                        if (total > 0L && written >= total) break
                        writeNasManifest(storage, "forced_prefetch_reconnect", cacheName, written, total)
                    } finally {
                        connection.disconnect()
                    }
                }
                val state = when {
                    vodPrefetchCancelled -> "forced_prefetch_cancelled_delete_on_exit"
                    total > 0L && vodPrefetchCachedBytes >= total -> "forced_prefetch_complete_until_exit"
                    vodPrefetchCachedBytes > 0L -> "forced_prefetch_partial_until_exit"
                    else -> "forced_prefetch_no_bytes"
                }
                vodPrefetchStatusLabel = when (state) {
                    "forced_prefetch_complete_until_exit" -> "Cache: 100% loaded"
                    "forced_prefetch_partial_until_exit" -> "Cache: ${formatBytes(vodPrefetchCachedBytes)} prefetched"
                    else -> "Cache: prefetch waiting for source"
                }
                writeNasManifest(storage, state, cacheName, vodPrefetchCachedBytes, total)
                Log.i("DebridChannels", "VOD_FORCED_PREFETCH: $state bytes=$vodPrefetchCachedBytes total=$total file=$cacheName")
            }.onFailure { error ->
                vodPrefetchStatusLabel = "Cache: forced prefetch failed"
                writeNasManifest(storage, "forced_prefetch_failed", cacheName, vodPrefetchCachedBytes, vodPrefetchTotalBytes)
                Log.w("DebridChannels", "VOD_FORCED_PREFETCH: failed ${error.message}")
            }
        }
    }

    private fun resolveHttpTotal(connection: HttpURLConnection, code: Int, previous: Long): Long {
        val range = connection.getHeaderField("Content-Range").orEmpty()
        val rangeTotal = if (range.contains("/")) range.substringAfterLast("/").toLongOrNull() ?: -1L else -1L
        if (rangeTotal > 0L) return rangeTotal
        val len = connection.contentLengthLong
        if (code == 200 && len > 0L) return len
        return previous
    }

    private fun startRealNasCacheWriter(storage: com.channelsdebrid.tv.settings.StorageSettings, streamUrl: String) {
        vodPrefetchExecutor.execute {
            val cacheName = "${sha1(streamUrl)}.dcache"
            val nasFolder = storage.nasPath.trimEnd('/') + "/DebridChannelsVodCache"
            val browser = SmbNasBrowser(storage.nasHost, storage.nasUsername, storage.nasPassword)
            runCatching {
                if (!browser.ensureFolder(nasFolder)) {
                    vodPrefetchStatusLabel = "Cache: NAS folder not writable"
                    writeNasManifest(storage, "nas_unwritable", cacheName, 0L, -1L)
                    Log.w("DebridChannels", "VOD_REAL_NAS_CACHE: nas_unwritable folder=$nasFolder")
                    return@execute
                }

                val total = probeContentLength(streamUrl)
                vodPrefetchTotalBytes = total
                var existing = browser.fileLength(nasFolder, cacheName).coerceAtLeast(0L)
                if (total > 0L) existing = existing.coerceAtMost(total)
                vodPrefetchCachedBytes = existing
                writeNasManifest(storage, "starting", cacheName, existing, total)

                if (total > 0L && existing >= total) {
                    vodPrefetchStatusLabel = "Cache: 100% saved to NAS"
                    writeNasManifest(storage, "complete", cacheName, existing, total)
                    Log.i("DebridChannels", "VOD_REAL_NAS_CACHE: hit bytes=$existing total=$total file=$cacheName")
                    return@execute
                }

                val isHls = streamUrl.contains(".m3u8", ignoreCase = true)
                val wrote = if (isHls) {
                    writeHlsStreamToNas(storage, browser, nasFolder, cacheName, streamUrl, existing, total)
                } else {
                    writeHttpStreamToNas(storage, browser, nasFolder, cacheName, streamUrl, existing, total)
                }

                if (!wrote) {
                    vodPrefetchStatusLabel = "Cache: source refused NAS writer"
                    writeNasManifest(storage, "source_refused", cacheName, vodPrefetchCachedBytes, total)
                    Log.w("DebridChannels", "VOD_REAL_NAS_CACHE: source_refused bytes=$vodPrefetchCachedBytes total=$total")
                }
            }.onFailure { error ->
                vodPrefetchStatusLabel = "Cache: NAS writer failed"
                writeNasManifest(storage, "writer_failed", cacheName, vodPrefetchCachedBytes, vodPrefetchTotalBytes)
                Log.w("DebridChannels", "VOD_REAL_NAS_CACHE: writer_failed ${error.message}")
            }
        }
    }

    private fun writeHttpStreamToNas(
        storage: com.channelsdebrid.tv.settings.StorageSettings,
        browser: SmbNasBrowser,
        nasFolder: String,
        cacheName: String,
        streamUrl: String,
        startBytes: Long,
        total: Long
    ): Boolean {
        // v2.8.15.6: Infuse-style NAS cache writer.
        // This loop is intentionally independent from ExoPlayer: playback can continue while
        // this writer keeps reconnecting/resuming until the full HTTP/MP4 source is on SMB.
        var written = startBytes.coerceAtLeast(0L)
        var lastProgressBytes = written
        var retryCount = 0
        var openedAtLeastOnce = false
        vodPrefetchCachedBytes = written
        writeNasManifest(storage, if (written > 0L) "resuming" else "starting", cacheName, written, total)

        while (!vodPrefetchCancelled && (total <= 0L || written < total)) {
            val connection = openVodPrefetchConnection(streamUrl, written, total)
            if (connection == null) {
                retryCount++
                val state = if (written > 0L) "waiting_source_resume" else "waiting_source_start"
                vodPrefetchStatusLabel = if (written > 0L) "Cache: waiting to resume NAS writer" else "Cache: waiting for source"
                writeNasManifest(storage, state, cacheName, written, total)
                Log.w("DebridChannels", "VOD_REAL_NAS_CACHE: $state retry=$retryCount bytes=$written total=$total")
                if (retryCount >= 12 && written == 0L && !openedAtLeastOnce) return false
                Thread.sleep((1500L * retryCount.coerceAtMost(8)).coerceAtMost(12000L))
                continue
            }

            openedAtLeastOnce = true
            retryCount = 0
            val code = connection.responseCode
            val append = code == 206 && written > 0L
            if (written > 0L && !append) {
                // Server did not honor resume. Restart the .dcache instead of appending corrupt data.
                written = 0L
                vodPrefetchCachedBytes = 0L
                writeNasManifest(storage, "restarting_full_stream", cacheName, 0L, total)
            }

            try {
                val out = browser.openWriteStream(nasFolder, cacheName, append = append) ?: return false
                BufferedOutputStream(out, 1024 * 1024).use { nasOut ->
                    connection.inputStream.use { input ->
                        vodPrefetchStatusLabel = if (total > 0L) "Cache: filling NAS cache" else "Cache: saving stream to NAS"
                        writeNasManifest(storage, "active", cacheName, written, total)
                        val buffer = ByteArray(1024 * 1024)
                        var sinceFlush = 0L
                        var lastManifestAt = System.currentTimeMillis()
                        while (!vodPrefetchCancelled && (total <= 0L || written < total)) {
                            val read = input.read(buffer)
                            if (read <= 0) break
                            nasOut.write(buffer, 0, read)
                            written += read.toLong()
                            sinceFlush += read.toLong()
                            vodPrefetchCachedBytes = if (total > 0L) written.coerceAtMost(total) else written
                            val now = System.currentTimeMillis()
                            if (sinceFlush >= 2L * 1024L * 1024L || now - lastManifestAt >= 1500L) {
                                nasOut.flush()
                                val smbLength = browser.fileLength(nasFolder, cacheName).coerceAtLeast(vodPrefetchCachedBytes)
                                vodPrefetchCachedBytes = if (total > 0L) smbLength.coerceAtMost(total) else smbLength
                                writeNasManifest(storage, "active", cacheName, vodPrefetchCachedBytes, total)
                                sinceFlush = 0L
                                lastManifestAt = now
                            }
                        }
                        nasOut.flush()
                    }
                }
                val smbLength = browser.fileLength(nasFolder, cacheName).coerceAtLeast(written)
                written = if (total > 0L) smbLength.coerceAtMost(total) else smbLength
                vodPrefetchCachedBytes = written
                writeNasManifest(storage, if (total > 0L && written >= total) "complete" else "active_reconnect", cacheName, written, total)
                lastProgressBytes = written
            } catch (error: Throwable) {
                retryCount++
                val state = if (written > lastProgressBytes) "active_reconnect" else "writer_retry"
                vodPrefetchStatusLabel = "Cache: NAS writer retrying"
                writeNasManifest(storage, state, cacheName, written, total)
                Log.w("DebridChannels", "VOD_REAL_NAS_CACHE: $state retry=$retryCount bytes=$written total=$total error=${error.message}")
                if (retryCount >= 12 && written == 0L && !openedAtLeastOnce) return false
                Thread.sleep((1500L * retryCount.coerceAtMost(8)).coerceAtMost(12000L))
            } finally {
                connection.disconnect()
            }
        }

        val state = when {
            vodPrefetchCancelled -> "paused"
            total > 0L && written >= total -> "complete"
            written > 0L -> "complete_unknown_total"
            else -> "source_refused"
        }
        vodPrefetchStatusLabel = when (state) {
            "complete" -> "Cache: 100% saved to NAS"
            "paused" -> "Cache: paused"
            "complete_unknown_total" -> "Cache: saved to NAS"
            else -> "Cache: source refused NAS writer"
        }
        writeNasManifest(storage, state, cacheName, vodPrefetchCachedBytes, total)
        Log.i("DebridChannels", "VOD_REAL_NAS_CACHE: $state bytes=$vodPrefetchCachedBytes total=$total file=$cacheName")
        return vodPrefetchCachedBytes > startBytes || state == "complete"
    }

    private fun writeHlsStreamToNas(
        storage: com.channelsdebrid.tv.settings.StorageSettings,
        browser: SmbNasBrowser,
        nasFolder: String,
        cacheName: String,
        streamUrl: String,
        startBytes: Long,
        total: Long
    ): Boolean {
        val manifestText = fetchSmallText(streamUrl) ?: return false
        val segmentUrls = parseHlsSegmentUrls(streamUrl, manifestText)
        if (segmentUrls.isEmpty()) return false
        var written = startBytes
        val out = browser.openWriteStream(nasFolder, cacheName, append = startBytes > 0L) ?: return false
        BufferedOutputStream(out, 512 * 1024).use { nasOut ->
            vodPrefetchStatusLabel = "Cache: saving HLS to NAS"
            writeNasManifest(storage, "active_hls", cacheName, written, total)
            for (segment in segmentUrls) {
                if (vodPrefetchCancelled) break
                val connection = openVodPrefetchConnection(segment, 0L, -1L) ?: continue
                try {
                    connection.inputStream.use { input ->
                        val buffer = ByteArray(512 * 1024)
                        while (!vodPrefetchCancelled) {
                            val read = input.read(buffer)
                            if (read <= 0) break
                            nasOut.write(buffer, 0, read)
                            written += read.toLong()
                            vodPrefetchCachedBytes = written
                        }
                        nasOut.flush()
                        writeNasManifest(storage, "active_hls", cacheName, vodPrefetchCachedBytes, total)
                    }
                } finally {
                    connection.disconnect()
                }
            }
        }
        val state = if (vodPrefetchCancelled) "paused_hls" else "complete_hls"
        vodPrefetchStatusLabel = if (vodPrefetchCancelled) "Cache: paused" else "Cache: HLS saved to NAS"
        writeNasManifest(storage, state, cacheName, vodPrefetchCachedBytes, total)
        Log.i("DebridChannels", "VOD_REAL_NAS_CACHE: $state bytes=$vodPrefetchCachedBytes segments=${segmentUrls.size} file=$cacheName")
        return vodPrefetchCachedBytes > startBytes
    }

    private fun fetchSmallText(url: String): String? {
        return runCatching {
            val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                instanceFollowRedirects = true
                connectTimeout = 12000
                readTimeout = 12000
                setRequestProperty("User-Agent", "Mozilla/5.0 (Android TV; Debrid Channels) AppleWebKit/537.36")
                setRequestProperty("Accept", "*/*")
            }
            try {
                if (connection.responseCode !in 200..299) return@runCatching null
                connection.inputStream.use { input ->
                    val out = ByteArrayOutputStream()
                    val buffer = ByteArray(32 * 1024)
                    var total = 0L
                    while (total < 2L * 1024L * 1024L) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        out.write(buffer, 0, read)
                        total += read.toLong()
                    }
                    out.toString(Charsets.UTF_8.name())
                }
            } finally {
                connection.disconnect()
            }
        }.getOrNull()
    }

    private fun parseHlsSegmentUrls(manifestUrl: String, manifestText: String): List<String> {
        val base = URL(manifestUrl)
        return manifestText.lineSequence()
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.startsWith("#") }
            .mapNotNull { line ->
                runCatching { URL(base, line).toString() }.getOrNull()
            }
            .toList()
    }

    private fun openVodPrefetchConnection(streamUrl: String, existing: Long, total: Long): HttpURLConnection? {
        // v2.8.15.7: source opener must mirror the player first.
        // The previous NAS downloader sent browser/Stremio Origin headers before trying
        // ExoPlayer-style headers. Some debrid/CDN links play fine in ExoPlayer but reject
        // those extra headers, leaving the UI stuck on "Cache: waiting for source".
        data class Attempt(val rangeHeader: String?, val userAgent: String, val addBrowserHeaders: Boolean, val label: String)
        fun build(attempt: Attempt): HttpURLConnection {
            return (URL(streamUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                instanceFollowRedirects = true
                connectTimeout = 25000
                readTimeout = 180000
                setRequestProperty("User-Agent", attempt.userAgent)
                setRequestProperty("Accept", "*/*")
                setRequestProperty("Accept-Encoding", "identity")
                setRequestProperty("Connection", "keep-alive")
                if (attempt.addBrowserHeaders) {
                    setRequestProperty("Referer", "https://app.strem.io/")
                    setRequestProperty("Origin", "https://app.strem.io")
                }
                if (!attempt.rangeHeader.isNullOrBlank()) setRequestProperty("Range", attempt.rangeHeader)
            }
        }
        val exoUa = "ChannelsDebridTV/1.7.1 LivePlayer"
        val chromeUa = "Mozilla/5.0 (Linux; Android TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36 DebridChannels/2.8.15.7"
        val attempts = mutableListOf<Attempt>()
        // First try EXACTLY how playback opens the stream: plain GET, same UA, no Origin/Referer.
        attempts += Attempt(null, exoUa, false, "player_plain")
        if (existing > 0L && total > 0L) attempts += Attempt("bytes=$existing-", exoUa, false, "player_resume")
        if (total > 0L) attempts += Attempt("bytes=0-", exoUa, false, "player_range0")
        attempts += Attempt(null, "ExoPlayerLib/2.19.1", false, "exo_plain")
        attempts += Attempt(null, chromeUa, false, "browser_plain_no_origin")
        attempts += Attempt(null, chromeUa, true, "browser_plain_origin")
        if (existing > 0L && total > 0L) attempts += Attempt("bytes=$existing-", chromeUa, false, "browser_resume_no_origin")

        for (attempt in attempts) {
            val connection = build(attempt)
            val code = runCatching { connection.responseCode }.getOrDefault(-1)
            if (code == 200 || code == 206) {
                Log.i("DebridChannels", "VOD_REAL_NAS_CACHE: source_open label=${attempt.label} code=$code range=${attempt.rangeHeader ?: "none"}")
                return connection
            }
            val message = runCatching { connection.responseMessage }.getOrDefault("")
            Log.w("DebridChannels", "VOD_REAL_NAS_CACHE: source_refused_attempt label=${attempt.label} code=$code message=$message")
            connection.disconnect()
        }
        return null
    }

    private fun openNasVodMirrorStream(storage: com.channelsdebrid.tv.settings.StorageSettings, fileName: String, append: Boolean): java.io.OutputStream? {
        if (!storage.preferredTarget.equals("nas", ignoreCase = true)) return null
        if (storage.nasHost.isBlank() || storage.nasPath.isBlank() || storage.nasUsername.isBlank()) return null
        return runCatching {
            SmbNasBrowser(storage.nasHost, storage.nasUsername, storage.nasPassword)
                .openWriteStream(storage.nasPath.trimEnd('/') + "/DebridChannelsVodCache", fileName, append)
        }.getOrNull()
    }

    private fun writeNasManifest(storage: com.channelsdebrid.tv.settings.StorageSettings, state: String, fileName: String, bytes: Long, total: Long) {
        if (!storage.preferredTarget.equals("nas", ignoreCase = true)) return
        if (storage.nasHost.isBlank() || storage.nasPath.isBlank() || storage.nasUsername.isBlank()) return
        runCatching {
            val totalText = if (total > 0L) total.toString() else "unknown"
            val percent = if (total > 0L) ((bytes.toDouble() / total.toDouble()) * 100.0).toInt().coerceIn(0, 100).toString() else "unknown"
            val manifest = "Debrid Channels VOD cache\nstate=$state\nfile=$fileName\nbytes=$bytes\ntotal=$totalText\npercent=$percent\nupdatedAt=${System.currentTimeMillis()}\n"
            SmbNasBrowser(storage.nasHost, storage.nasUsername, storage.nasPassword)
                .writeTextFile(storage.nasPath.trimEnd('/') + "/DebridChannelsVodCache", "vod_cache_manifest.txt", manifest)
        }
    }

    private fun mirrorCompletedVodCacheToNasIfNeeded(storage: com.channelsdebrid.tv.settings.StorageSettings, localFile: File, fileName: String, total: Long) {
        if (!storage.preferredTarget.equals("nas", ignoreCase = true)) return
        if (!localFile.exists() || localFile.length() <= 0L) return
        // Completed-cache mirroring is intentionally manifest-first here. Active playback writes directly
        // to NAS when SMB credentials are available, so this method only records completion state.
        writeNasManifest(storage, "complete", fileName, localFile.length(), total)
    }


    private inner class VodNasCacheProxy(
        private val storage: com.channelsdebrid.tv.settings.StorageSettings,
        private val upstreamUrl: String,
        private val cacheName: String
    ) {
        private val stopped = AtomicBoolean(false)
        private val executor = Executors.newSingleThreadExecutor()
        private val server = ServerSocket(0, 1, java.net.InetAddress.getByName("127.0.0.1"))
        val localUrl: String = "http://127.0.0.1:${server.localPort}/vod"
        private val nasFolder = storage.nasPath.trimEnd('/') + "/DebridChannelsVodCache"
        private val browser = SmbNasBrowser(storage.nasHost, storage.nasUsername, storage.nasPassword)

        fun start() {
            writeNasManifest(storage, "proxy_starting", cacheName, 0L, -1L)
            executor.execute {
                runCatching {
                    if (!browser.ensureFolder(nasFolder)) {
                        vodPrefetchStatusLabel = "Cache: NAS folder not writable"
                        writeNasManifest(storage, "nas_unwritable", cacheName, 0L, -1L)
                        return@execute
                    }
                    while (!stopped.get()) {
                        val socket = server.accept()
                        handleClient(socket)
                        // ExoPlayer may reconnect on seek. Keep accepting until activity exits.
                    }
                }.onFailure { error ->
                    if (!stopped.get()) {
                        vodPrefetchStatusLabel = "Cache: proxy failed"
                        writeNasManifest(storage, "proxy_failed", cacheName, vodPrefetchCachedBytes, vodPrefetchTotalBytes)
                        Log.w("DebridChannels", "VOD_NAS_PROXY: failed ${error.message}")
                    }
                }
            }
        }

        fun stop(deletePartial: Boolean) {
            stopped.set(true)
            runCatching { server.close() }
            runCatching { executor.shutdownNow() }
            if (deletePartial) {
                runCatching { browser.deleteFile(nasFolder, cacheName) }
                runCatching { browser.deleteFile(nasFolder, "vod_cache_manifest.txt") }
                Log.i("DebridChannels", "VOD_NAS_PROXY: cleanup_deleted file=$cacheName")
            }
        }

        private fun handleClient(socket: Socket) {
            socket.use { client ->
                client.soTimeout = 30000
                val header = readHttpHeader(client.getInputStream())
                val playerRange = Regex("(?im)^Range:\\s*(bytes=[^\\r\\n]+)").find(header)?.groupValues?.getOrNull(1)
                val connection = (URL(upstreamUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    instanceFollowRedirects = true
                    connectTimeout = 25000
                    readTimeout = 180000
                    setRequestProperty("User-Agent", "ChannelsDebridTV/1.7.1 LivePlayer")
                    setRequestProperty("Accept", "*/*")
                    setRequestProperty("Accept-Encoding", "identity")
                    setRequestProperty("Connection", "keep-alive")
                    if (!playerRange.isNullOrBlank()) setRequestProperty("Range", playerRange)
                }
                try {
                    val code = connection.responseCode
                    val total = resolveProxyTotal(connection, code)
                    vodPrefetchTotalBytes = total
                    val contentLength = connection.contentLengthLong.takeIf { it > 0L } ?: -1L
                    val contentType = connection.contentType ?: "application/octet-stream"
                    val responseHeader = buildString {
                        append("HTTP/1.1 ").append(code).append(' ').append(connection.responseMessage ?: "OK").append("\r\n")
                        append("Content-Type: ").append(contentType).append("\r\n")
                        if (contentLength > 0L) append("Content-Length: ").append(contentLength).append("\r\n")
                        connection.getHeaderField("Content-Range")?.let { append("Content-Range: ").append(it).append("\r\n") }
                        append("Accept-Ranges: bytes\r\n")
                        append("Connection: close\r\n\r\n")
                    }
                    val clientOut = BufferedOutputStream(client.getOutputStream(), 256 * 1024)
                    clientOut.write(responseHeader.toByteArray(Charsets.ISO_8859_1))
                    clientOut.flush()

                    val rangeStart = parseRangeStart(playerRange)
                    val append = rangeStart > 0L && code == 206
                    if (!append && rangeStart <= 0L) {
                        runCatching { browser.deleteFile(nasFolder, cacheName) }
                    }
                    val nasOut = browser.openWriteStream(nasFolder, cacheName, append = append)
                    if (nasOut == null) {
                        vodPrefetchStatusLabel = "Cache: NAS writer unavailable"
                        writeNasManifest(storage, "nas_writer_unavailable", cacheName, vodPrefetchCachedBytes, total)
                    }
                    BufferedOutputStream(nasOut ?: ByteArrayOutputStream(), 1024 * 1024).use { cacheOut ->
                        connection.inputStream.use { upstream ->
                            vodPrefetchStatusLabel = "Cache: filling NAS cache"
                            var written = if (append) rangeStart else 0L
                            vodPrefetchCachedBytes = written
                            writeNasManifest(storage, "active_proxy", cacheName, written, total)
                            val buffer = ByteArray(1024 * 1024)
                            var sinceFlush = 0L
                            var lastManifestAt = System.currentTimeMillis()
                            while (!stopped.get()) {
                                val read = upstream.read(buffer)
                                if (read <= 0) break
                                clientOut.write(buffer, 0, read)
                                cacheOut.write(buffer, 0, read)
                                written += read.toLong()
                                sinceFlush += read.toLong()
                                vodPrefetchCachedBytes = if (total > 0L) written.coerceAtMost(total) else written
                                val now = System.currentTimeMillis()
                                if (sinceFlush >= 2L * 1024L * 1024L || now - lastManifestAt >= 1500L) {
                                    clientOut.flush()
                                    cacheOut.flush()
                                    writeNasManifest(storage, "active_proxy", cacheName, vodPrefetchCachedBytes, total)
                                    sinceFlush = 0L
                                    lastManifestAt = now
                                }
                            }
                            clientOut.flush()
                            cacheOut.flush()
                            val state = when {
                                stopped.get() -> "deleted_after_playback"
                                total > 0L && vodPrefetchCachedBytes >= total -> "complete_until_exit"
                                else -> "active_proxy_ended"
                            }
                            vodPrefetchStatusLabel = if (state == "complete_until_exit") "Cache: 100% loaded" else "Cache: loaded ahead"
                            writeNasManifest(storage, state, cacheName, vodPrefetchCachedBytes, total)
                            Log.i("DebridChannels", "VOD_NAS_PROXY: $state bytes=$vodPrefetchCachedBytes total=$total")
                        }
                    }
                } finally {
                    connection.disconnect()
                }
            }
        }

        private fun readHttpHeader(input: java.io.InputStream): String {
            val out = ByteArrayOutputStream()
            var matched = 0
            val end = byteArrayOf('\r'.code.toByte(), '\n'.code.toByte(), '\r'.code.toByte(), '\n'.code.toByte())
            while (out.size() < 64 * 1024) {
                val b = input.read()
                if (b < 0) break
                out.write(b)
                matched = if (b.toByte() == end[matched]) matched + 1 else 0
                if (matched == end.size) break
            }
            return out.toString(Charsets.ISO_8859_1.name())
        }

        private fun parseRangeStart(range: String?): Long {
            if (range.isNullOrBlank()) return 0L
            return Regex("bytes=(\\d+)-").find(range)?.groupValues?.getOrNull(1)?.toLongOrNull() ?: 0L
        }

        private fun resolveProxyTotal(connection: HttpURLConnection, code: Int): Long {
            val cr = connection.getHeaderField("Content-Range")
            val fromRange = cr?.substringAfter('/')?.toLongOrNull() ?: -1L
            if (fromRange > 0L) return fromRange
            val len = connection.contentLengthLong
            return if (code == 200 && len > 0L) len else -1L
        }
    }

    private fun probeContentLength(streamUrl: String): Long {
        fun parseRangeTotal(connection: HttpURLConnection): Long {
            val length = connection.getHeaderFieldLong("Content-Length", -1L)
            val range = connection.getHeaderField("Content-Range").orEmpty()
            return if (range.contains("/")) range.substringAfterLast("/").toLongOrNull() ?: length else length
        }
        val headLength = runCatching {
            val connection = (URL(streamUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "HEAD"
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("User-Agent", "ChannelsDebridTV/1.0")
                setRequestProperty("Range", "bytes=0-1")
                setRequestProperty("Accept-Encoding", "identity")
            }
            try { parseRangeTotal(connection) } finally { connection.disconnect() }
        }.getOrDefault(-1L)
        if (headLength > 0L) return headLength
        return runCatching {
            val connection = (URL(streamUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("User-Agent", "ChannelsDebridTV/1.0")
                setRequestProperty("Range", "bytes=0-1")
                setRequestProperty("Accept-Encoding", "identity")
            }
            try { parseRangeTotal(connection) } finally {
                runCatching { connection.inputStream.close() }
                connection.disconnect()
            }
        }.getOrDefault(-1L)
    }

    private fun sha1(value: String): String {
        val digest = MessageDigest.getInstance("SHA-1").digest(value.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun canSeekCurrentLiveStream(): Boolean {
        if (isVodMode) return true
        // Clean mode: do not block channel controls on native Channels DVR seek detection.
        // If the current stream itself is not seekable, the player remains on live playback
        // while the app timeshift layer/storage settings handle buffering policy.
        return true
    }

    private fun seekBackSafely(revealControls: Boolean = true) {
        val p = player
        if (p != null && !isVodMode) {
            val handled = timeshiftSession?.seekBack(p, 30000L) == true
            if (!handled) {
                val duration = p.duration
                val seekable = p.isCurrentMediaItemSeekable && duration != C.TIME_UNSET && duration > 0L
                if (seekable) {
                    val target = (p.currentPosition - 30000L).coerceAtLeast(0L)
                    runCatching { p.seekTo(target) }.onFailure { showLiveSeekUnavailable("Rewind unavailable on this live stream") }
                } else {
                    val age = timeshiftSession?.bufferAgeMs() ?: 0L
                    val seconds = ((30_000L - age).coerceAtLeast(0L) / 1000L).coerceAtLeast(1L)
                    showLiveSeekUnavailable("Timeshift buffer is building - try rewind again in ${seconds}s")
                }
            }
        } else {
            if (!revealControls && !topOverlay.isVisible) suppressVodOverlayForHiddenScrub()
            seekVodBy(-vodSeekStepMs)
        }
        if (!isVodMode || revealControls || (topOverlay.isVisible && !shouldSuppressVodOverlay())) {
            showVodControls()
        } else {
            Log.i("DebridChannels", "VOD_SCRUB_HIDDEN_CONTROLS: direction=back stepMs=$vodSeekStepMs")
        }
    }

    private fun seekForwardSafely(revealControls: Boolean = true) {
        val p = player
        if (p != null && !isVodMode) {
            val handled = timeshiftSession?.seekForward(p, 30000L) == true
            if (!handled) {
                val duration = p.duration
                val seekable = p.isCurrentMediaItemSeekable && duration != C.TIME_UNSET && duration > 0L
                if (seekable) {
                    val target = (p.currentPosition + 30000L).coerceAtMost(duration)
                    runCatching { p.seekTo(target) }.onFailure { showLiveSeekUnavailable("Fast-forward unavailable on this live stream") }
                } else {
                    showLiveSeekUnavailable("Already at live edge")
                }
            }
        } else {
            if (!revealControls && !topOverlay.isVisible) suppressVodOverlayForHiddenScrub()
            seekVodBy(vodSeekStepMs)
        }
        if (!isVodMode || revealControls || (topOverlay.isVisible && !shouldSuppressVodOverlay())) {
            showVodControls()
        } else {
            Log.i("DebridChannels", "VOD_SCRUB_HIDDEN_CONTROLS: direction=forward stepMs=$vodSeekStepMs")
        }
    }



    private fun suppressVodOverlayForHiddenScrub() {
        suppressVodOverlayUntilMs = SystemClock.uptimeMillis() + 2500L
        if (isVodMode && topOverlay.isVisible) {
            topOverlay.visibility = View.GONE
        }
        Log.i("DebridChannels", "VOD_HIDDEN_SCRUB_OVERLAY_SUPPRESSED: untilMs=$suppressVodOverlayUntilMs")
    }

    private fun shouldSuppressVodOverlay(): Boolean {
        return isVodMode && SystemClock.uptimeMillis() < suppressVodOverlayUntilMs
    }
    private fun seekVodBy(deltaMs: Long) {
        val exo = player ?: return
        val duration = exo.duration
        val base = exo.currentPosition
        val target = if (duration != C.TIME_UNSET && duration > 0L) {
            (base + deltaMs).coerceIn(0L, duration)
        } else {
            (base + deltaMs).coerceAtLeast(0L)
        }
        runCatching { exo.seekTo(target) }
            .onSuccess {
                showTrickplayPreview(target, duration)
                Log.i("DebridChannels", "VOD_TRICKPLAY_SEEK: from=$base target=$target step=$deltaMs duration=$duration")
            }
            .onFailure { Log.w("DebridChannels", "VOD_TRICKPLAY_SEEK_FAILED: ${it.message}") }
    }

    private fun showTrickplayPreview(positionMs: Long, durationMs: Long) {
        val view = trickplayPreviewView ?: return
        val text = if (durationMs != C.TIME_UNSET && durationMs > 0L) {
            "Preview ${formatDuration(positionMs)} / ${formatDuration(durationMs)}"
        } else {
            "Preview ${formatDuration(positionMs)}"
        }
        view.text = text
        view.visibility = View.VISIBLE
        overlayHandler.removeCallbacks(hideTrickplayPreviewRunnable)
        overlayHandler.postDelayed(hideTrickplayPreviewRunnable, 1200L)
        overlayHandler.post(updateVodProgressRunnable)
        if (!shouldSuppressVodOverlay()) scheduleTopOverlayHide()
    }
    private fun currentFocusIsVodButton(): Boolean {
        val focused = currentFocus ?: return false
        return listOfNotNull(
            rewindButton, playPauseButton, forwardButton, switchLinkButton, audioButton,
            subtitlesButton, episodesButton, zoomButton, settingsButton
        ).any { it === focused }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (isVodMode && !topOverlay.isVisible && (event.keyCode == KeyEvent.KEYCODE_DPAD_LEFT || event.keyCode == KeyEvent.KEYCODE_DPAD_RIGHT)) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                suppressVodOverlayForHiddenScrub()
                if (event.keyCode == KeyEvent.KEYCODE_DPAD_LEFT) seekBackSafely(revealControls = false) else seekForwardSafely(revealControls = false)
            }
            return true
        }
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        if (topOverlay.isVisible && currentFocusIsVodButton()) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT,
                KeyEvent.KEYCODE_DPAD_RIGHT,
                KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER -> {
                    showVodControls()
                    return super.dispatchKeyEvent(event)
                }
            }
        }
        if (isVodMode) {
            if (topOverlay.isVisible && currentFocusIsVodButton()) {
                when (event.keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT,
                    KeyEvent.KEYCODE_DPAD_RIGHT,
                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER -> {
                        showVodControls()
                        return super.dispatchKeyEvent(event)
                    }
                }
            }
            when (event.keyCode) {
                KeyEvent.KEYCODE_MEDIA_REWIND -> {
                    seekBackSafely()
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                    seekForwardSafely()
                    return true
                }
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    seekBackSafely(revealControls = topOverlay.isVisible)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    seekForwardSafely(revealControls = topOverlay.isVisible)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                    if (!topOverlay.isVisible) {
                        showVodControls()
                        playPauseButton?.requestFocus()
                    } else {
                        toggleVodPlayback()
                        showVodControls()
                    }
                    return true
                }
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> {
                    showVodControls()
                    playPauseButton?.requestFocus()
                    return true
                }
                KeyEvent.KEYCODE_BACK -> {
                    if (topOverlay.isVisible) {
                        topOverlay.visibility = View.GONE
                        return true
                    }
                }
            }
        }
        when (event.keyCode) {
            KeyEvent.KEYCODE_MEDIA_REWIND -> {
                seekBackSafely()
                return true
            }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                seekForwardSafely()
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (guideOverlay.isVisible) {
                    moveGuideSelection(-1)
                    return true
                }
                if (topOverlay.isVisible) {
                    seekBackSafely()
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (guideOverlay.isVisible) {
                    moveGuideSelection(1)
                    return true
                }
                if (topOverlay.isVisible) {
                    seekForwardSafely()
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (!guideOverlay.isVisible) {
                    selectedGuideIndex = currentIndex
                    showGuideOverlay()
                }
                return true
            }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_BACK -> {
                if (guideOverlay.isVisible) {
                    hideGuideOverlay()
                    return true
                }
                if (topOverlay.isVisible && event.keyCode == KeyEvent.KEYCODE_BACK) {
                    topOverlay.visibility = View.GONE
                    return true
                }
                if (event.keyCode == KeyEvent.KEYCODE_BACK) {
                    setResult(RESULT_OK)
                    finish()
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                if (guideOverlay.isVisible) {
                    hideGuideOverlay()
                } else if (topOverlay.isVisible) {
                    toggleVodPlayback()
                    showVodControls()
                    playPauseButton?.requestFocus()
                } else {
                    topOverlay.visibility = View.VISIBLE
                    updateClockViews()
                    updateVodProgress()
                    playPauseButton?.requestFocus()
                    scheduleTopOverlayHide()
                }
                return true
            }
        }
        if (!guideOverlay.isVisible) {
            topOverlay.visibility = View.VISIBLE
            scheduleTopOverlayHide()
        }
        return super.dispatchKeyEvent(event)
    }

    private fun moveGuideSelection(delta: Int) {
        if (channels.isEmpty()) return
        selectedGuideIndex = (selectedGuideIndex + delta).coerceIn(0, channels.lastIndex)
        renderGuideOverlay()
        playSelectedChannel()
        scheduleGuideHide()
    }

    private fun showGuideOverlay() {
        if (isVodMode) {
            guideOverlay.visibility = View.GONE
            Log.i("DebridChannels", "VOD_LIVE_GUIDE_GHOST_FIX: blocked_show_guide_in_vod=true")
            return
        }
        guideModeView.text = "QUICK GUIDE"
        guideOverlay.visibility = View.VISIBLE
        updateClockViews()
        renderGuideOverlay()
        scheduleGuideHide()
    }

    private fun hideGuideOverlay() {
        overlayHandler.removeCallbacks(hideGuideRunnable)
        guideOverlay.visibility = View.GONE
        scheduleTopOverlayHide()
    }

    private fun scheduleTopOverlayHide() {
        overlayHandler.removeCallbacks(hideTopOverlayRunnable)
        overlayHandler.postDelayed(hideTopOverlayRunnable, if (isVodMode) 5000L else 4000L)
    }

    private fun scheduleGuideHide() {
        overlayHandler.removeCallbacks(hideGuideRunnable)
        overlayHandler.postDelayed(hideGuideRunnable, 4500)
    }



    private fun findOptionalButton(resourceName: String): Button? {
        val id = resources.getIdentifier(resourceName, "id", packageName)
        return if (id != 0) findViewById(id) else null
    }

    private fun wireVodButtons() {
        rewindButton?.setOnClickListener { seekBackSafely() }
        playPauseButton?.setOnClickListener { toggleVodPlayback(); showVodControls() }
        forwardButton?.setOnClickListener { seekForwardSafely() }
        switchLinkButton?.setOnClickListener { showSwitchLinkOverlay(); showVodControls() }
        subtitlesButton?.setOnClickListener { showSubtitleTrackPicker(); showVodControls() }
        audioButton?.setOnClickListener { showAudioTrackPicker(); showVodControls() }
        episodesButton?.setOnClickListener { openEpisodePickerFromPlayer(); showVodControls() }
        castCrewButton?.setOnClickListener { showCastCrewOverlay(); showVodControls() }
        zoomButton?.setOnClickListener { cycleZoomMode(); showVodControls() }
        settingsButton?.setOnClickListener { showPlayerSettingsPanel(); showVodControls() }
    }


    private fun showSubtitleTrackPicker() {
        val tracks = player?.currentTracks
        val languages = linkedSetOf<String>()
        tracks?.groups?.forEach { group ->
            if (group.type == C.TRACK_TYPE_TEXT) {
                for (i in 0 until group.length) {
                    val fmt = group.getTrackFormat(i)
                    val label = fmt.label?.takeIf { it.isNotBlank() }
                    val lang = fmt.language?.takeIf { it.isNotBlank() }
                    val value = lang ?: label
                    if (!value.isNullOrBlank()) languages.add(value)
                }
            }
        }
        val options = mutableListOf("Off")
        options.addAll(languages.ifEmpty { linkedSetOf("Default / Auto") })
        AlertDialog.Builder(this)
            .setTitle("Subtitles")
            .setItems(options.toTypedArray()) { _, which ->
                val builder = player?.trackSelectionParameters?.buildUpon() ?: return@setItems
                if (which == 0) {
                    player?.trackSelectionParameters = builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                    Toast.makeText(this, "Subtitles off", Toast.LENGTH_SHORT).show()
                } else {
                    val selected = options[which]
                    val lang = selected.takeIf { it != "Default / Auto" }
                    player?.trackSelectionParameters = builder
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                        .setPreferredTextLanguage(lang)
                        .build()
                    Toast.makeText(this, "Subtitles: $selected", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun showAudioTrackPicker() {
        val tracks = player?.currentTracks
        val languages = linkedSetOf<String>()
        tracks?.groups?.forEach { group ->
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (i in 0 until group.length) {
                    val fmt = group.getTrackFormat(i)
                    val label = fmt.label?.takeIf { it.isNotBlank() }
                    val lang = fmt.language?.takeIf { it.isNotBlank() }
                    val value = lang ?: label
                    if (!value.isNullOrBlank()) languages.add(value)
                }
            }
        }
        val options = languages.ifEmpty { linkedSetOf("Default / Auto") }.toList()
        AlertDialog.Builder(this)
            .setTitle("Audio")
            .setItems(options.toTypedArray()) { _, which ->
                val selected = options[which]
                val lang = selected.takeIf { it != "Default / Auto" }
                val builder = player?.trackSelectionParameters?.buildUpon() ?: return@setItems
                player?.trackSelectionParameters = builder.setPreferredAudioLanguage(lang).build()
                Toast.makeText(this, "Audio: $selected", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun showCastCrewOverlay() {
        if (!isVodMode || resumeTitle.isBlank()) {
            Toast.makeText(this, "Cast & Crew is available for VOD titles.", Toast.LENGTH_SHORT).show()
            return
        }
        val options = arrayOf("Open Cast & Crew", "Open media information")
        AlertDialog.Builder(this)
            .setTitle("Cast & Crew")
            .setMessage("View cast, crew, and other movies/shows they have done. The full person filmography opens from the media information cast row.")
            .setItems(options) { _, which ->
                openMediaDetailsForCastCrew()
            }
            .setNegativeButton("Close", null)
            .show()
        Log.i("DebridChannels", "VOD_CAST_CREW_OVERLAY_OPEN: title=${resumeTitle.take(48)} externalId=$resumeExternalId mediaType=$resumeMediaType")
    }

    private fun openMediaDetailsForCastCrew() {
        startActivity(Intent(this, MediaDetailsActivity::class.java).apply {
            putExtra(MediaDetailsActivity.EXTRA_TITLE, resumeTitle)
            putExtra(MediaDetailsActivity.EXTRA_META_LINE, resumeMeta)
            putExtra(MediaDetailsActivity.EXTRA_DESC, resumeOverview)
            putExtra(MediaDetailsActivity.EXTRA_MEDIA_TYPE, resumeMediaType.ifBlank { "movie" })
            putExtra(MediaDetailsActivity.EXTRA_EXTERNAL_ID, resumeExternalId)
            putExtra(MediaDetailsActivity.EXTRA_POSTER_URL, resumePosterUrl)
            putExtra(MediaDetailsActivity.EXTRA_BACKDROP_URL, resumeBackdropUrl)
            putExtra(MediaDetailsActivity.EXTRA_LOGO_URL, resumeLogoUrl)
        })
    }

    private fun openEpisodePickerFromPlayer() {
        if (!isVodMode || resumeTitle.isBlank()) {
            Toast.makeText(this, "Episode picker is available for TV shows.", Toast.LENGTH_SHORT).show()
            return
        }
        if (resumeMediaType.isNotBlank() && !resumeMediaType.equals("series", true) && !resumeMediaType.equals("show", true) && !resumeMediaType.equals("tv", true)) {
            Toast.makeText(this, "Episodes are only available for TV shows.", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, SeasonEpisodeActivity::class.java).apply {
            putExtra(SeasonEpisodeActivity.EXTRA_TITLE, resumeTitle)
            putExtra(SeasonEpisodeActivity.EXTRA_MEDIA_TYPE, "series")
            putExtra(SeasonEpisodeActivity.EXTRA_EXTERNAL_ID, resumeExternalId.ifBlank { resumeTitle })
            putExtra(SeasonEpisodeActivity.EXTRA_POSTER_URL, resumePosterUrl)
            putExtra(SeasonEpisodeActivity.EXTRA_BACKDROP_URL, resumeBackdropUrl.ifBlank { resumePosterUrl })
            putExtra(SeasonEpisodeActivity.EXTRA_LOGO_URL, resumeLogoUrl)
            putExtra(SeasonEpisodeActivity.EXTRA_ITEM_META, resumeMeta)
            putExtra(SeasonEpisodeActivity.EXTRA_DESC, resumeOverview)
        })
    }

    private fun cycleZoomMode() {
        val modes = listOf(
            AspectRatioFrameLayout.RESIZE_MODE_FIT to "Fit",
            AspectRatioFrameLayout.RESIZE_MODE_FILL to "Fill",
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM to "Zoom"
        )
        zoomModeIndex = (zoomModeIndex + 1) % modes.size
        playerView.resizeMode = modes[zoomModeIndex].first
        Toast.makeText(this, "Zoom: ${modes[zoomModeIndex].second}", Toast.LENGTH_SHORT).show()
    }

    private fun showPlayerSettingsPanel() {
        val exo = player ?: return
        val options = mutableListOf<String>()
        val switchIndex = if (isVodMode) options.size.also { options += "Switch Link" } else -1
        val seekIndex = options.size.also { options += "Seek step: ${vodSeekStepMs / 1000}s" }
        val audioBoostIndex = options.size.also { options += "Audio boost: ${String.format(Locale.US, "%.1f", audioBoostLevel)}x" }
        val audioDelayIndex = options.size.also { options += "Voice sync: ${audioDelayMs}ms" }
        val subtitleDelayIndex = options.size.also { options += "Subtitle sync: ${subtitleDelayMs}ms" }
        val speedIndex = options.size.also { options += if (exo.playbackParameters.speed == 1f) "Speed: 1.25x" else "Speed: 1.0x" }
        val audioTrackIndex = options.size.also { options += "Audio tracks" }
        val subtitleTrackIndex = options.size.also { options += "Subtitle tracks" }
        val zoomIndex = options.size.also { options += "Zoom / Aspect" }
        val debugIndex = options.size.also { options += "HDR / Audio info" }
        val repeatIndex = options.size.also { options += if (exo.repeatMode == androidx.media3.common.Player.REPEAT_MODE_OFF) "Repeat: On" else "Repeat: Off" }
        val restartIndex = options.size.also { options += "Restart from beginning" }
        val clearResumeIndex = if (isVodMode) options.size.also { options += "Clear resume position" } else -1
        AlertDialog.Builder(this)
            .setTitle("Player Settings")
            .setItems(options.toTypedArray()) { _, which ->
                when (which) {
                    switchIndex -> showSwitchLinkOverlay()
                    seekIndex -> showSeekStepPicker()
                    audioBoostIndex -> showAudioBoostPicker()
                    audioDelayIndex -> showAudioDelayPicker()
                    subtitleDelayIndex -> showSubtitleDelayPicker()
                    speedIndex -> {
                        val nextSpeed = if (exo.playbackParameters.speed == 1f) 1.25f else 1f
                        exo.setPlaybackSpeed(nextSpeed)
                        Toast.makeText(this, "Speed: ${nextSpeed}x", Toast.LENGTH_SHORT).show()
                    }
                    audioTrackIndex -> showAudioTrackPicker()
                    subtitleTrackIndex -> showSubtitleTrackPicker()
                    zoomIndex -> cycleZoomMode()
                    debugIndex -> showPlayerDebugInfo()
                    repeatIndex -> {
                        exo.repeatMode = if (exo.repeatMode == androidx.media3.common.Player.REPEAT_MODE_OFF) androidx.media3.common.Player.REPEAT_MODE_ONE else androidx.media3.common.Player.REPEAT_MODE_OFF
                        Toast.makeText(this, if (exo.repeatMode == androidx.media3.common.Player.REPEAT_MODE_ONE) "Repeat on" else "Repeat off", Toast.LENGTH_SHORT).show()
                    }
                    restartIndex -> exo.seekTo(0)
                    clearResumeIndex -> {
                        clearResumeProgress()
                        Toast.makeText(this, "Resume position cleared", Toast.LENGTH_SHORT).show()
                    }
                }
                showVodControls()
            }
            .show()
    }

    private fun showSeekStepPicker() {
        val steps = longArrayOf(5_000L, 10_000L, 30_000L, 60_000L)
        val labels = steps.map { "${it / 1000}s" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Seek step")
            .setItems(labels) { _, which ->
                vodSeekStepMs = steps[which]
                rewindButton?.text = "-${vodSeekStepMs / 1000}"
                forwardButton?.text = "+${vodSeekStepMs / 1000}"
                Log.i("DebridChannels", "VOD_SEEK_STEP_APPLY: ${vodSeekStepMs}ms")
                showVodControls()
            }
            .show()
    }

    private fun showAudioBoostPicker() {
        val values = floatArrayOf(1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
        val labels = values.map { "${String.format(Locale.US, "%.2f", it)}x" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Audio boost")
            .setItems(labels) { _, which ->
                audioBoostLevel = values[which]
                player?.volume = audioBoostLevel
                Log.i("DebridChannels", "VOD_AUDIO_BOOST_APPLY: level=$audioBoostLevel")
                Toast.makeText(this, "Audio boost: ${labels[which]}", Toast.LENGTH_SHORT).show()
                showVodControls()
            }
            .show()
    }

    private fun showAudioDelayPicker() {
        val values = longArrayOf(-500L, -250L, -100L, 0L, 100L, 250L, 500L)
        val labels = values.map { if (it == 0L) "0ms" else "${it}ms" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Voice sync")
            .setItems(labels) { _, which ->
                audioDelayMs = values[which]
                Log.i("DebridChannels", "VOD_AUDIO_DELAY_SET: ${audioDelayMs}ms")
                Toast.makeText(this, "Voice sync: ${labels[which]}", Toast.LENGTH_SHORT).show()
                showVodControls()
            }
            .show()
    }

    private fun showSubtitleDelayPicker() {
        val values = longArrayOf(-1000L, -500L, -250L, 0L, 250L, 500L, 1000L)
        val labels = values.map { if (it == 0L) "0ms" else "${it}ms" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Subtitle sync")
            .setItems(labels) { _, which ->
                subtitleDelayMs = values[which]
                Log.i("DebridChannels", "VOD_SUBTITLE_DELAY_SET: ${subtitleDelayMs}ms")
                Toast.makeText(this, "Subtitle sync: ${labels[which]}", Toast.LENGTH_SHORT).show()
                showVodControls()
            }
            .show()
    }

    private fun showPlayerDebugInfo() {
        val exo = player ?: return
        val video = exo.videoFormat
        val audio = exo.audioFormat
        val message = listOf(
            "Video: ${video?.sampleMimeType ?: "unknown"} ${video?.width ?: 0}x${video?.height ?: 0}",
            "Frame rate: ${video?.frameRate ?: 0f}",
            "HDR: ${video?.colorInfo?.colorTransfer ?: "unknown"}",
            "Audio: ${audio?.sampleMimeType ?: "unknown"} ${audio?.channelCount ?: 0}ch",
            "Audio mode: ${runCatching { SettingsRepository(this).loadPlayback().audioOutputMode }.getOrDefault("Auto")}",
            "Audio fallback: ${if (safeStereoAudioFallbackActive) "safe stereo active" else "normal"}",
            "Source: ${currentSourceLabel.ifBlank { "Direct" }}"
        ).joinToString("\n")
        AlertDialog.Builder(this)
            .setTitle("HDR / Audio Info")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showSwitchLinkOverlay() {
        if (!isVodMode) return
        val title = resumeTitle.ifBlank { intent.getStringExtra(EXTRA_TITLE).orEmpty() }
        val externalId = resumeExternalId.ifBlank { title }
        val mediaType = resumeMediaType.ifBlank { intent.getStringExtra(EXTRA_MEDIA_TYPE).orEmpty() }
        if (title.isBlank()) {
            Toast.makeText(this, "Unable to load alternate links for this item", Toast.LENGTH_SHORT).show()
            return
        }
        val currentPosition = player?.currentPosition ?: 0L
        Toast.makeText(this, "Loading available links…", Toast.LENGTH_SHORT).show()
        Log.i("DebridChannels", "VOD_SWITCH_LINKS: loading title=$title externalId=$externalId mediaType=$mediaType")
        sourceSwitchExecutor.execute {
            val repo = SettingsRepository(this)
            val addons = repo.loadStremioAddons()
            val playback = repo.loadPlayback()
            val options = runCatching { StreamingPipelineResolver().listCandidates(title, externalId, mediaType, addons, playback) }.getOrDefault(emptyList())
            overlayHandler.post {
                if (isFinishing || isDestroyed) return@post
                if (options.isEmpty()) {
                    Toast.makeText(this, "No alternate links found", Toast.LENGTH_LONG).show()
                    Log.i("DebridChannels", "VOD_SWITCH_LINKS: no_options")
                    return@post
                }
                val labels = options.map { sourceOptionLabel(it) }.toTypedArray()
                AlertDialog.Builder(this)
                    .setTitle("Switch Link")
                    .setItems(labels) { _, index ->
                        resolveAndSwitchLink(index, options.getOrNull(index), currentPosition)
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }
    }

    private fun resolveAndSwitchLink(index: Int, option: StreamingPipelineResolver.StreamOption?, resumePositionMs: Long) {
        val title = resumeTitle.ifBlank { intent.getStringExtra(EXTRA_TITLE).orEmpty() }
        val externalId = resumeExternalId.ifBlank { title }
        val mediaType = resumeMediaType.ifBlank { intent.getStringExtra(EXTRA_MEDIA_TYPE).orEmpty() }
        Toast.makeText(this, "Resolving link…", Toast.LENGTH_SHORT).show()
        Log.i("DebridChannels", "VOD_SWITCH_LINKS: resolve index=$index label=${option?.sourceLabel.orEmpty()}")
        sourceSwitchExecutor.execute {
            val repo = SettingsRepository(this)
            val addons = repo.loadStremioAddons()
            val debrid = repo.loadDebrid()
            val playback = repo.loadPlayback()
            val resolved = runCatching { StreamingPipelineResolver().resolveAtIndexWithFallback(title, externalId, mediaType, addons, debrid, playback, index) }.getOrNull()
            overlayHandler.post {
                if (isFinishing || isDestroyed) return@post
                if (resolved == null || resolved.url.isBlank()) {
                    Toast.makeText(this, "Unable to resolve selected link", Toast.LENGTH_LONG).show()
                    Log.w("DebridChannels", "VOD_SWITCH_LINKS: resolve_failed index=$index")
                    return@post
                }
                switchVodMediaItem(resolved.url, resolved.sourceLabel, resolved.debugLabel, option, resumePositionMs)
            }
        }
    }

    private fun switchVodMediaItem(url: String, sourceLabel: String, debugLabel: String, option: StreamingPipelineResolver.StreamOption?, resumePositionMs: Long) {
        val exo = player ?: return
        saveResumeProgress(resumePositionMs, exo.duration.takeIf { it > 0 } ?: 0L)
        currentStreamUrl = url
        currentSourceLabel = sourceLabel
        currentDebugLabel = debugLabel
        resumeStreamUrl = url
        val sourceMeta = listOf(option?.qualityLabel.orEmpty(), if (option?.isDolbyVision == true) "Dolby Vision" else "", option?.sizeLabel.orEmpty()).filter { it.isNotBlank() }.joinToString(" • ")
        if (sourceMeta.isNotBlank()) {
            vodMetaLineView.text = listOf(vodMetaLineView.text?.toString().orEmpty(), sourceMeta).filter { it.isNotBlank() }.distinct().joinToString("  •  ")
        }
        val mediaItemBuilder = MediaItem.Builder().setUri(Uri.parse(url))
        val lower = url.lowercase(Locale.US)
        when {
            lower.contains(".m3u8") -> mediaItemBuilder.setMimeType(MimeTypes.APPLICATION_M3U8)
            lower.contains(".mpd") -> mediaItemBuilder.setMimeType(MimeTypes.APPLICATION_MPD)
            lower.contains(".mp4") -> mediaItemBuilder.setMimeType(MimeTypes.VIDEO_MP4)
            lower.contains(".ts") -> mediaItemBuilder.setMimeType(MimeTypes.VIDEO_MP2T)
        }
        Log.i("DebridChannels", "VOD_SWITCH_LINKS: applying url=${url.take(72)} seekMs=$resumePositionMs source=$sourceLabel")
        exo.playWhenReady = false
        runCatching { exo.stop() }
        runCatching { exo.clearMediaItems() }
        exo.setMediaItem(mediaItemBuilder.build(), resumePositionMs.coerceAtLeast(0L))
        exo.prepare()
        exo.playWhenReady = true
        statusView.text = "Switched link"
        Toast.makeText(this, "Link switched", Toast.LENGTH_SHORT).show()
        showVodControls()
    }

    private fun sourceOptionLabel(option: StreamingPipelineResolver.StreamOption): String {
        val parts = mutableListOf<String>()
        if (option.qualityLabel.isNotBlank()) parts += option.qualityLabel
        if (option.isDolbyVision) parts += "Dolby Vision"
        if (option.sizeLabel.isNotBlank()) parts += option.sizeLabel
        if (option.sourceLabel.isNotBlank()) parts += option.sourceLabel
        val title = option.displayTitle.replace(Regex("\\s+"), " ").replace("|", " • ").trim()
        if (title.isNotBlank()) parts += title
        return parts.distinct().joinToString(" • ").ifBlank { "Alternate link" }
    }

    private fun promptResumeIfAvailable() {
        if (!isVodMode) return
        val info = loadResumeProgress() ?: return
        val exo = player ?: return
        if (info.positionMs < 30_000L || info.durationMs <= 0L) return
        if (exo.currentPosition > 10_000L) return
        val behavior = runCatching { SettingsRepository(this).loadPlayback().resumeBehavior }.getOrDefault("Ask to resume")
        when {
            behavior.equals("Always start from beginning", true) -> {
                clearResumeProgress()
                player?.seekTo(0)
                player?.playWhenReady = true
                Log.i("DebridChannels", "VOD_RESUME_BEHAVIOR: start_over")
            }
            behavior.equals("Ask to resume", true) -> {
                val message = "Resume from ${formatDuration(info.positionMs)}?"
                Log.i("DebridChannels", "VOD_RESUME_PROMPT: position=${info.positionMs} duration=${info.durationMs}")
                AlertDialog.Builder(this)
                    .setTitle("Resume playback")
                    .setMessage(message)
                    .setPositiveButton("Resume") { _, _ ->
                        player?.seekTo(info.positionMs)
                        player?.playWhenReady = true
                        Log.i("DebridChannels", "VOD_RESUME_APPLIED: position=${info.positionMs}")
                    }
                    .setNegativeButton("Start Over") { _, _ ->
                        clearResumeProgress()
                        player?.seekTo(0)
                        player?.playWhenReady = true
                    }
                    .show()
            }
            behavior.equals("Auto resume", true) && !xgimiAudioCompatibilityDevice -> {
                player?.seekTo(info.positionMs)
                player?.playWhenReady = true
                Log.i("DebridChannels", "VOD_RESUME_BEHAVIOR: auto_resume position=${info.positionMs}")
            }
            else -> {
                Log.i("DebridChannels", "VOD_RESUME_BEHAVIOR: safe_default_no_silent_seek position=${info.positionMs} xgimiCompat=$xgimiAudioCompatibilityDevice")
                AlertDialog.Builder(this)
                    .setTitle("Resume playback")
                    .setMessage("Resume from ${formatDuration(info.positionMs)}?")
                    .setPositiveButton("Resume") { _, _ ->
                        player?.seekTo(info.positionMs)
                        player?.playWhenReady = true
                        Log.i("DebridChannels", "VOD_RESUME_APPLIED: position=${info.positionMs}")
                    }
                    .setNegativeButton("Start Over") { _, _ ->
                        clearResumeProgress()
                        player?.seekTo(0)
                        player?.playWhenReady = true
                    }
                    .show()
            }
        }
    }

    private data class ResumeInfo(val positionMs: Long, val durationMs: Long)

    private fun loadResumeProgress(): ResumeInfo? {
        val key = resumeStreamUrl.ifBlank { resumeTitle }
        if (key.isBlank()) return null
        val arr = JSONArray(getSharedPreferences("continue_watching", MODE_PRIVATE).getString("items", "[]") ?: "[]")
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val matches = obj.optString("streamUrl") == key || obj.optString("title") == resumeTitle || obj.optString("externalId") == resumeExternalId
            if (matches) {
                val position = obj.optLong("positionMs", 0L)
                val duration = obj.optLong("durationMs", 0L)
                if (position > 0L) return ResumeInfo(position, duration)
            }
        }
        return null
    }

    private fun clearResumeProgress() {
        val prefs = getSharedPreferences("continue_watching", MODE_PRIVATE)
        val arr = JSONArray(prefs.getString("items", "[]") ?: "[]")
        val out = JSONArray()
        val key = resumeStreamUrl.ifBlank { resumeTitle }
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val matches = obj.optString("streamUrl") == key || obj.optString("title") == resumeTitle || obj.optString("externalId") == resumeExternalId
            if (!matches) out.put(obj)
        }
        prefs.edit().putString("items", out.toString()).apply()
        Log.i("DebridChannels", "VOD_RESUME_CLEARED: title=$resumeTitle")
    }

    private fun showVodControls() {
        if (shouldSuppressVodOverlay() && !topOverlay.isVisible) {
            Log.i("DebridChannels", "VOD_SHOW_CONTROLS_BLOCKED_DURING_HIDDEN_SCRUB")
            return
        }
        topOverlay.visibility = View.VISIBLE
        updateVodProgress()
        if (!currentFocusIsVodButton()) {
            playPauseButton?.requestFocus()
        }
        scheduleTopOverlayHide()
    }

    private fun toggleVodPlayback() {
        val exo = player ?: return
        if (exo.isPlaying) {
            exo.pause()
            if (!isVodMode) {
                livePauseStartedAtMs = System.currentTimeMillis()
                statusView.text = "Paused live TV"
            }
        } else {
            livePauseStartedAtMs = 0L
            exo.play()
            if (!isVodMode) statusView.text = ""
        }
        updateVodProgress()
    }

    private fun updateVodProgress() {
        val exo = player ?: return
        if (!isVodMode) {
            timeshiftSession?.updateFromPlayer(exo)
            val duration = exo.duration
            val position = exo.currentPosition.coerceAtLeast(0L)
            val isSeekable = duration != C.TIME_UNSET && duration > 0L && exo.isCurrentMediaItemSeekable
            if (isSeekable) {
                progressView.progress = ((position.toDouble() / duration.toDouble()) * 100).toInt().coerceIn(0, 100)
                currentTimeView.text = "-${formatDuration((duration - position).coerceAtLeast(0L))}"
                durationView.text = timeshiftStatusLabel()
                rewindButton?.isEnabled = true
                forwardButton?.isEnabled = true
            } else {
                progressView.progress = if (exo.isLoading) 35 else 100
                currentTimeView.text = "LIVE"
                durationView.text = timeshiftStatusLabel()
                rewindButton?.isEnabled = true
                forwardButton?.isEnabled = true
            }
            if (!exo.isPlaying && livePauseStartedAtMs > 0L) {
                val pausedFor = ((System.currentTimeMillis() - livePauseStartedAtMs) / 1000L).coerceAtLeast(0L)
                statusView.text = "Paused live TV • ${pausedFor}s"
            }
            playPauseButton?.text = if (exo.isPlaying) "Pause" else "Play"
            return
        }
        val duration = exo.duration.takeIf { it > 0 } ?: 0L
        val position = exo.currentPosition.coerceAtLeast(0L)
        if (duration > 0L) {
            progressView.progress = ((position.toDouble() / duration.toDouble()) * 100).toInt().coerceIn(0, 100)
            durationView.text = formatDuration(duration)
        } else {
            progressView.progress = 0
            durationView.text = "--:--"
        }
        updateVodCacheStatus(exo, duration)
        currentTimeView.text = formatDuration(position)
        playPauseButton?.text = if (exo.isPlaying) "Pause" else "Play"
        saveResumeProgress(position, duration)
    }

    private fun saveResumeProgress(position: Long, duration: Long) {
        if (!isVodMode || duration <= 0L || resumeStreamUrl.isBlank()) return
        val progress = (position.toDouble() / duration.toDouble()).coerceIn(0.0, 1.0)
        val prefs = getSharedPreferences("continue_watching", MODE_PRIVATE)
        val arr = org.json.JSONArray(prefs.getString("items", "[]") ?: "[]")
        val out = org.json.JSONArray()
        val key = resumeStreamUrl.ifBlank { resumeTitle }
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            if (obj.optString("streamUrl") != key && obj.optString("title") != resumeTitle) out.put(obj)
        }
        if (progress >= 0.93) {
            prefs.edit().putString("items", out.toString()).apply()
            Log.i("DebridChannels", "VOD_RESUME_COMPLETED_CLEAR: title=$resumeTitle")
            return
        }
        if (progress in 0.03..0.92) {
            out.put(org.json.JSONObject()
                .put("title", resumeTitle.ifBlank { "Playback" })
                .put("type", "movie")
                .put("meta", resumeMeta)
                .put("overview", resumeOverview)
                .put("posterUrl", resumePosterUrl)
                .put("backdropUrl", resumeBackdropUrl)
                .put("logoUrl", resumeLogoUrl)
                .put("streamUrl", resumeStreamUrl)
                .put("externalId", resumeStreamUrl)
                .put("progress", progress)
                .put("positionMs", position)
                .put("durationMs", duration)
                .put("updatedAt", System.currentTimeMillis()))
        }
        prefs.edit().putString("items", out.toString()).apply()
    }

    private fun formatDuration(ms: Long): String {
        val totalSeconds = (ms / 1000L).coerceAtLeast(0L)
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0) "%d:%02d:%02d".format(hours, minutes, seconds) else "%d:%02d".format(minutes, seconds)
    }

    private fun playSelectedChannel() {
        val target = channels.getOrNull(selectedGuideIndex) ?: return
        currentIndex = selectedGuideIndex
        currentSourceLabel = target.source
        currentDebugLabel = target.debug
        currentStreamUrl = target.url
        currentStreamSeekable = false
        channelsDvrNativeMode = false
        titleView.text = target.name
        statusView.text = ""
        durationView.text = timeshiftStatusLabel()
        bindLiveChannelLogo(target)
        bindProgramMeta(target)
        val mediaItemBuilder = MediaItem.Builder().setUri(Uri.parse(target.url))
        mediaItemBuilder.setLiveConfiguration(
            MediaItem.LiveConfiguration.Builder()
                .setTargetOffsetMs(if (isChannelsDvrSource()) 8000 else 5000)
                .setMinOffsetMs(1500)
                .setMaxOffsetMs(30_000L)
                .build()
        )
        if (looksLikeTsStream(target.url)) {
            mediaItemBuilder.setMimeType(MimeTypes.VIDEO_MP2T)
        }
        player?.apply {
            playWhenReady = false
            runCatching { stop() }
            runCatching { clearMediaItems() }
            setMediaItem(mediaItemBuilder.build(), true)
            seekToDefaultPosition()
            prepare()
            playWhenReady = true
        }
    }

    private fun bindProgramMeta(channel: GuideChannel?) {
        val now = Calendar.getInstance()
        val formatter = SimpleDateFormat("h:mm a", Locale.US)
        val activeName = channel?.programTitle?.takeIf { it.isNotBlank() } ?: channel?.name ?: "Live TV"
        val startMillis = channel?.programStartMillis?.takeIf { it > 0L } ?: run {
            val start = now.clone() as Calendar
            start.add(Calendar.MINUTE, -(now.get(Calendar.MINUTE) % 30))
            start.timeInMillis
        }
        val endMillis = channel?.programEndMillis?.takeIf { it > startMillis } ?: (startMillis + 30L * 60L * 1000L)
        val nextMillis = endMillis
        nowTimeView.text = "${formatter.format(Date(startMillis))} – ${formatter.format(Date(endMillis))}"
        titleView.text = activeName
        metaTextView.text = channel?.programDescription?.takeIf { it.isNotBlank() } ?: "Live TV"
        statusView.text = ""
        val pct = (((System.currentTimeMillis() - startMillis).toDouble() / (endMillis - startMillis).toDouble()) * 100).toInt().coerceIn(4, 96)
        progressView.progress = pct
        val nextTitle = channel?.nextTitle?.takeIf { it.isNotBlank() } ?: "${channel?.name ?: "Live TV"} Up Next"
        nextView.text = "NEXT  ${formatter.format(Date(nextMillis))}  $nextTitle"
    }

    private fun renderGuideOverlay() {
        if (isVodMode) {
            guideOverlay.visibility = View.GONE
            return
        }
        val selected = channels.getOrNull(selectedGuideIndex)
        guideTitleView.text = selected?.name ?: "Live TV Guide"
        guideMetaView.text = selected?.let { "${it.source} • Instant tune enabled" } ?: "Browse channels while video keeps playing"
        guideHintView.text = "LEFT/RIGHT change channel instantly • UP/BACK close"
        guideInfoLogoView.text = (selected?.name ?: "TV").take(2).uppercase(Locale.US)

        guideList.removeAllViews()
        if (channels.isEmpty()) {
            guideList.addView(makeGuideCard("No guide data", "", false))
            return
        }
        val start = (selectedGuideIndex - 2).coerceAtLeast(0)
        val end = (start + 5).coerceAtMost(channels.lastIndex)
        for (index in start..end) {
            val channel = channels[index]
            guideList.addView(makeGuideCard(channel.name, channel.iconUrl, index == selectedGuideIndex))
        }
        guideScroller.post {
            val focusedChild = guideList.getChildAt((selectedGuideIndex - start).coerceAtLeast(0))
            if (focusedChild != null) {
                val scroll = (focusedChild.left - dp(24)).coerceAtLeast(0)
                guideScroller.smoothScrollTo(scroll, 0)
            }
        }
    }

    private fun makeGuideCard(title: String, iconUrl: String, selected: Boolean): View {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM or Gravity.START
            background = getDrawable(if (selected) R.drawable.focus_ring_pill_pulse else R.drawable.pill_dark)
            setPadding(dp(18), dp(12), dp(18), dp(14))
            layoutParams = LinearLayout.LayoutParams(dp(240), dp(112)).apply {
                rightMargin = dp(14)
            }
        }
        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val icon = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(10) }
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(2), dp(2), dp(2), dp(2))
            visibility = if (iconUrl.isBlank()) View.GONE else View.VISIBLE
        }
        if (iconUrl.isNotBlank()) {
            runCatching { Glide.with(this).load(com.channelsdebrid.tv.net.BackendEndpoint.imageProxyUrl(iconUrl)).fitCenter().into(icon) }
        }
        val subtitleView = TextView(this).apply {
            text = "Live now"
            setTextColor(0xFFC8D1DC.toInt())
            textSize = 13f
        }
        topRow.addView(icon)
        topRow.addView(subtitleView)
        val titleView = TextView(this).apply {
            text = title
            setTextColor(0xFFFFFFFF.toInt())
            textSize = if (selected) 20f else 17f
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        container.addView(topRow)
        container.addView(titleView)
        return container
    }

    private fun updateClockViews() {
        val formatter = SimpleDateFormat("h:mm a", Locale.US)
        val value = formatter.format(Date())
        clockView.text = value
        guideClockView.text = value
    }

    private fun decodeChannels(json: String?): List<GuideChannel> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(json)
            mutableListOf<GuideChannel>().apply {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    add(
                        GuideChannel(
                            name = obj.optString("name"),
                            url = obj.optString("url"),
                            source = obj.optString("source"),
                            debug = obj.optString("debug"),
                            iconUrl = obj.optString("iconUrl"),
                            programTitle = obj.optString("programTitle"),
                            programDescription = obj.optString("programDescription"),
                            programStartMillis = obj.optLong("programStartMillis"),
                            programEndMillis = obj.optLong("programEndMillis"),
                            nextTitle = obj.optString("nextTitle")
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun inferPlaybackMimeType(url: String): String? {
        val lower = url.lowercase(Locale.US).substringBefore("?")
        return when {
            lower.endsWith(".m3u8") || lower.contains("m3u8") || lower.contains("/hls/") -> MimeTypes.APPLICATION_M3U8
            lower.endsWith(".mpd") || lower.contains("/dash/") -> MimeTypes.APPLICATION_MPD
            lower.endsWith(".ts") || lower.endsWith(".mpegts") || lower.endsWith(".mpg") || lower.contains("format=ts") || lower.contains("/auto/v") || lower.contains("hdhomerun") -> MimeTypes.VIDEO_MP2T
            lower.endsWith(".mp4") || lower.contains("format=mp4") -> MimeTypes.VIDEO_MP4
            lower.endsWith(".webm") || lower.endsWith(".mkv") -> MimeTypes.VIDEO_WEBM
            else -> null
        }
    }

    private fun looksLikeTsStream(url: String): Boolean {
        return inferPlaybackMimeType(url) == MimeTypes.VIDEO_MP2T
    }

    @Deprecated("Deprecated in Android API; kept for compatibility with the current project toolchain")
    override fun onBackPressed() {
        setResult(RESULT_OK)
        finish()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        Log.i("DebridChannels", "PlayerOwner duplicate launch received; closing current player cleanly")
        setResult(RESULT_CANCELED)
        finish()
    }

    override fun onStart() {
        super.onStart()
        player?.playWhenReady = true
    }

    override fun onPause() {
        player?.playWhenReady = false
        player?.pause()
        super.onPause()
    }

    override fun onStop() {
        releasePlayerResources()
        super.onStop()
    }

    override fun onDestroy() {
        releasePlayerResources()
        vodPrefetchCancelled = true
        runCatching { vodPrefetchExecutor.shutdownNow() }
        runCatching { sourceSwitchExecutor.shutdownNow() }
        runCatching { nasMirrorExecutor.shutdownNow() }
        super.onDestroy()
    }

    private fun releasePlayerResources() {
        if (resourcesReleased) return
        Log.i("DebridChannels", "PLAYER_RELEASE: releasing resources vod=$isVodMode firstFrame=$firstFrameLogged cacheTee=${vodTeeStorage != null} usbCache=${vodCacheDir != null}")
        resourcesReleased = true
        overlayHandler.removeCallbacks(updateVodProgressRunnable)
        overlayHandler.removeCallbacksAndMessages(null)
        unregisterAudioRouteProtection()
        runCatching { playerView.keepScreenOn = false }
        runCatching { playerView.player = null }
        val exo = player
        player = null
        runCatching { exo?.stop() }
        runCatching { exo?.clearMediaItems() }
        runCatching { exo?.release() }
        vodPrefetchCancelled = true
        runCatching { vodProxySession?.stop(deletePartial = true) }
        vodProxySession = null
        runCatching {
            val storage = vodTeeStorage
            val name = vodTeeCacheName
            if (storage != null && !name.isNullOrBlank()) {
                val folder = storage.nasPath.trimEnd('/') + "/DebridChannelsVodCache"
                SmbNasBrowser(storage.nasHost, storage.nasUsername, storage.nasPassword).deleteFile(folder, name)
                SmbNasBrowser(storage.nasHost, storage.nasUsername, storage.nasPassword).deleteFile(folder, "vod_cache_manifest.txt")
                Log.i("DebridChannels", "VOD_CACHE_TEE: cleanup_deleted file=$name")
            }
        }
        vodTeeStorage = null
        vodTeeCacheName = null
        runCatching { timeshiftSession?.close() }
        timeshiftSession = null
        val cache = liveTimeshiftCache
        liveTimeshiftCache = null
        runCatching { cache?.release() }
        val vodCache = vodDiskCache
        vodDiskCache = null
        runCatching { vodCache?.release() }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    data class GuideChannel(
        val name: String,
        val url: String,
        val source: String,
        val debug: String,
        val iconUrl: String = "",
        val programTitle: String = "",
        val programDescription: String = "",
        val programStartMillis: Long = 0L,
        val programEndMillis: Long = 0L,
        val nextTitle: String = ""
    )

    companion object {
        const val EXTRA_STREAM_URL = "stream_url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_MEDIA_TYPE = "media_type"
        const val EXTRA_EXTERNAL_ID = "external_id"
        const val EXTRA_SOURCE_LABEL = "source_label"
        const val EXTRA_ARTWORK_URL = "artwork_url"
        const val EXTRA_LOGO_URL = "logo_url"
        const val EXTRA_POSTER_URL = "poster_url"
        const val EXTRA_META_LINE = "meta_line"
        const val EXTRA_MEDIA_META_LINE = "media_meta_line"
        const val EXTRA_OVERVIEW = "overview"
        const val EXTRA_DEBUG_LABEL = "debug_label"
        const val EXTRA_CHANNELS_JSON = "channels_json"
        const val EXTRA_CHANNEL_INDEX = "channel_index"
        const val EXTRA_VOD_MODE = "vod_mode"
    }
}
