NewtoOld_v2.8.26.1_FULL_BRAND_PURGE_QR_PROFILES_STARTUP_ICON

versionCode: 282177
versionName: NewtoOld_v2.8.26.18_TRUE_HERO_POSTER_DEPTH_LAYER_ROW_LOGO_LEFT_MATH_FIX

Final playback hardening build with adaptive buffering, safe watchdog, silent rebuffer, decoder/source reliability memory, audio-route debounce, and session stability mode.

Verify logcat marker:
DC_BUILD_MARKER: NewtoOld_v2.8.26.1_FULL_BRAND_PURGE_QR_PROFILES_STARTUP_ICON
