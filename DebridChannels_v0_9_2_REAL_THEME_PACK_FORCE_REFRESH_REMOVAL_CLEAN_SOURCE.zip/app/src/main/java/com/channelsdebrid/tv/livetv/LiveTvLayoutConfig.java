package com.channelsdebrid.tv.livetv;

import android.graphics.Color;

/** v0.9.2 real Live TV theme pack. Reference screenshots are used for layout only. */
public final class LiveTvLayoutConfig {
    public final String id;
    public String name;
    public final boolean compact;
    public int catLeft, catTop, catWidth, catHeight;
    public int mainLeft, mainTop, mainWidth, mainHeight;
    public int fullLeft, fullTop, fullWidth, fullHeight;
    public int headerHeight, logoTileW, logoTileH, titleSp, metaSp, descSp;
    public int previewWidth, previewTop, previewRight, previewPadding, previewRadius;
    public int timelineHeight, timelineLeftPadding;
    public int[] tickWidths;
    public int redLineX, wideWidth, rowLogoWidth, nowCellWidth, nextCellWidth, laterCellWidth, farCellWidth;
    public int rowHeight, rowCellHeight, rowGap, visibleRows;
    public int categoryIconSize, categoryRowHeight, categoryTextSp, categorySubTextSp;
    public int refreshWidth, refreshHeight, refreshBottom;
    public int rootScrimLeft, rootScrimMid, rootScrimRight;
    public int guideCellColor, guideCellAltColor, guideFocusTextColor, guideFocusBgColor;
    public int categoryFocusBgColor, categoryFocusTextColor, radius;
    public boolean forceRefreshVisible, showTopMenuArtifacts, copyReferenceProfileImages;

    private LiveTvLayoutConfig(String id, String name, boolean compact) { this.id=id; this.name=name; this.compact=compact; }

    public static LiveTvLayoutConfig preset(int themeMode, boolean fourKCompact, int rows) {
        int theme=Math.max(0,Math.min(5,themeMode));
        LiveTvLayoutConfig c=base(theme,fourKCompact);
        c.visibleRows=Math.max(3,Math.min(7,rows));
        applyTheme(c,theme,fourKCompact);
        c.forceRefreshVisible=false;
        c.showTopMenuArtifacts=false;
        c.copyReferenceProfileImages=false;
        return c;
    }

    private static LiveTvLayoutConfig base(int theme, boolean fourK) {
        LiveTvLayoutConfig c=new LiveTvLayoutConfig(themeId(theme),themeName(theme),fourK);
        if(fourK){
            c.catLeft=56;c.catTop=132;c.catWidth=390;c.catHeight=828;c.mainLeft=468;c.mainTop=100;c.mainWidth=1392;c.mainHeight=900;c.fullLeft=44;c.fullTop=88;c.fullWidth=1836;c.fullHeight=958;
            c.headerHeight=268;c.logoTileW=64;c.logoTileH=48;c.titleSp=48;c.metaSp=17;c.descSp=14;c.previewWidth=384;c.previewTop=104;c.previewRight=58;c.previewPadding=8;c.previewRadius=18;
            c.timelineHeight=42;c.timelineLeftPadding=94;c.tickWidths=new int[]{170,210,242,242,242,242};c.redLineX=300;c.wideWidth=1788;c.rowLogoWidth=86;c.nowCellWidth=560;c.nextCellWidth=362;c.laterCellWidth=362;c.farCellWidth=340;
            c.rowHeight=68;c.rowCellHeight=54;c.rowGap=3;c.categoryIconSize=58;c.categoryRowHeight=74;c.categoryTextSp=18;c.categorySubTextSp=14;
        }else{
            c.catLeft=34;c.catTop=124;c.catWidth=330;c.catHeight=902;c.mainLeft=388;c.mainTop=92;c.mainWidth=1500;c.mainHeight=956;c.fullLeft=28;c.fullTop=84;c.fullWidth=1864;c.fullHeight=978;
            c.headerHeight=242;c.logoTileW=60;c.logoTileH=46;c.titleSp=46;c.metaSp=16;c.descSp=13;c.previewWidth=322;c.previewTop=104;c.previewRight=38;c.previewPadding=8;c.previewRadius=18;
            c.timelineHeight=38;c.timelineLeftPadding=88;c.tickWidths=new int[]{132,168,196,196,196,196};c.redLineX=245;c.wideWidth=1460;c.rowLogoWidth=72;c.nowCellWidth=455;c.nextCellWidth=300;c.laterCellWidth=300;c.farCellWidth=240;
            c.rowHeight=58;c.rowCellHeight=46;c.rowGap=3;c.categoryIconSize=48;c.categoryRowHeight=62;c.categoryTextSp=18;c.categorySubTextSp=14;
        }
        c.refreshWidth=0;c.refreshHeight=0;c.refreshBottom=0;c.forceRefreshVisible=false;
        c.rootScrimLeft=Color.argb(252,0,0,0);c.rootScrimMid=Color.argb(236,5,5,7);c.rootScrimRight=Color.argb(238,0,0,0);
        c.guideCellColor=Color.argb(122,22,23,29);c.guideCellAltColor=Color.argb(104,22,23,29);c.guideFocusBgColor=Color.rgb(238,240,246);c.guideFocusTextColor=Color.rgb(25,26,30);
        c.categoryFocusBgColor=Color.rgb(238,240,246);c.categoryFocusTextColor=Color.rgb(24,25,29);c.radius=12;
        return c;
    }

    private static void applyTheme(LiveTvLayoutConfig c, int theme, boolean fourK) {
        switch(theme){
            case 1: c.name="Google Free TV"; c.catWidth+=fourK?8:6; c.mainLeft+=fourK?12:8; c.headerHeight+=fourK?10:8; c.previewWidth=fourK?410:330; c.previewTop=fourK?108:106; c.nowCellWidth+=fourK?20:16; c.nextCellWidth+=fourK?22:18; c.laterCellWidth+=fourK?22:18; c.guideCellColor=Color.argb(116,22,23,29); c.guideCellAltColor=Color.argb(96,22,23,29); c.radius=14; break;
            case 2: c.name="TiviMate Pro"; c.catWidth=fourK?410:360; c.mainLeft=fourK?430:356; c.mainTop=fourK?72:62; c.mainWidth=fourK?1438:1528; c.headerHeight=fourK?252:230; c.previewWidth=fourK?360:300; c.previewTop=fourK?48:42; c.previewRight=fourK?72:56; c.rowHeight=fourK?64:56; c.rowCellHeight=fourK?52:46; c.rowLogoWidth=fourK?90:82; c.nowCellWidth=fourK?520:470; c.nextCellWidth=fourK?330:300; c.laterCellWidth=fourK?330:300; c.visibleRows=Math.max(5,c.visibleRows); c.guideCellColor=Color.argb(145,25,25,31); c.guideCellAltColor=Color.argb(118,25,25,31); c.guideFocusBgColor=Color.rgb(58,123,242); c.guideFocusTextColor=Color.WHITE; c.categoryFocusBgColor=Color.rgb(58,123,242); c.categoryFocusTextColor=Color.WHITE; c.radius=7; break;
            case 3: c.name="Minimal Grid"; c.catLeft=fourK?34:22; c.catTop=fourK?110:96; c.catWidth=fourK?312:276; c.mainLeft=fourK?366:310; c.mainTop=fourK?106:96; c.mainWidth=fourK?1510:1570; c.headerHeight=fourK?194:174; c.previewWidth=fourK?250:210; c.previewRight=fourK?46:34; c.previewTop=fourK?104:94; c.titleSp-=10; c.metaSp-=2; c.descSp-=2; c.rowHeight=fourK?62:54; c.rowCellHeight=fourK?50:44; c.nowCellWidth=fourK?600:500; c.nextCellWidth=fourK?390:330; c.laterCellWidth=fourK?390:330; c.guideCellColor=Color.argb(82,16,18,22); c.guideCellAltColor=Color.argb(70,16,18,22); c.guideFocusBgColor=Color.argb(64,255,255,255); c.guideFocusTextColor=Color.WHITE; c.radius=6; break;
            case 4: c.name="Cinematic Overlay"; c.catWidth=fourK?380:326; c.mainLeft=fourK?424:372; c.mainTop=fourK?72:66; c.mainWidth=fourK?1440:1508; c.headerHeight=fourK?276:252; c.previewWidth=fourK?420:340; c.previewTop=fourK?72:72; c.previewRight=fourK?60:42; c.rowHeight=fourK?64:58; c.rowCellHeight=fourK?52:46; c.guideCellColor=Color.argb(124,58,22,84); c.guideCellAltColor=Color.argb(96,42,20,68); c.guideFocusBgColor=Color.rgb(208,218,255); c.guideFocusTextColor=Color.rgb(38,28,58); c.categoryFocusBgColor=Color.rgb(120,74,220); c.categoryFocusTextColor=Color.WHITE; c.rootScrimMid=Color.argb(236,25,8,38); c.rootScrimRight=Color.argb(236,42,10,70); c.radius=11; break;
            case 5: c.name="Custom editable"; break;
            default: c.name="DebridChannels Base Theme"; break;
        }
        if(c.previewWidth<(fourK?250:200))c.previewWidth=fourK?250:200;if(c.rowHeight<44)c.rowHeight=44;if(c.rowCellHeight<38)c.rowCellHeight=38;if(c.headerHeight<150)c.headerHeight=150;
        c.forceRefreshVisible=false;c.showTopMenuArtifacts=false;c.copyReferenceProfileImages=false;
    }
    private static String themeId(int theme){switch(theme){case 1:return"google_free_tv";case 2:return"tivimate_pro";case 3:return"minimal_grid";case 4:return"cinematic_overlay";case 5:return"custom";default:return"debridchannels_base";}}
    private static String themeName(int theme){switch(theme){case 1:return"Google Free TV";case 2:return"TiviMate Pro";case 3:return"Minimal Grid";case 4:return"Cinematic Overlay";case 5:return"Custom editable";default:return"DebridChannels Base Theme";}}
}
