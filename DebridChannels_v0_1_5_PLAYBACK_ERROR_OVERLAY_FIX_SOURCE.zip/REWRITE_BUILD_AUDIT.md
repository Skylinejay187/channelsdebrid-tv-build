# Rewrite Build Audit - v0.1.5

Base: stable visual/playback line v0.1.4, consolidated cleanly.

Rule followed: no broken v7.x code path used; version markers updated.

Fixes:
- Handles Media3 ERROR_CODE_IO_BAD_HTTP_STATUS by returning to stream selection instead of leaving a dead player screen.
- Player overlay auto-hides after 4 seconds when playback is active.
- DPAD center toggles play/pause; LEFT/RIGHT seek 10 seconds.
- Overlay shows again on DPAD input.
- Preserves card visuals, row scrolling, hero ratings, Pro Layout Editor, and stream resolver settings.
