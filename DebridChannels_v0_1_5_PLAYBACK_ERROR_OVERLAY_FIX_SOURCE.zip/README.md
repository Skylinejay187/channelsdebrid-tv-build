# Debrid Channels Android TV — v0.1.2 Real Media3 VOD

Clean rewrite/consolidation from the stable v0.0.1 visual baseline.

Version: 0.1.2
Marker: DC_V0_1_2_PLAYBACK_CONTROL_FIX_ACTIVE

Core VOD flow:
Home -> Media Info -> Styled Stream List -> Select Stream -> Media3 ExoPlayer + cinematic overlay.
