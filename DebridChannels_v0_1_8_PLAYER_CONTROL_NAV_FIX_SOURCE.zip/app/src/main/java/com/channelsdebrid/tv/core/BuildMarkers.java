package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.1.8 PLAYER CONTROL NAV FIX";
    public static final String LOG_MARKER = "DC_V0_1_8_PLAYER_CONTROL_NAV_FIX_ACTIVE";
    private BuildMarkers() {}
}
