# v0.1.8 PLAYER CONTROL NAV FIX

Base: v0.1.7 working stream parity/player overlay input line.

Rewrite rule followed: clean consolidation from the working playback baseline. No broken v7.x build path used.

Fixes:
- DPAD LEFT/RIGHT no longer globally seek while overlay controls are visible; they navigate the controls.
- Media rewind/fast-forward keys still seek.
- Hidden overlay returns on any key press.
- BACK exits player and returns to media information screen.
- Added player progress bar and elapsed/duration text.
- Added Zoom button with Fit / Fill / Stretch modes.
- Preserved Stremio/RD/Torbox stream parity and Media3 playback.

Markers:
- versionName 0.1.8
- versionCode 18
- DC_V0_1_8_PLAYER_CONTROL_NAV_FIX_ACTIVE
