# Build Notes

versionCode: 282190
versionName: NewtoOld_v2.8.26.43_V42_BASE_FORCE_VISIBLE_CUTOUT_POP_DEBUG

DC_BUILD_MARKER: NewtoOld_v2.8.26.43_V42_BASE_FORCE_VISIBLE_CUTOUT_POP_DEBUG

Base: v2.8.26.40 / v37 real cutout layer path.

Changes:
- Uses backend real transparent foreground cutout as a raised cinematic subject layer.
- Adds subject-only shadow using alpha cutout, not global rectangular glow.
- Stronger app-side pop scale/translation/elevation so cutouts stand out above ghost rows.
- Darkens ambient backdrop slightly only when real cutout exists.
- Preserves ghost rows, row focus/scrolling, Live TV, backend compatibility, and 4K artwork path.
