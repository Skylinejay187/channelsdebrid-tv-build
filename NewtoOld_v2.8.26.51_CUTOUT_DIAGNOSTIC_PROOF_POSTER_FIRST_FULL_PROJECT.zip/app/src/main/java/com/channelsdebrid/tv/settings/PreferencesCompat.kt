package com.channelsdebrid.tv.settings

import android.content.SharedPreferences

object PreferencesCompat {
    fun getLong(prefs: SharedPreferences, key: String, defaultValue: Long = 0L): Long {
        return try {
            when (val value = prefs.all[key]) {
                is Long -> value
                is Int -> value.toLong()
                is String -> value.toLongOrNull() ?: defaultValue
                is Number -> value.toLong()
                else -> defaultValue
            }
        } catch (_: Throwable) {
            defaultValue
        }
    }
}
