# NewtoOld v2.8.26.51 CUTOUT_DIAGNOSTIC_PROOF_POSTER_FIRST

Focused cutout diagnostics build from latest clean v2.8.26.50 source.

- Preserves row scrolling/focus, Live TV, Pro Layout Editor, default preset, and backend compatibility.
- Keeps local runtime backend routing for cutout URLs.
- Adds cache-busted Glide retry for foreground-cutout.webp so earlier 202/not-ready responses cannot poison the retry path.
- Logs browser debug/preview URLs for each cutout URL.
- Only reports decoded/visible after alpha proof passes.
- Keeps ambient backdrop visible while cutout warms.
- Rollback baseline remains app v2.8.26.39 if this fails.
