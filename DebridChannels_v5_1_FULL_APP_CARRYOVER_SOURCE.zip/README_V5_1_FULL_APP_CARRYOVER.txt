Debrid Channels v5.1 FULL APP CARRYOVER

Full app surface preserved from attached v2.1.3 package: Settings, Pro Layout Editor, Live TV guide, VOD flows, source selection, backend/Stremio/M3U/Channels DVR paths, artwork/logo resources, storage/timeshift, and backend folder.

Verification marker: DC_V5_1_FULL_APP_CARRYOVER
Version name: 5.1-full-app-carryover
