package com.channelsdebrid.tv.core

import android.util.Log
import com.channelsdebrid.tv.BuildConfig

object BuildMarkers {
    const val BUILD_MARKER = "DC_V5_1_FULL_APP_CARRYOVER"
    const val ARCHITECTURE_MARKER = "v5_full_feature_surface_from_v2_1_3_clean_toolchain_ci_compatible"

    fun log(component: String) {
        Log.i("DebridChannels", "$BUILD_MARKER component=$component build=${BuildConfig.VERSION_NAME} code=${BuildConfig.VERSION_CODE} arch=$ARCHITECTURE_MARKER")
    }
}
