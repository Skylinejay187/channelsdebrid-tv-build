# NewtoOld v2.6.1 Full Merge Audit

Base used: latest v2.6 UI consolidation project archive.

Merged forward / preserved from v2.5.3 feature layer:
- True 4K UI mode and 4K-aware spacing markers.
- IMDb + TMDB hero badge support via `HeroRatingBadgeSystem` plus badge drawables.
- Hero lighting controller and gradient drawable.
- HDHomeRun auto-scan scanner support via `HdHomeRunAutoScanner`.
- Stremio manifest intelligence: addon name, icon/logo detection, catalog enumeration.
- Stremio catalog row bridge for new row-engine path.
- Hero top-menu position helper for Top / Center / Lower movement.

Consolidation goals retained from v2.6:
- Global FontManager path.
- Multi-layer ArtworkLayerEngine path.
- UIConfigManager observer/state path for real-time layout editor updates.
- Backend mode remains removed; direct providers stay active.

Debug marker: `DC_BUILD_MARKER: NewtoOld_v2.6.1_FULL_MERGE`.
