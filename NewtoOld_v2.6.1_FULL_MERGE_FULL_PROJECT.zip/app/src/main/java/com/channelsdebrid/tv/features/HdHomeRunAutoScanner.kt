package com.channelsdebrid.tv.features

import android.content.Context
import android.net.wifi.WifiManager
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** Lightweight HDHomeRun direct-network scanner. Runs off the UI thread. */
object HdHomeRunAutoScanner {
    data class Device(
        val ip: String,
        val friendlyName: String,
        val deviceId: String,
        val lineupUrl: String?
    )

    private val executor = Executors.newSingleThreadExecutor()

    fun scanAsync(context: Context, callback: (List<Device>) -> Unit) {
        executor.execute {
            val results = runCatching { scan(context) }.getOrDefault(emptyList())
            callback(results)
        }
    }

    fun scan(context: Context, timeoutMs: Int = 350): List<Device> {
        val subnet = detectSubnet(context) ?: "192.168.1."
        val found = mutableListOf<Device>()
        for (host in 1..254) {
            val ip = "$subnet$host"
            val device = probe(ip, timeoutMs)
            if (device != null) found += device
        }
        return found.distinctBy { it.deviceId.ifBlank { it.ip } }
    }

    private fun probe(ip: String, timeoutMs: Int): Device? {
        val conn = (URL("http://$ip/discover.json").openConnection() as HttpURLConnection).apply {
            connectTimeout = timeoutMs
            readTimeout = timeoutMs
            requestMethod = "GET"
        }
        return try {
            if (conn.responseCode != 200) return null
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            Device(
                ip = ip,
                friendlyName = json.optString("FriendlyName", "HDHomeRun $ip"),
                deviceId = json.optString("DeviceID", ip),
                lineupUrl = json.optString("LineupURL").takeIf { it.isNotBlank() }
            )
        } catch (_: Throwable) {
            null
        } finally {
            conn.disconnect()
        }
    }

    private fun detectSubnet(context: Context): String? {
        return runCatching {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val ip = wm.connectionInfo.ipAddress
            val a = ip and 0xff
            val b = ip shr 8 and 0xff
            val c = ip shr 16 and 0xff
            "$a.$b.$c."
        }.getOrNull()
    }
}
