package com.channelsdebrid.tv.ui

import android.content.Context
import com.channelsdebrid.tv.settings.HomeLayoutSettings

/** 4K-aware spacing scaler. Keeps 1080p-tuned layouts from becoming oversized in true 4K mode. */
object UIScaler {
    fun scaleDp(value: Int, context: Context, config: HomeLayoutSettings = UIConfigManager.current): Int {
        val adjusted = if (UIConfigManager.is4KActive(context, config)) (value * 0.75f).toInt() else value
        return (adjusted * context.resources.displayMetrics.density).toInt()
    }

    fun fontScale(config: HomeLayoutSettings = UIConfigManager.current): Float =
        config.heroTextSizePercent.coerceIn(60, 160) / 100f
}
