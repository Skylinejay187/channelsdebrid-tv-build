package com.channelsdebrid.tv.ui

import android.view.View
import android.widget.ImageView

/** v2.6 multi-layer artwork render helper. All hero artwork layers flow through this path. */
object ArtworkLayerEngine {
    enum class Layer { BACKDROP, POSTER, LOGO, EXTRA_1, EXTRA_2 }

    data class Config(
        val scale: Float = 1f,
        val x: Float = 0f,
        val y: Float = 0f,
        val alpha: Float = 1f,
        val visible: Boolean = true,
        val z: Float = 0f
    )

    fun apply(view: ImageView, config: Config) {
        view.scaleX = config.scale
        view.scaleY = config.scale
        view.translationX = config.x
        view.translationY = config.y
        view.alpha = config.alpha.coerceIn(0f, 1f)
        view.translationZ = config.z
        view.visibility = if (config.visible) View.VISIBLE else View.INVISIBLE
        view.invalidate()
        view.requestLayout()
    }
}
