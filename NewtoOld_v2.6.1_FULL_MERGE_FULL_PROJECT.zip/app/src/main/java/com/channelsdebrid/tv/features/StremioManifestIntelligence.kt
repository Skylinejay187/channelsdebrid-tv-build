package com.channelsdebrid.tv.features

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Fetches Stremio manifest metadata so settings can show real addon name/icon and row engine can add catalog rows. */
object StremioManifestIntelligence {
    data class Catalog(val type: String, val id: String, val name: String)
    data class AddonManifest(
        val id: String,
        val name: String,
        val logo: String?,
        val manifestUrl: String,
        val catalogs: List<Catalog>
    )

    fun fetch(manifestUrl: String, timeoutMs: Int = 6000): AddonManifest? {
        if (manifestUrl.isBlank()) return null
        val conn = (URL(manifestUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = timeoutMs
            readTimeout = timeoutMs
            requestMethod = "GET"
        }
        return try {
            if (conn.responseCode !in 200..299) return null
            parse(manifestUrl, conn.inputStream.bufferedReader().use { it.readText() })
        } catch (_: Throwable) {
            null
        } finally {
            conn.disconnect()
        }
    }

    fun parse(manifestUrl: String, body: String): AddonManifest {
        val json = JSONObject(body)
        val catalogsJson = json.optJSONArray("catalogs")
        val catalogs = mutableListOf<Catalog>()
        if (catalogsJson != null) {
            for (i in 0 until catalogsJson.length()) {
                val cat = catalogsJson.optJSONObject(i) ?: continue
                val type = cat.optString("type")
                val id = cat.optString("id")
                if (type.isBlank() || id.isBlank()) continue
                val name = cat.optString("name").ifBlank { prettifyCatalogName(id, type) }
                catalogs += Catalog(type, id, name)
            }
        }
        return AddonManifest(
            id = json.optString("id").ifBlank { manifestUrl.hashCode().toString() },
            name = json.optString("name").ifBlank { hostName(manifestUrl) },
            logo = json.optString("logo").takeIf { it.isNotBlank() }
                ?: json.optString("icon").takeIf { it.isNotBlank() },
            manifestUrl = manifestUrl,
            catalogs = catalogs
        )
    }

    private fun prettifyCatalogName(id: String, type: String): String {
        return (id.replace('_', ' ').replace('-', ' ') + " " + type)
            .split(' ')
            .filter { it.isNotBlank() }
            .joinToString(" ") { it.replaceFirstChar { ch -> if (ch.isLowerCase()) ch.titlecase() else ch.toString() } }
    }

    private fun hostName(url: String): String = url.substringAfter("//", url).substringBefore('/').substringBefore(':')
}
