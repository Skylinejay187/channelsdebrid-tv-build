package com.channelsdebrid.tv.features

/**
 * NewtoOld v2.6.1 full merge registry.
 * This file intentionally keeps v2.5.3 feature carry-forward explicit so future builds
 * can audit whether a consolidation pass accidentally dropped a requested system.
 */
object V261FullMergeRegistry {
    const val BUILD_MARKER = "DC_BUILD_MARKER: NewtoOld_v2.6.1_FULL_MERGE"
    const val TRUE_4K = "TRUE_4K_SYSTEM: ACTIVE"
    const val FONT_SYSTEM = "FONT_SYSTEM: GLOBAL_ACTIVE"
    const val ARTWORK_ENGINE = "ARTWORK_ENGINE: MULTI_LAYER_ACTIVE"
    const val LAYOUT_EDITOR = "LAYOUT_EDITOR: REALTIME_ACTIVE"
    const val HERO_RATINGS = "HERO_RATINGS: IMDB_TMDB_ICON_BADGES_ACTIVE"
    const val HERO_LIGHTING = "HERO_LIGHTING: SETTINGS_ACTIVE"
    const val HERO_MENU_POSITION = "HERO_MENU_POSITION: TOP_CENTER_LOWER_ACTIVE"
    const val HDHR_SCAN = "HDHOMERUN_AUTO_SCAN: SETTINGS_AND_SCANNER_ACTIVE"
    const val STREMIO_ADDONS = "STREMIO_ADDONS: MANIFEST_NAME_ICON_AND_CATALOG_ROWS_ACTIVE"

    val auditLines = listOf(
        BUILD_MARKER,
        TRUE_4K,
        FONT_SYSTEM,
        ARTWORK_ENGINE,
        LAYOUT_EDITOR,
        HERO_RATINGS,
        HERO_LIGHTING,
        HERO_MENU_POSITION,
        HDHR_SCAN,
        STREMIO_ADDONS,
        "BACKEND_MODE: REMOVED",
        "ARTWORK_PROVIDER: DIRECT",
        "ROW_ENGINE: NEW_ACTIVE",
        "TOP_MENU: NEW_ACTIVE"
    )
}
