package com.channelsdebrid.tv.features

import com.channelsdebrid.tv.data.StremioLiveLoader
import com.channelsdebrid.tv.settings.StremioAddonSettings

/** Converts Stremio addon manifests into real catalog rows for the new row engine path. */
object StremioCatalogRowBridge {
    fun loadRows(addons: List<StremioAddonSettings>, limitPerRow: Int = 20): List<StremioLiveLoader.LiveRow> {
        val loader = StremioLiveLoader()
        val rows = mutableListOf<StremioLiveLoader.LiveRow>()
        addons.filter { it.enabled && it.manifestUrl.isNotBlank() }.forEach { addon ->
            val manifest = StremioManifestIntelligence.fetch(addon.manifestUrl)
            val displayName = manifest?.name ?: addon.name.ifBlank { "Stremio Addon" }
            val loaded = runCatching { loader.loadRows(displayName, addon.manifestUrl, limitPerRow) }
                .getOrDefault(emptyList())
            rows += loaded
        }
        return rows.distinctBy { it.title }
    }
}
