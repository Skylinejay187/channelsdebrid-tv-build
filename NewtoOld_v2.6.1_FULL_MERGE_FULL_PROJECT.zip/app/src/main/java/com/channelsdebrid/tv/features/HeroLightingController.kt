package com.channelsdebrid.tv.features

import android.view.View
import com.channelsdebrid.tv.settings.HomeLayoutSettings

/** Applies the v2.5.3 hero lighting setting to real hero views during v2.6+ rendering. */
object HeroLightingController {
    fun apply(lightingView: View?, config: HomeLayoutSettings) {
        lightingView ?: return
        val enabled = config.glowStrengthPercent > 0
        lightingView.visibility = if (enabled) View.VISIBLE else View.GONE
        lightingView.alpha = (config.glowStrengthPercent.coerceIn(0, 100) / 100f).coerceIn(0f, 1f)
    }
}
