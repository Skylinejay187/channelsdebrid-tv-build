package com.channelsdebrid.tv

import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.channelsdebrid.tv.data.BackendHomeLoader
import com.channelsdebrid.tv.data.BackendlessArtworkProvider
import com.channelsdebrid.tv.playback.MediaDetailsActivity
import com.channelsdebrid.tv.settings.HomeLayoutSettings
import com.channelsdebrid.tv.settings.SettingsRepository
import com.channelsdebrid.tv.settings.homeLayoutFontName
import com.channelsdebrid.tv.ui.ArtworkLayerEngine
import com.channelsdebrid.tv.ui.FontManager
import com.channelsdebrid.tv.ui.UIConfigManager
import com.channelsdebrid.tv.ui.UiModeApplier
import com.channelsdebrid.tv.ui.UIScaler
import java.util.concurrent.Executors

/**
 * NewtoOld v2.1 hard home rebuild.
 *
 * This file intentionally does not use the previous ScrollView + per-row binding system.
 * Rows are owned by one vertical RecyclerView and one explicit FocusGraph so DPAD DOWN/UP
 * cannot be stolen by legacy scroll recovery code.
 */
class MainActivity : AppCompatActivity() {
    private companion object {
        private const val BACKEND_BASE_URL = "http://192.168.100.55:8181"
        private const val TAG = "DebridChannels"
    }

    private lateinit var repository: SettingsRepository
    private var config = HomeLayoutSettings()
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val backendLoader = BackendHomeLoader()
    private val artworkProvider by lazy { BackendlessArtworkProvider(this) }

    private lateinit var root: FrameLayout
    private lateinit var heroBackdrop: ImageView
    private lateinit var heroScrim: View
    private lateinit var heroText: LinearLayout
    private lateinit var heroTitle: TextView
    private lateinit var heroMeta: TextView
    private lateinit var heroDesc: TextView
    private lateinit var heroLogo: ImageView
    private lateinit var heroExtraArt: ImageView
    private lateinit var topMenu: LinearLayout
    private lateinit var rowsRecycler: RecyclerView
    private lateinit var statusPill: TextView

    private val rowRecyclerByIndex = LinkedHashMap<Int, RecyclerView>()
    private var currentRows: List<HomeRow> = emptyList()
    private var lastFocusedRow = 0
    private var lastFocusedColumn = 0

    data class TitleCard(
        val title: String,
        val meta: String,
        val desc: String,
        val backgroundRes: Int,
        val posterUrl: String? = null,
        val backdropUrl: String? = null,
        val logoUrl: String? = null,
        val mediaType: String = "movie",
        val externalId: String? = null,
        val year: Int = 0,
        val source: String = "Local"
    )

    data class HomeRow(val title: String, val items: List<TitleCard>)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repository = SettingsRepository(this)
        config = repository.loadHomeLayout()
        UIConfigManager.setConfig(config, notify = false)
        UiModeApplier.apply(this, config)
        Log.i(TAG, "DC_BUILD_MARKER: NewtoOld_v2.6_UI_CONSOLIDATION_FULL_PROJECT")
        Log.i(TAG, "ROW_ENGINE: HARD_REBUILT_FROM_SCRATCH")
        Log.i(TAG, "ROW_ENGINE: LEGACY_SCROLLVIEW_BINDING_NOT_USED")
        Log.i(TAG, "FOCUS_GRAPH: EXPLICIT_VERTICAL_AND_HORIZONTAL")
        Log.i(TAG, "TOP_MENU_ENGINE: FULL_THEME_CHOOSER_ACTIVE noGlassOption=true")
        Log.i(TAG, "DEBRID_STATUS: NOT_PRESENT runtimeHome=false")
        Log.i(TAG, "BACKENDLESS_ARTWORK_PROVIDER: ACTIVE mode=${config.artworkSourceMode}")
        buildUi()
        applyMenuTheme()
        setRows(defaultRows())
        loadArtworkRows()
        UIConfigManager.register {
            config = repository.loadHomeLayout()
            applyRuntimeUiConfig()
        }
    }

    private fun applyRuntimeUiConfig() {
        UIConfigManager.setConfig(config, notify = false)
        heroTitle.textSize = 48f * UIScaler.fontScale(config)
        heroMeta.textSize = 19f * UIScaler.fontScale(config)
        heroDesc.textSize = 24f * UIScaler.fontScale(config)
        FontManager.apply(heroTitle, config.heroFontIndex)
        FontManager.apply(heroMeta, config.heroFontIndex)
        FontManager.apply(heroDesc, config.heroFontIndex)
        buildTopMenuItems()
        applyMenuTheme()
        rowsRecycler.adapter?.notifyDataSetChanged()
        root.requestLayout()
        root.invalidate()
        Log.i(TAG, "LAYOUT_EDITOR_REALTIME_APPLY: font=" + config.heroFontIndex + "/" + config.contentFontIndex + " artworkLayered=true scaling4k=" + UIConfigManager.is4KActive(this, config))
    }

    override fun onDestroy() {
        super.onDestroy()
        io.shutdownNow()
    }

    private fun dp(value: Int): Int = UIScaler.scaleDp(value, this, config)

    private fun buildUi() {
        root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            clipChildren = false
            clipToPadding = false
        }
        heroBackdrop = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.88f
        }
        heroScrim = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xF2000000.toInt(), 0xAA000000.toInt(), 0x22000000)
            )
        }
        heroText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(34 + config.heroTextLeftDp), dp(118 + config.heroTextTopDp), dp(34), 0)
            clipChildren = false
        }
        heroTitle = TextView(this).apply {
            textSize = 48f * (config.heroTextSizePercent.coerceIn(60, 160) / 100f)
            setTextColor(Color.WHITE)
            typeface = FontManager.typeface(config.heroFontIndex)
            maxLines = 2
        }
        heroMeta = TextView(this).apply {
            textSize = 19f * (config.heroTextSizePercent.coerceIn(60, 160) / 100f)
            setTextColor(0xFFFFD84A.toInt())
            typeface = FontManager.typeface(config.heroFontIndex)
            setPadding(0, dp(12), 0, 0)
        }
        heroDesc = TextView(this).apply {
            textSize = 24f * (config.heroTextSizePercent.coerceIn(60, 160) / 100f)
            setTextColor(Color.WHITE)
            typeface = FontManager.typeface(config.heroFontIndex)
            maxLines = 3
            setPadding(0, dp(14), dp(380), 0)
        }
        heroText.addView(heroTitle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        heroText.addView(heroMeta, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        heroText.addView(heroDesc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        heroLogo = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            visibility = View.INVISIBLE
            elevation = dp(20).toFloat()
        }

        heroExtraArt = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            elevation = dp(18).toFloat()
            visibility = View.INVISIBLE
        }

        topMenu = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            clipChildren = false
            clipToPadding = false
            translationX = dp(config.topMenuOffsetDp).toFloat()
        }
        buildTopMenuItems()

        rowsRecycler = RecyclerView(this).apply {
            id = View.generateViewId()
            layoutManager = LinearLayoutManager(this@MainActivity, RecyclerView.VERTICAL, false)
            itemAnimator = null
            overScrollMode = View.OVER_SCROLL_NEVER
            clipChildren = false
            clipToPadding = false
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
            setHasFixedSize(false)
            isFocusable = false
        }

        statusPill = TextView(this).apply {
            text = "10:17 PM   •   No new favorites"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = rounded(0x66000000, 24, 0x55FFFFFF, 1)
        }

        root.addView(heroBackdrop, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(heroScrim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(heroText, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(430), Gravity.TOP or Gravity.START))
        root.addView(heroLogo, heroLogoParams())
        root.addView(heroExtraArt, extraArtHeroParams())
        root.addView(topMenu, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(58), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(48) })
        root.addView(rowsRecycler, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply {
            topMargin = dp(config.rowTopDp.coerceIn(360, 620))
            leftMargin = dp(config.rowLeftDp.coerceIn(0, 120))
            bottomMargin = dp(config.bottomSafeDp.coerceIn(24, 160))
        })
        if (config.statusHubVisible == 1) {
            root.addView(statusPill, FrameLayout.LayoutParams(dp(490), dp(58), Gravity.BOTTOM or Gravity.END).apply {
                rightMargin = dp(26)
                bottomMargin = dp(26)
            })
        }
        Log.i(TAG, "STATUS_HUB_VISIBLE_APPLY: ${config.statusHubVisible == 1}")
        setContentView(root)
    }

    private fun buildTopMenuItems() {
        topMenu.removeAllViews()
        val labels = menuLabelsForStyle(config.topMenuIconStyle)
        labels.forEachIndexed { index, item ->
            val tab = TextView(this).apply {
                id = View.generateViewId()
                text = item.first
                tag = item.second
                textSize = if (config.topMenuIconStyle == 2) 25f else 18f
                setTextColor(Color.WHITE)
                typeface = FontManager.typeface(config.topMenuFontIndex)
                gravity = Gravity.CENTER
                isFocusable = true
                isClickable = true
                setPadding(dp(18), 0, dp(18), 0)
                background = menuItemBg(false)
                setOnFocusChangeListener { v, hasFocus ->
                    v.background = menuItemBg(hasFocus)
                    animateMenuFocus(v, hasFocus)
                }
                setOnClickListener { handleMenuAction(item.second) }
                setOnKeyListener { _, keyCode, event ->
                    if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                    when (keyCode) {
                        KeyEvent.KEYCODE_DPAD_DOWN -> {
                            focusCard(0, lastFocusedColumn.coerceAtLeast(0))
                            true
                        }
                        KeyEvent.KEYCODE_DPAD_LEFT -> {
                            topMenu.getChildAt((index - 1).coerceAtLeast(0))?.requestFocus(); true
                        }
                        KeyEvent.KEYCODE_DPAD_RIGHT -> {
                            topMenu.getChildAt((index + 1).coerceAtMost(topMenu.childCount - 1))?.requestFocus(); true
                        }
                        else -> false
                    }
                }
            }
            topMenu.addView(tab, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT).apply {
                leftMargin = dp(4)
                rightMargin = dp(4)
            })
        }
    }

    private fun menuLabelsForStyle(style: Int): List<Pair<String, String>> = when (style.coerceIn(0, 5)) {
        1 -> listOf("◆ Home" to "home", "▶ Live TV" to "live", "▣ Movies" to "movies", "▤ Shows" to "shows", "⚙ Settings" to "settings", "⌕" to "search")
        2 -> listOf("⌂" to "home", "▶" to "live", "▣" to "movies", "▤" to "shows", "⚙" to "settings", "⌕" to "search")
        3 -> listOf("HOME" to "home", "LIVE" to "live", "MOVIES" to "movies", "SHOWS" to "shows", "SETTINGS" to "settings", "SEARCH" to "search")
        4 -> listOf("Home" to "home", "Live TV" to "live", "Movies" to "movies", "Shows" to "shows", "Settings" to "settings", "Search" to "search")
        5 -> listOf("⌂ Home" to "home", "◉ Live" to "live", "▰ Movies" to "movies", "▱ Shows" to "shows", "⚙ Settings" to "settings", "⌕ Search" to "search")
        else -> listOf("Home" to "home", "Live TV" to "live", "Movies" to "movies", "Shows" to "shows", "Settings" to "settings", "⌕" to "search")
    }

    private fun applyMenuTheme() {
        val theme = config.topMenuThemeStyle.coerceIn(0, 7)
        val bg: GradientDrawable? = when (theme) {
            0 -> null // true no-glass/no-pill mode
            1 -> rounded(0x00000000, 0, 0x00000000, 0) // flat transparent
            2 -> rounded(0x66000000, 24, 0x33FFFFFF, 1)
            3 -> rounded(0xCC06080F.toInt(), 18, 0xFFFFD84A.toInt(), 1)
            4 -> rounded(0xAA061A2A.toInt(), 34, 0x774DFFB8, 1)
            5 -> rounded(0xE60A0A10.toInt(), 8, 0x88FFFFFF.toInt(), 1)
            6 -> rounded(0x99111A2A.toInt(), 26, 0xFF76E4FF.toInt(), 1)
            else -> rounded(0xDD050507.toInt(), 30, 0x88B46CFF.toInt(), 2)
        }
        topMenu.background = bg
        topMenu.elevation = if (theme == 0 || theme == 1) 0f else dp(12).toFloat()
        topMenu.setPadding(if (theme <= 1) 0 else dp(12), 0, if (theme <= 1) 0 else dp(12), 0)
        Log.i(TAG, "TOP_MENU_THEME_VISIBLE_APPLY: theme=$theme noGlass=${theme == 0 || theme == 1}")
    }

    private fun menuItemBg(focused: Boolean): GradientDrawable {
        val theme = config.topMenuThemeStyle.coerceIn(0, 7)
        if (!focused) return rounded(Color.TRANSPARENT, 18, Color.TRANSPARENT, 0)
        return when (theme) {
            0, 1 -> rounded(Color.TRANSPARENT, 0, 0xFFFFD84A.toInt(), 2)
            3 -> rounded(0x22FFD84A, 14, 0xFFFFD84A.toInt(), 2)
            4 -> rounded(0x224DFFB8, 22, 0xFF4DFFB8.toInt(), 2)
            6 -> rounded(0x2276E4FF, 22, 0xFF76E4FF.toInt(), 2)
            else -> rounded(0x22FFFFFF, 18, 0x99FFFFFF.toInt(), 1)
        }
    }

    private fun animateMenuFocus(view: View, focused: Boolean) {
        view.animate().cancel()
        val style = config.topMenuAnimationStyle.coerceIn(0, 4)
        if (!focused) {
            view.animate().scaleX(1f).scaleY(1f).translationY(0f).alpha(1f).setDuration(100).start()
            return
        }
        when (style) {
            0 -> view.scaleX = 1.06f
            1 -> view.animate().scaleX(1.08f).scaleY(1.08f).translationY(-dp(2).toFloat()).setDuration(120).start()
            2 -> view.animate().scaleX(1.16f).scaleY(1.16f).translationY(-dp(4).toFloat()).setDuration(90).withEndAction {
                view.animate().scaleX(1.09f).scaleY(1.09f).setDuration(110).start()
            }.start()
            3 -> view.animate().alpha(0.72f).setDuration(70).withEndAction { view.animate().alpha(1f).scaleX(1.1f).scaleY(1.1f).setDuration(120).start() }.start()
            else -> view.animate().scaleX(1.05f).scaleY(1.05f).translationY(dp(3).toFloat()).setDuration(110).start()
        }
    }

    private fun handleMenuAction(action: String) {
        when (action) {
            "live" -> startActivity(Intent(this, LiveTvActivity::class.java))
            "settings" -> startActivity(Intent(this, SettingsActivity::class.java))
            "search" -> startActivity(Intent(this, SearchActivity::class.java))
            "movies" -> startActivity(Intent(this, BrowseSectionActivity::class.java).putExtra("section", "movies"))
            "shows" -> startActivity(Intent(this, BrowseSectionActivity::class.java).putExtra("section", "shows"))
            else -> focusCard(0, 0)
        }
    }

    private fun setRows(rows: List<HomeRow>) {
        currentRows = rows.filter { it.items.isNotEmpty() }
        rowRecyclerByIndex.clear()
        rowsRecycler.adapter = HomeRowsAdapter(currentRows)
        rowsRecycler.postDelayed({ focusCard(0, 0) }, 150)
        currentRows.firstOrNull()?.items?.firstOrNull()?.let { updateHero(it) }
    }

    private fun loadArtworkRows() {
        val mode = config.artworkSourceMode.coerceIn(0, 3)
        Log.i(TAG, "ARTWORK_SOURCE_MODE: ${artworkModeName(mode)}")
        io.execute {
            val directRows = if (mode in 0..2) {
                runCatching { artworkProvider.loadDirectRows(24) }.getOrDefault(emptyList())
            } else emptyList()

            val backendRows = emptyList<com.channelsdebrid.tv.data.BackendHomeLoader.BackendRow>()

            val mappedDirect = directRows.map { row ->
                HomeRow(row.title, row.items.mapIndexed { index, item ->
                    TitleCard(
                        title = item.title,
                        meta = item.meta.ifBlank { item.source },
                        desc = item.overview.ifBlank { "Direct metadata artwork item." },
                        backgroundRes = fallbackDrawable(index),
                        posterUrl = item.posterUrl,
                        backdropUrl = item.backdropUrl ?: item.posterUrl,
                        logoUrl = item.logoUrl,
                        mediaType = item.type.ifBlank { "movie" },
                        externalId = item.externalId.ifBlank { item.title },
                        source = item.source.ifBlank { "Direct" }
                    )
                })
            }

            val mappedBackend = backendRows.map { row ->
                HomeRow(row.title, row.items.mapIndexed { index, item ->
                    TitleCard(
                        title = item.title,
                        meta = listOfNotNull(item.year.takeIf { it > 0 }?.toString(), item.genre.takeIf { it.isNotBlank() }, item.source.takeIf { it.isNotBlank() }).joinToString("  •  "),
                        desc = item.overview.ifBlank { "Backend catalog item" },
                        backgroundRes = fallbackDrawable(index),
                        posterUrl = item.poster,
                        backdropUrl = item.backdrop ?: item.poster,
                        logoUrl = item.logo,
                        mediaType = item.type.ifBlank { "movie" },
                        externalId = item.imdbId ?: item.id,
                        year = item.year,
                        source = item.source.ifBlank { "Backend" }
                    )
                })
            }

            val finalRows = when (mode) {
                0 -> mappedDirect
                1 -> mappedDirect
                2 -> mappedDirect
                else -> emptyList()
            }

            main.post {
                if (!isFinishing && !isDestroyed && finalRows.isNotEmpty()) {
                    Log.i(TAG, "ARTWORK_ROWS_APPLIED: mode=${artworkModeName(mode)} rows=${finalRows.size} backendRequired=false")
                    setRows(finalRows)
                } else {
                    Log.i(TAG, "ARTWORK_ROWS_APPLIED: mode=${artworkModeName(mode)} rows=0 fallback=local")
                }
            }
        }
    }

    private fun artworkModeName(mode: Int): String = when (mode.coerceIn(0, 3)) {
        0 -> "Direct metadata"
        1 -> "Direct metadata + local cache"
        2 -> "Direct metadata (backend removed)"
        else -> "Offline/local fallback"
    }

    private inner class HomeRowsAdapter(private val rows: List<HomeRow>) : RecyclerView.Adapter<HomeRowsAdapter.RowHolder>() {
        inner class RowHolder(val box: LinearLayout, val title: TextView, val row: RecyclerView) : RecyclerView.ViewHolder(box)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowHolder {
            val box = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                clipChildren = false
                clipToPadding = false
                setPadding(0, 0, 0, dp(16))
            }
            val title = TextView(parent.context).apply {
                setTextColor(Color.WHITE)
                textSize = 21f
                typeface = Typeface.DEFAULT_BOLD
                setPadding(0, 0, 0, dp(8))
            }
            val row = RecyclerView(parent.context).apply {
                layoutManager = LinearLayoutManager(parent.context, RecyclerView.HORIZONTAL, false)
                itemAnimator = null
                overScrollMode = View.OVER_SCROLL_NEVER
                clipChildren = false
                clipToPadding = false
                descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
                setHasFixedSize(false)
                isFocusable = false
            }
            box.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, if (config.rowTextVisible == 1) dp(34) else 0))
            box.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(config.cardHeightDp.coerceIn(110, 260) + 38)))
            return RowHolder(box, title, row)
        }
        override fun getItemCount(): Int = rows.size
        override fun onBindViewHolder(holder: RowHolder, position: Int) {
            val rowData = rows[position]
            holder.title.visibility = if (config.rowTextVisible == 1) View.VISIBLE else View.GONE
            holder.title.text = rowData.title
            holder.row.adapter = CardAdapter(position, rowData.items)
            rowRecyclerByIndex[position] = holder.row
            Log.i(TAG, "ROW_ENGINE_BIND_ROW: index=$position title=${rowData.title} oldAdapter=false")
        }
    }

    private inner class CardAdapter(private val rowIndex: Int, private val items: List<TitleCard>) : RecyclerView.Adapter<CardAdapter.CardHolder>() {
        inner class CardHolder(val frame: FrameLayout, val art: ImageView, val logo: ImageView, val label: TextView) : RecyclerView.ViewHolder(frame)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardHolder {
            val w = dp(config.cardWidthDp.coerceIn(190, 420))
            val h = dp(config.cardHeightDp.coerceIn(110, 260))
            val frame = FrameLayout(parent.context).apply {
                id = View.generateViewId()
                layoutParams = RecyclerView.LayoutParams(w, h).apply { rightMargin = dp(config.cardSpacingDp.coerceIn(0, 40)) }
                isFocusable = true
                isClickable = true
                clipToOutline = true
                outlineProvider = roundOutline(config.cornerRadiusDp)
                background = rounded(if (config.glassCardMode == 1) 0xAA121A26.toInt() else 0xFF0B0F18.toInt(), config.cornerRadiusDp, 0x22FFFFFF, 1)
            }
            val art = ImageView(parent.context).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(0xFF05070D.toInt())
            }
            val logo = ImageView(parent.context).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                adjustViewBounds = true
                visibility = View.INVISIBLE
            }
            val label = TextView(parent.context).apply {
                gravity = Gravity.BOTTOM or Gravity.START
                textSize = 16f
                setTextColor(Color.WHITE)
                typeface = FontManager.typeface(config.contentFontIndex)
                setPadding(dp(14), 0, dp(14), dp(12))
                background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0x99000000.toInt()))
                maxLines = 2
            }
            frame.addView(art, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            frame.addView(logo, FrameLayout.LayoutParams(dp((config.cardWidthDp * 0.62f).toInt()), dp((config.cardHeightDp * 0.42f).toInt()), Gravity.CENTER))
            frame.addView(label, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            return CardHolder(frame, art, logo, label)
        }
        override fun getItemCount(): Int = items.size
        override fun onBindViewHolder(holder: CardHolder, position: Int) {
            val item = items[position]
            holder.label.text = if (config.rowTextVisible == 1) item.title else ""
            loadImage(holder.art, item.backdropUrl ?: item.posterUrl, item.backgroundRes)
            if (config.cardLogoVisible == 1 && !item.logoUrl.isNullOrBlank()) {
                Glide.with(this@MainActivity).load(item.logoUrl)
                    .apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).diskCacheStrategy(DiskCacheStrategy.AUTOMATIC))
                    .into(holder.logo)
                holder.logo.visibility = View.VISIBLE
                holder.label.visibility = View.GONE
            } else {
                holder.logo.visibility = View.INVISIBLE
                holder.label.visibility = if (config.rowTextVisible == 1) View.VISIBLE else View.GONE
            }
            Log.i(TAG, "CARD_LOGO_ARTWORK_APPLY: row=$rowIndex col=$position visible=${holder.logo.visibility == View.VISIBLE}")
            holder.frame.setOnClickListener { launchDetails(item) }
            holder.frame.setOnFocusChangeListener { v, focused ->
                if (focused) {
                    lastFocusedRow = rowIndex
                    lastFocusedColumn = position
                    updateHero(item)
                }
                applyCardFocus(v, focused)
            }
            holder.frame.setOnKeyListener { _, keyCode, event ->
                if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP -> { if (rowIndex == 0) focusTopMenu() else focusCard(rowIndex - 1, position); true }
                    KeyEvent.KEYCODE_DPAD_DOWN -> { focusCard((rowIndex + 1).coerceAtMost(currentRows.lastIndex), position); true }
                    else -> false
                }
            }
        }
    }

    private fun focusTopMenu() {
        topMenu.getChildAt(0)?.requestFocus()
    }

    private fun focusCard(rowIndex: Int, column: Int) {
        if (currentRows.isEmpty()) return
        val safeRow = rowIndex.coerceIn(0, currentRows.lastIndex)
        val safeCol = column.coerceIn(0, currentRows[safeRow].items.lastIndex)
        lastFocusedRow = safeRow
        lastFocusedColumn = safeCol
        rowsRecycler.scrollToPosition(safeRow)
        Log.i(TAG, "FOCUS_GRAPH_MOVE: row=$safeRow col=$safeCol")
        rowsRecycler.post {
            val inner = rowRecyclerByIndex[safeRow]
            if (inner == null) {
                rowsRecycler.postDelayed({ focusCard(safeRow, safeCol) }, 50)
                return@post
            }
            inner.scrollToPosition(safeCol)
            inner.post {
                val holder = inner.findViewHolderForAdapterPosition(safeCol)
                val target = holder?.itemView ?: inner.getChildAt(0)
                target?.requestFocus()
            }
        }
    }

    private fun formatHeroRatings(item: TitleCard): String {
        val raw = item.meta.ifBlank { "Featured • ${item.source}" }
        fun findRating(label: String): String {
            val rx = Regex(label + "\\s*[:★⭐]?\\s*([0-9]+(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE)
            return rx.find(raw)?.groupValues?.getOrNull(1).orEmpty()
        }
        val imdb = findRating("IMDb")
        val tmdb = findRating("TMDB").ifBlank {
            Regex("★\\s*([0-9]+(?:\\.[0-9]+)?)").find(raw)?.groupValues?.getOrNull(1).orEmpty()
        }
        val cleanParts = raw.split("•").map { it.trim() }
            .filter { it.isNotBlank() && !it.contains("IMDb", true) && !it.contains("TMDB", true) && !it.startsWith("★") }
        val ratingParts = mutableListOf<String>()
        if (imdb.isNotBlank()) ratingParts += "IMDb ★ $imdb"
        if (tmdb.isNotBlank()) ratingParts += "TMDB ★ $tmdb"
        if (ratingParts.isEmpty()) return raw
        return (cleanParts + ratingParts).joinToString("   •   ")
    }

    private fun updateHero(item: TitleCard) {
        heroTitle.text = item.title.uppercase()
        heroMeta.text = formatHeroRatings(item)
        heroDesc.text = item.desc.ifBlank { "Select to open details." }
        loadImage(heroBackdrop, item.backdropUrl ?: item.posterUrl, item.backgroundRes)
        applyHeroQualityMode()
        applyHeroLogo(item)
        applyHeroExtraArt(item)
    }

    private fun applyHeroQualityMode() {
        val mode = config.heroQualityMode.coerceIn(0, 1)
        heroBackdrop.alpha = if (mode == 1) 0.96f else 0.88f
        heroBackdrop.scaleType = ImageView.ScaleType.CENTER_CROP
        Log.i(TAG, "HERO_QUALITY_MODE_APPLY: ${if (mode == 1) "4K" else "1080p"} uiResolution=${if (config.uiResolutionMode == 1) "4K" else "1080p"}")
    }


    private fun heroLogoParams(): FrameLayout.LayoutParams {
        return FrameLayout.LayoutParams(dp(config.heroLogoWidthDp), dp(config.heroLogoHeightDp), Gravity.TOP or Gravity.START).apply {
            leftMargin = dp(34 + config.heroTextLeftDp)
            topMargin = dp(78 + config.heroTextTopDp)
        }
    }

    private fun applyHeroLogo(item: TitleCard) {
        root.removeView(heroLogo)
        root.addView(heroLogo, heroLogoParams())
        if (config.heroLogoVisible != 1 || item.logoUrl.isNullOrBlank()) {
            heroLogo.visibility = View.INVISIBLE
            heroTitle.visibility = View.VISIBLE
            Log.i(TAG, "HERO_LOGO_ARTWORK_APPLY: hidden fallbackTitle=true")
            return
        }
        Glide.with(this).load(item.logoUrl)
            .apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).diskCacheStrategy(DiskCacheStrategy.AUTOMATIC))
            .into(heroLogo)
        ArtworkLayerEngine.apply(heroLogo, ArtworkLayerEngine.Config(scale = 1f, alpha = 1f, visible = true, z = dp(20).toFloat()))
        heroTitle.visibility = View.INVISIBLE
        Log.i(TAG, "HERO_LOGO_ARTWORK_APPLY: visible source=logoUrl layered=true")
    }

    private fun applyHeroExtraArt(item: TitleCard) {
        root.removeView(heroExtraArt)
        root.addView(heroExtraArt, extraArtHeroParams())
        val sourceMode = config.extraArtworkSourceMode.coerceIn(0, 4)
        val url = when (sourceMode) {
            1 -> item.logoUrl ?: item.posterUrl ?: item.backdropUrl
            2 -> item.backdropUrl ?: item.posterUrl ?: item.logoUrl
            3 -> item.posterUrl ?: item.logoUrl ?: item.backdropUrl
            4 -> item.logoUrl ?: item.backdropUrl ?: item.posterUrl
            else -> item.posterUrl ?: item.logoUrl ?: item.backdropUrl
        }
        if (url.isNullOrBlank()) {
            heroExtraArt.setImageDrawable(ContextCompat.getDrawable(this, item.backgroundRes))
        } else {
            Glide.with(this).load(url).apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)).into(heroExtraArt)
        }
        heroExtraArt.visibility = View.VISIBLE
        val depth = config.extraArtworkDepthPercent.coerceIn(0, 100)
        heroExtraArt.rotationY = if (config.extraArtwork3dEnabled == 1) -(depth * 0.06f) else 0f
        heroExtraArt.translationZ = if (config.extraArtwork3dEnabled == 1) dp((depth / 5).coerceIn(0, 20)).toFloat() else 0f
        val layerScale = if (config.extraArtwork3dEnabled == 1) 1f + depth / 900f else 1f
        ArtworkLayerEngine.apply(heroExtraArt, ArtworkLayerEngine.Config(scale = layerScale, alpha = 1f, visible = true, z = heroExtraArt.translationZ))
        Log.i(TAG, "HERO_EXTRA_ART_LAYER_APPLY: placement=" + config.extraArtworkPlacement + " sourceMode=" + sourceMode + " heroIntegrated=true layered=true")
    }

    private fun extraArtHeroParams(): FrameLayout.LayoutParams {
        val w = dp(config.extraArtworkWidthDp)
        val h = dp(config.extraArtworkHeightDp)
        val placement = config.extraArtworkPlacement.coerceIn(0, 3)
        val gravity = when (placement) {
            1 -> Gravity.TOP or Gravity.START
            2 -> Gravity.TOP or Gravity.END
            3 -> Gravity.CENTER
            else -> Gravity.TOP or Gravity.END
        }
        return FrameLayout.LayoutParams(w, h, gravity).apply {
            topMargin = if (placement == 3) dp(config.extraArtworkOffsetYDp) else dp(150 + config.extraArtworkOffsetYDp)
            leftMargin = dp(52 + config.extraArtworkOffsetXDp)
            rightMargin = dp(86 - config.extraArtworkOffsetXDp)
        }
    }

    private fun launchDetails(item: TitleCard) {
        startActivity(Intent(this, MediaDetailsActivity::class.java).apply {
            putExtra(MediaDetailsActivity.EXTRA_TITLE, item.title)
            putExtra(MediaDetailsActivity.EXTRA_META_LINE, item.meta)
            putExtra(MediaDetailsActivity.EXTRA_DESC, item.desc)
            putExtra(MediaDetailsActivity.EXTRA_MEDIA_TYPE, item.mediaType)
            putExtra(MediaDetailsActivity.EXTRA_EXTERNAL_ID, item.externalId ?: item.title)
            putExtra(MediaDetailsActivity.EXTRA_POSTER_URL, item.posterUrl ?: "")
            putExtra(MediaDetailsActivity.EXTRA_BACKDROP_URL, item.backdropUrl ?: item.posterUrl ?: "")
            putExtra(MediaDetailsActivity.EXTRA_LOGO_URL, item.logoUrl ?: "")
        })
    }

    private fun applyCardFocus(view: View, focused: Boolean) {
        view.animate().cancel()
        val scale = if (focused) config.focusedScalePercent.coerceIn(100, 125) / 100f else 1f
        val lift = if (focused) dp(config.cardLiftDp.coerceIn(0, 24)).toFloat() else 0f
        view.background = rounded(
            if (focused) 0xFF111927.toInt() else if (config.glassCardMode == 1) 0xAA121A26.toInt() else 0xFF0B0F18.toInt(),
            config.cornerRadiusDp,
            if (focused && config.focusRingEnabled == 1) 0xFFFFD84A.toInt() else 0x22FFFFFF,
            if (focused && config.focusRingEnabled == 1) config.focusRingThicknessDp.coerceAtLeast(1) else 1
        )
        view.animate().scaleX(scale).scaleY(scale).translationZ(lift).setDuration(110).start()
    }

    private fun loadImage(target: ImageView, url: String?, fallbackRes: Int) {
        if (url.isNullOrBlank()) {
            target.setImageResource(fallbackRes)
        } else {
            Glide.with(this).load(url).placeholder(fallbackRes).error(fallbackRes).apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)).into(target)
        }
    }

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int, strokeDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(dp(strokeDp).coerceAtLeast(0), strokeColor)
    }

    private fun roundOutline(radiusDp: Int): ViewOutlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, dp(radiusDp).toFloat())
        }
    }

    private fun fallbackDrawable(index: Int): Int = when (index % 9) {
        0 -> R.drawable.bg_shogun
        1 -> R.drawable.bg_batman
        2 -> R.drawable.bg_fallout
        3 -> R.drawable.bg_dune
        4 -> R.drawable.bg_halo
        5 -> R.drawable.bg_wonka
        6 -> R.drawable.bg_mayor
        7 -> R.drawable.bg_civilwar
        else -> R.drawable.bg_avatar
    }

    private fun defaultRows(): List<HomeRow> {
        val base = listOf(
            TitleCard("The Housemaid", "2025  •  Popular   IMDb 6.8", "A young woman enters a mansion of secrets, manipulation, and escalating psychological games.", R.drawable.bg_shogun, mediaType = "movie", externalId = "the-housemaid"),
            TitleCard("Michael", "2025  •  Music Drama", "A cinematic music-story spotlight with large landscape artwork.", R.drawable.bg_batman, mediaType = "movie", externalId = "michael"),
            TitleCard("Send Help", "2025  •  Thriller", "A bold poster-driven hero example for the rebuilt row engine.", R.drawable.bg_fallout, mediaType = "movie", externalId = "send-help"),
            TitleCard("Dune", "2024  •  Sci-Fi", "Expansive cinema artwork with clean DPAD navigation.", R.drawable.bg_dune, mediaType = "movie", externalId = "dune"),
            TitleCard("Halo", "Series  •  Action", "A series card using the same rebuilt card renderer.", R.drawable.bg_halo, mediaType = "series", externalId = "halo"),
            TitleCard("Wonka", "Movie  •  Family", "A bright colorful fallback card.", R.drawable.bg_wonka, mediaType = "movie", externalId = "wonka")
        )
        return listOf(
            HomeRow("Featured", base),
            HomeRow("Popular Movies", base.shuffled()),
            HomeRow("Popular Shows", base.reversed()),
            HomeRow("Recently Added", base.drop(1) + base.take(1)),
            HomeRow("Because You Watched", base.drop(2) + base.take(2))
        )
    }
}
