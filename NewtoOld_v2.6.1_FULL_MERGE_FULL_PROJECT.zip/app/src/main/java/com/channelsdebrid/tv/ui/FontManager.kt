package com.channelsdebrid.tv.ui

import android.graphics.Typeface
import android.widget.TextView
import com.channelsdebrid.tv.settings.homeLayoutTypeface

/** Global font resolver used by hero, menu, rows, cards, and editor preview. */
object FontManager {
    fun typeface(index: Int): Typeface = homeLayoutTypeface(index)

    fun apply(textView: TextView, index: Int) {
        textView.typeface = typeface(index)
    }
}
