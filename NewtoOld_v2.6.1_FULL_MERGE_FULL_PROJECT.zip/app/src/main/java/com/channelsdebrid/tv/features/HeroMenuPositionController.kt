package com.channelsdebrid.tv.features

import android.view.View
import android.widget.FrameLayout
import com.channelsdebrid.tv.settings.HomeLayoutSettings
import com.channelsdebrid.tv.ui.UIScaler

/** Simple hero top-menu position support: Top / Center / Lower. */
object HeroMenuPositionController {
    const val TOP = 0
    const val CENTER = 1
    const val LOWER = 2

    fun apply(menuView: View?, config: HomeLayoutSettings) {
        menuView ?: return
        val params = menuView.layoutParams as? FrameLayout.LayoutParams ?: return
        val preset = when {
            config.topMenuOffsetDp <= -40 -> TOP
            config.topMenuOffsetDp >= 80 -> LOWER
            else -> CENTER
        }
        val base = when (preset) {
            TOP -> 32
            LOWER -> 168
            else -> 92
        }
        params.topMargin = UIScaler.scaleDp(base + config.topMenuOffsetDp.coerceIn(-80, 120), menuView.context)
        menuView.layoutParams = params
        menuView.requestLayout()
        menuView.invalidate()
    }
}
