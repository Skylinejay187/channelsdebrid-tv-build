package com.channelsdebrid.tv.ui

import android.content.Context
import android.util.Log
import com.channelsdebrid.tv.settings.HomeLayoutSettings

/**
 * NewtoOld v2.6 single runtime UI state bus.
 * Keeps layout/editor settings tied to the real renderers instead of fake preview-only toggles.
 */
object UIConfigManager {
    private const val TAG = "DC_UI_CONFIG"
    private val listeners = linkedSetOf<() -> Unit>()

    @Volatile
    var current: HomeLayoutSettings = HomeLayoutSettings()
        private set

    fun setConfig(config: HomeLayoutSettings, notify: Boolean = true) {
        current = config
        Log.i(TAG, "UI_CONFIG_UPDATED fontHero=${config.heroFontIndex} fontContent=${config.contentFontIndex} uiMode=${config.uiResolutionMode} artwork=${config.artworkSourceMode}")
        if (notify) notifyChanged()
    }

    fun register(listener: () -> Unit) {
        listeners.add(listener)
    }

    fun unregister(listener: () -> Unit) {
        listeners.remove(listener)
    }

    fun notifyChanged() {
        listeners.toList().forEach { runCatching { it.invoke() } }
    }

    fun is4KActive(context: Context, config: HomeLayoutSettings = current): Boolean {
        val width = context.resources.displayMetrics.widthPixels
        return when (config.uiResolutionMode.coerceIn(0, 1)) {
            1 -> true
            else -> false
        } || width >= 3840 && config.heroQualityMode == 1
    }
}
