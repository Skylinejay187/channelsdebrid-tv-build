package com.channelsdebrid.tv.features

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.channelsdebrid.tv.ui.UIScaler

/** Programmatic IMDb/TMDB badge row used by hero renderers that do not use XML binding. */
object HeroRatingBadgeSystem {
    fun createBadgeRow(context: Context, imdbRating: String?, tmdbRating: String?): LinearLayout {
        return LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(createBadge(context, "IMDb", imdbRating ?: "--", 0xFFFFC400.toInt(), Color.BLACK))
            addView(spacer(context, 10))
            addView(createBadge(context, "TMDB", tmdbRating ?: "--", 0xFF01D277.toInt(), Color.WHITE))
        }
    }

    private fun createBadge(context: Context, label: String, value: String, bg: Int, fg: Int): TextView {
        return TextView(context).apply {
            text = "$label  $value"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(fg)
            gravity = Gravity.CENTER
            setPadding(UIScaler.scaleDp(8, context), UIScaler.scaleDp(3, context), UIScaler.scaleDp(8, context), UIScaler.scaleDp(3, context))
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = UIScaler.scaleDp(6, context).toFloat()
                setColor(bg)
            }
        }
    }

    private fun spacer(context: Context, widthDp: Int) = android.view.View(context).apply {
        layoutParams = LinearLayout.LayoutParams(UIScaler.scaleDp(widthDp, context), 1)
    }
}
