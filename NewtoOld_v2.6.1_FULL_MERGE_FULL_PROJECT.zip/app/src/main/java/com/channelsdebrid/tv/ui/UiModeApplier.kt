package com.channelsdebrid.tv.ui

import android.content.Context
import android.util.Log
import com.channelsdebrid.tv.settings.HomeLayoutSettings

/** Applies the v2.6 true 4K/1080 UI render density before building the view tree. */
object UiModeApplier {
    private const val TAG = "DC_UI_MODE"

    fun apply(context: Context, config: HomeLayoutSettings) {
        val metrics = context.resources.displayMetrics
        when (config.uiResolutionMode.coerceIn(0, 1)) {
            1 -> {
                metrics.density = 1.0f
                metrics.scaledDensity = 1.0f
            }
            else -> {
                // Keep platform density for 1080p/default mode. This avoids forcing devices into a broken bucket.
            }
        }
        Log.i(TAG, "DC_UI_MODE_APPLY mode=${if (config.uiResolutionMode == 1) "TRUE_4K" else "1080P_DEFAULT"} width=${metrics.widthPixels} height=${metrics.heightPixels} density=${metrics.density}")
    }
}
