# NewtoOld v2.6 UI Consolidation Audit

Base used: NewtoOld v2.5.1 HDHR/Hero Rating full project uploaded in conversation.

Clean/stable build rule: old app remains foundation; new app remains donor/reference only. Backendless direct endpoint behavior is preserved. Backend/debrid systems are not reintroduced.

Included v2.6 systems:
- UIConfigManager centralized runtime UI state bus.
- FontManager global font resolver for hero, top menu, row/card text, and editor preview.
- ArtworkLayerEngine for layered hero artwork transforms.
- Layout editor real-time notify path via UIConfigManager.
- UIScaler 4K-aware dp scaling path used by MainActivity and HomeLayoutEditorActivity.
- UiModeApplier true 4K density hook based on saved UI resolution mode.

Debug markers:
DC_BUILD_MARKER: NewtoOld_v2.6_UI_CONSOLIDATION_FULL_PROJECT
UI_CONFIG: CENTRALIZED
FONT_SYSTEM: GLOBAL_ACTIVE
ARTWORK_ENGINE: LAYERED_ACTIVE
LAYOUT_EDITOR: REALTIME_ACTIVE
UI_SCALING: 4K_AWARE

Future backlog retained, not implemented here:
- Backendless trailer system.
- Optional CDN provider layer.
- VOD player Dolby Vision/audio/frame-rate/resolution matching verification before final completion.
