package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.1.7 PLAYER OVERLAY INPUT FIX";
    public static final String LOG_MARKER = "DC_V0_1_7_PLAYER_OVERLAY_INPUT_FIX_ACTIVE";
    private BuildMarkers() {}
}
