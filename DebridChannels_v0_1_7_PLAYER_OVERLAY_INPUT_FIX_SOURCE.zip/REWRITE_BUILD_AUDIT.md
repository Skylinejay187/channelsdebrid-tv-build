# v0.1.7 Player Overlay Input Fix Audit

Build rule followed: clean rewrite/consolidation from the current stable visual baseline. Broken v7.x paths were not used.

Old app zip usage: reference only. I inspected the old playback/resolver behavior and recreated the same flow in the new Java clean-core app instead of copying old Kotlin Activity files.

Recreated behavior:
- Stremio `/stream/{type}/{id}.json` stream candidate parsing.
- Direct URL, externalUrl, infoHash, behaviorHints.magnet, and fileIdx detection.
- Quality/size scoring for the styled stream list.
- Real-Debrid direct unrestrict.
- Real-Debrid magnet flow: add magnet, choose/select video file, poll links, unrestrict final URL.
- Torbox create torrent / inspect files / request download link flow.
- Media3 player configured with redirect-capable HTTP datasource, user-agent, decoder fallback, and VOD buffering.
- Stream resolving now happens off the UI thread before opening the player.

Markers:
- versionName: 0.1.7
- versionCode: 17
- visible/log marker: DC_V0_1_7_PLAYER_OVERLAY_INPUT_FIX_ACTIVE

Player overlay input repair:
- Overlay now fades to alpha 0 instead of GONE, so global key routing can restore it.
- Activity dispatchKeyEvent routes player keys while playback is active.
- First key press while overlay is hidden restores controls and restarts the 5-second timer.
- DPAD center/media play-pause toggles Media3; left/right seek; back hides overlay first.
