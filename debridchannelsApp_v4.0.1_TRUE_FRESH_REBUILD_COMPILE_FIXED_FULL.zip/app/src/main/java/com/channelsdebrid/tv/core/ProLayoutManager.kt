package com.channelsdebrid.tv.core

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.RelativeLayout
import android.widget.TextView
import com.channelsdebrid.tv.settings.HomeLayoutSettings
import com.channelsdebrid.tv.settings.SettingsRepository
import com.channelsdebrid.tv.settings.homeLayoutArtworkTypeName
import com.channelsdebrid.tv.settings.homeLayoutTypeface

class ProLayoutManager(context: Context) {
    private val repository = SettingsRepository(context.applicationContext)

    fun load(): HomeLayoutSettings = repository.loadHomeLayout()

    fun save(settings: HomeLayoutSettings) {
        repository.saveHomeLayout(settings)
        BuildMarkers.trace("ProLayoutManager", "saved menu=${settings.menuCompositionMode} search=${settings.searchItemPlacement} settings=${settings.settingsItemPlacement} rowTitle=${settings.rowTitleVisibility} art=${settings.extraArtworkEnabled}:${settings.extraArtworkType}")
    }

    fun reset() {
        repository.resetHomeLayout()
        BuildMarkers.trace("ProLayoutManager", "reset")
    }

    fun applyMenuComposition(topNav: ViewGroup, floatingSearch: View?, floatingSettings: View?, cfg: HomeLayoutSettings) {
        val integrated = cfg.menuCompositionMode == 1 || cfg.menuCompositionMode == 2
        floatingSearch?.visibility = if (cfg.searchItemPlacement == 0 || (cfg.menuCompositionMode == 2 && cfg.searchItemPlacement != 3)) View.VISIBLE else View.GONE
        floatingSettings?.visibility = if (cfg.settingsItemPlacement == 0 || (cfg.menuCompositionMode == 2 && cfg.settingsItemPlacement != 3)) View.VISIBLE else View.GONE
        topNav.visibility = View.VISIBLE
        typefaceAll(topNav, homeLayoutTypeface(cfg.topMenuFontIndex))
        renameNavItem(topNav, "navSearch", if (integrated && cfg.searchItemPlacement == 1) "⌕ Search" else null)
        renameNavItem(topNav, "navSettings", if (integrated && cfg.settingsItemPlacement == 1) "⚙ Settings" else null)
        BuildMarkers.trace("ProLayoutManager", "applied menu mode=${cfg.menuCompositionMode}")
    }

    fun applyHeroArtwork(host: ViewGroup, cfg: HomeLayoutSettings) {
        val tag = "v4_extra_artwork_layer"
        for (i in host.childCount - 1 downTo 0) {
            val child = host.getChildAt(i)
            if (child.tag == tag) host.removeViewAt(i)
        }
        if (cfg.extraArtworkEnabled != 1) return
        val art = TextView(host.context).apply {
            this.tag = tag
            text = homeLayoutArtworkTypeName(cfg.extraArtworkType)
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            alpha = cfg.extraArtworkOpacityPercent.coerceIn(20, 100) / 100f
            rotationY = -0.12f * cfg.extraArtworkDepthPercent.coerceIn(0, 100)
            translationZ = dp(host.context, (cfg.extraArtworkDepthPercent / 8).coerceAtLeast(1)).toFloat()
            setBackgroundColor(0x55202636)
        }
        val width = dp(host.context, cfg.extraArtworkWidthDp.coerceIn(80, 640))
        val height = dp(host.context, cfg.extraArtworkHeightDp.coerceIn(60, 420))
        val left = dp(host.context, cfg.extraArtworkXdp.coerceIn(0, 1500))
        val top = dp(host.context, cfg.extraArtworkYdp.coerceIn(0, 900))
        val params: ViewGroup.LayoutParams = when (host) {
            is FrameLayout -> FrameLayout.LayoutParams(width, height).apply {
                leftMargin = left
                topMargin = top
            }
            is RelativeLayout -> RelativeLayout.LayoutParams(width, height).apply {
                leftMargin = left
                topMargin = top
            }
            else -> ViewGroup.MarginLayoutParams(width, height).apply {
                leftMargin = left
                topMargin = top
            }
        }
        host.addView(art, params)
        BuildMarkers.trace("ProLayoutManager", "applied hero artwork type=${cfg.extraArtworkType}")
    }

    private fun renameNavItem(root: ViewGroup, resourceName: String, label: String?) {
        val id = root.resources.getIdentifier(resourceName, "id", root.context.packageName)
        if (id == 0) return
        val view = root.findViewById<TextView?>(id) ?: return
        if (label == null) return
        view.visibility = View.VISIBLE
        view.text = label
        view.isFocusable = true
        view.isClickable = true
    }

    private fun typefaceAll(root: ViewGroup, typeface: android.graphics.Typeface) {
        for (i in 0 until root.childCount) {
            val child = root.getChildAt(i)
            if (child is TextView) child.typeface = typeface
            if (child is ViewGroup) typefaceAll(child, typeface)
        }
    }

    private fun dp(context: Context, value: Int): Int = (value * context.resources.displayMetrics.density).toInt()
}
