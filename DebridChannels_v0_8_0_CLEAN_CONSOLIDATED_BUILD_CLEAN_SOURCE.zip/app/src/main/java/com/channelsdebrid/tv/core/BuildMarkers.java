package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.8.0 Clean Consolidated Build";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.8.0_clean_consolidated_build_helpers_stable_clean_base";
}
