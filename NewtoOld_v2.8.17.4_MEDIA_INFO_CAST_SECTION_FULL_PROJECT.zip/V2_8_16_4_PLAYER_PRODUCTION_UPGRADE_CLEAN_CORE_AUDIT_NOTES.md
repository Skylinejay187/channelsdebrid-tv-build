# NewtoOld v2.8.16.4 Player Production Upgrade + Clean Core Audit

Base used: NewtoOld_v2.8.16.3_PLAYBACK_CACHE_OFF_DIRECT_FIX_FULL_PROJECT.

Preserved:
- Donor/new-app one-active-row renderer from v2.8.16.1.
- Focus scale/ring/lift effects from v2.8.16.2.
- Original/high-quality hero backdrop path from v2.8.16.2.
- Cache default OFF and internal disk cache blocked from v2.8.16.3.
- Extra artwork layer and Pro Layout Editor paths.

Player changes:
- Added player production diagnostic logs for source, media item, state transitions, timeline, loading, first frame, video size, tracks, and player errors.
- Added media audio attributes for VOD/live playback with media/movie content type and audio focus handling.
- Kept cache OFF as direct ExoPlayer playback only.
- Kept NAS/USB cache gated behind explicit storage configuration.
- Added release logging to verify player and cache resources are cleaned up.

Clean-core audit:
- Active home row renderer remains donor/new-app one-row path only.
- Old NewtoOld stacked row renderer remains bypassed/deleted as an active execution path.
- No internal disk VOD cache fallback is allowed.
- Legacy NAS prefetch work remains backlog-only unless NAS/USB cache is explicitly enabled.

Verification markers:
- DC_BUILD_MARKER: NewtoOld_v2.8.16.4_PLAYER_PRODUCTION_UPGRADE_CLEAN_CORE_AUDIT
- PLAYER_PRODUCTION_UPGRADE: v2.8.16.4 diagnostics audio_attrs cache_gate clean_core_audit
- CLEAN_CORE_AUDIT: old_row_stack_deleted active_donor_row_only cache_off_direct_player_preserved
