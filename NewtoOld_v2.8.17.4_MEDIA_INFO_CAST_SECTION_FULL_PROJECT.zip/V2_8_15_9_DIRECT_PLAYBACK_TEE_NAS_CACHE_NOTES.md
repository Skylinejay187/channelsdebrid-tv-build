# NewtoOld v2.8.15.9 - Direct Playback Tee NAS Cache Fix

Audit rule: built as a stabilization/consolidation from the latest v2.8.15.8 source. No UI redesign. Preserved existing features and build markers.

## What changed
- Removed the localhost proxy playback replacement from the active VOD path because it caused sources not to load on-device.
- Playback now stays on the original resolved source URL.
- Added a DataSource tee that mirrors the exact bytes ExoPlayer reads to SMB `.dcache` during playback.
- Keeps Option B cleanup: temporary `.dcache` + manifest are deleted when playback exits.
- Manifest states now include `tee_ready`, `tee_active`, `tee_complete_until_exit`, and tee write failure states.

## Important behavior note
This is the safe source-loading fix. It mirrors the active playback stream to NAS without opening a second source connection and without replacing the player URL.
