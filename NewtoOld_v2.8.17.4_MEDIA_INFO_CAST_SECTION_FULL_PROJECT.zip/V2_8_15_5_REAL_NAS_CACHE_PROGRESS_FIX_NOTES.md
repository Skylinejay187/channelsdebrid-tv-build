# NewtoOld v2.8.15.5 Real NAS Cache Progress Fix

Base: NewtoOld_v2.8.15.4_REAL_NAS_CACHE_ENGINE.

Scope: no UI redesign. This build only fixes the NAS cache engine/progress path.

Changes:
- NAS mode no longer creates/uses local ExoPlayer SimpleCache as the displayed cache source.
- Playback remains direct/instant while the real SMB writer fills the `.dcache` file in the background.
- NAS cache label now only trusts bytes written by the SMB writer.
- NAS progress bar secondary progress now uses real `.dcache` percent only, not ExoPlayer buffer/watched position.
- HTTP writer now handles servers that reject range resume by restarting the full stream cleanly instead of appending bad progress.
- Connection attempts now try plain full-stream GET earlier because some debrid/CDN links reject Range probes but allow normal GET.

Expected verification:
- `vod_cache_manifest.txt` should move from `starting` to `active`.
- `bytes=` should grow above 0 while movie is playing.
- `.dcache` file on NAS should grow in real time.
- `percent=` should increase when total size is known.
