# NewtoOld v2.2 — Hero Artwork / Extra Artwork / UI Options Fix

Base: NewtoOld v2.1 full project.

## Fixed in this pass
- Preserved working rebuilt row scrolling from v2.1. No row-engine rewrite in this pass because DOWN/UP scrolling was reported working.
- Restored hero logo artwork support: when a catalog item provides `logoUrl`, it renders as a hero title logo; if no logo exists, the text title fallback returns.
- Restored row-card center logo artwork: row cards now render centered logo artwork when `logoUrl` exists and fall back to card title text when missing.
- Added extra artwork sizing controls:
  - width
  - height
  - left/right offset
  - up/down offset
  - placement
  - source mode
  - 3D depth
- Status hub is now optional and defaults hidden.
- Added full UI resolution toggle in the layout editor: 1080p default / 4K enabled.
- Kept hero quality mode as separate 1080p/4K hero artwork mode.
- Top menu remains the newer v2.1 menu system.
- Real-Debrid/TorBox are forced direct-only in stream resolver and hidden from settings UI.

## Verification log markers
- `DC_BUILD_MARKER: NewtoOld_v2.2_HERO_LOGO_EXTRA_ART_UI_FIX`
- `HERO_LOGO_ARTWORK_APPLY`
- `CARD_LOGO_ARTWORK_APPLY`
- `HERO_EXTRA_ART_LAYER_APPLY`
- `STATUS_HUB_VISIBLE_APPLY`
- `HERO_QUALITY_MODE_APPLY`
- `DEBRID_STATUS: NOT_PRESENT directOnly=true`

## Not touched
- Live TV logic/player path.
- Working row focus behavior from v2.1.
- Top menu runtime structure, except preserving theme/font usage.

## Build note
Gradle is not installed in this container, so this package was not compile-tested here.
