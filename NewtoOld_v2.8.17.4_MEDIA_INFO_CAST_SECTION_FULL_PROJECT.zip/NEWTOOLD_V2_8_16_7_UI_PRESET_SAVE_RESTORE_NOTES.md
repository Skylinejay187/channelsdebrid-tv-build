# NewtoOld v2.8.16.7 UI Preset Save/Restore

Scope: UI preset export/import only. No player, row renderer, cache, hero quality, focus effect, resolver, or CDN behavior changed.

Added:
- Home Layout Editor: Export button writes `DebridChannels_UI_Preset.json`.
- Home Layout Editor: Import button restores the same preset file and reloads the editor.
- Preset includes only safe visual UI keys with the `home_layout_` prefix.
- Preset intentionally excludes passwords, API keys, debrid tokens, NAS/SMB settings, cache paths, addon JSON, URLs, and server info.
- Export path preference: public Downloads folder, fallback to app external files folder.

Preserved:
- v2.8.16.6 row change reset to first card behavior.
- v2.8.16.5 player production stack behavior.
- v2.8.16.3 cache-off direct playback gate.
- v2.8.16.2 focus effects and high-quality hero backdrop behavior.

Backlog next:
- CDN support setup after preset system verification.
