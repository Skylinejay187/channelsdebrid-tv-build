# NewtoOld v2.8.15.12 — Cache Default Off / Internal Disk Blocked

## Purpose
The forced full-ahead NAS prefetch engine is moved to backlog because on-device testing still reported `Cache: prefetch waiting for source`.

## Current behavior
- Movie/VOD cache is OFF by default.
- Internal disk movie caching is blocked completely.
- Cache can only be enabled after selecting/configuring NAS/SMB or USB/external storage.
- No internal fallback is allowed when NAS or USB fails. Playback stays direct instead.

## Backlog
- Revisit Infuse/Sparkle-style source-byte interception/full-ahead prefetch engine later.
- Must use real received bytes only; no fake cache UI and no internal-disk fallback.
