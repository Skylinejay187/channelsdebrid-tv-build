# NewtoOld v2.8.15.6 — Full NAS Cache + Row/Logo Rewrite

Base used: v2.8.15.5 clean project zip.

## Real NAS cache engine changes
- Reworked the VOD NAS writer so it is not a one-shot small patch.
- Writer now continues independently from ExoPlayer and keeps reconnecting/resuming until the full HTTP/MP4 source is written to the SMB `.dcache` file.
- Increased SMB socket/response timeouts for long movie writes.
- Increased HTTP read timeout for full-length movie caching.
- Added browser-style headers plus ExoPlayer-style fallback headers to reduce debrid/CDN parallel-source refusal.
- Manifest now reports active retry states instead of immediately pretending the cache is done or stuck.
- Manifest states to verify:
  - `starting`
  - `active`
  - `waiting_source_start`
  - `waiting_source_resume`
  - `active_reconnect`
  - `complete`
- Correct target behavior: `.dcache` grows on NAS while playback continues, percent increases when total is known, and final state becomes `complete`.

## Hero/row/logo rewrite changes
- Updated row engine marker to V4 stable DPAD/no-jump path.
- Reduced forced row snap offset that caused visible row jumping during DPAD navigation.
- Stremio catalog rows now attempt meta-detail logo lookup when catalog payload does not include `logo`.
- New addon/catalog cards now show a centered title-logo fallback inside the card when no clear logo exists, so cards are not visually blank.

## Build markers
- `DC_BUILD_MARKER: NewtoOld_v2.8.15.6_FULL_NAS_CACHE_ROW_REWRITE`
- `ROW_ENGINE: V4_STABLE_DPAD_NO_JUMP_LOGO_FALLBACK`
- `VOD_REAL_NAS_CACHE` log lines show actual NAS writer state.

## Verification
- Open VOD with NAS cache enabled.
- Watch `DebridChannelsVodCache/<sha1>.dcache` on SMB.
- File size should grow repeatedly.
- `vod_cache_manifest.txt` should move from `starting/active` to `complete`.
- Added Stremio rows should show either a real logo from meta lookup or centered title-logo fallback.
