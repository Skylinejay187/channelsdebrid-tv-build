# v2.8.15.8 Single Source NAS Cache Proxy

Clean/consolidated from v2.8.15.7 source. This version changes VOD NAS caching from a second parallel downloader to a single-source local proxy path:

ExoPlayer -> 127.0.0.1 app proxy -> upstream stream
                         -> same bytes mirrored to SMB .dcache

Why: some debrid/CDN URLs allow the player but refuse a second downloader connection. The proxy uses the player stream as the only upstream source, so NAS cache bytes are the same bytes that playback receives.

Option B behavior: cache exists only while watching. When PlayerActivity exits, the proxy stops and deletes the temporary .dcache and manifest.

Verification markers:
- VOD_NAS_PROXY: enabled
- VOD_NAS_PROXY: active_proxy
- VOD_NAS_PROXY: complete_until_exit
- VOD_NAS_PROXY: cleanup_deleted
