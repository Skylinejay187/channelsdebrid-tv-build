package com.channelsdebrid.tv

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.channelsdebrid.tv.data.UnifiedCatalogRepository
import com.channelsdebrid.tv.playback.MediaDetailsActivity
import com.channelsdebrid.tv.playback.PlayerActivity
import java.util.concurrent.Executors

class BrowseSectionActivity : AppCompatActivity() {
    private lateinit var repo: UnifiedCatalogRepository
    private lateinit var rows: LinearLayout
    private lateinit var heroTitle: TextView
    private lateinit var heroMeta: TextView
    private lateinit var heroBg: ImageView
    private var section = "movies"
    private val executor = Executors.newSingleThreadExecutor()
    private var loadVersion = 0

    private val firstPageSize = 36
    private val nextPageSize = 18

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = UnifiedCatalogRepository(this)
        section = intent.getStringExtra(EXTRA_SECTION) ?: "movies"
        setContentView(buildLayout())
        renderSection()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildLayout(): View {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(3, 5, 9)) }
        heroBg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; alpha = 0.38f }
        root.addView(heroBg, FrameLayout.LayoutParams(-1, dp(310)))
        val shade = View(this).apply { background = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x66000000, 0xFF030509.toInt())) }
        root.addView(shade, FrameLayout.LayoutParams(-1, dp(340)))
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(52), dp(34), dp(52), 0) }
        heroTitle = TextView(this).apply { textSize = 38f; setTextColor(Color.WHITE); typeface = android.graphics.Typeface.DEFAULT_BOLD }
        heroMeta = TextView(this).apply { textSize = 15f; setTextColor(0xFFD7CCBF.toInt()); setPadding(0, dp(4), 0, dp(20)) }
        content.addView(heroTitle)
        content.addView(heroMeta)
        val scroll = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER; isFillViewport = false }
        rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(rows)
        content.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(content)
        return root
    }

    private fun renderSection() {
        val title = if (section == "shows") "TV Shows" else "Movies"
        heroTitle.text = title
        heroMeta.text = if (section == "shows") "Expanded TV discovery from TMDB, Stremio, Cinemeta, and installed addon catalogs" else "Expanded movie discovery from TMDB, Stremio, Cinemeta, and installed addon catalogs"
        val version = ++loadVersion
        rows.removeAllViews()
        rows.addView(loadingRow("Loading ${title.lowercase()} discovery rows…"))
        executor.execute {
            val discoveryRows = repo.discoveryRows(section)
            runOnUiThread {
                if (version != loadVersion || isFinishing || isDestroyed) return@runOnUiThread
                rows.removeAllViews()
                if (discoveryRows.isEmpty()) {
                    rows.addView(loadingRow("No ${title.lowercase()} rows are available. Add a TMDB key or Stremio catalog addon in Settings."))
                    return@runOnUiThread
                }
                discoveryRows.forEach { row -> addRow(row) }
                discoveryRows.firstOrNull()?.items?.firstOrNull()?.let { updateHero(it) }
            }
        }
    }

    private fun loadingRow(text: String): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(18), 0, dp(18))
            addView(ProgressBar(this@BrowseSectionActivity).apply { isIndeterminate = true }, LinearLayout.LayoutParams(dp(28), dp(28)).apply { rightMargin = dp(12) })
            addView(TextView(this@BrowseSectionActivity).apply {
                this.text = text
                textSize = 18f
                setTextColor(0xCCFFFFFF.toInt())
            })
        }
    }

    private fun addRow(row: UnifiedCatalogRepository.CatalogRow) {
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(10)) }
        header.addView(TextView(this).apply {
            text = row.title
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(TextView(this).apply {
            text = "${row.items.size} items"
            textSize = 13f
            setTextColor(0x99FFFFFF.toInt())
        })
        rows.addView(header)

        val scroller = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val lane = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val visible = row.items.take(firstPageSize).toMutableList()
        visible.forEach { lane.addView(portraitCard(it)) }
        if (row.items.size > visible.size) lane.addView(loadMoreCard(row, lane, visible))
        scroller.addView(lane)
        rows.addView(scroller, LinearLayout.LayoutParams(-1, dp(266)).apply { bottomMargin = dp(12) })
    }

    private fun loadMoreCard(row: UnifiedCatalogRepository.CatalogRow, lane: LinearLayout, visible: MutableList<UnifiedCatalogRepository.MediaItem>): View {
        val frame = FrameLayout(this).apply {
            isFocusable = true
            isClickable = true
            background = rounded(0xFF141A26.toInt(), 0x33FFFFFF, dp(16), dp(1))
            layoutParams = LinearLayout.LayoutParams(dp(142), dp(213)).apply { rightMargin = dp(14) }
        }
        frame.addView(TextView(this).apply {
            text = "Load\nMore"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }, FrameLayout.LayoutParams(-1, -1))
        frame.setOnFocusChangeListener { v, hasFocus ->
            v.animate().scaleX(if (hasFocus) 1.035f else 1f).scaleY(if (hasFocus) 1.035f else 1f).setDuration(120).start()
        }
        frame.setOnClickListener {
            val start = visible.size
            val next = row.items.drop(start).take(nextPageSize)
            if (next.isEmpty()) return@setOnClickListener
            lane.removeView(frame)
            next.forEach { item ->
                visible.add(item)
                lane.addView(portraitCard(item))
            }
            if (visible.size < row.items.size) lane.addView(loadMoreCard(row, lane, visible))
        }
        return frame
    }

    private fun portraitCard(item: UnifiedCatalogRepository.MediaItem): View {
        val frame = FrameLayout(this).apply {
            isFocusable = true
            isClickable = true
            background = rounded(0xFF101722.toInt(), 0, dp(16), 0)
            layoutParams = LinearLayout.LayoutParams(dp(142), dp(213)).apply { rightMargin = dp(14) }
        }
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(0xFF0B0F18.toInt()) }
        frame.addView(img, FrameLayout.LayoutParams(-1, -1))
        val gradient = View(this).apply { background = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0xAA000000.toInt())) }
        frame.addView(gradient, FrameLayout.LayoutParams(-1, -1))
        val label = TextView(this).apply {
            text = item.title
            textSize = 13.5f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.BOTTOM
            setPadding(dp(9), 0, dp(9), dp(9))
            maxLines = 2
        }
        frame.addView(label, FrameLayout.LayoutParams(-1, -1))
        val art = item.posterUrl.ifBlank { item.backdropUrl }
        if (art.isNotBlank()) Glide.with(this).load(art).centerCrop().thumbnail(0.15f).into(img)
        frame.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) updateHero(item)
            v.background = if (hasFocus) rounded(0xFF101722.toInt(), 0xFFFFFFFF.toInt(), dp(16), dp(2)) else rounded(0xFF101722.toInt(), 0, dp(16), 0)
            v.animate().scaleX(if (hasFocus) 1.045f else 1f).scaleY(if (hasFocus) 1.045f else 1f).setDuration(120).start()
        }
        frame.setOnClickListener { openItem(item) }
        return frame
    }

    private fun updateHero(item: UnifiedCatalogRepository.MediaItem) {
        heroTitle.text = item.title
        heroMeta.text = listOf(if (item.type == "series") "TV Show" else "Movie", item.meta).filter { it.isNotBlank() }.joinToString("  •  ")
        val art = item.backdropUrl.ifBlank { item.posterUrl }
        if (art.isNotBlank()) Glide.with(this).load(art).centerCrop().thumbnail(0.15f).into(heroBg)
    }

    private fun openItem(item: UnifiedCatalogRepository.MediaItem) {
        if (item.type == "live" && item.streamUrl.isNotBlank()) {
            startActivity(Intent(this, PlayerActivity::class.java).apply { putExtra(PlayerActivity.EXTRA_STREAM_URL, item.streamUrl); putExtra(PlayerActivity.EXTRA_TITLE, item.title); putExtra(PlayerActivity.EXTRA_SOURCE_LABEL, item.meta) })
            return
        }
        startActivity(Intent(this, MediaDetailsActivity::class.java).apply {
            putExtra(MediaDetailsActivity.EXTRA_TITLE, item.title)
            putExtra(MediaDetailsActivity.EXTRA_META_LINE, item.meta)
            putExtra(MediaDetailsActivity.EXTRA_DESC, item.overview)
            putExtra(MediaDetailsActivity.EXTRA_MEDIA_TYPE, if (item.type == "series") "series" else "movie")
            putExtra(MediaDetailsActivity.EXTRA_EXTERNAL_ID, item.externalId)
            putExtra(MediaDetailsActivity.EXTRA_POSTER_URL, item.posterUrl)
            putExtra(MediaDetailsActivity.EXTRA_BACKDROP_URL, item.backdropUrl)
            putExtra(MediaDetailsActivity.EXTRA_LOGO_URL, item.logoUrl)
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int, strokeWidth: Int) = android.graphics.drawable.GradientDrawable().apply { shape = android.graphics.drawable.GradientDrawable.RECTANGLE; setColor(fill); cornerRadius = radius.toFloat(); if (strokeWidth > 0) setStroke(strokeWidth, stroke) }

    companion object { const val EXTRA_SECTION = "section" }
}
