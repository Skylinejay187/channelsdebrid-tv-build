package com.channelsdebrid.tv

import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.widget.ProgressBar
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.ui.PlayerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.channelsdebrid.tv.live.LiveSourceResolver
import com.channelsdebrid.tv.BuildConfig
import com.channelsdebrid.tv.data.LiveGuideProgramResolver
import com.channelsdebrid.tv.playback.PlayerActivity
import com.channelsdebrid.tv.settings.SettingsRepository
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ExecutorService
import kotlin.math.roundToInt

class LiveTvActivity : AppCompatActivity() {

    private lateinit var settingsRepository: SettingsRepository
    private lateinit var clockView: TextView
    private lateinit var infoLogo: TextView
    private lateinit var infoIcon: ImageView
    private lateinit var infoChannel: TextView
    private lateinit var infoGroup: TextView
    private lateinit var nowTime: TextView
    private lateinit var nowTitle: TextView
    private lateinit var descriptionView: TextView
    private lateinit var nextLine: TextView
    private lateinit var laterLine: TextView
    private lateinit var progressBar: View
    private lateinit var timelineRow: LinearLayout
    private lateinit var channelList: LinearLayout
    private lateinit var previewImage: ImageView
    private lateinit var heroBackground: ImageView
    private lateinit var previewFrame: FrameLayout
    private lateinit var previewPlayerView: PlayerView
    private lateinit var previewHint: TextView
    private lateinit var guideHeaderRow: LinearLayout
    private lateinit var categoryRail: LinearLayout
    private lateinit var categoryPanel: LinearLayout
    private lateinit var mainPanel: LinearLayout
    private lateinit var horizontalScroll: HorizontalScrollView
    private lateinit var verticalScroll: ScrollView
    private lateinit var loadingOverlay: View
    private lateinit var contentRoot: View
    private lateinit var loadingTitle: TextView
    private lateinit var loadingSubtitle: TextView
    private lateinit var channelStats: TextView
    private lateinit var forceGuideButton: Button
    private lateinit var statusTitle: TextView
    private lateinit var statusSources: TextView

    private var executor: ExecutorService = Executors.newSingleThreadExecutor()
    private var liveTvDestroyed = false
    private lateinit var guideProgramResolver: LiveGuideProgramResolver
    private val categoryCache = linkedMapOf<String, List<GuideEntry>>()
    private val categoryCountCache = linkedMapOf<String, Int>()
    private var activeLiveSourceSignature: String = ""
    private lateinit var topSpacer: SpaceView
    private lateinit var bottomSpacer: SpaceView
    private var renderWindowStart = 0
    private var renderWindowEnd = -1
    private val renderWindowSize = 14
    private val renderWindowBuffer = 5
    private val rowHeightEstimateDp = 60
    private val firstScreenChannelLimit = 48
    private val guideHydrationChunkSize = 160
    private val logoLazyLoadDelayMs = 220L
    private var guideHydrationGeneration = 0
    private var guideShellOnlyMode = false
    private var currentChannels: List<GuideEntry> = emptyList()
    private var filteredChannels: List<GuideEntry> = emptyList()
    private var categories: List<CategoryFilter> = emptyList()
    private var categoryViews: List<View> = emptyList()
    private var selectedIndex = 0
    private var selectedCategoryIndex = 0
    private var activeZone = FocusZone.CATEGORY
    private var isGuideExpanded = false
    private var previewArmedIndex = -1
    private var previewPlayer: ExoPlayer? = null
    private var previewUrl: String = ""
    private var previewRequestToken = 0
    private val previewHandler = Handler(Looper.getMainLooper())
    private var previewRunnable: Runnable? = null
    private var is4kUiEnabled = true
    private var liveStatusChecksEnabled = true
    private var guideRefreshInProgress = false
    private var playerLaunchInProgress = false
    private var liveTvInputEnabled = true
    private var lastPlayerLaunchAtMs = 0L
    private var shellExitInProgress = false
    private var topNavViews: List<TextView> = emptyList()
    private var topNavIndex = 2
    private var lastLiveFocusZone: FocusZone = FocusZone.CATEGORY
    private var lastChannelsDvrPreviewStartedAtMs = 0L
    private var channelsDvrPreviewCooldownUntilMs = 0L
    private var currentPreviewIsChannelsDvr = false
    private var previewSourceLabel: String = ""
    private val liveTvDpadKeys = setOf(
        KeyEvent.KEYCODE_DPAD_UP,
        KeyEvent.KEYCODE_DPAD_DOWN,
        KeyEvent.KEYCODE_DPAD_LEFT,
        KeyEvent.KEYCODE_DPAD_RIGHT,
        KeyEvent.KEYCODE_DPAD_CENTER,
        KeyEvent.KEYCODE_ENTER,
        KeyEvent.KEYCODE_BACK
    )

    private fun setTopNavFocusable(enabled: Boolean) {
        topNavViews.forEach { view ->
            view.isFocusable = enabled
            view.isFocusableInTouchMode = false
            view.isClickable = true
            if (!enabled) view.clearFocus()
        }
    }

    private fun restoreLiveTvKeyAnchor() {
        if (activeZone == FocusZone.NAV) return
        setTopNavFocusable(false)
        forceGuideButton.clearFocus()
        contentRoot.post {
            if (!isFinishing && !isDestroyed && activeZone != FocusZone.NAV && window.decorView.hasWindowFocus()) {
                contentRoot.requestFocus()
            }
        }
    }

    private fun recoverLiveTvWindowFocus(reason: String = "recover") {
        if (isFinishing || isDestroyed || activeZone == FocusZone.NAV) return
        val focusRunnable = Runnable {
            if (isFinishing || isDestroyed || activeZone == FocusZone.NAV || !window.decorView.hasWindowFocus()) return@Runnable
            setupLiveTvFocusGuard()
            setTopNavFocusable(false)
            currentFocus?.takeIf { it != contentRoot }?.clearFocus()
            contentRoot.requestFocus()
            applyZoneState()
            if (activeZone == FocusZone.GUIDE && filteredChannels.isNotEmpty()) {
                armPreviewForSelection(selectedIndex, immediate = false)
            }
        }
        contentRoot.post(focusRunnable)
        contentRoot.postDelayed(focusRunnable, 120L)
        contentRoot.postDelayed(focusRunnable, 420L)
    }

    private fun setupUnifiedShellNavigation() {
        val navResume = findViewById<TextView?>(R.id.navResume)
        val navSmart = findViewById<TextView?>(R.id.navSmart)
        val navLive = findViewById<TextView?>(R.id.navLive)
        val navMovies = findViewById<TextView?>(R.id.navMovies)
        val navShows = findViewById<TextView?>(R.id.navShows)

        topNavViews = listOfNotNull(navResume, navSmart, navLive, navMovies, navShows)
        topNavIndex = topNavViews.indexOf(navLive).takeIf { it >= 0 } ?: 0
        listOf("RESUME", "HOME", "LIVE", "MOVIES", "TV SHOWS").forEachIndexed { i, label -> topNavViews.getOrNull(i)?.text = label }
        Log.i("DebridChannels", "TOP_MENU_FLAT_THEME_ACTIVE: target=LiveTvActivity.unifiedTopNav views=${topNavViews.size}")
        topNavViews.forEachIndexed { index, view ->
            view.isFocusable = false
            view.isFocusableInTouchMode = false
            view.isClickable = true
            view.setOnFocusChangeListener { v, hasFocus ->
                v.isSelected = hasFocus || (activeZone == FocusZone.NAV && index == topNavIndex)
            }
            view.setOnKeyListener { _, _, event ->
                if (event.action == KeyEvent.ACTION_DOWN && event.keyCode in liveTvDpadKeys) handleLiveTvNavigationKey(event) else false
            }
        }

        navLive?.setOnClickListener { restoreLiveTvFocusFromTopNav() }
        navSmart?.setOnClickListener { returnToMainShell() }
        navResume?.setOnClickListener { openShellSection(ContinueWatchingActivity::class.java) }
        navMovies?.setOnClickListener { openBrowseSection("movies") }
        navShows?.setOnClickListener { openBrowseSection("shows") }
    }

    private fun focusTopNavigation() {
        if (topNavViews.isEmpty()) return
        lastLiveFocusZone = if (activeZone == FocusZone.NAV) lastLiveFocusZone else activeZone
        activeZone = FocusZone.NAV
        setTopNavFocusable(true)
        topNavIndex = topNavViews.indexOfFirst { it.id == R.id.navLive }.takeIf { it >= 0 } ?: topNavIndex.coerceIn(0, topNavViews.lastIndex)
        topNavViews.getOrNull(topNavIndex)?.requestFocus()
        updateTopNavVisualState()
        previewHint.visibility = View.VISIBLE
        previewHint.text = "Top menu • Left/Right choose section • Down returns to guide"
    }

    private fun updateTopNavVisualState() {
        topNavViews.forEachIndexed { index, view ->
            val active = activeZone == FocusZone.NAV && index == topNavIndex
            view.isSelected = active
            view.isActivated = active
            view.alpha = if (active) 1f else 0.78f
            view.scaleX = if (active) 1.045f else 1f
            view.scaleY = if (active) 1.045f else 1f
        }
    }

    private fun handleTopNavKey(keyCode: Int): Boolean {
        if (topNavViews.isEmpty()) return false
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                topNavIndex = (topNavIndex - 1).coerceAtLeast(0)
                topNavViews[topNavIndex].requestFocus()
                updateTopNavVisualState()
                return true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                topNavIndex = (topNavIndex + 1).coerceAtMost(topNavViews.lastIndex)
                topNavViews[topNavIndex].requestFocus()
                updateTopNavVisualState()
                return true
            }
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_BACK -> {
                restoreLiveTvFocusFromTopNav()
                return true
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                updateTopNavVisualState()
                return true
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                topNavViews.getOrNull(topNavIndex)?.performClick()
                return true
            }
        }
        return false
    }

    private fun restoreLiveTvFocusFromTopNav() {
        activeZone = if (lastLiveFocusZone == FocusZone.NAV) FocusZone.GUIDE else lastLiveFocusZone
        setTopNavFocusable(false)
        updateTopNavVisualState()
        contentRoot.requestFocus()
        applyZoneState()
        if (activeZone == FocusZone.GUIDE) armPreviewForSelection(selectedIndex, immediate = false)
    }

    private fun releaseLiveTvNavigationOwnership() {
        liveTvInputEnabled = false
        playerLaunchInProgress = false
        previewRequestToken++
        previewRunnable = null
        previewHandler.removeCallbacksAndMessages(null)
        previewRunnable = null
        previewRequestToken++
        previewUrl = ""
        previewPlayer?.apply {
            playWhenReady = false
            runCatching { stop() }
            runCatching { clearMediaItems() }
            runCatching { seekToDefaultPosition() }
        }
        runCatching { window.decorView.setOnKeyListener(null) }
        runCatching { contentRoot.setOnKeyListener(null) }
        runCatching { currentFocus?.clearFocus() }
        setTopNavFocusable(false)
    }

    private fun navigateAway(intent: Intent, finishLiveTv: Boolean = true) {
        if (shellExitInProgress || isFinishing || isDestroyed) return
        shellExitInProgress = true
        releaseLiveTvNavigationOwnership()
        startActivity(intent)
        if (finishLiveTv) finish()
        overridePendingTransition(0, 0)
    }

    private fun returnToMainShell() {
        navigateAway(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        )
    }

    private fun openShellSection(clazz: Class<*>) {
        navigateAway(Intent(this, clazz).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP))
    }

    private fun openBrowseSection(section: String) {
        navigateAway(
            Intent(this, BrowseSectionActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra(BrowseSectionActivity.EXTRA_SECTION, section)
            }
        )
    }

    private fun setupLiveTvFocusGuard() {
        // Android TV requires one real focused view to receive remote DPAD events.
        // The previous guard made the Live TV body non-focusable, so Android often
        // defaulted focus to the first top-nav item (Resume Watching). That made OK
        // open Continue Watching and made UP/DOWN/LEFT/RIGHT feel completely disabled.
        contentRoot.isFocusable = true
        contentRoot.isFocusableInTouchMode = false
        (contentRoot as? ViewGroup)?.descendantFocusability = ViewGroup.FOCUS_BEFORE_DESCENDANTS
        contentRoot.setOnKeyListener { _, _, event -> handleLiveTvNavigationKey(event) }

        listOfNotNull(previewFrame, previewPlayerView, mainPanel, horizontalScroll, verticalScroll, categoryRail, categoryPanel).forEach { view ->
            view.isFocusable = false
            view.isFocusableInTouchMode = false
            view.setOnKeyListener { _, _, event -> handleLiveTvNavigationKey(event) }
        }
    }

    private fun requestSyntheticLiveFocus() {
        if (topNavViews.any { it == currentFocus }) return
        forceGuideButton.clearFocus()
        horizontalScroll.clearFocus()
        verticalScroll.clearFocus()
        previewFrame.clearFocus()
        previewPlayerView.clearFocus()
    }

    private fun handleLiveTvNavigationKey(event: KeyEvent): Boolean {
        if (!liveTvInputEnabled || event.action != KeyEvent.ACTION_DOWN || event.keyCode !in liveTvDpadKeys) return false
        if ((event.keyCode == KeyEvent.KEYCODE_DPAD_CENTER || event.keyCode == KeyEvent.KEYCODE_ENTER) && event.repeatCount > 0) return true

        // Stable Live TV tree: contentRoot owns guide keys, top nav owns top-menu keys, PlayerActivity owns playback keys.
        if (activeZone == FocusZone.NAV) return handleTopNavKey(event.keyCode)

        requestSyntheticLiveFocus()

        if (currentFocus == forceGuideButton) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { forceGuideButton.performClick(); return true }
                KeyEvent.KEYCODE_DPAD_UP -> { activeZone = FocusZone.CATEGORY; selectedCategoryIndex = categories.lastIndex.coerceAtLeast(0); forceGuideButton.clearFocus(); applyZoneState(); return true }
                KeyEvent.KEYCODE_BACK -> { forceGuideButton.clearFocus(); activeZone = FocusZone.CATEGORY; applyZoneState(); return true }
                KeyEvent.KEYCODE_DPAD_RIGHT -> { activeZone = FocusZone.GUIDE; isGuideExpanded = true; forceGuideButton.clearFocus(); applyZoneState(); armPreviewForSelection(selectedIndex); return true }
                KeyEvent.KEYCODE_DPAD_LEFT -> return true
            }
        }

        if (filteredChannels.isEmpty() && categories.isEmpty()) {
            if (event.keyCode == KeyEvent.KEYCODE_BACK) { returnToMainShell(); return true }
            if (event.keyCode == KeyEvent.KEYCODE_DPAD_UP) { focusTopNavigation(); return true }
            return true
        }

        return when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> {
                when (activeZone) {
                    FocusZone.NAV -> handleTopNavKey(event.keyCode)
                    FocusZone.CATEGORY -> if (selectedCategoryIndex <= 0) { focusTopNavigation(); true } else { moveCategory(-1); applyZoneState(); true }
                    FocusZone.GUIDE -> if (selectedIndex <= 0) { focusTopNavigation(); true } else { moveSelection(-1); applyZoneState(); true }
                }
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                when (activeZone) {
                    FocusZone.NAV -> { restoreLiveTvFocusFromTopNav(); true }
                    FocusZone.CATEGORY -> {
                        if (!isGuideExpanded && selectedCategoryIndex >= categories.lastIndex && forceGuideButton.visibility == View.VISIBLE) { forceGuideButton.requestFocus(); return true }
                        moveCategory(1)
                    }
                    FocusZone.GUIDE -> moveSelection(1)
                }
                applyZoneState(); true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                when (activeZone) {
                    FocusZone.NAV -> handleTopNavKey(event.keyCode)
                    FocusZone.GUIDE -> { activeZone = FocusZone.CATEGORY; isGuideExpanded = false; applyZoneState(); true }
                    FocusZone.CATEGORY -> true
                }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                when (activeZone) {
                    FocusZone.NAV -> handleTopNavKey(event.keyCode)
                    FocusZone.CATEGORY -> { activeZone = FocusZone.GUIDE; isGuideExpanded = true; applyZoneState(); armPreviewForSelection(selectedIndex); true }
                    FocusZone.GUIDE -> true
                }
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                when (activeZone) {
                    FocusZone.NAV -> handleTopNavKey(event.keyCode)
                    FocusZone.CATEGORY -> { applyCategorySelection(selectedCategoryIndex); activeZone = FocusZone.GUIDE; isGuideExpanded = true; applyZoneState(); armPreviewForSelection(selectedIndex); true }
                    FocusZone.GUIDE -> { openPlayer(selectedIndex); true }
                }
            }
            KeyEvent.KEYCODE_BACK -> {
                when (activeZone) {
                    FocusZone.NAV -> { restoreLiveTvFocusFromTopNav(); true }
                    FocusZone.GUIDE -> { activeZone = FocusZone.CATEGORY; isGuideExpanded = false; applyZoneState(); true }
                    FocusZone.CATEGORY -> { returnToMainShell(); true }
                }
            }
            else -> false
        }
    }

    companion object {
        private const val PLAYER_REQUEST_CODE = 4207
        private const val EPG_CACHE_PREFS = "live_tv_epg_cache"
        private const val EPG_CACHE_JSON = "epg_programs_json"
        private const val EPG_CACHE_UPDATED_AT = "epg_updated_at"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i("DebridChannels", "TRUE_CLEAN_CORE_START LiveTvActivity build=" + BuildConfig.VERSION_NAME + " code=" + BuildConfig.VERSION_CODE)
        supportActionBar?.hide()
        setContentView(R.layout.activity_live_tv)
        settingsRepository = SettingsRepository(this)
        val liveBackend = settingsRepository.loadLiveBackend()
        val dvrSettingsForGuide = settingsRepository.loadChannelsDvr()
        val xtreamSettingsForGuide = settingsRepository.loadXtream()
        guideProgramResolver = LiveGuideProgramResolver(
            this,
            liveBackend.baseUrl,
            liveBackend.userId.ifBlank { "demo" },
            dvrSettingsForGuide.baseUrl,
            liveBackend.xmltvGuideUrl,
            dvrSettingsForGuide.hdHomeRunManualGuideUrl,
            dvrSettingsForGuide.hdHomeRunUseManualGuide,
            xtreamSettingsForGuide.server,
            xtreamSettingsForGuide.username,
            xtreamSettingsForGuide.password
        )

        clockView = findViewById(R.id.liveTvClock)
        infoLogo = findViewById(R.id.liveTvInfoLogo)
        infoIcon = findViewById(R.id.liveTvInfoIcon)
        infoChannel = findViewById(R.id.liveTvInfoChannel)
        infoGroup = findViewById(R.id.liveTvInfoGroup)
        nowTime = findViewById(R.id.liveTvNowTime)
        nowTitle = findViewById(R.id.liveTvNowTitle)
        descriptionView = findViewById(R.id.liveTvDescription)
        nextLine = findViewById(R.id.liveTvNextLine)
        laterLine = findViewById(R.id.liveTvLaterLine)
        progressBar = findViewById(R.id.liveTvProgressBar)
        timelineRow = findViewById(R.id.liveTvTimeline)
        channelList = findViewById(R.id.liveTvChannelList)
        previewImage = findViewById(R.id.liveTvPreviewImage)
        heroBackground = findViewById(R.id.liveTvHeroBackground)
        previewFrame = findViewById(R.id.liveTvPreviewFrame)
        previewPlayerView = findViewById(R.id.liveTvPreviewPlayer)
        previewHint = findViewById(R.id.liveTvPreviewHint)
        guideHeaderRow = findViewById(R.id.liveTvGuideHeaderRow)
        categoryRail = findViewById(R.id.liveTvCategoryRail)
        categoryPanel = findViewById(R.id.liveTvCategoryPanel)
        mainPanel = findViewById(R.id.liveTvMainPanel)
        horizontalScroll = findViewById(R.id.liveTvHorizontalScroll)
        verticalScroll = findViewById(R.id.liveTvVerticalScroll)
        loadingOverlay = findViewById(R.id.liveTvLoadingOverlay)
        contentRoot = findViewById(R.id.liveTvContentRoot)
        loadingTitle = findViewById(R.id.liveTvLoadingTitle)
        loadingSubtitle = findViewById(R.id.liveTvLoadingSubtitle)
        channelStats = findViewById(R.id.liveTvChannelStats)
        forceGuideButton = findViewById(R.id.liveTvForceGuideButton)
        setupUnifiedShellNavigation()
        setupLiveTvFocusGuard()
        forceGuideButton.visibility = View.GONE
        forceGuideButton.isFocusable = false
        forceGuideButton.isClickable = false
        Log.i("DebridChannels", "FORCE_REFRESH_GUIDE_BUTTON: REMOVED")
        forceGuideButton.nextFocusUpId = R.id.liveTvForceGuideButton
        forceGuideButton.nextFocusDownId = R.id.liveTvForceGuideButton
        forceGuideButton.nextFocusLeftId = R.id.liveTvForceGuideButton
        forceGuideButton.nextFocusRightId = R.id.liveTvForceGuideButton
        forceGuideButton.setOnClickListener { forceLocalGuideRefreshFromLiveTv() }
        forceGuideButton.setOnFocusChangeListener { _, hasFocus ->
            forceGuideButton.alpha = if (hasFocus) 1f else 0.88f
            forceGuideButton.scaleX = if (hasFocus) 1.05f else 1f
            forceGuideButton.scaleY = if (hasFocus) 1.05f else 1f
        }
        statusTitle = findViewById(R.id.liveTvStatusTitle)
        statusSources = findViewById(R.id.liveTvStatusSources)
        topSpacer = SpaceView(this)
        bottomSpacer = SpaceView(this)

        // Start Live TV in guide/category control mode, not on the top menu.
        activeZone = FocusZone.CATEGORY
        lastLiveFocusZone = FocusZone.CATEGORY
        contentRoot.post {
            if (!isFinishing && !isDestroyed) {
                setTopNavFocusable(false)
                contentRoot.requestFocus()
                applyZoneState()
            }
        }

        previewFrame.setOnClickListener {
            if (filteredChannels.isNotEmpty()) {
                openPlayer(selectedIndex)
            }
        }
        initializePreviewPlayer()

        val playbackSettings = settingsRepository.loadPlayback()
        is4kUiEnabled = playbackSettings.ultraHdGuideUiEnabled
        liveStatusChecksEnabled = playbackSettings.liveStatusChecksEnabled

        updateClock()
        buildTimeline()
        activeLiveSourceSignature = currentLiveSourceSignature()
        // Keep Live TV browsing lightweight on Android TV devices. The full player is
        // opened only when a channel is selected, which prevents the guide from
        // holding decoder buffers while rows are being rebuilt during DPAD scrolls.
        val hadWarmCache = renderCachedChannelsIfAvailable()
        if (!hadWarmCache) {
            showLoading(true, "Loading channels", "Pulling guide data and lineup details…")
            channelStats.text = "Scanning channel lineup…"
        } else {
            channelStats.text = "Using instant cached lineup • refreshing in background…"
        }
        statusTitle.text = "Live TV connected"
        statusSources.text = "● Checking Channels DVR Direct   •   ● Checking HDHomeRun   •   ● Checking M3U/Xtream IPTV"
        if (!hadWarmCache || isLiveTvCacheExpired()) {
            loadChannels(showFullLoading = !hadWarmCache)
        } else {
            channelStats.text = "Using cached Live TV sources • next guide/source refresh follows Settings cache"
        }
    }

    private fun isActivityAlive(): Boolean = !isFinishing && !isDestroyed

    private fun safeLoadImage(url: String, target: ImageView, centerCrop: Boolean = false): Boolean {
        if (!isActivityAlive() || url.isBlank()) return false
        return try {
            val request = Glide.with(target)
                .load(url)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .dontAnimate()
            if (centerCrop) request.centerCrop().into(target) else request.into(target)
            true
        } catch (_: IllegalArgumentException) {
            false
        } catch (_: Exception) {
            false
        }
    }

    private fun guideCacheHours(): Int {
        val raw = settingsRepository.loadLiveBackend().epgRefreshEveryHours
        return when {
            raw <= 6 -> 6
            raw <= 12 -> 12
            else -> 24
        }
    }

    private fun guideCacheTtlMs(): Long = guideCacheHours() * 60L * 60L * 1000L

    private fun guideCacheLabel(): String = "${guideCacheHours()}-hour"

    private fun currentLiveSourceSignature(): String {
        val dvr = settingsRepository.loadChannelsDvr()
        val xtream = settingsRepository.loadXtream()
        val liveBackend = settingsRepository.loadLiveBackend()
        return listOf(
            "dvr=${dvr.baseUrl.trim()}",
            "dvrDevice=${dvr.deviceId.trim()}",
            "hdhrAuto=${dvr.hdHomeRunAutoScan}",
            "hdhrManual=${dvr.hdHomeRunManualUrl.trim()}",
            "iptvM3u=${xtream.m3uUrl.trim()}",
            "iptvXtreamServer=${xtream.server.trim()}",
            "iptvXtreamUser=${xtream.username.trim()}",
            "iptvEnabled=${xtream.enabled}",
            "xmltv=${liveBackend.xmltvGuideUrl.trim()}"
        ).joinToString("|")
    }

    private fun clearLiveTvRenderStateForSourceSwitch() {
        currentChannels = emptyList()
        filteredChannels = emptyList()
        categories = emptyList()
        categoryCache.clear()
        categoryCountCache.clear()
        selectedIndex = 0
        selectedCategoryIndex = 0
        renderWindowStart = 0
        renderWindowEnd = -1
        previewRunnable?.let { previewHandler.removeCallbacks(it) }
        previewRunnable = null
        previewArmedIndex = -1
        previewUrl = ""
        runCatching { previewPlayer?.stop() }
        runCatching { getSharedPreferences(EPG_CACHE_PREFS, MODE_PRIVATE).edit().clear().apply() }
        Log.i("DebridChannels", "SOURCE_SWITCH_CLEAR: source cache invalidated")
    }

    @Deprecated("Deprecated in Android API; kept for compatibility with the current project toolchain")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PLAYER_REQUEST_CODE) {
            playerLaunchInProgress = false
            liveTvInputEnabled = true
            lastPlayerLaunchAtMs = 0L
            previewHandler.removeCallbacksAndMessages(null)
            contentRoot.postDelayed({
                if (!isFinishing && !isDestroyed) {
                    setupLiveTvFocusGuard()
                    restartPreviewAtLiveEdge("player-result")
                    recoverLiveTvWindowFocus("player-result")
                }
            }, 250L)
        }
    }

    override fun onResume() {
        super.onResume()
        previewHandler.removeCallbacksAndMessages(null)
        if (!isFinishing && !isDestroyed && !shellExitInProgress) {
            liveTvInputEnabled = true
            playerLaunchInProgress = false
            lastPlayerLaunchAtMs = 0L
            setupLiveTvFocusGuard()
            contentRoot.post {
                restartPreviewAtLiveEdge("onResume")
                recoverLiveTvWindowFocus("onResume")
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            liveTvInputEnabled = true
            playerLaunchInProgress = false
            recoverLiveTvWindowFocus("windowFocus")
        }
    }

    override fun onPause() {
        super.onPause()
        liveTvInputEnabled = false
        playerLaunchInProgress = false
    }

    override fun onStop() {
        super.onStop()
        liveTvInputEnabled = false
        playerLaunchInProgress = false
        previewRequestToken++
        previewHandler.removeCallbacksAndMessages(null)
        previewRunnable = null
        previewRequestToken++
        previewUrl = ""
        previewPlayer?.apply {
            playWhenReady = false
            runCatching { stop() }
            runCatching { clearMediaItems() }
            runCatching { seekToDefaultPosition() }
        }
    }

    override fun onDestroy() {
        liveTvDestroyed = true
        super.onDestroy()
        previewRequestToken++
        previewHandler.removeCallbacksAndMessages(null)
        runCatching { executor.shutdownNow() }
        previewPlayerView.player = null
        previewPlayer?.release()
        previewPlayer = null
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (liveTvInputEnabled && event.keyCode in liveTvDpadKeys && handleLiveTvNavigationKey(event)) return true
        return super.dispatchKeyEvent(event)
    }

    /**
     * Returning from full-screen playback must never resume the guide preview
     * from a paused/timeshifted position. Reload the selected channel from the
     * original live URL so the preview snaps back to live edge.
     */
    private fun restartPreviewAtLiveEdge(reason: String = "") {
        if (liveTvDestroyed || !isActivityAlive() || filteredChannels.isEmpty()) return
        val entry = filteredChannels.getOrNull(selectedIndex) ?: return
        if (entry.item.url.isBlank()) return
        previewRunnable?.let { previewHandler.removeCallbacks(it) }
        previewRunnable = null
        previewRequestToken++
        previewUrl = ""
        previewSourceLabel = ""
        currentPreviewIsChannelsDvr = false
        previewPlayer?.apply {
            playWhenReady = false
            runCatching { stop() }
            runCatching { clearMediaItems() }
            runCatching { seekToDefaultPosition() }
        }
        if (activeZone == FocusZone.GUIDE || isGuideExpanded) {
            armPreviewForSelection(selectedIndex, immediate = true)
        }
    }

    private fun initializePreviewPlayer() {
        if (previewPlayer != null || liveTvDestroyed) return
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("ChannelsDebridTV/1.6.2 LivePreview")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(8000)
            .setReadTimeoutMs(12000)
        val renderersFactory = DefaultRenderersFactory(this)
            .setEnableDecoderFallback(true)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
        previewPlayer = ExoPlayer.Builder(this, renderersFactory)
            .setMediaSourceFactory(DefaultMediaSourceFactory(httpFactory))
            .build().apply {
                playWhenReady = false
                volume = 1f
                addListener(object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        if (currentPreviewIsChannelsDvr) {
                            channelsDvrPreviewCooldownUntilMs = System.currentTimeMillis() + 15_000L
                            previewHint.visibility = View.VISIBLE
                            previewHint.text = "DVR preview cooling down - OK to watch"
                            playWhenReady = false
                            runCatching { stop() }
                            runCatching { clearMediaItems() }
                        }
                    }
                })
            }
        previewPlayerView.player = previewPlayer
        previewPlayerView.useController = false
    }

    private fun updateClock() {
        val formatter = SimpleDateFormat("HH:mm", Locale.US)
        clockView.text = formatter.format(Date())
    }

    private fun loadChannels(showFullLoading: Boolean = true) {
        if (showFullLoading) {
            infoChannel.text = ""
            infoGroup.text = ""
            descriptionView.text = ""
            channelList.removeAllViews()
            categoryRail.removeAllViews()
            showLoading(true, "Loading channels", "Pulling guide data and lineup details…")
        }

        val dvr = settingsRepository.loadChannelsDvr()
        val xtream = settingsRepository.loadXtream()
        val requestedSignature = currentLiveSourceSignature()
        if (requestedSignature != activeLiveSourceSignature) {
            activeLiveSourceSignature = requestedSignature
            clearLiveTvRenderStateForSourceSwitch()
            if (showFullLoading) {
                channelList.removeAllViews()
                categoryRail.removeAllViews()
            }
        }

        runLiveTvBackground {
            val allChannels = mutableListOf<LiveSourceResolver.ChannelItem>()
            var dvrDeviceId = dvr.deviceId
            var dvrResultMessage = "Channels DVR not configured"
            var xtreamResultMessage = if (xtream.enabled || xtream.m3uUrl.isNotBlank() || xtream.server.isNotBlank()) "IPTV not configured" else "IPTV disabled"
            var hdhrResultMessage = if (dvr.hdHomeRunManualUrl.isNotBlank()) "HDHomeRun manual override" else if (dvr.hdHomeRunAutoScan) "HDHomeRun scanning" else "HDHomeRun off"
            var dvrCount = 0
            var hdhrCount = 0
            var xtreamCount = 0
            Log.i("DebridChannels", "LIVE_TV_LOGIC_PORT_ACTIVE: v0.6 donor=v0.9.8.3 sources=manual_dvr,m3u,xtream,manual_xmltv")
            Log.i("DebridChannels", "HDHOMERUN_LOAD: auto=" + dvr.hdHomeRunAutoScan + " manual=" + dvr.hdHomeRunManualUrl.isNotBlank())

            if (dvr.baseUrl.isNotBlank()) {
                val dvrResult = LiveSourceResolver.loadDvrChannels(dvr.baseUrl, dvr.deviceId)
                dvrResultMessage = dvrResult.message
                dvrCount = dvrResult.channels.size
                allChannels += dvrResult.channels
                if (!dvrResult.deviceId.isNullOrBlank() && dvrResult.deviceId != dvr.deviceId) {
                    dvrDeviceId = dvrResult.deviceId
                    settingsRepository.saveChannelsDvr(dvr.copy(deviceId = dvrDeviceId))
                }
            }

            if (dvr.hdHomeRunManualUrl.isNotBlank() || dvr.hdHomeRunAutoScan) {
                val hdhrResult = LiveSourceResolver.loadHdHomeRunChannels(dvr.hdHomeRunManualUrl, dvr.hdHomeRunAutoScan)
                hdhrResultMessage = hdhrResult.message
                hdhrCount = hdhrResult.channels.size
                val hdhrIconMap = if (dvr.hdHomeRunUseManualGuide && dvr.hdHomeRunManualGuideUrl.isNotBlank()) {
                    LiveSourceResolver.loadXmltvChannelIconMap(dvr.hdHomeRunManualGuideUrl)
                } else emptyMap()
                val hdhrChannelsWithManualIcons = if (hdhrIconMap.isNotEmpty()) {
                    hdhrResult.channels.map { item ->
                        if (item.iconUrl.isNotBlank()) item else {
                            val icon = hdhrIconMap[item.number] ?: hdhrIconMap[item.name] ?: hdhrIconMap[item.number.lowercase(Locale.US).replace(Regex("[^a-z0-9]+"), "")] ?: hdhrIconMap[item.name.lowercase(Locale.US).replace(Regex("[^a-z0-9]+"), "")] ?: ""
                            if (icon.isBlank()) item else item.copy(iconUrl = icon, debug = item.debug + " • manual xmltv logo")
                        }
                    }
                } else hdhrResult.channels
                allChannels += hdhrChannelsWithManualIcons
            }

            // v2.6.8 IPTV stability fix:
            // Do not gate direct M3U/Xtream loading only behind the old enabled switch.
            // If a user entered an M3U URL or Xtream credentials, load them. The enabled
            // switch is still respected as an explicit on/off when no source fields exist,
            // but it no longer causes configured IPTV/M3U sources to be skipped silently.
            val hasM3u = xtream.m3uUrl.isNotBlank()
            val hasXtreamCreds = xtream.server.isNotBlank() && xtream.username.isNotBlank() && xtream.password.isNotBlank()
            if (xtream.enabled || hasM3u || hasXtreamCreds) {
                val iptvMessages = mutableListOf<String>()
                val iptvChannels = mutableListOf<LiveSourceResolver.ChannelItem>()

                if (hasM3u) {
                    val m3uUrls = xtream.m3uUrl
                        .split(Regex("[,;\\n]+"))
                        .map { it.trim() }
                        .filter { it.startsWith("http://", true) || it.startsWith("https://", true) }
                        .distinct()
                    m3uUrls.forEachIndexed { idx, url ->
                        val (channels, message) = LiveSourceResolver.loadM3uChannels(url)
                        iptvChannels += channels
                        iptvMessages += "M3U ${idx + 1}: $message"
                    }
                    if (m3uUrls.isEmpty()) iptvMessages += "M3U URL configured but no valid http(s) URL found"
                }

                if (hasXtreamCreds) {
                    val (channels, message) = LiveSourceResolver.loadXtreamChannels(
                        xtream.server,
                        xtream.username,
                        xtream.password
                    )
                    iptvChannels += channels
                    iptvMessages += "Xtream: $message"
                }

                xtreamResultMessage = iptvMessages.joinToString(" | ").ifBlank { "IPTV not configured" }
                xtreamCount = iptvChannels.size
                allChannels += iptvChannels
                Log.i("DebridChannels", "IPTV_PARSE_COUNT: " + xtreamCount)
                Log.i("DebridChannels", "IPTV_DIRECT_LOAD_APPLIED: unified=true m3u=" + hasM3u + " xtream=" + hasXtreamCreds + " count=" + xtreamCount + " msg=" + xtreamResultMessage)
            }

            val iconMergedChannels = backfillHdHomeRunIconsFromDvr(allChannels)
            val dedupedItems = iconMergedChannels
                .distinctBy { it.source + "|" + it.name + "|" + it.url }
                .sortedWith(compareBy<LiveSourceResolver.ChannelItem>({ sourcePriority(it.source) }, { extractChannelSortNumber(it) }, { it.name.lowercase(Locale.US) }))
            saveLiveTvCache(dedupedItems)
            // v2.7.1 lower-end safe mode: do not hydrate/render the full playlist on first open.
            // The first visible screen is built immediately, then the remaining channel index is
            // attached in background chunks. Preview stays enabled; only heavy guide/index work is staged.
            val generation = ++guideHydrationGeneration
            val firstScreenItems = dedupedItems.take(firstScreenChannelLimit.coerceAtLeast(renderWindowSize + renderWindowBuffer))
            val firstScreenEntries = applyPersistentEpgCache(firstScreenItems.mapIndexed { index, item -> buildGuideEntry(item, index) })
            val seededCategories = buildCategories(firstScreenEntries)
            val epgFresh = isEpgProgramCacheFresh()
            val fullCount = dedupedItems.size

            runOnUiThread {
                guideShellOnlyMode = fullCount > firstScreenEntries.size
                currentChannels = firstScreenEntries
                categoryCache.clear()
                categoryCountCache.clear()
                categories = seededCategories
                selectedCategoryIndex = 0
                buildCategoryRail()
                showLoading(false)
                val dvrConnected = dvrCount > 0
                val hdhrConnected = hdhrCount > 0
                val xtreamConnected = xtreamCount > 0
                val hdhrBadge = if (hdhrConnected) "🟢 HDHR $hdhrCount" else if (dvr.hdHomeRunAutoScan) "⚪ HDHR 0" else "⚪ HDHR off"
                val dvrBadge = if (dvrConnected) "🟢 DVR $dvrCount" else "⚪ DVR 0"
                val xtreamBadge = if (xtreamConnected) "🟢 IPTV $xtreamCount" else if (xtream.enabled || xtream.m3uUrl.isNotBlank() || xtream.server.isNotBlank()) "⚪ IPTV 0" else "⚪ IPTV off"
                statusTitle.text = if (firstScreenEntries.isNotEmpty()) "Live TV connected" else "Waiting for channels"
                statusSources.text = listOf(dvrBadge, hdhrBadge, xtreamBadge, "XMLTV manual supported").joinToString("   •   ")
                Log.i("DebridChannels", "SOURCE_CACHE_KEY: " + activeLiveSourceSignature)
                Log.i("DebridChannels", "GUIDE_INITIAL_SHELL: first=" + firstScreenEntries.size + " full=" + fullCount + " chunk=" + guideHydrationChunkSize)
                Log.i("DebridChannels", "LIVE_TV_SOURCES_APPLIED: dvr=" + dvrCount + " hdhr=" + hdhrCount + " iptv=" + xtreamCount + " total=" + fullCount + " hdhrMessage=" + hdhrResultMessage + " ui=first_screen_only")
                if (firstScreenEntries.isEmpty()) {
                    channelStats.text = "No channels loaded yet"
                    infoChannel.text = "No channels found"
                    infoGroup.text = "Add manual Channels DVR, enable HDHomeRun auto-scan, add M3U, Xtream/IPTV, or XMLTV in Settings"
                    Toast.makeText(this, "No source configured. Add manual Channels DVR, enable HDHomeRun auto-scan, add M3U, Xtream/IPTV, or XMLTV in Settings.", Toast.LENGTH_LONG).show()
                } else {
                    applyCategorySelection(0)
                    infoGroup.text = "First screen ready • ${fullCount} total channels indexing in background"
                    channelStats.text = if (guideShellOnlyMode) {
                        "Showing first ${firstScreenEntries.size} of $fullCount channels • background indexing active"
                    } else if (epgFresh) {
                        "Showing ${filteredChannels.size} of ${firstScreenEntries.size} channels • using saved ${guideCacheLabel()} EPG cache"
                    } else {
                        "Showing ${filteredChannels.size} of ${firstScreenEntries.size} channels • guide shell ready"
                    }
                    if (fullCount > firstScreenEntries.size) {
                        Handler(Looper.getMainLooper()).postDelayed({ hydrateFullGuideIndexInBackground(dedupedItems, generation) }, 450L)
                    }
                    if (!epgFresh) {
                        Handler(Looper.getMainLooper()).postDelayed({ refreshGuideProgramsInBackground(firstScreenEntries) }, 5200L)
                    }
                }
            }
        }
    }


    private fun hydrateFullGuideIndexInBackground(items: List<LiveSourceResolver.ChannelItem>, generation: Int) {
        if (items.isEmpty() || generation != guideHydrationGeneration || liveTvDestroyed) return
        val signatureAtStart = activeLiveSourceSignature
        runLiveTvBackground {
            val hydrated = ArrayList<GuideEntry>(items.size)
            items.chunked(guideHydrationChunkSize).forEachIndexed { chunkIndex, chunk ->
                if (Thread.currentThread().isInterrupted || liveTvDestroyed || generation != guideHydrationGeneration) return@runLiveTvBackground
                val baseIndex = hydrated.size
                chunk.forEachIndexed { offset, item ->
                    hydrated += buildGuideEntry(item, baseIndex + offset)
                }
                if (chunkIndex == 0 || chunkIndex % 2 == 1) {
                    val snapshot = hydrated.toList()
                    runOnUiThread {
                        if (!isActivityAlive() || generation != guideHydrationGeneration || signatureAtStart != activeLiveSourceSignature) return@runOnUiThread
                        applyGuideHydrationSnapshot(snapshot, partial = snapshot.size < items.size)
                    }
                    Thread.sleep(35L)
                }
            }
            val finalSnapshot = applyPersistentEpgCache(hydrated)
            runOnUiThread {
                if (!isActivityAlive() || generation != guideHydrationGeneration || signatureAtStart != activeLiveSourceSignature) return@runOnUiThread
                applyGuideHydrationSnapshot(finalSnapshot, partial = false)
                val epgFresh = isEpgProgramCacheFresh()
                if (!epgFresh) {
                    Handler(Looper.getMainLooper()).postDelayed({ refreshGuideProgramsInBackground(finalSnapshot) }, 1800L)
                }
            }
        }
    }

    private fun applyGuideHydrationSnapshot(snapshot: List<GuideEntry>, partial: Boolean) {
        if (snapshot.isEmpty()) return
        val selectedUrl = filteredChannels.getOrNull(selectedIndex)?.item?.url.orEmpty()
        currentChannels = snapshot
        categoryCache.clear()
        categoryCountCache.clear()
        categories = buildCategories(snapshot)
        selectedCategoryIndex = if (categories.isEmpty()) 0 else selectedCategoryIndex.coerceIn(0, categories.lastIndex)
        buildCategoryRail()
        val category = categories.getOrNull(selectedCategoryIndex)
        filteredChannels = category?.let { currentChannels.filter(it.matcher).ifEmpty { currentChannels } } ?: currentChannels
        val restoredIndex = filteredChannels.indexOfFirst { it.item.url == selectedUrl }
        selectedIndex = if (restoredIndex >= 0) restoredIndex else selectedIndex.coerceIn(0, filteredChannels.lastIndex)
        rebuildGuideWindow(force = true)
        updateSelection(selectedIndex, restartPreview = false)
        guideShellOnlyMode = partial
        channelStats.text = if (partial) {
            "Showing ${filteredChannels.size} of ${snapshot.size}+ channels • background indexing…"
        } else {
            "Showing ${filteredChannels.size} of ${snapshot.size} channels • guide index ready"
        }
        Log.i("DebridChannels", "BACKGROUND_CHANNEL_INDEX: loaded=${snapshot.size} partial=$partial rows=$renderWindowStart-$renderWindowEnd")
    }


    private fun isLiveTvCacheExpired(): Boolean {
        val prefs = getSharedPreferences("live_tv_cache", MODE_PRIVATE)
        val updatedAt = prefs.getLong("updated_at", 0L)
        val ttlMs = guideCacheTtlMs()
        return updatedAt <= 0L || System.currentTimeMillis() - updatedAt > ttlMs
    }

    private fun renderCachedChannelsIfAvailable(): Boolean {
        val prefs = getSharedPreferences("live_tv_cache", MODE_PRIVATE)
        val cachedSignature = prefs.getString("source_signature", "").orEmpty()
        val currentSignature = currentLiveSourceSignature()
        if (cachedSignature.isNotBlank() && cachedSignature != currentSignature) {
            clearLiveTvRenderStateForSourceSwitch()
            prefs.edit().remove("channels_json").remove("updated_at").remove("source_signature").apply()
            Log.i("DebridChannels", "SOURCE_CACHE_KEY: stale cache removed old=$cachedSignature new=$currentSignature")
            return false
        }
        activeLiveSourceSignature = currentSignature
        val raw = prefs.getString("channels_json", "").orEmpty()
        if (raw.isBlank()) return false
        return runCatching {
            val arr = JSONArray(raw)
            val items = mutableListOf<LiveSourceResolver.ChannelItem>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val groupsArr = obj.optJSONArray("groups") ?: JSONArray()
                val groups = mutableListOf<String>()
                for (g in 0 until groupsArr.length()) groups += groupsArr.optString(g)
                val name = obj.optString("name")
                val url = obj.optString("url")
                if (name.isBlank() || url.isBlank()) continue
                items += LiveSourceResolver.ChannelItem(
                    name = name,
                    url = url,
                    source = obj.optString("source"),
                    debug = obj.optString("debug"),
                    groups = groups,
                    number = obj.optString("number"),
                    iconUrl = obj.optString("iconUrl")
                )
            }
            if (items.isEmpty()) return false
            val generation = ++guideHydrationGeneration
            val firstScreenItems = items.take(firstScreenChannelLimit.coerceAtLeast(renderWindowSize + renderWindowBuffer))
            val seededEntries = applyPersistentEpgCache(firstScreenItems.mapIndexed { index, item -> buildGuideEntry(item, index) })
            val seededCategories = buildCategories(seededEntries)
            val epgFresh = isEpgProgramCacheFresh()
            guideShellOnlyMode = items.size > seededEntries.size
            currentChannels = seededEntries
            categoryCache.clear()
            categoryCountCache.clear()
            categories = seededCategories
            selectedCategoryIndex = if (categories.isEmpty()) 0 else selectedCategoryIndex.coerceIn(0, categories.lastIndex)
            buildCategoryRail()
            showLoading(false)
            applyCategorySelection(selectedCategoryIndex)
            statusTitle.text = "Live TV ready"
            statusSources.text = "⚡ Instant cache • first screen ready • background indexing active"
            Log.i("DebridChannels", "SOURCE_CACHE_KEY: $currentSignature")
            Log.i("DebridChannels", "GUIDE_INITIAL_SHELL_CACHE: first=${seededEntries.size} full=${items.size}")
            Log.i("DebridChannels", "GUIDE_VISIBLE_COLUMNS: 4_minimum rows=14 compactRows=4_visible_min")
            channelStats.text = if (guideShellOnlyMode) {
                "Showing first ${seededEntries.size} of ${items.size} cached channels • background indexing active"
            } else if (epgFresh) {
                "Showing ${filteredChannels.size} of ${seededEntries.size} cached channels • EPG restored from ${guideCacheLabel()} disk cache"
            } else {
                "Showing ${filteredChannels.size} of ${seededEntries.size} cached channels • guide shell ready"
            }
            if (items.size > seededEntries.size) {
                Handler(Looper.getMainLooper()).postDelayed({ hydrateFullGuideIndexInBackground(items, generation) }, 300L)
            }
            if (!epgFresh) {
                Handler(Looper.getMainLooper()).postDelayed({ refreshGuideProgramsInBackground(seededEntries) }, 5200L)
            }
            true
        }.getOrDefault(false)
    }

    private fun saveLiveTvCache(items: List<LiveSourceResolver.ChannelItem>) {
        val arr = JSONArray()
        items.take(6000).forEach { channel ->
            val groups = JSONArray()
            channel.groups.forEach { groups.put(it) }
            arr.put(JSONObject()
                .put("name", channel.name)
                .put("url", channel.url)
                .put("source", channel.source)
                .put("debug", channel.debug)
                .put("groups", groups)
                .put("number", channel.number)
                .put("iconUrl", channel.iconUrl)
            )
        }
        getSharedPreferences("live_tv_cache", MODE_PRIVATE).edit()
            .putString("channels_json", arr.toString())
            .putString("source_signature", activeLiveSourceSignature.ifBlank { currentLiveSourceSignature() })
            .putLong("updated_at", System.currentTimeMillis())
            .apply()
    }


    private fun forceLocalGuideRefreshFromLiveTv() {
        if (guideRefreshInProgress) {
            Toast.makeText(this, "Guide refresh already running", Toast.LENGTH_SHORT).show()
            return
        }
        forceGuideButton.text = "Refreshing Guide…"
        loadingSubtitle.text = "Refreshing guide in the background. Live TV will stay open."
        val seedSnapshot = currentChannels.ifEmpty { filteredChannels }
        if (seedSnapshot.isEmpty()) {
            forceGuideButton.text = "Refresh Guide"
            Toast.makeText(this, "Channels are still loading. Try refresh again in a moment.", Toast.LENGTH_SHORT).show()
            return
        }
        getSharedPreferences(EPG_CACHE_PREFS, MODE_PRIVATE).edit()
            .putBoolean("force_refresh_requested", true)
            .apply()
        Toast.makeText(this, "Guide refresh queued in background", Toast.LENGTH_SHORT).show()
        refreshGuideProgramsInBackground(seedSnapshot, force = true)
    }

    private fun postJson(url: String, body: String): Int {
        return try {
            val conn = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 8000
                readTimeout = 8000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
            }
            conn.outputStream.bufferedWriter().use { it.write(body) }
            try { conn.responseCode } finally { conn.disconnect() }
        } catch (_: Exception) {
            -1
        }
    }

    private fun showLoading(visible: Boolean, title: String = "Loading channels", subtitle: String = "Pulling guide data and lineup details…") {
        loadingOverlay.visibility = if (visible) View.VISIBLE else View.GONE
        contentRoot.visibility = if (visible) View.GONE else View.VISIBLE
        loadingTitle.text = title
        loadingSubtitle.text = subtitle
        if (!visible) restoreLiveTvKeyAnchor()
    }

    private fun buildCategories(entries: List<GuideEntry>): List<CategoryFilter> {
        val defs = mutableListOf<CategoryFilter>()
        defs += CategoryFilter("All Channels") { true }
        val explicitGroups = entries
            .flatMap { it.item.groups }
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.equals("Channels DVR", true) }
            .distinct()
            .sortedBy { it.lowercase(Locale.US) }
            .take(60)
        explicitGroups.forEach { groupName ->
            defs += CategoryFilter(groupName) { entry -> entry.item.groups.any { it.equals(groupName, true) } }
        }
        defs += CategoryFilter("Favorites") { it.tags.contains("favorites") }
        defs += CategoryFilter("DVR") { it.item.source.contains("DVR", true) }
        defs += CategoryFilter("HDHomeRun") { it.item.source.contains("HDHomeRun", true) }
        defs += CategoryFilter("IPTV") { it.item.source.contains("IPTV", true) || it.item.source.contains("Xtream", true) }
        return defs
            .distinctBy { it.name.lowercase(Locale.US) }
            .filter { filter -> entries.any(filter.matcher) }
    }

    private fun buildCategoryRail() {
        categoryRail.removeAllViews()
        categoryViews = categories.mapIndexed { index, category ->
            val count = categoryCountCache.getOrPut(category.name) { currentChannels.count(category.matcher) }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = getDrawable(R.drawable.guide_category_idle)
                setPadding(dp(14), dp(9), dp(14), dp(9))
                isClickable = true
                isFocusable = false
                isFocusableInTouchMode = false
                setOnKeyListener { _, _, event -> handleLiveTvNavigationKey(event) }
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58))
                lp.bottomMargin = dp(6)
                layoutParams = lp
                setOnClickListener {
                    selectedCategoryIndex = index
                    applyCategorySelection(index)
                    activeZone = FocusZone.CATEGORY
                    applyZoneState()
                }
            }
            val icon = TextView(this).apply {
                tag = "icon"
                text = categoryIcon(category.name)
                gravity = Gravity.CENTER
                textSize = 15f
                setTypeface(typeface, Typeface.BOLD)
                background = getDrawable(R.drawable.guide_category_icon_idle)
                setTextColor(0xFFFFFFFF.toInt())
                layoutParams = LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginEnd = dp(14) }
            }
            val labels = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            }
            labels.addView(TextView(this).apply {
                tag = "title"
                text = category.name
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 15f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setTypeface(typeface, Typeface.BOLD)
            })
            labels.addView(TextView(this).apply {
                tag = "count"
                text = "$count channels"
                setTextColor(0xFF9BA3AF.toInt())
                textSize = 11f
                maxLines = 1
            })
            row.addView(icon)
            row.addView(labels)
            categoryRail.addView(row)
            row
        }
        styleCategories()
    }

    private fun categoryIcon(name: String): String {
        val n = name.lowercase(Locale.US)
        return when {
            n.contains("favorite") -> "★"
            n.contains("popular") -> "●"
            n.contains("movie") || n.contains("film") -> "▰"
            n.contains("news") -> "▤"
            n.contains("sport") -> "◉"
            n.contains("kid") || n.contains("family") -> "☺"
            n.contains("music") -> "♪"
            n.contains("local") -> "⌂"
            n.contains("hit") || n.contains("tv") -> "▭"
            n.contains("entertain") -> "✦"
            n.contains("crime") -> "✪"
            n.contains("reality") -> "♣"
            n.contains("dvr") -> "D"
            n.contains("hdhome") -> "H"
            n.contains("iptv") -> "I"
            else -> "□"
        }
    }

    private fun applyCategorySelection(index: Int) {
        if (!isActivityAlive() || categories.isEmpty()) return
        selectedCategoryIndex = if (categories.isEmpty()) 0 else index.coerceIn(0, categories.lastIndex)
        val category = categories[selectedCategoryIndex]
        filteredChannels = categoryCache.getOrPut(category.name) {
            currentChannels.filter(category.matcher).ifEmpty { currentChannels }
        }
        selectedIndex = if (filteredChannels.isEmpty()) 0 else selectedIndex.coerceIn(0, filteredChannels.lastIndex)
        previewArmedIndex = -1
        rebuildGuideWindow(force = true)
        Log.i("DebridChannels", "GUIDE_VISIBLE_ROWS: start=$renderWindowStart end=$renderWindowEnd total=${filteredChannels.size}")
        Log.i("DebridChannels", "GUIDE_VISIBLE_COLUMNS: 4_minimum")
        updateSelection(selectedIndex, restartPreview = false)
        channelStats.text = "Showing ${filteredChannels.size} of ${currentChannels.size} channels"
        styleCategories()
        if (filteredChannels.isEmpty()) {
            activeZone = FocusZone.CATEGORY
        }
        applyZoneState()
    }

    private fun desiredWindowStart(targetIndex: Int): Int {
        if (filteredChannels.isEmpty()) return 0
        val maxStart = (filteredChannels.size - renderWindowSize).coerceAtLeast(0)
        return (targetIndex - renderWindowBuffer).coerceIn(0, maxStart)
    }

    private fun rebuildGuideWindow(force: Boolean = false) {
        if (!isActivityAlive()) return
        if (filteredChannels.isEmpty()) {
            channelList.removeAllViews()
            renderWindowStart = 0
            renderWindowEnd = -1
            return
        }
        val desiredStart = desiredWindowStart(selectedIndex)
        val desiredEnd = (desiredStart + renderWindowSize - 1).coerceAtMost(filteredChannels.lastIndex)
        if (!force && desiredStart == renderWindowStart && desiredEnd == renderWindowEnd) return
        renderWindowStart = desiredStart
        renderWindowEnd = desiredEnd

        channelList.removeAllViews()
        topSpacer.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(renderWindowStart * rowHeightEstimateDp)
        )
        bottomSpacer.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(((filteredChannels.size - renderWindowEnd - 1).coerceAtLeast(0)) * rowHeightEstimateDp)
        )
        channelList.addView(topSpacer)
        for (rowIndex in renderWindowStart..renderWindowEnd) {
            channelList.addView(makeGuideRow(rowIndex, filteredChannels[rowIndex]))
        }
        channelList.addView(bottomSpacer)
    }

    private fun styleCategories() {
        categoryViews.forEachIndexed { index, view ->
            val selected = index == selectedCategoryIndex
            val active = activeZone == FocusZone.CATEGORY && selected
            view.background = getDrawable(if (selected) R.drawable.guide_category_selected else R.drawable.guide_category_idle)
            view.alpha = if (selected) 1f else 0.82f
            val row = view as? LinearLayout
            val icon = findTaggedText(row, "icon")
            val title = findTaggedText(row, "title")
            val count = findTaggedText(row, "count")
            icon?.background = getDrawable(if (selected) R.drawable.guide_category_icon_selected else R.drawable.guide_category_icon_idle)
            icon?.setTextColor(if (selected) 0xFF111111.toInt() else 0xFFFFFFFF.toInt())
            title?.setTextColor(if (selected) 0xFF202124.toInt() else 0xFFFFFFFF.toInt())
            count?.setTextColor(if (selected) 0xFF5F6368.toInt() else 0xFF9BA3AF.toInt())
        }
    }

    private fun findTaggedText(root: View?, tagValue: String): TextView? {
        if (root is TextView && root.tag == tagValue) return root
        if (root is ViewGroup) {
            for (i in 0 until root.childCount) {
                val result = findTaggedText(root.getChildAt(i), tagValue)
                if (result != null) return result
            }
        }
        return null
    }

    private fun buildTimeline() {
        timelineRow.removeAllViews()
        val cal = Calendar.getInstance().apply {
            set(Calendar.MINUTE, if (get(Calendar.MINUTE) < 30) 0 else 30)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val formatter = SimpleDateFormat("h:mm a", Locale.US)
        addSpacer(timelineRow, 98)
        timelineRow.addView(TextView(this).apply {
            text = "ON NOW"
            setTextColor(0xFFC2C7D0.toInt())
            textSize = 10f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        // v2.6.9.1: keep at least four full guide time columns visible.
        repeat(4) { idx ->
            val label = if (idx == 0) SimpleDateFormat("h:mm a", Locale.US).format(Date()) else formatter.format(cal.time)
            timelineRow.addView(TextView(this).apply {
                text = label
                setTextColor(if (idx == 0) 0xFFFF4457.toInt() else 0xFFA9B1BD.toInt())
                textSize = 11f
                gravity = Gravity.CENTER
                setTypeface(typeface, if (idx == 0) Typeface.BOLD else Typeface.NORMAL)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            cal.add(Calendar.MINUTE, 30)
        }
    }

    private fun makeGuideRow(index: Int, entry: GuideEntry): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = getDrawable(R.drawable.guide_row_bg)
            isClickable = true
            isFocusable = false
            isFocusableInTouchMode = false
            setOnKeyListener { _, _, event -> handleLiveTvNavigationKey(event) }
            setPadding(dp(8), dp(4), dp(8), dp(4))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(6)
            layoutParams = lp
            setOnClickListener {
                selectedIndex = index
                updateSelection(index, restartPreview = true)
                activeZone = FocusZone.GUIDE
                applyZoneState()
            }
        }

        val logoContainer = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(70), dp(44))
            background = getDrawable(R.drawable.guide_logo_tile)
        }

        val logoImage = ImageView(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

        val logoBox = TextView(this).apply {
            text = entry.logoText
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 15f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        logoContainer.addView(logoImage)
        logoContainer.addView(logoBox)
        val channelIconUrl = entry.item.iconUrl.trim()
        if (channelIconUrl.isNotBlank()) {
            logoBox.visibility = View.GONE
            logoImage.visibility = View.VISIBLE
            logoImage.tag = channelIconUrl
            logoImage.postDelayed({
                if (logoImage.tag == channelIconUrl && row.parent != null) {
                    safeLoadImage(channelIconUrl, logoImage, centerCrop = false)
                }
            }, logoLazyLoadDelayMs)
        } else {
            logoImage.visibility = View.GONE
            logoBox.visibility = View.VISIBLE
        }

        val star = TextView(this).apply {
            text = if (entry.tags.contains("favorites")) "★" else ""
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 11f
            gravity = Gravity.BOTTOM or Gravity.END
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        logoContainer.addView(star)
        val logoLp = logoContainer.layoutParams as LinearLayout.LayoutParams
        logoLp.marginEnd = dp(8)
        logoContainer.layoutParams = logoLp
        row.addView(logoContainer)

        entry.programs.forEachIndexed { programIndex, program ->
            row.addView(makeProgramCard(program, programIndex == 0))
        }
        row.tag = index
        return row
    }

    private fun buildSourceLabel(entry: GuideEntry): String {
        val base = when {
            entry.item.source.contains("HDHomeRun", ignoreCase = true) -> "LIVE • HDHR"
            entry.item.source.contains("DVR", ignoreCase = true) -> "LIVE • DVR"
            else -> "LIVE • IPTV"
        }
        val group = entry.item.groups.firstOrNull { !it.equals("IPTV", true) && !it.equals("Channels DVR", true) && !it.equals("HDHomeRun", true) }
        val withGroup = if (group.isNullOrBlank()) base else "$base • $group"
        return if (entry.tags.contains("hd")) "$withGroup • HD" else withGroup
    }

    private fun makeProgramCard(program: ProgramBlock, isNow: Boolean): View {
        val widthDp = program.widthDp.coerceAtLeast(110)
        val outer = FrameLayout(this).apply {
            background = getDrawable(R.drawable.guide_program_card)
            tag = if (isNow) "program_now" else "program_later"
            val lp = LinearLayout.LayoutParams(0, dp(46), widthDp.toFloat())
            lp.marginEnd = dp(4)
            layoutParams = lp
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(0), dp(10), dp(0))
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        val time = TextView(this).apply {
            text = program.startLabel
            setTextColor(0xFFB9C0C9.toInt())
            textSize = 10f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val title = TextView(this).apply {
            text = program.title
            setTextColor(0xFFE7EAEE.toInt())
            textSize = 13f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        content.addView(time)
        content.addView(title)
        outer.addView(content)
        if (isNow) {
            val offsetDp = currentProgramOffsetDp(program, widthDp)
            outer.addView(View(this).apply {
                background = getDrawable(R.drawable.guide_now_line)
                layoutParams = FrameLayout.LayoutParams(dp(2), ViewGroup.LayoutParams.MATCH_PARENT).apply {
                    leftMargin = dp(offsetDp.coerceIn(0, widthDp - 2))
                }
            })
        }
        return outer
    }

    private fun currentProgramOffsetDp(program: ProgramBlock, widthDp: Int): Int {
        val now = System.currentTimeMillis()
        val start = program.startMillis
        val end = program.endMillis
        if (start <= 0L || end <= start || now <= start) return 0
        if (now >= end) return widthDp - 2
        val fraction = (now - start).toFloat() / (end - start).toFloat()
        return (widthDp * fraction).roundToInt()
    }

    private fun moveSelection(delta: Int) {
        if (filteredChannels.isEmpty()) return
        if (filteredChannels.isEmpty()) return
        selectedIndex = (selectedIndex + delta).coerceIn(0, filteredChannels.lastIndex)
        rebuildGuideWindow(force = false)
        updateSelection(selectedIndex, restartPreview = false)
    }

    private fun moveCategory(delta: Int) {
        if (categories.isEmpty()) return
        if (categories.isEmpty()) return
        selectedCategoryIndex = (selectedCategoryIndex + delta).coerceIn(0, categories.lastIndex)
        applyCategorySelection(selectedCategoryIndex)
        activeZone = FocusZone.CATEGORY
        applyZoneState()
    }

    private fun updateSelection(index: Int, restartPreview: Boolean) {
        if (!isActivityAlive() || filteredChannels.isEmpty()) return
        if (filteredChannels.isEmpty()) return
        selectedIndex = index.coerceIn(0, filteredChannels.lastIndex)
        val selected = filteredChannels[selectedIndex]
        val channelPrograms = selected.programs.ifEmpty { noInformationPrograms() }

        infoLogo.text = selected.logoText
        val selectedIconUrl = selected.item.iconUrl.trim()
        if (selectedIconUrl.isNotBlank()) {
            infoIcon.visibility = View.VISIBLE
            infoLogo.visibility = View.GONE
            safeLoadImage(selectedIconUrl, infoIcon, centerCrop = false)
        } else {
            infoIcon.visibility = View.GONE
            infoLogo.visibility = View.VISIBLE
        }
        infoChannel.text = selected.item.name
        val categoryName = categories.getOrNull(selectedCategoryIndex)?.name ?: "All Channels"
        infoGroup.text = categoryName
        nowTime.text = "Today, ${channelPrograms[0].startLabel} - ${channelPrograms[0].endLabel}"
        nowTitle.text = channelPrograms[0].title
        descriptionView.text = channelPrograms.firstOrNull()?.description?.takeIf { it.isNotBlank() } ?: selected.description
        // Keep selection updates allocation-free while scrolling. Remote artwork is
        // intentionally avoided here; the full-screen player/details path can show
        // richer art without destabilizing the guide.
        heroBackground.setImageResource(selected.previewRes)
        previewImage.setImageResource(selected.previewRes)
        if (activeZone == FocusZone.GUIDE) {
            armPreviewForSelection(selectedIndex, immediate = false)
        } else if (previewUrl.isBlank()) {
            previewFrame.visibility = View.GONE
            previewImage.alpha = 0.30f
            previewHint.visibility = View.VISIBLE
            previewHint.text = "Move right to guide • preview stays active"
        }

        for (i in 0 until channelList.childCount) {
            val child = channelList.getChildAt(i) as? LinearLayout ?: continue
            val rowTag = child.tag as? Int ?: continue
            val isSelected = rowTag == selectedIndex
            styleRow(child, isSelected, activeZone == FocusZone.GUIDE && isSelected)
        }
        scrollToSelection(selectedIndex)
    }

    private fun armPreviewForSelection(index: Int, immediate: Boolean = true) {
        val entry = filteredChannels.getOrNull(index) ?: return
        if (entry.item.url.isBlank()) return
        previewArmedIndex = index
        previewFrame.visibility = View.VISIBLE
        previewHint.visibility = View.VISIBLE
        previewHint.text = "Loading preview... OK to watch"
        initializePreviewPlayer()
        val isDvrPreview = isChannelsDvrPreview(entry.item.source, entry.item.url)
        val safeDelay = when {
            isDvrPreview -> if (immediate) 1100L else 1400L
            immediate -> 180L
            else -> 420L
        }
        schedulePreview(entry.item.url, entry.item.source, force = true, delayMs = safeDelay)
    }

    private fun schedulePreview(
        url: String,
        sourceLabel: String = "",
        force: Boolean = false,
        delayMs: Long = if (force) 180L else 420L
    ) {
        if (url.isBlank() || liveTvDestroyed) return
        val isDvr = isChannelsDvrPreview(sourceLabel, url)
        val now = System.currentTimeMillis()
        if (isDvr && now < channelsDvrPreviewCooldownUntilMs) {
            previewHint.visibility = View.VISIBLE
            previewHint.text = "DVR preview cooling down - OK to watch"
            return
        }
        if (!force && url == previewUrl && previewPlayer?.playWhenReady == true) return
        previewRunnable?.let { previewHandler.removeCallbacks(it) }
        val targetUrl = url
        val targetSource = sourceLabel
        val token = ++previewRequestToken
        val guardedDelay = if (isDvr) delayMs.coerceAtLeast(1200L) else delayMs.coerceAtLeast(250L)
        previewRunnable = Runnable {
            if (token == previewRequestToken && !liveTvDestroyed) {
                playPreviewNow(targetUrl, targetSource, force, token)
            }
        }
        previewHandler.postDelayed(previewRunnable!!, guardedDelay)
    }

    private fun playPreviewNow(
        url: String,
        sourceLabel: String = "",
        force: Boolean = false,
        token: Int = previewRequestToken
    ) {
        if (url.isBlank() || liveTvDestroyed || token != previewRequestToken) return
        val isDvr = isChannelsDvrPreview(sourceLabel, url)
        val now = System.currentTimeMillis()
        if (isDvr) {
            if (now < channelsDvrPreviewCooldownUntilMs) return
            val sinceLast = now - lastChannelsDvrPreviewStartedAtMs
            if (sinceLast in 0 until 2200L) {
                previewHandler.postDelayed({
                    if (token == previewRequestToken && !liveTvDestroyed) {
                        playPreviewNow(url, sourceLabel, force, token)
                    }
                }, 2200L - sinceLast)
                return
            }
        }
        if (!force && url == previewUrl && previewPlayer?.playWhenReady == true) return
        previewUrl = url
        previewSourceLabel = sourceLabel
        currentPreviewIsChannelsDvr = isDvr
        if (isDvr) lastChannelsDvrPreviewStartedAtMs = System.currentTimeMillis()
        previewImage.alpha = 0.25f
        val mediaItemBuilder = MediaItem.Builder().setUri(Uri.parse(url))
        inferLiveMimeType(url)?.let { mediaItemBuilder.setMimeType(it) }
        try {
            initializePreviewPlayer()
            if (token != previewRequestToken || liveTvDestroyed) return
            previewPlayer?.apply {
                if (currentMediaItem?.localConfiguration?.uri?.toString() != url) {
                    playWhenReady = false
                    runCatching { stop() }
                    runCatching { clearMediaItems() }
                    setMediaItem(mediaItemBuilder.build())
                    prepare()
                }
                playWhenReady = true
                previewHint.visibility = View.VISIBLE
                previewHint.text = if (isDvr) "DVR preview protected - OK to watch" else "OK to watch"
                previewHandler.postDelayed({
                    if (token == previewRequestToken && previewUrl.isNotBlank() && previewPlayer?.playWhenReady == true) {
                        previewHint.visibility = View.GONE
                    }
                }, 3000L)
            }
        } catch (_: Exception) {
            if (isDvr) channelsDvrPreviewCooldownUntilMs = System.currentTimeMillis() + 15_000L
            if (token == previewRequestToken) {
                previewImage.alpha = 1f
                previewHint.visibility = View.VISIBLE
                previewHint.text = if (isDvr) "DVR preview unavailable - OK to watch" else "Preview unavailable - OK to watch"
            }
        }
    }

    private fun isChannelsDvrPreview(sourceLabel: String, url: String): Boolean {
        val source = sourceLabel.lowercase(Locale.US)
        val lowerUrl = url.lowercase(Locale.US)
        return source.contains("dvr") ||
            lowerUrl.contains("/devices/") ||
            lowerUrl.contains("/dvr/") ||
            lowerUrl.contains(":8089")
    }

    private fun applyZoneState() {
        updateTopNavVisualState()
        styleCategories()
        for (i in 0 until channelList.childCount) {
            val child = channelList.getChildAt(i) as? LinearLayout ?: continue
            val rowTag = child.tag as? Int ?: continue
            val isSelected = rowTag == selectedIndex
            styleRow(child, isSelected, activeZone == FocusZone.GUIDE && isSelected)
        }
        val guideVisible = true
        isGuideExpanded = activeZone == FocusZone.GUIDE
        if (guideVisible) rebuildGuideWindow(force = false)
        guideHeaderRow.visibility = View.VISIBLE
        timelineRow.visibility = View.VISIBLE
        horizontalScroll.visibility = View.VISIBLE
        previewFrame.foreground = null
        if (previewUrl.isNotBlank() && previewPlayer != null) {
            previewFrame.visibility = View.VISIBLE
            previewHint.visibility = if (previewPlayer?.playWhenReady == true) View.GONE else View.VISIBLE
            previewHint.text = "OK to watch"
        } else {
            previewFrame.visibility = View.GONE
            previewHint.visibility = View.VISIBLE
            previewHint.text = "Move right to guide • preview auto-starts"
        }
        categoryRail.alpha = 1f
        updateGuideExpansionState()
        previewPlayer?.playWhenReady = previewUrl.isNotBlank()
        forceGuideButton.visibility = View.GONE
        forceGuideButton.isFocusable = false
        forceGuideButton.isClickable = false
        restoreLiveTvKeyAnchor()
    }

    private fun updateGuideExpansionState() {
        categoryPanel.visibility = if (isGuideExpanded) View.GONE else View.VISIBLE
        val layoutParams = mainPanel.layoutParams as LinearLayout.LayoutParams
        layoutParams.marginStart = if (isGuideExpanded) 0 else dp(16)
        mainPanel.layoutParams = layoutParams
        guideHeaderRow.alpha = 1f
        timelineRow.alpha = 1f
        horizontalScroll.alpha = 1f
    }

    private fun scrollToSelection(index: Int) {
        verticalScroll.post {
            val target = (dp(index * rowHeightEstimateDp) - dp(64)).coerceAtLeast(0)
            verticalScroll.scrollTo(0, target)
        }
    }

    private fun styleRow(row: LinearLayout, selected: Boolean, active: Boolean) {
        // v9.7: restore the white focus/selection box without touching the
        // synced red now-line. Program cards are FrameLayout children, so v9.6
        // skipped them when it only looked for LinearLayout children.
        row.background = getDrawable(if (active) R.drawable.guide_row_selected else R.drawable.guide_row_bg)
        row.isSelected = active
        row.isActivated = active
        row.scaleX = if (active) 1.012f else 1f
        row.scaleY = if (active) 1.012f else 1f
        row.alpha = when {
            active -> 1f
            selected -> 0.97f
            else -> 0.90f
        }

        for (i in 1 until row.childCount) {
            val child = row.getChildAt(i) as? ViewGroup ?: continue
            styleProgramCard(child, focused = active && i == 1)
        }
    }

    private fun styleProgramCard(card: ViewGroup, focused: Boolean) {
        card.background = getDrawable(if (focused) R.drawable.guide_program_card_selected else R.drawable.guide_program_card)
        card.isSelected = focused
        card.isActivated = focused
        card.elevation = if (focused) dp(8).toFloat() else 0f
        setProgramTextColor(card, if (focused) 0xFF202124.toInt() else 0xFFE7EAEE.toInt())
    }

    private fun setProgramTextColor(view: View, color: Int) {
        if (view is TextView) {
            view.setTextColor(color)
            return
        }
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                setProgramTextColor(view.getChildAt(i), color)
            }
        }
    }

    private fun openPlayer(index: Int) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (playerLaunchInProgress || now - lastPlayerLaunchAtMs < 900L) return
        val entry = filteredChannels.getOrNull(index) ?: return
        if (entry.item.url.isBlank()) {
            Toast.makeText(this, "This channel has no playable stream yet.", Toast.LENGTH_SHORT).show()
            return
        }
        playerLaunchInProgress = true
        liveTvInputEnabled = false
        lastPlayerLaunchAtMs = now
        previewHandler.removeCallbacksAndMessages(null)
        previewRunnable = null
        previewRequestToken++
        previewUrl = ""
        previewPlayer?.apply {
            playWhenReady = false
            runCatching { stop() }
            runCatching { clearMediaItems() }
            runCatching { seekToDefaultPosition() }
        }

        val windowStart = (index - 40).coerceAtLeast(0)
        val windowEnd = (index + 40).coerceAtMost(filteredChannels.lastIndex)
        val playbackWindow = filteredChannels.subList(windowStart, windowEnd + 1)
        val playbackIndex = (index - windowStart).coerceAtLeast(0)

        Log.i("DebridChannels", "LiveTvOwner launching PlayerActivity index=" + index + " title=" + entry.item.name.take(40))
        startActivityForResult(
            Intent(this, PlayerActivity::class.java)
                .putExtra(PlayerActivity.EXTRA_STREAM_URL, entry.item.url)
                .putExtra(PlayerActivity.EXTRA_TITLE, entry.item.name)
                .putExtra(PlayerActivity.EXTRA_SOURCE_LABEL, entry.item.source)
                .putExtra(PlayerActivity.EXTRA_DEBUG_LABEL, entry.item.debug)
                .putExtra(PlayerActivity.EXTRA_CHANNEL_INDEX, playbackIndex)
                .putExtra(PlayerActivity.EXTRA_CHANNELS_JSON, serializeChannels(playbackWindow)),
            PLAYER_REQUEST_CODE
        )
    }

    private fun serializeChannels(entries: List<GuideEntry>): String {
        val arr = JSONArray()
        entries.forEach { entry ->
            val channel = entry.item
            val now = entry.programs.firstOrNull()
            val next = entry.programs.drop(1).firstOrNull()
            arr.put(
                JSONObject()
                    .put("name", channel.name)
                    .put("url", channel.url)
                    .put("source", channel.source)
                    .put("debug", channel.debug)
                    .put("iconUrl", channel.iconUrl)
                    .put("programTitle", now?.title.orEmpty())
                    .put("programDescription", now?.description.orEmpty())
                    .put("programStartMillis", now?.startMillis ?: 0L)
                    .put("programEndMillis", now?.endMillis ?: 0L)
                    .put("nextTitle", next?.title.orEmpty())
            )
        }
        return arr.toString()
    }

    private fun buildGuideEntry(item: LiveSourceResolver.ChannelItem, index: Int, resolveProgramsNow: Boolean = false): GuideEntry {
        val seed = item.name.uppercase(Locale.US)
        val tags = mutableSetOf<String>()
        when {
            seed.contains("CNN") || seed.contains("FOX") || seed.contains("MSNBC") || seed.contains("CSPAN") || seed.contains("HLN") -> tags += "news"
            seed.contains("ESPN") || seed.contains("FS") || seed.contains("NFL") || seed.contains("NBA") || seed.contains("GOLF") || seed.contains("CBS") -> tags += "sports"
            seed.contains("AMC") || seed.contains("TNT") || seed.contains("LIFETIME") || seed.contains("TRU") || seed.contains("HBO") || seed.contains("STARZ") -> tags += "movies"
            seed.contains("DISNEY") || seed.contains("NICK") || seed.contains("CARTOON") -> tags += "kids"
            else -> tags += "general"
        }
        if (item.groups.any { it.equals("Favorites", true) || it.equals("Favorite", true) }) tags += "favorites"
        if (seed.contains("HD")) tags += "hd"
        when {
            item.source.contains("HDHomeRun", true) -> tags += "hdhr"
            item.source.contains("DVR", true) -> tags += "dvr"
            else -> tags += "iptv"
        }
        item.groups.forEach { group ->
            val normalized = group.lowercase(Locale.US)
            when {
                normalized.contains("news") -> tags += "news"
                normalized.contains("sport") -> tags += "sports"
                normalized.contains("movie") || normalized.contains("film") -> tags += "movies"
                normalized.contains("kids") || normalized.contains("family") -> tags += "kids"
            }
        }

        val descriptor = when {
            tags.contains("news") -> "Live news, breaking updates, and current coverage in the unified ARVIO-style guide."
            tags.contains("movies") -> "Movie and event blocks with polished premium-channel presentation."
            tags.contains("sports") -> "Live sports and studio coverage with upcoming game windows."
            tags.contains("kids") -> "Family and kids programming with lighter schedule blocks."
            else -> "Current episode and upcoming schedule blocks shown in the live guide with full now/next/later details."
        }
        val programs = if (resolveProgramsNow) resolveProgramsForItem(item).ifEmpty { noInformationPrograms() } else noInformationPrograms()
        val logoText = item.name
            .replace("Channels DVR", "")
            .trim()
            .split(" ", "-", "_")
            .filter { it.isNotBlank() }
            .take(2)
            .joinToString("") { it.take(1).uppercase(Locale.US) }
            .ifBlank { "TV" }
            .take(4)
        val previewPool = listOf(
            R.drawable.bg_wonka,
            R.drawable.bg_dune,
            R.drawable.bg_fallout,
            R.drawable.bg_shogun,
            R.drawable.bg_civilwar,
            R.drawable.bg_halo,
            R.drawable.bg_batman,
            R.drawable.bg_mayor
        )
        return GuideEntry(item, logoText, descriptor, programs, previewPool[index % previewPool.size], tags)
    }

    private fun resolveProgramsForItem(item: LiveSourceResolver.ChannelItem): List<ProgramBlock> {
        return runCatching {
            val resolvedPrograms = guideProgramResolver.programsFor(item.name, item.number, guideKeyFrom(item), item.source)
            resolvedPrograms
                .filter { it.title.isNotBlank() }
                .map {
                    ProgramBlock(
                        title = it.title.ifBlank { "No information" },
                        startLabel = it.start.ifBlank { "Now" },
                        endLabel = it.end.ifBlank { "Later" },
                        widthDp = it.widthDp.coerceIn(100, 560),
                        description = it.description,
                        imageUrl = it.imageUrl,
                        startMillis = it.startMillis,
                        endMillis = it.endMillis
                    )
                }
                .ifEmpty { noInformationPrograms() }
        }.getOrElse {
            noInformationPrograms()
        }
    }

    private fun runLiveTvBackground(block: () -> Unit) {
        if (liveTvDestroyed) return
        if (executor.isShutdown || executor.isTerminated) {
            executor = Executors.newSingleThreadExecutor()
        }
        try {
            executor.execute {
                if (!liveTvDestroyed) block()
            }
        } catch (_: java.util.concurrent.RejectedExecutionException) {
            if (!liveTvDestroyed) {
                executor = Executors.newSingleThreadExecutor()
                executor.execute { block() }
            }
        }
    }

    private fun refreshGuideProgramsInBackground(seedEntries: List<GuideEntry>, force: Boolean = false) {
        if (guideRefreshInProgress || seedEntries.isEmpty()) return
        if (!force && isEpgProgramCacheFresh()) {
            val cachedEntries = applyPersistentEpgCache(seedEntries)
            currentChannels = cachedEntries
            categoryCache.clear()
            categories = buildCategories(cachedEntries)
            if (categories.isNotEmpty()) applyCategorySelection(selectedCategoryIndex.coerceIn(0, categories.lastIndex))
            channelStats.text = "Showing ${filteredChannels.size} of ${cachedEntries.size} channels • using saved ${guideCacheLabel()} EPG cache"
            return
        }
        guideRefreshInProgress = true
        runLiveTvBackground {
            val updatedByUrl = linkedMapOf<String, List<ProgramBlock>>()
            val guideScanEntries = seedEntries
                .sortedWith(compareByDescending<GuideEntry> { isCurrentOrNearCurrentGuideEntry(it) }
                    .thenByDescending { it.item.source.contains("HDHomeRun", true) || it.item.source.contains("DVR", true) })
            val maxInitialGuideChannels = guideScanEntries.size.coerceAtMost(if (force) 40 else 24)
            guideScanEntries.take(maxInitialGuideChannels).forEachIndexed { idx, entry ->
                if (Thread.currentThread().isInterrupted) return@runLiveTvBackground
                val programs = resolveProgramsForItem(entry.item)
                if (programs.isNotEmpty()) updatedByUrl[entry.item.url] = programs
                if (idx > 0 && idx % 6 == 0) {
                    val snapshot = updatedByUrl.toMap()
                    runOnUiThread { mergeGuideProgramUpdates(snapshot, done = false, scanned = idx + 1, total = maxInitialGuideChannels.coerceAtMost(seedEntries.size)) }
                }
            }

            runOnUiThread {
                mergeGuideProgramUpdates(updatedByUrl.toMap(), done = true, scanned = guideScanEntries.take(maxInitialGuideChannels).size, total = guideScanEntries.size)
                if (updatedByUrl.isNotEmpty()) savePersistentEpgCache(updatedByUrl)
                getSharedPreferences(EPG_CACHE_PREFS, MODE_PRIVATE).edit().putBoolean("force_refresh_requested", false).apply()
                guideRefreshInProgress = false
                forceGuideButton.text = "Refresh Guide"
            }
        }
    }

    private fun isCurrentOrNearCurrentGuideEntry(entry: GuideEntry): Boolean {
        val now = System.currentTimeMillis()
        return entry.programs.any { program ->
            val start = program.startMillis
            val end = program.endMillis
            start > 0L && end > start && start <= now + 2L * 60L * 60L * 1000L && end >= now - 30L * 60L * 1000L
        }
    }

    private fun mergeGuideProgramUpdates(updates: Map<String, List<ProgramBlock>>, done: Boolean, scanned: Int, total: Int) {
        runCatching {
            if (updates.isNotEmpty()) {
                currentChannels = currentChannels.map { entry ->
                    updates[entry.item.url]?.let { programs ->
                        entry.copy(programs = programs.ifEmpty { noInformationPrograms() })
                    } ?: entry
                }
                categoryCache.clear()
                val selectedCategory = categories.getOrNull(selectedCategoryIndex)
                filteredChannels = selectedCategory?.let { category ->
                    currentChannels.filter(category.matcher).ifEmpty { currentChannels }
                } ?: currentChannels
                selectedIndex = if (filteredChannels.isEmpty()) 0 else selectedIndex.coerceIn(0, filteredChannels.lastIndex)
                rebuildGuideWindow(force = true)
                updateSelection(selectedIndex, restartPreview = false)
            }
            channelStats.text = if (done) {
                "Showing ${filteredChannels.size} of ${currentChannels.size} channels • guide loaded for ${updates.size} channels"
            } else {
                "Showing ${filteredChannels.size} of ${currentChannels.size} channels • loading guide ${scanned.coerceAtMost(total)}/$total"
            }
        }.onFailure {
            channelStats.text = "Guide data loaded, but render failed safely — keeping channel list visible"
        }
    }

    private fun isEpgProgramCacheFresh(): Boolean {
        val prefs = getSharedPreferences(EPG_CACHE_PREFS, MODE_PRIVATE)
        if (prefs.getBoolean("force_refresh_requested", false)) return false
        val updatedAt = prefs.getLong(EPG_CACHE_UPDATED_AT, 0L)
        return updatedAt > 0L && System.currentTimeMillis() - updatedAt < guideCacheTtlMs()
    }

    private fun loadPersistentEpgCache(): Map<String, List<ProgramBlock>> {
        val prefs = getSharedPreferences(EPG_CACHE_PREFS, MODE_PRIVATE)
        val updatedAt = prefs.getLong(EPG_CACHE_UPDATED_AT, 0L)
        if (updatedAt <= 0L || System.currentTimeMillis() - updatedAt > guideCacheTtlMs()) return emptyMap()
        val raw = prefs.getString(EPG_CACHE_JSON, "").orEmpty()
        if (raw.isBlank()) return emptyMap()
        return runCatching {
            val root = JSONObject(raw)
            val out = linkedMapOf<String, List<ProgramBlock>>()
            val keys = root.keys()
            while (keys.hasNext()) {
                val url = keys.next()
                val arr = root.optJSONArray(url) ?: JSONArray()
                val blocks = mutableListOf<ProgramBlock>()
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    blocks += ProgramBlock(
                        title = obj.optString("title").ifBlank { "No information" },
                        startLabel = obj.optString("startLabel").ifBlank { "Now" },
                        endLabel = obj.optString("endLabel").ifBlank { "Later" },
                        widthDp = obj.optInt("widthDp", 170).coerceIn(100, 560),
                        description = obj.optString("description"),
                        imageUrl = obj.optString("imageUrl"),
                        startMillis = obj.optLong("startMillis", 0L),
                        endMillis = obj.optLong("endMillis", 0L)
                    )
                }
                if (blocks.isNotEmpty()) out[url] = blocks
            }
            out
        }.getOrDefault(emptyMap())
    }

    private fun applyPersistentEpgCache(entries: List<GuideEntry>): List<GuideEntry> {
        val cached = loadPersistentEpgCache()
        if (cached.isEmpty()) return entries
        return entries.map { entry ->
            cached[entry.item.url]?.let { programs ->
                entry.copy(programs = programs.ifEmpty { noInformationPrograms() })
            } ?: entry
        }
    }

    private fun savePersistentEpgCache(updates: Map<String, List<ProgramBlock>>) {
        if (updates.isEmpty()) return
        val merged = linkedMapOf<String, List<ProgramBlock>>()
        merged.putAll(loadPersistentEpgCache())
        updates.forEach { (url, programs) ->
            val usable = programs.filter { it.title.isNotBlank() && !it.title.equals("No information", true) }
            if (url.isNotBlank() && usable.isNotEmpty()) merged[url] = usable.take(12)
        }
        val root = JSONObject()
        merged.entries.take(6000).forEach { (url, programs) ->
            val arr = JSONArray()
            programs.take(12).forEach { p ->
                arr.put(JSONObject()
                    .put("title", p.title)
                    .put("startLabel", p.startLabel)
                    .put("endLabel", p.endLabel)
                    .put("widthDp", p.widthDp)
                    .put("description", p.description)
                    .put("imageUrl", p.imageUrl)
                    .put("startMillis", p.startMillis)
                    .put("endMillis", p.endMillis)
                )
            }
            root.put(url, arr)
        }
        getSharedPreferences(EPG_CACHE_PREFS, MODE_PRIVATE).edit()
            .putString(EPG_CACHE_JSON, root.toString())
            .putLong(EPG_CACHE_UPDATED_AT, System.currentTimeMillis())
            .apply()
    }

    private fun guideKeyFrom(item: LiveSourceResolver.ChannelItem): String {
        val candidates = listOf(item.debug, item.groups.joinToString(" "), item.name)
        val source = item.source.lowercase(Locale.US)
        val preferred = if (source.contains("xtream") || source.contains("iptv")) {
            listOf(Regex("streamId=([^ •]+)"), Regex("stream_id=([^ •]+)"), Regex("tvgId=([^ •]+)"), Regex("epgId=([^ •]+)"))
        } else {
            listOf(Regex("tvg-id=\"([^\"]+)\""), Regex("tvgId=([^ •]+)"), Regex("guide=([^ •]+)"), Regex("ch=([^ •]+)"), Regex("tvg=([^ •]+)"), Regex("tvgName=([^ •]+)"), Regex("id=([^ •]+)"))
        }
        for (text in candidates) {
            for (regex in preferred) {
                regex.find(text)?.groupValues?.getOrNull(1)?.let { if (it.isNotBlank()) return it }
            }
        }
        return ""
    }

    private fun tvgIdFrom(item: LiveSourceResolver.ChannelItem): String {
        val candidates = listOf(item.debug, item.groups.joinToString(" "), item.name)
        val regexes = listOf(Regex("tvg-id=\"([^\"]+)\""), Regex("tvgId=([^ •]+)"), Regex("tvg=([^ •]+)"), Regex("tvgName=([^ •]+)"), Regex("guide=([^ •]+)"), Regex("epgId=([^ •]+)"), Regex("streamId=([^ •]+)"))
        for (text in candidates) {
            for (regex in regexes) regex.find(text)?.groupValues?.getOrNull(1)?.let { return it }
        }
        return ""
    }

    private fun noInformationPrograms(): List<ProgramBlock> = listOf(
        ProgramBlock("No information", "Now", "Next", 170),
        ProgramBlock("No information", "Next", "Later", 170),
        ProgramBlock("No information", "Later", "", 170)
    )

    private fun syntheticProgramsFor(channelName: String, index: Int): List<ProgramBlock> {
        val titlePool = when {
            channelName.contains("TRU", ignoreCase = true) -> listOf("Hoosiers (1986)", "NHL on TNT Face Off", "NHL Hockey", "Postgame Live", "Inside the Arena")
            channelName.contains("AMC", ignoreCase = true) -> listOf("The Martian (2015)", "National Treasure (2004)", "Movie Bonus Round", "Late Night Rewind", "Behind the Scenes")
            channelName.contains("LIFETIME", ignoreCase = true) -> listOf("Toni Braxton's Breathe Again", "Mary J. Blige Presents Be Happy", "The Beach House Murders", "Movie Extra", "Tonight on Lifetime")
            channelName.contains("CNN", ignoreCase = true) -> listOf("CNN News Central", "Inside Politics", "The Lead With Jake Tapper", "The Situation Room", "Newsnight")
            channelName.contains("CSPAN", ignoreCase = true) -> listOf("Washington Journal", "Public Affairs Event", "Floor Debate Replay", "Committee Hearing", "Capitol Review")
            channelName.contains("A&E", ignoreCase = true) || channelName.contains("AETV", ignoreCase = true) -> listOf("Live PD: Police Patrol", "Live PD: Police Patrol", "Court Cam", "Booked: First Day In", "Nightwatch")
            channelName.contains("HLN", ignoreCase = true) -> listOf("Morning Express", "Weekend Express", "Forensic Files", "Weekend Express", "Forensic Files II")
            else -> listOf("${channelName} Live", "${channelName} Spotlight", "${channelName} After Hours", "${channelName} Tonight", "${channelName} Encore")
        }
        val cal = Calendar.getInstance().apply {
            set(Calendar.MINUTE, if (get(Calendar.MINUTE) < 30) 0 else 30)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val formatter = SimpleDateFormat("h:mm a", Locale.US)
        val durations = listOf(60, 30, 30, 60, 30)
        val widths = listOf(170, 120, 120, 170, 120)
        val blocks = mutableListOf<ProgramBlock>()
        for (i in titlePool.indices) {
            val start = cal.time
            cal.add(Calendar.MINUTE, durations[i])
            val end = cal.time
            blocks += ProgramBlock(
                titlePool[i],
                formatter.format(start),
                formatter.format(end),
                widths[i] + ((index + i) % 2) * 10
            )
        }
        return blocks
    }


    private fun sourcePriority(source: String): Int {
        return when {
            source.contains("HDHomeRun", true) -> 0
            source.contains("DVR", true) -> 1
            else -> 2
        }
    }

    private fun extractChannelSortNumber(item: LiveSourceResolver.ChannelItem): Int {
        val debugMatch = Regex("""(?:guide|playKey|number|ch)=([0-9]+(?:\.[0-9]+)?)""").find(item.debug)
        val textMatch = item.number.takeIf { it.isNotBlank() }
            ?: debugMatch?.groupValues?.getOrNull(1)
            ?: Regex("""\b([0-9]{1,4}(?:\.[0-9]+)?)\b""").find(item.name)?.groupValues?.getOrNull(1)
        return textMatch?.toDoubleOrNull()?.times(10)?.toInt() ?: Int.MAX_VALUE
    }

    private fun backfillHdHomeRunIconsFromDvr(items: List<LiveSourceResolver.ChannelItem>): List<LiveSourceResolver.ChannelItem> {
        if (items.isEmpty()) return items
        val iconMap = linkedMapOf<String, String>()

        fun addIconKeys(item: LiveSourceResolver.ChannelItem) {
            val icon = item.iconUrl.trim()
            if (icon.isBlank()) return
            val candidates = mutableListOf<String>()
            candidates += item.number
            candidates += item.name
            candidates += item.name.substringBefore("-").trim()
            candidates += item.name.substringBefore(" ").trim()
            candidates += guideKeyFrom(item)
            candidates += tvgIdFrom(item)
            candidates.forEach { key ->
                val normalized = normalizeChannelIconKey(key)
                if (normalized.isNotBlank()) iconMap.putIfAbsent(normalized, icon)
            }
        }

        // Prefer logos from Channels DVR/IPTV first, then fill matching HDHomeRun rows.
        loadCachedLogoTable().forEach { (key, icon) -> if (key.isNotBlank() && icon.isNotBlank()) iconMap.putIfAbsent(key, icon) }
        items.filter { it.iconUrl.isNotBlank() && !it.source.contains("HDHomeRun", true) }.forEach { addIconKeys(it) }
        items.filter { it.iconUrl.isNotBlank() && it.source.contains("HDHomeRun", true) }.forEach { addIconKeys(it) }
        saveCachedLogoTable(iconMap)

        return items.map { item ->
            if (!item.source.contains("HDHomeRun", true) || item.iconUrl.isNotBlank()) return@map item
            val matchedIcon = listOf(
                item.number,
                item.name,
                item.name.substringBefore("-").trim(),
                item.name.substringBefore(" ").trim(),
                guideKeyFrom(item),
                tvgIdFrom(item)
            )
                .asSequence()
                .map { normalizeChannelIconKey(it) }
                .filter { it.isNotBlank() }
                .mapNotNull { iconMap[it] }
                .firstOrNull()
                .orEmpty()
            if (matchedIcon.isBlank()) item else item.copy(iconUrl = matchedIcon)
        }
    }

    private fun loadCachedLogoTable(): Map<String, String> {
        val raw = getSharedPreferences("live_tv_logo_cache", MODE_PRIVATE).getString("logos", "").orEmpty()
        if (raw.isBlank()) return emptyMap()
        return runCatching {
            val obj = JSONObject(raw)
            val out = linkedMapOf<String, String>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val value = obj.optString(key)
                if (key.isNotBlank() && value.isNotBlank()) out[key] = value
            }
            out
        }.getOrDefault(emptyMap())
    }

    private fun saveCachedLogoTable(iconMap: Map<String, String>) {
        if (iconMap.isEmpty()) return
        runCatching {
            val obj = JSONObject()
            iconMap.entries.take(2000).forEach { (key, value) -> if (key.isNotBlank() && value.isNotBlank()) obj.put(key, value) }
            getSharedPreferences("live_tv_logo_cache", MODE_PRIVATE).edit().putString("logos", obj.toString()).apply()
        }
    }

    private fun normalizeChannelIconKey(raw: String): String {
        return raw
            .lowercase(Locale.US)
            .replace("hd", "")
            .replace(Regex("[^a-z0-9]+"), "")
            .trim()
    }

    private fun addSpacer(parent: LinearLayout, widthDp: Int) {
        parent.addView(SpaceView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(widthDp), 1)
        })
    }

    private fun inferLiveMimeType(url: String): String? {
        val lower = url.lowercase(Locale.US).substringBefore("?")
        return when {
            lower.endsWith(".m3u8") || lower.contains("m3u8") || lower.contains("/hls/") -> MimeTypes.APPLICATION_M3U8
            lower.endsWith(".mpd") || lower.contains("/dash/") -> MimeTypes.APPLICATION_MPD
            lower.endsWith(".ts") || lower.endsWith(".mpegts") || lower.endsWith(".mpg") || lower.contains("format=ts") || lower.contains("/auto/v") || lower.contains("hdhomerun") -> MimeTypes.VIDEO_MP2T
            lower.endsWith(".mp4") || lower.contains("format=mp4") -> MimeTypes.VIDEO_MP4
            else -> null
        }
    }

    private fun looksLikeTsStream(url: String): Boolean {
        return inferLiveMimeType(url) == MimeTypes.VIDEO_MP2T
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    data class GuideEntry(
        val item: LiveSourceResolver.ChannelItem,
        val logoText: String,
        val description: String,
        val programs: List<ProgramBlock>,
        val previewRes: Int,
        val tags: Set<String>
    )

    data class ProgramBlock(
        val title: String,
        val startLabel: String,
        val endLabel: String,
        val widthDp: Int,
        val description: String = "",
        val imageUrl: String = "",
        val startMillis: Long = 0L,
        val endMillis: Long = 0L
    )

    data class CategoryFilter(
        val name: String,
        val matcher: (GuideEntry) -> Boolean
    )

    enum class FocusZone { NAV, CATEGORY, GUIDE }

    private class SpaceView(context: android.content.Context) : View(context)
}
