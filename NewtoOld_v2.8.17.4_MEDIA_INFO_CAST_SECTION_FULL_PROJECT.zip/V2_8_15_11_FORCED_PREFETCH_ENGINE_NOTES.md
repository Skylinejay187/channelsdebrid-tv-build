# NewtoOld v2.8.15.11 Forced Prefetch Engine

Clean consolidation from v2.8.15.10. Playback stays direct. NAS cache now uses a forced ahead prefetch worker for progressive VOD links and writes real bytes to `.dcache`; temporary cache is deleted on playback exit. Expected manifest state while active: `forced_prefetch_active`.
