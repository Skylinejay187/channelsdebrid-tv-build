# NewtoOld v2.8.15.7 — Source Open Fix + Option B Cache Policy

Base: v2.8.15.6 clean consolidated source.

## Fix focus
This build fixes the `Cache: waiting for source` NAS cache problem seen after v2.8.15.6.

## What changed
- Option B cache policy confirmed: cache only while playback is active; stop/pause when playback exits.
- Reworked the NAS downloader source opener so it mirrors ExoPlayer first:
  - plain GET first
  - same player User-Agent first
  - no Stremio Origin/Referer on first attempts
  - range resume attempted only after a plain player-style open
- Added stronger logcat labels:
  - `VOD_REAL_NAS_CACHE: source_open ...`
  - `VOD_REAL_NAS_CACHE: source_refused_attempt ...`
  - `VOD_REAL_NAS_CACHE: active ...`
- Kept the real SMB `.dcache` writer path from v2.8.15.6.

## Expected verification
- Overlay should move past `Cache: waiting for source` into `Cache: filling NAS cache` or `Cache: saving stream to NAS`.
- NAS `.dcache` file should grow while playback continues.
- `vod_cache_manifest.txt` should show `state=active`, `bytes>0`, and percent when the source reports total length.

## Still preserved
- v2.8.15.6 row/logo rewrite work remains in place.
- No UI redesign was done in this patch.
