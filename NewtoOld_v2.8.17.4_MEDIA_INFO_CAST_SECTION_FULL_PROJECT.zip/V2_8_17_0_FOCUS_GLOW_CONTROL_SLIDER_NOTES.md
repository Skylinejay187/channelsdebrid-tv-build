# v2.8.17.0 Focus Glow Control Slider

Scope: Layout Editor focus-glow control only.

Preserved unchanged:
- Donor new-app one-row system
- Full card strip / no 7-card cap
- Row change resets to first card
- Player production stack behavior
- Cache OFF direct playback and internal cache block
- Hero original/high-quality backdrop path
- UI preset picker/export/import/View behavior

Added:
- New HomeLayoutSettings field: focusGlowSpreadPercent
- New Layout Editor slider: Focus glow spread (0-100)
- Glow strength now controls focus-ring alpha
- Focus glow spread controls ring spread and focus elevation
- Preset export/import includes the new home_layout_focus_glow_spread_percent key automatically

Audit:
- No hidden row renderer changes
- No player/cache/source resolver changes
- No hero artwork source changes
