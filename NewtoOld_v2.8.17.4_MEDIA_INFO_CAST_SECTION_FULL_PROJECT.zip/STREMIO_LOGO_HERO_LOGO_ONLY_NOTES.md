# NewtoOld v2.8.17.2 - Stremio Logo + Hero Logo Only

Scope: logo resolution only. No row layout, focus, hero backdrop, player, cache, preset, or layout-editor behavior was intentionally changed.

Changes:
- Added expanded Stremio logo lookup keys: logo, clearLogo, clearlogo, titleLogo, title_logo, hdLogo, hdtvLogo, and nested images logo keys.
- Added addon meta endpoint lookup for missing row-card logos.
- Added Cinemeta IMDb-id fallback lookup for Stremio items when the addon catalog omits logos.
- Hero logo now uses the same upgraded artwork loader path and preserves full-quality transparent logos.

Preserved:
- Donor one-row system.
- Focus effects and glow controls.
- Hero backdrop quality.
- Player and cache behavior.
- Preset import/export behavior.
