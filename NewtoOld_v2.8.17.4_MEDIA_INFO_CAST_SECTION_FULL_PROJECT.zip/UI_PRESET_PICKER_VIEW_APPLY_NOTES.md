# NewtoOld v2.8.16.9 UI Preset Picker + View Apply

Scope-limited change from v2.8.16.8 feature-stack base.

## Added
- UI preset export now uses Android ACTION_CREATE_DOCUMENT so the user chooses where to save the JSON file.
- UI preset import now uses Android ACTION_OPEN_DOCUMENT so the user chooses the preset file.
- If no picker/file manager is available, export/import falls back to the app-safe external files folder.
- Added View button behavior that saves the layout and returns to MainActivity with a force reload flag.
- MainActivity now reloads HomeLayoutSettings on resume/new intent so saved layout changes apply immediately without force-closing the app.

## Preserved
- Donor one-row system and reset-to-first-card behavior.
- Focus scale/ring/lift effects.
- Original-quality hero background path.
- Cache OFF direct playback behavior.
- Internal disk cache remains blocked.
- Player production stack from v2.8.16.8 base.

## Build marker
NewtoOld_v2.8.16.9_UI_PRESET_PICKER_VIEW_APPLY
