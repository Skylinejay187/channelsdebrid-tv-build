# v2.1.0 TRUE Clean Core Rewrite

This build is a clean ownership consolidation pass, not a feature add.

## Fixed
- Version name/code now reports `2.1.0-true-clean-core` / `78`.
- Added `DebridChannels TRUE_CLEAN_CORE_START ...` log markers in MainActivity, LiveTvActivity, and PlayerActivity.
- PlayerActivity is `singleTask` and excluded from recents to prevent stacked/duplicate player windows.
- PlayerActivity now attaches ExoPlayer to `PlayerView` immediately using `playerView.player = exoPlayer`; this targets the full-player black screen where PlayerActivity launched but video surface never attached.
- Removed stale `SINGLE_TOP` launch flag from the Live TV -> PlayerActivity launch path.
- Added PlayerActivity duplicate-launch guard via `onNewIntent`.
- Preserved VOD player UI features: poster, backdrop, logo, rating/info, subtitles/audio/episodes/zoom/settings controls.

## Verification
Use logcat and confirm this exact marker appears after install:

`TRUE_CLEAN_CORE_START MainActivity build=2.1.0-true-clean-core code=78`

## GitHub workflow note
Old workflow runs do not change the new uploaded zip, but old workflow artifacts/APKs can absolutely be installed by mistake. Delete old artifacts if it helps avoid confusion, and always install the newest APK from the newest run.
