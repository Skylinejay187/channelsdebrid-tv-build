# NewtoOld v2.4 Backendless Artwork

This build adds direct artwork loading so the app can show posters, backdrops, hero logos, row-card logos, and extra art without requiring a backend.

Default artwork source mode is Direct metadata. The backend remains optional only for Hybrid/Backend-only modes.

Trailers were intentionally left for the next pass.
