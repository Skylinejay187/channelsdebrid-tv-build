# NewtoOld v2.5.1 — HDHomeRun + Hero Controls Hotfix

Base: NewtoOld v2.5 backendless direct endpoint project.

Changes:
- Restored HDHomeRun LAN auto-scan support without reintroducing backend dependencies.
- Added HDHomeRun discovery via my.hdhomerun.com/discover and direct lineup.json loading.
- Re-enabled HDHomeRun status in Live TV source badges/logs.
- Restored Settings toggle: Enable HDHomeRun auto-scan.
- Added hero logo width and height controls to Pro Layout Editor.
- Added hero text size control to Pro Layout Editor.
- Hero logo renderer now uses saved logo width/height settings.
- Hero title/meta/description now scale from saved hero text size percentage.
- Hero information text restores IMDb/TMDB rating labels with star/logo-style text badges when rating data is present.

Kept:
- Backend mode remains removed.
- Real Debrid/Torbox remain removed.
- Timeshift remains disabled by settings.
- Direct IPTV/M3U/XMLTV/Xtream paths remain active.
