# NewtoOld v1.1 - Row Focus + Extra Artwork + Top Menu Theme Fix

Base: NewtoOld v1.0 full project source.

## Fixes
- Reworked row DOWN/UP DPAD handling so vertical row changes do not get consumed by the old repeat/bounce guard.
- Added `ROW_FOCUS_NAV_APPLY` log marker when moving between rows.
- Reduced row-settle lock timing so focus does not bounce back to the previous row.
- Added stronger row focus fallback after scroll-to-row.

## Extra artwork
- Added extra artwork placement settings:
  - 0 = original/center
  - 1 = top-left
  - 2 = top-right
- Added extra artwork source mode settings:
  - 0 = auto
  - 1 = logo only
  - 2 = card artwork/full artwork
  - 3 = prefer clear logo/art then fallback
- Added runtime log: `EXTRA_ARTWORK_PLACEMENT_APPLY`.

## Top menu
- Added top menu theme options 0-5.
- Top-center remains the default.
- Future movable layout-editor support is preserved via the existing offset setting.
- Added runtime log: `TOP_MENU_THEME_APPLY`.

## Preserved
- Live TV stream logic from v0.6 was not touched.
- Player was not touched.
- Live TV UI/layout was not touched.
- Backend/artwork loader paths were preserved.

## Build note
Gradle is not installed in this container, so a full local compile could not be run here. The wrapper prints: "Gradle is not installed. Install Gradle 8.7+ or use the provided GitHub Actions workflow."
