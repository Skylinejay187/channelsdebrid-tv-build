# NewtoOld v2.8.17.2 - VOD Player Switch Links + Resume

Scope: player-only update.

Added:
- In-player Switch Link option in Player Settings overlay.
- Lists available sources for the current movie/episode without backing out manually.
- Resolves selected alternate source with existing resolver fallback path.
- Swaps playback media item in-place and seeks to the current playback position.
- Resume prompt for VOD when prior progress exists.
- Auto-save progress while watching.
- Clear resume entry when content is completed past the finish threshold.

Preserved:
- Donor one-row home renderer.
- Row change reset-to-first-card behavior.
- Hero image quality.
- Focus effects/glow controls.
- Cache OFF direct playback behavior and internal disk cache block.
- Preset import/export and View apply behavior.
- Stremio logo/hero-logo path fixes.
- HDHomeRun manual/native guide work from the current base.

Verification log markers:
- VOD_PLAYER_SWITCH_LINKS_RESUME
- VOD_SWITCH_LINKS: loading
- VOD_SWITCH_LINKS: applying
- VOD_RESUME_PROMPT
- VOD_RESUME_APPLIED
- VOD_RESUME_COMPLETED_CLEAR
