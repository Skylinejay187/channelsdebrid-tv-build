# NewtoOld v2.8.15.15 — Build Marker Enforced + Row Focus Audit

Base: v2.8.15.14 clean source.

Critical correction:
- app/build.gradle versionName was still reporting NewtoOld_v2.8.15.6_FULL_NAS_CACHE_ROW_REWRITE.
- versionCode was still 281506.
- This made runtime verification unreliable and violated the clean-build marker rule.

Now enforced:
- versionCode 281515
- versionName NewtoOld_v2.8.15.15_BUILD_MARKER_ENFORCED_ROW_FOCUS_AUDIT
- Logcat marker: DC_BUILD_MARKER: NewtoOld_v2.8.15.15_BUILD_MARKER_ENFORCED_ROW_FOCUS_AUDIT
- Row marker: ROW_ENGINE: V6_MARKER_ENFORCED_TRUE_REPLACEMENT_LINEAR_ROWS_NO_RECYCLER_JUMP
- Focus marker: FOCUS_GRAPH: V4_MARKER_ENFORCED_NO_RELAYOUT_NO_FULL_ROW_REFRESH

Preservation note:
- Extra hero artwork remains present and controlled by existing user placement/size configuration.
- Cache remains default OFF and internal disk cache remains blocked unless NAS/USB is enabled.

Audit requirement for next APK upload:
- If logcat does not show v2.8.15.15 markers, the built APK is stale or the wrong APK was installed.
