# v2.8.17.3 HDHomeRun Manual XMLTV Override

Scoped change only: Live TV HDHomeRun guide/logo override.

Added:
- Settings field: Use manual XMLTV guide for HDHomeRun channels.
- Settings field: HDHomeRun manual XMLTV guide URL.
- Force Refresh Guide button clears HDHomeRun XMLTV guide cache.
- Live guide resolver now loads HDHomeRun manual XMLTV when enabled.
- XMLTV channel logos are used to backfill HDHomeRun channel icons by channel id, number, and display-name.

Preserved:
- Donor one-row home system.
- Focus effects and hero image quality.
- Player/cache-off direct playback behavior.
- UI preset export/import behavior.
