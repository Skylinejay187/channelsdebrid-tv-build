# v2.8.17.4 Media Info Cast Section

Scope-only change:
- Adds real cast metadata population inside MediaDetailsActivity.
- Uses TMDB credits when TMDB key/external IMDb id are available.
- Falls back to Cinemeta/Stremio meta cast/director data.
- Shows actor image when available, otherwise safe initials/text fallback.
- Keeps rows, hero, focus effects, player, trailer controls, cache behavior, presets, HDHomeRun work, and layout editor untouched.

Verification marker:
- MEDIA_INFO_CAST_SECTION: members=<count> source=<tmdb|cinemeta|none>
