# NewtoOld v2.8.17.1 - Glow Control Fixed Clean Rebuild

Clean rebuild from latest UI preset picker / focus effects base.

Fixes:
- Fixed HomeLayoutEditorActivity compile error from invalid card reference inside FrameLayout.apply.
- Fixed MainActivity onNewIntent signature to match Android/AppCompat non-null Intent override.
- Preserves donor one-row renderer, focus effects, hero quality, player stack, cache OFF direct playback, UI preset picker/view apply.
- Adds focus glow spread/intensity slider wiring without touching unrelated systems.

Audit:
- No row system changes beyond existing donor path.
- No cache/player behavior changes.
- No hero quality changes.
