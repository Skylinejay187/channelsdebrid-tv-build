package com.channelsdebrid.tv.data

import android.content.Context
import android.util.Base64
import java.io.File
import com.channelsdebrid.tv.live.LiveSourceResolver
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class LiveGuideProgramResolver(
    private val context: Context? = null,
    private val backendBaseUrl: String = "",
    private val userId: String = "demo",
    private val channelsDvrBaseUrl: String = "",
    private val xtreamServer: String = "",
    private val xtreamUser: String = "",
    private val xtreamPass: String = ""
) {
    companion object {
        private const val CHANNELS_DVR_INITIAL_GUIDE_SECONDS = 43_200
        private const val CHANNELS_DVR_EXTENDED_GUIDE_SECONDS = 43_200
        private const val LOCAL_GUIDE_CACHE_TTL_MS = 12L * 60L * 60L * 1000L
    }

    data class Program(
        val title: String,
        val start: String,
        val end: String,
        val widthDp: Int,
        val description: String = "",
        val imageUrl: String = "",
        val startMillis: Long = 0L,
        val endMillis: Long = 0L
    )

    private data class XmltvProgram(
        val channelId: String,
        val title: String,
        val startRaw: String,
        val stopRaw: String,
        val description: String,
        val imageUrl: String
    )

    @Volatile private var dvrXmltvLoaded = false
    @Volatile private var dvrExtendedXmltvLoaded = false
    @Volatile private var dvrXmltvPrograms: Map<String, List<XmltvProgram>> = emptyMap()
@Volatile private var hdhrXmltvLoaded = false
@Volatile private var hdhrXmltvPrograms: Map<String, List<XmltvProgram>> = emptyMap()
    private val xtreamEpgCache = linkedMapOf<String, List<Program>>()

    fun programsFor(channelName: String, channelNumber: String, tvgId: String = "", source: String = ""): List<Program> {
        val normalizedSource = source.lowercase(Locale.US)

        // Live TV guide is app-owned now. Channels DVR, M3U and Xtream/IPTV no longer
        // depend on the Debrid backend. Channels DVR XMLTV is cached locally for 12
        // hours so reopening Live TV is instant and does not re-download the guide.
        if (normalizedSource.contains("channels dvr") || normalizedSource.contains("dvr")) {
            val dvrPrograms = programsFromChannelsDvrXmltv(channelName, channelNumber, tvgId)
            if (dvrPrograms.isNotEmpty()) return dvrPrograms
        }

        if (normalizedSource.contains("hdhomerun") || normalizedSource.contains("hdhr")) {
            val hdhrPrograms = programsFromHdHomeRunXmltv(channelName, channelNumber, tvgId)
            if (hdhrPrograms.isNotEmpty()) return hdhrPrograms
        }

        if (normalizedSource.contains("xtream") || normalizedSource.contains("iptv")) {
            val xtreamPrograms = listOf(tvgId, channelNumber)
                .map { it.trim() }
                .firstNotNullOfOrNull { key -> programsFromXtream(key).takeIf { it.isNotEmpty() } }
            if (!xtreamPrograms.isNullOrEmpty()) return xtreamPrograms
        }

        return emptyList()
    }

    private fun programsFromChannelsDvrXmltv(channelName: String, channelNumber: String, tvgId: String): List<Program> {
        ensureDvrXmltvLoaded()
        if (dvrXmltvPrograms.isEmpty()) return emptyList()

        val keys = linkedSetOf<String>()
        listOf(tvgId, channelNumber, channelName).forEach { raw ->
            val value = raw.trim()
            if (value.isNotBlank()) {
                keys += value
                keys += normalize(value)
            }
        }

        val matches = keys.asSequence()
            .mapNotNull { key -> dvrXmltvPrograms[key] }
            .firstOrNull { it.isNotEmpty() }
            ?: return emptyList()

        return matches
            .sortedBy { parseDateMillis(it.startRaw) ?: 0L }
            .take(8)
            .map { xml ->
                val minutes = durationMinutes(xml.startRaw, xml.stopRaw).coerceIn(15, 240)
                Program(
                    title = xml.title.ifBlank { "No information" },
                    start = labelTime(xml.startRaw).ifBlank { "Now" },
                    end = labelTime(xml.stopRaw).ifBlank { "Later" },
                    widthDp = ((minutes / 30f) * 120).roundToInt().coerceIn(100, 560),
                    description = xml.description,
                    imageUrl = xml.imageUrl,
                    startMillis = parseDateMillis(xml.startRaw) ?: 0L,
                    endMillis = parseDateMillis(xml.stopRaw) ?: 0L
                )
            }
    }

    private fun programsFromHdHomeRunXmltv(channelName: String, channelNumber: String, tvgId: String): List<Program> {
        ensureHdHomeRunXmltvLoaded()
        if (hdhrXmltvPrograms.isEmpty()) return emptyList()

        val keys = linkedSetOf<String>()
        listOf(tvgId, channelNumber, channelName).forEach { raw ->
            val value = raw.trim()
            if (value.isNotBlank()) {
                keys += value
                keys += normalize(value)
            }
        }

        val matches = keys.asSequence()
            .mapNotNull { key -> hdhrXmltvPrograms[key] }
            .firstOrNull { it.isNotEmpty() }
            ?: return emptyList()

        return matches
            .sortedBy { parseDateMillis(it.startRaw) ?: 0L }
            .take(8)
            .map { xml ->
                val minutes = durationMinutes(xml.startRaw, xml.stopRaw).coerceIn(15, 240)
                Program(
                    title = xml.title.ifBlank { "No information" },
                    start = labelTime(xml.startRaw).ifBlank { "Now" },
                    end = labelTime(xml.stopRaw).ifBlank { "Later" },
                    widthDp = ((minutes / 30f) * 120).roundToInt().coerceIn(100, 560),
                    description = xml.description,
                    imageUrl = xml.imageUrl,
                    startMillis = parseDateMillis(xml.startRaw) ?: 0L,
                    endMillis = parseDateMillis(xml.stopRaw) ?: 0L
                )
            }
    }

    private fun ensureHdHomeRunXmltvLoaded() {
        if (hdhrXmltvLoaded) return
        synchronized(this) {
            if (hdhrXmltvLoaded) return
            hdhrXmltvLoaded = true
            val xml = fetchHdHomeRunXmltv()
            if (xml.isBlank()) return
            hdhrXmltvPrograms = parseXmltv(xml)
        }
    }

    private fun fetchHdHomeRunXmltv(): String {
        val cacheFile = context?.let { File(it.filesDir, "hdhomerun_guide.xml") }
        val metaFile = context?.let { File(it.filesDir, "hdhomerun_guide.timestamp") }
        val now = System.currentTimeMillis()
        if (cacheFile != null && metaFile != null && cacheFile.exists() && metaFile.exists()) {
            val updatedAt = metaFile.readText().trim().toLongOrNull() ?: 0L
            if (updatedAt > 0L && now - updatedAt < LOCAL_GUIDE_CACHE_TTL_MS) {
                return runCatching { cacheFile.readText() }.getOrDefault("")
            }
        }

        val deviceAuth = LiveSourceResolver.discoverHdHomeRunDeviceAuths().joinToString("")
        if (deviceAuth.isBlank()) return runCatching { cacheFile?.readText().orEmpty() }.getOrDefault("")

        val fresh = fetchText(
            "https://api.hdhomerun.com/api/xmltv?DeviceAuth=${enc(deviceAuth)}",
            accept = "application/xml,text/xml,*/*",
            maxBytes = 8 * 1024 * 1024
        )
        if (fresh.isNotBlank() && cacheFile != null && metaFile != null) {
            runCatching {
                cacheFile.writeText(fresh)
                metaFile.writeText(now.toString())
            }
        }
        return fresh.ifBlank { runCatching { cacheFile?.readText().orEmpty() }.getOrDefault("") }
    }

    private fun ensureDvrXmltvLoaded() {
        if (dvrXmltvLoaded) return
        synchronized(this) {
            if (dvrXmltvLoaded) return
            dvrXmltvLoaded = true
            val xml = fetchChannelsDvrXmltv(CHANNELS_DVR_INITIAL_GUIDE_SECONDS)
            if (xml.isBlank()) return
            dvrXmltvPrograms = parseXmltv(xml)
        }
    }

    fun prefetchExtendedChannelsDvrGuide() {
        dvrExtendedXmltvLoaded = true
    }

    private fun fetchChannelsDvrXmltv(durationSeconds: Int): String {
        val configured = channelsDvrBaseUrl.trim().trimEnd('/')
        val base = configured.ifBlank { LiveSourceResolver.discoverChannelsDvrBaseUrl().orEmpty() }.trimEnd('/')
        if (base.isBlank()) return ""

        val cacheFile = context?.let { File(it.filesDir, "channels_dvr_guide_${durationSeconds}.xml") }
        val metaFile = context?.let { File(it.filesDir, "channels_dvr_guide_${durationSeconds}.timestamp") }
        val now = System.currentTimeMillis()
        if (cacheFile != null && metaFile != null && cacheFile.exists() && metaFile.exists()) {
            val updatedAt = metaFile.readText().trim().toLongOrNull() ?: 0L
            if (updatedAt > 0L && now - updatedAt < LOCAL_GUIDE_CACHE_TTL_MS) {
                return runCatching { cacheFile.readText() }.getOrDefault("")
            }
        }

        val fresh = fetchText("$base/devices/ANY/guide/xmltv?duration=$durationSeconds", accept = "application/xml,text/xml,*/*", maxBytes = 4 * 1024 * 1024)
        if (fresh.isNotBlank() && cacheFile != null && metaFile != null) {
            runCatching {
                cacheFile.writeText(fresh)
                metaFile.writeText(now.toString())
            }
        }
        return fresh.ifBlank { runCatching { cacheFile?.readText().orEmpty() }.getOrDefault("") }
    }

    private fun mergeProgramMaps(current: Map<String, List<XmltvProgram>>, incoming: Map<String, List<XmltvProgram>>): Map<String, List<XmltvProgram>> {
        if (current.isEmpty()) return incoming
        if (incoming.isEmpty()) return current
        val merged = linkedMapOf<String, MutableList<XmltvProgram>>()
        current.forEach { (key, programs) -> merged.getOrPut(key) { mutableListOf() }.addAll(programs) }
        incoming.forEach { (key, programs) ->
            val bucket = merged.getOrPut(key) { mutableListOf() }
            programs.forEach { program ->
                if (bucket.none { it.channelId == program.channelId && it.startRaw == program.startRaw && it.title == program.title }) {
                    bucket += program
                }
            }
        }
        return merged.mapValues { it.value.sortedBy { program -> parseDateMillis(program.startRaw) ?: 0L } }
    }

    private fun parseXmltv(xml: String): Map<String, List<XmltvProgram>> {
        val channelNames = linkedMapOf<String, MutableSet<String>>()
        val channelRegex = Regex("<channel\\s+[^>]*id=\"([^\"]+)\"[^>]*>(.*?)</channel>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        channelRegex.findAll(xml).forEach { match ->
            val id = unescapeXml(match.groupValues[1].trim())
            val body = match.groupValues[2]
            val names = channelNames.getOrPut(id) { linkedSetOf() }
            names += id
            Regex("<display-name[^>]*>(.*?)</display-name>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                .findAll(body)
                .forEach { names += unescapeXml(it.groupValues[1].trim()) }
        }

        val result = linkedMapOf<String, MutableList<XmltvProgram>>()
        val programmeRegex = Regex("<programme\\s+([^>]*)>(.*?)</programme>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        programmeRegex.findAll(xml).forEach { match ->
            val attrs = match.groupValues[1]
            val body = match.groupValues[2]
            val channelId = attr(attrs, "channel")
            if (channelId.isBlank()) return@forEach
            val start = attr(attrs, "start")
            val stop = attr(attrs, "stop")
            val title = tag(body, "title").ifBlank { "No information" }
            val desc = tag(body, "desc")
            val icon = Regex("<icon[^>]*src=\"([^\"]+)\"", RegexOption.IGNORE_CASE)
                .find(body)?.groupValues?.getOrNull(1).orEmpty()
            val program = XmltvProgram(channelId, title, start, stop, desc, unescapeXml(icon))

            val names = channelNames[channelId].orEmpty() + channelId
            names.forEach { key ->
                val clean = key.trim()
                if (clean.isNotBlank()) {
                    result.getOrPut(clean) { mutableListOf() } += program
                    result.getOrPut(normalize(clean)) { mutableListOf() } += program
                }
            }
        }
        return result
    }

    private fun programsFromXtream(streamOrEpgId: String): List<Program> {
        val streamId = streamOrEpgId.trim()
        val base = xtreamServer.trim().trimEnd('/')
        if (base.isBlank() || streamId.isBlank() || xtreamUser.isBlank() || xtreamPass.isBlank()) return emptyList()
        xtreamEpgCache[streamId]?.let { return it }

        val encodedUser = enc(xtreamUser)
        val encodedPass = enc(xtreamPass)
        val encodedStream = enc(streamId)
        val urls = listOf(
            "$base/player_api.php?username=$encodedUser&password=$encodedPass&action=get_short_epg&stream_id=$encodedStream",
            "$base/player_api.php?username=$encodedUser&password=$encodedPass&action=get_simple_data_table&stream_id=$encodedStream"
        )
        for (url in urls) {
            val parsed = parseXtreamEpg(fetchText(url, accept = "application/json"))
            if (parsed.isNotEmpty()) {
                xtreamEpgCache[streamId] = parsed
                return parsed
            }
        }
        xtreamEpgCache[streamId] = emptyList()
        return emptyList()
    }

    private fun parseXtreamEpg(body: String): List<Program> {
        if (body.isBlank()) return emptyList()
        val root = try {
            if (body.trim().startsWith("[")) JSONObject().put("epg_listings", JSONArray(body)) else JSONObject(body)
        } catch (_: Exception) { return emptyList() }
        val arr = root.optJSONArray("epg_listings")
            ?: root.optJSONArray("listings")
            ?: root.optJSONArray("epg")
            ?: root.optJSONArray("data")
            ?: return emptyList()
        val out = mutableListOf<Program>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val title = decodeMaybeBase64(firstString(obj, "title", "name", "program"))
            val desc = decodeMaybeBase64(firstString(obj, "description", "desc", "plot"))
            val start = firstString(obj, "start", "start_timestamp", "startTime", "startLabel")
            val end = firstString(obj, "end", "stop", "end_timestamp", "endTime", "endLabel")
            val minutes = durationMinutes(start, end).coerceIn(15, 240)
            out += Program(
                title = title.ifBlank { "No information" },
                start = labelTime(start).ifBlank { if (i == 0) "Now" else "Next" },
                end = labelTime(end).ifBlank { "Later" },
                widthDp = ((minutes / 30f) * 120).roundToInt().coerceIn(100, 560),
                description = desc,
                imageUrl = firstString(obj, "image", "icon", "thumbnail", "cover"),
                startMillis = parseDateMillis(start) ?: obj.optLong("start_timestamp", 0L).takeIf { it > 0L }?.let { if (it < 100000000000L) it * 1000L else it } ?: 0L,
                endMillis = parseDateMillis(end) ?: obj.optLong("end_timestamp", 0L).takeIf { it > 0L }?.let { if (it < 100000000000L) it * 1000L else it } ?: 0L
            )
        }
        return out.take(8)
    }

    private fun programsFromBackend(channelName: String, channelNumber: String, tvgId: String, source: String): List<Program> {
        val base = backendBaseUrl.trim().trimEnd('/').ifBlank { return emptyList() }
        val encodedName = enc(channelName)
        val encodedNumber = enc(channelNumber)
        val encodedTvg = enc(tvgId)
        val encodedSource = enc(source)
        val encodedUser = enc(userId.ifBlank { "demo" })
        val urls = listOf(
            "$base/live/guide?userId=$encodedUser&channelName=$encodedName&channelNumber=$encodedNumber&tvgId=$encodedTvg&source=$encodedSource",
            "$base/live/epg?userId=$encodedUser&channelName=$encodedName&channelNumber=$encodedNumber&tvgId=$encodedTvg&source=$encodedSource",
            "$base/api/live/guide?userId=$encodedUser&channelName=$encodedName&channelNumber=$encodedNumber&tvgId=$encodedTvg&source=$encodedSource"
        )
        for (url in urls) {
            val parsed = parseBackendJson(fetchText(url, accept = "application/json"))
            if (parsed.isNotEmpty()) return parsed
        }
        return emptyList()
    }

    private fun parseBackendJson(body: String): List<Program> {
        if (body.isBlank()) return emptyList()
        val root = try {
            if (body.trim().startsWith("[")) JSONObject().put("programs", JSONArray(body)) else JSONObject(body)
        } catch (_: Exception) { return emptyList() }
        val arr = findProgramArray(root) ?: return emptyList()
        val out = mutableListOf<Program>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val title = firstString(obj, "title", "Title", "name", "Name", "program", "Program", "episodeTitle", "EpisodeTitle")
            if (title.isBlank()) continue
            val startRaw = firstString(obj, "startLabel", "start", "Start", "startTime", "StartTime", "airDateTime", "time")
            val endRaw = firstString(obj, "endLabel", "end", "End", "endTime", "EndTime", "stop")
            val minutes = durationMinutes(startRaw, endRaw).coerceIn(15, 240)
            val description = firstString(obj, "description", "Description", "summary", "plot", "desc")
            val image = firstString(obj, "image", "Image", "imageUrl", "ImageURL", "poster", "backdrop", "fanart", "thumbnail")
            out += Program(
                title,
                labelTime(startRaw).ifBlank { if (i == 0) "Now" else "Next" },
                labelTime(endRaw).ifBlank { "Later" },
                ((minutes / 30f) * 120).roundToInt().coerceIn(100, 560),
                description,
                image,
                parseDateMillis(startRaw) ?: obj.optLong("startMs", 0L).takeIf { it > 0L } ?: (obj.optLong("start", 0L).takeIf { it > 1000000000L }?.let { if (it < 100000000000L) it * 1000L else it } ?: 0L),
                parseDateMillis(endRaw) ?: obj.optLong("endMs", 0L).takeIf { it > 0L } ?: (obj.optLong("end", 0L).takeIf { it > 1000000000L }?.let { if (it < 100000000000L) it * 1000L else it } ?: 0L)
            )
        }
        return out.take(10)
    }

    private fun fetchText(url: String, accept: String, maxBytes: Int = 512 * 1024): String {
        return try {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 900
                readTimeout = 1200
                requestMethod = "GET"
                setRequestProperty("Accept", accept)
            }
            if (conn.responseCode !in 200..299) "" else conn.inputStream.bufferedReader().use { reader ->
                val out = StringBuilder()
                val buffer = CharArray(8192)
                var total = 0
                while (true) {
                    val read = reader.read(buffer)
                    if (read <= 0) break
                    total += read
                    if (total > maxBytes) break
                    out.append(buffer, 0, read)
                }
                out.toString()
            }
        } catch (_: Exception) {
            ""
        }
    }

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

    private fun findProgramArray(root: JSONObject): JSONArray? {
        listOf("programs", "guide", "items", "epg", "data", "results", "airings", "listings", "epg_listings").forEach { key ->
            root.optJSONArray(key)?.let { return it }
        }
        listOf("channel", "Channel", "schedule", "Schedule", "guideData").forEach { key ->
            val obj = root.optJSONObject(key) ?: return@forEach
            listOf("programs", "guide", "items", "epg", "airings", "listings", "epg_listings").forEach { inner ->
                obj.optJSONArray(inner)?.let { return it }
            }
        }
        return null
    }

    private fun firstString(obj: JSONObject, vararg keys: String): String {
        for (key in keys) {
            val value = obj.optString(key).trim()
            if (value.isNotBlank() && !value.equals("null", true)) return value
        }
        return ""
    }

    private fun attr(attrs: String, name: String): String = Regex("$name=\"([^\"]+)\"", RegexOption.IGNORE_CASE)
        .find(attrs)?.groupValues?.getOrNull(1)?.let { unescapeXml(it) }.orEmpty()

    private fun tag(body: String, name: String): String = Regex("<$name[^>]*>(.*?)</$name>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        .find(body)?.groupValues?.getOrNull(1)?.let { unescapeXml(it.trim()) }.orEmpty()

    private fun unescapeXml(value: String): String = value
        .replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&apos;", "'")

    private fun normalize(value: String): String = value.lowercase(Locale.US)
        .replace("hd", "")
        .replace("fhd", "")
        .replace("uhd", "")
        .replace("4k", "")
        .replace(Regex("[^a-z0-9]+"), "")

    private fun labelTime(raw: String): String {
        val value = raw.trim()
        if (value.isBlank()) return ""
        value.toLongOrNull()?.let { epoch ->
            val millis = if (epoch < 100000000000L) epoch * 1000L else epoch
            return SimpleDateFormat("h:mm a", Locale.US).format(Date(millis))
        }
        if (Regex("^[0-9]{1,2}:[0-9]{2}(\\s?[AP]M)?$", RegexOption.IGNORE_CASE).matches(value)) return value.uppercase(Locale.US)
        val millis = parseDateMillis(value) ?: return value.takeLast(8).trim().ifBlank { value.take(12) }
        return SimpleDateFormat("h:mm a", Locale.US).format(Date(millis))
    }

    private fun parseDateMillis(raw: String): Long? {
        val value = raw.trim()
        value.toLongOrNull()?.let { epoch -> return if (epoch < 100000000000L) epoch * 1000L else epoch }
        val candidates = listOf(
            "yyyy-MM-dd'T'HH:mm:ss.SSSX",
            "yyyy-MM-dd'T'HH:mm:ssX",
            "yyyy-MM-dd HH:mm:ss",
            "yyyyMMddHHmmss Z",
            "yyyyMMddHHmmssZ",
            "yyyyMMddHHmmss"
        )
        for (fmt in candidates) {
            try {
                return SimpleDateFormat(fmt, Locale.US).parse(value)?.time
            } catch (_: Exception) {}
        }
        return null
    }

    private fun durationMinutes(startRaw: String, endRaw: String): Int {
        val start = parseDateMillis(startRaw)
        val end = parseDateMillis(endRaw)
        if (start != null && end != null && end > start) return ((end - start) / 60000L).toInt()
        return 30
    }

    private fun decodeMaybeBase64(value: String): String {
        val trimmed = value.trim()
        if (trimmed.isBlank()) return ""
        return try {
            val decoded = String(Base64.decode(trimmed, Base64.DEFAULT)).trim()
            decoded.ifBlank { trimmed }
        } catch (_: Exception) {
            trimmed
        }
    }
}
