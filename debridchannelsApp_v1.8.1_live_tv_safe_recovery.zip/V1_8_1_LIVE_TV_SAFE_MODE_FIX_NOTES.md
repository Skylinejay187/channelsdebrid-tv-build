# v1.8.1 Live TV Safe Recovery

Fixes the Live TV freeze reported after the premium polish build.

Changes:
- Disabled inline Live TV preview decoder during guide open/scroll.
- Full playback still opens normally when pressing OK/Enter on a channel.
- Disabled remote HD channel-logo loading inside the guide to avoid memory spikes from large icon packs.
- Keeps cached lineup and 12-hour EPG disk cache behavior.
- Keeps Channels DVR Direct, HDHomeRun, M3U, and Xtream/IPTV provider support.
- Keeps the rest of the v1.8.x movie/TV/trailer polish intact.
