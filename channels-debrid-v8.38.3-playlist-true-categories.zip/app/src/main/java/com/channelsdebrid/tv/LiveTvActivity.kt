package com.channelsdebrid.tv

import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.ui.PlayerView
import com.channelsdebrid.tv.live.LiveSourceResolver
import com.channelsdebrid.tv.playback.PlayerActivity
import com.channelsdebrid.tv.settings.SettingsRepository
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class LiveTvActivity : AppCompatActivity() {

    private lateinit var settingsRepository: SettingsRepository
    private lateinit var clockView: TextView
    private lateinit var infoLogo: TextView
    private lateinit var infoChannel: TextView
    private lateinit var infoGroup: TextView
    private lateinit var nowTime: TextView
    private lateinit var nowTitle: TextView
    private lateinit var descriptionView: TextView
    private lateinit var nextLine: TextView
    private lateinit var laterLine: TextView
    private lateinit var progressBar: View
    private lateinit var timelineRow: LinearLayout
    private lateinit var channelList: LinearLayout
    private lateinit var previewImage: ImageView
    private lateinit var previewFrame: FrameLayout
    private lateinit var previewPlayerView: PlayerView
    private lateinit var previewHint: TextView
    private lateinit var guideHeaderRow: LinearLayout
    private lateinit var categoryRail: LinearLayout
    private lateinit var horizontalScroll: HorizontalScrollView
    private lateinit var verticalScroll: ScrollView
    private lateinit var loadingOverlay: FrameLayout
    private lateinit var loadingText: TextView
    private lateinit var contentRoot: View

    private val executor = Executors.newSingleThreadExecutor()
    private var currentChannels: List<GuideEntry> = emptyList()
    private var filteredChannels: List<GuideEntry> = emptyList()
    private var categories: List<CategoryFilter> = emptyList()
    private var categoryViews: List<TextView> = emptyList()
    private var selectedIndex = 0
    private var selectedCategoryIndex = 0
    private var activeZone = FocusZone.CATEGORY
    private var previewArmedIndex = -1
    private var previewPlayer: ExoPlayer? = null
    private var previewUrl: String = ""
    private val previewHandler = Handler(Looper.getMainLooper())
    private var previewRunnable: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_live_tv)
        settingsRepository = SettingsRepository(this)

        clockView = findViewById(R.id.liveTvClock)
        infoLogo = findViewById(R.id.liveTvInfoLogo)
        infoChannel = findViewById(R.id.liveTvInfoChannel)
        infoGroup = findViewById(R.id.liveTvInfoGroup)
        nowTime = findViewById(R.id.liveTvNowTime)
        nowTitle = findViewById(R.id.liveTvNowTitle)
        descriptionView = findViewById(R.id.liveTvDescription)
        nextLine = findViewById(R.id.liveTvNextLine)
        laterLine = findViewById(R.id.liveTvLaterLine)
        progressBar = findViewById(R.id.liveTvProgressBar)
        timelineRow = findViewById(R.id.liveTvTimeline)
        channelList = findViewById(R.id.liveTvChannelList)
        previewImage = findViewById(R.id.liveTvPreviewImage)
        previewFrame = findViewById(R.id.liveTvPreviewFrame)
        previewPlayerView = findViewById(R.id.liveTvPreviewPlayer)
        previewHint = findViewById(R.id.liveTvPreviewHint)
        guideHeaderRow = findViewById(R.id.liveTvGuideHeaderRow)
        categoryRail = findViewById(R.id.liveTvCategoryRail)
        horizontalScroll = findViewById(R.id.liveTvHorizontalScroll)
        verticalScroll = findViewById(R.id.liveTvVerticalScroll)
        loadingOverlay = findViewById(R.id.liveTvLoadingOverlay)
        loadingText = findViewById(R.id.liveTvLoadingText)
        contentRoot = findViewById(R.id.liveTvContentRoot)

        previewFrame.setOnClickListener {
            if (filteredChannels.isNotEmpty() && activeZone == FocusZone.GUIDE) {
                openPlayer(selectedIndex)
            }
        }

        updateClock()
        buildTimeline()
        initializePreviewPlayer()
        loadChannels()
    }

    override fun onStop() {
        super.onStop()
        previewHandler.removeCallbacksAndMessages(null)
        previewPlayer?.playWhenReady = false
    }

    override fun onDestroy() {
        super.onDestroy()
        previewHandler.removeCallbacksAndMessages(null)
        executor.shutdownNow()
        previewPlayerView.player = null
        previewPlayer?.release()
        previewPlayer = null
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        if (filteredChannels.isEmpty() && categories.isEmpty()) return super.dispatchKeyEvent(event)

        return when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> {
                when (activeZone) {
                    FocusZone.CATEGORY -> moveCategory(-1)
                    FocusZone.GUIDE -> moveSelection(-1)
                }
                applyZoneState()
                true
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                when (activeZone) {
                    FocusZone.CATEGORY -> moveCategory(1)
                    FocusZone.GUIDE -> moveSelection(1)
                }
                applyZoneState()
                true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                when (activeZone) {
                    FocusZone.GUIDE -> {
                        activeZone = FocusZone.CATEGORY
                        applyZoneState()
                        true
                    }
                    FocusZone.CATEGORY -> super.dispatchKeyEvent(event)
                }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                when (activeZone) {
                    FocusZone.CATEGORY -> {
                        activeZone = FocusZone.GUIDE
                        armPreviewForSelection(selectedIndex)
                        applyZoneState()
                        true
                    }
                    FocusZone.GUIDE -> {
                        openPlayer(selectedIndex)
                        true
                    }
                }
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                when (activeZone) {
                    FocusZone.CATEGORY -> {
                        applyCategorySelection(selectedCategoryIndex)
                        activeZone = FocusZone.GUIDE
                        armPreviewForSelection(selectedIndex)
                        applyZoneState()
                        true
                    }
                    FocusZone.GUIDE -> {
                        openPlayer(selectedIndex)
                        true
                    }
                }
            }
            KeyEvent.KEYCODE_BACK -> {
                when (activeZone) {
                    FocusZone.GUIDE -> {
                        activeZone = FocusZone.CATEGORY
                        applyZoneState()
                        true
                    }
                    FocusZone.CATEGORY -> super.dispatchKeyEvent(event)
                }
            }
            else -> super.dispatchKeyEvent(event)
        }
    }

    private fun initializePreviewPlayer() {
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("ChannelsDebridTV/1.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(7000)
            .setReadTimeoutMs(10000)
        previewPlayer = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(httpFactory))
            .build().also {
                previewPlayerView.player = it
                it.volume = 0f
                it.repeatMode = androidx.media3.common.Player.REPEAT_MODE_ALL
                it.playWhenReady = false
            }
    }

    private fun updateClock() {
        val formatter = SimpleDateFormat("h:mm a", Locale.US)
        clockView.text = formatter.format(Date())
    }

    private fun loadChannels() {
        showLoading(true, "Loading channels...")
        infoChannel.text = "Loading Live TV"
        infoGroup.text = "Unified Live TV"
        descriptionView.text = "Loading unified Channels DVR and IPTV guide with ARVIO-style layout behavior."
        channelList.removeAllViews()
        categoryRail.removeAllViews()

        val dvr = settingsRepository.loadChannelsDvr()
        val xtream = settingsRepository.loadXtream()

        executor.execute {
            val allChannels = mutableListOf<LiveSourceResolver.ChannelItem>()
            var dvrDeviceId = dvr.deviceId

            if (dvr.baseUrl.isNotBlank()) {
                val dvrResult = LiveSourceResolver.loadDvrChannels(dvr.baseUrl, dvr.deviceId)
                allChannels += dvrResult.channels
                if (!dvrResult.deviceId.isNullOrBlank() && dvrResult.deviceId != dvr.deviceId) {
                    dvrDeviceId = dvrResult.deviceId
                    settingsRepository.saveChannelsDvr(dvr.copy(deviceId = dvrDeviceId))
                }
            }

            if (xtream.enabled && xtream.server.isNotBlank() && xtream.username.isNotBlank() && xtream.password.isNotBlank()) {
                val (xtreamChannels, _) = LiveSourceResolver.loadXtreamChannels(
                    xtream.server,
                    xtream.username,
                    xtream.password
                )
                allChannels += xtreamChannels
            }

            val entries = allChannels
                .distinctBy { it.source + "|" + it.name + "|" + it.url }
                .mapIndexed { index, item -> buildGuideEntry(item, index) }
                .take(160)

            runOnUiThread {
                showLoading(false)
                currentChannels = entries
                categories = buildCategories(entries)
                selectedCategoryIndex = 0
                buildCategoryRail()
                if (entries.isEmpty()) {
                    infoChannel.text = "No channels found"
                    infoGroup.text = "Add Channels DVR or IPTV in Settings"
                    descriptionView.text = "Once a source is configured, channels will appear here in the unified guide."
                    Toast.makeText(this, "No source configured. Add Channels DVR or Xtream in Settings.", Toast.LENGTH_LONG).show()
                } else {
                    applyCategorySelection(0)
                    infoGroup.text = "${entries.size} channels • ${if (dvrDeviceId.isNotBlank()) "DVR $dvrDeviceId + IPTV" else "Unified Live TV"}"
                }
            }
        }
    }

    private fun showLoading(isLoading: Boolean, message: String = "Loading channels...") {
        loadingText.text = message
        loadingOverlay.visibility = if (isLoading) View.VISIBLE else View.GONE
        contentRoot.visibility = if (isLoading) View.INVISIBLE else View.VISIBLE
        if (isLoading) {
            loadingOverlay.bringToFront()
            loadingOverlay.alpha = 1f
        } else {
            loadingOverlay.alpha = 1f
        }
    }

    private fun buildCategories(entries: List<GuideEntry>): List<CategoryFilter> {
        if (entries.isEmpty()) return emptyList()

        val defs = mutableListOf<CategoryFilter>()
        defs += CategoryFilter("All Channels", entries.size) { true }

        val orderedGroups = linkedMapOf<String, Int>()
        entries.forEach { entry ->
            val rawGroup = entry.item.group.trim()
            val normalized = rawGroup.ifBlank { if (entry.item.source.contains("DVR", true)) "Channels DVR" else "Other" }
            orderedGroups[normalized] = (orderedGroups[normalized] ?: 0) + 1
        }

        orderedGroups.forEach { (groupName, count) ->
            defs += CategoryFilter(groupName, count) { entry ->
                entry.item.group.trim().ifBlank { if (entry.item.source.contains("DVR", true)) "Channels DVR" else "Other" } == groupName
            }
        }

        return defs
    }

    private fun buildCategoryRail() {
        categoryRail.removeAllViews()
        categoryViews = categories.mapIndexed { index, category ->
            TextView(this).apply {
                text = if (category.count > 0) "${category.name} (${category.count})" else category.name
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 13f
                background = getDrawable(R.drawable.guide_category_idle)
                setPadding(dp(16), dp(12), dp(16), dp(12))
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.bottomMargin = dp(12)
                layoutParams = lp
                setOnClickListener {
                    selectedCategoryIndex = index
                    applyCategorySelection(index)
                    activeZone = FocusZone.CATEGORY
                    applyZoneState()
                }
            }.also { categoryRail.addView(it) }
        }
        styleCategories()
    }

    private fun applyCategorySelection(index: Int) {
        if (categories.isEmpty()) return
        selectedCategoryIndex = index.coerceIn(0, categories.lastIndex)
        filteredChannels = currentChannels.filter(categories[selectedCategoryIndex].matcher)
        if (filteredChannels.isEmpty()) filteredChannels = currentChannels
        channelList.removeAllViews()
        filteredChannels.forEachIndexed { rowIndex, entry ->
            channelList.addView(makeGuideRow(rowIndex, entry))
        }
        selectedIndex = 0
        previewArmedIndex = -1
        updateSelection(0, restartPreview = false)
        styleCategories()
        if (filteredChannels.isEmpty()) {
            activeZone = FocusZone.CATEGORY
        }
        applyZoneState()
    }

    private fun styleCategories() {
        categoryViews.forEachIndexed { index, view ->
            val selected = index == selectedCategoryIndex
            val active = activeZone == FocusZone.CATEGORY && selected
            view.background = getDrawable(if (active || selected) R.drawable.guide_category_selected else R.drawable.guide_category_idle)
            view.alpha = if (selected) 1f else 0.74f
        }
    }

    private fun buildTimeline() {
        timelineRow.removeAllViews()
        val labels = mutableListOf<String>()
        val cal = Calendar.getInstance().apply {
            set(Calendar.MINUTE, if (get(Calendar.MINUTE) < 30) 0 else 30)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val formatter = SimpleDateFormat("h:mm a", Locale.US)
        repeat(7) {
            labels += formatter.format(cal.time)
            cal.add(Calendar.MINUTE, 30)
        }
        addSpacer(timelineRow, 188)
        labels.forEach {
            timelineRow.addView(TextView(this).apply {
                text = it
                setTextColor(0xFFA9B1BD.toInt())
                textSize = 14f
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(148), ViewGroup.LayoutParams.WRAP_CONTENT)
            })
        }
    }

    private fun makeGuideRow(index: Int, entry: GuideEntry): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = getDrawable(R.drawable.guide_row_bg)
            isClickable = true
            setPadding(dp(12), dp(10), dp(12), dp(10))
            val lp = LinearLayout.LayoutParams(dp(1110), ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(12)
            layoutParams = lp
            setOnClickListener {
                selectedIndex = index
                updateSelection(index, restartPreview = true)
                activeZone = FocusZone.GUIDE
                applyZoneState()
            }
        }

        val logoBox = TextView(this).apply {
            text = entry.logoText
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 16f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            background = getDrawable(R.drawable.guide_logo_tile)
            layoutParams = LinearLayout.LayoutParams(dp(54), dp(54))
        }

        val channelColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val lp = LinearLayout.LayoutParams(dp(126), ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginStart = dp(12)
            lp.marginEnd = dp(16)
            layoutParams = lp
        }

        val name = TextView(this).apply {
            text = entry.item.name
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 18f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val source = TextView(this).apply {
            text = buildSourceLabel(entry)
            setTextColor(0xFF19E3A8.toInt())
            textSize = 12f
        }
        channelColumn.addView(name)
        channelColumn.addView(source)

        row.addView(logoBox)
        row.addView(channelColumn)

        entry.programs.forEachIndexed { programIndex, program ->
            row.addView(makeProgramCard(program, programIndex == 0))
        }
        row.tag = index
        return row
    }

    private fun buildSourceLabel(entry: GuideEntry): String {
        val base = if (entry.item.source.contains("DVR", ignoreCase = true)) "LIVE • DVR" else "LIVE • IPTV"
        return if (entry.tags.contains("hd")) "$base • HD" else base
    }

    private fun makeProgramCard(program: ProgramBlock, isNow: Boolean): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            background = getDrawable(if (isNow) R.drawable.guide_program_card_selected else R.drawable.guide_program_card)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            val lp = LinearLayout.LayoutParams(dp((program.widthDp - 28).coerceAtLeast(128)), dp(70))
            lp.marginEnd = dp(4)
            layoutParams = lp
        }
        val time = TextView(this).apply {
            text = program.startLabel
            setTextColor(0xFFF1F5FA.toInt())
            textSize = 14f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val title = TextView(this).apply {
            text = program.title
            setTextColor(if (isNow) 0xFFFFFFFF.toInt() else 0xFFC6CCD7.toInt())
            textSize = 14f
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        card.addView(time)
        card.addView(title)

        if (isNow) {
            card.addView(View(this).apply {
                setBackgroundColor(0xFF19E3A8.toInt())
                layoutParams = LinearLayout.LayoutParams((program.widthDp * resources.displayMetrics.density * 0.72f).roundToInt(), dp(3)).apply {
                    topMargin = dp(8)
                }
            })
        }
        return card
    }

    private fun moveSelection(delta: Int) {
        if (filteredChannels.isEmpty()) return
        selectedIndex = (selectedIndex + delta).coerceIn(0, filteredChannels.lastIndex)
        updateSelection(selectedIndex, restartPreview = false)
    }

    private fun moveCategory(delta: Int) {
        if (categories.isEmpty()) return
        selectedCategoryIndex = (selectedCategoryIndex + delta).coerceIn(0, categories.lastIndex)
        applyCategorySelection(selectedCategoryIndex)
        activeZone = FocusZone.CATEGORY
        applyZoneState()
    }

    private fun updateSelection(index: Int, restartPreview: Boolean) {
        if (filteredChannels.isEmpty()) return
        selectedIndex = index.coerceIn(0, filteredChannels.lastIndex)
        val selected = filteredChannels[selectedIndex]
        val channelPrograms = selected.programs

        infoLogo.text = selected.logoText
        infoChannel.text = selected.item.name
        infoGroup.text = "${selected.item.group.ifBlank { categories.getOrNull(selectedCategoryIndex)?.name ?: "All Channels" }} • ${selected.item.source}"
        nowTime.text = "${channelPrograms[0].startLabel} - ${channelPrograms[0].endLabel}"
        nowTitle.text = channelPrograms[0].title
        descriptionView.text = selected.description
        nextLine.text = "NEXT   ${channelPrograms[1].startLabel}  ${channelPrograms[1].title}"
        laterLine.text = "LATER  ${channelPrograms[2].startLabel}  ${channelPrograms[2].title}"
        progressBar.layoutParams = progressBar.layoutParams.apply {
            width = dp((220 + (selectedIndex % 5) * 24).coerceAtMost(340))
        }
        progressBar.requestLayout()
        previewImage.setImageResource(selected.previewRes)
        schedulePreview(selected.item.url, force = restartPreview || previewArmedIndex == selectedIndex)

        for (i in 0 until channelList.childCount) {
            val child = channelList.getChildAt(i) as? LinearLayout ?: continue
            val isSelected = i == selectedIndex
            styleRow(child, isSelected, activeZone == FocusZone.GUIDE && isSelected)
        }
        scrollToSelection(selectedIndex)
    }

    private fun armPreviewForSelection(index: Int) {
        val entry = filteredChannels.getOrNull(index) ?: return
        previewArmedIndex = index
        schedulePreview(entry.item.url, force = true)
    }

    private fun schedulePreview(url: String, force: Boolean = false) {
        if (url.isBlank()) return
        previewRunnable?.let { previewHandler.removeCallbacks(it) }
        val targetUrl = url
        previewRunnable = Runnable {
            playPreviewNow(targetUrl, force)
        }
        previewHandler.postDelayed(previewRunnable!!, if (force) 80L else 280L)
    }

    private fun playPreviewNow(url: String, force: Boolean = false) {
        if (url.isBlank()) return
        if (!force && url == previewUrl) return
        previewUrl = url
        previewImage.alpha = 0.25f
        val mediaItemBuilder = MediaItem.Builder().setUri(Uri.parse(url))
        if (looksLikeTsStream(url)) {
            mediaItemBuilder.setMimeType(MimeTypes.VIDEO_MP2T)
        }
        try {
            previewPlayer?.apply {
                stop()
                clearMediaItems()
                setMediaItem(mediaItemBuilder.build())
                prepare()
                playWhenReady = activeZone == FocusZone.GUIDE
            }
        } catch (_: Exception) {
            previewImage.alpha = 1f
        }
    }

    private fun applyZoneState() {
        styleCategories()
        for (i in 0 until channelList.childCount) {
            val child = channelList.getChildAt(i) as? LinearLayout ?: continue
            val isSelected = i == selectedIndex
            styleRow(child, isSelected, activeZone == FocusZone.GUIDE && isSelected)
        }
        val guideVisible = activeZone == FocusZone.GUIDE
        guideHeaderRow.visibility = if (guideVisible) View.VISIBLE else View.INVISIBLE
        timelineRow.visibility = if (guideVisible) View.VISIBLE else View.INVISIBLE
        horizontalScroll.visibility = if (guideVisible) View.VISIBLE else View.INVISIBLE
        previewFrame.foreground = getDrawable(if (guideVisible) R.drawable.guide_preview_selected else R.drawable.guide_preview_idle)
        previewHint.visibility = View.GONE
        categoryRail.alpha = 1f
        previewPlayer?.playWhenReady = guideVisible
    }

    private fun scrollToSelection(index: Int) {
        val child = channelList.getChildAt(index) ?: return
        verticalScroll.post {
            val target = (child.top - dp(84)).coerceAtLeast(0)
            verticalScroll.smoothScrollTo(0, target)
        }
    }

    private fun styleRow(row: LinearLayout, selected: Boolean, active: Boolean) {
        row.background = getDrawable(if (selected) R.drawable.guide_row_selected else R.drawable.guide_row_bg)
        row.scaleX = if (active) 1.015f else 1f
        row.scaleY = if (active) 1.015f else 1f
        row.alpha = when {
            active -> 1f
            selected -> 0.97f
            else -> 0.82f
        }
    }

    private fun openPlayer(index: Int) {
        val entry = filteredChannels.getOrNull(index) ?: return
        if (entry.item.url.isBlank()) {
            Toast.makeText(this, "This channel has no playable stream yet.", Toast.LENGTH_SHORT).show()
            return
        }
        previewHandler.removeCallbacksAndMessages(null)
        previewPlayer?.playWhenReady = false
        startActivity(
            Intent(this, PlayerActivity::class.java)
                .putExtra(PlayerActivity.EXTRA_STREAM_URL, entry.item.url)
                .putExtra(PlayerActivity.EXTRA_TITLE, entry.item.name)
                .putExtra(PlayerActivity.EXTRA_SOURCE_LABEL, entry.item.source)
                .putExtra(PlayerActivity.EXTRA_DEBUG_LABEL, entry.item.debug)
                .putExtra(PlayerActivity.EXTRA_CHANNEL_INDEX, index)
                .putExtra(PlayerActivity.EXTRA_CHANNELS_JSON, serializeChannels(filteredChannels.map { it.item }))
        )
    }

    private fun serializeChannels(channels: List<LiveSourceResolver.ChannelItem>): String {
        val arr = JSONArray()
        channels.forEach { channel ->
            arr.put(
                JSONObject()
                    .put("name", channel.name)
                    .put("url", channel.url)
                    .put("source", channel.source)
                    .put("debug", channel.debug)
            )
        }
        return arr.toString()
    }

    private fun buildGuideEntry(item: LiveSourceResolver.ChannelItem, index: Int): GuideEntry {
        val seed = item.name.uppercase(Locale.US)
        val tags = mutableSetOf<String>()
        when {
            seed.contains("CNN") || seed.contains("FOX") || seed.contains("MSNBC") || seed.contains("CSPAN") || seed.contains("HLN") -> tags += "news"
            seed.contains("ESPN") || seed.contains("FS") || seed.contains("NFL") || seed.contains("NBA") || seed.contains("GOLF") || seed.contains("CBS") -> tags += "sports"
            seed.contains("AMC") || seed.contains("TNT") || seed.contains("LIFETIME") || seed.contains("TRU") || seed.contains("HBO") || seed.contains("STARZ") -> tags += "movies"
            seed.contains("DISNEY") || seed.contains("NICK") || seed.contains("CARTOON") -> tags += "kids"
            else -> tags += "general"
        }
        if (seed.contains("HD")) tags += "hd"
        if (item.source.contains("DVR", true)) tags += "dvr" else tags += "iptv"

        val descriptor = when {
            tags.contains("news") -> "Live news, breaking updates, and current coverage in the unified ARVIO-style guide."
            tags.contains("movies") -> "Movie and event blocks with polished premium-channel presentation."
            tags.contains("sports") -> "Live sports and studio coverage with upcoming game windows."
            tags.contains("kids") -> "Family and kids programming with lighter schedule blocks."
            else -> "Unified live guide with current, next, and later programming in the ARVIO black glass layout."
        }
        val programs = syntheticProgramsFor(item.name, index)
        val logoText = item.name
            .replace("Channels DVR", "")
            .trim()
            .split(" ", "-", "_")
            .filter { it.isNotBlank() }
            .take(2)
            .joinToString("") { it.take(1).uppercase(Locale.US) }
            .ifBlank { "TV" }
            .take(4)
        val previewPool = listOf(
            R.drawable.bg_wonka,
            R.drawable.bg_dune,
            R.drawable.bg_fallout,
            R.drawable.bg_shogun,
            R.drawable.bg_civilwar,
            R.drawable.bg_halo,
            R.drawable.bg_batman,
            R.drawable.bg_mayor
        )
        return GuideEntry(item, logoText, descriptor, programs, previewPool[index % previewPool.size], tags)
    }

    private fun syntheticProgramsFor(channelName: String, index: Int): List<ProgramBlock> {
        val titlePool = when {
            channelName.contains("TRU", ignoreCase = true) -> listOf("Hoosiers (1986)", "NHL on TNT Face Off", "NHL Hockey")
            channelName.contains("AMC", ignoreCase = true) -> listOf("The Martian (2015)", "National Treasure (2004)", "Movie Bonus Round")
            channelName.contains("LIFETIME", ignoreCase = true) -> listOf("Toni Braxton's Breathe Again", "Mary J. Blige Presents Be Happy", "The Beach House Murders")
            channelName.contains("CNN", ignoreCase = true) -> listOf("CNN News Central", "Inside Politics", "The Lead With Jake Tapper")
            channelName.contains("CSPAN", ignoreCase = true) -> listOf("Washington Journal", "Public Affairs Event", "Floor Debate Replay")
            channelName.contains("A&E", ignoreCase = true) || channelName.contains("AETV", ignoreCase = true) -> listOf("Live PD: Police Patrol", "Live PD: Police Patrol", "Live PD: Police Patrol")
            channelName.contains("HLN", ignoreCase = true) -> listOf("Morning Express", "Weekend Express", "Forensic Files")
            else -> listOf("${channelName} Live", "${channelName} Spotlight", "${channelName} After Hours")
        }
        val times = listOf(
            Triple("12:00 PM", "2:00 PM", 170),
            Triple("2:00 PM", "3:00 PM", 210),
            Triple("3:00 PM", "4:30 PM", 240)
        )
        return titlePool.mapIndexed { i, title ->
            ProgramBlock(title, times[i].first, times[i].second, times[i].third + ((index + i) % 3) * 18)
        }
    }

    private fun addSpacer(parent: LinearLayout, widthDp: Int) {
        parent.addView(SpaceView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(widthDp), 1)
        })
    }

    private fun looksLikeTsStream(url: String): Boolean {
        val lower = url.lowercase(Locale.US)
        return lower.contains("format=ts") || lower.endsWith(".ts") || lower.endsWith(".mpg")
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    data class GuideEntry(
        val item: LiveSourceResolver.ChannelItem,
        val logoText: String,
        val description: String,
        val programs: List<ProgramBlock>,
        val previewRes: Int,
        val tags: Set<String>
    )

    data class ProgramBlock(
        val title: String,
        val startLabel: String,
        val endLabel: String,
        val widthDp: Int
    )

    data class CategoryFilter(
        val name: String,
        val count: Int = 0,
        val matcher: (GuideEntry) -> Boolean
    )

    enum class FocusZone { CATEGORY, GUIDE }

    private class SpaceView(context: android.content.Context) : View(context)
}
