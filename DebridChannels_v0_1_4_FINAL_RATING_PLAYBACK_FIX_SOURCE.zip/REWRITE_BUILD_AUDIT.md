# Rewrite Build Audit — v0.1.4 Final Rating + Playback Fix

Base used: stable v0.0.1 visual/card baseline with clean consolidation of resolver/playback changes.

Rule followed: clean rewrite/consolidation from known-good stable base. Broken later generated builds were not used as the source base.

Version:
- versionCode: 14
- versionName: 0.1.4
- visible marker: DC_V0_1_4_FINAL_RATING_PLAYBACK_FIX_ACTIVE
- logcat marker: DC_V0_1_4_FINAL_RATING_PLAYBACK_FIX_ACTIVE

Preserved:
- Stable row navigation and active row viewport behavior.
- Centered card logos and clipped landscape cards.
- Hero artwork and IMDb/TMDB badge placement.
- Pro Layout Editor/settings surfaces.
- Default backend URL: http://192.168.100.55:8181

Changed:
- Ratings are locked/cached by IMDb ID/title and stream loading no longer overwrites metadata.
- Added one-time Cinemeta rating fill for IMDb IDs when backend rows do not provide ratings.
- Stream list tries selected links first and supports Stremio HTTP/external/magnet entries without prematurely opening a fake player.
- Media3 ExoPlayer remains the VOD playback target and Real-Debrid HTTP unrestrict is attempted when configured.
