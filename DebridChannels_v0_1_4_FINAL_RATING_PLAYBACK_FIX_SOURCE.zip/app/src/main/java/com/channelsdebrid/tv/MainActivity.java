package com.channelsdebrid.tv;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import android.widget.*;
import android.net.Uri;
import android.text.InputType;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

import com.channelsdebrid.tv.core.*;
import com.channelsdebrid.tv.player.*;
import com.channelsdebrid.tv.livetv.*;
import com.channelsdebrid.tv.cache.*;
import com.channelsdebrid.tv.layout.*;
import com.channelsdebrid.tv.backend.*;
import com.channelsdebrid.tv.stremio.*;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.common.PlaybackException;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class MainActivity extends Activity {
    FrameLayout root;
    NavigationController nav;
    PlayerManager player;
    LiveTvStateMachine live;
    GuideCacheOwner guideCache;
    TimeshiftEngine timeshift;
    UiStateStore ui;
    BackendConfig backend;
    StremioAddonRegistry stremio;
    LinearLayout heroMenu;
    final ArrayList<View> menuItems = new ArrayList<>();
    final ArrayList<HomeRow> homeRows = new ArrayList<>();
    final ArrayList<LinearLayout> rowLists = new ArrayList<>();
    final ArrayList<HorizontalScrollView> rowScrolls = new ArrayList<>();
    final ArrayList<TextView> rowTitleViews = new ArrayList<>();
    final ArrayList<Movie> movies = new ArrayList<>();
    final ArrayList<Channel> channels = new ArrayList<>();
    ImageView heroBackdropImage, heroLogoImage, heroBannerImage;
    ScrollView editorScroll;
    TextView heroTitle, heroDesc, heroMeta;
    LinearLayout heroRatingRow;
    boolean suppressRowAutoFocus = false;
    int activeRowIndex = 0;
    final Handler heroHandler = new Handler(Looper.getMainLooper());
    Runnable pendingHeroRunnable;
    final Map<String, Bitmap> imageCache = Collections.synchronizedMap(new LinkedHashMap<String, Bitmap>(64, .75f, true){protected boolean removeEldestEntry(Map.Entry<String,Bitmap> e){return size()>80;}});
    final ExecutorService imageExecutor = Executors.newFixedThreadPool(3);
    final Set<String> failedArtworkUrls = Collections.synchronizedSet(new HashSet<String>());
    final Map<String, String[]> ratingCache = Collections.synchronizedMap(new HashMap<String, String[]>());
    ExoPlayer exoPlayer;
    SelectedMedia selectedMedia;

    static class Movie {
        String id = "", type = "movie", title = "Untitled", meta = "", url = "";
        String poster = "", background = "", logo = "", banner = "", overview = "", year = "", tag = "FEATURED", imdbRating = "", tmdbRating = "";
        Movie(String title, String meta, String url) { this.title = title; this.meta = meta; this.url = url; }
    }
    static class SelectedMedia { Movie movie; ArrayList<StreamLink> streams = new ArrayList<>(); SelectedMedia(Movie m){movie=m;} }
    static class StreamLink { String name="Stream", title="", description="", quality="", size="", source="Stremio", url=""; boolean external=false; boolean playable(){return url!=null && (url.startsWith("http://")||url.startsWith("https://"));}
        boolean needsResolver(){ if(url==null)return true; String u=url.toLowerCase(Locale.US); return u.startsWith("magnet:")||u.startsWith("torrent:")||u.endsWith(".torrent"); } }
    static class HomeRow { String id = "", title = "Catalog"; ArrayList<Movie> items = new ArrayList<>(); HomeRow(String title){this.title=title;} }
    static class Channel { String name, group, url, logo; Channel(String n,String g,String u,String l){name=n;group=g;url=u;logo=l;} }

    class CardFrame extends FrameLayout {
        final Path clipPath = new Path();
        final RectF rect = new RectF();
        float radius;
        CardFrame(Context context, float r) { super(context); radius = r; setWillNotDraw(false); }
         protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            clipPath.reset(); rect.set(0, 0, w, h);
            clipPath.addRoundRect(rect, radius, radius, Path.Direction.CW); clipPath.close();
        }
         public void draw(Canvas canvas) {
            int save = canvas.save();
            canvas.clipPath(clipPath);
            super.draw(canvas);
            canvas.restoreToCount(save);
        }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        nav = new NavigationController();
        player = new PlayerManager(this);
        live = new LiveTvStateMachine();
        guideCache = new GuideCacheOwner(this);
        timeshift = new TimeshiftEngine(this);
        ui = new UiStateStore(this);
        backend = new BackendConfig(this);
        stremio = new StremioAddonRegistry(this);
        seedFallback();
        root = new FrameLayout(this);
        setContentView(root);
        AppLogger.mark("BOOT " + BuildMarkers.LOG_MARKER + " backend=" + backend.baseUrl());
        showHome();
        loadBackendHomeRows();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        try { if(exoPlayer!=null){exoPlayer.release();exoPlayer=null;} } catch(Exception ignored) {}
        try { imageExecutor.shutdownNow(); } catch(Exception ignored) {}
    }

    void seedFallback() {
        movies.clear(); homeRows.clear(); channels.clear();
        Movie a = new Movie("Project Hail Mary", "2026 • FEATURED • IMDB 8.2 • TMDB 7.0", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4");
        a.year="2026"; a.imdbRating="8.2"; a.tmdbRating="7.0"; a.overview="Focus a card to update the cinematic background, logo/title layer, metadata, poster row and future banner/3D art slot."; movies.add(a);
        Movie b = new Movie("The Mummy", "1999 • 4K • Adventure • 7.1", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4");
        b.year="1999"; b.imdbRating="7.1"; b.tmdbRating="7.2"; b.overview="Artwork comes from the backend first: poster, background, logo and banner fields. The app does not require a TMDB key."; movies.add(b);
        Movie c = new Movie("The Super Mario Galaxy Movie", "2026 • Family • 8.0", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4");
        c.year="2026"; c.imdbRating="8.0"; c.tmdbRating="7.6"; c.overview="Each Stremio addon catalog can become a row. Settings will control hide, rename and reorder without changing the clean core."; movies.add(c);
        Movie d = new Movie("Avatar", "2009 • 4K • Sci-Fi", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4");
        d.year="2009"; d.overview="The right-side Banner area is preserved as the extra artwork layer for clearlogo, disc/DVD, character and future 3D pop art."; movies.add(d);
        HomeRow row = new HomeRow("Trending Movies"); row.items.addAll(movies); homeRows.add(row);
        channels.add(new Channel("Sample Live Channel", "Favorites", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4", ""));
        channels.add(new Channel("Movies 24/7", "Movies", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4", ""));
        channels.add(new Channel("Demo Sports", "Sports", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4", ""));
    }

    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);} 
    void clear(){root.removeAllViews();menuItems.clear();rowLists.clear();rowScrolls.clear();rowTitleViews.clear();}
    GradientDrawable bg(int c,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    GradientDrawable stroke(int c,int s){GradientDrawable g=bg(c,26);g.setStroke(dp(1),s);return g;}
    TextView tv(String x,int sp,int style){TextView t=new TextView(this);t.setText(x);t.setTextColor(Color.WHITE);t.setTextSize(sp);t.setTypeface(Typeface.DEFAULT,style);t.setGravity(Gravity.CENTER);return t;}

    void backdrop(){
        heroBackdropImage = new ImageView(this);
        heroBackdropImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        heroBackdropImage.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(115,80,28),Color.rgb(23,28,42),Color.rgb(1,3,8)}));
        root.addView(heroBackdropImage,new FrameLayout.LayoutParams(-1,-1));
        View tone = new View(this); tone.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.argb(120,120,72,14),Color.argb(70,20,28,46),Color.argb(155,0,0,0)})); root.addView(tone,new FrameLayout.LayoutParams(-1,-1));
        View side = new View(this); side.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.argb(240,0,0,0),Color.argb(155,0,0,0),Color.argb(35,0,0,0)})); root.addView(side,new FrameLayout.LayoutParams(-1,-1));
        View bottom = new View(this); bottom.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,new int[]{Color.argb(245,0,0,0),Color.TRANSPARENT})); root.addView(bottom,new FrameLayout.LayoutParams(-1,dp(400),Gravity.BOTTOM));
    }

    TextView btn(String x){TextView v=tv(x,16,Typeface.BOLD);v.setFocusable(true);v.setPadding(dp(18),0,dp(18),0);v.setBackground(bg(Color.argb(0,0,0,0),18));v.setOnFocusChangeListener((a,h)->focus((TextView)a,h));return v;}
    void focus(TextView a,boolean h){a.animate().scaleX(h?1.08f:1f).scaleY(h?1.08f:1f).setDuration(130).start();a.setBackground(h?bg(Color.argb(165,21,57,88),0):bg(Color.argb(0,0,0,0),0));}

    void addMenu(){
        heroMenu=new LinearLayout(this);heroMenu.setGravity(Gravity.CENTER);heroMenu.setPadding(dp(8),0,dp(8),0);
        String ip=ui.iconPlacement();ArrayList<String> labels=new ArrayList<>();
        if(ip.equals("left")){labels.add("⌕");labels.add("⚙");}
        if(ip.equals("inline"))Collections.addAll(labels,"Home","Live TV","Movies","Shows","Settings","⌕","⚙"); else Collections.addAll(labels,"Home","Live TV","Movies","Shows","Settings");
        if(ip.equals("right")){labels.add("⌕");labels.add("⚙");}
        for(String s:labels){
            TextView m=btn(s);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(48));lp.setMargins(dp(5),0,dp(5),0);heroMenu.addView(m,lp);menuItems.add(m);
            m.setOnClickListener(v->{String z=((TextView)v).getText().toString();if(z.equals("Live TV"))showLiveTv();else if(z.equals("Movies")||z.equals("Shows"))showCatalogs(z);else if(z.equals("Settings")||z.equals("⚙"))showSettings();else if(z.equals("⌕"))showSearch();else showHome();});
            m.setOnKeyListener((v,key,event)->{if(event.getAction()!=KeyEvent.ACTION_DOWN)return false;int pos=menuItems.indexOf(v);if(key==KeyEvent.KEYCODE_DPAD_RIGHT){menuItems.get((pos+1)%menuItems.size()).requestFocus();return true;}if(key==KeyEvent.KEYCODE_DPAD_LEFT){menuItems.get((pos-1+menuItems.size())%menuItems.size()).requestFocus();return true;}if(key==KeyEvent.KEYCODE_DPAD_DOWN){focusRowCard(0,0);return true;}return false;});
        }
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(dp(650),dp(58));hp.topMargin=dp(20);hp.leftMargin=dp(ui.topMenuOffsetDp());String pos=ui.menuPosition();hp.gravity=Gravity.TOP|(pos.equals("left")?Gravity.LEFT:pos.equals("right")?Gravity.RIGHT:Gravity.CENTER_HORIZONTAL);root.addView(heroMenu,hp);
    }

    void showHome(){
        clear();nav.go(NavigationController.Screen.HOME);backdrop();addMenu();
        heroLogoImage=new ImageView(this);heroLogoImage.setScaleType(ImageView.ScaleType.FIT_CENTER);heroLogoImage.setAdjustViewBounds(true);FrameLayout.LayoutParams lpLogo=new FrameLayout.LayoutParams(dp(430),dp(96));lpLogo.leftMargin=dp(22+ui.heroTextLeftDp());lpLogo.topMargin=dp(86+ui.heroTextTopDp());root.addView(heroLogoImage,lpLogo);
        heroTitle=tv("Debrid\nChannels",42,Typeface.BOLD);heroTitle.setGravity(Gravity.LEFT);heroTitle.setIncludeFontPadding(false);FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(dp(680),dp(112));tp.leftMargin=dp(22+ui.heroTextLeftDp());tp.topMargin=dp(92+ui.heroTextTopDp());root.addView(heroTitle,tp);
        heroMeta=tv("",17,Typeface.BOLD);heroMeta.setVisibility(View.GONE);heroRatingRow=new LinearLayout(this);heroRatingRow.setOrientation(LinearLayout.HORIZONTAL);heroRatingRow.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(dp(760),dp(42));mp.leftMargin=dp(22+ui.heroTextLeftDp());mp.topMargin=dp(184+ui.heroTextTopDp());root.addView(heroRatingRow,mp);
        heroDesc=tv("Backend catalog artwork is loading. Focus a row card to update the full-screen background, logo/title layer, metadata and extra-art slot.",18,Typeface.BOLD);heroDesc.setGravity(Gravity.LEFT);FrameLayout.LayoutParams dpv=new FrameLayout.LayoutParams(dp(780),dp(120));dpv.leftMargin=dp(22+ui.heroTextLeftDp());dpv.topMargin=dp(222+ui.heroTextTopDp());root.addView(heroDesc,dpv);
        heroBannerImage=new ImageView(this);heroBannerImage.setScaleType(ImageView.ScaleType.FIT_CENTER);heroBannerImage.setBackground(bg(Color.argb(0,0,0,0),0));heroBannerImage.setAlpha(ui.extraArtworkOpacityPercent()/100f);FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(ui.extraArtworkWidthDp()),dp(ui.extraArtworkHeightDp()));bp.leftMargin=dp(ui.extraArtworkXdp());bp.topMargin=dp(ui.extraArtworkYdp());root.addView(heroBannerImage,bp);
        addHeroRows(); addBuildMarker(); if(!movies.isEmpty())updateHero(movies.get(0));
    }
    void addBuildMarker(){TextView marker=tv("DC_V0_1_4_FINAL_RATING_PLAYBACK_FIX_ACTIVE",11,Typeface.BOLD);marker.setTextColor(Color.argb(150,255,255,255));marker.setGravity(Gravity.RIGHT|Gravity.BOTTOM);FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(dp(360),dp(28),Gravity.RIGHT|Gravity.BOTTOM);mp.rightMargin=dp(18);mp.bottomMargin=dp(10);root.addView(marker,mp);}

    GradientDrawable cardBg(int a){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.argb(55,18,26,36),Color.argb(70,5,8,14)});g.setCornerRadius(dp(ui.cornerRadiusDp()));g.setStroke(0,Color.TRANSPARENT);return g;}
    GradientDrawable focusedCardBg(){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.argb(76,25,32,44),Color.argb(90,6,10,18)});g.setCornerRadius(dp(ui.cornerRadiusDp()));g.setStroke(dp(Math.max(1,ui.focusRingThicknessDp())),Color.argb(120,255,255,255));return g;}
    void addHeroRows(){
        rowLists.clear();rowScrolls.clear();rowTitleViews.clear();
        int top=ui.rowTopDp();
        int max=Math.min(6,homeRows.size());
        activeRowIndex=Math.max(0,Math.min(activeRowIndex,Math.max(0,max-1)));
        for(int ri=0;ri<max;ri++)addHeroRow(homeRows.get(ri),top);
        updateActiveRowViewport(false);
    }
    void addHeroRow(HomeRow sourceRow,int topDp){
        TextView rt=null;
        if(ui.rowTitleVisibility()==1){rt=tv((ui.rowTitleIconsEnabled()==1?"▸ ":"")+sourceRow.title,22,Typeface.BOLD);rt.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);FrameLayout.LayoutParams rtp=new FrameLayout.LayoutParams(dp(700),dp(44));rtp.leftMargin=dp(38+ui.rowLeftDp());rtp.topMargin=dp(topDp-45);root.addView(rt,rtp);}        
        final HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);hsv.setClipToPadding(false);hsv.setSmoothScrollingEnabled(true);hsv.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);int sidePad=dp(28+ui.rowLeftDp());hsv.setPadding(sidePad,0,dp(320),0);FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(Math.max(190, ui.cardHeightDp()+78)));hp.topMargin=dp(topDp);root.addView(hsv,hp);
        final LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);hsv.addView(row,new HorizontalScrollView.LayoutParams(-2,-1));
        final int rowIndex=rowLists.size();rowLists.add(row);rowScrolls.add(hsv);rowTitleViews.add(rt);
        int maxCards=Math.min(sourceRow.items.size(), Math.max(12, ui.previewCardCount()*4));
        for(int i=0;i<maxCards;i++){final Movie movie=sourceRow.items.get(i);CardFrame card=new CardFrame(this,dp(ui.cornerRadiusDp()));card.setFocusable(true);card.setPadding(0,0,0,0);card.setBackground(cardBg(215));if(Build.VERSION.SDK_INT>=21)card.setElevation(dp(3));
            ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);img.setBackgroundColor(Color.TRANSPARENT);card.addView(img,new FrameLayout.LayoutParams(-1,-1));String art=rowArtwork(movie);if(!art.isEmpty())loadImage(art,img,false);else img.setImageDrawable(null);
            ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);logo.setAdjustViewBounds(true);logo.setAlpha(.98f);logo.setBackgroundColor(Color.TRANSPARENT);FrameLayout.LayoutParams lpLogoCard=new FrameLayout.LayoutParams(dp(Math.max(120,ui.cardWidthDp()-86)),dp(Math.max(48,ui.cardHeightDp()/2)),Gravity.CENTER);card.addView(logo,lpLogoCard);String cardLogoUrl=cardLogoArtwork(movie);if(isSafeCardLogo(cardLogoUrl)){logo.setVisibility(View.VISIBLE);loadImage(cardLogoUrl,logo,false);}else {logo.setImageDrawable(null);logo.setVisibility(View.GONE);}
            card.setOnKeyListener((v,key,event)->{if(event.getAction()!=KeyEvent.ACTION_DOWN)return false;int pos=Math.max(0,row.indexOfChild(v));if(key==KeyEvent.KEYCODE_DPAD_RIGHT&&pos<row.getChildCount()-1){View next=row.getChildAt(pos+1);next.requestFocus();centerSnap(hsv,next);AppLogger.mark("ROW_NAV right row="+rowIndex+" col="+(pos+1));return true;}if(key==KeyEvent.KEYCODE_DPAD_LEFT&&pos>0){View prev=row.getChildAt(pos-1);prev.requestFocus();centerSnap(hsv,prev);AppLogger.mark("ROW_NAV left row="+rowIndex+" col="+(pos-1));return true;}if(key==KeyEvent.KEYCODE_DPAD_DOWN){focusRowCard(rowIndex+1,pos);return true;}if(key==KeyEvent.KEYCODE_DPAD_UP){focusRowCard(rowIndex-1,pos);return true;}return false;});
            card.setOnFocusChangeListener((v,h)->{float scale=h?Math.max(1f,ui.focusedScalePercent()/100f):1f;v.animate().scaleX(scale).scaleY(scale).translationY(h?-dp(10):0).setDuration(190).start();if(Build.VERSION.SDK_INT>=21)v.setElevation(h?dp(18):dp(3));v.setBackground(h?focusedCardBg():cardBg(215));if(h){activeRowIndex=rowIndex;updateActiveRowViewport(false);scheduleHeroUpdate(movie);v.postDelayed(()->centerSnap(hsv,v),40);}});
            card.setOnClickListener(v->showMovieDetails(movie));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(ui.cardWidthDp()),dp(ui.cardHeightDp()));cp.setMargins(0,dp(18),dp(ui.cardSpacingDp()),0);row.addView(card,cp);
        }
        hsv.postDelayed(()->{if(!suppressRowAutoFocus && rowIndex==0 && row.getChildCount()>0){View start=row.getChildAt(0);start.requestFocus();centerSnap(hsv,start);}},140);
    }
    void focusRowCard(int rowIndex,int colIndex){
        AppLogger.mark("ROW_NAV request row="+rowIndex+" col="+colIndex+" rows="+rowLists.size());
        if(rowIndex<0){ if(!menuItems.isEmpty())menuItems.get(0).requestFocus(); return; }
        if(rowIndex>=rowLists.size()){ AppLogger.mark("ROW_NAV ignored: no target row"); return; }
        LinearLayout row=rowLists.get(rowIndex);
        if(row==null||row.getChildCount()==0){ AppLogger.mark("ROW_NAV ignored: empty row "+rowIndex); return; }
        int target=Math.max(0,Math.min(colIndex,row.getChildCount()-1));
        View card=row.getChildAt(target);
        activeRowIndex=rowIndex;
        updateActiveRowViewport(true);
        card.postDelayed(()->{ card.requestFocus(); if(rowIndex<rowScrolls.size())centerSnap(rowScrolls.get(rowIndex),card); AppLogger.mark("ROW_NAV focused row="+rowIndex+" col="+target); },70);
    }
    void updateActiveRowViewport(boolean animate){
        for(int i=0;i<rowScrolls.size();i++){
            boolean active=(i==activeRowIndex);
            HorizontalScrollView hsv=rowScrolls.get(i);
            TextView title=i<rowTitleViews.size()?rowTitleViews.get(i):null;
            hsv.setVisibility(active?View.VISIBLE:View.INVISIBLE);
            hsv.setFocusable(active);
            hsv.setFocusableInTouchMode(active);
            hsv.setEnabled(active);
            hsv.setAlpha(active?1f:0f);
            hsv.setTranslationY(0f);
            if(title!=null){title.setVisibility(active?View.VISIBLE:View.INVISIBLE);title.setAlpha(active?1f:0f);}
        }
    }
    void centerSnap(HorizontalScrollView hsv,View card){int target=card.getLeft()+card.getWidth()/2-getResources().getDisplayMetrics().widthPixels/2;hsv.smoothScrollTo(Math.max(0,target),0);}
    void scheduleHeroUpdate(Movie m){
        if(pendingHeroRunnable!=null)heroHandler.removeCallbacks(pendingHeroRunnable);
        pendingHeroRunnable=()->updateHero(m);
        heroHandler.postDelayed(pendingHeroRunnable,210);
    }


    TextView metaText(String text,int color,int style){TextView t=tv(text,16,style);t.setGravity(Gravity.CENTER_VERTICAL);t.setTextColor(color);t.setIncludeFontPadding(false);return t;}
    TextView badge(String text,int bgColor,int textColor){TextView t=tv(text,14,Typeface.BOLD);t.setTextColor(textColor);t.setIncludeFontPadding(false);t.setGravity(Gravity.CENTER);t.setPadding(dp(9),0,dp(9),0);t.setBackground(bg(bgColor,7));return t;}
    void addMetaPiece(LinearLayout row,View v,int w,int h,int leftMargin){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(w<0?w:dp(w),dp(h));lp.setMargins(dp(leftMargin),0,0,0);row.addView(v,lp);}
    void buildHeroRatingRow(Movie m){
        if(heroRatingRow==null)return; heroRatingRow.removeAllViews();
        String y=first(m.year,extractYear(m.meta));
        if(!y.isEmpty())addMetaPiece(heroRatingRow,metaText(y,Color.rgb(255,220,56),Typeface.BOLD),-2,30,0);
        addMetaPiece(heroRatingRow,metaText("•",Color.WHITE,Typeface.BOLD),-2,30,12);
        addMetaPiece(heroRatingRow,metaText(first(m.tag,"FEATURED").toUpperCase(Locale.US),Color.WHITE,Typeface.BOLD),-2,30,12);
        String imdb=first(m.imdbRating,extractRating(m.meta,"IMDB"),extractRating(m.meta,"IMDb"));
        if(!imdb.isEmpty()){addMetaPiece(heroRatingRow,badge("IMDb",Color.rgb(245,197,24),Color.BLACK),58,24,20);addMetaPiece(heroRatingRow,metaText(imdb,Color.WHITE,Typeface.NORMAL),-2,30,8);}
        String tmdb=first(m.tmdbRating,extractRating(m.meta,"TMDB"));
        if(!tmdb.isEmpty()){addMetaPiece(heroRatingRow,metaText("|",Color.argb(210,255,255,255),Typeface.NORMAL),-2,30,14);addMetaPiece(heroRatingRow,badge("TMDB",Color.rgb(1,180,228),Color.WHITE),62,24,14);addMetaPiece(heroRatingRow,metaText(tmdb,Color.WHITE,Typeface.NORMAL),-2,30,8);}
    }
    String extractYear(String meta){if(meta==null)return "";java.util.regex.Matcher m=java.util.regex.Pattern.compile("(19|20)\\d{2}").matcher(meta);return m.find()?m.group():"";}
    String extractRating(String meta,String key){if(meta==null)return "";int i=meta.toUpperCase(Locale.US).indexOf(key.toUpperCase(Locale.US));if(i<0)return "";java.util.regex.Matcher m=java.util.regex.Pattern.compile("([0-9](?:\\.[0-9])?)").matcher(meta.substring(i));return m.find()?m.group(1):"";}


    void lockRatings(Movie m){
        if(m==null)return;
        String imdbId=first(m.id,extractImdbId(m.meta));
        String key=first(imdbId,m.title);
        String imdb=first(m.imdbRating,extractRating(m.meta,"IMDB"),extractRating(m.meta,"IMDb"));
        String tmdb=first(m.tmdbRating,extractRating(m.meta,"TMDB"),extractRating(m.meta,"TMDb"));
        String[] cached=ratingCache.get(key);
        if(imdb.isEmpty()&&cached!=null)imdb=cached[0];
        if(tmdb.isEmpty()&&cached!=null)tmdb=cached[1];
        if(!imdb.isEmpty()||!tmdb.isEmpty())ratingCache.put(key,new String[]{imdb,tmdb});
        m.imdbRating=imdb==null?"":imdb;
        m.tmdbRating=tmdb==null?"":tmdb;
        if((m.id==null||m.id.isEmpty())&&!imdbId.isEmpty())m.id=imdbId;
    }

    void updateHero(Movie m){
        lockRatings(m);
        fetchMissingRatingsOnce(m);
        if(heroTitle!=null){heroTitle.setText(m.title.replace(" ","\n"));heroTitle.setVisibility((m.logo!=null&&!m.logo.isEmpty())?View.INVISIBLE:View.VISIBLE);} 
        if(heroMeta!=null)heroMeta.setText((m.meta==null||m.meta.isEmpty()?m.year:m.meta));
        buildHeroRatingRow(m);
        if(heroDesc!=null)heroDesc.setText(m.overview==null||m.overview.isEmpty()?"Focused card updates background, logo, banner and metadata from backend artwork fields.":m.overview);
        if(heroBackdropImage!=null)loadImage(first(m.background,m.poster),heroBackdropImage,true);
        if(heroLogoImage!=null){ if(m.logo!=null&&!m.logo.isEmpty())loadImage(m.logo,heroLogoImage,true); else heroLogoImage.setImageDrawable(null);}
        if(heroBannerImage!=null){String extra=first(m.banner,m.logo); if(extra.isEmpty()){heroBannerImage.setImageDrawable(null);heroBannerImage.setAlpha(0f);} else {heroBannerImage.setAlpha(ui.extraArtworkOpacityPercent()/100f);loadImage(extra,heroBannerImage,true);}}
    }
    String first(String...v){for(String x:v)if(x!=null&&!x.trim().isEmpty())return x.trim();return "";}
    boolean looksPortraitOrLogo(String u){
        if(u==null)return true;
        String x=u.trim().toLowerCase(Locale.US);
        if(x.isEmpty())return true;
        return x.contains("/poster/")||x.contains("poster")||x.contains("portrait")||x.contains("thumbnail")||x.contains("thumb")||x.contains("/logo/")||x.contains("clearlogo")||x.contains("clear_logo")||x.contains("clear-logo");
    }
    boolean isSafeCardLogo(String u){
        if(u==null)return false;
        String x=u.trim().toLowerCase(Locale.US);
        if(x.isEmpty())return false;
        if(x.contains("poster")||x.contains("background")||x.contains("backdrop")||x.contains("thumbnail")||x.contains("thumb")||x.contains("portrait")||x.contains("landscape")||x.contains("banner"))return false;
        return x.contains("/logo/")||x.contains("clearlogo")||x.contains("clear_logo")||x.contains("clear-logo")||x.contains("fanart.tv/fanart/");
    }
    String cardLogoArtwork(Movie m){
        if(m==null)return "";
        if(isSafeCardLogo(m.logo))return m.logo.trim();
        if(m.id!=null && m.id.trim().startsWith("tt"))return "https://images.metahub.space/logo/medium/"+m.id.trim()+"/img";
        return "";
    }
    String rowArtwork(Movie m){
        if(m==null)return "";
        if(m.banner!=null&&!m.banner.trim().isEmpty()&&!looksPortraitOrLogo(m.banner))return m.banner.trim();
        if(m.background!=null&&!m.background.trim().isEmpty()&&!looksPortraitOrLogo(m.background))return m.background.trim();
        return "";
    }

    final Set<String> ratingFetchInFlight = Collections.synchronizedSet(new HashSet<String>());
    void fetchMissingRatingsOnce(Movie m){
        if(m==null)return;
        if(!first(m.imdbRating,m.tmdbRating).isEmpty())return;
        String id=first(m.id,extractImdbId(m.meta));
        if(id.isEmpty()||!id.startsWith("tt")||ratingFetchInFlight.contains(id))return;
        ratingFetchInFlight.add(id);
        new Thread(()->{
            try{
                String txt=httpGet("https://v3-cinemeta.strem.io/meta/movie/"+URLEncoder.encode(id,"UTF-8")+".json");
                JSONObject obj=new JSONObject(txt).optJSONObject("meta");
                if(obj==null)return;
                String imdb=ratingFrom(obj,"imdbRating","imdb_rating","imdbScore","imdb");
                String tmdb=ratingFrom(obj,"tmdbRating","tmdb_rating","tmdbScore","tmdb","vote_average");
                if(!imdb.isEmpty()||!tmdb.isEmpty()){
                    runOnUiThread(()->{
                        if(m.imdbRating.isEmpty())m.imdbRating=imdb;
                        if(m.tmdbRating.isEmpty())m.tmdbRating=tmdb;
                        lockRatings(m);
                        if(heroRatingRow!=null)buildHeroRatingRow(m);
                    });
                }
            }catch(Exception e){AppLogger.mark("Cinemeta rating fill skipped: "+e.getMessage());}
        }).start();
    }

    void showCatalogs(String type){suppressRowAutoFocus=false;clear();nav.go(NavigationController.Screen.VOD);backdrop();addMenu();TextView h=tv(type,38,Typeface.BOLD);h.setGravity(Gravity.LEFT);FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(dp(500),dp(60));hp.leftMargin=dp(55);hp.topMargin=dp(115);root.addView(h,hp);addHeroRows();}

    void showMovieDetails(Movie m){
        suppressRowAutoFocus=false; lockRatings(m); selectedMedia = new SelectedMedia(m);
        clear();backdrop();addMenu();updateHero(m);
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.HORIZONTAL);panel.setGravity(Gravity.CENTER_VERTICAL);panel.setPadding(dp(56),dp(110),dp(56),dp(40));
        FrameLayout.LayoutParams ppnl=new FrameLayout.LayoutParams(-1,dp(520));ppnl.topMargin=dp(80);root.addView(panel,ppnl);
        CardFrame posterFrame=new CardFrame(this,dp(18));posterFrame.setBackground(cardBg(230));
        ImageView poster=new ImageView(this);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);posterFrame.addView(poster,new FrameLayout.LayoutParams(-1,-1));String posterUrl=first(m.poster,m.background);if(!posterUrl.isEmpty())loadImage(posterUrl,poster,false);
        LinearLayout.LayoutParams pflp=new LinearLayout.LayoutParams(dp(250),dp(370));pflp.setMargins(0,0,dp(38),0);panel.addView(posterFrame,pflp);
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);panel.addView(info,new LinearLayout.LayoutParams(0,-1,1));
        ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);String lg=cardLogoArtwork(m);if(isSafeCardLogo(lg)){loadImage(lg,logo,false);info.addView(logo,new LinearLayout.LayoutParams(dp(520),dp(120)));}else{TextView title=tv(m.title,42,Typeface.BOLD);title.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);info.addView(title,new LinearLayout.LayoutParams(-1,dp(90)));}
        LinearLayout ratings=new LinearLayout(this);ratings.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);ratings.setOrientation(LinearLayout.HORIZONTAL);info.addView(ratings,new LinearLayout.LayoutParams(-1,dp(42)));buildRatingRowInto(ratings,m,true);
        TextView desc=tv(first(m.overview,"Select Play to load Stremio addon streams for this title."),18,Typeface.NORMAL);desc.setGravity(Gravity.LEFT|Gravity.TOP);desc.setLineSpacing(dp(2),1.02f);desc.setAlpha(.92f);info.addView(desc,new LinearLayout.LayoutParams(dp(720),dp(130)));
        LinearLayout buttons=new LinearLayout(this);buttons.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);info.addView(buttons,new LinearLayout.LayoutParams(-1,dp(76)));
        TextView play=btn("▶ Play / Select Streams");TextView back=btn("Back");buttons.addView(play,new LinearLayout.LayoutParams(dp(310),dp(58)));LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(dp(150),dp(58));blp.setMargins(dp(16),0,0,0);buttons.addView(back,blp);
        play.setOnClickListener(v->showStreamList(m));back.setOnClickListener(v->showHome());play.requestFocus();
    }

    void buildRatingRowInto(LinearLayout row, Movie m, boolean includeTag){
        row.removeAllViews(); String y=first(m.year,extractYear(m.meta));
        if(!y.isEmpty())addMetaPiece(row,metaText(y,Color.rgb(255,220,56),Typeface.BOLD),-2,30,0);
        if(includeTag){addMetaPiece(row,metaText("•",Color.WHITE,Typeface.BOLD),-2,30,12);addMetaPiece(row,metaText(first(m.tag,"FEATURED").toUpperCase(Locale.US),Color.WHITE,Typeface.BOLD),-2,30,12);}
        String imdb=first(m.imdbRating,extractRating(m.meta,"IMDB"),extractRating(m.meta,"IMDb"));
        if(!imdb.isEmpty()){addMetaPiece(row,badge("IMDb",Color.rgb(245,197,24),Color.BLACK),58,24,20);addMetaPiece(row,metaText(imdb,Color.WHITE,Typeface.NORMAL),-2,30,8);}
        String tmdb=first(m.tmdbRating,extractRating(m.meta,"TMDB"));
        if(!tmdb.isEmpty()){addMetaPiece(row,metaText("|",Color.argb(210,255,255,255),Typeface.NORMAL),-2,30,14);addMetaPiece(row,badge("TMDB",Color.rgb(1,180,228),Color.WHITE),62,24,14);addMetaPiece(row,metaText(tmdb,Color.WHITE,Typeface.NORMAL),-2,30,8);}
    }

    void showStreamList(Movie m){
        lockRatings(m); selectedMedia = new SelectedMedia(m); clear();backdrop();addMenu();updateHero(m);
        LinearLayout p=form("Select stream"); TextView sub=tv("Loading Stremio addon links for " + m.title + "…",18,Typeface.NORMAL);sub.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);p.addView(sub,new LinearLayout.LayoutParams(-1,dp(54)));
        new Thread(()->{ArrayList<StreamLink> links=loadStremioStreams(m);runOnUiThread(()->renderStreamList(m,links));}).start();
    }

    void renderStreamList(Movie m, ArrayList<StreamLink> links){
        lockRatings(m); selectedMedia = new SelectedMedia(m); selectedMedia.streams.addAll(links); clear();backdrop();addMenu();updateHero(m);
        LinearLayout p=form("Select stream"); LinearLayout head=new LinearLayout(this);head.setOrientation(LinearLayout.VERTICAL);head.setPadding(0,0,0,dp(8));p.addView(head,new LinearLayout.LayoutParams(-1,dp(112)));
        TextView title=tv(m.title,28,Typeface.BOLD);title.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);head.addView(title,new LinearLayout.LayoutParams(-1,dp(48)));
        LinearLayout ratingLine=new LinearLayout(this);ratingLine.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);head.addView(ratingLine,new LinearLayout.LayoutParams(-1,dp(38)));buildRatingRowInto(ratingLine,m,true);
        if(links.isEmpty()){TextView none=tv("No playable streams found. Make sure the Stremio addon provides stream links, not just catalogs.",20,Typeface.BOLD);none.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);none.setPadding(dp(18),0,dp(18),0);none.setBackground(bg(Color.argb(130,70,24,24),18));p.addView(none,new LinearLayout.LayoutParams(dp(980),dp(86)));none.requestFocus();return;}
        for(StreamLink link:links){TextView row=streamButton(link);row.setOnClickListener(v->showMedia3Player(m,link));p.addView(row,new LinearLayout.LayoutParams(dp(1040),dp(78)));}
        if(p.getChildCount()>2)p.getChildAt(2).requestFocus();
    }

    TextView streamButton(StreamLink l){
        String label="  ▶  "+first(l.name,l.title,"Stream"); if(l.needsResolver())label+="    [Resolver]"; else if(l.external)label+="    [Try Direct]"; if(!l.quality.isEmpty())label+="    ["+l.quality+"]"; if(!l.size.isEmpty())label+="    "+l.size; if(!l.source.isEmpty())label+="    • "+l.source;
        String second=first(l.description,l.url); if(second.length()>120)second=second.substring(0,117)+"…";
        TextView b=btn(label+"\n     "+second);b.setTextSize(17);b.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);b.setPadding(dp(18),0,dp(18),0);b.setBackground(stroke(Color.argb(140,12,18,30),Color.argb(72,255,255,255)));return b;
    }

    ArrayList<StreamLink> loadStremioStreams(Movie m){
        ArrayList<StreamLink> out=new ArrayList<>(); String links=stremio.getJsonLinks(); if(links==null||links.trim().isEmpty())return out;
        String[] parts=links.split("[\\n, ]+");
        for(String raw:parts){String manifest=raw.trim(); if(manifest.isEmpty()||!manifest.startsWith("http"))continue;
            try{String base=manifest; int ix=base.indexOf("/manifest.json"); if(ix>=0)base=base.substring(0,ix); while(base.endsWith("/"))base=base.substring(0,base.length()-1);
                String type=first(m.type,"movie"); if(!type.equals("series"))type="movie"; String id=first(m.id,extractImdbId(m.meta)); if(id.isEmpty())continue;
                String endpoint=base+"/stream/"+type+"/"+URLEncoder.encode(id,"UTF-8")+".json"; String txt=httpGet(endpoint); JSONObject obj=new JSONObject(txt);JSONArray arr=obj.optJSONArray("streams");if(arr==null)continue;
                for(int i=0;i<arr.length();i++){JSONObject so=arr.optJSONObject(i); if(so==null)continue; String u=so.optString("url",""); boolean isExternal=false; if(u.isEmpty()){u=so.optString("externalUrl",""); isExternal=true;} if(u.isEmpty() && so.has("infoHash")){u="magnet:?xt=urn:btih:"+so.optString("infoHash","");} StreamLink sl=new StreamLink(); sl.url=u; sl.external=isExternal || looksLikeExternalPage(u); sl.name=first(so.optString("name",""),so.optString("title",""),"Stream"); sl.title=so.optString("title",""); sl.description=first(so.optString("description",""),sl.title); sl.source=hostLabel(base); sl.quality=inferQuality(sl.name+" "+sl.title+" "+sl.description+" "+u); sl.size=inferSize(sl.name+" "+sl.title+" "+sl.description); if(u!=null && !u.trim().isEmpty())out.add(sl);}
            }catch(Exception e){AppLogger.mark("Stremio stream load failed: "+e.getMessage()+" manifest="+manifest);}}
        return out;
    }

    String extractImdbId(String meta){if(meta==null)return "";java.util.regex.Matcher m=java.util.regex.Pattern.compile("tt\\d+").matcher(meta);return m.find()?m.group():"";}
    String inferQuality(String s){String u=s==null?"":s.toUpperCase(Locale.US);if(u.contains("2160")||u.contains("4K"))return "4K";if(u.contains("1080"))return "1080p";if(u.contains("720"))return "720p";if(u.contains("HDR"))return "HDR";return "";}
    String inferSize(String s){if(s==null)return "";java.util.regex.Matcher m=java.util.regex.Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(GB|MB)",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(s);return m.find()?m.group(1)+" "+m.group(2).toUpperCase(Locale.US):"";}
    String hostLabel(String url){try{return new URL(url).getHost().replace("www.","");}catch(Exception e){return "Stremio";}}
    boolean looksLikeExternalPage(String url){if(url==null)return true;String u=url.toLowerCase(Locale.US);if(!(u.startsWith("http://")||u.startsWith("https://")))return true;if(u.contains("youtube.com")||u.contains("youtu.be")||u.contains("imdb.com")||u.contains("stremio.com"))return true;return false;}

    String resolverMode(){ return backend.playbackResolverMode(); }
    String resolvePlayableUrl(StreamLink link){
        String mode=resolverMode();
        String url=link.url==null?"":link.url.trim();
        if(url.isEmpty())return "";
        if(url.startsWith("http://")||url.startsWith("https://")){
            if((mode.equals("realdebrid")||mode.equals("auto")) && !backend.realDebridApiKey().isEmpty()){
                String rd=tryRealDebridUnrestrict(url);
                if(!rd.isEmpty())return rd;
            }
            if((mode.equals("torbox")||mode.equals("auto")) && !backend.torboxApiKey().isEmpty()){
                AppLogger.mark("Torbox resolver mode reserved; trying direct stream first");
            }
            return url;
        }
        if(url.startsWith("magnet:") && (mode.equals("realdebrid")||mode.equals("auto")) && !backend.realDebridApiKey().isEmpty()){
            AppLogger.mark("Magnet selected; RD torrent workflow reserved for next resolver upgrade");
        }
        return "";
    }
    String tryRealDebridUnrestrict(String url){
        try{
            HttpURLConnection c=(HttpURLConnection)new URL("https://api.real-debrid.com/rest/1.0/unrestrict/link").openConnection();
            c.setConnectTimeout(9000); c.setReadTimeout(15000); c.setRequestMethod("POST"); c.setDoOutput(true);
            c.setRequestProperty("Authorization","Bearer "+backend.realDebridApiKey());
            c.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
            String body="link="+URLEncoder.encode(url,"UTF-8");
            try(OutputStream os=c.getOutputStream()){os.write(body.getBytes("UTF-8"));}
            InputStream in=(c.getResponseCode()>=200&&c.getResponseCode()<300)?c.getInputStream():c.getErrorStream();
            ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buf=new byte[8192]; int n; while(in!=null&&(n=in.read(buf))>0)out.write(buf,0,n);
            String txt=out.toString("UTF-8");
            if(c.getResponseCode()>=200&&c.getResponseCode()<300){String dl=new JSONObject(txt).optString("download",""); if(!dl.isEmpty()){AppLogger.mark("RD unrestrict success host="+hostLabel(dl)); return dl;}}
            AppLogger.mark("RD unrestrict failed http="+c.getResponseCode());
        }catch(Exception e){AppLogger.mark("RD unrestrict error: "+e.getMessage());}
        return "";
    }

    void showMedia3Player(Movie m, StreamLink link){
        String playUrl=resolvePlayableUrl(link);
        if(playUrl.isEmpty()){Toast.makeText(this,"This stream needs a resolver or is not a direct playable URL.",Toast.LENGTH_LONG).show();return;}
        lockRatings(m); selectedMedia = new SelectedMedia(m); selectedMedia.streams.add(link); clear();
        if(exoPlayer!=null){try{exoPlayer.release();}catch(Exception ignored){} exoPlayer=null;}
        PlayerView pv=new PlayerView(this);pv.setUseController(false);pv.setFocusable(false);root.addView(pv,new FrameLayout.LayoutParams(-1,-1));
        TextView loading=tv("Loading stream…",22,Typeface.BOLD);loading.setGravity(Gravity.CENTER);loading.setBackgroundColor(Color.argb(110,0,0,0));root.addView(loading,new FrameLayout.LayoutParams(-1,-1));
        try{
            exoPlayer=new ExoPlayer.Builder(this).build();pv.setPlayer(exoPlayer);
            exoPlayer.addListener(new Player.Listener(){
                @Override public void onPlaybackStateChanged(int state){AppLogger.mark("Media3 state="+state+" url="+playUrl);if(state==Player.STATE_READY){loading.setVisibility(View.GONE);}if(state==Player.STATE_BUFFERING){loading.setText("Buffering stream…");loading.setVisibility(View.VISIBLE);}if(state==Player.STATE_ENDED){loading.setText("Playback ended");loading.setVisibility(View.VISIBLE);}}
                @Override public void onPlayerError(PlaybackException error){AppLogger.mark("Media3 playback error: "+error.getErrorCodeName()+" "+error.getMessage()+" url="+playUrl);loading.setText("Playback failed: "+error.getErrorCodeName());loading.setVisibility(View.VISIBLE);Toast.makeText(MainActivity.this,"Playback failed: "+error.getErrorCodeName(),Toast.LENGTH_LONG).show();}
            });
            exoPlayer.setMediaItem(MediaItem.fromUri(Uri.parse(playUrl)));exoPlayer.prepare();exoPlayer.play();
        }catch(Exception e){AppLogger.mark("Media3 start failed: "+e.getMessage());Toast.makeText(this,"Playback failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        buildCinematicPlayerOverlay(m,link);
    }

    void buildCinematicPlayerOverlay(Movie m, StreamLink link){
        FrameLayout overlay=new FrameLayout(this);overlay.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,new int[]{Color.argb(235,0,0,0),Color.argb(110,0,0,0),Color.TRANSPARENT}));root.addView(overlay,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.HORIZONTAL);info.setGravity(Gravity.BOTTOM|Gravity.LEFT);info.setPadding(dp(46),0,dp(46),dp(98));overlay.addView(info,new FrameLayout.LayoutParams(-1,-1));
        CardFrame posterFrame=new CardFrame(this,dp(16));posterFrame.setBackground(cardBg(230));ImageView poster=new ImageView(this);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);posterFrame.addView(poster,new FrameLayout.LayoutParams(-1,-1));String posterUrl=first(m.poster,m.background);if(!posterUrl.isEmpty())loadImage(posterUrl,poster,false);LinearLayout.LayoutParams plp=new LinearLayout.LayoutParams(dp(160),dp(238));plp.setMargins(0,0,dp(26),0);info.addView(posterFrame,plp);
        LinearLayout text=new LinearLayout(this);text.setOrientation(LinearLayout.VERTICAL);text.setGravity(Gravity.BOTTOM|Gravity.LEFT);info.addView(text,new LinearLayout.LayoutParams(0,dp(260),1));
        ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);String lg=cardLogoArtwork(m);if(isSafeCardLogo(lg)){text.addView(logo,new LinearLayout.LayoutParams(dp(430),dp(78)));loadImage(lg,logo,false);}else{TextView title=tv(m.title,34,Typeface.BOLD);title.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);text.addView(title,new LinearLayout.LayoutParams(-1,dp(70)));}
        LinearLayout ratingLine=new LinearLayout(this);ratingLine.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);text.addView(ratingLine,new LinearLayout.LayoutParams(-1,dp(36)));buildRatingRowInto(ratingLine,m,true);
        TextView desc=tv(first(m.overview,link.description),16,Typeface.NORMAL);desc.setGravity(Gravity.LEFT|Gravity.TOP);desc.setAlpha(.9f);text.addView(desc,new LinearLayout.LayoutParams(dp(760),dp(76)));
        LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.HORIZONTAL);controls.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);text.addView(controls,new LinearLayout.LayoutParams(-1,dp(62)));
        TextView playPause=btn("Pause");playPause.setOnClickListener(v->{if(exoPlayer!=null){if(exoPlayer.isPlaying()){exoPlayer.pause();playPause.setText("Play");}else{exoPlayer.play();playPause.setText("Pause");}}});controls.addView(playPause,new LinearLayout.LayoutParams(dp(118),dp(54)));
        TextView rw=btn("-10");rw.setOnClickListener(v->{if(exoPlayer!=null)exoPlayer.seekTo(Math.max(0,exoPlayer.getCurrentPosition()-10000));});controls.addView(rw,new LinearLayout.LayoutParams(dp(92),dp(54)));
        TextView ff=btn("+10");ff.setOnClickListener(v->{if(exoPlayer!=null)exoPlayer.seekTo(exoPlayer.getCurrentPosition()+10000);});controls.addView(ff,new LinearLayout.LayoutParams(dp(92),dp(54)));
        TextView audio=btn("Audio");audio.setOnClickListener(v->Toast.makeText(this,"Audio track selector coming next",Toast.LENGTH_SHORT).show());controls.addView(audio,new LinearLayout.LayoutParams(dp(118),dp(54)));
        TextView sub=btn("Subtitles");sub.setOnClickListener(v->Toast.makeText(this,"Subtitle selector coming next",Toast.LENGTH_SHORT).show());controls.addView(sub,new LinearLayout.LayoutParams(dp(150),dp(54)));
        TextView eps=btn("Episodes");eps.setOnClickListener(v->Toast.makeText(this,"Episodes coming next",Toast.LENGTH_SHORT).show());controls.addView(eps,new LinearLayout.LayoutParams(dp(142),dp(54)));
        TextView zoom=btn("Zoom");zoom.setOnClickListener(v->Toast.makeText(this,"Zoom modes coming next",Toast.LENGTH_SHORT).show());controls.addView(zoom,new LinearLayout.LayoutParams(dp(105),dp(54)));
        TextView back=btn("Back");back.setOnClickListener(v->{try{if(exoPlayer!=null){exoPlayer.release();exoPlayer=null;}}catch(Exception ignored){}showMovieDetails(m);});FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(150),dp(56),Gravity.RIGHT|Gravity.BOTTOM);bp.rightMargin=dp(42);bp.bottomMargin=dp(42);overlay.addView(back,bp);playPause.requestFocus();
        overlay.setFocusable(false); overlay.setFocusableInTouchMode(false);
    }

    void playChannel(Channel c){showVideo(c.name,c.url,"LIVE TV PLAYER • single PlayerManager owner");}
    void showVideo(String title,String url,String overlay){clear();backdrop();VideoView vv=new VideoView(this);vv.setFocusable(false);root.addView(vv,new FrameLayout.LayoutParams(-1,-1));TextView top=tv(title+"\n"+overlay,24,Typeface.BOLD);top.setGravity(Gravity.LEFT|Gravity.TOP);top.setPadding(dp(32),dp(28),0,0);top.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{Color.argb(190,0,0,0),Color.TRANSPARENT}));root.addView(top,new FrameLayout.LayoutParams(-1,dp(160)));TextView back=btn("Back");back.setOnClickListener(v->showHome());FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(160),dp(55),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);bp.bottomMargin=dp(45);root.addView(back,bp);try{vv.setVideoURI(android.net.Uri.parse(url));vv.setOnPreparedListener(mp->{mp.setLooping(true);vv.start();});}catch(Exception e){}back.requestFocus();}

    void showLiveTv(){suppressRowAutoFocus=false;clear();nav.go(NavigationController.Screen.LIVE_TV);backdrop();addMenu();TextView title=tv("Live TV Guide",34,Typeface.BOLD);title.setGravity(Gravity.LEFT);FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(dp(430),dp(60));tp.leftMargin=dp(52);tp.topMargin=dp(112);root.addView(title,tp);LinearLayout guide=new LinearLayout(this);guide.setOrientation(LinearLayout.VERTICAL);guide.setBackground(bg(Color.argb(145,5,8,16),20));FrameLayout.LayoutParams gp=new FrameLayout.LayoutParams(dp(1120),dp(500));gp.leftMargin=dp(55);gp.topMargin=dp(185);root.addView(guide,gp);TextView th=tv("CHANNEL        NOW              2:30 PM              3:00 PM              3:30 PM",16,Typeface.BOLD);guide.addView(th,new LinearLayout.LayoutParams(-1,dp(50)));for(int i=0;i<8;i++){Channel ch=channels.get(i%channels.size());TextView r=btn("  "+(101+i)+"  "+ch.name+"        Playing Now              Up Next              Later");r.setGravity(Gravity.CENTER_VERTICAL);final Channel fc=ch;r.setOnClickListener(v->playChannel(fc));guide.addView(r,new LinearLayout.LayoutParams(-1,dp(56)));}guide.getChildAt(1).requestFocus();}

    LinearLayout form(String title){
        ScrollView sv=new ScrollView(this);sv.setFillViewport(false);sv.setFocusable(false);sv.setFocusableInTouchMode(false);sv.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);sv.setSmoothScrollingEnabled(true);sv.setClipToPadding(false);sv.setPadding(0,0,0,dp(120));editorScroll=sv;
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(dp(60),dp(96),dp(60),dp(60));
        sv.addView(p,new ScrollView.LayoutParams(-1,-2));root.addView(sv,new FrameLayout.LayoutParams(-1,-1));
        TextView h=tv(title,34,Typeface.BOLD);h.setGravity(Gravity.LEFT);p.addView(h,new LinearLayout.LayoutParams(-1,dp(70)));return p;
    }
    LinearLayout overlayForm(String title){
        View dim=new View(this);dim.setBackgroundColor(Color.argb(132,0,0,0));root.addView(dim,new FrameLayout.LayoutParams(-1,-1));
        ScrollView sv=new ScrollView(this);
        editorScroll=sv;
        sv.setFillViewport(false);
        sv.setFocusable(false);
        sv.setFocusableInTouchMode(false);
        sv.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        sv.setSmoothScrollingEnabled(true);
        sv.setClipToPadding(false);
        sv.setPadding(0,0,0,dp(80));
        sv.setBackground(bg(Color.argb(232,9,13,22),28));
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(dp(28),dp(24),dp(28),dp(140));sv.addView(p,new ScrollView.LayoutParams(-1,-2));
        FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(dp(870),-1,Gravity.RIGHT|Gravity.TOP);sp.setMargins(0,dp(78),dp(22),dp(30));root.addView(sv,sp);
        TextView h=tv(title,30,Typeface.BOLD);h.setGravity(Gravity.LEFT);p.addView(h,new LinearLayout.LayoutParams(-1,dp(62)));return p;
    }
    void settingButton(LinearLayout p,String text,View.OnClickListener l){TextView b=btn(text);b.setGravity(Gravity.CENTER_VERTICAL);b.setOnClickListener(l);b.setOnFocusChangeListener((v,has)->{focus((TextView)v,has);if(has)ensureEditorVisible(v);});p.addView(b,new LinearLayout.LayoutParams(dp(790),dp(58)));}
    void ensureEditorVisible(View v){ if(editorScroll==null||v==null)return; editorScroll.postDelayed(()->{try{Rect r=new Rect();v.getDrawingRect(r);editorScroll.offsetDescendantRectToMyCoords(v,r);int pad=dp(90);int top=r.top-pad;int bottom=r.bottom+pad;int sy=editorScroll.getScrollY();int sh=editorScroll.getHeight();if(top<sy)editorScroll.smoothScrollTo(0,Math.max(0,top));else if(bottom>sy+sh)editorScroll.smoothScrollTo(0,bottom-sh);}catch(Exception ignored){}},40); }
    String maskKey(String key){ if(key==null||key.trim().isEmpty())return "Not set"; String k=key.trim(); return k.length()<=6?"••••••":k.substring(0,3)+"••••"+k.substring(k.length()-3); }
    void cycleResolverMode(){ String m=backend.playbackResolverMode(); backend.savePlaybackResolverMode(m.equals("direct")?"auto":m.equals("auto")?"realdebrid":m.equals("realdebrid")?"torbox":"direct"); }
    void showSettings(){suppressRowAutoFocus=false;clear();nav.go(NavigationController.Screen.SETTINGS);backdrop();addMenu();LinearLayout p=form("Settings");settingButton(p,"Pro Layout Editor",v->showLayoutEditor());settingButton(p,"Stremio Addon JSON Manager",v->editTextScreen("Stremio addon JSON links",stremio.getJsonLinks(),s->stremio.saveJsonLinks(s)));settingButton(p,"Playback Resolver Mode: "+backend.playbackResolverMode(),v->{cycleResolverMode();showSettings();});settingButton(p,"Real-Debrid API Key: "+maskKey(backend.realDebridApiKey()),v->editTextScreen("Real-Debrid API Key",backend.realDebridApiKey(),s->backend.saveRealDebridApiKey(s)));settingButton(p,"Torbox API Key: "+maskKey(backend.torboxApiKey()),v->editTextScreen("Torbox API Key",backend.torboxApiKey(),s->backend.saveTorboxApiKey(s)));settingButton(p,"Backend Base URL: "+backend.baseUrl(),v->editTextScreen("Backend Base URL",backend.baseUrl(),s->{backend.saveBaseUrl(s);loadBackendHomeRows();}));settingButton(p,"Live TV M3U / Channels DVR URL",v->editTextScreen("Live TV M3U URL",backend.m3uUrl(),s->{backend.saveM3uUrl(s);loadM3u(s);}));settingButton(p,"Refresh Backend Catalog Rows",v->{loadBackendHomeRows();Toast.makeText(this,"Refreshing backend rows",Toast.LENGTH_SHORT).show();});settingButton(p,"4K UI: "+(ui.ui4k()?"Enabled":"Disabled"),v->{ui.save4k(!ui.ui4k());showSettings();});settingButton(p,"Build: DC_V0_1_4_FINAL_RATING_PLAYBACK_FIX",v->Toast.makeText(this,BuildMarkers.LOG_MARKER,Toast.LENGTH_SHORT).show());if(p.getChildCount()>1)p.getChildAt(1).requestFocus();}
    interface SaveText{void save(String s);} void editTextScreen(String title,String current,SaveText save){clear();backdrop();addMenu();LinearLayout p=form(title);EditText e=new EditText(this);e.setText(current);e.setSingleLine(false);e.setMinLines(3);e.setTextColor(Color.WHITE);e.setHintTextColor(Color.GRAY);e.setTextSize(18);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);e.setBackground(stroke(Color.argb(120,20,25,35),Color.argb(100,255,255,255)));p.addView(e,new LinearLayout.LayoutParams(-1,dp(160)));TextView done=btn("Save");done.setOnClickListener(v->{save.save(e.getText().toString());showSettings();});p.addView(done,new LinearLayout.LayoutParams(dp(180),dp(60)));e.requestFocus();}

    void showLayoutEditor(){
        suppressRowAutoFocus=true;showHome();nav.go(NavigationController.Screen.LAYOUT_EDITOR);
        LinearLayout p=overlayForm("Pro Layout Editor");
        settingButton(p,"Save layout",v->{ui.saveLayoutSnapshot();Toast.makeText(this,"Layout saved",Toast.LENGTH_SHORT).show();});
        settingButton(p,"Reset layout",v->{ui.resetLayoutDefaults();Toast.makeText(this,"Layout reset",Toast.LENGTH_SHORT).show();showLayoutEditor();});
        settingButton(p,"View Home",v->{ui.saveLayoutSnapshot();suppressRowAutoFocus=false;showHome();});
        settingButton(p,"Menu position: "+ui.menuPosition(),v->{cycleMenuPosition();showLayoutEditor();});
        settingButton(p,"Icons: "+ui.iconPlacement(),v->{cycleIconPlacement();showLayoutEditor();});
        settingButton(p,"Row titles: "+(ui.rowTitles()?"Shown":"Hidden"),v->{ui.saveRowTitles(!ui.rowTitles());ui.saveValue("rowTitleVisibility",ui.rowTitles()?1:0);showLayoutEditor();});
        settingButton(p,"4K UI: "+(ui.ui4k()?"Enabled":"Disabled"),v->{ui.save4k(!ui.ui4k());showLayoutEditor();});
        addSlider(p,"Preview cards","previewCardCount",1,8,ui.previewCardCount());
        addSlider(p,"Row vertical position","rowTopDp",300,620,ui.rowTopDp());
        addSlider(p,"Row left / right","rowLeftDp",0,120,ui.rowLeftDp());
        addSlider(p,"Card width","cardWidthDp",190,420,ui.cardWidthDp());
        addSlider(p,"Card height","cardHeightDp",110,260,ui.cardHeightDp());
        addSlider(p,"Card spacing","cardSpacingDp",0,40,ui.cardSpacingDp());
        addSlider(p,"Focused card scale","focusedScalePercent",100,120,ui.focusedScalePercent());
        addSlider(p,"Glow strength","glowStrengthPercent",0,100,ui.glowStrengthPercent());
        addSlider(p,"Pulse effect","pulseStrengthPercent",0,100,ui.pulseStrengthPercent());
        addSlider(p,"Focus ring on/off","focusRingEnabled",0,1,ui.focusRingEnabled());
        addSlider(p,"Focus ring thickness","focusRingThicknessDp",0,8,ui.focusRingThicknessDp());
        addSlider(p,"Focus ring color","focusRingColorIndex",0,5,ui.focusRingColorIndex());
        addSlider(p,"3D tilt effect","cardTiltPercent",0,100,ui.cardTiltPercent());
        addSlider(p,"Card lift","cardLiftDp",0,24,ui.cardLiftDp());
        addSlider(p,"Rounded corners","cornerRadiusDp",8,44,ui.cornerRadiusDp());
        addSlider(p,"Dim unfocused cards","dimUnfocusedPercent",0,70,ui.dimUnfocusedPercent());
        addSlider(p,"Top menu icon style","topMenuIconStyle",0,3,ui.topMenuIconStyle());
        addSlider(p,"Menu composition","menuCompositionMode",0,2,ui.menuCompositionMode());
        addSlider(p,"Search icon placement","searchItemPlacement",0,3,ui.searchItemPlacement());
        addSlider(p,"Settings icon placement","settingsItemPlacement",0,3,ui.settingsItemPlacement());
        addSlider(p,"Show row title text","rowTitleVisibility",0,1,ui.rowTitleVisibility());
        addSlider(p,"Hero extra artwork on/off","extraArtworkEnabled",0,1,ui.extraArtworkEnabled());
        addSlider(p,"Hero artwork type","extraArtworkType",0,7,ui.extraArtworkType());
        addSlider(p,"Hero artwork X","extraArtworkXdp",0,1100,ui.extraArtworkXdp());
        addSlider(p,"Hero artwork Y","extraArtworkYdp",0,520,ui.extraArtworkYdp());
        addSlider(p,"Hero artwork width","extraArtworkWidthDp",80,520,ui.extraArtworkWidthDp());
        addSlider(p,"Hero artwork height","extraArtworkHeightDp",60,340,ui.extraArtworkHeightDp());
        addSlider(p,"Hero artwork opacity","extraArtworkOpacityPercent",20,100,ui.extraArtworkOpacityPercent());
        addSlider(p,"Hero artwork 3D pop","extraArtworkDepthPercent",0,100,ui.extraArtworkDepthPercent());
        addSlider(p,"Top menu font","topMenuFontIndex",0,11,ui.topMenuFontIndex());
        addSlider(p,"Hero text font","heroFontIndex",0,11,ui.heroFontIndex());
        addSlider(p,"Content/card font","contentFontIndex",0,11,ui.contentFontIndex());
        addSlider(p,"Row title icons","rowTitleIconsEnabled",0,1,ui.rowTitleIconsEnabled());
        addSlider(p,"Focus bounce","focusBouncePercent",0,100,ui.focusBouncePercent());
        addSlider(p,"Glass card mode","glassCardMode",0,1,ui.glassCardMode());
        addSlider(p,"Hover info overlay","hoverInfoOverlay",0,1,ui.hoverInfoOverlay());
        addSlider(p,"Background dim on focus","backgroundDimOnFocusPercent",0,45,ui.backgroundDimOnFocusPercent());
        addSlider(p,"Effect profile","effectProfileIndex",0,4,ui.effectProfileIndex());
        addSlider(p,"Hero text left / right","heroTextLeftDp",-80,220,ui.heroTextLeftDp());
        addSlider(p,"Hero text up / down","heroTextTopDp",-80,180,ui.heroTextTopDp());
        addSlider(p,"Top menu left / right","topMenuOffsetDp",-220,220,ui.topMenuOffsetDp());
        addSlider(p,"Bottom safe space","bottomSafeDp",24,160,ui.bottomSafeDp());
        if(p.getChildCount()>8)p.getChildAt(8).requestFocus();
    }
    void cycleMenuPosition(){String m=ui.menuPosition();ui.saveMenuPosition(m.equals("left")?"center":m.equals("center")?"right":"left");}
    void cycleIconPlacement(){String m=ui.iconPlacement();ui.saveIconPlacement(m.equals("right")?"inline":m.equals("inline")?"left":m.equals("left")?"hidden":"right");}
    void addSlider(LinearLayout parent,String label,String key,int min,int max,int current){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setFocusable(true);
        box.setFocusableInTouchMode(true);
        box.setPadding(dp(16),dp(6),dp(16),dp(8));
        box.setBackground(stroke(Color.argb(54,20,25,35),Color.argb(45,255,255,255)));
        TextView title=tv(label+": "+current,15,Typeface.BOLD);
        title.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        TextView hint=tv("◀ / ▶ adjust    OK save preview",11,Typeface.NORMAL);
        hint.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        hint.setTextColor(Color.argb(185,255,255,255));
        ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        bar.setMax(max-min);
        bar.setProgress(Math.max(0,Math.min(max-min,current-min)));
        box.addView(title,new LinearLayout.LayoutParams(dp(750),dp(30)));
        box.addView(bar,new LinearLayout.LayoutParams(dp(750),dp(22)));
        box.addView(hint,new LinearLayout.LayoutParams(dp(750),dp(24)));
        final int[] val=new int[]{Math.max(min,Math.min(max,current))};
        Runnable apply=()->{ title.setText(label+": "+val[0]); bar.setProgress(val[0]-min); ui.saveValue(key,val[0]); };
        box.setOnFocusChangeListener((v,has)->{ box.animate().scaleX(has?1.018f:1f).scaleY(has?1.018f:1f).setDuration(100).start(); box.setBackground(has?stroke(Color.argb(120,18,72,126),Color.argb(210,64,160,255)):stroke(Color.argb(54,20,25,35),Color.argb(45,255,255,255))); if(has)ensureEditorVisible(box); });
        box.setOnKeyListener((v,k,e)->{ if(e.getAction()!=KeyEvent.ACTION_DOWN)return false; int step=(max-min)>500?25:(max-min)>120?10:1; if(k==KeyEvent.KEYCODE_DPAD_LEFT){val[0]=Math.max(min,val[0]-step);apply.run();return true;} if(k==KeyEvent.KEYCODE_DPAD_RIGHT){val[0]=Math.min(max,val[0]+step);apply.run();return true;} if(k==KeyEvent.KEYCODE_DPAD_CENTER||k==KeyEvent.KEYCODE_ENTER){ui.saveLayoutSnapshot();Toast.makeText(this,label+" saved",Toast.LENGTH_SHORT).show();return true;} return false; });
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(790),dp(94));lp.setMargins(0,dp(5),0,dp(10));parent.addView(box,lp);
    }

    void showSearch(){suppressRowAutoFocus=false;clear();backdrop();addMenu();LinearLayout p=form("Search");EditText e=new EditText(this);e.setHint("Search movies, shows, channels");e.setTextColor(Color.WHITE);e.setHintTextColor(Color.GRAY);e.setTextSize(22);e.setSingleLine(true);e.setBackground(stroke(Color.argb(110,20,25,35),Color.argb(100,255,255,255)));p.addView(e,new LinearLayout.LayoutParams(-1,dp(70)));e.requestFocus();}
    void loadM3u(String url){new Thread(()->{try{ArrayList<Channel> out=new ArrayList<>();BufferedReader br=new BufferedReader(new InputStreamReader(new URL(url).openStream()));String line,name="Channel",group="Other",logo="";while((line=br.readLine())!=null){if(line.startsWith("#EXTINF")){int ix=line.lastIndexOf(',');name=ix>=0?line.substring(ix+1).trim():"Channel";group=grab(line,"group-title=\"");logo=grab(line,"tvg-logo=\"");}else if(line.startsWith("http")){out.add(new Channel(name,group,line.trim(),logo));}}if(!out.isEmpty())runOnUiThread(()->{channels.clear();channels.addAll(out);Toast.makeText(this,"Loaded "+out.size()+" channels",Toast.LENGTH_LONG).show();});}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"M3U load failed: "+e.getMessage(),Toast.LENGTH_LONG).show());}}).start();}
    String grab(String line,String key){int s=line.indexOf(key);if(s<0)return "";s+=key.length();int e=line.indexOf('"',s);return e>s?line.substring(s,e):"";}

    void loadBackendHomeRowsLegacy(){new Thread(()->{try{String txt=httpGet(joinUrl(backend.baseUrl(),"/api/home"));JSONObject rootObj=new JSONObject(txt);JSONArray rails=rootObj.optJSONArray("rails");if(rails==null||rails.length()==0)return;ArrayList<HomeRow> loaded=new ArrayList<>();ArrayList<Movie> flat=new ArrayList<>();for(int r=0;r<rails.length();r++){JSONObject ro=rails.optJSONObject(r);if(ro==null)continue;HomeRow row=new HomeRow(ro.optString("title",ro.optString("name","Catalog")));row.id=ro.optString("slug",ro.optString("id",""));JSONArray items=ro.optJSONArray("items");if(items==null)continue;for(int i=0;i<items.length();i++){JSONObject it=items.optJSONObject(i);if(it==null)continue;Movie m=new Movie(it.optString("title",it.optString("name","Untitled")),metaFrom(it,ro),"");m.id=it.optString("id",it.optString("externalId",it.optString("imdbId","")));m.type=it.optString("type",it.optString("streamLookupType","movie"));m.poster=abs(it.optString("poster",it.optString("posterUrl","")));m.background=abs(it.optString("background",it.optString("backdrop",it.optString("backdropUrl",m.poster))));m.logo=abs(it.optString("logo",it.optString("clearlogo",it.optString("logoUrl",""))));m.banner=abs(it.optString("banner",it.optString("thumb",m.logo)));m.overview=it.optString("overview",it.optString("description",""));m.year=it.optString("year","");row.items.add(m);flat.add(m);}if(!row.items.isEmpty())loaded.add(row);}if(!loaded.isEmpty())runOnUiThread(()->{homeRows.clear();homeRows.addAll(loaded);movies.clear();movies.addAll(flat);showHome();Toast.makeText(this,"Loaded backend artwork rows: "+flat.size(),Toast.LENGTH_SHORT).show();});}catch(Exception e){AppLogger.mark("Backend home load failed: "+e.getMessage());}}).start();}
    void loadBackendHomeRows(){new Thread(()->{try{if(!loadBackendHomeRowsFresh()){try{httpPost(joinUrl(backend.baseUrl(),"/api/refresh"),"{}");}catch(Exception re){AppLogger.mark("Backend refresh failed: "+re.getMessage());}loadBackendHomeRowsFresh();}}catch(Exception e){AppLogger.mark("Backend artwork load failed: "+e.getMessage());runOnUiThread(()->Toast.makeText(this,"Backend artwork load failed: "+e.getMessage(),Toast.LENGTH_LONG).show());}}).start();}
    boolean loadBackendHomeRowsFresh()throws Exception{String txt=httpGet(joinUrl(backend.baseUrl(),"/api/home"));JSONObject rootObj=new JSONObject(txt);JSONArray rails=rootObj.optJSONArray("rails");if(rails==null||rails.length()==0)return false;ArrayList<HomeRow> loaded=new ArrayList<>();ArrayList<Movie> flat=new ArrayList<>();for(int r=0;r<rails.length();r++){JSONObject ro=rails.optJSONObject(r);if(ro==null)continue;HomeRow row=new HomeRow(ro.optString("title",ro.optString("name","Catalog")));row.id=ro.optString("slug",ro.optString("id",""));JSONArray items=ro.optJSONArray("items");if(items==null)continue;for(int i=0;i<items.length();i++){JSONObject it=items.optJSONObject(i);if(it==null)continue;Movie m=new Movie(it.optString("title",it.optString("name","Untitled")),metaFrom(it,ro),"");m.id=it.optString("id",it.optString("externalId",it.optString("imdbId",it.optString("imdb_id",""))));m.type=it.optString("type",it.optString("streamLookupType","movie"));m.poster=artUrl(it,"poster","posterUrl","poster_url","thumbnail","thumb","image");m.background=artUrl(it,"background","backdrop","backdropUrl","backgroundUrl","fanart","fanartUrl");if(m.background.isEmpty())m.background=m.poster;m.logo=artUrl(it,"logo","clearlogo","clearLogo","clear_logo","clearlogoUrl","logoUrl");m.banner=artUrl(it,"banner","landscape","landscapeUrl","landscape_url","card","cardUrl","card_url","horizontal","horizontalUrl");m.overview=it.optString("overview",it.optString("description",it.optString("summary","")));m.year=it.optString("year","");m.tag=it.optString("tag",it.optString("label",ro.optString("title","FEATURED")));m.imdbRating=ratingFrom(it,"imdbRating","imdb_rating","imdbScore","imdb","imdb_vote_average");m.tmdbRating=ratingFrom(it,"tmdbRating","tmdb_rating","tmdbScore","tmdb","vote_average");row.items.add(m);flat.add(m);}if(!row.items.isEmpty())loaded.add(row);}if(loaded.isEmpty())return false;runOnUiThread(()->{homeRows.clear();homeRows.addAll(loaded);movies.clear();movies.addAll(flat);showHome();Toast.makeText(this,"Loaded backend artwork rows: "+flat.size(),Toast.LENGTH_SHORT).show();});return true;}
    String ratingFrom(JSONObject it,String...keys){for(String k:keys){String v=it.optString(k,"");if(v!=null&&!v.trim().isEmpty()&&!v.equals("0")&&!v.equals("0.0"))return normalizeRating(v);}JSONObject ratings=it.optJSONObject("ratings");if(ratings!=null){for(String k:keys){String v=ratings.optString(k,"");if(v!=null&&!v.trim().isEmpty()&&!v.equals("0")&&!v.equals("0.0"))return normalizeRating(v);}}return "";}
    String normalizeRating(String v){try{String cleaned=v.replaceAll("[^0-9.]","");double d=Double.parseDouble(cleaned);if(d>10)d=d/10.0;return String.format(Locale.US,"%.1f",d);}catch(Exception e){return v.replaceAll("[^0-9.]","");}}
    String artUrl(JSONObject it,String... keys){for(String k:keys){String v=it.optString(k,"");if(v!=null&&!v.trim().isEmpty())return abs(v);}JSONObject art=it.optJSONObject("artwork");if(art!=null){for(String k:keys){String v=art.optString(k,"");if(v!=null&&!v.trim().isEmpty())return abs(v);}}JSONObject images=it.optJSONObject("images");if(images!=null){for(String k:keys){String v=images.optString(k,"");if(v!=null&&!v.trim().isEmpty())return abs(v);}}return "";}
    String httpPost(String u,String body)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(45000);c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Accept","application/json");try(OutputStream os=c.getOutputStream()){os.write(body.getBytes("UTF-8"));}try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);return out.toString("UTF-8");}}

    String metaFrom(JSONObject it,JSONObject ro){String y=it.optString("year","");String source=it.optString("source",ro.optString("source","Stremio Catalog"));return (y.isEmpty()?source:(y+" • "+source));}
    String joinUrl(String base,String path){if(base==null||base.trim().isEmpty())base="http://192.168.100.55:8181";base=base.trim();while(base.endsWith("/"))base=base.substring(0,base.length()-1);return base+path;}
    String abs(String u){if(u==null)return "";u=u.trim();if(u.isEmpty())return "";if(u.startsWith("http://")||u.startsWith("https://"))return u;if(u.startsWith("/"))return joinUrl(backend.baseUrl(),u);return u;}
    String httpGet(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);c.setRequestProperty("Accept","application/json");try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);return out.toString("UTF-8");}}
    void loadImage(String url,ImageView target,boolean cinematic){
        url=abs(url);
        if(target==null)return;
        if(url.isEmpty()){target.setImageDrawable(null);return;}
        final String fu=url;
        target.setTag(fu);
        Bitmap cached=imageCache.get(fu);
        if(cached!=null){target.setImageBitmap(cached);target.setAlpha(1f);return;}
        if(failedArtworkUrls.contains(fu))return;
        imageExecutor.execute(()->{
            try{
                HttpURLConnection c=(HttpURLConnection)new URL(fu).openConnection();
                c.setConnectTimeout(3500);
                c.setReadTimeout(6500);
                c.setRequestProperty("User-Agent","DebridChannelsAndroidTV/0.1.4");
                c.setInstanceFollowRedirects(true);
                int code=c.getResponseCode();
                if(code<200||code>=300){failedArtworkUrls.add(fu);AppLogger.mark("Artwork HTTP "+code+" url="+fu);return;}
                BitmapFactory.Options opts=new BitmapFactory.Options();
                opts.inPreferredConfig=Bitmap.Config.RGB_565;
                Bitmap bm=BitmapFactory.decodeStream(c.getInputStream(),null,opts);
                if(bm!=null){
                    imageCache.put(fu,bm);
                    runOnUiThread(()->{
                        if(!fu.equals(String.valueOf(target.getTag())))return;
                        if(cinematic){
                            target.animate().alpha(.18f).setDuration(90).withEndAction(()->{
                                target.setImageBitmap(bm);
                                target.animate().alpha(1f).setDuration(360).start();
                            }).start();
                        } else {
                            target.setImageBitmap(bm);
                            target.setAlpha(1f);
                        }
                    });
                } else failedArtworkUrls.add(fu);
            }catch(Exception e){failedArtworkUrls.add(fu);AppLogger.mark("Artwork load failed: "+e.getClass().getSimpleName()+": "+e.getMessage()+" url="+fu);}
        });
    }


}
