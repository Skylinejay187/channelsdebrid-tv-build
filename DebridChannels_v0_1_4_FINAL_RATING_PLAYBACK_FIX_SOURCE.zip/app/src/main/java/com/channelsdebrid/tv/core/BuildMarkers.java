package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.1.4 FINAL RATING PLAYBACK FIX";
    public static final String LOG_MARKER = "DC_V0_1_4_FINAL_RATING_PLAYBACK_FIX_ACTIVE";
    private BuildMarkers() {}
}
