package com.channelsdebrid.tv.settings

object SettingsScaffold {
    val defaultTmdb = TmdbSettings()
    val defaultCatalogs = CatalogSettings()

    val defaultAddons = listOf(
        StremioAddonSettings(
            id = "cinematic",
            name = "Cinematic",
            manifestUrl = "https://example.com/manifest.json",
            enabled = true
        )
    )

    val defaultDebrid = DebridSettings()

    val defaultChannelsDvr = ChannelsDvrSettings(
        autoDetect = true,
        baseUrl = "",
        username = "",
        password = "",
        deviceId = ""
    )

    val defaultXtream = XtreamSettings(
        server = "",
        username = "",
        password = "",
        enabled = false
    )

    val defaultStorageTargets = listOf(
        StorageTarget(
            id = "internal",
            type = "internal",
            label = "Internal Storage",
            path = "/data/user/0/com.channelsdebrid.tv/files/cache",
            allowTimeshift = true,
            allowVodCache = false,
            priority = 99
        ),
        StorageTarget(
            id = "usb",
            type = "usb",
            label = "USB / External",
            path = "",
            allowTimeshift = true,
            allowVodCache = true,
            priority = 1
        ),
        StorageTarget(
            id = "nas",
            type = "nas",
            label = "NAS Share",
            path = "",
            allowTimeshift = true,
            allowVodCache = true,
            priority = 2
        )
    )

    val defaultStorage = StorageSettings()
    val defaultTrailers = TrailerSettings()
    val defaultPlayback = PlaybackSettings()
}
