package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v6.7 ARTWORK_VISUAL_PARITY_FIX";
    public static final String LOG_MARKER = "DC_V6_7_ARTWORK_VISUAL_PARITY_FIX";
    private BuildMarkers() {}
}
