NewtoOld_v2.8.26.1_FULL_BRAND_PURGE_QR_PROFILES_STARTUP_ICON

Adds optional internal VLC/libVLC fallback engine under the existing Debrid Channels VOD overlay. Media3/ExoPlayer remains the default production engine. Use Settings > Playback > Player engine to choose Auto, ExoPlayer, VLC/libVLC, or VLC fallback only.

Verify logcat marker:
DC_BUILD_MARKER: NewtoOld_v2.8.26.1_FULL_BRAND_PURGE_QR_PROFILES_STARTUP_ICON

Android source placeholder with guide + trailer wiring instructions

NewtoOld_v2.8.26.1_FULL_BRAND_PURGE_QR_PROFILES_STARTUP_ICON
- Live TV/Channels DVR EPG cache window options limited to 3, 6, and 12 hours.
- Default EPG cache window changed from 12 hours to 6 hours.
- No VOD/player/row/hero/cache changes.


NewtoOld_v2.8.26.1_FULL_BRAND_PURGE_QR_PROFILES_STARTUP_ICON
- Device codec profiles, GPU hardware-composition markers, and optional MPV foundation bridge added.
- Verify with logcat marker: DC_BUILD_MARKER: NewtoOld_v2.8.26.1_FULL_BRAND_PURGE_QR_PROFILES_STARTUP_ICON


NewtoOld_v2.8.26.2_HERO_FOREGROUND_PRIORITY_ROLLBACK: Hero Foreground Priority with rollback marker. Rows can still ghost behind hero, but hero logo/text/rating/extra art/menu are layered above them.

Build v2.8.26.54: startup visible-window input-first patch.
