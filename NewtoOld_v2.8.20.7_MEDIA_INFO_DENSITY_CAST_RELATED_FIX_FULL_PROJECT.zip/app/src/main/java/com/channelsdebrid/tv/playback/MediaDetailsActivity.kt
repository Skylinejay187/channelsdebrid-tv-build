package com.channelsdebrid.tv.playback

import com.channelsdebrid.tv.net.BackendEndpoint
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.channelsdebrid.tv.data.UnifiedCatalogRepository
import com.channelsdebrid.tv.R
import com.channelsdebrid.tv.TvSafeAreaHelper
import com.channelsdebrid.tv.settings.SettingsRepository
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MediaDetailsActivity : AppCompatActivity() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val trailerExecutor = Executors.newSingleThreadExecutor()
    private var backgroundTrailerRunnable: Runnable? = null
    private var backgroundTrailerPlayer: ExoPlayer? = null
    private lateinit var settingsRepository: SettingsRepository
    private lateinit var trailerPlayerView: PlayerView
    private lateinit var popupTrailerPlayerView: PlayerView
    private lateinit var trailerMuteButton: Button
    private lateinit var playTrailerButton: Button
    private lateinit var trailerPopupOverlay: FrameLayout
    private lateinit var trailerLoadingText: TextView
    private lateinit var trailerLoadingSubtext: TextView
    private lateinit var trailerPopupStatus: TextView
    private lateinit var trailerPopupCloseButton: Button
    private lateinit var trailerPopupMuteButton: Button
    private lateinit var trailerPopupFullscreenButton: Button
    private lateinit var trailerPopupControls: LinearLayout
    private var trailerPopupExpanded = false
    private var trailerMuted = false
    private var trailerRequestVersion = 0
    private var popupTrailerWebView: WebView? = null
    private var popupTrailerAutoRunnable: Runnable? = null
    private var trailerMuteHideRunnable: Runnable? = null
    private var trailerPopupControlsHideRunnable: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_media_details)
        settingsRepository = SettingsRepository(this)
        trailerPlayerView = findViewById(R.id.detailsTrailerPlayer)
        popupTrailerPlayerView = findViewById(R.id.detailsTrailerPopupPlayer)
        trailerMuteButton = findViewById(R.id.detailsTrailerMute)
        playTrailerButton = findViewById(R.id.detailsPlayTrailer)
        trailerPopupOverlay = findViewById(R.id.detailsTrailerPopupOverlay)
        trailerLoadingText = findViewById(R.id.detailsTrailerLoading)
        trailerLoadingSubtext = findViewById(R.id.detailsTrailerLoadingSubtext)
        trailerPopupStatus = findViewById(R.id.detailsTrailerPopupStatus)
        trailerPopupCloseButton = findViewById(R.id.detailsTrailerPopupClose)
        trailerPopupMuteButton = findViewById(R.id.detailsTrailerPopupMute)
        trailerPopupFullscreenButton = findViewById(R.id.detailsTrailerPopupFullscreen)
        trailerPopupControls = findViewById(R.id.detailsTrailerPopupControls)
        trailerPlayerView.useController = false
        popupTrailerPlayerView.useController = false
        trailerMuteButton.visibility = View.GONE
        trailerPopupOverlay.isFocusable = true
        trailerPopupOverlay.isFocusableInTouchMode = true
        listOf(trailerPopupCloseButton, trailerPopupMuteButton, trailerPopupFullscreenButton).forEach {
            it.isFocusable = true
            it.isFocusableInTouchMode = true
            it.isClickable = true
        }
        trailerPopupCloseButton.setOnClickListener { closeTrailerPopup() }
        trailerPopupMuteButton.setOnClickListener { toggleTrailerMute() }
        trailerPopupFullscreenButton.setOnClickListener { toggleTrailerPopupFullscreen() }

        val backdrop = intent.getStringExtra(EXTRA_BACKDROP_URL).orEmpty()
        val logo = intent.getStringExtra(EXTRA_LOGO_URL).orEmpty()
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val meta = intent.getStringExtra(EXTRA_META_LINE).orEmpty()
        val desc = intent.getStringExtra(EXTRA_DESC).orEmpty()
        val poster = intent.getStringExtra(EXTRA_POSTER_URL).orEmpty()
        val externalId = intent.getStringExtra(EXTRA_EXTERNAL_ID).orEmpty()
        val mediaType = intent.getStringExtra(EXTRA_MEDIA_TYPE).orEmpty().ifBlank { "movie" }

        Glide.with(this).load(upgradeArtworkUrl(backdrop.ifBlank { poster })).override(com.bumptech.glide.request.target.Target.SIZE_ORIGINAL).diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.ALL).centerCrop().into(findViewById<ImageView>(R.id.detailsBackdrop))

        val logoView = findViewById<ImageView>(R.id.detailsLogo)
        val titleView = findViewById<TextView>(R.id.detailsTitle)
        if (logo.isNotBlank()) {
            Glide.with(this).load(com.channelsdebrid.tv.net.BackendEndpoint.imageProxyUrl(logo)).fitCenter().into(logoView)
        } else {
            logoView.visibility = View.GONE
            titleView.text = title
            titleView.visibility = TextView.VISIBLE
        }

        findViewById<TextView>(R.id.detailsMeta).text = meta
        findViewById<TextView>(R.id.detailsDesc).text = desc
        applyMediaInfoNativeLayoutMode()

        val favoriteButton = findViewById<Button>(R.id.detailsFavorite)
        applyMediaInfoButtonFocus(findViewById(R.id.detailsPlay), primary = true)
        applyMediaInfoButtonFocus(playTrailerButton, primary = false)
        applyMediaInfoButtonFocus(favoriteButton, primary = false)
        val favoriteKey = "favorite_${mediaType}_${externalId.ifBlank { title }}"
        val prefs = getSharedPreferences("debrid_channels_favorites", MODE_PRIVATE)
        fun refreshFavoriteButton() {
            favoriteButton.text = if (prefs.getBoolean(favoriteKey, false)) "✓" else "♡"
        }
        refreshFavoriteButton()
        favoriteButton.setOnClickListener {
            val next = !prefs.getBoolean(favoriteKey, false)
            prefs.edit().putBoolean(favoriteKey, next).apply()
            refreshFavoriteButton()
            Toast.makeText(this, if (next) "Added to favorites" else "Removed from favorites", Toast.LENGTH_SHORT).show()
        }

        buildCastRow(title, externalId, mediaType)
        buildRelatedRow(title, poster.ifBlank { backdrop }, mediaType, externalId)

        val trailerSettings = settingsRepository.loadTrailers()
        val trailerLocation = trailerSettings.playbackLocation.lowercase()
        val detailsTrailersAllowed = trailerSettings.enabled && trailerLocation != "off" && trailerLocation != "hero"
        if (detailsTrailersAllowed) {
            playTrailerButton.visibility = View.VISIBLE
            trailerMuteButton.visibility = View.GONE
            prewarmTrailer(title, meta, mediaType, externalId)
            playTrailerButton.setOnClickListener { showTrailerPopup(title, meta, mediaType, externalId) }
            popupTrailerAutoRunnable = Runnable {
                if (!isFinishing && !isDestroyed && trailerPopupOverlay.visibility != View.VISIBLE) {
                    showTrailerPopup(title, meta, mediaType, externalId)
                }
            }
            mainHandler.postDelayed(popupTrailerAutoRunnable!!, 5000L)
            scheduleBackgroundTrailer(title, meta, mediaType, externalId)
        } else {
            playTrailerButton.visibility = View.GONE
            trailerMuteButton.visibility = View.GONE
        }

        val detailsPlayButton = findViewById<Button>(R.id.detailsPlay)
        var effectiveMediaType = mediaType
        var effectiveExternalId = externalId
        var treatAsSeries = isSeriesMediaType(effectiveMediaType)
        fun refreshPlayButton() {
            detailsPlayButton.text = if (treatAsSeries) "Browse Episodes" else "Play"
        }
        refreshPlayButton()

        // Do NOT auto-convert movies into series by title search.
        // Some movies share titles with shows, and that caused movie pages to show "Browse Episodes".
        // Only explicit media types (series/show/tv) should open SeasonEpisodeActivity.
        detailsPlayButton.setOnClickListener {
            stopBackgroundTrailer()
            if (treatAsSeries) {
                startActivity(Intent(this, SeasonEpisodeActivity::class.java).apply {
                    putExtra(SeasonEpisodeActivity.EXTRA_TITLE, title)
                    putExtra(SeasonEpisodeActivity.EXTRA_MEDIA_TYPE, "series")
                    putExtra(SeasonEpisodeActivity.EXTRA_EXTERNAL_ID, effectiveExternalId)
                    putExtra(SeasonEpisodeActivity.EXTRA_POSTER_URL, poster)
                    putExtra(SeasonEpisodeActivity.EXTRA_BACKDROP_URL, backdrop.ifBlank { poster })
                    putExtra(SeasonEpisodeActivity.EXTRA_LOGO_URL, logo)
                    putExtra(SeasonEpisodeActivity.EXTRA_ITEM_META, meta)
                    putExtra(SeasonEpisodeActivity.EXTRA_DESC, desc)
                })
            } else {
                startActivity(Intent(this, SourceSelectionActivity::class.java).apply {
                    putExtra(SourceSelectionActivity.EXTRA_TITLE, title)
                    putExtra(SourceSelectionActivity.EXTRA_MEDIA_TYPE, effectiveMediaType)
                    putExtra(SourceSelectionActivity.EXTRA_EXTERNAL_ID, effectiveExternalId)
                    putExtra(SourceSelectionActivity.EXTRA_ARTWORK_URL, backdrop.ifBlank { poster })
                    putExtra(SourceSelectionActivity.EXTRA_BACKDROP_URL, backdrop.ifBlank { poster })
                    putExtra(SourceSelectionActivity.EXTRA_LOGO_URL, logo)
                    putExtra(SourceSelectionActivity.EXTRA_POSTER_URL, poster)
                    putExtra(SourceSelectionActivity.EXTRA_META_LINE, meta)
                    putExtra(SourceSelectionActivity.EXTRA_DESC, desc)
                })
            }
        }
    }


    private fun isSeriesMediaType(mediaType: String): Boolean {
        return mediaType.equals("series", ignoreCase = true) ||
            mediaType.equals("show", ignoreCase = true) ||
            mediaType.equals("tv", ignoreCase = true)
    }

    private fun resolveSeriesIdFromCinemeta(queryTitle: String): String {
        val cleanedTitle = queryTitle.trim()
        if (cleanedTitle.isBlank()) return ""
        return runCatching {
            val encoded = URLEncoder.encode(cleanedTitle, "UTF-8").replace("+", "%20")
            val searchUrls = listOf(
                "https://v3-cinemeta.strem.io/catalog/series/top/search=$encoded.json",
                "https://v3-cinemeta.strem.io/catalog/series/popular/search=$encoded.json",
                "https://v3-cinemeta.strem.io/catalog/series/imdbRating/search=$encoded.json"
            )
            for (urlValue in searchUrls) {
                val body = fetchSmallJsonBody(urlValue)
                val metas = JSONObject(body).optJSONArray("metas") ?: continue
                for (i in 0 until metas.length()) {
                    val meta = metas.optJSONObject(i) ?: continue
                    val name = meta.optString("name").ifBlank { meta.optString("title") }
                    val id = meta.optString("id").trim()
                    val imdbId = meta.optString("imdb_id").trim().ifBlank { meta.optString("imdbId").trim() }
                    val candidate = imdbId.ifBlank { id }
                    if (candidate.isNotBlank() && titlesLooselyMatch(cleanedTitle, name)) return@runCatching candidate
                }
            }
            ""
        }.getOrDefault("")
    }

    private fun fetchSmallJsonBody(urlValue: String): String {
        val connection = (URL(urlValue).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 7000
            readTimeout = 10000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "ChannelsDebridTV/1.0")
        }
        return try {
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        } finally {
            connection.disconnect()
        }
    }

    private fun titlesLooselyMatch(a: String, b: String): Boolean {
        fun normalize(value: String): String = value.lowercase(java.util.Locale.US)
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()
        val left = normalize(a)
        val right = normalize(b)
        if (left.isBlank() || right.isBlank()) return false
        return left == right || left.contains(right) || right.contains(left)
    }

    private fun prewarmTrailer(title: String, meta: String, mediaType: String, externalId: String) {
        if (title.isBlank()) return
        trailerExecutor.execute {
            runCatching {
                val liveBackend = settingsRepository.loadLiveBackend()
                val backendBase = liveBackend.baseUrl.ifBlank { "http://skylinejay187.duckdns.org:8181" }.trimEnd('/')
                val year = Regex("(19|20)\\d{2}").find(meta)?.value.orEmpty()
                val body = JSONObject().apply {
                    put("prefer4k", false)
                    put("items", org.json.JSONArray().put(JSONObject().apply {
                        put("title", title)
                        put("year", year)
                        put("type", mediaType.ifBlank { "movie" })
                        put("externalId", externalId)
                    }))
                }.toString()
                val connection = (URL("$backendBase/trailers/prewarm").openConnection() as HttpURLConnection).apply {
                    connectTimeout = 4000
                    readTimeout = 4000
                    requestMethod = "POST"
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Accept", "application/json")
                }
                connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                (if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream)?.close()
                connection.disconnect()
            }
        }
    }

    private fun scheduleBackgroundTrailer(title: String, meta: String, mediaType: String, externalId: String) {
        val settings = settingsRepository.loadTrailers()
        if (!settings.enabled || !settings.backgroundAutoplayEnabled || title.isBlank()) return
        val delay = settings.backgroundAutoplayDelayMs.coerceIn(0L, 60000L).let { if (it == 3000L) 5000L else it }
        val requestId = ++trailerRequestVersion
        backgroundTrailerRunnable = Runnable {
            trailerExecutor.execute {
                val stream = resolveBackendTrailerStream(title, meta, mediaType, externalId, settings.prefer4k)
                mainHandler.post {
                    if (requestId == trailerRequestVersion && !isFinishing && !isDestroyed && stream?.playbackUrl?.isNotBlank() == true) {
                        startBackgroundTrailer(stream)
                    }
                }
            }
        }
        mainHandler.postDelayed(backgroundTrailerRunnable!!, delay)
    }

    private fun showTrailerPopup(title: String, meta: String, mediaType: String, externalId: String) {
        val settings = settingsRepository.loadTrailers()
        if (!settings.enabled || title.isBlank()) return
        stopBackgroundTrailer()
        trailerPopupExpanded = false
        resetTrailerPopupSize()
        trailerPopupOverlay.visibility = View.VISIBLE
        trailerPopupOverlay.alpha = 0f
        trailerPopupOverlay.scaleX = 0.96f
        trailerPopupOverlay.scaleY = 0.96f
        trailerPopupOverlay.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(190L).start()
        showTrailerPopupControls(resetTimer = true)
        trailerPopupMuteButton.requestFocus()
        trailerMuteButton.visibility = View.GONE
        trailerMuteHideRunnable?.let(mainHandler::removeCallbacks)
        val requestId = ++trailerRequestVersion
        showTrailerLoadingState("Finding trailer…", "Checking backend cache and best match", "Finding best available trailer")
        mainHandler.postDelayed({ if (requestId == trailerRequestVersion) showTrailerLoadingState("Preparing preview…", "Requesting clean 1080p playback", "Preparing 1080p trailer preview") }, 550L)
        trailerExecutor.execute {
            val stream = resolveBackendTrailerStream(title, meta, mediaType, externalId, settings.prefer4k)
            mainHandler.post {
                if (requestId != trailerRequestVersion || isFinishing || isDestroyed) return@post
                if (stream?.playbackUrl?.isNotBlank() == true) {
                    popupTrailerWebView?.let { webView ->
                        (webView.parent as? FrameLayout)?.removeView(webView)
                        webView.destroy()
                    }
                    popupTrailerWebView = null
                    popupTrailerPlayerView.visibility = View.VISIBLE
                    showTrailerLoadingState("Starting trailer…", "Opening player preview", "Starting trailer playback")
                    startTrailerStream(stream, popupTrailerPlayerView, repeat = false)
                    trailerPopupMuteButton.requestFocus()
                } else {
                    showTrailerLoadingState("Trailer unavailable", "Try again later or choose another title", "Trailer unavailable")
                    Toast.makeText(this, "Trailer unavailable from backend", Toast.LENGTH_LONG).show()
                    mainHandler.postDelayed({ if (requestId == trailerRequestVersion) closeTrailerPopup() }, 1600L)
                }
            }
        }
    }

    private fun resolveBackendTrailerStream(title: String, meta: String, mediaType: String, externalId: String, prefer4k: Boolean): TrailerStream? {
        return runCatching {
            val liveBackend = settingsRepository.loadLiveBackend()
            val backendBase = liveBackend.baseUrl.ifBlank { "http://skylinejay187.duckdns.org:8181" }.trimEnd('/')
            val encodedTitle = URLEncoder.encode(title.trim(), "UTF-8")
            val year = Regex("(19|20)\\d{2}").find(meta)?.value.orEmpty()
            val requestedQuality = if (prefer4k) "2160p,1080p" else "1080p"
            val query = buildString {
                append("title=").append(encodedTitle)
                append("&year=").append(URLEncoder.encode(year, "UTF-8"))
                append("&type=").append(URLEncoder.encode(mediaType.ifBlank { "movie" }, "UTF-8"))
                append("&externalId=").append(URLEncoder.encode(externalId, "UTF-8"))
                append("&mediaId=").append(URLEncoder.encode(externalId, "UTF-8"))
                append("&quality=").append(URLEncoder.encode(requestedQuality, "UTF-8"))
                append("&prefer4k=").append(if (prefer4k) "true" else "false")
                append("&strictTitle=false&officialOnly=false")
            }
            val url = URL("$backendBase/trailers/resolve?$query")
            val connection = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 60000
                requestMethod = "GET"
                setRequestProperty("Accept", "application/json")
            }
            val response = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            response?.bufferedReader()?.use { reader ->
                val json = JSONObject(reader.readText())
                if (!json.optBoolean("ok", false)) return null
                val trailer = json.optJSONObject("trailer") ?: json
                val videoUrl = trailer.optString("videoUrl").ifBlank { trailer.optString("video_url") }
                val audioUrl = trailer.optString("audioUrl").ifBlank { trailer.optString("audio_url") }
                val playbackUrl = videoUrl.ifBlank { trailer.optString("playbackUrl").ifBlank { trailer.optString("url") }.ifBlank { trailer.optString("directUrl") }.ifBlank { trailer.optString("streamUrl") } }
                val resolvedTitle = trailer.optString("title")
                if (playbackUrl.isBlank()) return null
                // Backend scoring already filters the candidate; do not hide playable trailers with overly strict app-side title rejection.
                TrailerStream(
                    playbackUrl = playbackUrl,
                    audioUrl = audioUrl,
                    mimeType = trailer.optString("videoMimeType").ifBlank { trailer.optString("mimeType") },
                    audioMimeType = trailer.optString("audioMimeType"),
                    quality = trailer.optString("quality"),
                    allow4k = prefer4k
                )
            }
        }.getOrNull()
    }

    private fun buildYouTubeTrailerQuery(title: String, meta: String, mediaType: String): String {
        val year = Regex("(19|20)\\d{2}").find(meta)?.value.orEmpty()
        val typeHint = if (isSeriesMediaType(mediaType)) "series" else "movie"
        return listOf(title.trim(), year, typeHint, "official trailer")
            .filter { it.isNotBlank() }
            .joinToString(" ")
    }

    private fun startYouTubeTrailerSearch(title: String, meta: String, mediaType: String) {
        startYouTubeWebView(buildYouTubeTrailerQuery(title, meta, mediaType))
    }

    private fun startYouTubeTrailer(videoId: String) {
        startYouTubeWebView(videoId, isVideoId = true)
    }

    private fun startYouTubeWebView(value: String, isVideoId: Boolean = false) {
        releaseTrailerPlayer()
        popupTrailerPlayerView.player = null
        popupTrailerPlayerView.visibility = View.GONE
        val container = popupTrailerPlayerView.parent as? FrameLayout ?: return
        popupTrailerWebView?.let {
            container.removeView(it)
            it.destroy()
        }
        val webView = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            isFocusable = false
            isFocusableInTouchMode = false
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            setOnKeyListener { _, keyCode, event ->
                if (keyCode == android.view.KeyEvent.KEYCODE_BACK && event.action == android.view.KeyEvent.ACTION_DOWN) {
                    closeTrailerPopup()
                    true
                } else false
            }
        }
        popupTrailerWebView = webView
        container.addView(webView, 0, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        trailerLoadingText.visibility = View.GONE
        val src = if (isVideoId) {
            "https://www.youtube.com/embed/${Uri.encode(value)}?autoplay=1&playsinline=1&rel=0&modestbranding=1&vq=hd1080"
        } else {
            val q = URLEncoder.encode(value, "UTF-8").replace("+", "%20")
            "https://www.youtube.com/embed?listType=search&list=$q&autoplay=1&playsinline=1&rel=0&modestbranding=1&vq=hd1080"
        }
        val html = """
            <!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
            <style>html,body,#player{margin:0;width:100%;height:100%;background:#000;overflow:hidden}</style></head>
            <body><iframe id="player" src="$src" frameborder="0" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe></body></html>
        """.trimIndent()
        webView.loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "UTF-8", null)
        trailerPopupMuteButton.requestFocus()
    }

    private fun looksLikeTrailerForTitle(candidate: String, expected: String): Boolean {
        fun normalize(value: String): Set<String> = value.lowercase()
            .replace(Regex("[^a-z0-9 ]"), " ")
            .split(Regex("\\s+"))
            .filter { it.length > 2 && it !in setOf("the", "and", "official", "trailer", "teaser", "clip", "movie", "series", "season") }
            .toSet()
        val expectedWords = normalize(expected)
        if (expectedWords.isEmpty()) return true
        val candidateWords = normalize(candidate)
        return expectedWords.count { it in candidateWords } >= minOf(2, expectedWords.size)
    }

    private fun startBackgroundTrailer(stream: TrailerStream) {
        startTrailerStream(stream, trailerPlayerView, repeat = true)
        trailerPlayerView.visibility = View.VISIBLE
        trailerPlayerView.animate().alpha(1f).setDuration(350L).start()
    }

    private fun startTrailerStream(stream: TrailerStream, playerView: PlayerView, repeat: Boolean) {
        releaseTrailerPlayer()
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Android TV; ChannelsDebrid)")
            .setAllowCrossProtocolRedirects(true)
        val mediaSourceFactory = DefaultMediaSourceFactory(this).setDataSourceFactory(httpFactory)
        val trackSelector = DefaultTrackSelector(this).apply {
            setParameters(
                buildUponParameters()
                    .setMaxVideoSize(if (stream.allow4k) 3840 else 1920, if (stream.allow4k) 2160 else 1080)
                    .setMinVideoSize(1280, 720)
                    .setForceHighestSupportedBitrate(true)
            )
        }
        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(mediaSourceFactory)
            .setTrackSelector(trackSelector)
            .build()
        backgroundTrailerPlayer = player
        playerView.player = player
        val videoItemBuilder = MediaItem.Builder().setUri(stream.playbackUrl)
        if (stream.mimeType.contains("dash", ignoreCase = true) || stream.playbackUrl.contains(".mpd", ignoreCase = true)) {
            videoItemBuilder.setMimeType(MimeTypes.APPLICATION_MPD)
        } else if (stream.mimeType.contains("hls", ignoreCase = true) || stream.playbackUrl.contains(".m3u8", ignoreCase = true)) {
            videoItemBuilder.setMimeType(MimeTypes.APPLICATION_M3U8)
        }
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    findViewById<View>(R.id.detailsTrailerLoadingPanel).visibility = View.GONE
                    trailerPopupStatus.text = if (stream.allow4k) "Playing best available trailer" else "Playing 1080p trailer preview"
                    scheduleTrailerPopupControlsAutoHide()
                }
                if (playbackState == Player.STATE_BUFFERING) {
                    showTrailerLoadingState("Buffering preview…", "Keeping playback smooth", "Buffering trailer preview")
                }
                if (playbackState == Player.STATE_ENDED && !repeat) closeTrailerPopup()
            }
        })
        if (stream.audioUrl.isNotBlank()) {
            val audioItemBuilder = MediaItem.Builder().setUri(stream.audioUrl)
            if (stream.audioMimeType.contains("dash", ignoreCase = true) || stream.audioUrl.contains(".mpd", ignoreCase = true)) {
                audioItemBuilder.setMimeType(MimeTypes.APPLICATION_MPD)
            } else if (stream.audioMimeType.contains("hls", ignoreCase = true) || stream.audioUrl.contains(".m3u8", ignoreCase = true)) {
                audioItemBuilder.setMimeType(MimeTypes.APPLICATION_M3U8)
            }
            val videoSource = mediaSourceFactory.createMediaSource(videoItemBuilder.build())
            val audioSource = mediaSourceFactory.createMediaSource(audioItemBuilder.build())
            player.setMediaSource(MergingMediaSource(videoSource, audioSource))
        } else {
            player.setMediaItem(videoItemBuilder.build())
        }
        player.repeatMode = if (repeat) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        player.volume = 1f
        player.prepare()
        player.playWhenReady = true
    }

    private fun showTrailerLoadingState(title: String, subtext: String, status: String) {
        findViewById<View>(R.id.detailsTrailerLoadingPanel).visibility = View.VISIBLE
        trailerLoadingText.text = title
        trailerLoadingSubtext.text = subtext
        trailerPopupStatus.text = status
    }

    private fun toggleTrailerPopupFullscreen() {
        trailerPopupExpanded = !trailerPopupExpanded
        val card = findViewById<FrameLayout>(R.id.detailsTrailerPopupCard)
        val params = card.layoutParams as FrameLayout.LayoutParams
        if (trailerPopupExpanded) {
            params.width = FrameLayout.LayoutParams.MATCH_PARENT
            params.height = FrameLayout.LayoutParams.MATCH_PARENT
            params.setMargins(dp(42), dp(42), dp(42), dp(42))
            params.gravity = Gravity.CENTER
            trailerPopupFullscreenButton.text = "Shrink"
        } else {
            params.width = dp(780)
            params.height = dp(438)
            params.setMargins(0, 0, 0, 0)
            params.gravity = Gravity.CENTER
            trailerPopupFullscreenButton.text = "Fullscreen"
        }
        card.layoutParams = params
        showTrailerPopupControls(resetTimer = true)
    }

    private fun resetTrailerPopupSize() {
        val card = findViewById<FrameLayout>(R.id.detailsTrailerPopupCard)
        val params = card.layoutParams as FrameLayout.LayoutParams
        params.width = dp(780)
        params.height = dp(438)
        params.setMargins(0, 0, 0, 0)
        params.gravity = Gravity.CENTER
        card.layoutParams = params
        trailerPopupFullscreenButton.text = "Fullscreen"
    }

    private fun applyMediaInfoNativeLayoutMode() {
        val config = runCatching { settingsRepository.loadHomeLayout() }.getOrNull() ?: return
        val active = config.mediaInfoNative4KMode == 1 || config.nativeUiResolutionMode == 2
        val content = findViewById<FrameLayout>(R.id.detailsContent)
        val scroll = findViewById<ScrollView>(R.id.detailsInfoScroll)
        val left = findViewById<LinearLayout>(R.id.detailsLeftPanel)
        val logo = findViewById<ImageView>(R.id.detailsLogo)
        val desc = findViewById<TextView>(R.id.detailsDesc)
        val meta = findViewById<TextView>(R.id.detailsMeta)
        val title = findViewById<TextView>(R.id.detailsTitle)
        val castSection = findViewById<LinearLayout>(R.id.detailsCastSection)

        // Media details must be scroll-safe on TV/projector. Do not use fixed, non-scrollable
        // content heights: long descriptions, cast, episodes, and future related rows must be
        // allowed to flow downward inside the scroll view instead of being cropped by safe-area
        // padding or TV overscan.
        scroll.isFillViewport = false
        scroll.clipToPadding = false
        scroll.isVerticalFadingEdgeEnabled = false
        scroll.isHorizontalFadingEdgeEnabled = false
        scroll.setFadingEdgeLength(0)
        scroll.setWillNotCacheDrawing(true)
        scroll.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        left.clipToPadding = false
        left.clipChildren = false
        left.setPadding(left.paddingLeft, left.paddingTop, left.paddingRight, dp(220))
        castSection.minimumHeight = dp(184)
        castSection.layoutParams = (castSection.layoutParams as LinearLayout.LayoutParams).apply {
            height = LinearLayout.LayoutParams.WRAP_CONTENT
            topMargin = if (active) dp(34) else dp(30)
        }

        if (active) {
            content.setPadding(dp(72), dp(70), dp(72), dp(46))
            scroll.layoutParams = (scroll.layoutParams as FrameLayout.LayoutParams).apply {
                width = dp(980)
                height = FrameLayout.LayoutParams.MATCH_PARENT
                gravity = Gravity.START or Gravity.TOP
            }
            left.layoutParams = left.layoutParams.apply { width = dp(980) }
            logo.layoutParams = logo.layoutParams.apply { width = dp(560); height = dp(146) }
            desc.layoutParams = desc.layoutParams.apply { width = dp(900) }
            desc.maxLines = 4
            desc.textSize = 20f
            meta.textSize = 18f
            title.textSize = 36f
            android.util.Log.i("DebridChannels", "MEDIA_INFO_4K_UI_MODE: active layout=scroll_safe_cinematic_flow")
        } else {
            scroll.layoutParams = (scroll.layoutParams as FrameLayout.LayoutParams).apply {
                width = dp(900)
                height = FrameLayout.LayoutParams.MATCH_PARENT
                gravity = Gravity.START or Gravity.TOP
            }
            left.layoutParams = left.layoutParams.apply { width = dp(820) }
            android.util.Log.i("DebridChannels", "MEDIA_INFO_4K_UI_MODE: standard layout=scroll_safe_cinematic_flow")
        }

        // Apply TV-safe margins after native/tablet layout sizing so the helper does not get
        // overwritten. Tablets remain unchanged because the helper no-ops unless the device is TV-like.
        TvSafeAreaHelper.applyIfTv(this, content, "media_details")
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun scheduleTrailerPopupControlsAutoHide() {
        if (!::trailerPopupControls.isInitialized || trailerPopupOverlay.visibility != View.VISIBLE) return
        trailerPopupControlsHideRunnable?.let(mainHandler::removeCallbacks)
        trailerPopupControlsHideRunnable = Runnable {
            if (trailerPopupOverlay.visibility == View.VISIBLE && findViewById<View>(R.id.detailsTrailerLoadingPanel).visibility != View.VISIBLE) {
                trailerPopupControls.animate().alpha(0f).setDuration(180L).withEndAction {
                    trailerPopupControls.visibility = View.GONE
                    trailerPopupOverlay.requestFocus()
                }.start()
                android.util.Log.i("DebridChannels", "TRAILER_PREVIEW_CONTROLS: auto_hidden_after_3s")
            }
        }
        mainHandler.postDelayed(trailerPopupControlsHideRunnable!!, 3000L)
    }

    private fun showTrailerPopupControls(resetTimer: Boolean) {
        if (!::trailerPopupControls.isInitialized) return
        trailerPopupControls.animate().cancel()
        trailerPopupControls.visibility = View.VISIBLE
        trailerPopupControls.alpha = 1f
        if (resetTimer) scheduleTrailerPopupControlsAutoHide()
        android.util.Log.i("DebridChannels", "TRAILER_PREVIEW_CONTROLS: visible resetTimer=$resetTimer")
    }

    private fun toggleTrailerMute() {
        trailerMuted = !trailerMuted
        backgroundTrailerPlayer?.volume = if (trailerMuted) 0f else 1f
        trailerMuteButton.visibility = View.GONE
        if (::trailerPopupMuteButton.isInitialized) {
            trailerPopupMuteButton.text = if (trailerMuted) "Unmute" else "Mute"
        }
    }

    private fun refreshTrailerMuteButton() {
        if (::trailerMuteButton.isInitialized) {
            trailerMuteButton.visibility = View.GONE
        }
        if (::trailerPopupMuteButton.isInitialized) {
            trailerPopupMuteButton.text = if (trailerMuted) "Unmute" else "Mute"
        }
    }

    private fun closeTrailerPopup() {
        trailerRequestVersion++
        trailerPopupControlsHideRunnable?.let(mainHandler::removeCallbacks)
        trailerPopupControlsHideRunnable = null
        releaseTrailerPlayer()
        popupTrailerWebView?.let { webView ->
            (webView.parent as? FrameLayout)?.removeView(webView)
            webView.destroy()
        }
        popupTrailerWebView = null
        popupTrailerPlayerView.visibility = View.VISIBLE
        popupTrailerPlayerView.player = null
        trailerPopupOverlay.animate().cancel()
        trailerPopupOverlay.animate().alpha(0f).setDuration(140L).withEndAction {
            trailerPopupOverlay.visibility = View.GONE
            if (settingsRepository.loadTrailers().popupMode.contains("popup", ignoreCase = true)) {
                trailerMuteButton.visibility = View.GONE
            }
        }.start()
    }

    private fun stopBackgroundTrailer() {
        trailerRequestVersion++
        popupTrailerAutoRunnable?.let(mainHandler::removeCallbacks)
        trailerMuteHideRunnable?.let(mainHandler::removeCallbacks)
        trailerPopupControlsHideRunnable?.let(mainHandler::removeCallbacks)
        trailerPopupControlsHideRunnable = null
        popupTrailerAutoRunnable = null
        backgroundTrailerRunnable?.let(mainHandler::removeCallbacks)
        backgroundTrailerRunnable = null
        trailerPlayerView.animate().cancel()
        trailerPlayerView.alpha = 0f
        trailerPlayerView.visibility = View.GONE
        trailerPlayerView.player = null
        popupTrailerPlayerView.player = null
        releaseTrailerPlayer()
    }

    private fun releaseTrailerPlayer() {
        backgroundTrailerPlayer?.release()
        backgroundTrailerPlayer = null
    }


    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (::trailerPopupOverlay.isInitialized && trailerPopupOverlay.visibility == View.VISIBLE && event.action == KeyEvent.ACTION_DOWN) {
            if (::trailerPopupControls.isInitialized && trailerPopupControls.visibility != View.VISIBLE) {
                showTrailerPopupControls(resetTimer = true)
                trailerPopupFullscreenButton.requestFocus()
                return true
            }
            showTrailerPopupControls(resetTimer = true)
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onBackPressed() {
        if (::trailerPopupOverlay.isInitialized && trailerPopupOverlay.visibility == View.VISIBLE) {
            closeTrailerPopup()
            return
        }
        super.onBackPressed()
    }

    override fun onStop() {
        super.onStop()
        closeTrailerPopup()
        stopBackgroundTrailer()
    }

    override fun onDestroy() {
        stopBackgroundTrailer()
        trailerExecutor.shutdownNow()
        super.onDestroy()
    }

    private fun applyMediaInfoButtonFocus(view: View, primary: Boolean) {
        view.setOnFocusChangeListener { focusedView, hasFocus ->
            val scale = if (hasFocus) 1.045f else 1f
            val targetAlpha = if (hasFocus || primary) 1f else 0.92f
            focusedView.animate()
                .scaleX(scale)
                .scaleY(scale)
                .alpha(targetAlpha)
                .setDuration(140L)
                .start()
            focusedView.elevation = if (hasFocus) dp(12).toFloat() else dp(2).toFloat()
        }
    }

    private fun buildCastRow(title: String, externalId: String, mediaType: String) {
        val row = findViewById<LinearLayout>(R.id.detailsCastRow)
        val section = findViewById<LinearLayout>(R.id.detailsCastSection)
        row.removeAllViews()
        renderCastLoading(row)
        section.visibility = View.VISIBLE
        trailerExecutor.execute {
            val resolved = resolveCastMembers(title, externalId, mediaType)
            mainHandler.post {
                if (!isFinishing && !isDestroyed) {
                    renderCastMembers(row, resolved)
                    android.util.Log.i("DebridChannels", "MEDIA_INFO_CAST_SECTION: members=${resolved.size} source=${if (resolved.isNotEmpty()) resolved.first().source else "none"}")
                }
            }
        }
    }

    private fun renderCastLoading(row: LinearLayout) {
        row.removeAllViews()
        val label = TextView(this).apply {
            text = "Loading cast…"
            setTextColor(0xAAFFFFFF.toInt())
            textSize = 14f
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(label, LinearLayout.LayoutParams(dp(220), LinearLayout.LayoutParams.MATCH_PARENT))
    }

    private fun renderCastMembers(row: LinearLayout, cast: List<CastMember>) {
        row.removeAllViews()
        if (cast.isEmpty()) {
            val label = TextView(this).apply {
                text = "Cast unavailable"
                setTextColor(0xAAFFFFFF.toInt())
                textSize = 14f
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(label, LinearLayout.LayoutParams(dp(220), LinearLayout.LayoutParams.MATCH_PARENT))
            return
        }
        cast.take(16).forEach { member ->
            val column = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isFocusable = true
                isFocusableInTouchMode = true
                background = makePillDrawable(0x00000000, 0x00000000)
            }
            val avatarFrame = FrameLayout(this).apply {
                background = makePillDrawable(0x33FFFFFF, 0x44FFFFFF)
                clipToOutline = false
                elevation = dp(4).toFloat()
            }
            val image = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
            }
            avatarFrame.addView(image, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            if (member.imageUrl.isNotBlank()) {
                Glide.with(this).load(com.channelsdebrid.tv.net.BackendEndpoint.imageProxyUrl(member.imageUrl)).centerCrop().into(image)
            } else {
                avatarFrame.removeAllViews()
                avatarFrame.addView(TextView(this).apply {
                    text = member.name.trim().take(1).ifBlank { "?" }
                    setTextColor(Color.WHITE)
                    textSize = 24f
                    setTypeface(typeface, Typeface.BOLD)
                    gravity = Gravity.CENTER
                }, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            }
            column.addView(avatarFrame, LinearLayout.LayoutParams(dp(64), dp(64)))
            val label = TextView(this).apply {
                text = member.name
                setTextColor(0xEEFFFFFF.toInt())
                textSize = 13f
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            column.addView(label, LinearLayout.LayoutParams(dp(104), LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
            // Keep Media Info dense on TV/projector screens: actor role text is hidden here.
            row.addView(column, LinearLayout.LayoutParams(dp(112), LinearLayout.LayoutParams.MATCH_PARENT).apply { marginEnd = dp(8) })
        }
    }

    private fun resolveCastMembers(title: String, externalId: String, mediaType: String): List<CastMember> {
        val type = if (isSeriesMediaType(mediaType)) "series" else "movie"
        val tmdbCast = resolveTmdbCast(externalId, type)
        if (tmdbCast.isNotEmpty()) return tmdbCast
        val tmdbTitleCast = resolveTmdbCastByTitle(title, type)
        if (tmdbTitleCast.isNotEmpty()) return tmdbTitleCast
        val cinemetaId = externalId.takeIf { it.startsWith("tt") } ?: if (type == "series") resolveSeriesIdFromCinemeta(title) else externalId
        val cinemetaCast = resolveCinemetaCast(cinemetaId, type)
        if (cinemetaCast.isNotEmpty()) return cinemetaCast
        return emptyList()
    }

    private fun resolveTmdbCast(externalId: String, mediaType: String): List<CastMember> {
        val tmdb = settingsRepository.loadTmdb()
        val apiKey = tmdb.apiKey.trim()
        if (apiKey.isBlank() || externalId.isBlank() || !externalId.startsWith("tt")) return emptyList()
        return runCatching {
            val lang = tmdb.language.ifBlank { "en-US" }
            val find = JSONObject(fetchSmallJsonBody("https://api.themoviedb.org/3/find/${enc(externalId)}?api_key=${enc(apiKey)}&external_source=imdb_id&language=${enc(lang)}"))
            val arrayName = if (mediaType == "series") "tv_results" else "movie_results"
            val chosen = find.optJSONArray(arrayName)?.optJSONObject(0) ?: return@runCatching emptyList<CastMember>()
            val tmdbId = chosen.optInt("id", 0)
            if (tmdbId <= 0) return@runCatching emptyList<CastMember>()
            val endpointType = if (mediaType == "series") "tv" else "movie"
            val credits = JSONObject(fetchSmallJsonBody("https://api.themoviedb.org/3/$endpointType/$tmdbId/credits?api_key=${enc(apiKey)}&language=${enc(lang)}"))
            val cast = credits.optJSONArray("cast") ?: JSONArray()
            val out = mutableListOf<CastMember>()
            for (i in 0 until cast.length().coerceAtMost(16)) {
                val obj = cast.optJSONObject(i) ?: continue
                val name = obj.optString("name").trim()
                if (name.isBlank()) continue
                val role = obj.optString("character").trim().ifBlank { "Cast" }
                val profile = obj.optString("profile_path").trim().takeIf { it.isNotBlank() }?.let { "https://image.tmdb.org/t/p/w342$it" }.orEmpty()
                out += CastMember(name, role, profile, "tmdb")
            }
            out
        }.getOrDefault(emptyList())
    }


    private fun resolveTmdbCastByTitle(title: String, mediaType: String): List<CastMember> {
        val tmdb = settingsRepository.loadTmdb()
        val apiKey = tmdb.apiKey.trim()
        val cleanTitle = title.trim()
        if (apiKey.isBlank() || cleanTitle.isBlank()) return emptyList()
        return runCatching {
            val lang = tmdb.language.ifBlank { "en-US" }
            val endpointType = if (mediaType == "series") "tv" else "movie"
            val searchType = if (mediaType == "series") "tv" else "movie"
            val search = JSONObject(fetchSmallJsonBody("https://api.themoviedb.org/3/search/$searchType?api_key=${enc(apiKey)}&language=${enc(lang)}&query=${enc(cleanTitle)}&include_adult=false&page=1"))
            val tmdbId = search.optJSONArray("results")?.optJSONObject(0)?.optInt("id", 0) ?: 0
            if (tmdbId <= 0) return@runCatching emptyList<CastMember>()
            val credits = JSONObject(fetchSmallJsonBody("https://api.themoviedb.org/3/$endpointType/$tmdbId/credits?api_key=${enc(apiKey)}&language=${enc(lang)}"))
            val cast = credits.optJSONArray("cast") ?: JSONArray()
            val out = mutableListOf<CastMember>()
            for (i in 0 until cast.length().coerceAtMost(16)) {
                val obj = cast.optJSONObject(i) ?: continue
                val name = obj.optString("name").trim()
                if (name.isBlank()) continue
                val role = obj.optString("character").trim().ifBlank { "Cast" }
                val profile = obj.optString("profile_path").trim().takeIf { it.isNotBlank() }?.let { "https://image.tmdb.org/t/p/w342$it" }.orEmpty()
                out += CastMember(name, role, profile, "tmdb-title")
            }
            out
        }.getOrDefault(emptyList())
    }

    private fun resolveCinemetaCast(externalId: String, mediaType: String): List<CastMember> {
        if (externalId.isBlank()) return emptyList()
        return runCatching {
            val cleanType = if (mediaType == "series") "series" else "movie"
            val meta = JSONObject(fetchSmallJsonBody("https://v3-cinemeta.strem.io/meta/$cleanType/${enc(externalId)}.json")).optJSONObject("meta") ?: return@runCatching emptyList<CastMember>()
            val out = mutableListOf<CastMember>()
            val castArray = meta.optJSONArray("cast")
            if (castArray != null) {
                for (i in 0 until castArray.length().coerceAtMost(16)) {
                    when (val item = castArray.opt(i)) {
                        is JSONObject -> {
                            val name = item.optString("name").ifBlank { item.optString("title") }.trim()
                            if (name.isNotBlank()) {
                                val role = item.optString("character").ifBlank { item.optString("role") }.ifBlank { "Cast" }
                                val image = item.optString("photo").ifBlank { item.optString("poster") }.ifBlank { item.optString("image") }
                                out += CastMember(name, role, image, "cinemeta")
                            }
                        }
                        is String -> {
                            val name = item.trim()
                            if (name.isNotBlank()) out += CastMember(name, "Cast", "", "cinemeta")
                        }
                    }
                }
            }
            if (out.isEmpty()) {
                val director = meta.optJSONArray("director") ?: meta.optJSONArray("directors")
                if (director != null) {
                    for (i in 0 until director.length().coerceAtMost(4)) {
                        val name = director.optString(i).trim()
                        if (name.isNotBlank()) out += CastMember(name, "Director", "", "cinemeta")
                    }
                } else {
                    meta.optString("director").split(",").map { it.trim() }.filter { it.isNotBlank() }.take(4).forEach { out += CastMember(it, "Director", "", "cinemeta") }
                }
            }
            out
        }.getOrDefault(emptyList())
    }

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8").replace("+", "%20")

    private fun buildRelatedRow(title: String, artwork: String, mediaType: String, externalId: String) {
        val sectionTitle = findViewById<TextView>(R.id.detailsRelatedTitle)
        sectionTitle.text = if (isSeriesMediaType(mediaType)) "Shows You’ll Also Like" else "Movies You’ll Also Like"
        val row = findViewById<LinearLayout>(R.id.detailsRelatedRow)
        row.removeAllViews()
        fun addRelatedCard(labelText: String, imageUrl: String, item: UnifiedCatalogRepository.MediaItem? = null) {
            val frame = FrameLayout(this).apply {
                background = makePillDrawable(0x33000000, 0x55FFFFFF)
                isFocusable = true
                isClickable = item != null
                clipToOutline = true
            }
            val image = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            frame.addView(image, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            val art = imageUrl.ifBlank { artwork }
            if (art.isNotBlank()) Glide.with(this).load(BackendEndpoint.imageProxyUrl(art)).diskCacheStrategy(DiskCacheStrategy.ALL).centerCrop().into(image)
            frame.contentDescription = labelText
            frame.setOnFocusChangeListener { v, hasFocus ->
                v.animate().scaleX(if (hasFocus) 1.08f else 1f).scaleY(if (hasFocus) 1.08f else 1f).setDuration(120).start()
                v.alpha = if (hasFocus) 1f else 0.94f
            }
            frame.setOnClickListener {
                item?.let {
                    startActivity(Intent(this, MediaDetailsActivity::class.java).apply {
                        putExtra(EXTRA_TITLE, it.title)
                        putExtra(EXTRA_META_LINE, it.meta)
                        putExtra(EXTRA_DESC, it.overview)
                        putExtra(EXTRA_MEDIA_TYPE, it.type)
                        putExtra(EXTRA_EXTERNAL_ID, it.externalId)
                        putExtra(EXTRA_POSTER_URL, it.posterUrl)
                        putExtra(EXTRA_BACKDROP_URL, it.backdropUrl)
                        putExtra(EXTRA_LOGO_URL, it.logoUrl)
                    })
                }
            }
            row.addView(frame, LinearLayout.LayoutParams(dp(142), dp(213)).apply { marginEnd = dp(14) })
        }
        repeat(4) { index -> addRelatedCard(if (index == 0) title else "Loading…", artwork) }
        trailerExecutor.execute {
            val related = UnifiedCatalogRepository(this).relatedItems(title, mediaType, externalId).take(10)
            runOnUiThread {
                if (isFinishing || isDestroyed || related.isEmpty()) return@runOnUiThread
                row.removeAllViews()
                related.forEach { item -> addRelatedCard(item.title, item.posterUrl.ifBlank { item.backdropUrl }, item) }
            }
        }
    }


    private fun upgradeArtworkUrl(url: String): String {
        return BackendEndpoint.imageProxyUrl(url)
    }

    private fun makePillDrawable(fill: Int, stroke: Int): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = 18f
            setColor(fill)
            setStroke(1, stroke)
        }
    }

    private data class CastMember(
        val name: String,
        val role: String,
        val imageUrl: String = "",
        val source: String = ""
    )

    private data class TrailerStream(
        val playbackUrl: String,
        val audioUrl: String = "",
        val mimeType: String,
        val audioMimeType: String = "",
        val quality: String,
        val allow4k: Boolean = false
    )

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_META_LINE = "meta_line"
        const val EXTRA_DESC = "desc"
        const val EXTRA_MEDIA_TYPE = "media_type"
        const val EXTRA_EXTERNAL_ID = "external_id"
        const val EXTRA_POSTER_URL = "poster_url"
        const val EXTRA_BACKDROP_URL = "backdrop_url"
        const val EXTRA_LOGO_URL = "logo_url"
    }
}
