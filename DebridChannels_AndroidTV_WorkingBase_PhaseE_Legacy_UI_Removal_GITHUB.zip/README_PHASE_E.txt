Debrid Channels Android TV — Phase E

Build: NewtoOld_v2.8.26.81_APPLE_PARITY_LEGACY_UI_REMOVAL_PHASE_E
Base: Phase D v2.8.26.80

This ZIP removes the superseded Android UI routes, removes Pro Editor completely from the runtime app, rebuilds Settings with the Apple-style category/content shell, and guarantees Home, Movies, and TV Shows open catalog-row experiences backed by the existing repositories.

Playback, resolver, debrid, Live TV, guide, networking, storage, settings data, favorites/history, and Phase D playback presentation remain protected.

See ANDROID_APPLE_PARITY_PHASE_E_LEGACY_UI_REMOVAL.md for the exact removals, protected systems, and device checklist.
