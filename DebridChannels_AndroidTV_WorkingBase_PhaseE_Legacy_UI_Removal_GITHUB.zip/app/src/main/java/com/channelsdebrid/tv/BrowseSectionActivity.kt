package com.channelsdebrid.tv

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.channelsdebrid.tv.data.UnifiedCatalogRepository
import com.channelsdebrid.tv.playback.MediaDetailsActivity
import com.channelsdebrid.tv.playback.PlayerActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Phase E catalog shell. Movies and TV Shows use the same Apple-parity chrome as
 * Home and Live TV while continuing to consume the protected catalog repository.
 */
class BrowseSectionActivity : AppCompatActivity() {
    private lateinit var repo: UnifiedCatalogRepository
    private lateinit var rows: LinearLayout
    private lateinit var heroTitle: TextView
    private lateinit var heroMeta: TextView
    private lateinit var heroBg: ImageView
    private lateinit var topNav: LinearLayout
    private lateinit var searchButton: TextView
    private lateinit var clockView: TextView
    private var activeNav: TextView? = null
    private var firstCatalogCard: View? = null
    private var section = "movies"
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var loadVersion = 0
    private val firstPageSize = 36
    private val nextPageSize = 18
    private val clockRunnable = object : Runnable {
        override fun run() {
            if (::clockView.isInitialized) {
                clockView.text = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            }
            main.postDelayed(this, 30_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = UnifiedCatalogRepository(this)
        section = normalizeSection(intent.getStringExtra(EXTRA_SECTION))
        setContentView(buildLayout())
        renderSection(requestContentFocus = true)
        main.post(clockRunnable)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val next = normalizeSection(intent.getStringExtra(EXTRA_SECTION))
        if (next != section) {
            section = next
            renderSection(requestContentFocus = true)
        }
    }

    private fun normalizeSection(raw: String?): String = if (raw.equals("shows", true) || raw.equals("tv", true) || raw.equals("series", true)) "shows" else "movies"
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildLayout(): View {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        heroBg = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.48f
            setBackgroundColor(Color.BLACK)
        }
        root.addView(heroBg, FrameLayout.LayoutParams(-1, dp(350)))
        root.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x42000000, 0xA0000000.toInt(), 0xFF000000.toInt())
            )
        }, FrameLayout.LayoutParams(-1, dp(390)))

        val chrome = buildTopChrome()
        root.addView(chrome, FrameLayout.LayoutParams(-1, dp(64), Gravity.TOP))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(42), dp(78), dp(42), 0)
            clipChildren = false
            clipToPadding = false
        }
        heroTitle = TextView(this).apply {
            textSize = 38f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
        }
        heroMeta = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFD7CCBF.toInt())
            setPadding(0, dp(5), 0, dp(18))
            maxLines = 2
        }
        content.addView(heroTitle)
        content.addView(heroMeta)

        val scroll = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            isFillViewport = false
            clipChildren = false
            clipToPadding = false
            isFocusable = false
        }
        rows = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            setPadding(0, dp(178), 0, dp(54))
        }
        scroll.addView(rows)
        content.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(content)
        return root
    }

    private fun buildTopChrome(): View {
        val bar = FrameLayout(this)
        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(this@BrowseSectionActivity).apply {
                text = "DEBRID"
                textSize = 9f
                setTextColor(0xFFE5E5E5.toInt())
                typeface = Typeface.DEFAULT_BOLD
                letterSpacing = 0.18f
                includeFontPadding = false
            })
            addView(TextView(this@BrowseSectionActivity).apply {
                text = "CHANNELS"
                textSize = 8f
                setTextColor(0xFFD98A45.toInt())
                typeface = Typeface.DEFAULT_BOLD
                letterSpacing = 0.14f
                includeFontPadding = false
            })
        }
        bar.addView(brand, FrameLayout.LayoutParams(dp(116), dp(48), Gravity.START or Gravity.TOP).apply { leftMargin = dp(28); topMargin = dp(8) })

        topNav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            clipChildren = false
        }
        val entries = listOf(
            "Home" to "home",
            "Movies" to "movies",
            "TV Shows" to "shows",
            "Sports" to "sports",
            "Favorites" to "favorites",
            "Live TV" to "live",
            "Settings" to "settings"
        )
        entries.forEachIndexed { index, entry ->
            val tab = TextView(this).apply {
                text = entry.first
                tag = entry.second
                textSize = 14f
                gravity = Gravity.CENTER
                isFocusable = true
                isClickable = true
                setPadding(dp(12), 0, dp(12), 0)
                setOnClickListener { handleTopAction(entry.second) }
                setOnFocusChangeListener { v, focused ->
                    val tv = v as TextView
                    val selected = tv.tag == section
                    tv.setTextColor(if (focused || selected) Color.WHITE else 0xFF8F8F8F.toInt())
                    v.animate().scaleX(if (focused) 1.018f else 1f).scaleY(if (focused) 1.018f else 1f).setDuration(110).start()
                }
                setOnKeyListener { _, keyCode, event ->
                    if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                    when (keyCode) {
                        KeyEvent.KEYCODE_DPAD_DOWN -> { firstCatalogCard?.requestFocus(); true }
                        KeyEvent.KEYCODE_DPAD_LEFT -> { topNav.getChildAt((index - 1).coerceAtLeast(0))?.requestFocus(); true }
                        KeyEvent.KEYCODE_DPAD_RIGHT -> {
                            if (index == entries.lastIndex) searchButton.requestFocus() else topNav.getChildAt(index + 1)?.requestFocus()
                            true
                        }
                        else -> false
                    }
                }
            }
            topNav.addView(tab, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(50)).apply { leftMargin = dp(2); rightMargin = dp(2) })
        }
        bar.addView(topNav, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(50), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(7) })

        searchButton = TextView(this).apply {
            text = "⌕"
            textSize = 25f
            setTextColor(0xFFD9D9D9.toInt())
            gravity = Gravity.CENTER
            isFocusable = true
            isClickable = true
            setOnClickListener { startActivity(Intent(this@BrowseSectionActivity, SearchActivity::class.java)) }
            setOnFocusChangeListener { v, focused -> v.animate().scaleX(if (focused) 1.08f else 1f).scaleY(if (focused) 1.08f else 1f).setDuration(110).start() }
            setOnKeyListener { _, keyCode, event ->
                if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> { topNav.getChildAt(topNav.childCount - 1)?.requestFocus(); true }
                    KeyEvent.KEYCODE_DPAD_DOWN -> { firstCatalogCard?.requestFocus(); true }
                    else -> false
                }
            }
        }
        clockView = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFFD9D9D9.toInt())
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val utilities = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(searchButton, LinearLayout.LayoutParams(dp(42), dp(42)))
            addView(clockView, LinearLayout.LayoutParams(dp(82), dp(42)))
        }
        bar.addView(utilities, FrameLayout.LayoutParams(dp(124), dp(48), Gravity.TOP or Gravity.END).apply { rightMargin = dp(22); topMargin = dp(7) })
        return bar
    }

    private fun handleTopAction(action: String) {
        when (action) {
            "home", "favorites" -> startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            "movies", "shows" -> {
                section = action
                renderSection(requestContentFocus = true)
            }
            "live", "sports" -> startActivity(Intent(this, LiveTvActivity::class.java))
            "settings" -> startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun updateTopNavigation() {
        activeNav = null
        for (i in 0 until topNav.childCount) {
            val tab = topNav.getChildAt(i) as? TextView ?: continue
            val selected = tab.tag == section
            tab.background = if (selected) ContextCompat.getDrawable(this, R.drawable.apple_nav_live_active) else null
            tab.setTextColor(if (selected) Color.WHITE else 0xFF8F8F8F.toInt())
            tab.typeface = Typeface.create("sans-serif", if (selected) Typeface.BOLD else Typeface.NORMAL)
            if (selected) activeNav = tab
        }
    }

    private fun renderSection(requestContentFocus: Boolean) {
        updateTopNavigation()
        val title = if (section == "shows") "TV Shows" else "Movies"
        heroTitle.text = title
        heroMeta.text = if (section == "shows") {
            "Catalog rows from TMDB, Cinemeta, Stremio and installed add-ons"
        } else {
            "Movie catalog rows from TMDB, Cinemeta, Stremio and installed add-ons"
        }
        firstCatalogCard = null
        val version = ++loadVersion
        rows.removeAllViews()
        val cachedRows = repo.cachedDiscoveryRows(section)
        if (cachedRows.isNotEmpty()) {
            cachedRows.forEachIndexed { index, row -> addRow(row, index == 0) }
            cachedRows.firstOrNull()?.items?.firstOrNull()?.let { updateHero(it) }
            if (requestContentFocus) rows.post { firstCatalogCard?.requestFocus() }
        } else {
            rows.addView(loadingRow("Loading ${title.lowercase()} catalog rows…"))
        }
        executor.execute {
            val discoveryRows = repo.discoveryRows(section)
            repo.preloadArtwork(discoveryRows.flatMap { it.items }.take(60))
            runOnUiThread {
                if (version != loadVersion || isFinishing || isDestroyed) return@runOnUiThread
                rows.removeAllViews()
                firstCatalogCard = null
                if (discoveryRows.isEmpty()) {
                    rows.addView(loadingRow("No ${title.lowercase()} rows are available. Add a TMDB key or Stremio catalog add-on in Settings."))
                    return@runOnUiThread
                }
                discoveryRows.forEachIndexed { index, row -> addRow(row, index == 0) }
                discoveryRows.firstOrNull()?.items?.firstOrNull()?.let { updateHero(it) }
                if (requestContentFocus) rows.post { firstCatalogCard?.requestFocus() }
            }
        }
    }

    private fun loadingRow(text: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(18), 0, dp(18))
        addView(ProgressBar(this@BrowseSectionActivity).apply { isIndeterminate = true }, LinearLayout.LayoutParams(dp(28), dp(28)).apply { rightMargin = dp(12) })
        addView(TextView(this@BrowseSectionActivity).apply {
            this.text = text
            textSize = 18f
            setTextColor(0xCCFFFFFF.toInt())
        })
    }

    private fun addRow(row: UnifiedCatalogRepository.CatalogRow, isTopRow: Boolean) {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(8))
        }
        header.addView(TextView(this).apply {
            text = row.title
            textSize = 20f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(TextView(this).apply {
            text = row.source.ifBlank { "Catalog" }
            textSize = 12f
            setTextColor(0x889999A0.toInt())
        })
        rows.addView(header)

        val scroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipChildren = false
            clipToPadding = false
        }
        val lane = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            clipToPadding = false
            setPadding(dp(3), dp(4), dp(3), dp(10))
        }
        val visible = row.items.take(firstPageSize).toMutableList()
        visible.forEach { lane.addView(landscapeCard(it, isTopRow)) }
        if (row.items.size > visible.size) lane.addView(loadMoreCard(row, lane, visible, isTopRow))
        scroller.addView(lane)
        rows.addView(scroller, LinearLayout.LayoutParams(-1, dp(174)).apply { bottomMargin = dp(11) })
    }

    private fun loadMoreCard(row: UnifiedCatalogRepository.CatalogRow, lane: LinearLayout, visible: MutableList<UnifiedCatalogRepository.MediaItem>, isTopRow: Boolean): View {
        val frame = FrameLayout(this).apply {
            isFocusable = true
            isClickable = true
            background = rounded(0xFF151519.toInt(), 0x2AFFFFFF, dp(15), dp(1))
            layoutParams = LinearLayout.LayoutParams(dp(238), dp(134)).apply { rightMargin = dp(16) }
        }
        frame.addView(TextView(this).apply {
            text = "Load More"
            textSize = 17f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }, FrameLayout.LayoutParams(-1, -1))
        frame.setOnFocusChangeListener { v, hasFocus ->
            v.animate().scaleX(if (hasFocus) 1.045f else 1f).scaleY(if (hasFocus) 1.045f else 1f).setDuration(120).start()
        }
        frame.setOnKeyListener { _, keyCode, event ->
            if (isTopRow && event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_UP) {
                activeNav?.requestFocus(); true
            } else false
        }
        frame.setOnClickListener {
            val start = visible.size
            val next = row.items.drop(start).take(nextPageSize)
            if (next.isEmpty()) return@setOnClickListener
            lane.removeView(frame)
            next.forEach { item -> visible.add(item); lane.addView(landscapeCard(item, isTopRow)) }
            if (visible.size < row.items.size) lane.addView(loadMoreCard(row, lane, visible, isTopRow))
        }
        return frame
    }

    private fun landscapeCard(item: UnifiedCatalogRepository.MediaItem, isTopRow: Boolean): View {
        val frame = FrameLayout(this).apply {
            isFocusable = true
            isClickable = true
            background = rounded(0xFF101014.toInt(), 0, dp(15), 0)
            layoutParams = LinearLayout.LayoutParams(dp(238), dp(134)).apply { rightMargin = dp(16) }
        }
        if (firstCatalogCard == null) firstCatalogCard = frame
        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFF0B0B0E.toInt())
            clipToOutline = true
        }
        frame.addView(img, FrameLayout.LayoutParams(-1, -1))
        frame.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0x25000000, 0xD0000000.toInt()))
        }, FrameLayout.LayoutParams(-1, -1))
        frame.addView(TextView(this).apply {
            text = item.title
            textSize = 13.5f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.BOTTOM or Gravity.START
            setPadding(dp(11), 0, dp(11), dp(10))
            maxLines = 2
        }, FrameLayout.LayoutParams(-1, -1))
        val art = item.backdropUrl.ifBlank { item.posterUrl }
        if (art.isNotBlank()) {
            Glide.with(this)
                .load(com.channelsdebrid.tv.net.BackendEndpoint.imageProxyUrl(art))
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .centerCrop()
                .thumbnail(0.15f)
                .into(img)
        }
        frame.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) updateHero(item)
            v.background = if (hasFocus) rounded(0xFF101014.toInt(), Color.WHITE, dp(15), dp(2)) else rounded(0xFF101014.toInt(), 0, dp(15), 0)
            v.animate().scaleX(if (hasFocus) 1.048f else 1f).scaleY(if (hasFocus) 1.048f else 1f).translationY(if (hasFocus) -dp(3).toFloat() else 0f).setDuration(120).start()
        }
        frame.setOnKeyListener { _, keyCode, event ->
            if (isTopRow && event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_UP) {
                activeNav?.requestFocus(); true
            } else false
        }
        frame.setOnClickListener { openItem(item) }
        return frame
    }

    private fun updateHero(item: UnifiedCatalogRepository.MediaItem) {
        heroTitle.text = item.title
        heroMeta.text = listOf(if (item.type == "series") "TV Show" else "Movie", item.meta).filter { it.isNotBlank() }.joinToString("  •  ")
        val art = item.backdropUrl.ifBlank { item.posterUrl }
        if (art.isNotBlank()) {
            Glide.with(this).load(com.channelsdebrid.tv.net.BackendEndpoint.imageProxyUrl(art)).diskCacheStrategy(DiskCacheStrategy.ALL).centerCrop().thumbnail(0.15f).into(heroBg)
        }
    }

    private fun openItem(item: UnifiedCatalogRepository.MediaItem) {
        if (item.type == "live" && item.streamUrl.isNotBlank()) {
            startActivity(Intent(this, PlayerActivity::class.java).apply {
                putExtra(PlayerActivity.EXTRA_STREAM_URL, item.streamUrl)
                putExtra(PlayerActivity.EXTRA_TITLE, item.title)
                putExtra(PlayerActivity.EXTRA_SOURCE_LABEL, item.meta)
            })
            return
        }
        startActivity(Intent(this, MediaDetailsActivity::class.java).apply {
            putExtra(MediaDetailsActivity.EXTRA_TITLE, item.title)
            putExtra(MediaDetailsActivity.EXTRA_META_LINE, item.meta)
            putExtra(MediaDetailsActivity.EXTRA_DESC, item.overview)
            putExtra(MediaDetailsActivity.EXTRA_MEDIA_TYPE, if (item.type == "series") "series" else "movie")
            putExtra(MediaDetailsActivity.EXTRA_EXTERNAL_ID, item.externalId)
            putExtra(MediaDetailsActivity.EXTRA_POSTER_URL, item.posterUrl)
            putExtra(MediaDetailsActivity.EXTRA_BACKDROP_URL, item.backdropUrl)
            putExtra(MediaDetailsActivity.EXTRA_LOGO_URL, item.logoUrl)
        })
    }

    override fun onDestroy() {
        main.removeCallbacks(clockRunnable)
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int, strokeWidth: Int) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(fill)
        cornerRadius = radius.toFloat()
        if (strokeWidth > 0) setStroke(strokeWidth, stroke)
    }

    companion object { const val EXTRA_SECTION = "section" }
}
