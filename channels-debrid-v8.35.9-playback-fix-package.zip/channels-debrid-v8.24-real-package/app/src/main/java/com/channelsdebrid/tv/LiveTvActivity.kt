package com.channelsdebrid.tv

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.channelsdebrid.tv.playback.PlayerActivity
import com.channelsdebrid.tv.settings.SettingsRepository
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class LiveTvActivity : AppCompatActivity() {

    private lateinit var settingsRepository: SettingsRepository
    private lateinit var statusText: TextView
    private lateinit var channelList: LinearLayout
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_live_tv)
        settingsRepository = SettingsRepository(this)

        statusText = findViewById(R.id.liveTvStatus)
        channelList = findViewById(R.id.liveTvChannelList)

        findViewById<View>(R.id.liveTvBackButton).setOnClickListener { finish() }
        loadChannels()
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    private fun loadChannels() {
        statusText.text = "Checking configured Live TV sources…"
        channelList.removeAllViews()

        val dvr = settingsRepository.loadChannelsDvr()
        val xtream = settingsRepository.loadXtream()

        executor.execute {
            val result = when {
                dvr.baseUrl.isNotBlank() -> loadDvrChannels(dvr.baseUrl)
                xtream.enabled && xtream.server.isNotBlank() && xtream.username.isNotBlank() && xtream.password.isNotBlank() ->
                    loadXtreamChannels(xtream.server, xtream.username, xtream.password)
                else -> LoadResult(emptyList(), "No source configured. Add Channels DVR or Xtream in Settings.")
            }

            runOnUiThread {
                if (result.channels.isEmpty()) {
                    statusText.text = result.message
                    Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
                } else {
                    statusText.text = result.message
                    result.channels.take(200).forEachIndexed { index, channel ->
                        channelList.addView(makeChannelRow(index + 1, channel))
                    }
                }
            }
        }
    }

    private fun makeChannelRow(index: Int, channel: ChannelItem): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14))
            isFocusable = true
            isClickable = true
            background = getDrawable(R.drawable.pill_dark)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.bottomMargin = dp(12)
            layoutParams = lp
            setOnClickListener {
                startActivity(
                    Intent(this@LiveTvActivity, PlayerActivity::class.java)
                        .putExtra(PlayerActivity.EXTRA_STREAM_URL, channel.url)
                        .putExtra(PlayerActivity.EXTRA_TITLE, channel.name)
                )
            }
            setOnFocusChangeListener { v, hasFocus ->
                v.animate().cancel()
                v.animate().scaleX(if (hasFocus) 1.03f else 1f)
                    .scaleY(if (hasFocus) 1.03f else 1f)
                    .alpha(if (hasFocus) 1f else 0.96f)
                    .setDuration(140)
                    .start()
            }
        }

        val num = TextView(this).apply {
            text = index.toString().padStart(2, '0')
            setTextColor(0xFFEDEDED.toInt())
            textSize = 15f
            setPadding(0, 0, dp(16), 0)
        }
        val name = TextView(this).apply {
            text = channel.name
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 17f
            setSingleLine(true)
            ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val source = TextView(this).apply {
            text = channel.source
            setTextColor(0xFFB7BDC6.toInt())
            textSize = 13f
        }

        row.addView(num)
        row.addView(name)
        row.addView(source)
        return row
    }

    private fun loadDvrChannels(baseUrl: String): LoadResult {
        val base = baseUrl.trim().trimEnd('/')

        // First try ANY, then discover actual devices and retry.
        val candidates = mutableListOf("ANY")
        val deviceProbe = getJson("$base/devices")
        if (deviceProbe.body != null) {
            candidates.addAll(parseDeviceNames(deviceProbe.body))
        }

        for (device in candidates.distinct()) {
            val encodedDevice = URLEncoder.encode(device, "UTF-8")
            val probe = getJson("$base/devices/$encodedDevice/channels")
            if (probe.error != null) continue
            val parsed = parseDvrChannels(base, device, probe.body ?: "")
            if (parsed.isNotEmpty()) {
                return LoadResult(parsed, "Channels DVR connected • ${parsed.size} channels found ($device)")
            }
        }

        // If nothing found, provide the best debug message we can.
        return when {
            deviceProbe.error != null -> LoadResult(emptyList(), "Channels DVR failed: ${deviceProbe.error}")
            else -> LoadResult(emptyList(), "Channels DVR connected, but no channels were returned.")
        }
    }

    private fun parseDeviceNames(json: String): List<String> {
        val names = mutableListOf<String>()
        try {
            if (json.trim().startsWith("[")) {
                val arr = JSONArray(json)
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val name = obj.optString("Name")
                        .ifBlank { obj.optString("name") }
                        .ifBlank { obj.optString("ID") }
                        .ifBlank { obj.optString("id") }
                    if (name.isNotBlank()) names += name
                }
            } else {
                val root = JSONObject(json)
                val arr = root.optJSONArray("devices") ?: root.optJSONArray("Devices")
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i) ?: continue
                        val name = obj.optString("Name")
                            .ifBlank { obj.optString("name") }
                            .ifBlank { obj.optString("ID") }
                            .ifBlank { obj.optString("id") }
                        if (name.isNotBlank()) names += name
                    }
                }
            }
        } catch (_: Exception) { }
        return names
    }

    private fun parseDvrChannels(base: String, device: String, json: String): List<ChannelItem> {
        val out = mutableListOf<ChannelItem>()
        try {
            val arr = if (json.trim().startsWith("[")) {
                JSONArray(json)
            } else {
                val root = JSONObject(json)
                root.optJSONArray("channels")
                    ?: root.optJSONArray("Channels")
                    ?: JSONArray()
            }

            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue

                val guideNumber = obj.optString("GuideNumber")
                    .ifBlank { obj.optString("Number") }
                    .ifBlank { obj.optString("number") }

                val id = obj.optString("id")
                    .ifBlank { obj.optString("ID") }
                    .ifBlank { guideNumber }

                val name = obj.optString("GuideName")
                    .ifBlank { obj.optString("Name") }
                    .ifBlank { obj.optString("name") }
                    .ifBlank { obj.optString("channel") }
                    .ifBlank { "Channel ${if (guideNumber.isNotBlank()) guideNumber else id}" }

                var url = obj.optString("URL")
                    .ifBlank { obj.optString("stream_url") }

                if (url.isNotBlank() && url.startsWith("/")) {
                    url = base + url
                }

                if (url.isBlank() && id.isNotBlank()) {
                    val encodedDevice = URLEncoder.encode(device, "UTF-8")
                    url = "$base/devices/$encodedDevice/channels/$id/stream.mpg?format=ts&codec=copy"
                }

                if (url.isNotBlank()) {
                    out += ChannelItem(name, url, "Channels DVR")
                }
            }
        } catch (_: Exception) { }
        return out
    }

    private fun loadXtreamChannels(server: String, user: String, pass: String): LoadResult {
        val base = server.trim().trimEnd('/')
        val probe = getJson("$base/player_api.php?username=$user&password=$pass&action=get_live_streams")
        if (probe.error != null) {
            return LoadResult(emptyList(), "Xtream failed: ${probe.error}")
        }
        val json = probe.body ?: return LoadResult(emptyList(), "Xtream returned no data.")
        val arr = try {
            JSONArray(json)
        } catch (_: Exception) {
            return LoadResult(emptyList(), "Xtream returned invalid JSON.")
        }
        val items = mutableListOf<ChannelItem>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val id = obj.optString("stream_id")
            if (id.isBlank()) continue
            val ext = obj.optString("container_extension").ifBlank { "m3u8" }
            val name = obj.optString("name").ifBlank { "Channel $id" }
            val url = "$base/live/$user/$pass/$id.$ext"
            items += ChannelItem(name, url, "Xtream/IPTV")
        }
        return if (items.isEmpty()) {
            LoadResult(emptyList(), "Xtream connected, but no channels were returned.")
        } else {
            LoadResult(items, "Xtream connected • ${items.size} channels found")
        }
    }

    private fun getJson(url: String): HttpResult {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 6000
        connection.readTimeout = 6000
        connection.instanceFollowRedirects = true
        connection.requestMethod = "GET"
        return try {
            connection.connect()
            val code = connection.responseCode
            if (code !in 200..299) {
                HttpResult(null, "HTTP $code")
            } else {
                val body = BufferedReader(InputStreamReader(connection.inputStream)).use { it.readText() }
                HttpResult(body, null)
            }
        } catch (e: Exception) {
            HttpResult(null, e.javaClass.simpleName + (e.message?.let { ": $it" } ?: ""))
        } finally {
            connection.disconnect()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    data class ChannelItem(
        val name: String,
        val url: String,
        val source: String
    )

    data class LoadResult(
        val channels: List<ChannelItem>,
        val message: String
    )

    data class HttpResult(
        val body: String?,
        val error: String?
    )
}
