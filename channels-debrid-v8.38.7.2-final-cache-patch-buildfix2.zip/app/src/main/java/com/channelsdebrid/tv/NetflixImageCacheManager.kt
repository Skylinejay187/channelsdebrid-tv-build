package com.channelsdebrid.tv

import android.content.Context
import com.bumptech.glide.Glide
import com.bumptech.glide.MemoryCategory
import com.bumptech.glide.Priority
import com.bumptech.glide.load.engine.DiskCacheStrategy
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

object NetflixImageCacheManager {
    private const val PREFS_NAME = "netflix_image_cache"
    private const val KEY_HOT_URLS = "hot_urls"
    private const val MAX_HOT_URLS = 1400

    private val rememberedUrls = linkedSetOf<String>()
    private val inFlightRequests = ConcurrentHashMap.newKeySet<String>()
    private val executor = Executors.newFixedThreadPool(3)
    @Volatile private var initialized = false

    @Synchronized
    fun initialize(context: Context) {
        if (initialized) return
        initialized = true
        Glide.get(context.applicationContext).setMemoryCategory(MemoryCategory.HIGH)
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_HOT_URLS, "")
            .orEmpty()
        raw.lineSequence()
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .forEach { rememberedUrls.add(it) }
        warmRememberedSet(context.applicationContext, 220)
    }

    fun registerAndWarm(
        context: Context,
        url: String?,
        widthsHeights: List<Pair<Int, Int>>,
        priority: Priority = Priority.HIGH,
        warmOriginalFile: Boolean = true
    ) {
        val normalized = url?.trim().orEmpty()
        if (normalized.isBlank()) return
        rememberUrl(context.applicationContext, normalized)
        widthsHeights.distinct().forEach { (width, height) ->
            warmSized(context.applicationContext, normalized, width, height, priority)
        }
        if (warmOriginalFile) {
            warmOriginal(context.applicationContext, normalized)
        }
    }

    fun warmRememberedSet(context: Context, maxItems: Int = 320) {
        val urls = synchronized(this) { rememberedUrls.toList().takeLast(maxItems) }
        urls.forEach { url ->
            registerAndWarm(
                context.applicationContext,
                url,
                listOf(560 to 320, 980 to 560, 1200 to 420, 1920 to 1080, 3840 to 2160),
                priority = Priority.LOW,
                warmOriginalFile = true
            )
        }
    }

    @Synchronized
    private fun rememberUrl(context: Context, url: String) {
        if (rememberedUrls.add(url)) {
            while (rememberedUrls.size > MAX_HOT_URLS) {
                val iterator = rememberedUrls.iterator()
                if (iterator.hasNext()) {
                    iterator.next()
                    iterator.remove()
                } else {
                    break
                }
            }
            persist(context)
        }
    }

    @Synchronized
    private fun persist(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_HOT_URLS, rememberedUrls.joinToString("\n"))
            .apply()
    }

    private fun warmSized(context: Context, url: String, width: Int, height: Int, priority: Priority) {
        val key = "res:${width}x${height}:$url"
        if (!inFlightRequests.add(key)) return
        executor.execute {
            try {
                Glide.with(context)
                    .load(url)
                    .priority(priority)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .skipMemoryCache(false)
                    .override(width, height)
                    .preload(width, height)
            } catch (_: Throwable) {
            } finally {
                inFlightRequests.remove(key)
            }
        }
    }

    private fun warmOriginal(context: Context, url: String) {
        val key = "file:$url"
        if (!inFlightRequests.add(key)) return
        executor.execute {
            try {
                Glide.with(context)
                    .asFile()
                    .load(url)
                    .priority(Priority.LOW)
                    .diskCacheStrategy(DiskCacheStrategy.DATA)
                    .submit()
                    .get()
            } catch (_: Throwable) {
            } finally {
                inFlightRequests.remove(key)
            }
        }
    }
}
