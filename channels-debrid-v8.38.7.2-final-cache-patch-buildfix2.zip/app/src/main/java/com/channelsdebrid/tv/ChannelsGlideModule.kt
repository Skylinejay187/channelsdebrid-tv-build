package com.channelsdebrid.tv

import android.content.Context
import com.bumptech.glide.GlideBuilder
import com.bumptech.glide.annotation.GlideModule
import com.bumptech.glide.load.engine.cache.InternalCacheDiskCacheFactory
import com.bumptech.glide.load.engine.cache.LruResourceCache
import com.bumptech.glide.load.engine.bitmap_recycle.LruBitmapPool
import com.bumptech.glide.module.AppGlideModule

@GlideModule
class ChannelsGlideModule : AppGlideModule() {
    override fun applyOptions(context: Context, builder: GlideBuilder) {
        builder.setDiskCache(InternalCacheDiskCacheFactory(context, "channels_image_cache", 1024L * 1024L * 1024L * 2L))
        builder.setMemoryCache(LruResourceCache(1024L * 1024L * 320L))
        builder.setBitmapPool(LruBitmapPool(1024L * 1024L * 160L))
    }

    override fun isManifestParsingEnabled(): Boolean = false
}
