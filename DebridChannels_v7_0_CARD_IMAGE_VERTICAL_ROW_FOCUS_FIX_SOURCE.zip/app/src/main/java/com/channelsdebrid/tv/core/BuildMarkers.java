package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v7.0 CARD_IMAGE_VERTICAL_ROW_FOCUS_FIX";
    public static final String LOG_MARKER = "DC_V7_0_CARD_IMAGE_VERTICAL_ROW_FOCUS_FIX";
    private BuildMarkers() {}
}
