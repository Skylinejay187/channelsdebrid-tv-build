# Signal Android TV checkpoint

Base: DebridChannels_AndroidTV_Restart_PhaseA1_Apple_UI_Precision_GITHUB.zip.
Current parity reference: Signal_F143_1252_Main_Catalog_Masking.zip. The F143 Swift sources were inspected from a read-only reference copy.

The Media3PlaybackController implements the existing PlaybackController boundary with an owned ExoPlayer. It accepts resolved HTTP(S) Live and VOD URLs, uses per-source HTTP headers, and supports explicit MIME types for extensionless HLS/DASH URLs. Live uses the media source's default position and VOD uses its requested resume point. An accepted result means preparation was submitted. Playback failures arrive asynchronously through Player.Listener. The blueprint currently still uses its stub controller.

Verified: Kotlin 2.0.21 compiled the adapter together with all core model and data sources against Media3 1.6.1 classes and Android APIs. The Gradle wrapper failed to resolve services.gradle.org in this environment. APK, emulator, real stream playback and remote focus remain unverified.

Next: bind the controller to a lifecycle-owned player surface through the existing FunctionalCore boundary, first using a deterministic test stream. Observe playback states and errors, and exercise screen exit/re-entry, VOD resume, and Live default position. Then connect resolved production stream URLs.

Artwork parity: F143's CatalogHeroForegroundDepth uses the upgraded original image URL and a backend-relative /api/artwork/foreground/v1 route with size=browse or master and model=hrsod1. It keeps the base image visible while the matching cutout loads. Port this into the catalog hero before comparing artwork themes, Unity overlays, Cover Flow, and remote focus/playback controls against F143.

Skip Lite review: https://skip.dev/docs/modes/ describes Swift-to-Kotlin transpilation at module scope. Consider it for isolated Swift data transforms if reuse proves worthwhile. Keep the existing native Kotlin UI and Media3 controller as the Android foundation because the tvOS focus, composition, and playback stack require platform-specific integration. No Skip transpilation build was run.

## Checkpoint 02 — Android TV playback smoke screen

A debug-only activity uses the Media3PlaybackController through the PlaybackController contract and displays the Media3 PlayerView. It saves position and detaches/releases ExoPlayer when the activity stops. On return it creates a new player and seeks to the saved position. The debug activity accepts an optional initial position, uses a fixed public HTTPS MP4, and shows buffering and asynchronous player errors. Production navigation still uses the blueprint and has no dependency on the debug activity.

Verified on November 20, 2026. The Kotlin compiler compiled the screen, adapter, and core model/data modules against Media3 1.6.1, including media3-ui. The fixture returned HTTP 200 with video/mp4. The debug manifest parsed as XML. APK assembly stopped at Gradle's services.gradle.org DNS failure. No adb or emulator was available.

On an Android TV build host, assemble and install the debug APK, then run:

```sh
adb shell am start -n com.debridchannels.tv.debug/com.debridchannels.tv.PlaybackSmokeActivity --el positionMs 30000
```

Check start near 00:30, D-pad focus and play/pause, then Home and return to the existing activity to check resume. Back should exit the activity. Repeat with a network interruption to verify the error message. The next parity work can proceed independently by implementing and testing F143's foreground artwork URL selection while the Android test host is unavailable.

## Checkpoint 03 — Catalog hero artwork URLs

Added catalogHeroArtwork in core/data, using the F143 PremiumArtworkURL and CatalogHeroForegroundDepth implementations as references. It returns the upgraded base artwork and optional foreground URL. A Kotlin 2.0.21 JVM smoke run compiled the resolver and scripts/CatalogHeroArtworkSmoke.kt and passed checks for TMDB originals, nested query encoding, backend path prefixes, local and catalog assets, masking off, resolution choices, and invalid sources. No network requests were made by the checks.

Next, supply remote artwork from catalog items to the hero, keep the base image visible while loading, and draw the foreground only if it matches the currently focused item. Verify on Android TV with rapid focus changes and failed mask requests. APK assembly, playback and remote focus remain unverified.

## Checkpoint 04 — GitHub Actions sideload package

Extract the ZIP and commit its contents at repository root, including .github/workflows. Push to main or master, or run Build Debrid Channels Android TV manually in Actions. Download the Signal-AndroidTV-debug-APK artifact and extract app-debug.apk to sideload. CI uploads this debug APK before running unit tests, lint and release builds. Check those results separately.

The clean Compose boundary check passed. Local APK generation stopped during Gradle distribution download. Android TV installation and runtime behavior remain unverified. The next coding step from checkpoint 03 is unchanged.

## Checkpoint 05 — Focused catalog artwork

Home, Movies and TV Shows use the focused card for hero metadata and artwork. With no focused match, the first item from a nonempty row supplies the hero. Items can now carry a remote landscape URL. Compose scopes base and foreground requests to the item and resolved URLs, uses its bundled artwork during loading or base errors, and waits for the base to load before displaying its optional cutout. The standalone catalog currently supplies local artwork. The production remote catalog, backend settings and mask preference still need wiring. Browse mode uses the F143 default backend and browse resolution.

All nine core/data JVM tests and the artwork URL smoke passed, including four new focus-selection tests. Clean Compose boundary passed. APK assembly stopped during Gradle bootstrap because services.gradle.org did not resolve. Compose compilation, visual parity, fast D-pad changes, live mask loading and actual device playback remain unverified. The workflow now checks the APK signature before publishing the dedicated artifact.

docs/F143_SOURCE_COVERAGE.csv indexes source entries found under the two project.yml target source lists by path and content hash. Its partial entries cover only the named artwork behavior. Unreviewed entries are open work. Vendor packages, generated source and target exclusions require reconciliation before final parity sign-off. On the next run, map the F143 catalog response into MediaItem.landscapeUrl and exercise it with representative payloads, including missing artwork. Compare actual UI and mask failure behavior once an Android host is available.

## Checkpoint 06 — Official catalog batch

Home, Movies and TV Shows now request the official manifest and its advertised HTTPS batch endpoint on demand. A successful load is shared across these tabs while the app composition lives. Cards and detail artwork use remote images, with poster fallback for missing backgrounds. A failed fetch exposes Retry. Live TV startup does not initiate this fetch.

Verified all 11 core JVM tests, the artwork smoke and the Compose boundary check. The Kotlin mapper decoded the downloaded production manifest and batch: 82 rows, 2,450 cards, 2,436 with a different backdrop from their poster. The first local compiler pass exposed a Gson collection conversion issue, fixed before rerunning. Local Gradle bootstrap still failed to resolve services.gradle.org. No APK or device/UI test in this checkpoint. GitHub Actions retains the signature verification and dedicated debug APK artifact.

Next: implement an atomic last-known-good official catalog snapshot and a stale refresh path; compare F143 cache acceptance and expiry rules before accepting partial responses. Verify offline relaunch, refresh failure, device startup cost, rapid focus and mask display. Full source coverage remains open.

## Checkpoint 07 — Catalog restore and refresh

Opening a catalog tab restores the most recent valid private disk snapshot before fetching a replacement. Offline refresh failures leave restored rows visible. Live TV startup performs no catalog read. Both provisional and full catalogs use a versioned current/previous pair. Android uses typed row IDs to retain missing rows, keep rows truncated below 70%, and append new rows. F143 also handles title-based row migrations and separates full and provisional snapshots; those paths are pending. Android revalidates once per successful browsing session and retries after failed refresh on catalog re-entry. There is no age cutoff on offline restore.

Verified 15 core JVM tests, including cold-start completeness, offline repository recreation, partial response merge, and previous-file recovery after corruption. An actual downloaded production batch restored from disk with 82 rows and 2,450 entries. Artwork smoke, Compose boundary and ZIP checks passed. Android UI execution and signing remain unverified here. Gradle bootstrap failed to resolve services.gradle.org. No APK produced in this run.

Next: handle stable row identity when a manifest ID changes while its title and type remain the same. Compare row order, type corrections and duplicate titles against F143, and test before porting delta refresh. Device verification should include offline relaunch and a refresh while focus is on a restored row.

## Checkpoint 08 — Catalog row identity during refresh

The official manifest parser carries uniquely declared typed IDs into snapshot acceptance. The merge reserves exact IDs, then recognizes a manifest-confirmed type correction by raw ID, then matches unmatched rows by media type and normalized title. Normalization follows F143 trimming, lowercasing and space/hyphen/underscore removal. The replacement occupies the saved row's position. A confirmed type correction can replace a longer wrong-type row. Ambiguous title groups remain separate, an intentional difference from the Swift first-title lookup. New and existing files use the same snapshot format. UI focus restoration when a Compose row key changes requires device verification.

All 20 core JVM tests passed including five new migration and collision regressions. Artwork smoke and clean Compose checks passed. The Gradle wrapper could not resolve services.gradle.org, and the alternate distribution download probe timed out. No APK or Android TV device test this run. The ZIP retains the workflow's dedicated signed debug APK artifact.

Next: inspect the F143 revision-delta request/response contract and port fallback to full batch for stale, missing or invalid revisions. Exercise it against controlled changed/unchanged row fixtures and preserve the accepted snapshot on failures.

## Checkpoint 09 — Official catalog revision refresh

Entering the catalog from a non-catalog tab checks the manifest and asks the F143 delta endpoint for changed rows. Switching between Home, Movies and Shows shares the current result. Known revisions are session-local, scoped to the complete manifest and updated only after snapshot acceptance. The parser checks order size, unique keys, changed row count, sequence and revision agreement. On failure it falls back to the full catalog batch and defers another delta attempt for 60 seconds. Offline restore still uses the previous snapshot format.

Verified 24 core JVM tests, artwork smoke and Compose boundary checks. Two real POST responses were captured and replayed through Kotlin refresh and disk acceptance: the first contained 82 changed rows (3,624,560 bytes); the second had zero changes (14,711 bytes). Both restored to 82 rows and 2,450 cards. Local Gradle assembly stopped at services.gradle.org DNS lookup. No device run, APK, focus or playback verification.

Next: reuse the already mapped Kotlin rows for unchanged revisions, as Swift does, and verify that a no-change response avoids remapping artwork and metadata. Preserve freshness and rollback when snapshot acceptance fails. Test repeated enter/exit and focus restoration on Android hardware when available.

## Checkpoint 10 — Reuse mapped catalog rows

OfficialCatalogRefresh now stores a CatalogRow with each accepted revision. On warm refresh it decodes only changed rows using the same manifest rules as the full-batch path. Snapshot validation still runs and manifest changes invalidate the session cache. The change eliminates repeated artwork URL computation for unchanged cards. Disk restore, snapshot comparison and persistence are separate costs.

Verified 26 core JVM tests, including identity reuse, changed-row replacement and rollback after snapshot rejection. Fresh production delta responses replayed through the Kotlin refresh and actual disk store reused all 82 row objects and 2,450 cards; restored snapshot matched. The first Python HTTP POST got 403, and both repeated POSTs with curl succeeded. No Android HTTP transport or UI test was performed. Artwork smoke and clean Compose checks passed. Gradle assembly failed before compilation because services.gradle.org did not resolve.

Next: port and test F143 catalog page loading so a row can extend beyond the initial batch when browsing near the end. Check page offset, item deduplication, cancellation and retry against CatalogStore.swift before updating the coverage ledger. Verify focus continuity and latency on device once an APK is available.

## Checkpoint 11 — Manual catalog pagination

Settings → Streaming Catalogs → Reload official catalog fetches the current batch, expands likely truncated rows and passes the result through the existing validated snapshot store. Ordinary tab entry keeps the checkpoint 10 delta behavior. The F143 source limits this paging path to forced reloads. Android tries the query offset first and the path offset if the query errors, is empty or only repeats seen IDs. It advances by the raw metadata count, deduplicates within and across pages, stops on short/no-progress pages and checks the eight-page and 500-card thresholds before each request. Failed rows retain the pages obtained so far. The status reports the first failed row and offset and the same action can retry. Cancellation propagates between blocking requests. Android currently routes by typed batch row ID, and uses the existing snapshot acceptance rules.

31 core JVM tests passed, including five paging regressions for fallback, offsets, duplicate suppression, partial failure, bounded loading and cancellation. Artwork smoke and Compose boundary checks passed. Two live HTTP GETs for trending-movies returned 100 records each. At skip 30, the first 70 IDs matched the last 70 from the initial page in order and 30 IDs were new. This samples the HTTP contract. The full multirow reload and Settings UI have not run on Android. Local Gradle assembly stopped before compilation with UnknownHostException for services.gradle.org. No APK, signature check on a produced APK, device or emulator run.

Next: exercise manual reload through snapshot acceptance followed by normal delta refresh and offline relaunch. Check whether the size-based merge can drop extra pages or preserve stale seed cards. Compare with the Swift protected/provisional snapshot paths. Playback gating, request retry policy, focus continuity and reload latency remain unverified. File-level coverage is partial; no final-revision parity claim.

## Checkpoint 12 — Keep manually loaded pages across delta refresh and offline restore

A 46-row Kotlin fixture reproduced checkpoint 11 losing three of fifteen titles on the first row. A normal delta returned the same twelve first-page IDs with an updated title, and the 70% row acceptance rule discarded the three extra titles. Official manual paging now records the seed size alongside the stored row. A seed-only refresh with the same typed row ID, count and ordered item IDs updates the first page and reuses the recorded tail. Reordered or replaced first-page IDs use the existing Swift-based health rules. A successful manual page check can replace the tail. Snapshots written by earlier checkpoints decode without this optional field and acquire it on the next successful manual reload.

Android-specific refinement to the F143 CatalogStore.swift row selection around lines 3706–3764 and snapshot validation around lines 4076–4116. F143 also selects between fuller protected/rollback and provisional stores. Android still has current/previous files and a single acceptance path. The 70% guard may retain an older row if the seed changes and the replacement is severely shorter. Recovery after a later page fails during a multi-page manual recheck needs its own comparison.

All 35 core JVM tests passed. Four new end-to-end data tests use the production manual loader and disk store with fixture HTTP responses. The regression test also uses the delta loader, forbids a full-batch fallback, changes metadata and reconstructs the store for offline restore. Additional cases cover a changed seed, a shorter manual page and an empty manual page. Artwork smoke and Compose boundary checks passed. No Android build or sideload verification: local Gradle distribution lookup failed before compilation (services.gradle.org DNS). No device or emulator run.

Next: compare full, provisional and previous snapshot selection and atomic recovery against F143 lines 3685–3704 and 3820–3945. Test a damaged current snapshot, a fuller previous one, and same-size replacements carrying fresh metadata. Keep Android focus, playback and device relaunch verification open.

## Checkpoint 13 — Catalog rollback repair and full snapshot promotion

The Kotlin disk store now uses a protected current/previous pair for catalogs reaching 83 rows. The original file names remain readable for provisional and legacy full snapshots. Promotion keeps the last provisional copy for recovery if both protected files become unreadable. On restore and before accepting a refresh, the store selects the valid copy with the most rows. Rollback repair copies to a temporary file, flushes it and renames it over current while preserving the rollback. If repair runs out of writable space, offline restore can still return the decoded rollback. A refresh starting with a winning rollback does not rotate a smaller or corrupt current over it.

Mapped F143 CatalogStore.swift lines 3685–3704, 3832–3874, 3893–3957 and 4108–4115. Swift can rank equal-row copies by total item count. Android prefers current on a row-count tie within a pair, keeping newer metadata, confirmed type corrections and deliberately shortened manual pages. Protected copies win ties against provisional copies. Compact launch cache, in-memory candidate ranking and decoded snapshot caching remain open.

Three recovery regressions failed against checkpoint 12 before the changes. All 40 core JVM tests passed after implementation, including five new disk tests for damaged current, valid shorter current, provisional fallback after both protected copies fail, legacy promotion and refresh before recovery. Same-size metadata replacements and checkpoint 12 paging regressions passed. Artwork URL smoke and Compose boundary checks passed. Gradle assembly again failed before compilation because services.gradle.org did not resolve. No APK signature, emulator, remote, or hardware test was performed.

Next: inspect F143 catalog remote focus restoration and implement or test the Android path for leaving detail and returning to the same card, including restored and refreshed rows. Measure snapshot decoding and cold-start latency on Android TV when a runnable build is available.

## Checkpoint 14 — Return from catalog detail to the originating card

Home, Movies and Shows record the selected row ID, typed item and both indices when opening detail. The detail screen requests entry focus on its functioning Back action. After either Back route removes the overlay, the catalog resolves the target against the current rows. It requests scroll on each offscreen axis and focus on the composed card. The selected hero stays pinned through the handoff until the target reports focus. A duplicate elsewhere cannot override an exact source match. When the source disappears, Android looks for the same typed item on another shelf, then chooses the nearest available position. FocusSurface now uses the clickable control's own focus target for both the ring and remote activation.

F143 DebridChannelsTVOSApp.swift lines 11196–11222 and CatalogStore.swift lines 11449–11528 implement origin capture, popup handoff and hero anchoring. Android performs the handoff after overlay removal and currently compares type plus ID. Swift canonical aliases, nested detail returns, animation timing, menu focus locking and separate Favorites/Unity behavior need further work. A removed card's nearest-position fallback is an Android choice. No tvOS source edits.

45 core JVM tests passed, including five new focus resolver tests for duplicate shelves, changed row order and metadata, moved typed items, removed targets and empty rows. Artwork URL smoke and Compose boundary checks passed. Local assembleDebug stopped before compilation because services.gradle.org failed DNS resolution. No APK or Android UI execution; physical focus, D-pad activation, focus containment and hero continuity need device or emulator checks.

Next: add an Android UI regression that opens a duplicate title from the second row, changes the data while detail is open, closes via Back and checks focused card identity and D-pad activation. Exercise the same route on Android TV hardware and compare top-menu interference and artwork transitions against F143. Keep build and device status separate from resolver tests.

## Checkpoint 15 — Provider identity during catalog focus return and Android TV test

The Kotlin catalog mapper accepts IMDb, TMDB and TVDB fields in camelCase or snake_case. Older snapshots can omit these optional fields. Focus return now checks provider identity inside the originating shelf before searching other shelves. Exact normalized IDs take precedence over aliases within a shelf. Conflicting IDs for the same provider suppress an identity match, and different episode suffixes cannot match through a shared show ID. The existing positional fallback still applies if no identity matches. These changes map part of F143 CatalogStore.swift (StremioMeta decoding, inferred provider identifiers, canonical matching and the detail-dismissal handoff). Title/year-only matches, explicit season/episode metadata, alias normalization in other features and device behavior remain open.

Added CatalogDetailFocusTest to the Android instrumentation suite. It renders the production CatalogScreen and DetailScreen in a test host, focuses a duplicate on the second shelf, opens it with D-pad Center, changes its provider ID and position while details are visible, sends Android Back, asserts which shelf has focus, and reopens the card to check the refreshed metadata. Test fixtures use local artwork. It exercises the two UI components with fixture data; live networking, the app's top menu and physical remotes require separate checks.

The normal GitHub build publishes the dedicated signed debug APK before compiling the instrumentation APK. When manually running Build Debrid Channels Android TV, the test_tv_focus option starts an Android TV emulator and runs the new test, then collects its result files. A connected Android TV can run the same suite with :app:connectedDebugAndroidTest.

Verified 48 core JVM tests, artwork URL smoke, Compose boundary checks, emulator script syntax and workflow structure. The local wrapper attempted debug assembly, instrumentation assembly and connected tests but failed before compilation at the services.gradle.org DNS lookup. Local adb, emulator and /dev/kvm unavailable. Neither an APK nor an instrumentation pass is verified for this checkpoint.

Next: obtain the connected test result from an Android-capable environment and fix any compile, focus or fixture failure before marking device behavior verified. Meanwhile compare F143 title/year identity fallback and conflicting provider IDs against the Android return path, retaining strict episode and media-type boundaries.

## Checkpoint 16 — Return to a refreshed title across providers

If the selected title reappears with another provider ID, the Kotlin focus resolver now considers normalized title and four-digit release year on the original shelf. It retains the media-type boundary and rejects conflicting IMDb, TMDB or TVDB IDs before identity matching. Within each shelf, exact IDs rank above provider matches and provider matches rank above title/year matches. Season and episode numbers parsed from colon-separated IDs compare numerically. Episodes without numbers require an exact ID. Positional fallback remains available if the item disappeared.

F143 mapping: CatalogStore.swift unifiedSearchTitleYearKey (4713–4718), normalizedMatchText (5359), catalogEpisodeIdentitySuffix, catalogIdentityKeys and catalogItemsShareCanonicalIdentity (5407–5463). Android uses its parsed integer release year; separate season/episode model fields, Swift's unified series/episode type and identity reuse outside focus return remain open. No Swift files changed.

Two red tests on checkpoint 15 reproduced wrong-shelf return and a missed episode with differently padded IDs. With the fix all 54 core JVM tests passed, as did artwork smoke and Compose boundary checks. Expanded CatalogDetailFocusTest with a title/year-only refresh exercising Back and D-pad Center. Both UI scenarios still require instrumented execution. Local assembleDebug and connectedDebugAndroidTest stopped before Android compilation at services.gradle.org DNS resolution; no adb or virtual device was available. No APK or signing result was produced locally.

Next: run the existing TV instrumentation workflow on an Android-capable host when available. Independently trace the approved tvOS detail Play action through source selection and port the first verified step into Android's detail screen. Its current Play action is a placeholder; the Media3 smoke activity is separate.

## Checkpoint 17 — Movie detail Play and a single configured direct-stream provider

Settings → Source Intelligence accepts one HTTPS Stremio manifest URL. It is masked during editing and saved in an app-private file excluded from backup. Clearing the field and saving removes the configured value. Play on a catalog movie requests the manifest on demand, checks stream resource type and ID prefixes, and probes the catalog ID and explicit IMDb alias. The resolver preserves configured URL paths and queries and passes a direct stream URL and its proxy request headers to the existing Kotlin Media3 controller. The in-app PlayerView owns remote controls. Its host releases the player on stop or dismissal, retaining position and play/pause intent across stop/start while the same view is mounted. Back returns to detail. The screen reports missing configuration, empty results and provider failures.

F143 partial mappings: CatalogStore.swift lines 732–744 (direct URL rules), 6705–6731 (resource/type/prefix checks), 6825–6888 (stream query and decoding), 9522–9564 (Play handoff), DebridChannelsTVOSApp.swift lines 14302–14312 (Play action) and TorBoxUsenetClient.swift lines 352–355 (preparation clip). Android uses the first eligible movie URL in one provider's response. Multi-provider ranking, source memory, automatic alternate playback, external or debrid-only resolution, subtitles, persistent resume, series/episode selection and custom Unity playback controls remain open. Only HTTPS provider manifests are supported; plain HTTP media is subject to Android cleartext transport restrictions.

60 Kotlin core JVM tests passed, including six new tests for capability checks, encoded endpoint/query handling, aliases, excluded stream types, headers, empty results and provider failure. Artwork smoke and clean Compose boundary passed. Local assembleDebug stopped before compilation at services.gradle.org DNS lookup. No APK or connected device run. Live provider credentials, video start, remote play/pause, seek, Back and stop/start require Android verification.

Next: build the debug APK on an Android-capable runner and exercise the main detail-to-player route with a controlled HTTPS manifest and direct video. Verify signed artifact delivery, playback state and return focus. Independently trace F143's source confirmation and alternate-source selection to extend the single-provider movie path.

## Checkpoint 18 — Movie source selection and confirmation

Movie detail → Source Intelligence requests direct sources from the configured HTTPS manifest. The Kotlin resolver returns provider-order options, preserves signed URLs and per-source request headers, and deduplicates by URL plus file index. It stops after the first productive item ID. The 25/50 result limit in Source Intelligence settings now persists across launches. The Play button still uses just the first eligible source. The chooser shows the provider label for each stream (or filename/number if absent); its confirmation view shows the source provider and available file size. Only Play source hands the selected request to Media3. Back from confirmation requests focus on the selected row; Back from playback opened through the chooser reopens that list without another network request.

F143 DebridChannelsTVOSApp.swift source selection and confirmation around 14142–14175, 14284–14296, 14312–14326 and 14383–14389; CatalogStore.swift scans and filters provider streams around 6825–6890. Android implements a modal Compose dialog for one movie provider. Multi-provider ranking, episode and debrid resolution, track probes, automatic failover, subtitles, Unity animation and custom playback controls remain pending.

62 core JVM tests passed. New fixtures verify selected-request URL and header isolation, skipped external-only entries, duplicates, display metadata, provider order, result limits and first-successful-ID behavior. Artwork URL and Compose boundary checks passed. MovieSourcePickerTest exercises remote Down, Center, Back and confirmation; the optional TV workflow now includes it. Gradle stopped before compiling either APK when services.gradle.org did not resolve. No APK, emulator run or device playback was verified.

Next: exercise both Play routes on Android TV and compare Back focus with F143. Independently port the ordered alternate direct URLs and their individual request headers into the movie playback session; verify fallback never loops, never crosses titles and preserves playback position where appropriate.

## Checkpoint 19 — Movie startup source recovery

Both movie launch routes build a session from the configured provider's results. The selected URL plays first. The session retains at most three distinct same-movie alternatives in provider order. Before the first rendered video frame, a Media3 network, HTTP status, timeout or unspecified I/O failure schedules one retry per URL after 1.2 seconds. A subsequent failure, or a non-transient error, advances to the next URL with that source's headers and MIME type. The replacement starts at the higher of the requested resume point and the failed player's position. A first rendered frame disables automatic source switching for the remainder of the session. Exhaustion shows the playback error and Back instruction. Leaving the active lifecycle cancels a queued open and releases the player.

Reference paths inspected: DebridResolverPreflightManager.playableURLs, AutomaticSourceFailoverPolicy.nextCandidate and normalizedResumeSeconds, CatalogStore.beginAutomaticSourceFailover, and DebridChannelsTVOSApp.attemptAutomaticSourceFailover. Android uses the Media3 rendered-frame event and typed error codes. Stable-frame timing, multi-provider ranking, experimental audio handoffs, launch cover transfer and startup watchdog parity remain open. All 125 source hashes in the coverage ledger matched the supplied F143 reference. Final-revision equivalence remains unverified.

65 JVM tests passed, including three recovery tests for retry limits, alternate order and exhaustion, signed query and header isolation, title isolation, resume position and first-frame cutoff. Artwork and Compose boundary checks passed. Local Gradle assembly stopped before compilation because services.gradle.org did not resolve. No APK or Android device result was obtained.

Next: run the signed debug build and exercise both movie launch routes with a controlled provider on Android TV. Verify the HTTP request and playback position on each attempt, Back focus, Home during a pending retry, and behavior when a stream stalls without emitting an error. Compare stall handling with the F143 startup watchdog before adding that path.

## Checkpoint 20 — Movie startup stall recovery

MoviePlayer now monitors each foreground movie attempt if another direct source is available. MovieStartupRecovery derives a 21/25/30/36/42-second startup deadline from the active option's label and provider. Unknown cache state gets the uncached grace period. At expiry, more than 350 ms of buffered media earns one 9-second extension. On expiry without a rendered video frame, the player advances directly to the next session source using checkpoint 19's resume and header handling. Rendering, errors, lifecycle exit and pause cancel the timer. Resuming before a frame rearms it. The final source has no fallback timer, matching F143.

Traced CatalogStore.swift sourceIntelligenceIsCached, sourceIntelligenceSeederCount, sourceIntelligenceAdaptiveCacheHint, and DebridChannelsTVOSApp.swift automaticSourceStartupGraceSeconds, armAutomaticSourceFailoverWatchdog and markStableFirstFrameReady. Android derives cache hints from available provider labels. Structured Voyager/TorBox cache facts and tvOS engine-specific stable-playback checks remain open. Media3 uses totalBufferedDuration and onRenderedFirstFrame.

68 Kotlin JVM tests passed, including grace selection, source change, final-source and first-frame suppression, the buffer boundary, one extension and cancelled callback isolation. Artwork URL smoke and Compose boundary checks passed. Local :app:assembleDebug stopped at Gradle distribution DNS lookup before Android compilation. No local APK, Actions artifact or connected TV test was verified.

Next: run a controlled two-source Android TV playback test. Hold the first HTTP response open without video, record time to the second URL and its request headers, then repeat with pause/resume, Home/return, and a first frame just before the deadline. Verify signature, sideload and remote focus on Back. The last-source stall and stable-frame behavior should be compared on device before expanding recovery.

## Checkpoint 21 — Controlled movie startup playback test

Added MovieStartupPlaybackTest to the existing optional Android TV emulator workflow. It mounts the production MoviePlayer with two direct movie sources. A device-local Kotlin HTTP server keeps sending MP4 padding for the first source and serves a generated 20-second H.264 clip for the second. Only the first source starts with an eight-second resume point. The test checks the request order and headers, one request for the stalled source, the switch interval around the 21-second deadline, a rendered replacement frame and resumed position, and delivery of the Back action. The loopback HTTP exception is scoped to the debug build. Test video is packaged in the instrumentation APK.

Verified on the host: compiled and exercised the actual fixture with concurrent HTTP connections, separate request headers, a partial range and exact video bytes. FFmpeg decoded the full 200-frame clip. All 68 existing Kotlin core tests, artwork smoke, Compose boundary and emulator script syntax passed. The Android test itself has not run or compiled here. The wrapper could not resolve services.gradle.org. adb and an emulator are unavailable.

On an Android runner, dispatch the existing workflow with test_tv_focus enabled. Inspect MovieStartupPlaybackTest alongside the catalog and source picker tests. The APK artifact is published by the build job after signature verification. Next verify pause/resume and Home/return during startup, followed by remote focus on the actual source row after Back. This checkpoint does not establish end-to-end focus or final design parity.

## Checkpoint 22 — Paused movie startup and activity return

MoviePlayer restores the active source's play intent before Media3 prepares it. The movie session retains the requested resume position if the activity stops before the new player has established a position. Once a frame renders or the viewer seeks, it accepts the current position, including backward seeks to zero. The ordinary VOD and live controller entry points continue to start playback automatically.

The optional TV emulator test pauses during the stalled source, moves the activity through CREATED and RESUMED, and waits through a full startup deadline in both the background and paused foreground. It checks the reopened player, request order, saved eight-second position and alternate request after Play. This exercises Android lifecycle transitions within an existing session. Physical Home navigation, focus after Back and restoring after process death remain open.

70 core JVM tests passed. The new tests exercise startup zero, a later reported position, a source switch and backward seeks. Artwork and Compose boundary checks passed. Local assembly of the app and instrumentation APKs stopped before compilation because services.gradle.org did not resolve. No emulator or physical TV test result. F143's player teardown distinguishes internal handoff from durable resume cache and Trakt updates (DebridChannelsTVOSApp.swift lines 33140–33170). Android currently handles the in-memory movie session only.

Next: trace F143's durable movie resume rules and port the eligibility and completion boundaries for reopening a movie after leaving detail or restarting the application. Execute the lifecycle test and remote Back focus checks when a TV runner is available.

## Checkpoint 23 — Device-local movie resume

Both movie launch routes now restore the saved timestamp for the exact movie media ID before opening Media3. MoviePlayer saves eligible progress every five seconds while playing, on pause, and when stopping or leaving. Startup without an established position preserves the previous record. A resumed source ignores clocks more than four seconds below its queued target until playback catches up or the user seeks. Playback from eight seconds qualifies, including streams of unknown duration. During the final 5% ordinary updates preserve the previous checkpoint. A qualifying exit at or above 95% clears the entry, as does Media3 EOF. An implausible time more than five seconds beyond known duration is ignored. Short rewinds below eight seconds leave the previous durable record intact, following F143.

Traced PlaybackResumeCache.swift resumeEntry/saveProgress and DebridChannelsTVOSApp.swift saveResumePositionIfNeeded. Android stores milliseconds under the exact media ID in private SharedPreferences and applies updates asynchronously; stop/exit has no synchronous fsync guarantee for abrupt termination. Timing-only storage does not yet implement tvOS alias reconciliation, recents/artwork, history limits, Trakt, episode progress or the Continue Watching shelf. The Kotlin instrumentation test exercises an eligible exit, same-ID reopen and EOF removal in one process. Force-stop/relaunch and physical remote behavior are still unverified.

73 core JVM tests passed. Cases include the eight-second inclusive minimum, exact and fractional 95% boundaries, unknown duration, duration overshoot, the resume protection floor and intentional rewind. Artwork smoke and Compose boundary checks passed. Local debug and instrumentation assembly stopped before compilation at services.gradle.org DNS lookup. No APK or device test result.

Next: port stable movie identity aliases from PlaybackResumeCache.swift, then show eligible resume timing in the movie detail action. Run the new resume test and verify a process restart when an Android build runner is available.

## Checkpoint 24 — Movie resume across catalog IDs

Both movie launch routes bind the selected catalog item's metadata to MovieResumeStore. PlaybackResumeCache.swift playbackKey/playbackKeyAliases and the TMDB/IMDb parsing helpers (607–666 and 773–800) informed the Kotlin implementation. Exact case-sensitive catalog IDs and qualified IMDb, TMDB and TVDB aliases link to one timestamp. A later item with identifiers from two previous records joins them using the latest save revision, even if the user has rewound. Completing a movie removes every linked alias in one edit. Items without a shared identifier stay separate. Title/year matching, episodes, cloud data and Continue Watching metadata still need independent parity work.

Migration imports eligible checkpoint 23 entries once, preserving opaque IDs and extracting provider IDs where present. Where two legacy entries map to the same movie and have no write-order data, the furthest position wins. Android stores each edit with SharedPreferences.apply. Physical process restart and durable flush on abrupt termination remain unverified.

77 Kotlin JVM tests passed. Four new tests cover embedded/explicit IDs, remake isolation, merging two histories after an ID bridge, and legacy migration. A host exercise compiled MovieResumeStore with an in-memory preferences substitute and verified migration, cross-catalog reads, rewinds, reopen and completion/clear while a remake retained its position. Artwork smoke and Compose boundary checks passed. The local Gradle wrapper failed to resolve services.gradle.org before APK or instrumentation compilation. No APK, emulator or device result.

Next: show the eligible resume timestamp on the movie detail action and verify that the label refreshes after Back and after completion. Compare F143's title/year fallback and ambiguous identities before extending the shared-ID matcher.

## Checkpoint 25 — Movie detail resume indicator

F143 keeps the primary PLAY action and places a progress bar, rounded percentage, resume clock and remaining time below it (DebridChannelsTVOSApp.swift 13414–13437). The source selection header also shows the resume clock and remaining time (17152–17166). Android now implements those displays using the saved movie position and measured Media3 duration. Existing records without duration can still resume playback. The indicator appears after a save includes duration. Detail refreshes on entering or returning from playback, after the outgoing player's disposal has run. The progress display has an accessibility description and adds no focus target. The Play and source selection actions retain their existing behavior.

Mapped PlaybackResumeCache.swift dcProgressFraction, dcRemainingSeconds, dcRemainingText and dcResumePositionText. A new duration field defaults to zero for older store entries. When alias groups merge, duration and position come from the same winning save. The original reference files were not edited.

80 JVM tests passed, including clock rounding into the next minute/hour, remaining-time formatting, percentage, hidden states and cross-catalog duration selection. Artwork smoke and Compose boundary checks passed. The existing optional movie playback instrumentation now asserts the detail indicator after remote Back and its absence after EOF plus Back. It has not been compiled or executed here. Local build could not resolve services.gradle.org; no APK was produced or sideloaded.

Next: run the updated playback instrumentation on a TV runner, compare the detail and source-picker presentation and D-pad focus, and trace the Continue Watching shelf's ordering, deduplication and required artwork/identity fields before porting it.

## Checkpoint 26 — Local movie Continue Watching shelf

Home and Movies prepend a local Continue Watching row when an eligible card exists. Existing detail and movie playback handle selection. The row refreshes on browsing/return and catalog updates, outside playback. It uses save revision for newest-first order, includes positions from eight seconds with unknown duration or below 95% of known duration, and displays at most 24 cards. A folded title plus year and the item ID suppress duplicates. Asset URLs from the current catalog take priority, with independently saved poster and landscape URLs filling gaps. A newly saved movie retains its MediaItem for cold or unavailable catalogs. Older timing-only saves appear when their identity matches a loaded card. The Retry action remains available on catalog failure.

Mapped the movie branch of CatalogStore.localContinueWatchingRow (2841 onward) and the resume cache's persisted artwork and recent-entry ordering. Android resolves by existing provider aliases and uses the current catalog row renderer. Episode grouping, Trakt import, explicit hide/remove, cold remote artwork enrichment, custom shelf presentation and long-term history pruning remain open. The short list considers up to 60 eligible records and uses the tvOS row ID dc-local-continue.

83 JVM tests passed including ordering, deduplication, remakes, eligibility thresholds, limit, cold card serialization, independent artwork fallback and matching older timing-only saves. Artwork smoke and clean Compose boundary passed. Local Gradle assembly stopped before compilation at services.gradle.org DNS resolution. No APK build, physical device or emulator result.

Next: port the local hide/remove action against F143 ResumeVisibilityPreferences, with tests for provider aliases and the behavior when playback starts again. Verify D-pad card selection and focus restoration after a completed movie disappears on a TV runner.

## Checkpoint 27 — Remove a movie from Continue Watching

A long press on a movie in a Continue Watching or Resume shelf opens an action dialog for the selected card. Remove updates the visible shelves immediately and persists hidden identities in device preferences. Cancel and Back dismiss the dialog. A short press still opens detail. Removal leaves the saved playback point and the ordinary catalog card intact. Refreshing the catalog and saving a later playback position both respect the hide preference.

Traced DebridChannelsTVOSApp.swift 10900–10952, CatalogStore.swift removeFromContinueWatchingOnThisDevice and PlaybackResumeCache.swift ResumeVisibilityPreferences. F143 writes a normalized movie title with and without year. Thus same-title remakes are also hidden on the shelf, while their resume positions stay distinct. Android additionally records linked provider IDs to cover localized titles and falls back to IDs for empty normalized titles. No active F143 call to reveal on playback was found. Episode/history actions and Trakt remain pending.

85 Kotlin JVM tests passed. New cases cover yearless matches, same-title remakes, replay, cross-catalog aliases, retaining ordinary rows and omitting an empty Continue Watching shelf. Artwork smoke and Compose boundary checks passed. The optional Compose instrumentation tests the long-click semantics action, Cancel focus, Back dismissal and explicit removal. It has not been compiled or run locally. Gradle stopped at services.gradle.org DNS resolution before compiling either APK; no emulator or TV was available.

Next: verify real D-pad hold versus tap and deterministic focus on an adjacent card or row when the removed card disappears. Continue the tvOS catalog actions with the existing favorites subsystem after tracing durable favorite identity and toggle behavior.

## Checkpoint 28 — Focus after removing a movie

Continue Watching now captures the selected shelf and card position before opening the actions dialog. After local removal, Android requests focus at that position on the updated shelf, clamped to its last card. If the shelf disappears it chooses the nearest populated row, retaining the column where possible. Empty catalogs have no card focus target. Returning from detail still follows movie identity.

Source correspondence: DebridChannelsTVOSApp.swift lines 10900–10952. F143 focuses the shelf and tracks its selected poster. Android Compose focuses individual cards, so the positional fallback is an Android implementation decision. Source hashes and coverage status remain recorded in the ledger.

87 Kotlin JVM tests passed, including the duplicate-on-another-shelf and disappearing-shelf cases. Artwork URL smoke and the Compose boundary check passed. The extended instrumentation sends D-pad center down, long-press repeat and up, dismisses with Back, then checks focus after deleting the last shelf card. Gradle failed at Gradle 8.13 distribution DNS lookup before compilation. No APK, emulator or physical remote test was available.

Next: execute the optional TV focus workflow and trace the F143 catalog favorite action against Android's existing favorites subsystem. Episodes, history and Trakt actions remain open.

## Checkpoint 29 — Local catalog favorites

Home, Movies and Shows expose Add to Favorites or Remove from Favorites when a movie or show card is held. Favorites replaces the four sample entries with the locally saved cards, sorted by title. A favorite stores its full MediaItem, including artwork URLs, in private Android preferences. Removing a favorite from the Favorites row uses the existing positional focus fallback. Continue Watching removal remains a separate movie action.

Mapped DebridChannelsTVOSApp.swift lines 9679–9707, 10298–10340, 10507–10529, 10908–10952 and the Favorites row at 64213. Canonical identity prefers IMDb, TMDB, TVDB, item ID, then title/year, scoped to movie or series. Android writes individual preferences instead of the Apple key list and snapshot dictionary. Local snapshot restore is covered. Legacy Apple key import, merging snapshots as IDs and metadata improve, snapshot budgets, profile backup/sync, favorite Live TV channels, popup actions and complete Favorites UI parity are pending.

90 core Kotlin JVM tests passed. New cases cover canonical identifier precedence, catalog ID changes with stable provider ID, media type separation, fallback title/year, artwork round-trip and invalid records. Artwork smoke and clean Compose boundary passed. A Compose instrumentation case exercises add/remove for a show; execution and compilation remain pending. Gradle could not resolve services.gradle.org while fetching 8.13 and exited before Android compilation. No APK or TV result this run.

Next: trace F143 snapshot identity/merge and improve favorite retrieval when provider metadata gains a stronger ID. Verify persistence across app restart, menu focus and removal on an Android TV runner.

## Checkpoint 30 — Keep a favorite recognizable after a provider ID upgrade

Catalog action labels and favorite removal now use the same Kotlin lookup. A direct canonical-key hit stays fast. A miss checks the saved cards for shared provider IDs, then item ID, then normalized title and compatible release year within the same media type. A unique best match returns the original Android preference key, so removing a refreshed card also removes its persisted entry from checkpoint 29. Opening a menu does not rewrite preferences or scan the catalog.

Source mapping: DebridChannelsTVOSApp.swift 10149–10159 (favoriteMediaSnapshotIdentityMatches), 10321–10340 (remove and retrieve snapshot), 10507–10529 (membership and toggle). Android rejects conflicting provider IDs during fallback and declines a tie among equally good candidates. These safeguards protect separately saved remakes when a catalog omits the year. Saved-card metadata and artwork enrichment, including F143 mergedFavoriteMediaSnapshot at 10040, remain open.

94 Kotlin JVM tests passed. Four new tests cover restoring a pre-upgrade snapshot and selecting its removal key, title changes with a shared item ID, media-type separation, remakes with conflicting or missing years, and provider conflicts. Artwork URL smoke and clean Compose boundary checks passed. The Compose show menu case now refreshes the card with an IMDb ID between adding and removing. It has not run on Android. Gradle 8.13 distribution lookup failed at services.gradle.org before APK or instrumentation compilation. No APK or connected TV was available.

Next: map F143 metadata and artwork merge priorities for a matching favorite, preserve richer offline data on refresh, and test persistence across an activity or app restart on a TV runner.

## Checkpoint 31 — Preserve favorite artwork when opening refreshed catalog detail

Selecting an existing favorite from Home, Movies, Shows or Favorites merges its saved fields into the selected detail card. Incoming poster and backdrop URLs take priority independently. Blank artwork, descriptions, IDs and empty genres fall back to the stored values. Android also carries forward a missing year, runtime, subtitle and local artwork keys. A changed favorite writes its compact snapshot and removes an obsolete preference key in one edit. Brand-new favorites also use the compact format. Existing CP29/30 records can still be read.

F143 DebridChannelsTVOSApp.swift 10025–10061 and 13068–13072 map to compactFavorite, withSavedFavoriteFields and the catalog detail callback. Android limits saved descriptions to 1400 Unicode code points and eight genres. Swift counts extended grapheme clusters. The detail view can use the full incoming description. Clearlogo URL, trailer preview URL and add-on branding have no equivalent fields in the current Android MediaItem. Passive catalog hydration, backup and restart tests on hardware remain open.

97 core Kotlin JVM tests passed, including independent poster/backdrop selection, missing metadata retention, ID upgrade plus snapshot restore, and Unicode clipping. Also compiled and executed the production add/select/remove callbacks with a host preferences substitute, checking re-key, reload and subsequent removal using the old card. Artwork smoke and Compose boundary checks passed. Gradle distribution DNS lookup at services.gradle.org stopped APK and instrumentation assembly before compilation. No Android APK or device result this run.

Next: trace the F143 detail popup favorite toggle at 13074 onward and connect Android movie/show detail to the same favorites state. Exercise the same title from the shelf and the popup, then verify persistent data and focus on a TV runner.

## Checkpoint 32 — Toggle a catalog favorite from detail

Movie and show details now expose Add to Favorites or Remove from Favorites. The detail overlay reads the same live membership and invokes the same persistence callback as the catalog long-press menu. The action stays in the open overlay. Its separate row preserves the existing Play, Source Intelligence and Back positions. Episode and channel detail do not expose this catalog action.

F143 DebridChannelsTVOSApp.swift 13037–13039, 13074–13087 and 14375–14376 map to DebridChannelsApp and DetailScreen. Android uses the updated chip label for confirmation. Trakt watchlist and follow-show actions are separate paths still pending.

97 Kotlin core JVM tests passed, along with artwork URL smoke and Compose boundary checks. A host harness executed the detail action and production toggle with substitute controls/preferences for all four media types. Both movie and show could be added, reloaded from serialized state, and removed. Added a full-app Compose instrumentation test that opens a saved movie, toggles twice with D-pad Center, returns to its card and removes it from the long-press menu. It is pending compilation and device execution. Gradle could not resolve services.gradle.org while retrieving 8.13. No APK, emulator or physical TV result this run.

Next: trace F143 detail artwork versus the Android detail backdrop, which currently loads the raw landscape URL. Verify the appropriate mask and fallback behavior before changing it. Run the full-app Favorites focus test and verify restart persistence on an Android TV runner.

## Checkpoint 33 — Detail backdrop selection and fallback

Detail opens the base landscape image or, if absent or unusable, the poster. Coil tries the shared image relay before its embedded public origin, then any distinct poster candidate. On exhausted requests, it can use mapped local artwork or the black stage. Same-title URL changes retain the last successful painter while a replacement loads. The painter is scoped to the selected media type and ID. This path requests base images only.

Mapped F143 DebridChannelsTVOSApp.swift 11855–11874, 12626–12648 and 59861–59891, and RemoteImageFit.swift 329–410, 978 and 1622–1690. F143 distinguishes the connected panel, Favorites/Search stage ownership and full detail backdrop. Android currently uses a full detail overlay. Trying a distinct poster after a failed landscape is an Android fallback. Premium catalog backdrop rotation, presentation anchors, connected glass geometry and origin-specific ownership are still open.

100 Kotlin JVM tests passed. New cases cover normalized TMDB originals, relay and direct retry order, signed query preservation, deduplication of pre-routed assets, catalog and local URLs, missing or invalid landscapes, and the empty remote list. Artwork URL smoke and clean Compose boundary passed. Gradle failed resolving services.gradle.org before assembling the app or instrumentation APK. No live Coil load, decoded-frame comparison, physical TV, emulator or APK result.

Next: trace CatalogStore's premium detail backdrop pool and presentation anchor lifecycle. Verify same-title image replacement and navigation between different titles on a TV runner.

## Checkpoint 34 — Keep the selected catalog card’s artwork in detail

Home, Movies and Shows now carry the selected card alongside the enriched detail item for the lifetime of the overlay. Detail tries the selected landscape, then its poster, ahead of artwork recovered from an older favorite. Repeated URLs are deduplicated. Opening from Favorites continues to prefer the saved detail landscape. Closing the overlay releases its selected-card reference.

F143 CatalogStore.swift 10444–10457 captures the presentation origin, generation and selected anchor. DebridChannelsTVOSApp.swift 59861–59883 gives premium art first priority, then the catalog anchor, then the ordinary detail path when there is no anchor. Android implements the anchor branch plus enriched artwork as a load-failure fallback. CatalogStore.swift 10357–10419 interleaves Fanart, backend and TMDB pools, excludes current and duplicate URLs, rotates a per-title session cursor and guards asynchronous results against a later selection. Those premium provider paths remain pending.

102 Kotlin core tests passed. Two new tests cover a poster-only selection with a saved landscape, ordinary Favorites order, updated detail art after selection, deduplication and an unusable anchor. Artwork smoke and clean Compose boundary checks passed. Gradle 8.13 distribution lookup at services.gradle.org failed before Android compilation. No APK or TV visual comparison this run.

Next: port the F143 backend premium-backdrop provider starting at backendPremiumDetailBackdrops, including response-size bounds, candidate ranking and cancellation on leaving detail. Keep the catalog anchor visible until a premium replacement loads.

## Checkpoint 35 — Backend premium detail backdrops

Catalog movie and show detail requests /api/artwork/resolve off the UI thread with title, media type, proxyImages=0 and available external IDs. The Kotlin provider accepts the backdrops and landscape buckets, removes duplicates and selected-card artwork, then ranks Fanart, TVDB, TMDB and other sources by provider priority, descending pixel count and URL. The first candidate enters the existing image relay/direct-origin path once the base artwork succeeds or exhausts its fallbacks. The previous decoded image can remain visible until replacement. Favorites and other detail origins without a catalog anchor skip this lookup.

CatalogStore.swift 10172–10247 maps to PremiumDetailBackdrop.kt. A composition-scoped effect runs interruptible I/O with ten-second connect/read timeouts; stale effects cannot publish into a new selection. A blocked socket may finish at its read timeout. The transport checks both declared length and streamed bytes against 2,000,000. Android uses the built-in backend default and omits both anchor images from candidate selection. Session cache, rotating cursor, direct Fanart and direct TMDB providers remain open.

106 core JVM tests passed. Local HTTP fixtures covered successful responses, 503 and malformed JSON; separate tests covered an oversized stream, missing buckets, title escaping, IDs, provider order, dimensions, duplicate URLs and selected-art exclusion. Artwork URL smoke and clean Compose boundary passed. Production endpoint, Android cancellation timing and live image transition remain unverified. Gradle 8.13 distribution DNS lookup failed before Android compilation. No APK or TV test result.

Next: cache successful backdrop pools for the session and rotate through them when the same catalog title reopens, matching F143 CatalogStore.swift 10380–10419. Test per-title isolation, empty results, close/reopen and cancellation on a TV runner.

## Checkpoint 36 — Rotate premium backdrops on catalog detail reopen

The app keeps successful backend backdrop URL lists in memory while its root composition is alive. A new catalog detail opening selects the next URL and wraps to the first at the end. IMDb, TMDB, TVDB and raw identifiers use the existing catalog focus identity parser, scoped to media type, with normalized title and year as a fallback. Empty responses can retry on the next opening. The selected URL and completion flag live above the player branch, so returning to the same detail after playback can retain its selection. Favorites skips the provider lookup.

CatalogStore.swift 5423–5445, 10162–10165 and 10384–10419 map to backdropCacheKey, DetailBackdropSession and the DetailScreen effect. Async fetching happens off the UI thread; only the resumed effect commits the nonempty pool and advances the cursor. Android resets the in-memory cache if the root composition is recreated. Direct Fanart/TMDB and interleaving those providers with backend results remain pending.

109 Kotlin core tests passed. Three new cases cover repeated openings with a single fetch, alias sharing, isolation by media type, ID and year, wraparound, empty results, single-image pools and session reset. Artwork URL smoke and clean Compose boundary passed. Gradle could not resolve services.gradle.org before compiling either APK. No live provider, TV rotation, cancellation timing or playback-return result this run.

Next: trace F143 direct Fanart/TMDB credentials and artwork resolvers, then implement the first supported direct provider while preserving the backend-only fallback. Verify reopening, cancellation and playback return on a TV runner.

## Checkpoint 37 — Direct TMDB backdrops for titles with catalog IDs

Settings > Source Intelligence now accepts a masked TMDB API key. Save a blank value to clear it. The key is held in the application's private no-backup directory. On a catalog-detail cache miss, movie and show lookups with a positive explicit TMDB ID request the appropriate /images endpoint with English and untagged images. Backend and TMDB lookups run concurrently. Android ranks TMDB images by pixel area, vote count and average, interleaves the two pools starting with the backend, and drops duplicates and anchor artwork before session rotation. Without a key or ID, or on ordinary provider failure, the backend pool remains usable. Existing cached titles keep their pool until the session resets.

F143 CatalogStore.swift 10321–10383 partially mapped. Android caps responses at 2 MB, accepts a user-entered key and currently requires a catalog-supplied TMDB ID. Fanart.tv, other TMDB identity resolution branches and production endpoint behavior remain open. No tvOS files changed.

112 Kotlin core tests, the artwork URL smoke test and the clean Compose boundary check passed. New coverage includes key and ID gating, movie/show endpoints, language parameters, missing and duplicate images, ranking ties, round-robin ordering and backend-only fallback. Gradle distribution DNS failure at services.gradle.org prevented APK compilation. Settings focus, live image decoding, cancellation and playback return still need a TV test. Next run: add direct Fanart.tv movie/show lookups with supplied TMDB/TVDB IDs and test the three-provider ordering.

## Checkpoint 38 — Direct Fanart.tv detail backdrops

Catalog detail can use an optional Fanart.tv key saved under Settings > Source Intelligence. The masked editor stores it in a private no-backup file, independently of TMDB. Saving an empty value removes the configured credential. Shows use their explicit TVDB ID and movies use their explicit TMDB ID. Missing IDs and keys skip the direct request. Successful results prioritize English or untagged images, then likes. Responses are bounded at 4,000,000 bytes. The existing session cursor rotates through the Fanart.tv, backend and TMDB pools in that order, skipping the current image and duplicates. Previously cached titles retain their pool until the session resets.

CatalogStore.swift 10249–10319 and 10357–10383 are partially covered. The reference can recover a missing provider ID through TMDB. Android currently skips that path. Next: port the ID resolution branches in tmdbTargetForCredits (11277 onward), starting with explicit IMDb lookup and tests for movie/show disambiguation and missing results.

115 core JVM tests passed. New fixtures cover independent keys, provider-specific IDs, movie/show buckets, language and likes ordering, the response limit, normalization, duplicate filtering and three-provider rotation through wraparound. Artwork URL smoke and clean Compose boundary checks passed. The Gradle wrapper could not resolve services.gradle.org before compiling the debug or instrumented APK. Live Fanart.tv authentication, Android settings focus, cancellation and transitions on a TV remain unverified.

## Checkpoint 39 — TMDB backdrops from IMDb catalog IDs

TMDB detail artwork now resolves a typed tmdb:kind:id first, then a positive explicit TMDB ID. Otherwise a configured TMDB key and a valid IMDb ID trigger /find with external_source=imdb_id and language=en-US. An explicit IMDb ID wins over one embedded in the catalog ID. The resolver prefers the item's media kind, then accepts the other available kind as in F143, and requests images using the returned kind and ID. Missing results, HTTP errors and malformed JSON yield an empty TMDB pool so the other providers can still supply artwork. Resolved IDs remain local to this lookup.

CatalogStore.swift 11277–11318 (typed ID, catalog ID, IMDb lookup and kind selection) partially mapped to PremiumDetailBackdrop.kt. Android accepts positive numeric TMDB IDs, bounds streamed responses to 2 MB, and extracts validated IMDb tokens using its catalog identity parser. Other encoded TMDB ID formats, title/year search and passing recovered movie IDs to Fanart.tv remain open. Next: port tmdbTargetByTitleYear including exact title, release year, vote ranking and the HTTP-error versus empty-result fallthrough. Then share recovered targets with eligible Fanart.tv movie requests.

119 core Kotlin JVM tests passed. Local HTTP fixtures verified the two requests in sequence, explicit and embedded IMDb IDs, movie/show selection, cross-kind fallback, bypass for existing TMDB IDs, unsuccessful results, malformed JSON and HTTP 503. Artwork smoke and clean Compose boundary also passed. Gradle could not resolve services.gradle.org to download Gradle 8.13, so neither APK compiled here. Live credentials, artwork rendering and device behavior remain unverified.

## Checkpoint 40 — Find TMDB backdrops by catalog title and year

For a movie or show with a configured TMDB key, direct artwork lookup now searches by title when the catalog has no usable ID or an IMDb find returns no match. Read and decode errors in the IMDb request permit title search. An HTTP rejection ends the lookup. Movie queries use year and show queries use first_air_date_year when the release year is available. Selection prefers a normalized exact title, then a matching year, then the higher vote average. Fully tied entries keep their provider order. Missing results leave the other artwork providers available.

CatalogStore.swift 5359–5361 and 11312–11355 map to titleYearArtworkTarget, tmdbDetailBackdrops and TmdbArtworkLookupTest. Android uses the parsed integer year, omits invalid result IDs, and ranks nonmatching years as a single group before comparing scores. The Swift comparison can retain provider order for distinct nonmatching years. The search applies to TMDB detail backdrops. Sharing recovered movie IDs with Fanart.tv and handling additional TMDB ID formats remain pending.

121 Kotlin core JVM tests passed. HTTP fixtures cover movie/show endpoints, escaped title and key, year parameters, normalized title priority, remake selection, vote tie-breaking, stable ties, blank titles, IMDb no-match/decode fallback, and no secondary request after HTTP 503. Artwork URL smoke and clean Compose boundary passed. Gradle 8.13 download failed at DNS lookup of services.gradle.org before compilation. No live endpoint, emulator or physical TV check this run.

Next: make the resolved movie target available to direct Fanart.tv and TMDB without duplicating discovery requests. Preserve the catalog-ID shortcut and the Fanart-only key path. Verify independent failures and cancellation.

## Checkpoint 41 — Share resolved movie IDs across direct artwork providers

The detail screen starts one scoped lookup for the TMDB target. Fanart.tv uses its catalog-supplied movie TMDB ID or show TVDB ID immediately. A movie with a missing TMDB ID can await the same resolved movie target used for the TMDB image request. Backend artwork runs independently. The Fanart-only key path for catalog-supplied IDs still works. Cross-kind TV matches are excluded from the Fanart movie endpoint. Only the in-flight detail request owns the shared result.

F143 CatalogStore.swift 10249–10283, 10357–10383, 11277–11355 map to resolveArtworkTarget, premiumDetailBackdrops and the DetailScreen effect. Android shares discovery across child coroutines and deliberately requires a movie match for recovered Fanart movie IDs. A suspended/cancelled detail cannot publish the resolved pool. A socket already reading may take until its timeout to unwind.

124 Kotlin core JVM tests passed, plus artwork URL smoke and the Compose boundary check. HTTP fixtures verified one discovery request feeding both direct endpoints, independent 503 failures, Fanart-only operation, and cancellation during discovery with zero subsequent image requests. Android APK compilation could not start because the Gradle 8.13 distribution host did not resolve. No live provider or Android TV run.

Next: trace TrailerServiceManager.extractedTMDBId, port alternate catalog-ID formats into the shared resolver, and test ordering versus explicit IDs and online discovery. Android TV focus, cancellation latency and live backdrop transitions remain outstanding.

## Checkpoint 42 — Alternate catalog IDs and trailer metadata

The shared artwork resolver now handles embedded tmdb or themoviedb followed by colon, underscore, slash or hyphen and at least two digits, or a wholly numeric ID of two or more digits. Typed TMDB IDs and explicit TMDB metadata retain priority. An IMDb token of five or more digits anywhere in the raw ID prevents interpreting a second token as a TMDB identity. Android requires a positive ID representable as a Long. The existing title/year and IMDb discovery paths handle unusable numeric tokens.

Official catalog rows now retain previewVideo, preview, trailer, trailers[].source and videos[].url/src/source metadata in tvOS priority order. YouTube trailer IDs become watch URLs for later resolution. Favorite snapshots retain these fields via the selected previewUrl, and enrichment can restore a missing preview. The Android JSON field helper trims strings and skips blank fields. No preview playback is wired in this checkpoint.

Source mapping: TrailerServiceManager.swift 36–49, CatalogStore.swift 6275–6277, 11277–11291 and 13982–14001, and DebridChannelsTVOSApp.swift 9975–10053. Kotlin equivalents and pending branches are in docs/F143_SOURCE_COVERAGE.csv. Next: wire direct trailer URL classification and a user-triggered Media3 preview with safe Back/focus return. Web-trailer resolution and pause/resume of an underlying Unity playback session require separate verification.

Build status: Gradle 8.13 distribution download failed at services.gradle.org DNS resolution before Android compilation. No APK, device or live-provider result. The initial new favorite fixture passed a nullable key to restoreFavorite; corrected by asserting the test item's key before restore.

Final checks passed: 128 Kotlin core JVM tests, artwork URL smoke and Compose boundary. HTTP fixtures confirmed successful alternate-ID requests bypass discovery; catalog fixtures verified preview priority and favorite restore. All 125 tracked tvOS source hashes matched the reference.

## Checkpoint 43 — Play direct trailers from catalog detail

Movie and show detail now offer Watch Trailer when the stored preview identifies remote direct media. CatalogTrailer.directTrailerRequest accepts HTTP(S) media-file paths and the video, playback and preview path hints. It preserves signed query parameters. Hosted YouTube/Vimeo pages, raw IDs, file URLs, missing hosts and userinfo are excluded. Android checks media hints on the path; a query string alone cannot qualify a web page.

DetailScreen opens the existing Media3 MoviePlayer with a transient session, a trailer-specific ID and no MovieResumeStore. Manual Back and normal EOF dismiss the trailer and request focus on Watch Trailer. A subsequent detail Back uses the existing catalog return flow. The existing lifecycle handling releases the player while stopped. This scope covers catalog detail. Unity trailers over an already playing movie still need parent pause/resume integration.

130 core JVM tests, the artwork URL smoke test and the Compose boundary check passed. New unit cases cover direct movie/show playback requests, URL filtering, signed URLs, isolated IDs and zero initial position. MovieStartupPlaybackTest.trailerReturnsToItsActionWithoutChangingMovieResume exercises decoded frames, manual Back, EOF, focus restoration and movie resume preservation on the optional TV runner. It has not been compiled or executed here. Gradle 8.13 distribution DNS failure at services.gradle.org prevented local Android compilation. No APK or physical TV result.

Next: port the approved backend trailer resolution path for web trailer metadata, with cancellable resolution, cache identity, error feedback and tests. Validate direct playback, EOF/Back and D-pad return on the TV runner.

## Checkpoint 44 — On-demand backend trailer lookup for catalog detail

Watch Trailer first uses direct catalog media. For movies and shows without a direct preview, including watch-page metadata, the action requests /trailers/resolve by title, year and catalog type. The request asks for a cached or newly prepared, complete, muxed 720–1080p result, using the F143 fast HD flags. Android uses its existing Signal HTTPS API base; the live trailer route at this base is unverified. The backend receives title metadata and does not receive the original watch URL. The item-scoped effect suppresses repeated presses while pending and cancels publication when the detail leaves composition. Network and unavailable-result messages allow retry.

BackendTrailer.kt maps CatalogStore.swift 6109–6177, 6421–6451 and 6590–6615 in part. The bounded first response accepts plain media URLs and common named JSON fields/containers. Android rejects split inputs, flagged pending jobs, hosted watch pages and remux-cache outputs. A 1 MiB size bound applies to declared and streamed bytes. Native trailer lookup, pollPreparedTrailerURL (6189 onward), remux-cache stabilization/materialization and audio-duration checks, app-side cache and cross-detail single-flight remain open. This is the backend-ready direct branch only.

132 Kotlin core JVM tests passed. Loopback HTTP verified encoded title/year/type, the complete/muxed flags, a signed URL returned under result.playbackUrl, and no backend call for direct catalog media. New parser fixtures covered plain responses, pending, split, remux-cache, web pages and invalid data. Artwork smoke and Compose boundary passed. Gradle 8.13 download failed before Android compilation at services.gradle.org DNS lookup. No APK, live route, emulator or physical TV result. Next: port cache-only polling with bounded retries and cancellation tests, followed by remux finalization and audio/video verification before playback.

## Checkpoint 45 — Wait for backend trailer preparation

Watch Trailer can now finish the original user request after a successful JSON response without playable media. The detail screen displays Preparing trailer. After the single initial resolve, the Kotlin client makes at most 40 cache-only requests. It waits one second before each of the first eight polls and 1.5 seconds before each remaining poll. Each poll has eight-second connect and read timeouts. Transient poll errors permit another attempt. Direct catalog URLs and ready first responses skip polling. The first qualifying remote URL supplies the separate Media3 trailer request. The resolve coroutine is owned by the detail composition. Cancellation during a wait prevents the next request. A socket already blocked in a read may take until its timeout to unwind. JSON parsing runs off the UI thread.

CatalogStore.swift 6189–6265 maps to resolveCatalogTrailer, trailerEndpoint and the status callback in DetailScreen. Android still excludes remux-cache media until file stabilization, complete download and audio/video coverage verification are available. File-based playback, raw-remux response parsing, cross-detail cache/single-flight, live provider behavior and on-device playback remain pending. Next: port the remux candidate and file-readiness checks before allowing a remux-cache URL into the player.

Build: the Gradle 8.13 distribution could not be downloaded because services.gradle.org did not resolve. APK compilation and TV tests did not run. The root workflow still builds assembleDebug, verifies its signature with apksigner, and uploads the dedicated Signal-AndroidTV-debug-APK artifact.

Final verification: 136 Kotlin JVM tests passed, plus the artwork URL smoke and clean Compose boundary checks. A loopback HTTP server received one initial and one cache-only request, then supplied the expected signed trailer URL and trailer-specific playback ID. Deterministic tests covered transient errors, the full retry limit, cadence transition, early success and cancellation before another request. All 125 tracked tvOS source hashes matched F143.

## Checkpoint 46 — Signal launcher, browse, search, live playback and shelf layout

Resumed checkpoint 45. The approved archive is Signal_F143_1252_Main_Catalog_Masking.zip. Its project.yml declares 1.0.1252 and build 1252 even though the internal folder is named Signal_F91_BUILD_1200. The previous Android shell still used the old visible name and launched sample channels. The launcher, banner, header, Settings version, build workflow and README now identify Signal. The Android package ID is retained.

Home starts with the reference TopShelfExtension/SeedCatalog.json (14 movies and 10 shows). A saved or refreshed catalog supersedes the seed. Search opens titles and imported stations and retains its query when returning from a result. Live TV can import a local extended M3U or save a direct HTTPS stream. A valid import atomically replaces the app-private lineup. Sports filters its channel names/groups. A station opens the lifecycle-owned Media3 live player. A bundled H.264/AAC test clip plays from either tab without an account. Settings persists Classic Rows or the initial Cover Flow presentation with a landscape selection and perspective side posters. The static Unity hero shade is wired into browse artwork.

Verification: 139 JVM tests, the catalog artwork smoke check, the Compose boundary check, the actual bundled seed parser (24 unique within their shelves), a desktop decode of both clip tracks, archive round-trip and reference hashes. The dedicated GitHub Actions debug-APK signing check and artifact step are present. Added SignalLaunchTest for the actual launcher → Live TV → local player route, included in the manual TV emulator job. Neither the new Compose screens nor instrumentation were compiled locally. Gradle distribution download failed with UnknownHostException for services.gradle.org. APK signing, installation, hardware playback, focus movement and visual parity need a successful Android build and device pass.

Remaining: full Unity overlays, mirrored and centered/wrapping Cover Flow, live EPG, richer sports, Xtream, remote playlists, show episode playback, and remux verification. First run the Actions build and launch test, then compare first launch, search return, Cover Flow and real HTTPS station playback on TV. Do not count the test pattern as a successfully tuned station.
