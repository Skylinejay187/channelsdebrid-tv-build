package com.debridchannels.tv.ui

import android.content.Context
import com.debridchannels.core.data.catalogFavoriteKey
import com.debridchannels.core.data.storedFavoriteKey
import com.debridchannels.core.data.DetailBackdropSession
import com.debridchannels.core.data.compactFavorite
import com.debridchannels.core.data.withSavedFavoriteFields
import com.debridchannels.core.data.restoreFavorite
import com.debridchannels.core.data.encodeFavorite
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.tv.material3.Button
import androidx.tv.material3.Text
import androidx.compose.ui.platform.LocalContext
import com.debridchannels.core.data.OfficialCatalogSnapshots
import com.debridchannels.core.data.visibleContinueRows
import com.debridchannels.core.data.continueWatchingRow
import com.debridchannels.tv.playback.MovieResumeStore
import com.debridchannels.core.data.OfficialCatalogRefresh
import com.debridchannels.core.model.CatalogRow
import com.debridchannels.core.model.MediaType
import kotlinx.coroutines.CancellationException
import androidx.compose.runtime.rememberCoroutineScope
import com.debridchannels.core.data.reloadOfficialCatalog
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.debridchannels.core.data.BlueprintFunctionalCoreFactory
import com.debridchannels.core.designsystem.DebridColors
import com.debridchannels.core.model.AppTab
import com.debridchannels.core.model.LiveChannel
import com.debridchannels.core.model.MediaItem
import com.debridchannels.tv.ui.components.TopMenuBar
import com.debridchannels.tv.ui.screens.CatalogScreen
import com.debridchannels.tv.ui.screens.SignalLiveScreen
import com.debridchannels.tv.ui.screens.SignalStationPlayer
import com.debridchannels.tv.ui.screens.SignalLineupStore
import com.debridchannels.core.data.SignalStation
import com.debridchannels.core.data.signalSeedRows
import com.debridchannels.tv.R
import com.debridchannels.tv.ui.screens.DetailScreen
import com.debridchannels.tv.ui.screens.LiveTvScreen
import com.debridchannels.tv.ui.screens.SearchScreen
import com.debridchannels.tv.ui.screens.SettingsScreen
import com.debridchannels.tv.ui.screens.SourceResultsScreen

private sealed interface OverlayDestination {
    data class Detail(val item: MediaItem, val catalogAnchor: MediaItem? = null) : OverlayDestination
    data class Channel(val station: SignalStation?) : OverlayDestination
    data object Search : OverlayDestination
    data class Sources(val item: MediaItem, val limit: Int) : OverlayDestination
}

@Composable
fun DebridChannelsApp() {
    val backdropSession = remember { DetailBackdropSession() }
    val core = remember { BlueprintFunctionalCoreFactory.create() }
    var selectedTab by remember { mutableStateOf(AppTab.HOME) }
    var overlay by remember { mutableStateOf<OverlayDestination?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var fromSearch by remember { mutableStateOf(false) }
    val closeOverlay: () -> Unit = {
        overlay = if (fromSearch) OverlayDestination.Search else null
        fromSearch = false
    }

    val filesDir = LocalContext.current.noBackupFilesDir
    val snapshots = remember(filesDir) { OfficialCatalogSnapshots(filesDir) }
    val catalogRefresh = remember { OfficialCatalogRefresh() }
    var officialRows by remember { mutableStateOf(emptyList<CatalogRow>()) }
    var loadFailed by remember { mutableStateOf(false) }
    var reloadStatus by remember { mutableStateOf("") }
    var reloading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var attempt by remember { mutableIntStateOf(0) }
    val context = LocalContext.current
    val displayPrefs = remember(context) { context.getSharedPreferences("signal_display", Context.MODE_PRIVATE) }
    var coverFlow by remember { mutableStateOf(displayPrefs.getBoolean("cover_flow", false)) }
    val seedRows = remember(context) {
        context.resources.openRawResource(R.raw.signal_seed_catalog).bufferedReader().use { signalSeedRows(it.readText()) }
    }
    val browseRows = officialRows.ifEmpty { seedRows }
    val lineup = remember(filesDir) { SignalLineupStore(filesDir) }
    var stations by remember { mutableStateOf(emptyList<SignalStation>()) }
    var lineupBusy by remember { mutableStateOf(true) }
    var lineupNotice by remember { mutableStateOf("") }
    LaunchedEffect(lineup) {
        try { stations = withContext(Dispatchers.IO) { lineup.restore() } }
        catch (e: CancellationException) { throw e }
        catch (_: Exception) { lineupNotice = "Could not restore the saved lineup." }
        finally { lineupBusy = false }
    }
    LaunchedEffect(attempt, reloading) {
        if (!reloading) {
            loadFailed = false
            try {
                if (officialRows.isEmpty()) {
                    officialRows = withContext(Dispatchers.IO) { snapshots.restore() }
                }
                officialRows = withContext(Dispatchers.IO) { catalogRefresh.refresh(snapshots::accept) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                loadFailed = true
            }
        }
    }

    val favoritePrefs = remember(context) { context.getSharedPreferences("catalog_favorites", Context.MODE_PRIVATE) }
    var favorites by remember(favoritePrefs) {
        mutableStateOf(favoritePrefs.all.mapNotNull { (key, raw) ->
            restoreFavorite(key, raw)?.let { key to it }
        }.toMap())
    }
    val toggleFavorite: (MediaItem) -> Unit = toggle@{ item ->
        val key = item.catalogFavoriteKey() ?: return@toggle
        val storedKey = favorites.storedFavoriteKey(item)
        if (storedKey != null) {
            favoritePrefs.edit().remove(storedKey).apply()
            favorites = favorites - storedKey
        } else {
            val snapshot = item.compactFavorite()
            favoritePrefs.edit().putString(key, encodeFavorite(snapshot)).apply()
            favorites = favorites + (key to snapshot)
        }
    }
    val openCatalogDetail: (MediaItem) -> Unit = { item ->
        val oldKey = favorites.storedFavoriteKey(item)
        val saved = favorites[oldKey]
        val detail = if (saved == null) item else item.withSavedFavoriteFields(saved)
        if (saved != null && oldKey != null) {
            val updated = detail.compactFavorite()
            val key = updated.catalogFavoriteKey()
            if (updated != saved && key != null && (key == oldKey || key !in favorites)) {
                favoritePrefs.edit().remove(oldKey).putString(key, encodeFavorite(updated)).apply()
                favorites = favorites - oldKey + (key to updated)
            }
        }
        val anchor = item.takeIf { selectedTab != AppTab.FAVORITES }
        overlay = OverlayDestination.Detail(detail, catalogAnchor = anchor)
    }
    val resumeStore = remember(context) { MovieResumeStore(context) }
    var continueRow by remember { mutableStateOf<CatalogRow?>(null) }
    var hiddenMovies by remember(resumeStore) { mutableStateOf(resumeStore.hiddenMovies()) }
    val showResume = selectedTab == AppTab.HOME || selectedTab == AppTab.MOVIES
    LaunchedEffect(showResume, overlay, officialRows, hiddenMovies) {
        if (showResume && overlay == null) {
            continueRow = withContext(Dispatchers.Default) {
                continueWatchingRow(resumeStore.recentMovies(), officialRows, hiddenMovies)
            }
        }
    }

    BackHandler(enabled = overlay != null, onBack = closeOverlay)

    Box(Modifier.fillMaxSize().background(DebridColors.Black)) {
        Column(Modifier.fillMaxSize()) {
            TopMenuBar(
                selectedTab = selectedTab,
                onTabSelected = {
                    overlay = null
                    fromSearch = false
                    selectedTab = it
                },
                onSearch = { searchQuery = ""; fromSearch = false; overlay = OverlayDestination.Search },
            )
            Box(Modifier.fillMaxSize().padding(top = 0.dp)) {
                when (selectedTab) {
                    AppTab.HOME, AppTab.MOVIES, AppTab.SHOWS -> {
                        val rows = remember(browseRows, selectedTab, continueRow, hiddenMovies) {
                            val local = listOfNotNull(continueRow)
                            val base = if (local.isEmpty()) browseRows else browseRows.filter { it.id != local.first().id }
                            visibleContinueRows(when (selectedTab) {
                                AppTab.MOVIES -> local + base.filter { it.items.first().type == MediaType.MOVIE }
                                AppTab.SHOWS -> browseRows.filter { it.items.first().type == MediaType.SHOW }
                                else -> local + base
                            }, hiddenMovies)
                        }
                        if (loadFailed && rows.isEmpty() && officialRows.isEmpty()) {
                            Button(onClick = { attempt++ }, modifier = Modifier.align(Alignment.Center)) {
                                Text("Official catalog unavailable · Retry")
                            }
                        } else if (rows.isEmpty()) {
                            Text(if (officialRows.isEmpty()) "Loading catalog…" else "No titles available", modifier = Modifier.align(Alignment.Center), color = Color.White)
                        } else {
                            Column {
                                if (loadFailed && officialRows.isEmpty()) {
                                    Button(onClick = { attempt++ }) { Text("Official catalog unavailable · Retry") }
                                }
                                CatalogScreen(selectedTab.label, rows, coverFlow = coverFlow, detailOpen = overlay != null,
                                    favorites = favorites, onToggleFavorite = toggleFavorite,
                                    onRemoveMovie = { hiddenMovies = resumeStore.hideMovie(it) },
                                    onItemSelected = openCatalogDetail)
                            }
                        }
                    }
                    AppTab.SPORTS, AppTab.LIVE_TV -> SignalLiveScreen(
                        stations, selectedTab == AppTab.SPORTS, lineupNotice, lineupBusy,
                        onImport = { read ->
                            if (!lineupBusy) {
                                lineupBusy = true
                                lineupNotice = "Reading channels…"
                                scope.launch {
                                    try {
                                        stations = withContext(Dispatchers.IO) { lineup.replace(read()) }
                                        lineupNotice = "Saved ${stations.size} channels."
                                    } catch (e: CancellationException) { throw e }
                                    catch (_: Exception) { lineupNotice = "Import failed. Use a direct HTTPS stream or an M3U list with HTTPS channels." }
                                    finally { lineupBusy = false }
                                }
                            }
                        },
                        onPlay = { overlay = OverlayDestination.Channel(it) },
                    )
                    AppTab.FAVORITES -> {
                        val rows = remember(favorites) {
                            val cards = favorites.values.sortedWith(compareBy({ it.title.lowercase() }, { it.catalogFavoriteKey() }))
                            listOf(CatalogRow("catalog-favorites-quick-panel", "Favorite Movies & Shows",
                                subtitle = if (cards.isEmpty()) "Hold a movie or show to add it to Favorites." else "",
                                items = cards))
                        }
                        CatalogScreen("Favorites", rows, onItemSelected = openCatalogDetail,
                            detailOpen = overlay != null, showHero = false, favorites = favorites,
                            onToggleFavorite = toggleFavorite)
                    }
                    AppTab.MEMBERSHIP -> CatalogScreen("Membership", core.catalogs.catalogRows(AppTab.HOME).take(1), onItemSelected = { overlay = OverlayDestination.Detail(it) }, showHero = false)
                    AppTab.SETTINGS -> SettingsScreen(reloadStatus, coverFlow, onLayout = {
                        coverFlow = it
                        displayPrefs.edit().putBoolean("cover_flow", it).apply()
                    }, onReload = {
                        if (!reloading) {
                            reloading = true
                            reloadStatus = "Checking catalog pages…"
                            scope.launch {
                                try {
                                    val (rows, failures) = withContext(Dispatchers.IO) {
                                        val result = reloadOfficialCatalog(checkActive = { ensureActive() })
                                        snapshots.accept(result.batch) to result.failedRows
                                    }
                                    officialRows = rows
                                    reloadStatus = if (failures.isEmpty()) "Checked ${rows.size} catalog rows."
                                        else "Reload incomplete. Page requests failed for ${failures.size} rows. First: ${failures.first()}"
                                } catch (e: CancellationException) {
                                    throw e
                                } catch (_: Exception) {
                                    reloadStatus = "Catalog reload failed. Try again."
                                } finally {
                                    reloading = false
                                }
                            }
                        }
                    })
                }
            }
        }

        when (val destination = overlay) {
            is OverlayDestination.Detail -> DetailScreen(
                destination.item,
                catalogAnchor = destination.catalogAnchor,
                backdropSession = backdropSession,
                onBack = closeOverlay,
                isFavorite = remember(favorites, destination.item) {
                    favorites.storedFavoriteKey(destination.item) != null
                },
                onToggleFavorite = toggleFavorite,
            )
            is OverlayDestination.Channel -> SignalStationPlayer(destination.station, onBack = closeOverlay)
            OverlayDestination.Search -> SearchScreen(browseRows, stations, searchQuery, { searchQuery = it },
                onItem = { fromSearch = true; openCatalogDetail(it) },
                onStation = { fromSearch = true; overlay = OverlayDestination.Channel(it) }, onBack = { overlay = null })
            is OverlayDestination.Sources -> SourceResultsScreen(core.sources.sourceResults(destination.limit), destination.limit, onBack = { overlay = null })
            null -> Unit
        }
    }
}
