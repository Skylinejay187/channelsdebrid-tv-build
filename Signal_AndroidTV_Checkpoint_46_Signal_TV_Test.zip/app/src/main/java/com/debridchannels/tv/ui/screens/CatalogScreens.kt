package com.debridchannels.tv.ui.screens

import androidx.compose.ui.window.Dialog
import com.debridchannels.core.data.storedFavoriteKey
import com.debridchannels.core.data.catalogFavoriteKey
import com.debridchannels.core.data.isContinueShelf
import com.debridchannels.core.model.MediaType
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import com.debridchannels.core.data.CatalogCardPosition
import com.debridchannels.core.data.CatalogFocusReturn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import coil.compose.AsyncImage
import com.debridchannels.core.data.catalogHeroArtwork
import com.debridchannels.core.data.focusedCatalogItem
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import com.debridchannels.core.designsystem.DebridColors
import com.debridchannels.core.model.CatalogRow
import com.debridchannels.core.model.MediaItem
import com.debridchannels.tv.ui.artworkResource
import com.debridchannels.tv.ui.components.MediaCard
import com.debridchannels.tv.ui.components.PosterCard

@Composable
fun CatalogScreen(
    title: String,
    rows: List<CatalogRow>,
    onItemSelected: (MediaItem) -> Unit,
    modifier: Modifier = Modifier,
    showHero: Boolean = true,
    coverFlow: Boolean = false,
    detailOpen: Boolean? = null,
    favorites: Map<String, MediaItem> = emptyMap(),
    onToggleFavorite: ((MediaItem) -> Unit)? = null,
    onRemoveMovie: ((MediaItem) -> Unit)? = null,
) {
    var focusedId by remember(title) { mutableStateOf<String?>(null) }
    var focusedRowId by remember(title) { mutableStateOf<String?>(null) }
    var origin by remember(title) { mutableStateOf<CatalogFocusReturn?>(null) }
    var actionCard by remember(title) { mutableStateOf<CatalogFocusReturn?>(null) }
    var removedCard by remember(title) { mutableStateOf<CatalogFocusReturn?>(null) }
    val target = remember(origin, removedCard, rows, detailOpen) {
        when {
            detailOpen == true -> null
            removedCard != null -> removedCard?.nearestRemainingCard(rows)
            detailOpen == false -> origin?.resolve(rows)
            else -> null
        }
    }
    val list = rememberLazyListState()
    LaunchedEffect(target, rows, detailOpen) {
        if (target != null && list.layoutInfo.visibleItemsInfo.none { it.key == rows[target.row].id }) {
            list.scrollToItem(target.row + 1) // The hero occupies the first slot.
        }
        if (target == null && detailOpen != true) {
            origin = null
            removedCard = null
        }
    }
    val hero = origin?.item ?: remember(rows, focusedRowId, focusedId) {
        rows.firstOrNull { it.id == focusedRowId }?.items?.firstOrNull { it.id == focusedId }
            ?: focusedCatalogItem(rows, focusedId)
    }
    Box(modifier.fillMaxSize().background(DebridColors.Black)) {
        if (showHero && hero != null) {
            CatalogHeroImage(hero, Modifier.fillMaxWidth().height(420.dp).align(Alignment.TopCenter))
            Box(Modifier.fillMaxWidth().height(420.dp).background(Brush.verticalGradient(
                listOf(Color.Black.copy(alpha = 0.075f), Color.Black.copy(alpha = 0.135f)))))
            Box(
                Modifier.fillMaxWidth().height(460.dp).background(
                    Brush.verticalGradient(listOf(Color.Transparent, DebridColors.Black.copy(alpha = 0.55f), DebridColors.Black)),
                ),
            )
        }

        LazyColumn(
            state = list,
            modifier = Modifier.fillMaxSize().testTag("catalog-rows"),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 58.dp, end = 58.dp, top = 26.dp, bottom = 72.dp),
            verticalArrangement = Arrangement.spacedBy(28.dp),
        ) {
            item {
                if (hero != null && showHero) HeroInfo(hero)
                else Text(title, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            }
            itemsIndexed(rows, key = { _, row -> row.id }) { rowIndex, row ->
                CatalogRowSection(row, target?.takeIf { it.row == rowIndex }?.card,
                    coverFlow = coverFlow,
                    allowShowActions = onToggleFavorite != null,
                    onCardActions = if (onToggleFavorite != null || (onRemoveMovie != null && row.isContinueShelf())) ({ index, item ->
                        actionCard = CatalogFocusReturn(row.id, item, CatalogCardPosition(rowIndex, index))
                    }) else null,
                    onItemSelected = { card, item ->
                        if (detailOpen != null) origin = CatalogFocusReturn(row.id, item, CatalogCardPosition(rowIndex, card))
                        onItemSelected(item)
                    },
                    onFocused = { card, item ->
                        if (showHero) {
                            focusedRowId = row.id
                            focusedId = item.id
                        }
                        if (target?.row == rowIndex && target.card == card) {
                            origin = null
                            removedCard = null
                        }
                    },
                )
            }
        }
    }
    actionCard?.let { selected ->
        val movie = selected.item
        Dialog(onDismissRequest = { actionCard = null }) {
            val cancel = remember { FocusRequester() }
            LaunchedEffect(movie) { cancel.requestFocus() }
            Column(Modifier.background(DebridColors.Black).padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(movie.title, color = Color.White, fontSize = 22.sp)
                if (onToggleFavorite != null) {
                    val saved = remember(favorites, movie) { favorites.storedFavoriteKey(movie) != null }
                    ActionChip(if (saved) "Remove from Favorites" else "Add to Favorites") {
                        onToggleFavorite(movie)
                        if (selected.rowId == "catalog-favorites-quick-panel") removedCard = selected
                        actionCard = null
                    }
                }
                if (movie.type == MediaType.MOVIE && onRemoveMovie != null &&
                    rows.any { it.id == selected.rowId && it.isContinueShelf() }) ActionChip("Remove from Continue Watching") {
                    onRemoveMovie(movie)
                    removedCard = selected
                    actionCard = null
                }
                ActionChip("Cancel", Modifier.focusRequester(cancel)) { actionCard = null }
            }
        }
    }
}

@Composable
private fun CatalogHeroImage(item: MediaItem, modifier: Modifier) {
    val urls = remember(item.landscapeUrl) {
        item.landscapeUrl?.let {
            catalogHeroArtwork(it, "https://api.skylinejay187.it.com", masking = true, fullResolution = false)
        }
    }
    val fallback = if (item.landscapeKey.isNotEmpty()) painterResource(artworkResource(item.landscapeKey)) else null
    Box(modifier) {
        if (urls == null) {
            if (fallback != null) Image(fallback, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alpha = 0.54f)
        } else key(item.id, urls) {
            var baseReady by remember { mutableStateOf(false) }
            AsyncImage(
                model = urls.baseUrl, contentDescription = null, modifier = Modifier.fillMaxSize(),
                placeholder = fallback, error = fallback, contentScale = ContentScale.Crop, alpha = 0.54f,
                onSuccess = { baseReady = true },
            )
            if (baseReady && urls.foregroundUrl != null) {
                AsyncImage(
                    model = urls.foregroundUrl, contentDescription = null,
                    modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
                )
            }
        }
    }
}

@Composable
private fun HeroInfo(item: MediaItem) {
    Column(Modifier.padding(top = 42.dp).fillMaxWidth(0.56f)) {
        Text(item.logoText, color = Color.White, fontSize = 42.sp, fontWeight = FontWeight.Black, maxLines = 2)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(item.year?.toString().orEmpty(), color = Color.White.copy(alpha = 0.70f), fontSize = 15.sp)
            item.rating?.let { Text("★ $it", color = DebridColors.Orange, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
            item.runtimeMinutes?.let { Text("${it}m", color = Color.White.copy(alpha = 0.70f), fontSize = 15.sp) }
        }
        Spacer(Modifier.height(9.dp))
        Text(
            item.description,
            color = Color.White.copy(alpha = 0.78f),
            fontSize = 16.sp,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun CatalogRowSection(
    row: CatalogRow,
    returnIndex: Int?,
    coverFlow: Boolean,
    allowShowActions: Boolean,
    onCardActions: ((Int, MediaItem) -> Unit)?,
    onItemSelected: (Int, MediaItem) -> Unit,
    onFocused: (Int, MediaItem) -> Unit,
) {
    val list = rememberLazyListState()
    var selectedIndex by remember(row.id) { mutableStateOf(0) }
    fun cardKey(item: MediaItem) = if (row.id == "catalog-favorites-quick-panel") item.catalogFavoriteKey() ?: item.id else item.id
    LaunchedEffect(returnIndex, row) {
        if (returnIndex != null && list.layoutInfo.visibleItemsInfo.none { it.key == cardKey(row.items[returnIndex]) }) {
            list.scrollToItem(returnIndex)
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(row.title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        if (row.subtitle.isNotBlank()) Text(row.subtitle, color = Color.White.copy(alpha = 0.45f), fontSize = 13.sp)
        LazyRow(modifier = Modifier.testTag("catalog-row-${row.id}"), state = list, verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(if (coverFlow) 5.dp else 18.dp)) {
            itemsIndexed(row.items, key = { _, item -> cardKey(item) }) { index, item ->
                var hasFocus by remember { mutableStateOf(false) }
                val modifier = if (returnIndex == index) {
                    val requester = remember { FocusRequester() }
                    LaunchedEffect(requester, hasFocus) {
                        if (hasFocus) onFocused(index, item) else requester.requestFocus()
                    }
                    Modifier.focusRequester(requester)
                } else Modifier
                val focus: (Boolean) -> Unit = {
                    hasFocus = it
                    if (it) { selectedIndex = index; onFocused(index, item) }
                }
                val click = { onItemSelected(index, item) }
                val hold: (() -> Unit)? = if (onCardActions != null &&
                    (item.type == MediaType.MOVIE || (allowShowActions && item.type == MediaType.SHOW))) {
                    { onCardActions(index, item) }
                } else null
                if (coverFlow) {
                    MediaCard(item, click, modifier, onFocusChanged = focus, onLongClick = hold, coverOffset = index - selectedIndex)
                } else if (row.id == "watchable") {
                    PosterCard(item, click, modifier, onFocusChanged = focus, onLongClick = hold)
                } else {
                    MediaCard(item, click, modifier, onFocusChanged = focus, onLongClick = hold)
                }
            }
        }
    }
}
