# NewtoOld v2.8.26.5 — 4K Hero Artwork + Smart Startup Cache Audit

Base: v2.8.26.4 performance/cache render rewrite.

Changes:
- Hero backdrop requests now force 3840x2160 decode/cache target while UI composition may remain 1080p.
- ARGB_8888 hero artwork quality preserved.
- Startup cache strategy changed to show cached home immediately, load hero/focused window first, and warm only the visible/nearby window first.
- Removed large startup image warm burst behavior by lowering initial warm limits.
- Rows/cache/player/live systems otherwise preserved.

Verification markers:
- DC_BUILD_MARKER: NewtoOld_v2.8.26.6_BACKEND_TRAILER_CACHE_HERO_FITMENT_FIX
- HERO_4K_ARTWORK_FORCE: enabled=true target=3840x2160
- SMART_STARTUP_CACHE_STRATEGY: cached_home_instant=true hero_first=true visibleWindowItems=24
