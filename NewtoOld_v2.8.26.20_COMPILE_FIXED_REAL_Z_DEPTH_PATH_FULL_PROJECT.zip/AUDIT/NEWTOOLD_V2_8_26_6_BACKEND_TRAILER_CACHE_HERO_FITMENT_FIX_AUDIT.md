# NewtoOld v2.8.26.6 — Backend Trailer Cache + Hero Fitment Fix Audit

Base: v2.8.26.5 4K Hero Artwork + Smart Startup Cache.

Changes:
- Added backend trailer cache queue for visible Home/Movies/Shows hero/row items.
- Queues both the newer `/api/trailers/cache` endpoint and backward-compatible `/trailers/prewarm` endpoint.
- Requests backend/CDN artwork persistence for hero/row artwork via `/api/artwork/cache`.
- Keeps app-side startup cache staged: cached home first, hero/focused items first, no preload-everything burst.
- Keeps hero artwork decode target at 3840x2160 and ARGB_8888.
- Fixes hero fitment so portrait poster artwork is right-staged without stretching or aggressive full-screen cropping; landscape backdrop uses soft crop only.

Verification markers:
- DC_BUILD_MARKER: NewtoOld_v2.8.26.6_BACKEND_TRAILER_CACHE_HERO_FITMENT_FIX
- BACKEND_TRAILER_CACHE_ENGINE: enabled=true
- BACKEND_IMAGE_CDN_CACHE_ENGINE: enabled=true
- HERO_BACKDROP_QUALITY: ... fitment=adaptive_no_stretch
- BACKEND_TRAILER_CACHE_QUEUE
- BACKEND_IMAGE_CDN_CACHE_QUEUE

Not changed:
- Player hardening.
- Live TV systems.
- QR/profile foundation.
- Dim unfocused cards.
- Hero foreground priority.
