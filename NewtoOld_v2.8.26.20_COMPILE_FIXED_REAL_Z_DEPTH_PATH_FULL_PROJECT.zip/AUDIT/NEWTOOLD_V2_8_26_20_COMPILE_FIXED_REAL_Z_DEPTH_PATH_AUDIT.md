# NewtoOld v2.8.26.20 Compile-Fixed Real-Z Depth Path Audit

Base: NewtoOld_v2.8.26.19_NO_BLUR_FOCUSED_POSTER_DEPTH_REAL_Z_FIX_FULL_PROJECT.zip.

Purpose:
- Fix the GitHub build failure caused by unresolved `posterZ` references in MainActivity.kt.
- Keep the no-blur real-Z focused poster/card depth approach.
- Preserve focused row logo bottom-left placement from v2.8.26.18+.
- Preserve all Live TV, XMLTV/Gracenote, VOD, Pro Layout Editor, cache and backend compatibility systems.

Corrections:
- Declared `posterZ` in `applyHeroForegroundPriorityLayers()` using the existing `heroPosterDepthZ()` renderer helper.
- Removed dangling unresolved references from the hero layer path.
- Reworked focused-card depth so the real draw order uses Android view `elevation + translationZ` instead of a duplicate translucent full-screen overlay.
- Changed the animation lift from `translationZ` to `translationY` so animation no longer overwrites the focused card Z ordering.
- Added log marker: `HERO_POSTER_DEPTH_COMPILE_FIXED_REAL_Z_APPLY`.

Verification performed in this environment:
- Confirmed no remaining `cardDepthZ` references.
- Confirmed `posterZ` is declared before use.
- Attempted Gradle compile, but the provided wrapper exits because Gradle is not installed in this container.

Device/GitHub verification target:
- `DC_BUILD_MARKER: NewtoOld_v2.8.26.20_COMPILE_FIXED_REAL_Z_DEPTH_PATH`
- `HERO_POSTER_DEPTH_COMPILE_FIXED_REAL_Z_APPLY`
