# NewtoOld v2.8.26.7 — Instant Home Pipeline Audit

Base: v2.8.26.6 backend trailer cache + hero fitment fix.

Changes:
- Added backend-ready home endpoint support: `/api/home/instant` with fallback `/home/instant`.
- Added hero-first endpoint support: `/api/home/hero` with fallback `/home/hero`.
- Cached home snapshot still paints first for instant startup.
- Backend refresh applies in the background only when rows are returned.
- 4K hero artwork path remains forced and warmed at 3840x2160.
- Visible-window prewarm remains in place; no preload-everything burst restored.
- Existing cache/player/live/QR/profile systems preserved.

Verify log markers:
- `DC_BUILD_MARKER: NewtoOld_v2.8.26.7_INSTANT_HOME_PIPELINE`
- `INSTANT_HOME_PIPELINE`
- `INSTANT_HOME_PIPELINE_FETCH`
- `INSTANT_HOME_PIPELINE_APPLY`
- `HERO_FIRST_PIPELINE_APPLY`
