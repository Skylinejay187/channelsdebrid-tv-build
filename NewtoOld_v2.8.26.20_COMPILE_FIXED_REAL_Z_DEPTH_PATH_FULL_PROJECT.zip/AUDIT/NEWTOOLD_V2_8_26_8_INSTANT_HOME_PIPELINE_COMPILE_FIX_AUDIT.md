# NewtoOld v2.8.26.8 — Instant Home Pipeline Compile Fix Audit

Base: v2.8.26.7 Instant Home Pipeline.

Changes:
- Fixed Kotlin compile type mismatch in `MainActivity.kt` where background Movies/Shows prewarm returned `UnifiedCatalogRepository.MediaItem` but backend cache queue helpers expected `MainActivity.TitleCard`.
- Added an explicit MediaItem → TitleCard adapter at the UI/cache queue boundary instead of unsafe casting.
- Added a safe year parser for metadata strings.
- Preserved Instant Home Pipeline endpoints, 4K hero artwork, cache strategy, hero foreground priority, dim cards, player, Live TV, QR/profile systems.

Verify log markers:
- `DC_BUILD_MARKER: NewtoOld_v2.8.26.8_INSTANT_HOME_PIPELINE_COMPILE_FIX`
- `INSTANT_HOME_COMPILE_FIX`
- `PERSISTENT_ARTWORK_CATALOG_CACHE`
- `HERO_BACKDROP_QUALITY: ... force4KHeroArtwork=true`

Local note: this environment does not have Gradle installed; compile validation should be performed by the GitHub/device build runner.
