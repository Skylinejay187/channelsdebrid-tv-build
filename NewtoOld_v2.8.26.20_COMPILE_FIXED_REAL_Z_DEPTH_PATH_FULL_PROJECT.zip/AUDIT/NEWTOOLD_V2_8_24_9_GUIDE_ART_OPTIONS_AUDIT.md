# NewtoOld v2.8.24.9 Guide Artwork Options Audit

Base: v2.8.24.8 clean sticky dim/cache build.

Changes:
- Added Live TV guide background program artwork option, default OFF, intended only for faster devices.
- Added Live TV guide program thumbnail option, default ON.
- Changed regular guide program artwork from full stretched cell background to right-side artwork chip.
- Live TV player guide backdrop now respects the same background artwork setting.
- Preserved VLC dual ABI, player engine selector, search/cache fixes, sticky dim, and menu hold highlight behavior.

Verification markers:
- DC_BUILD_MARKER: NewtoOld_v2.8.24.9_GUIDE_ART_OPTIONS_NO_BACKGROUND_DEFAULT
- LIVE_GUIDE_ART_OPTIONS: backgroundArt=<bool> thumbnails=<bool> defaultBackgroundOff=true
