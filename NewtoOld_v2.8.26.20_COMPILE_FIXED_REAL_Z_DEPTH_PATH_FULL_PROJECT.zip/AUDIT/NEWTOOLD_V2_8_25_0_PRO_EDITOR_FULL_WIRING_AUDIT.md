# NewtoOld_v2.8.25.0_PRO_EDITOR_FULL_WIRING_AUDIT_EXTRA_ART_TOGGLE

Clean-core Pro Layout Editor wiring audit.

- Added real **Extra artwork on/off** Pro Editor option.
- Wired option through HomeLayoutSettings, SettingsRepository persistence, sanitizer, reset path, and MainActivity renderer.
- Extra hero artwork now hides immediately and logs `HERO_EXTRA_ART_LAYER_APPLY: enabled=false source=pro_editor`.
- Re-audited major Pro Editor controls and added runtime marker `PRO_EDITOR_FULL_WIRING_AUDIT`.
- Dim unfocused cards now reapplies focused/held card alpha=1 and all other cards alpha from slider.
- Focus bounce now changes focused card scale instead of being a dead slider.
- Background dim on focus now affects hero lighting/dim amount instead of being unused.
- Version marker updated everywhere to `NewtoOld_v2.8.25.0_PRO_EDITOR_FULL_WIRING_AUDIT_EXTRA_ART_TOGGLE`.
