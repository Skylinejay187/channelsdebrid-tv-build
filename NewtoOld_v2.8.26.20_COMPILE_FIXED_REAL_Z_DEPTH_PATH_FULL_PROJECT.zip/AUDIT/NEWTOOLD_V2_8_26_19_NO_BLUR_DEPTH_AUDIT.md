# NewtoOld v2.8.26.19 No-Blur Focused Poster Depth Real-Z Fix

Base: NewtoOld v2.8.26.18 clean project.

Purpose:
- Correct the hero poster depth editor control after screenshots showed the old implementation created a blurry/milky full-screen overlay.
- Keep focused row card logo placement fix from v2.8.26.18.

Changes:
- Disabled the duplicate full-screen heroPosterDepthLayer image load.
- Removed the translucent alpha overlay path that copied the hero backdrop over row ghosts.
- Rewired depth slider to focused card/poster real Z/elevation and lift.
- Default formula: focusedCardZ = 36dp + depthPercent * 56dp; focusedCardLift = cardLift + depthPercent * 12dp.
- Ghost rows remain visible because the actual focused card is raised rather than a second image being blended over the whole screen.

Preserved:
- Live TV fixes, Gracenote/XMLTV, VOD player, Pro Layout Editor, row logo bottom-left controls, hero fitment lock, cache systems, DPAD/focus behavior.

Verification performed:
- Searched source for old full-screen depth load and replaced it with no-op guard.
- Verified build marker updated in MainActivity and BuildAuditMarkers.
- Verified row logo left/bottom inset code remains bottom-start.
- Gradle compile not available in this container.
