package com.channelsdebrid.tv

import android.graphics.Typeface
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.util.TypedValue
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import java.io.File
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.util.concurrent.Executors
import java.net.URL
import java.net.HttpURLConnection
import org.json.JSONObject
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.channelsdebrid.tv.data.SourceTestRunner
import com.channelsdebrid.tv.settings.CatalogSettings
import com.channelsdebrid.tv.settings.ChannelsDvrSettings
import com.channelsdebrid.tv.settings.LiveBackendSettings
import com.channelsdebrid.tv.settings.PlaybackSettings
import com.channelsdebrid.tv.settings.SettingsRepository
import com.channelsdebrid.tv.settings.StorageSettings
import com.channelsdebrid.tv.settings.StremioAddonSettings
import com.channelsdebrid.tv.settings.TmdbSettings
import com.channelsdebrid.tv.settings.TrailerSettings
import com.channelsdebrid.tv.settings.XtreamSettings
import com.channelsdebrid.tv.storage.SmbNasBrowser

class SettingsActivity : AppCompatActivity() {
    private val requestSafNasFolder = 2815
    private lateinit var repository: SettingsRepository

    private lateinit var backButton: Button
    private lateinit var cancelButton: Button
    private lateinit var saveButton: Button
    private val sourceTestRunner = SourceTestRunner()

    private lateinit var tmdbTestButton: Button
    private lateinit var stremioTestButton: Button
    private lateinit var channelsTestButton: Button
    private lateinit var xtreamTestButton: Button
    private lateinit var liveBackendTestButton: Button
    private lateinit var liveBackendEpgRefreshButton: Button
    private lateinit var channelsConnectButton: Button
    private lateinit var xtreamConnectButton: Button
    private lateinit var homeLayoutEditorButton: Button
    private lateinit var profilesButton: Button
    private lateinit var qrSetupButton: Button

    private lateinit var tmdbStatusText: TextView
    private lateinit var stremioStatusText: TextView
    private lateinit var channelsStatusText: TextView
    private lateinit var xtreamStatusText: TextView
    private lateinit var liveBackendStatusText: TextView
    private lateinit var settingsScrollView: ScrollView
    private lateinit var settingsSectionLiveBackend: View
    private lateinit var settingsSectionCatalogs: View
    private lateinit var settingsSectionStremio: View
    private lateinit var settingsSectionPlayback: View
    private lateinit var settingsSectionStorage: View
    private lateinit var navBackend: TextView
    private lateinit var navLiveTv: TextView
    private lateinit var navCatalogs: TextView
    private lateinit var navStremio: TextView
    private lateinit var navPlayer: TextView
    private lateinit var navStorage: TextView

    private lateinit var tmdbApiKeyInput: EditText
    private lateinit var tmdbRegionInput: EditText
    private lateinit var tmdbLanguageInput: EditText

    private lateinit var catalogTrendingMoviesSwitch: SwitchCompat
    private lateinit var catalogPopularMoviesSwitch: SwitchCompat
    private lateinit var catalogTrendingShowsSwitch: SwitchCompat
    private lateinit var catalogPopularShowsSwitch: SwitchCompat
    private lateinit var catalogPlatformSwitch: SwitchCompat
    private lateinit var catalogStremioSwitch: SwitchCompat

    private lateinit var stremioEnabledSwitch: SwitchCompat
    private lateinit var stremioNameInput: EditText
    private lateinit var stremioManifestInput: EditText
    private lateinit var stremioAddSourceButton: Button
    private lateinit var stremioSourcesContainer: LinearLayout
    private lateinit var stremioSourceCountText: TextView
    private val stremioSources = mutableListOf<StremioAddonSettings>()


    private lateinit var liveBackendBaseUrlInput: EditText
    private lateinit var liveBackendUserIdInput: EditText
    private lateinit var liveBackendAutoSyncSwitch: SwitchCompat
    private lateinit var liveBackendEpgIntervalInput: AutoCompleteTextView
    private lateinit var liveXmltvGuideUrlInput: EditText

    private lateinit var channelsAutoDetectSwitch: SwitchCompat
    private lateinit var hdHomeRunManualUrlInput: EditText
    private lateinit var hdHomeRunUseManualGuideSwitch: SwitchCompat
    private lateinit var hdHomeRunManualGuideUrlInput: EditText
    private lateinit var hdHomeRunGuideRefreshButton: Button
    private lateinit var channelsBaseUrlInput: EditText

    private lateinit var xtreamEnabledSwitch: SwitchCompat
    private lateinit var xtreamServerInput: EditText
    private lateinit var xtreamUsernameInput: EditText
    private lateinit var xtreamPasswordInput: EditText
    private lateinit var xtreamM3uInput: EditText

    private lateinit var storageTargetInput: AutoCompleteTextView
    private lateinit var storageUsbInput: EditText
    private lateinit var storageNasInput: EditText
    private lateinit var storageNasHostInput: EditText
    private lateinit var storageNasShareInput: EditText
    private lateinit var storageNasUsernameInput: EditText
    private lateinit var storageNasPasswordInput: EditText
    private lateinit var discoverNasButton: Button
    private lateinit var lockNasPathButton: Button
    private lateinit var selectSafNasFolderButton: Button
    private lateinit var nasDiscoveryStatusText: TextView
    private lateinit var safNasStatusText: TextView
    private lateinit var movieCacheSwitch: SwitchCompat

    private lateinit var trailerEnabledSwitch: SwitchCompat
    private lateinit var trailerAutoplaySwitch: SwitchCompat
    private lateinit var trailerDelayInput: EditText
    private lateinit var trailerBackgroundSwitch: SwitchCompat
    private lateinit var trailerBackgroundDelayInput: EditText
    private lateinit var trailerModeInput: AutoCompleteTextView
    private lateinit var trailerLocationInput: AutoCompleteTextView
    private lateinit var trailerYoutubeKeyInput: EditText
    private lateinit var trailerPrefer4kSwitch: SwitchCompat

    private lateinit var frameRateSwitch: SwitchCompat
    private lateinit var autoPlayBestSwitch: SwitchCompat
    private lateinit var preferExternalSwitch: SwitchCompat
    private lateinit var fourKUiSwitch: SwitchCompat
    private lateinit var liveStatusChecksSwitch: SwitchCompat
    private lateinit var liveGuideBackgroundArtSwitch: SwitchCompat
    private lateinit var liveGuideProgramThumbnailsSwitch: SwitchCompat
    private lateinit var fileSizeLimitInput: EditText
    private lateinit var playerEngineInput: AutoCompleteTextView
    private lateinit var playerAudioLanguageInput: AutoCompleteTextView
    private lateinit var playerSubtitleLanguageInput: AutoCompleteTextView
    private lateinit var playerSubtitleModeInput: AutoCompleteTextView
    private lateinit var playerHdrModeInput: AutoCompleteTextView
    private lateinit var playerAudioOutputModeInput: AutoCompleteTextView
    private lateinit var playerBufferProfileInput: AutoCompleteTextView
    private lateinit var playerStreamQualityInput: AutoCompleteTextView
    private lateinit var playerLetterboxBackgroundInput: AutoCompleteTextView
    private lateinit var playerResumeBehaviorInput: AutoCompleteTextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        repository = SettingsRepository(this)
        bindViews()

        storageTargetInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("internal", "usb", "nas")))
        storageTargetInput.setOnItemClickListener { _, _, _, _ ->
            val target = storageTargetInput.text.toString().trim().lowercase()
            val external = target == "nas" || target == "usb"
            movieCacheSwitch.isEnabled = external
            if (!external) movieCacheSwitch.isChecked = false
            movieCacheSwitch.text = if (external) "Movie cache / pre-buffer to selected storage" else "Movie cache disabled (NAS/USB only - internal disk blocked)"
        }
        trailerModeInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("hero_background")))
        trailerLocationInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("details", "hero", "both", "off")))
        liveBackendEpgIntervalInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("3 hours", "6 hours", "12 hours")))
        playerEngineInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("Auto", "ExoPlayer", "VLC/libVLC", "VLC fallback only")))
        playerAudioLanguageInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("Auto", "Original", "English", "Spanish", "French", "German", "Italian", "Portuguese", "Japanese", "Korean")))
        playerSubtitleLanguageInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("Off", "Auto", "English", "Spanish", "French", "German", "Italian", "Portuguese", "Japanese", "Korean")))
        playerSubtitleModeInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("Off", "On", "Forced Only", "Smart")))
        playerHdrModeInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("Auto", "Prefer HDR", "Disable HDR")))
        playerAudioOutputModeInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("Auto", "Prefer Surround", "Stereo Only")))
        playerBufferProfileInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("Fast Start", "Balanced", "Stable")))
        playerStreamQualityInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("Auto", "720p only", "1080p only", "4K only", "1080p or higher", "4K preferred")))
        playerLetterboxBackgroundInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("Black bars", "Background poster")))
        playerResumeBehaviorInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("Auto resume", "Ask to resume", "Always start from beginning")))
        configurePlayerDropdowns()
        wireSettingsNavigation()

        loadAll()
        stremioAddSourceButton.setOnClickListener { addCurrentStremioSourceAsync() }
        wireStremioAddButtonRearm()
        backButton.setOnClickListener { finish() }
        cancelButton.setOnClickListener { finish() }
        saveButton.setOnClickListener {
            val saved = runCatching { saveAll() }
            if (saved.isSuccess) {
                Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Settings save failed: ${saved.exceptionOrNull()?.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
            }
        }
        wireTestButtons()
        homeLayoutEditorButton.setOnClickListener { startActivity(android.content.Intent(this, HomeLayoutEditorActivity::class.java)) }
        profilesButton.setOnClickListener { startActivity(android.content.Intent(this, ProfilesActivity::class.java)) }
        qrSetupButton.setOnClickListener { startActivity(android.content.Intent(this, QrSetupActivity::class.java)) }
        discoverNasButton.setOnClickListener { discoverNasShares() }
        lockNasPathButton.setOnClickListener { lockCurrentNasPath() }
        selectSafNasFolderButton.setOnClickListener { openSafNasFolderPicker() }
    }


    private fun openSafNasFolderPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
        }
        val canOpenTree = intent.resolveActivity(packageManager) != null
        if (canOpenTree) {
            runCatching { startActivityForResult(Intent.createChooser(intent, "Select cache folder"), requestSafNasFolder) }
                .onFailure { showSafPickerUnavailableDialog(it.message ?: it.javaClass.simpleName) }
        } else {
            showSafPickerUnavailableDialog("No Android folder picker app is installed on this device.")
        }
    }

    private fun showSafPickerUnavailableDialog(reason: String) {
        safNasStatusText.text = "Android folder picker unavailable. Use Login / Browse NAS or enter a URI/path manually."
        AlertDialog.Builder(this)
            .setTitle("Folder picker unavailable")
            .setMessage("$reason\n\nThis device does not expose Android's system folder picker. Use Login / Browse NAS for SMB storage, or enter a content:// URI/path manually if another file manager provides one.")
            .setPositiveButton("Login / Browse NAS") { _, _ -> lockCurrentNasPath() }
            .setNeutralButton("Manual URI / path") { _, _ -> showManualStorageLocationDialog() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showManualStorageLocationDialog() {
        val input = EditText(this).apply {
            hint = "content://... or smb://ip/share/folder"
            setSingleLine(false)
            minLines = 2
            setText(getSharedPreferences("channels_debrid_settings", MODE_PRIVATE).getString("storage_saf_tree_uri", "").orEmpty())
        }
        AlertDialog.Builder(this)
            .setTitle("Manual cache location")
            .setMessage("Use content:// URI if your file manager can copy one. For SMB, enter smb://ip/share/folder and make sure NAS username/password fields are filled.")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val value = input.text.toString().trim()
                if (value.isBlank()) {
                    Toast.makeText(this, "No cache location entered", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                storageTargetInput.setText("nas", false)
                if (value.startsWith("content://", ignoreCase = true)) {
                    getSharedPreferences("channels_debrid_settings", MODE_PRIVATE)
                        .edit()
                        .putString("storage_saf_tree_uri", value)
                        .putLong("storage_saf_tree_saved_at", System.currentTimeMillis())
                        .apply()
                    safNasStatusText.text = "Manual SAF URI saved. Save settings, then test VOD cache."
                } else {
                    storageNasInput.setText(value)
                    safNasStatusText.text = "Manual NAS path saved in settings. Use Login / Browse NAS when possible for verified SMB write access."
                }
                Toast.makeText(this, "Cache location saved", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != requestSafNasFolder || resultCode != RESULT_OK) return
        val treeUri = data?.data ?: return
        val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        runCatching {
            contentResolver.takePersistableUriPermission(treeUri, flags)
        }.onFailure {
            runCatching {
                contentResolver.takePersistableUriPermission(
                    treeUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
        }
        getSharedPreferences("channels_debrid_settings", MODE_PRIVATE)
            .edit()
            .putString("storage_saf_tree_uri", treeUri.toString())
            .putLong("storage_saf_tree_saved_at", System.currentTimeMillis())
            .apply()
        storageTargetInput.setText("nas", false)
        safNasStatusText.text = "SAF VOD cache folder selected and permission saved."
        Toast.makeText(this, "NAS cache folder selected", Toast.LENGTH_LONG).show()
    }

    private fun bindViews() {
        backButton = findViewById(R.id.backButton)
        cancelButton = findViewById(R.id.cancelButton)
        saveButton = findViewById(R.id.saveButton)
        tmdbTestButton = findViewById(R.id.tmdbTestButton)
        stremioTestButton = findViewById(R.id.stremioTestButton)
        channelsTestButton = findViewById(R.id.channelsTestButton)
        xtreamTestButton = findViewById(R.id.xtreamTestButton)
        liveBackendTestButton = findViewById(R.id.liveBackendTestButton)
        liveBackendEpgRefreshButton = findViewById(R.id.liveBackendEpgRefreshButton)
        channelsConnectButton = findViewById(R.id.channelsConnectButton)
        xtreamConnectButton = findViewById(R.id.xtreamConnectButton)
        homeLayoutEditorButton = findViewById(R.id.homeLayoutEditorButton)
        profilesButton = findViewById(R.id.profilesButton)
        qrSetupButton = findViewById(R.id.qrSetupButton)
        tmdbStatusText = findViewById(R.id.tmdbStatusText)
        stremioStatusText = findViewById(R.id.stremioStatusText)
        channelsStatusText = findViewById(R.id.channelsStatusText)
        xtreamStatusText = findViewById(R.id.xtreamStatusText)
        liveBackendStatusText = findViewById(R.id.liveBackendStatusText)
        settingsScrollView = findViewById(R.id.settingsScrollView)
        settingsSectionLiveBackend = findViewById(R.id.settingsSectionLiveBackend)
        settingsSectionCatalogs = findViewById(R.id.settingsSectionCatalogs)
        settingsSectionStremio = findViewById(R.id.settingsSectionStremio)
        settingsSectionPlayback = findViewById(R.id.settingsSectionPlayback)
        settingsSectionStorage = findViewById(R.id.settingsSectionStorage)
        navBackend = findViewById(R.id.navBackend)
        navLiveTv = findViewById(R.id.navLiveTv)
        navCatalogs = findViewById(R.id.navCatalogs)
        navStremio = findViewById(R.id.navStremio)
        navPlayer = findViewById(R.id.navPlayer)
        navStorage = findViewById(R.id.navStorage)
        hideRemovedLegacyViews()

        tmdbApiKeyInput = findViewById(R.id.tmdbApiKeyInput)
        tmdbRegionInput = findViewById(R.id.tmdbRegionInput)
        tmdbLanguageInput = findViewById(R.id.tmdbLanguageInput)

        catalogTrendingMoviesSwitch = findViewById(R.id.catalogTrendingMoviesSwitch)
        catalogPopularMoviesSwitch = findViewById(R.id.catalogPopularMoviesSwitch)
        catalogTrendingShowsSwitch = findViewById(R.id.catalogTrendingShowsSwitch)
        catalogPopularShowsSwitch = findViewById(R.id.catalogPopularShowsSwitch)
        catalogPlatformSwitch = findViewById(R.id.catalogPlatformSwitch)
        catalogStremioSwitch = findViewById(R.id.catalogStremioSwitch)

        stremioEnabledSwitch = findViewById(R.id.stremioEnabledSwitch)
        stremioNameInput = findViewById(R.id.stremioNameInput)
        stremioManifestInput = findViewById(R.id.stremioManifestInput)
        stremioAddSourceButton = findViewById(R.id.stremioAddSourceButton)
        stremioSourcesContainer = findViewById(R.id.stremioSourcesContainer)
        stremioSourceCountText = findViewById(R.id.stremioSourceCountText)


        liveBackendBaseUrlInput = findViewById(R.id.liveBackendBaseUrlInput)
        liveBackendUserIdInput = findViewById(R.id.liveBackendUserIdInput)
        liveBackendAutoSyncSwitch = findViewById(R.id.liveBackendAutoSyncSwitch)
        liveBackendEpgIntervalInput = findViewById(R.id.liveBackendEpgIntervalInput)
        liveXmltvGuideUrlInput = findViewById(R.id.liveXmltvGuideUrlInput)
        listOf<View>(liveBackendBaseUrlInput, liveBackendUserIdInput, liveBackendAutoSyncSwitch, liveBackendTestButton).forEach { it.visibility = View.GONE }
        liveBackendEpgIntervalInput.visibility = View.VISIBLE
        liveBackendStatusText.text = "BACKEND_MODE: REMOVED - XMLTV_DIRECT: ACTIVE"

        channelsAutoDetectSwitch = findViewById(R.id.channelsAutoDetectSwitch)
        hdHomeRunManualUrlInput = findViewById(R.id.hdHomeRunManualUrlInput)
        hdHomeRunUseManualGuideSwitch = findViewById(R.id.hdHomeRunUseManualGuideSwitch)
        hdHomeRunManualGuideUrlInput = findViewById(R.id.hdHomeRunManualGuideUrlInput)
        hdHomeRunGuideRefreshButton = findViewById(R.id.hdHomeRunGuideRefreshButton)
        channelsBaseUrlInput = findViewById(R.id.channelsBaseUrlInput)

        xtreamEnabledSwitch = findViewById(R.id.xtreamEnabledSwitch)
        xtreamServerInput = findViewById(R.id.xtreamServerInput)
        xtreamUsernameInput = findViewById(R.id.xtreamUsernameInput)
        xtreamPasswordInput = findViewById(R.id.xtreamPasswordInput)
        xtreamM3uInput = findViewById(R.id.xtreamM3uInput)

        storageTargetInput = findViewById(R.id.storageTargetInput)
        storageUsbInput = findViewById(R.id.storageUsbInput)
        storageNasInput = findViewById(R.id.storageNasInput)
        storageNasHostInput = findViewById(R.id.storageNasHostInput)
        storageNasShareInput = findViewById(R.id.storageNasShareInput)
        storageNasUsernameInput = findViewById(R.id.storageNasUsernameInput)
        storageNasPasswordInput = findViewById(R.id.storageNasPasswordInput)
        discoverNasButton = findViewById(R.id.discoverNasButton)
        lockNasPathButton = findViewById(R.id.lockNasPathButton)
        selectSafNasFolderButton = findViewById(R.id.selectSafNasFolderButton)
        nasDiscoveryStatusText = findViewById(R.id.nasDiscoveryStatusText)
        safNasStatusText = findViewById(R.id.safNasStatusText)
        movieCacheSwitch = findViewById(R.id.movieCacheSwitch)

        trailerEnabledSwitch = findViewById(R.id.trailerEnabledSwitch)
        trailerAutoplaySwitch = findViewById(R.id.trailerAutoplaySwitch)
        trailerDelayInput = findViewById(R.id.trailerDelayInput)
        trailerBackgroundSwitch = findViewById(R.id.trailerBackgroundSwitch)
        trailerBackgroundDelayInput = findViewById(R.id.trailerBackgroundDelayInput)
        trailerModeInput = findViewById(R.id.trailerModeInput)
        trailerLocationInput = findViewById(R.id.trailerLocationInput)
        trailerYoutubeKeyInput = findViewById(R.id.trailerYoutubeKeyInput)
        trailerYoutubeKeyInput.visibility = View.GONE
        trailerPrefer4kSwitch = findViewById(R.id.trailerPrefer4kSwitch)

        frameRateSwitch = findViewById(R.id.frameRateSwitch)
        autoPlayBestSwitch = findViewById(R.id.autoPlayBestSwitch)
        preferExternalSwitch = findViewById(R.id.preferExternalSwitch)
        fourKUiSwitch = findViewById(R.id.fourKUiSwitch)
        liveStatusChecksSwitch = findViewById(R.id.liveStatusChecksSwitch)
        liveGuideBackgroundArtSwitch = findViewById(R.id.liveGuideBackgroundArtSwitch)
        liveGuideProgramThumbnailsSwitch = findViewById(R.id.liveGuideProgramThumbnailsSwitch)
        fileSizeLimitInput = findViewById(R.id.fileSizeLimitInput)
        playerEngineInput = findViewById(R.id.playerEngineInput)
        playerAudioLanguageInput = findViewById(R.id.playerAudioLanguageInput)
        playerSubtitleLanguageInput = findViewById(R.id.playerSubtitleLanguageInput)
        playerSubtitleModeInput = findViewById(R.id.playerSubtitleModeInput)
        playerHdrModeInput = findViewById(R.id.playerHdrModeInput)
        playerAudioOutputModeInput = findViewById(R.id.playerAudioOutputModeInput)
        playerBufferProfileInput = findViewById(R.id.playerBufferProfileInput)
        playerStreamQualityInput = findViewById(R.id.playerStreamQualityInput)
        playerLetterboxBackgroundInput = findViewById(R.id.playerLetterboxBackgroundInput)
        playerResumeBehaviorInput = findViewById(R.id.playerResumeBehaviorInput)
    }


    private fun configurePlayerDropdowns() {
        listOf(
            playerEngineInput,
            playerAudioLanguageInput,
            playerSubtitleLanguageInput,
            playerSubtitleModeInput,
            playerHdrModeInput,
            playerAudioOutputModeInput,
            playerBufferProfileInput,
            playerStreamQualityInput,
            playerLetterboxBackgroundInput,
            playerResumeBehaviorInput,
            liveBackendEpgIntervalInput,
            storageTargetInput,
            trailerModeInput,
            trailerLocationInput
        ).forEach { input ->
            input.threshold = 0
            input.keyListener = null
            input.isFocusable = true
            input.isFocusableInTouchMode = true
            input.isClickable = true
            input.setOnClickListener { input.showDropDown() }
            input.setOnFocusChangeListener { _, _ -> }
        }
        android.util.Log.i("DebridChannels", "SETTINGS_PLAYER_DROPDOWNS_CLICKABLE: true focusAutoOpen=false")
    }

    private fun wireSettingsNavigation() {
        fun scrollTo(section: View) {
            settingsScrollView.post { settingsScrollView.smoothScrollTo(0, section.top) }
        }
        navBackend.setOnClickListener { scrollTo(settingsSectionLiveBackend) }
        navLiveTv.setOnClickListener { scrollTo(settingsSectionLiveBackend) }
        navCatalogs.setOnClickListener { scrollTo(settingsSectionCatalogs) }
        navStremio.setOnClickListener { scrollTo(settingsSectionStremio) }
        navPlayer.setOnClickListener { scrollTo(settingsSectionPlayback) }
        navStorage.setOnClickListener { scrollTo(settingsSectionStorage) }
        android.util.Log.i("DebridChannels", "SETTINGS_NAV_CLICKABLE: player_stremio_storage=true")
    }

    private fun loadAll() {
        val tmdb = repository.loadTmdb()
        tmdbApiKeyInput.setText(tmdb.apiKey)
        tmdbRegionInput.setText(tmdb.region)
        tmdbLanguageInput.setText(tmdb.language)

        val catalogs = repository.loadCatalogs()
        catalogTrendingMoviesSwitch.isChecked = catalogs.trendingMoviesEnabled
        catalogPopularMoviesSwitch.isChecked = catalogs.popularMoviesEnabled
        catalogTrendingShowsSwitch.isChecked = catalogs.trendingShowsEnabled
        catalogPopularShowsSwitch.isChecked = catalogs.popularShowsEnabled
        catalogPlatformSwitch.isChecked = catalogs.platformRowsEnabled
        catalogStremioSwitch.isChecked = catalogs.stremioCatalogRowsEnabled

        val addons = repository.loadStremioAddons()
        stremioEnabledSwitch.isChecked = addons.firstOrNull()?.enabled ?: true
        stremioSources.clear()
        stremioSources += addons
        stremioNameInput.setText("")
        stremioManifestInput.setText("")
        renderStremioSources()


        val liveBackend = repository.loadLiveBackend()
        liveBackendBaseUrlInput.setText(liveBackend.baseUrl)
        liveBackendUserIdInput.setText(liveBackend.userId)
        liveBackendAutoSyncSwitch.isChecked = liveBackend.autoSyncSources
        liveBackendEpgIntervalInput.setText(epgIntervalLabel(liveBackend.epgRefreshEveryHours), false)
        liveXmltvGuideUrlInput.setText(liveBackend.xmltvGuideUrl)

        val dvr = repository.loadChannelsDvr()
        channelsAutoDetectSwitch.isChecked = dvr.hdHomeRunAutoScan
        channelsAutoDetectSwitch.isEnabled = true
        channelsAutoDetectSwitch.visibility = View.VISIBLE
        hdHomeRunManualUrlInput.setText(dvr.hdHomeRunManualUrl)
        hdHomeRunUseManualGuideSwitch.isChecked = dvr.hdHomeRunUseManualGuide
        hdHomeRunManualGuideUrlInput.setText(dvr.hdHomeRunManualGuideUrl)
        hdHomeRunGuideRefreshButton.setOnClickListener { forceRefreshHdHomeRunGuideCache() }
        channelsBaseUrlInput.setText(dvr.baseUrl)

        val xtream = repository.loadXtream()
        xtreamEnabledSwitch.isChecked = xtream.enabled
        xtreamServerInput.setText(xtream.server)
        xtreamUsernameInput.setText(xtream.username)
        xtreamPasswordInput.setText(xtream.password)
        xtreamM3uInput.setText(xtream.m3uUrl)

        val storage = repository.loadStorage()
        storageTargetInput.setText(storage.preferredTarget, false)
        storageUsbInput.setText(storage.usbPath)
        storageNasInput.setText(storage.nasPath)
        storageNasHostInput.setText(storage.nasHost)
        storageNasShareInput.setText(storage.nasShare)
        storageNasUsernameInput.setText(storage.nasUsername)
        storageNasPasswordInput.setText(storage.nasPassword)
        movieCacheSwitch.isChecked = storage.movieCacheEnabled && !storage.preferredTarget.equals("internal", ignoreCase = true)
        if (storage.preferredTarget.equals("internal", ignoreCase = true)) {
            movieCacheSwitch.isEnabled = false
            movieCacheSwitch.text = "Movie cache disabled (NAS/USB only - internal disk blocked)"
        } else {
            movieCacheSwitch.isEnabled = true
            movieCacheSwitch.text = "Movie cache / pre-buffer to selected storage"
        }
        val safUri = getSharedPreferences("channels_debrid_settings", MODE_PRIVATE).getString("storage_saf_tree_uri", "").orEmpty()
        safNasStatusText.text = if (safUri.isBlank()) "SAF folder not selected. Select NAS/storage folder for real VOD cache writing." else "SAF VOD cache folder selected and permission saved."

        val trailers = repository.loadTrailers()
        trailerEnabledSwitch.isChecked = trailers.enabled
        trailerAutoplaySwitch.isChecked = trailers.autoplayOnFocus
        trailerDelayInput.setText(trailers.autoplayDelayMs.toString())
        trailerBackgroundSwitch.isChecked = trailers.backgroundAutoplayEnabled
        trailerBackgroundDelayInput.setText(trailers.backgroundAutoplayDelayMs.toString())
        trailerModeInput.setText(trailers.popupMode, false)
        trailerLocationInput.setText(trailers.playbackLocation.ifBlank { "both" }, false)
        trailerPrefer4kSwitch.isChecked = trailers.prefer4k

        val playback = repository.loadPlayback()
        frameRateSwitch.isChecked = playback.frameRateMatching
        autoPlayBestSwitch.isChecked = playback.autoPlayBestStream
        preferExternalSwitch.isChecked = playback.preferExternalStorageForCache
        fourKUiSwitch.isChecked = playback.ultraHdGuideUiEnabled
        liveStatusChecksSwitch.isChecked = playback.liveStatusChecksEnabled
        liveGuideBackgroundArtSwitch.isChecked = playback.liveGuideBackgroundArtEnabled
        liveGuideProgramThumbnailsSwitch.isChecked = playback.liveGuideProgramThumbnailsEnabled
        playerEngineInput.setText(playback.playerEngine.ifBlank { "Auto" }, false)
        playerAudioLanguageInput.setText(playback.preferredAudioLanguage.ifBlank { "Auto" }, false)
        playerSubtitleLanguageInput.setText(playback.preferredSubtitleLanguage.ifBlank { "Off" }, false)
        playerSubtitleModeInput.setText(playback.subtitleMode.ifBlank { "Off" }, false)
        playerHdrModeInput.setText(playback.hdrMode.ifBlank { "Auto" }, false)
        playerAudioOutputModeInput.setText(playback.audioOutputMode.ifBlank { "Auto" }, false)
        playerBufferProfileInput.setText(playback.bufferProfile.ifBlank { "Balanced" }, false)
        playerStreamQualityInput.setText(playback.streamQualityPreference.ifBlank { "Auto" }, false)
        playerLetterboxBackgroundInput.setText(playback.letterboxBackground.ifBlank { "Black bars" }, false)
        playerResumeBehaviorInput.setText(playback.resumeBehavior.ifBlank { "Auto resume" }, false)
        fileSizeLimitInput.setText(playback.fileSizeLimitGb.toString())
    }

    private fun discoverNasShares() {
        nasDiscoveryStatusText.text = "Scanning local network for NAS/SMB devices…"
        discoverNasButton.isEnabled = false
        Executors.newSingleThreadExecutor().execute {
            val results = discoverSmbHosts()
            runOnUiThread {
                discoverNasButton.isEnabled = true
                if (results.isEmpty()) {
                    nasDiscoveryStatusText.text = "No NAS/SMB devices found. Make sure the NAS is on the same network and SMB is enabled."
                    Toast.makeText(this, "No NAS found", Toast.LENGTH_SHORT).show()
                } else {
                    nasDiscoveryStatusText.text = "Found ${results.size} NAS/SMB device(s). Choose one, then enter username/password and lock path."
                    showNasPicker(results)
                }
            }
        }
    }

    private fun showNasPicker(hosts: List<String>) {
        val labels = hosts.map { host -> "smb://$host/" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Select NAS / SMB device")
            .setItems(labels) { _, which ->
                val host = hosts[which]
                storageTargetInput.setText("nas", false)
                storageNasHostInput.setText(host)
                if (storageNasShareInput.text.isNullOrBlank()) storageNasShareInput.setText("Timeshift")
                updateNasPathPreview()
                storageNasUsernameInput.requestFocus()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun lockCurrentNasPath() {
        storageTargetInput.setText("nas", false)
        val host = storageNasHostInput.text.toString().trim().removePrefix("smb://").substringBefore("/")
        val username = storageNasUsernameInput.text.toString().trim()
        val password = storageNasPasswordInput.text.toString()
        if (host.isBlank()) {
            Toast.makeText(this, "Select or enter a NAS host first", Toast.LENGTH_LONG).show()
            return
        }
        if (username.isBlank()) {
            Toast.makeText(this, "Enter your NAS username first", Toast.LENGTH_LONG).show()
            storageNasUsernameInput.requestFocus()
            return
        }
        storageNasHostInput.setText(host)
        nasDiscoveryStatusText.text = "Logging into smb://$host/…"
        lockNasPathButton.isEnabled = false
        Executors.newSingleThreadExecutor().execute {
            val result = runCatching {
                val browser = SmbNasBrowser(host, username, password)
                val entries = browser.list(null)
                entries
            }
            runOnUiThread {
                lockNasPathButton.isEnabled = true
                result.onSuccess { entries ->
                    nasDiscoveryStatusText.text = "Login successful. Select a share/folder for timeshift storage."
                    showNasFolderBrowser(host, username, password, "smb://$host/", entries)
                }.onFailure { error ->
                    nasDiscoveryStatusText.text = "NAS login failed: ${error.message ?: error.javaClass.simpleName}"
                    Toast.makeText(this, "NAS login failed. Check username/password.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun showNasFolderBrowser(
        host: String,
        username: String,
        password: String,
        currentPath: String,
        entries: List<SmbNasBrowser.Entry>
    ) {
        val folders = entries.filter { it.isDirectory }
        val labels = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()

        if (currentPath.trimEnd('/').count { it == '/' } > 2) {
            labels += "..  Up one folder"
            actions += {
                val parent = currentPath.trimEnd('/').substringBeforeLast('/', "smb://$host") + "/"
                browseNasPath(host, username, password, parent)
            }
        }

        labels += "✓ Use this folder for timeshift"
        actions += { validateAndSelectNasFolder(host, username, password, currentPath) }

        folders.forEach { entry ->
            labels += "📁 ${entry.name}"
            actions += { browseNasPath(host, username, password, entry.path) }
        }

        AlertDialog.Builder(this)
            .setTitle("Browse NAS: $currentPath")
            .setItems(labels.toTypedArray()) { _, which -> actions[which].invoke() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun browseNasPath(host: String, username: String, password: String, path: String) {
        nasDiscoveryStatusText.text = "Opening $path…"
        Executors.newSingleThreadExecutor().execute {
            val result = runCatching { SmbNasBrowser(host, username, password).list(path) }
            runOnUiThread {
                result.onSuccess { showNasFolderBrowser(host, username, password, path, it) }
                    .onFailure {
                        nasDiscoveryStatusText.text = "Could not open folder: ${it.message ?: it.javaClass.simpleName}"
                        Toast.makeText(this, "Could not open NAS folder", Toast.LENGTH_LONG).show()
                    }
            }
        }
    }

    private fun validateAndSelectNasFolder(host: String, username: String, password: String, path: String) {
        nasDiscoveryStatusText.text = "Testing write access to $path…"
        Executors.newSingleThreadExecutor().execute {
            val writable = SmbNasBrowser(host, username, password).ensureWritable(path)
            runOnUiThread {
                if (writable) {
                    val cleanPath = if (path.endsWith("/")) path.dropLast(1) else path
                    val relative = cleanPath.removePrefix("smb://$host/")
                    val share = relative.substringBefore('/').trim('/')
                    storageTargetInput.setText("nas", false)
                    storageNasHostInput.setText(host)
                    storageNasShareInput.setText(relative.trim('/'))
                    storageNasInput.setText(cleanPath)
                    nasDiscoveryStatusText.text = "NAS connected and writable: $cleanPath. Save settings to apply."
                    Toast.makeText(this, "NAS folder selected and writable", Toast.LENGTH_LONG).show()
                } else {
                    nasDiscoveryStatusText.text = "NAS folder is not writable. Pick another folder or fix NAS permissions."
                    Toast.makeText(this, "NAS folder is not writable", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun updateNasPathPreview() {
        val host = storageNasHostInput.text.toString().trim().removePrefix("smb://").substringBefore("/")
        val share = storageNasShareInput.text.toString().trim().trim('/')
        storageNasInput.setText(if (host.isNotBlank() && share.isNotBlank()) "smb://$host/$share" else "")
    }

    private fun discoverSmbHosts(): List<String> {
        val candidates = linkedSetOf<String>()
        runCatching {
            java.io.File("/proc/net/arp").readLines().drop(1).forEach { line ->
                val ip = line.trim().split(Regex("\\s+")).firstOrNull().orEmpty()
                if (ip.matches(Regex("\\d+\\.\\d+\\.\\d+\\.\\d+"))) candidates += ip
            }
        }
        val localPrefixes = runCatching {
            NetworkInterface.getNetworkInterfaces().toList().flatMap { iface ->
                iface.inetAddresses.toList().mapNotNull { addr ->
                    val ip = addr.hostAddress ?: return@mapNotNull null
                    if (!addr.isLoopbackAddress && ip.count { it == '.' } == 3) ip.substringBeforeLast('.') else null
                }
            }
        }.getOrDefault(emptyList())
        localPrefixes.take(2).forEach { prefix ->
            for (i in 1..254) candidates += "$prefix.$i"
        }
        return candidates.asSequence()
            .filter { it != "0.0.0.0" }
            .distinct()
            .mapNotNull { ip -> if (isPortOpen(ip, 445, 180) || isPortOpen(ip, 139, 180)) ip else null }
            .take(24)
            .toList()
    }

    private fun isPortOpen(host: String, port: Int, timeoutMs: Int): Boolean {
        return runCatching {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), timeoutMs)
                true
            }
        }.getOrDefault(false)
    }

    private fun wireTestButtons() {
        tmdbTestButton.setOnClickListener {
            runSourceTest(tmdbStatusText, "Testing TMDB…") {
                sourceTestRunner.testTmdb(
                    tmdbApiKeyInput.text.toString().trim(),
                    tmdbRegionInput.text.toString().trim(),
                    tmdbLanguageInput.text.toString().trim()
                )
            }
        }
        stremioTestButton.setOnClickListener {
            runSourceTest(stremioStatusText, "Testing Stremio…") {
                val pending = buildAddonFromInputs()
                val addons = (stremioSources + listOfNotNull(pending))
                    .distinctBy { it.manifestUrl.trim().lowercase() }
                    .map { it.copy(enabled = stremioEnabledSwitch.isChecked) }
                if (addons.isEmpty()) {
                    "Add at least one manifest URL"
                } else {
                    addons.joinToString(" | ") { addon ->
                        sourceTestRunner.testStremio(addon.name.ifBlank { "Stremio" }, addon.manifestUrl)
                    }
                }
            }
        }
        channelsTestButton.setOnClickListener {
            runSourceTest(channelsStatusText, "Testing Channels DVR…") {
                sourceTestRunner.testChannelsDvr(
                    channelsAutoDetectSwitch.isChecked,
                    channelsBaseUrlInput.text.toString().trim()
                )
            }
        }
        xtreamTestButton.setOnClickListener {
            runSourceTest(xtreamStatusText, "Testing IPTV…") {
                sourceTestRunner.testXtream(
                    xtreamServerInput.text.toString().trim(),
                    xtreamUsernameInput.text.toString().trim(),
                    xtreamPasswordInput.text.toString().trim(),
                    xtreamM3uInput.text.toString().trim()
                )
            }
        }
        liveBackendTestButton.setOnClickListener {
            liveBackendStatusText.text = "BACKEND_MODE: REMOVED - Direct XMLTV/IPTV only"
        }
        liveBackendEpgRefreshButton.setOnClickListener {
            runSourceTest(liveBackendStatusText, "Preparing local EPG refresh…") {
                refreshLocalEpgNow()
            }
        }
        channelsConnectButton.setOnClickListener {
            runSourceTest(channelsStatusText, "Testing manual Channels DVR...") {
                sourceTestRunner.testChannelsDvr(false, channelsBaseUrlInput.text.toString().trim())
            }
        }
        xtreamConnectButton.setOnClickListener {
            runSourceTest(xtreamStatusText, "Testing direct IPTV...") {
                sourceTestRunner.testXtream(xtreamServerInput.text.toString().trim(), xtreamUsernameInput.text.toString().trim(), xtreamPasswordInput.text.toString().trim(), xtreamM3uInput.text.toString().trim())
            }
        }
    }

    private fun runSourceTest(statusView: TextView, runningText: String, block: () -> String) {
        statusView.text = runningText
        Thread {
            val result = runCatching(block).getOrElse { "Test failed" }
            runOnUiThread { statusView.text = result }
        }.start()
    }

    private fun parseStremioAddons(enabled: Boolean, rawNames: String, rawManifests: String): List<StremioAddonSettings> {
        val names = rawNames.lineSequence().map { it.trim() }.filter { it.isNotBlank() }.toList()
        val manifests = rawManifests.lineSequence().map { it.trim() }.filter { it.isNotBlank() }.toList()
        return manifests.mapIndexed { index, manifestUrl ->
            val inferredName = inferAddonName(manifestUrl)
            StremioAddonSettings(
                id = if (index == 0) "primary" else "addon_${index + 1}",
                name = names.getOrNull(index).orEmpty().ifBlank { inferredName.ifBlank { "Addon ${index + 1}" } },
                manifestUrl = manifestUrl,
                enabled = enabled
            )
        }
    }

    private fun inferAddonName(manifestUrl: String): String {
        return manifestUrl
            .substringBefore('?')
            .substringAfter("//", manifestUrl)
            .substringBefore('/')
            .substringBefore(':')
            .replace('-', ' ')
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
    }

    private data class ManifestInfo(val name: String, val iconUrl: String)

    private fun fetchManifestInfo(manifestUrl: String): ManifestInfo? {
        val normalized = if (manifestUrl.endsWith("/manifest.json")) manifestUrl else manifestUrl.trimEnd('/') + "/manifest.json"
        return runCatching {
            val connection = java.net.URL(normalized).openConnection() as java.net.HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 5000
            connection.readTimeout = 5000
            connection.setRequestProperty("Accept", "application/json")
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()
            val json = org.json.JSONObject(body)
            ManifestInfo(
                name = json.optString("name").trim(),
                iconUrl = json.optString("logo").trim().ifBlank { json.optString("icon").trim() }
            )
        }.getOrNull()
    }

    private fun wireStremioAddButtonRearm() {
        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                rearmStremioAddButton("text_changed")
            }
            override fun afterTextChanged(s: Editable?) = Unit
        }
        stremioManifestInput.addTextChangedListener(watcher)
        stremioNameInput.addTextChangedListener(watcher)
        stremioManifestInput.setOnFocusChangeListener { _, _ -> rearmStremioAddButton("manifest_focus") }
        stremioNameInput.setOnFocusChangeListener { _, _ -> rearmStremioAddButton("name_focus") }
    }

    private fun rearmStremioAddButton(reason: String) {
        stremioAddSourceButton.post {
            stremioAddSourceButton.isEnabled = true
            stremioAddSourceButton.isClickable = true
            stremioAddSourceButton.isFocusable = true
            stremioAddSourceButton.isFocusableInTouchMode = true
            Log.i("DebridChannels", "STREMIO_ADD_BUTTON_REARMED: reason=$reason")
        }
    }

    private fun fetchManifestName(manifestUrl: String): String? = fetchManifestInfo(manifestUrl)?.name?.takeIf { it.isNotBlank() }

    private fun buildAddonFromInputs(): StremioAddonSettings? {
        val manifestUrl = stremioManifestInput.text.toString().trim()
        if (manifestUrl.isBlank()) return null
        val normalized = if (manifestUrl.endsWith("/manifest.json", ignoreCase = true)) manifestUrl else manifestUrl.trimEnd('/') + "/manifest.json"
        val name = stremioNameInput.text.toString().trim().ifBlank { inferAddonName(normalized).ifBlank { "Addon ${stremioSources.size + 1}" } }
        return StremioAddonSettings(
            id = "addon_" + (stremioSources.size + 1),
            name = name,
            manifestUrl = normalized,
            enabled = stremioEnabledSwitch.isChecked,
            iconUrl = ""
        )
    }

    private fun addCurrentStremioSourceAsync() {
        // Keep Add Source clickable/focusable on Android TV.
        // Never disable this button during manifest checks; async work updates metadata only.
        rearmStremioAddButton("before_add")
        addCurrentStremioSource()
        rearmStremioAddButton("after_add")
    }

    private fun addCurrentStremioSource() {
        val addon = buildAddonFromInputs()
        if (addon == null) {
            Toast.makeText(this, "Paste a manifest JSON URL first", Toast.LENGTH_SHORT).show()
            stremioAddSourceButton.isEnabled = true
            stremioAddSourceButton.isClickable = true
            return
        }
        if (stremioSources.any { it.manifestUrl.equals(addon.manifestUrl, ignoreCase = true) }) {
            Toast.makeText(this, "That source is already added", Toast.LENGTH_SHORT).show()
            stremioAddSourceButton.isEnabled = true
            stremioAddSourceButton.isClickable = true
            return
        }
        stremioSources += addon
        stremioNameInput.setText("")
        stremioManifestInput.setText("")
        renderStremioSources()
        stremioAddSourceButton.isEnabled = true
        stremioAddSourceButton.isClickable = true
        stremioAddSourceButton.isFocusable = true
        stremioAddSourceButton.isFocusableInTouchMode = true
        stremioStatusText.text = "Added ${addon.name}"
        Log.i("DebridChannels", "STREMIO_ADD_BUTTON_REARMED: immediate=true addon=${addon.name}")
        Thread {
            val info = fetchManifestInfo(addon.manifestUrl)
            if (info != null && (info.name.isNotBlank() || info.iconUrl.isNotBlank())) {
                val updated = stremioSources.indexOfFirst { it.manifestUrl.equals(addon.manifestUrl, ignoreCase = true) }
                if (updated >= 0) {
                    val current = stremioSources[updated]
                    stremioSources[updated] = current.copy(
                        name = info.name.ifBlank { current.name },
                        iconUrl = info.iconUrl.ifBlank { current.iconUrl }
                    )
                    runOnUiThread {
                        renderStremioSources()
                        stremioAddSourceButton.isEnabled = true
                        stremioAddSourceButton.isClickable = true
                        stremioAddSourceButton.isFocusable = true
                        stremioAddSourceButton.isFocusableInTouchMode = true
                        stremioStatusText.text = "Manifest detected • ${info.name.ifBlank { current.name }}"
                        Log.i("DebridChannels", "STREMIO_ADD_BUTTON_REARMED: manifest_refresh=true")
                    }
                }
            }
        }.start()
    }

    private fun renderStremioSources() {
        stremioSourcesContainer.removeAllViews()
        val density = resources.displayMetrics.density
        if (stremioSources.isEmpty()) {
            val empty = TextView(this).apply {
                text = "No Stremio JSON sources added yet."
                setTextColor(0xFFA9B2C8.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            }
            stremioSourcesContainer.addView(empty)
            stremioSourceCountText.text = "0 sources added"
            rearmStremioAddButton("render_empty")
            return
        }
        stremioSourceCountText.text = "${stremioSources.size} source${if (stremioSources.size == 1) "" else "s"} added"
        stremioSources.forEachIndexed { index, addon ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = getDrawable(R.drawable.settings_input_bg)
                setPadding((14 * density).toInt(), (12 * density).toInt(), (12 * density).toInt(), (12 * density).toInt())
            }
            val textWrap = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            val title = TextView(this).apply {
                text = addon.name
                setTextColor(0xFFF4EFE8.toInt())
                setTypeface(typeface, Typeface.BOLD)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            }
            val subtitle = TextView(this).apply {
                text = listOf(addon.manifestUrl, addon.iconUrl.takeIf { it.isNotBlank() }?.let { "Icon: available" }).filterNotNull().joinToString("\n")
                setTextColor(0xFFA9B2C8.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                maxLines = 2
            }
            textWrap.addView(title)
            textWrap.addView(subtitle)
            val remove = ImageButton(this).apply {
                setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
                background = getDrawable(R.drawable.settings_fab_modern)
                layoutParams = LinearLayout.LayoutParams((38 * density).toInt(), (38 * density).toInt()).apply {
                    marginStart = (12 * density).toInt()
                }
                contentDescription = "Remove ${addon.name}"
                setOnClickListener {
                    stremioSources.removeAt(index)
                    renderStremioSources()
                    stremioStatusText.text = "Removed ${addon.name}"
                }
            }
            val icon = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams((42 * density).toInt(), (42 * density).toInt()).apply { marginEnd = (12 * density).toInt() }
                scaleType = ImageView.ScaleType.FIT_CENTER
                setBackgroundColor(0x22000000)
            }
            if (addon.iconUrl.isNotBlank()) {
                Glide.with(this).load(com.channelsdebrid.tv.net.BackendEndpoint.imageProxyUrl(addon.iconUrl)).diskCacheStrategy(DiskCacheStrategy.ALL).into(icon)
            } else {
                icon.setImageResource(android.R.drawable.sym_def_app_icon)
            }
            row.addView(icon)
            row.addView(textWrap)
            row.addView(remove)
            val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            if (index > 0) params.topMargin = (10 * density).toInt()
            stremioSourcesContainer.addView(row, params)
        }
        rearmStremioAddButton("render_complete")
    }



    private fun normalizeTrailerDelay(raw: String, fallbackMs: Long, allowZero: Boolean = false): Long {
        val value = raw.trim().toLongOrNull() ?: fallbackMs
        val ms = if (value in 0..60) value * 1000L else value
        val min = if (allowZero) 0L else 1000L
        return ms.coerceIn(min, 60000L)
    }

    private fun normalizeBackendBase(raw: String): String {
        val value = raw.trim()
        if (value.isBlank()) return ""
        val withScheme = if (value.startsWith("http://") || value.startsWith("https://")) value else "http://$value"
        return withScheme.trimEnd('/')
    }

    private fun epgIntervalLabel(hours: Int): String = when {
        hours <= 3 -> "3 hours"
        hours <= 6 -> "6 hours"
        else -> "12 hours"
    }

    private fun parseEpgIntervalHours(raw: String): Int {
        val value = Regex("""\d+""").find(raw.trim().lowercase())?.value?.toIntOrNull() ?: 6
        return when {
            value <= 3 -> 3
            value <= 6 -> 6
            else -> 12
        }
    }

    private fun refreshLocalEpgNow(): String {
        saveAll()
        val hours = parseEpgIntervalHours(liveBackendEpgIntervalInput.text.toString())
        getSharedPreferences("live_tv_epg_cache", MODE_PRIVATE).edit()
            .clear()
            .putBoolean("force_refresh_requested", true)
            .apply()
        var deleted = 0
        listOf(filesDir, cacheDir).forEach { dir ->
            runCatching {
                dir.listFiles()?.forEach { file ->
                    val name = file.name
                    if (name.startsWith("hdhomerun_guide") || name.startsWith("channels_dvr_guide_") || name.startsWith("live_epg_") || name.startsWith("xmltv_")) {
                        if (file.delete()) deleted++
                    }
                }
            }
        }
        return "Local EPG refresh queued • ${hours}h cache • cleared $deleted guide cache files. Open Live TV to reload direct guide data."
    }

    private fun pushBackendEpgSettings(): String = "BACKEND_MODE: REMOVED"

    private fun refreshBackendEpgNow(): String = refreshLocalEpgNow()

    private fun testLiveBackend(baseUrlRaw: String, userIdRaw: String): String = "BACKEND_MODE: REMOVED - app uses direct XMLTV/IPTV/Xtream/Channels paths"

    private fun connectChannelsSourceToBackend(): String = "CHANNELS_DVR_MANUAL_ONLY: ACTIVE"


    private fun requestCode(url: String): Int {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 6000
        connection.readTimeout = 6000
        connection.setRequestProperty("Accept", "application/json")
        return try {
            connection.responseCode
        } finally {
            connection.disconnect()
        }
    }


    private fun getText(url: String): String {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 5000
        connection.readTimeout = 5000
        connection.setRequestProperty("Accept", "application/json")
        return try {
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        } finally {
            connection.disconnect()
        }
    }

    private fun readEpgProgress(baseUrl: String, userId: String): String {
        val candidates = listOf(
            "$baseUrl/live/epg/progress?userId=$userId",
            "$baseUrl/live/epg/status?userId=$userId",
            "$baseUrl/live/epg/progress?user_id=$userId",
            "$baseUrl/live/epg/status?user_id=$userId"
        )
        for (url in candidates) {
            val text = runCatching { getText(url) }.getOrNull().orEmpty()
            if (text.isBlank()) continue
            val json = runCatching { JSONObject(text) }.getOrNull() ?: continue
            val message = listOf(
                json.optString("message"),
                json.optString("stage"),
                json.optString("status"),
                json.optString("state")
            ).firstOrNull { it.isNotBlank() }.orEmpty()
            val progress = when {
                json.has("progress") -> json.optInt("progress", -1)
                json.has("percent") -> json.optInt("percent", -1)
                else -> -1
            }
            val channelCount = json.optInt("channels", json.optInt("channelCount", -1))
            val programCount = json.optInt("programs", json.optInt("programCount", -1))
            val parts = mutableListOf<String>()
            parts += if (message.isNotBlank()) message else "EPG refresh running"
            if (progress >= 0) parts += "$progress%"
            if (channelCount >= 0) parts += "$channelCount channels"
            if (programCount >= 0) parts += "$programCount programs"
            return parts.joinToString(" • ")
        }
        return "EPG refresh running…"
    }

    private data class HttpPostResult(val code: Int, val body: String) {
        fun errorSuffix(): String {
            val clean = body.replace(Regex("\\s+"), " ").trim()
            return if (clean.isBlank()) "" else " • " + clean.take(120)
        }
    }

    private fun postJsonResultWithRetry(url: String, body: String): HttpPostResult {
        var last = HttpPostResult(-1, "")
        repeat(3) { attempt ->
            last = postJsonResult(url, body)
            if (last.code in 200..299) return last
            try { Thread.sleep((350L * (attempt + 1)).coerceAtMost(1200L)) } catch (_: InterruptedException) { return last }
        }
        return last
    }

    private fun postJsonWithRetry(url: String, body: String): Int = postJsonResultWithRetry(url, body).code

    private fun postJson(url: String, body: String): Int = postJsonResult(url, body).code

    private fun postJsonResult(url: String, body: String): HttpPostResult {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = "POST"
        connection.connectTimeout = 8000
        connection.readTimeout = 8000
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        connection.setRequestProperty("Accept", "application/json")
        connection.outputStream.bufferedWriter().use { it.write(body) }
        return try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            HttpPostResult(code, stream?.bufferedReader()?.use { it.readText() }.orEmpty())
        } finally {
            connection.disconnect()
        }
    }


    private fun validateSavedTimeshiftStorage(storage: StorageSettings) {
        android.util.Log.i("DebridChannels", "TIMESHIFT: REMOVED storage validation skipped")
    }

    private fun hideRemovedLegacyViews() {
        val ids = intArrayOf(            R.id.realDebridEnabledSwitch, R.id.realDebridApiKeyInput,
            R.id.torBoxEnabledSwitch, R.id.torBoxApiKeyInput,            R.id.timeshiftMinutesInput, R.id.timeshiftEnabledSwitch
        )
        ids.forEach { id -> findViewById<View>(id)?.visibility = View.GONE }
    }

    private fun forceRefreshHdHomeRunGuideCache() {
        val prefs = getSharedPreferences("channels_debrid_settings", MODE_PRIVATE)
        prefs.edit()
            .remove("hdhomerun_manual_guide_cache_xml")
            .remove("hdhomerun_manual_guide_cache_updated_at")
            .apply()
        runCatching { File(filesDir, "hdhomerun_manual_xmltv_guide.xml").delete() }
        runCatching { File(filesDir, "hdhomerun_manual_xmltv_guide.timestamp").delete() }
        runCatching { File(filesDir, "live_tv_cache.json").delete() }
        Toast.makeText(this, "HDHomeRun guide cache cleared. Save settings, then reopen Live TV.", Toast.LENGTH_LONG).show()
        channelsStatusText.text = "Manual HDHomeRun guide refresh requested. Save settings, then reopen Live TV."
    }

    private fun saveAll() {
        repository.saveTmdb(
            TmdbSettings(
                apiKey = tmdbApiKeyInput.text.toString().trim(),
                region = tmdbRegionInput.text.toString().trim().ifEmpty { "US" },
                language = tmdbLanguageInput.text.toString().trim().ifEmpty { "en-US" }
            )
        )

        repository.saveCatalogs(
            CatalogSettings(
                trendingMoviesEnabled = catalogTrendingMoviesSwitch.isChecked,
                popularMoviesEnabled = catalogPopularMoviesSwitch.isChecked,
                trendingShowsEnabled = catalogTrendingShowsSwitch.isChecked,
                popularShowsEnabled = catalogPopularShowsSwitch.isChecked,
                platformRowsEnabled = catalogPlatformSwitch.isChecked,
                stremioCatalogRowsEnabled = catalogStremioSwitch.isChecked
            )
        )

        val pendingAddon = buildAddonFromInputs()
        val addonsToSave = (stremioSources + listOfNotNull(pendingAddon))
            .distinctBy { it.manifestUrl.trim().lowercase() }
            .mapIndexed { index, addon ->
                addon.copy(
                    id = if (index == 0) "primary" else "addon_${index + 1}",
                    enabled = stremioEnabledSwitch.isChecked
                )
            }
        repository.saveStremioAddons(addonsToSave)
        repository.saveLiveBackend(
            LiveBackendSettings(
                baseUrl = normalizeBackendBase(liveBackendBaseUrlInput.text.toString().trim()),
                userId = liveBackendUserIdInput.text.toString().trim().ifEmpty { "demo" },
                autoSyncSources = liveBackendAutoSyncSwitch.isChecked,
                epgRefreshEveryHours = parseEpgIntervalHours(liveBackendEpgIntervalInput.text.toString()),
                xmltvGuideUrl = liveXmltvGuideUrlInput.text.toString().trim()
            )
        )
        // Normal Settings Save must be local-only. Backend calls here can block every tab
        // and were preventing Stremio/add-on settings from saving when the backend was busy.

        val existingDvr = repository.loadChannelsDvr()
        val newBaseUrl = channelsBaseUrlInput.text.toString().trim()
        repository.saveChannelsDvr(
            ChannelsDvrSettings(
                autoDetect = false,
                hdHomeRunAutoScan = channelsAutoDetectSwitch.isChecked,
                hdHomeRunManualUrl = hdHomeRunManualUrlInput.text.toString().trim(),
                hdHomeRunUseManualGuide = hdHomeRunUseManualGuideSwitch.isChecked,
                hdHomeRunManualGuideUrl = hdHomeRunManualGuideUrlInput.text.toString().trim(),
                baseUrl = newBaseUrl,
                deviceId = if (existingDvr.baseUrl.trim().trimEnd('/') == newBaseUrl.trim().trimEnd('/')) existingDvr.deviceId else ""
            )
        )

        repository.saveXtream(
            XtreamSettings(
                server = xtreamServerInput.text.toString().trim(),
                username = xtreamUsernameInput.text.toString().trim(),
                password = xtreamPasswordInput.text.toString().trim(),
                m3uUrl = xtreamM3uInput.text.toString().trim(),
                enabled = xtreamEnabledSwitch.isChecked
            )
        )

        val requestedStorageTarget = storageTargetInput.text.toString().trim().ifEmpty { "internal" }
        val storageTargetAllowsMovieCache = requestedStorageTarget.equals("nas", ignoreCase = true) || requestedStorageTarget.equals("usb", ignoreCase = true)
        val storageSettings = StorageSettings(
            preferredTarget = requestedStorageTarget,
            usbPath = storageUsbInput.text.toString().trim(),
            nasPath = storageNasInput.text.toString().trim(),
            nasHost = storageNasHostInput.text.toString().trim().removePrefix("smb://").substringBefore("/"),
            nasShare = storageNasShareInput.text.toString().trim().trim('/'),
            nasUsername = storageNasUsernameInput.text.toString().trim(),
            nasPassword = storageNasPasswordInput.text.toString().trim(),
            timeshiftMinutes = 0,
            movieCacheEnabled = movieCacheSwitch.isChecked && storageTargetAllowsMovieCache
        )
        if (movieCacheSwitch.isChecked && !storageTargetAllowsMovieCache) {
            Toast.makeText(this, "Movie cache blocked: choose NAS or USB first. Internal disk caching is disabled.", Toast.LENGTH_LONG).show()
        }
        repository.saveStorage(storageSettings)
        validateSavedTimeshiftStorage(storageSettings)

        repository.saveTrailers(
            TrailerSettings(
                enabled = trailerEnabledSwitch.isChecked,
                autoplayOnFocus = trailerAutoplaySwitch.isChecked,
                autoplayDelayMs = normalizeTrailerDelay(trailerDelayInput.text.toString(), 5000L),
                backgroundAutoplayEnabled = trailerBackgroundSwitch.isChecked,
                backgroundAutoplayDelayMs = normalizeTrailerDelay(trailerBackgroundDelayInput.text.toString(), 5000L, allowZero = true),
                popupMode = "hero_background",
                playbackLocation = trailerLocationInput.text.toString().trim().lowercase().ifEmpty { "both" },
                youtubeApiKey = "",
                prefer4k = trailerPrefer4kSwitch.isChecked
            )
        )

        repository.savePlayback(
            PlaybackSettings(
                frameRateMatching = frameRateSwitch.isChecked,
                preferExternalStorageForCache = preferExternalSwitch.isChecked,
                timeshiftEnabled = false,
                autoPlayBestStream = autoPlayBestSwitch.isChecked,
                fileSizeLimitGb = fileSizeLimitInput.text.toString().toIntOrNull() ?: 40,
                ultraHdGuideUiEnabled = fourKUiSwitch.isChecked,
                liveStatusChecksEnabled = liveStatusChecksSwitch.isChecked,
                liveGuideBackgroundArtEnabled = liveGuideBackgroundArtSwitch.isChecked,
                liveGuideProgramThumbnailsEnabled = liveGuideProgramThumbnailsSwitch.isChecked,
                preferredAudioLanguage = playerAudioLanguageInput.text.toString().trim().ifEmpty { "Auto" },
                preferredSubtitleLanguage = playerSubtitleLanguageInput.text.toString().trim().ifEmpty { "Off" },
                subtitleMode = playerSubtitleModeInput.text.toString().trim().ifEmpty { "Off" },
                hdrMode = playerHdrModeInput.text.toString().trim().ifEmpty { "Auto" },
                audioOutputMode = playerAudioOutputModeInput.text.toString().trim().ifEmpty { "Auto" },
                bufferProfile = playerBufferProfileInput.text.toString().trim().ifEmpty { "Balanced" },
                streamQualityPreference = playerStreamQualityInput.text.toString().trim().ifEmpty { "Auto" },
                letterboxBackground = playerLetterboxBackgroundInput.text.toString().trim().ifEmpty { "Black bars" },
                resumeBehavior = playerResumeBehaviorInput.text.toString().trim().ifEmpty { "Auto resume" },
                playerEngine = playerEngineInput.text.toString().trim().ifEmpty { "Auto" }
            )
        )
    }
}
