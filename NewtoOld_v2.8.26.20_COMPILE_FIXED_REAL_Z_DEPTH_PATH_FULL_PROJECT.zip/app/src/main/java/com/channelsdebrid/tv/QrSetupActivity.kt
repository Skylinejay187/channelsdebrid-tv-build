package com.channelsdebrid.tv

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import java.util.EnumMap

class QrSetupActivity : AppCompatActivity() {
    private companion object { private const val TAG = "DebridChannels" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val code = pairingCode()
        val payload = "debridchannels://pair?code=$code&device=${Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID).orEmpty()}"
        Log.i(TAG, "QR_SYSTEM_ACTIVITY_OPEN: code=$code localPairing=true")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(48), dp(32), dp(48), dp(32))
            setBackgroundColor(Color.rgb(4, 5, 8))
        }
        root.addView(TextView(this).apply {
            text = "QR Setup"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Scan to pair, import/export setup, or configure Debrid Channels from another device."
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(0xFF92A0B7.toInt())
            setPadding(0, dp(8), 0, dp(18))
        })
        root.addView(ImageView(this).apply { setImageBitmap(makeQr(payload, dp(310))) }, LinearLayout.LayoutParams(dp(330), dp(330)))
        root.addView(TextView(this).apply {
            text = "Pairing code: $code"
            textSize = 22f
            setTextColor(0xFFEAD8BF.toInt())
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(18), 0, dp(8))
        })
        root.addView(TextView(this).apply {
            text = "Foundation ready: QR pairing, profile setup, preset import/export handoff. Backend/device portal can attach to this code later."
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(0xFF7D8BA6.toInt())
        })
        root.addView(Button(this).apply {
            text = "Copy / Refresh Code"
            isAllCaps = false
            setOnClickListener { Toast.makeText(this@QrSetupActivity, "Code refreshed on next open", Toast.LENGTH_SHORT).show() }
        }, LinearLayout.LayoutParams(dp(260), dp(48)).apply { topMargin = dp(18) })
        root.addView(Button(this).apply {
            text = "Back"
            isAllCaps = false
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(180), dp(44)).apply { topMargin = dp(10) })
        setContentView(root)
    }

    private fun pairingCode(): String {
        val raw = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID).orEmpty().ifBlank { "DEBRID" }
        return raw.takeLast(6).uppercase().padStart(6, '0')
    }

    private fun makeQr(text: String, size: Int): Bitmap {
        val hints = EnumMap<EncodeHintType, Any>(EncodeHintType::class.java)
        hints[EncodeHintType.MARGIN] = 1
        val matrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints)
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        for (x in 0 until size) for (y in 0 until size) bitmap.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
        return bitmap
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
