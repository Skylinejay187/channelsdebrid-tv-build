package com.channelsdebrid.tv

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ProfilesActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("channels_debrid_settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val active = ProfileManager.activeProfile(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(48), dp(34), dp(48), dp(34))
            setBackgroundColor(Color.rgb(4, 5, 8))
        }
        root.addView(title("Profiles", 30f))
        root.addView(subtitle("Choose who is watching. Kids profile support is local and ready for catalog filtering / PIN enforcement."))

        val current = subtitle("Current profile: ${active.name}${if (active.kidsMode) "  •  Kids mode" else ""}").apply { setTextColor(0xFFEAD8BF.toInt()) }
        root.addView(current)

        val adult = action("Use Adult Profile") {
            ProfileManager.setActiveProfile(this, "adult")
            Toast.makeText(this, "Adult profile active", Toast.LENGTH_SHORT).show()
            recreate()
        }
        val kids = action("Use Kids Profile") {
            ProfileManager.setActiveProfile(this, "kids")
            Toast.makeText(this, "Kids profile active", Toast.LENGTH_SHORT).show()
            recreate()
        }
        val pin = EditText(this).apply {
            hint = "Kids PIN (optional)"
            setHintTextColor(0xFF7D8BA6.toInt())
            setTextColor(Color.WHITE)
            setSingleLine(true)
            setPadding(dp(16), 0, dp(16), 0)
            setText(prefs.getString("profile_kids_pin", ""))
            background = roundedBg()
        }
        val savePin = action("Save Kids Profile Settings") {
            ProfileManager.saveKidsPin(this, pin.text.toString())
            Toast.makeText(this, "Kids profile settings saved", Toast.LENGTH_SHORT).show()
        }
        val back = action("Back") { finish() }

        root.addView(adult)
        root.addView(kids)
        root.addView(pin, LinearLayout.LayoutParams(520, dp(52)).apply { topMargin = dp(18) })
        root.addView(savePin)
        root.addView(back)
        setContentView(root)
    }

    private fun title(text: String, size: Float) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
    }

    private fun subtitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(0xFF92A0B7.toInt())
        setPadding(0, dp(8), 0, dp(14))
    }

    private fun action(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
        background = roundedBg()
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(420, dp(48)).apply { topMargin = dp(14) }
    }

    private fun roundedBg() = android.graphics.drawable.GradientDrawable().apply {
        cornerRadius = dp(18).toFloat()
        setColor(0xFF11161E.toInt())
        setStroke(1, 0x55EAD8BF.toInt())
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
