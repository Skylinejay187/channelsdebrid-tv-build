package com.channelsdebrid.tv

import android.animation.ObjectAnimator
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class StartupActivity : AppCompatActivity() {
    private companion object { private const val TAG = "DebridChannels" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i(TAG, "STARTUP_ANIMATION_APPLY: letters=DebridChannels loadingCircle=true lessBlueBrand=true")
        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(2, 3, 6)) }
        val title = TextView(this).apply {
            text = "Debrid Channels"
            textSize = 34f
            letterSpacing = 0.08f
            setTextColor(0xFFEAD8BF.toInt())
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            alpha = 0f
        }
        val progress = ProgressBar(this).apply { isIndeterminate = true; alpha = 0f }
        root.addView(title, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp(80), Gravity.CENTER).apply { bottomMargin = dp(36) })
        root.addView(progress, FrameLayout.LayoutParams(dp(64), dp(64), Gravity.CENTER).apply { topMargin = dp(80) })
        setContentView(root)
        ObjectAnimator.ofFloat(title, "alpha", 0f, 1f).setDuration(450).start()
        ObjectAnimator.ofFloat(progress, "alpha", 0f, 1f).setDuration(450).start()
        ObjectAnimator.ofFloat(title, "translationY", dp(14).toFloat(), 0f).setDuration(500).start()
        ObjectAnimator.ofFloat(progress, "rotation", 0f, 360f).apply { duration = 900; repeatCount = ObjectAnimator.INFINITE; interpolator = LinearInterpolator(); start() }
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }, 1150)
    }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
