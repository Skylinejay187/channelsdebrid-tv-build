package com.channelsdebrid.tv

import android.content.Context
import android.util.Log

object ProfileManager {
    private const val PREFS = "channels_debrid_settings"
    private const val TAG = "DebridChannels"

    data class Profile(
        val id: String,
        val name: String,
        val kidsMode: Boolean,
        val pinProtected: Boolean
    )

    fun activeProfile(context: Context): Profile {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val id = prefs.getString("profile_active_id", "adult") ?: "adult"
        return if (id == "kids") {
            Profile("kids", prefs.getString("profile_kids_name", "Kids").orEmpty().ifBlank { "Kids" }, true, true)
        } else {
            Profile("adult", prefs.getString("profile_adult_name", "Adult").orEmpty().ifBlank { "Adult" }, false, false)
        }
    }

    fun setActiveProfile(context: Context, id: String) {
        val safe = if (id == "kids") "kids" else "adult"
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString("profile_active_id", safe)
            .apply()
        Log.i(TAG, "PROFILE_ACTIVE_APPLY: id=$safe kids=${safe == "kids"}")
    }

    fun saveKidsPin(context: Context, pin: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString("profile_kids_pin", pin.take(12))
            .putBoolean("profile_kids_enabled", true)
            .putBoolean("profile_kids_hide_adult", true)
            .putBoolean("profile_kids_safe_search", true)
            .apply()
        Log.i(TAG, "PROFILE_KIDS_SAVE: enabled=true safeSearch=true pinSet=${pin.isNotBlank()}")
    }

    fun kidsEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("profile_kids_enabled", true)
}
