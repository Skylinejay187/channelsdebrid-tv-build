package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.6 ACTIVE ROW VIEWPORT + CARD LOGO FIX";
    public static final String LOG_MARKER = "DC_V0_6_ACTIVE_ROW_VIEWPORT_CARD_LOGO_FIX_ACTIVE";
    private BuildMarkers() {}
}
