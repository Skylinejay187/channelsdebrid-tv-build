# Rewrite Build Audit - v0.6

Base used: v0.4/v6.9 stable line.
Build rule followed: clean rewrite/consolidation from the latest known-good stable base; broken v7.1/v0.5 behavior was not used as a source of truth.

Fixes included:
- Active row viewport: only the selected home row is visible/aligned at a time.
- DPAD UP/DOWN switches active rows in the real MainActivity renderer.
- Card overlay logo is only shown when the URL is a safe logo/clearlogo asset, preventing poster/square art from appearing in front of cards.
- Version and log markers updated to v0.6.
