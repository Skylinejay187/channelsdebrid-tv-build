Debrid Channels v0.6 - Active Row Viewport + Card Logo Fix
