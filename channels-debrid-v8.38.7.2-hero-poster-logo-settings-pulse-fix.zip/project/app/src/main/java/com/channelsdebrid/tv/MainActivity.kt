
package com.channelsdebrid.tv

import android.animation.Animator
import android.content.Intent
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.graphics.Outline
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.KeyEvent
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.bumptech.glide.request.RequestOptions
import com.channelsdebrid.tv.databinding.ActivityMainBinding
import com.channelsdebrid.tv.settings.SettingsRepository
import com.channelsdebrid.tv.data.TmdbLiveLoader
import com.channelsdebrid.tv.data.StremioLiveLoader
import com.channelsdebrid.tv.data.SourceProbe
import com.channelsdebrid.tv.BuildConfig
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.ConcurrentHashMap
import android.widget.Toast
import com.channelsdebrid.tv.playback.PlayerActivity
import com.channelsdebrid.tv.playback.PlaybackResolver
import com.channelsdebrid.tv.LiveTvActivity

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var settingsRepository: SettingsRepository
    private val tmdbLiveLoader = TmdbLiveLoader()
    private val stremioLiveLoader = StremioLiveLoader()
    private val sourceProbe = SourceProbe()
    private val playbackResolver = PlaybackResolver()
    private val liveExecutor = Executors.newSingleThreadExecutor()
    private val heroLogoExecutor = Executors.newSingleThreadExecutor()
    private var tmdbRequestVersion = 0
    private var stremioRequestVersion = 0
    private var startupFocusLocked = true
    @Volatile private var pendingHeroLogoRequestKey: String? = null
    private val resolvedHeroLogoCache = ConcurrentHashMap<String, String>()
    private val loadedCardArtworkRequests = ConcurrentHashMap<Int, String>()
    private val loadedCardLogoRequests = ConcurrentHashMap<Int, String>()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var pendingHeroCommitRunnable: Runnable? = null
    private var committedHeroRequestKey: String? = null
    private var pendingRevealRunnable: Runnable? = null
    private var pendingRowSettleRunnable: Runnable? = null
    private var pendingNavigationIdleRunnable: Runnable? = null
    private var pendingBottomHudHideRunnable: Runnable? = null
    private var bottomHudDismissedForSession = false
    private var lastFocusedCardId: Int = View.NO_ID
    private var lastTopMenuFocusId: Int = View.NO_ID
    private var activeRowSection: RowSection? = null
    private var rowSettleInProgress = false
    private var navigationInFlight = false
    private var motionIdleDeadlineMs: Long = 0L
    private var pendingLiveRowsRunnable: Runnable? = null
    private var pendingLiveStremioRunnable: Runnable? = null
    private var liveRowsAppliedOnce = false
    private var initialWindowFocusHandled = false
    private var lastDirectionalKeyCode: Int = KeyEvent.KEYCODE_UNKNOWN
    private var lastDirectionalKeyAtMs: Long = 0L

    private enum class RowSection {
        FIRST,
        SECOND,
        THIRD,
        FOURTH,
        FIFTH,
        SIXTH,
        SEVENTH
    }

    private data class RowSlot(
        val section: RowSection,
        val titleView: TextView,
        val subtitleView: TextView,
        val scrollView: HorizontalScrollView,
        val rowLayout: LinearLayout
    )

    private data class HomeRowSpec(
        val title: String,
        val subtitle: String,
        val section: RowSection,
        val items: List<TitleCard>
    )

    data class TitleCard(
        val title: String,
        val meta: String,
        val desc: String,
        val badge: String,
        val brand: String,
        val footer: String,
        val progress: Float,
        val backgroundRes: Int,
        val posterUrl: String? = null,
        val backdropUrl: String? = null,
        val logoUrl: String? = null,
        val mediaType: String? = null,
        val tmdbId: Int = 0,
        val sourceKey: String? = null
    )

    private val heroTitles = listOf(
        TitleCard("SHŌGUN", "S1 E7: A Stick of Time  •  43 min left", "A premium lean-back presentation for your media center, with live TV, trending shows, smart recommendations, and instant playback.", "⚑  Instant Playback Ready", "FX", "43 min left", 0.58f, R.drawable.bg_shogun),
        TitleCard("THE BATMAN", "2h 56m  •  IMAX", "A darker detective spotlight with premium backdrop changes and clean TV-safe row alignment.", "⚑  Direct Play Ready", "PLEX", "IMAX", 0.42f, R.drawable.bg_batman),
        TitleCard("FALLOUT", "49 min left  •  Prime", "Post-apocalyptic action with large-format hero art and poster rows that stay locked in place.", "⚑  Synced to Library", "prime", "49 min left", 0.51f, R.drawable.bg_fallout),
        TitleCard("DUNE", "2h 35m  •  Max", "Expansive cinema-style focus treatment with large typography and backdrop-driven navigation.", "⚑  HDR Available", "max", "Featured", 0.46f, R.drawable.bg_dune),
        TitleCard("HALO", "Series  •  Prime", "Sci-fi recommendations rendered in the same composition language as your reference shot.", "⚑  Resume Synced", "prime", "Series", 0.33f, R.drawable.bg_halo),
        TitleCard("WONKA", "Movie  •  Max", "Bright contrast title art for spotlight and recently-added rows without breaking the layout grid.", "⚑  Trailer Ready", "max", "Movie", 0.37f, R.drawable.bg_wonka),
        TitleCard("MAYOR OF KINGSTOWN", "Series  •  Paramount+", "Grounded drama hero state with full-screen poster changes as focus moves across rows.", "⚑  Watched on Device", "P+", "Series", 0.28f, R.drawable.bg_mayor),
        TitleCard("CIVIL WAR", "Movie  •  109 min", "Poster rows line up under the hero so the screen still feels premium and intentional.", "⚑  Cache Eligible", "A24", "109 min", 0.22f, R.drawable.bg_civilwar),
        TitleCard("AVATAR", "Movie  •  Disney+", "High-contrast blockbuster art for the lower row examples and future trailer pop-up placement.", "⚑  Dolby Vision", "D+", "Featured", 0.48f, R.drawable.bg_avatar)
    )

    private fun rowSlots(): List<RowSlot> = listOf(
        RowSlot(RowSection.FIRST, binding.rowOneTitle, binding.rowOneSubtitle, binding.rowOneScroll, binding.rowOne),
        RowSlot(RowSection.SECOND, binding.rowTwoTitle, binding.rowTwoSubtitle, binding.rowTwoScroll, binding.rowTwo),
        RowSlot(RowSection.THIRD, binding.rowThreeTitle, binding.rowThreeSubtitle, binding.rowThreeScroll, binding.rowThree),
        RowSlot(RowSection.FOURTH, binding.rowFourTitle, binding.rowFourSubtitle, binding.rowFourScroll, binding.rowFour),
        RowSlot(RowSection.FIFTH, binding.rowFiveTitle, binding.rowFiveSubtitle, binding.rowFiveScroll, binding.rowFive),
        RowSlot(RowSection.SIXTH, binding.rowSixTitle, binding.rowSixSubtitle, binding.rowSixScroll, binding.rowSix),
        RowSlot(RowSection.SEVENTH, binding.rowSevenTitle, binding.rowSevenSubtitle, binding.rowSevenScroll, binding.rowSeven)
    )

    private fun firstVisibleRowSlot(): RowSlot? = rowSlots().firstOrNull { it.scrollView.visibility == View.VISIBLE && it.rowLayout.childCount > 0 }

    private fun lastVisibleRowSlot(): RowSlot? = rowSlots().lastOrNull { it.scrollView.visibility == View.VISIBLE && it.rowLayout.childCount > 0 }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        settingsRepository = SettingsRepository(this)
        binding.contentScroll.clipToPadding = false
        binding.contentScroll.clipChildren = false
        rowSlots().forEach {
            it.scrollView.clipToPadding = false
            it.scrollView.clipChildren = false
            it.rowLayout.clipToPadding = false
            it.rowLayout.clipChildren = false
        }

        commitHero(heroTitles[3])
        applySettingsToHome()
        lockRowsForStartup()
        wireTopControls()
        wireRowNavigation()
        showBottomHudTemporarily()
        binding.contentScroll.post {
            binding.contentScroll.scrollTo(0, 0)
            binding.contentScroll.postDelayed({
                unlockRowsAfterStartup()
                binding.contentScroll.scrollTo(0, 0)
                requestInitialRowFocus()
            }, 90)
            binding.contentScroll.postDelayed({
                binding.contentScroll.scrollTo(0, 0)
                requestInitialRowFocus()
            }, 220)
            binding.contentScroll.postDelayed({
                binding.contentScroll.scrollTo(0, 0)
                requestInitialRowFocus()
            }, 520)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        pendingHeroCommitRunnable?.let(mainHandler::removeCallbacks)
        pendingRevealRunnable?.let(mainHandler::removeCallbacks)
        pendingRowSettleRunnable?.let(mainHandler::removeCallbacks)
        pendingNavigationIdleRunnable?.let(mainHandler::removeCallbacks)
        pendingBottomHudHideRunnable?.let(mainHandler::removeCallbacks)
        pendingLiveRowsRunnable?.let(mainHandler::removeCallbacks)
        pendingLiveStremioRunnable?.let(mainHandler::removeCallbacks)
        liveExecutor.shutdownNow()
        heroLogoExecutor.shutdownNow()
    }

    override fun onResume() {
        super.onResume()
        applySettingsToHome()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || initialWindowFocusHandled) return
        initialWindowFocusHandled = true
        binding.contentScroll.post {
            unlockRowsAfterStartup()
            binding.contentScroll.scrollTo(0, 0)
            requestInitialRowFocus()
        }
        binding.contentScroll.postDelayed({
            if (!isFinishing && !isDestroyed) {
                binding.contentScroll.scrollTo(0, 0)
                requestInitialRowFocus()
            }
        }, 180L)
    }

    private fun applySettingsToHome() {
        val catalogs = settingsRepository.loadCatalogs()
        val tmdb = settingsRepository.loadTmdb()
        val stremio = settingsRepository.loadPrimaryAddon().let {
            if (it.manifestUrl.isBlank()) it.copy(name = "Cinemeta", manifestUrl = "https://v3-cinemeta.strem.io/manifest.json", enabled = true) else it
        }
        val debrid = settingsRepository.loadDebrid()
        val dvr = settingsRepository.loadChannelsDvr()
        val xtream = settingsRepository.loadXtream()
        val trailers = settingsRepository.loadTrailers()
        val playback = settingsRepository.loadPlayback()
        val storage = settingsRepository.loadStorage()
        val sourceSummary = buildInitialSourceSummary(stremio.enabled, dvr, xtream, debrid)

        val sectionOrder = RowSection.values().toList()
        val rowSpecs = mutableListOf<HomeRowSpec>()
        fun addRow(title: String, subtitle: String, itemOffset: Int) {
            if (rowSpecs.size >= sectionOrder.size) return
            rowSpecs += HomeRowSpec(
                title = title,
                subtitle = subtitle,
                section = sectionOrder[rowSpecs.size],
                items = List(24) { index -> heroTitles[(index + itemOffset) % heroTitles.size] }
            )
        }

        if (catalogs.trendingMoviesEnabled) addRow("Popular Movies", "Cinemeta • built-in posters", 3)
        if (catalogs.popularMoviesEnabled) addRow("Popular Shows", "Cinemeta • built-in posters", 5)
        if (catalogs.trendingShowsEnabled) addRow("Featured Movies", "Cinemeta • built-in posters", 6)
        if (catalogs.popularShowsEnabled) addRow("Featured Series", "Cinemeta • built-in posters", 1)
        if (catalogs.platformRowsEnabled) addRow("More From Cinemeta", "Built-in Stremio catalog", 2)
        addRow("Catalog Picks", "Cinemeta • main artwork source", 7)
        if (catalogs.stremioCatalogRowsEnabled) {
            val addonName = stremio.name.ifBlank { "Stremio" }
            addRow(
                "$addonName Catalog",
                if (stremio.enabled) "Addon ready • custom rows" else "Addon configured • currently disabled",
                4
            )
        }
        while (rowSpecs.size < sectionOrder.size) {
            addRow("Featured Picks ${rowSpecs.size + 1}", "Fallback catalog • browse ready", rowSpecs.size + 2)
        }

        rowSlots().forEachIndexed { index, slot ->
            bindRowSpec(rowSpecs.getOrNull(index), slot.titleView, slot.subtitleView, slot.scrollView, slot.rowLayout)
        }

        binding.infoChip.text = buildInfoChipText(trailers.enabled, playback.autoPlayBestStream, storage.movieCacheEnabled, sourceSummary)
        binding.statusBadge.text = buildStatusBadgeText(debrid.realDebridEnabled, debrid.torBoxEnabled, playback.timeshiftEnabled)
        binding.heroMeta.text = "Cinemeta • built-in catalog • ${if (trailers.enabled) "Trailers On" else "Trailers Off"}"
        binding.weatherPill.text = buildWeatherPill(playback.frameRateMatching)
        wireRowNavigation()
        binding.contentScroll.post {
            snapToRow(RowSection.FIRST, smooth = false)
        }
        scheduleLiveCatalogRefresh(catalogs, tmdb, stremio)
    }



    private fun bindRowSpec(
        spec: HomeRowSpec?,
        titleView: TextView,
        subtitleView: TextView,
        scrollView: HorizontalScrollView,
        rowLayout: LinearLayout
    ) {
        if (spec == null) {
            titleView.visibility = View.GONE
            subtitleView.visibility = View.GONE
            scrollView.visibility = View.GONE
            rowLayout.removeAllViews()
            return
        }
        titleView.visibility = View.VISIBLE
        subtitleView.visibility = View.VISIBLE
        scrollView.visibility = View.VISIBLE
        titleView.text = spec.title
        subtitleView.text = spec.subtitle

        rowLayout.removeAllViews()
        spec.items.forEachIndexed { index, item ->
            rowLayout.addView(makeCard(item, scrollView, binding.contentScroll, index, 258, 145))
        }
    }

    private fun buildInfoChipText(
        trailersEnabled: Boolean,
        autoBest: Boolean,
        movieCacheEnabled: Boolean,
        sourceSummary: String? = null
    ): String {
        val parts = mutableListOf<String>()
        parts += if (trailersEnabled) "Trailers On" else "Trailers Off"
        parts += if (autoBest) "Auto Best Stream" else "Manual Source Select"
        parts += if (movieCacheEnabled) "Movie Cache Ready" else "Cache Limited"
        sourceSummary?.takeIf { it.isNotBlank() }?.let { parts += it }
        return parts.joinToString("  •  ")
    }

    private fun buildStatusBadgeText(
        rdEnabled: Boolean,
        torBoxEnabled: Boolean,
        timeshiftEnabled: Boolean
    ): String {
        return when {
            rdEnabled -> "⚑  Real-Debrid Ready"
            torBoxEnabled -> "⚑  TorBox Ready"
            timeshiftEnabled -> "⚑  Timeshift Ready"
            else -> "⚑  Instant Playback Ready"
        }
    }

    private fun buildWeatherPill(frameRateMatchingEnabled: Boolean): String {
        return if (frameRateMatchingEnabled) {
            "1:33  •  Frame Match On"
        } else {
            "1:33  •  Frame Match Off"
        }
    }

    private fun buildInitialSourceSummary(
        stremioEnabled: Boolean,
        dvr: com.channelsdebrid.tv.settings.ChannelsDvrSettings,
        xtream: com.channelsdebrid.tv.settings.XtreamSettings,
        debrid: com.channelsdebrid.tv.settings.DebridSettings
    ): String {
        val parts = mutableListOf<String>()
        if (stremioEnabled) parts += "Cinemeta Built-In"
        if (debrid.realDebridEnabled) parts += "Real-Debrid Armed"
        if (debrid.torBoxEnabled) parts += "TorBox Armed"
        if (dvr.autoDetect || dvr.baseUrl.isNotBlank()) parts += "Channels DVR Ready"
        if (xtream.enabled) parts += "Xtream Ready"
        return parts.take(2).joinToString("  •  ")
    }



    private fun scheduleLiveCatalogRefresh(
        catalogs: com.channelsdebrid.tv.settings.CatalogSettings,
        tmdb: com.channelsdebrid.tv.settings.TmdbSettings,
        stremio: com.channelsdebrid.tv.settings.StremioAddonSettings
    ) {
        pendingLiveRowsRunnable?.let(mainHandler::removeCallbacks)
        pendingLiveStremioRunnable?.let(mainHandler::removeCallbacks)
        pendingLiveStremioRunnable = Runnable {
            maybeLoadLiveStremioRow(catalogs, stremio)
        }.also { mainHandler.postDelayed(it, if (liveRowsAppliedOnce) 180L else 320L) }
        pendingLiveRowsRunnable = Runnable {
            maybeLoadLiveTmdbRows(catalogs, tmdb)
        }.also { mainHandler.postDelayed(it, if (liveRowsAppliedOnce) 1200L else 2200L) }
    }

    private fun maybeLoadLiveTmdbRows(catalogs: com.channelsdebrid.tv.settings.CatalogSettings, tmdb: com.channelsdebrid.tv.settings.TmdbSettings) {
        if (liveRowsAppliedOnce || tmdb.apiKey.isBlank()) return

        val enabledKeys = mutableListOf<String>().apply {
            if (catalogs.trendingMoviesEnabled) add("trending_movies")
            if (catalogs.popularMoviesEnabled) add("popular_movies")
            if (catalogs.trendingShowsEnabled) add("trending_shows")
            if (catalogs.popularShowsEnabled) add("popular_shows")
            if (catalogs.platformRowsEnabled) add("platform_rows")
            add("top_rated_movies")
        }.take(6)

        if (enabledKeys.isEmpty()) return
        val requestVersion = ++tmdbRequestVersion

        liveExecutor.execute {
            val rows = runCatching {
                tmdbLiveLoader.loadRows(
                    apiKey = tmdb.apiKey,
                    region = tmdb.region.ifBlank { "US" },
                    language = tmdb.language.ifBlank { "en-US" },
                    enabledKeys = enabledKeys,
                    fanartApiKey = BuildConfig.FANART_API_KEY,
                    fanartClientKey = BuildConfig.FANART_CLIENT_KEY,
                    limit = 12
                )
            }.getOrDefault(emptyList())

            if (rows.isEmpty()) return@execute
            runOnUiThread {
                if (isFinishing || requestVersion != tmdbRequestVersion) return@runOnUiThread
                applyLiveRows(rows)
            }
        }
    }

    private fun applyLiveRows(rows: List<TmdbLiveLoader.LiveRow>) {
        val slots = rowSlots()
        if (rows.isEmpty()) return
        liveRowsAppliedOnce = true

        val firstChunk = rows.take(2)
        slots.forEachIndexed { index, slot ->
            bindLiveRow(firstChunk.getOrNull(index), slot.section, slot.titleView, slot.subtitleView, slot.scrollView, slot.rowLayout)
        }
        prefetchHeroAssets(firstChunk.flatMap { it.items }.take(4).mapIndexed { index, item -> mapLiveItemToTitleCard(item, index) })
        wireRowNavigation()

        if (lastFocusedCardId == View.NO_ID) {
            firstChunk.firstOrNull()?.items?.firstOrNull()?.let { commitHero(mapLiveItemToTitleCard(it, 0)) }
        }
        if (startupFocusLocked || currentFocus == null || isTopMenuView(currentFocus)) {
            binding.contentScroll.post {
                unlockRowsAfterStartup()
                requestInitialRowFocus()
            }
            binding.contentScroll.postDelayed({
                if (!isFinishing && !isDestroyed) requestInitialRowFocus()
            }, 140L)
        }

        val remaining = rows.drop(2)
        if (remaining.isEmpty()) {
            binding.contentScroll.post { snapToRow(RowSection.FIRST, smooth = false) }
            return
        }

        mainHandler.postDelayed({
            if (isFinishing || isDestroyed) return@postDelayed
            slots.forEachIndexed { index, slot ->
                bindLiveRow(rows.getOrNull(index), slot.section, slot.titleView, slot.subtitleView, slot.scrollView, slot.rowLayout)
            }
            prefetchHeroAssets(rows.flatMap { it.items }.take(6).mapIndexed { index, item -> mapLiveItemToTitleCard(item, index) })
            wireRowNavigation()
        }, 180L)
    }

    private fun bindLiveRow(
        row: TmdbLiveLoader.LiveRow?,
        section: RowSection,
        titleView: TextView,
        subtitleView: TextView,
        scrollView: HorizontalScrollView,
        rowLayout: LinearLayout
    ) {
        if (row == null) {
            titleView.visibility = View.GONE
            subtitleView.visibility = View.GONE
            scrollView.visibility = View.GONE
            rowLayout.removeAllViews()
            return
        }
        titleView.visibility = View.VISIBLE
        subtitleView.visibility = View.VISIBLE
        scrollView.visibility = View.VISIBLE
        titleView.text = row.title
        subtitleView.text = row.subtitle
        rowLayout.removeAllViews()
        val mappedItems = row.items.mapIndexed { index, item -> mapLiveItemToTitleCard(item, index) }
        row.items.forEachIndexed { index, _ ->
            rowLayout.addView(makeCard(mappedItems[index], scrollView, binding.contentScroll, index, 258, 145))
        }
        prefetchHeroAssets(mappedItems.take(2))
        prefetchCardArtwork(mappedItems)
    }

    private fun mapLiveItemToTitleCard(item: TmdbLiveLoader.LiveCatalogItem, index: Int): TitleCard {
        val fallback = heroTitles[index % heroTitles.size]
        return TitleCard(
            title = item.title,
            meta = item.meta,
            desc = item.desc,
            badge = item.badge,
            brand = item.brand,
            footer = item.footer,
            progress = item.progress.coerceIn(0.12f, 0.94f),
            backgroundRes = fallback.backgroundRes,
            posterUrl = item.posterUrl,
            backdropUrl = item.backdropUrl,
            logoUrl = item.logoUrl,
            mediaType = item.mediaType,
            tmdbId = item.tmdbId,
            sourceKey = "tmdb"
        )
    }
    private fun maybeLoadLiveStremioRow(
        catalogs: com.channelsdebrid.tv.settings.CatalogSettings,
        stremio: com.channelsdebrid.tv.settings.StremioAddonSettings
    ) {
        if (!catalogs.stremioCatalogRowsEnabled || !stremio.enabled || stremio.manifestUrl.isBlank()) return
        val requestVersion = ++stremioRequestVersion
        liveExecutor.execute {
            val rows = runCatching {
                stremioLiveLoader.loadRows(stremio.name.ifBlank { "Cinemeta" }, stremio.manifestUrl, 12)
            }.getOrDefault(emptyList())
            if (rows.isEmpty()) return@execute
            runOnUiThread {
                if (isFinishing || requestVersion != stremioRequestVersion) return@runOnUiThread
                applyStremioRows(rows)
            }
        }
    }

    private fun applyStremioRows(rows: List<com.channelsdebrid.tv.data.StremioLiveLoader.LiveRow>) {
        val slots = rowSlots()
        if (rows.isEmpty()) return
        liveRowsAppliedOnce = true

        val firstChunk = rows.take(2)
        slots.forEachIndexed { index, slot ->
            bindStremioRowInto(slot.titleView, slot.subtitleView, slot.scrollView, slot.rowLayout, firstChunk.getOrNull(index))
        }
        prefetchHeroAssets(firstChunk.flatMap { it.items }.take(4).mapIndexed { index, item -> mapStremioItemToTitleCard(item, index) })
        wireRowNavigation()

        if (lastFocusedCardId == View.NO_ID) {
            firstChunk.firstOrNull()?.items?.firstOrNull()?.let { commitHero(mapStremioItemToTitleCard(it, 0)) }
        }
        if (startupFocusLocked || currentFocus == null || isTopMenuView(currentFocus)) {
            binding.contentScroll.post {
                unlockRowsAfterStartup()
                requestInitialRowFocus()
            }
            binding.contentScroll.postDelayed({
                if (!isFinishing && !isDestroyed) requestInitialRowFocus()
            }, 140L)
        }

        val remaining = rows.drop(2)
        if (remaining.isEmpty()) {
            binding.contentScroll.post { snapToRow(RowSection.FIRST, smooth = false) }
            return
        }

        mainHandler.postDelayed({
            if (isFinishing || isDestroyed) return@postDelayed
            slots.forEachIndexed { index, slot ->
                bindStremioRowInto(slot.titleView, slot.subtitleView, slot.scrollView, slot.rowLayout, rows.getOrNull(index))
            }
            prefetchHeroAssets(rows.flatMap { it.items }.take(6).mapIndexed { index, item -> mapStremioItemToTitleCard(item, index) })
            wireRowNavigation()
        }, 180L)
    }

    private fun bindStremioRowInto(
        titleView: TextView,
        subtitleView: TextView,
        scrollView: HorizontalScrollView,
        rowLayout: LinearLayout,
        row: com.channelsdebrid.tv.data.StremioLiveLoader.LiveRow?
    ) {
        if (row == null) {
            titleView.visibility = View.GONE
            subtitleView.visibility = View.GONE
            scrollView.visibility = View.GONE
            rowLayout.removeAllViews()
            return
        }
        titleView.visibility = View.VISIBLE
        subtitleView.visibility = View.VISIBLE
        scrollView.visibility = View.VISIBLE
        titleView.text = row.title
        subtitleView.text = row.subtitle
        rowLayout.removeAllViews()
        val mappedItems = row.items.mapIndexed { index, item -> mapStremioItemToTitleCard(item, index) }
        mappedItems.forEachIndexed { index, item ->
            rowLayout.addView(makeCard(item, scrollView, binding.contentScroll, index, 258, 145))
        }
        prefetchCardArtwork(mappedItems)
    }

    private fun mapStremioItemToTitleCard(item: com.channelsdebrid.tv.data.StremioLiveLoader.LiveCatalogItem, index: Int): TitleCard {
        val fallback = heroTitles[index % heroTitles.size]
        return TitleCard(
            title = item.title,
            meta = item.meta,
            desc = item.desc,
            badge = item.badge,
            brand = item.brand,
            footer = item.footer,
            progress = item.progress.coerceIn(0.12f, 0.92f),
            backgroundRes = fallback.backgroundRes,
            posterUrl = item.posterUrl,
            backdropUrl = item.backdropUrl,
            logoUrl = item.logoUrl,
            mediaType = null,
            tmdbId = 0,
            sourceKey = "stremio"
        )
    }

    private fun probeSourceStatuses(
        stremio: com.channelsdebrid.tv.settings.StremioAddonSettings,
        dvr: com.channelsdebrid.tv.settings.ChannelsDvrSettings,
        xtream: com.channelsdebrid.tv.settings.XtreamSettings,
        debrid: com.channelsdebrid.tv.settings.DebridSettings,
        trailers: com.channelsdebrid.tv.settings.TrailerSettings,
        playback: com.channelsdebrid.tv.settings.PlaybackSettings,
        storage: com.channelsdebrid.tv.settings.StorageSettings
    ) {
        liveExecutor.execute {
            val parts = mutableListOf<String>()
            if (stremio.enabled && stremio.manifestUrl.isNotBlank()) {
                sourceProbe.probeStremio(stremio.manifestUrl)?.let { parts += it }
            }
            sourceProbe.probeChannelsDvr(dvr.autoDetect, dvr.baseUrl)?.let { parts += it }
            if (xtream.enabled) {
                sourceProbe.probeXtream(xtream.server, xtream.username, xtream.password)?.let { parts += it }
            }
            val summary = parts.take(2).joinToString("  •  ")
            if (summary.isBlank()) return@execute
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                binding.infoChip.text = buildInfoChipText(trailers.enabled, playback.autoPlayBestStream, storage.movieCacheEnabled, summary)
                if (!debrid.realDebridEnabled && !debrid.torBoxEnabled) {
                    binding.statusBadge.text = "⚑  $summary"
                }
            }
        }
    }

    private fun lockRowsForStartup() {
        startupFocusLocked = true
        rowSlots().forEach { blockRowFocus(it.rowLayout) }
    }

    private fun unlockRowsAfterStartup() {
        startupFocusLocked = false
        rowSlots().forEach { allowRowFocus(it.rowLayout) }
    }

    private fun blockRowFocus(row: LinearLayout) {
        row.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        for (i in 0 until row.childCount) {
            row.getChildAt(i).apply {
                isFocusable = false
                isFocusableInTouchMode = false
            }
        }
    }

    private fun allowRowFocus(row: LinearLayout) {
        row.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        for (i in 0 until row.childCount) {
            row.getChildAt(i).apply {
                isFocusable = true
                isFocusableInTouchMode = true
            }
        }
    }

    private fun markNavigationBusy(durationMs: Long = 170L) {
        navigationInFlight = true
        motionIdleDeadlineMs = android.os.SystemClock.uptimeMillis() + durationMs
        pendingNavigationIdleRunnable?.let(mainHandler::removeCallbacks)
        pendingNavigationIdleRunnable = Runnable {
            if (android.os.SystemClock.uptimeMillis() >= motionIdleDeadlineMs) {
                navigationInFlight = false
            } else {
                pendingNavigationIdleRunnable = this.pendingNavigationIdleRunnable
            }
        }.also { mainHandler.postDelayed(it, durationMs) }
    }

    private fun isMotionBusy(): Boolean {
        val now = android.os.SystemClock.uptimeMillis()
        val horizontalBusy = rowSlots().any { kotlin.math.abs(it.scrollView.scrollX - (it.scrollView.getTag(R.id.tag_last_stable_scroll_x) as? Int ?: it.scrollView.scrollX)) > 2 }
        val verticalBusy = kotlin.math.abs(binding.contentScroll.scrollY - (binding.contentScroll.getTag(R.id.tag_last_stable_scroll_y) as? Int ?: binding.contentScroll.scrollY)) > 2
        if (!horizontalBusy) {
            rowSlots().forEach { it.scrollView.setTag(R.id.tag_last_stable_scroll_x, it.scrollView.scrollX) }
        }
        if (!verticalBusy) {
            binding.contentScroll.setTag(R.id.tag_last_stable_scroll_y, binding.contentScroll.scrollY)
        }
        return rowSettleInProgress || navigationInFlight || now < motionIdleDeadlineMs || binding.contentScroll.isPressed || horizontalBusy || verticalBusy
    }

        private fun openLiveTv() {
        startActivity(Intent(this, LiveTvActivity::class.java))
    }

private fun wireTopControls() {
        val focusables = listOf(
            binding.menuButton,
            binding.homeButton,
            binding.navResume,
            binding.navSmart,
            binding.navLive,
            binding.navMovies,
            binding.settingsCard
        )
        if (lastTopMenuFocusId == View.NO_ID) {
            lastTopMenuFocusId = binding.navSmart.id
        }

        binding.settingsCard.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        binding.navLive.isClickable = true
        binding.navLive.isFocusable = true
        binding.navLive.setOnClickListener { openLiveTv() }
        binding.navLive.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_UP &&
                (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER)
            ) {
                openLiveTv()
                true
            } else {
                false
            }
        }
        binding.homeButton.setOnClickListener {
            binding.contentScroll.smoothScrollTo(0, 0)
            binding.navSmart.requestFocus()
        }

        binding.settingsCard.setOnKeyListener { _, keyCode, event ->
            if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_UP -> {
                    val target = findViewById<View>(lastFocusedCardId)
                        ?: lastVisibleRowSlot()?.rowLayout?.getChildAt(0)
                    if (target != null) {
                        target.requestFocus()
                        true
                    } else {
                        false
                    }
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> true
                KeyEvent.KEYCODE_DPAD_DOWN -> true
                else -> false
            }
        }

        focusables.forEach { v ->
            v.setOnFocusChangeListener { view, hasFocus ->
                if (hasFocus) {
                    lastTopMenuFocusId = view.id
                }
                view.animate().cancel()
                view.animate()
                    .scaleX(if (hasFocus) 1.05f else 1f)
                    .scaleY(if (hasFocus) 1.05f else 1f)
                    .alpha(if (hasFocus) 1f else 0.96f)
                    .setDuration(150)
                    .start()
            }
        }
    }


    private fun preferredTopMenuFocusId(): Int {
        val candidateIds = listOf(
            binding.menuButton.id,
            binding.homeButton.id,
            binding.navResume.id,
            binding.navSmart.id,
            binding.navLive.id,
            binding.navMovies.id,
            binding.settingsCard.id
        )
        return if (candidateIds.contains(lastTopMenuFocusId)) lastTopMenuFocusId else binding.navSmart.id
    }

    private fun isTopMenuView(view: View?): Boolean {
        val id = view?.id ?: return false
        return id == binding.menuButton.id ||
            id == binding.homeButton.id ||
            id == binding.navResume.id ||
            id == binding.navSmart.id ||
            id == binding.navLive.id ||
            id == binding.navMovies.id ||
            id == binding.settingsCard.id
    }

    private fun requestInitialRowFocus() {
        val firstRow = firstVisibleRowSlot() ?: return
        val firstCard = firstRow.rowLayout.getChildAt(0) ?: return
        activeRowSection = firstRow.section
        lastFocusedCardId = firstCard.id
        firstRow.scrollView.scrollTo(0, 0)
        binding.contentScroll.scrollTo(0, 0)
        if (currentFocus != firstCard) {
            currentFocus?.clearFocus()
            firstCard.isFocusable = true
            firstCard.isFocusableInTouchMode = true
            firstCard.requestFocus()
        }
    }

    private fun showBottomHudTemporarily() {
        if (bottomHudDismissedForSession) return
        pendingBottomHudHideRunnable?.let(mainHandler::removeCallbacks)
        binding.weatherPill.animate().cancel()
        binding.weatherPill.alpha = 0f
        binding.weatherPill.visibility = View.GONE
        val hud = binding.infoChip
        if (hud.visibility != View.VISIBLE) {
            hud.alpha = 0f
            hud.visibility = View.VISIBLE
        }
        hud.animate().cancel()
        hud.animate().alpha(1f).setDuration(160L).start()
        pendingBottomHudHideRunnable = Runnable {
            hideBottomHud(permanentForSession = true)
        }.also { mainHandler.postDelayed(it, 8000L) }
    }

    private fun hideBottomHud(permanentForSession: Boolean = false) {
        if (permanentForSession) {
            bottomHudDismissedForSession = true
        }
        listOf(binding.weatherPill, binding.infoChip).forEach { hud ->
            hud.animate().cancel()
            hud.animate()
                .alpha(0f)
                .setDuration(180L)
                .withEndAction {
                    hud.visibility = View.GONE
                }
                .start()
        }
    }

    private fun shouldConsumeDirectionalRepeat(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode !in setOf(
                KeyEvent.KEYCODE_DPAD_LEFT,
                KeyEvent.KEYCODE_DPAD_RIGHT,
                KeyEvent.KEYCODE_DPAD_UP,
                KeyEvent.KEYCODE_DPAD_DOWN
            )
        ) return false
        if (event.action != KeyEvent.ACTION_DOWN) return false
        if (event.repeatCount > 0) return true
        val now = android.os.SystemClock.uptimeMillis()
        val tooSoon = keyCode == lastDirectionalKeyCode && (now - lastDirectionalKeyAtMs) < 110L
        if (tooSoon || rowSettleInProgress || navigationInFlight) return true
        lastDirectionalKeyCode = keyCode
        lastDirectionalKeyAtMs = now
        markNavigationBusy(if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) 110L else 140L)
        return false
    }

    private fun wireRowNavigation() {
        val visibleRows = rowSlots().filter { it.rowLayout.childCount > 0 && it.scrollView.visibility == View.VISIBLE }
        if (visibleRows.isEmpty()) {
            binding.settingsCard.nextFocusUpId = View.NO_ID
            return
        }

        val firstRowFirstCardId = visibleRows.first().rowLayout.getChildAt(0)?.id ?: View.NO_ID
        val lastRowFirstCardId = visibleRows.last().rowLayout.getChildAt(0)?.id ?: View.NO_ID
        val topMenuFocusId = preferredTopMenuFocusId()
        binding.homeButton.nextFocusDownId = firstRowFirstCardId
        binding.navResume.nextFocusDownId = firstRowFirstCardId
        binding.navSmart.nextFocusDownId = firstRowFirstCardId
        binding.navLive.nextFocusDownId = firstRowFirstCardId
        binding.navMovies.nextFocusDownId = firstRowFirstCardId
        binding.settingsCard.nextFocusUpId = lastRowFirstCardId

        binding.menuButton.nextFocusRightId = binding.homeButton.id
        binding.homeButton.nextFocusLeftId = binding.menuButton.id
        binding.homeButton.nextFocusRightId = binding.navResume.id
        binding.navResume.nextFocusLeftId = binding.homeButton.id
        binding.navResume.nextFocusRightId = binding.navSmart.id
        binding.navSmart.nextFocusLeftId = binding.navResume.id
        binding.navSmart.nextFocusRightId = binding.navLive.id
        binding.navLive.nextFocusLeftId = binding.navSmart.id
        binding.navLive.nextFocusRightId = binding.navMovies.id
        binding.navMovies.nextFocusLeftId = binding.navLive.id
        binding.navMovies.nextFocusRightId = binding.settingsCard.id
        binding.settingsCard.nextFocusLeftId = binding.navMovies.id

        for (rowIndex in visibleRows.indices) {
            val current = visibleRows[rowIndex]
            val prev = visibleRows.getOrNull(rowIndex - 1)
            val next = visibleRows.getOrNull(rowIndex + 1)
            val prevFirstCard = prev?.rowLayout?.getChildAt(0)
            val nextFirstCard = next?.rowLayout?.getChildAt(0)
            val firstInPrevRowId = prevFirstCard?.id ?: View.NO_ID
            val firstInNextRowId = nextFirstCard?.id ?: View.NO_ID
            val childCount = current.rowLayout.childCount

            for (childIndex in 0 until childCount) {
                val card = current.rowLayout.getChildAt(childIndex)
                val selfId = card.id
                val leftCardId = if (childIndex > 0) current.rowLayout.getChildAt(childIndex - 1)?.id ?: selfId else selfId
                val rightCardId = if (childIndex < childCount - 1) current.rowLayout.getChildAt(childIndex + 1)?.id ?: selfId else selfId
                val upTargetId = if (firstInPrevRowId != View.NO_ID) firstInPrevRowId else topMenuFocusId
                val downTargetId = when {
                    firstInNextRowId != View.NO_ID -> firstInNextRowId
                    rowIndex == visibleRows.lastIndex -> binding.settingsCard.id
                    else -> selfId
                }

                card.nextFocusLeftId = leftCardId
                card.nextFocusRightId = rightCardId
                card.nextFocusUpId = upTargetId
                card.nextFocusDownId = downTargetId
                card.setOnKeyListener { _, keyCode, event ->
                    if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                    if (shouldConsumeDirectionalRepeat(keyCode, event)) return@setOnKeyListener true
                    when (keyCode) {
                        KeyEvent.KEYCODE_DPAD_UP -> {
                            if (prevFirstCard != null) {
                                moveFocusToRowStart(prev, prevFirstCard)
                                true
                            } else {
                                moveFocusToTopMenu()
                                true
                            }
                        }
                        KeyEvent.KEYCODE_DPAD_DOWN -> {
                            if (nextFirstCard != null) {
                                moveFocusToRowStart(next, nextFirstCard)
                                true
                            } else if (rowIndex == visibleRows.lastIndex) {
                                binding.settingsCard.requestFocus()
                                true
                            } else {
                                false
                            }
                        }
                        else -> false
                    }
                }
            }
        }
    }

    private fun moveFocusToTopMenu() {
        val targetId = preferredTopMenuFocusId()
        val targetView = findViewById<View>(targetId) ?: binding.navSmart
        rowSettleInProgress = false
        pendingRowSettleRunnable?.let(mainHandler::removeCallbacks)
        activeRowSection = null
        lastTopMenuFocusId = targetView.id
        markNavigationBusy(120L)
        binding.contentScroll.post {
            binding.contentScroll.scrollTo(0, 0)
            targetView.requestFocus()
        }
    }

    private fun moveFocusToRowStart(targetRow: RowSlot?, targetCard: View) {
        if (targetRow == null) return
        rowSettleInProgress = true
        pendingRowSettleRunnable?.let(mainHandler::removeCallbacks)
        activeRowSection = targetRow.section
        lastFocusedCardId = targetCard.id
        targetRow.scrollView.scrollTo(0, 0)
        snapToRow(targetRow.section, smooth = false)
        markNavigationBusy(180L)
        targetCard.post {
            targetRow.scrollView.scrollTo(0, 0)
            targetCard.requestFocus()
            pendingRowSettleRunnable?.let(mainHandler::removeCallbacks)
            pendingRowSettleRunnable = Runnable {
                if (targetCard.isFocused && lastFocusedCardId == targetCard.id) {
                    targetRow.scrollView.scrollTo(0, 0)
                }
                rowSettleInProgress = false
            }.also { mainHandler.postDelayed(it, 120L) }
        }
    }

    private fun populateRows() {
        applySettingsToHome()
    }

    private fun makeCard(item: TitleCard, scrollView: HorizontalScrollView, verticalScroll: ScrollView, index: Int, widthDp: Int, heightDp: Int): View {
        val density = resources.displayMetrics.density
        val widthPx = (widthDp * density).toInt()
        val heightPx = (heightDp * density).toInt()
        val marginEnd = (16 * density).toInt()
        val pad = (14 * density).toInt()
        val progressHeight = 3
        val progressWidth = ((widthPx - (pad * 2)) * item.progress).toInt().coerceAtLeast((40 * density).toInt())
        val pillRadius = 34f * density

        val frame = FrameLayout(this).apply {
            id = View.generateViewId()
            layoutParams = LinearLayout.LayoutParams(widthPx, heightPx).apply { rightMargin = marginEnd }
            isFocusable = true
            isClickable = true
            foreground = null
            background = (ContextCompat.getDrawable(this@MainActivity, item.backgroundRes)?.mutate() as? GradientDrawable)?.apply {
                cornerRadius = pillRadius
            } ?: ContextCompat.getDrawable(this@MainActivity, item.backgroundRes)
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, pillRadius)
                }
            }
        }

        val posterImage = ImageView(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFF0B0F18.toInt())
        }
        loadCardArtworkInto(posterImage, item, highQuality = false)

        val overlay = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            background = (ContextCompat.getDrawable(this@MainActivity, R.drawable.card_overlay)?.mutate() as? GradientDrawable)?.apply {
                cornerRadius = pillRadius
            } ?: ContextCompat.getDrawable(this@MainActivity, R.drawable.card_overlay)
            alpha = 0.26f
        }

        val focusSheen = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x42FFFFFF, 0x14FFFFFF, 0x00000000)
            ).apply {
                cornerRadius = pillRadius
            }
            alpha = 0f
        }

        val cardLogo = ImageView(this).apply {
            layoutParams = FrameLayout.LayoutParams((widthPx * 0.82f).toInt(), (heightPx * 0.40f).toInt(), Gravity.CENTER_HORIZONTAL or Gravity.CENTER_VERTICAL).apply {
                bottomMargin = (heightPx * 0.02f).toInt()
            }
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            alpha = 1f
            visibility = View.GONE
            elevation = 14f * resources.displayMetrics.density
        }
        bindCardLogo(cardLogo, item, highQuality = false)

        val bottomWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
            setPadding(pad, 0, pad, pad)
        }

        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }

        val title = TextView(this).apply {
            text = item.title
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 13.5f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 1
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val brand = TextView(this).apply {
            text = item.brand
            setTextColor(0xFFEFE6DA.toInt())
            textSize = 8.5f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

        val progressTrack = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (progressHeight * density).toInt()).apply {
                topMargin = (6 * density).toInt()
            }
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.pill_dark)
            alpha = 0.45f
        }

        val progressBar = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(progressWidth, (progressHeight * density).toInt(), Gravity.START or Gravity.CENTER_VERTICAL)
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.button_primary)
            alpha = 0.95f
        }

        val progressFrame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (progressHeight * density).toInt()).apply {
                topMargin = (6 * density).toInt()
            }
            addView(progressTrack)
            addView(progressBar)
        }

        val footer = TextView(this).apply {
            text = item.footer
            setTextColor(0xFFE6DCCD.toInt())
            textSize = 8.5f
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = (6 * density).toInt()
            }
        }

        brandRow.addView(title)
        brandRow.addView(brand)
        bottomWrap.addView(brandRow)
        bottomWrap.addView(progressFrame)
        bottomWrap.addView(footer)

        frame.addView(posterImage)
        frame.addView(overlay)
        frame.addView(focusSheen)
        frame.addView(cardLogo)
        frame.addView(bottomWrap)

        frame.cameraDistance = 12000f
        frame.elevation = 6f * resources.displayMetrics.density

        frame.setOnFocusChangeListener { view, hasFocus ->
            pendingRevealRunnable?.let(mainHandler::removeCallbacks)
            if (hasFocus) markNavigationBusy()
            view.animate().cancel()
            cardLogo.animate().cancel()
            overlay.animate().cancel()
            focusSheen.animate().cancel()
            val section = rowSlots().firstOrNull { it.scrollView.id == scrollView.id }?.section
            val verticalRowChange = hasFocus && section != null && activeRowSection != null && activeRowSection != section
            if (hasFocus && section != null) {
                activeRowSection = section
            }
            val motionBusy = isMotionBusy()
            val suppressScale = rowSettleInProgress || verticalRowChange
            view.alpha = if (hasFocus) 1f else 0.985f
            view.translationZ = if (hasFocus && !motionBusy) 20f * resources.displayMetrics.density else 0f
            if (motionBusy) {
                view.scaleX = 1f
                view.scaleY = 1f
            } else {
                view.animate()
                     .scaleX(if (hasFocus && !suppressScale) 1.015f else 1f)
                     .scaleY(if (hasFocus && !suppressScale) 1.015f else 1f)
                     .setDuration(if (hasFocus) 60L else 50L)
                    .start()
            }
            overlay.animate().alpha(if (hasFocus) 0.08f else 0.24f).setDuration(90L).start()
            focusSheen.animate().alpha(if (hasFocus) 0.42f else 0f).setDuration(90L).start()
            cardLogo.alpha = if (hasFocus) 1f else 0.98f
            if (motionBusy) {
                cardLogo.scaleX = 1f
                cardLogo.scaleY = 1f
            } else {
                cardLogo.animate()
                     .scaleX(if (hasFocus && !suppressScale) 1.01f else 1f)
                     .scaleY(if (hasFocus && !suppressScale) 1.01f else 1f)
                     .setDuration(if (hasFocus) 60L else 50L)
                    .start()
            }
            title.alpha = if (cardLogo.visibility == View.VISIBLE) 0.80f else 1f
            frame.foreground = if (hasFocus) makeFocusRing(pillRadius) else null
            pulseAnimator(view, hasFocus)
            posterImage.setLayerType(if (hasFocus) View.LAYER_TYPE_HARDWARE else View.LAYER_TYPE_NONE, null)
            cardLogo.setLayerType(if (hasFocus) View.LAYER_TYPE_HARDWARE else View.LAYER_TYPE_NONE, null)
            if (hasFocus) {
                lastFocusedCardId = view.id
                if (section != null && section == lastVisibleRowSlot()?.section) {
                    binding.settingsCard.nextFocusUpId = view.id
                }
                previewHeroForFocus(item)
                scheduleHeroCommit(item, if (startupFocusLocked) 150L else if (verticalRowChange) 210L else 110L)
                if (!startupFocusLocked) {
                    pendingRevealRunnable = Runnable {
                        if (view.isFocused && lastFocusedCardId == view.id) {
                            revealFocusedCard(scrollView, verticalScroll, view, index, verticalRowChange)
                        }
                    }.also { mainHandler.postDelayed(it, if (verticalRowChange) 190L else 130L) }
                }
            }
        }
        frame.setOnClickListener {
            launchPlaybackFor(item)
        }
        return frame
    }



    private fun launchPlaybackFor(item: TitleCard) {
        val dvr = settingsRepository.loadChannelsDvr()
        val xtream = settingsRepository.loadXtream()
        binding.statusBadge.text = "Resolving stream…"
        liveExecutor.execute {
            val target = playbackResolver.resolveLiveTestTarget(item.title, dvr, xtream)
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (target == null) {
                    binding.statusBadge.text = "No live test source"
                    Toast.makeText(
                        this,
                        "Configure Channels DVR or Xtream/IPTV in Settings to test playback.",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    binding.statusBadge.text = "Launching ${target.sourceLabel}"
                    val intent = Intent(this, PlayerActivity::class.java)
                        .putExtra(PlayerActivity.EXTRA_STREAM_URL, target.url)
                        .putExtra(PlayerActivity.EXTRA_TITLE, target.title)
                                .putExtra(PlayerActivity.EXTRA_DEBUG_LABEL, target.debugLabel)
                        .putExtra(PlayerActivity.EXTRA_SOURCE_LABEL, target.sourceLabel)
                    startActivity(intent)
                }
            }
        }
    }

    private fun revealFocusedCard(scrollView: HorizontalScrollView, verticalScroll: ScrollView, view: View, index: Int, verticalRowChange: Boolean = false) {
        val section = rowSlots().firstOrNull { it.scrollView.id == scrollView.id }?.section
        val performHorizontalReveal = Runnable {
            val leftAnchorPx = (52f * resources.displayMetrics.density).toInt()
            val horizontalTarget = when {
                index <= 0 -> 0
                else -> (view.left - leftAnchorPx).coerceAtLeast(0)
            }
            val horizontalDelta = kotlin.math.abs(scrollView.scrollX - horizontalTarget)
            when {
                horizontalDelta > (180f * resources.displayMetrics.density).toInt() -> scrollView.scrollTo(horizontalTarget, 0)
                horizontalDelta > (6f * resources.displayMetrics.density).toInt() -> scrollView.smoothScrollTo(horizontalTarget, 0)
            }
        }
        scrollView.postOnAnimation {
            if (section != null) {
                if (verticalRowChange) {
                    rowSettleInProgress = true
                    pendingRowSettleRunnable?.let(mainHandler::removeCallbacks)
                    markNavigationBusy(220L)
                    snapToRow(section, smooth = false)
                    pendingRowSettleRunnable = Runnable {
                        if (view.isFocused && lastFocusedCardId == view.id) {
                            performHorizontalReveal.run()
                        }
                        rowSettleInProgress = false
                    }.also { mainHandler.postDelayed(it, 190L) }
                } else {
                    performHorizontalReveal.run()
                    markNavigationBusy(160L)
                    snapToRow(section, smooth = false)
                }
            } else {
                verticalScroll.scrollTo(0, view.top)
                performHorizontalReveal.run()
            }
        }
    }

    private fun snapToRow(section: RowSection, smooth: Boolean) {
        val density = resources.displayMetrics.density
        val slot = rowSlots().firstOrNull { it.section == section } ?: return
        val rowTop = slot.titleView.top
        val target = if (section == RowSection.FIRST) 0 else (rowTop - (22f * density).toInt()).coerceAtLeast(0)
        binding.contentScroll.post {
            if (smooth) binding.contentScroll.smoothScrollTo(0, target)
            else binding.contentScroll.scrollTo(0, target)
        }
    }

    private fun pulseAnimator(view: View, hasFocus: Boolean) {
        (view.getTag(R.id.tag_pulse_animator) as? Animator)?.cancel()
        view.setTag(R.id.tag_pulse_animator, null)
        view.animate().cancel()
        if (!hasFocus) {
            view.scaleX = 1f
            view.scaleY = 1f
            view.translationY = 0f
            view.translationZ = 0f
            view.alpha = 0.985f
            return
        }
        view.scaleX = 1.02f
        view.scaleY = 1.02f
        view.translationZ = 22f * resources.displayMetrics.density
        view.alpha = 1f
        val pulse = ObjectAnimator.ofPropertyValuesHolder(
            view,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1.02f, 1.032f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1.02f, 1.032f)
        ).apply {
            duration = 1800L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
        }
        view.setTag(R.id.tag_pulse_animator, pulse)
        pulse.start()
    }

    private fun makeFocusRing(radius: Float): Drawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius
            setColor(0x00000000)
            setStroke((2f * resources.displayMetrics.density).toInt(), 0xFFDCEBFF.toInt())
        }
    }


    private fun animateHeroContentEntrance() {
        val targets = listOf(binding.heroTitleArtwork, binding.heroTitle, binding.heroMeta, binding.heroDesc, binding.statusBadge)
        targets.forEach { view ->
            view.animate().cancel()
            view.alpha = 1f
            view.translationY = 0f
        }
    }

    private fun previewHeroForFocus(item: TitleCard) {
        loadHeroBackdrop(item)
        applyHeroTitleVisual(item)
        binding.heroMeta.text = item.meta
        binding.heroDesc.text = item.desc
        binding.statusBadge.text = item.badge
    }

    private fun applyHeroTitleVisual(item: TitleCard) {
        val requestKey = heroRequestKey(item)
        pendingHeroLogoRequestKey = requestKey
        val cachedResolvedLogo = resolvedHeroLogoCache[requestKey]
        val logoUrl = cachedResolvedLogo?.takeIf { it.isNotBlank() } ?: item.logoUrl?.takeIf { it.isNotBlank() }
        val logoRes = resolveHeroLogoRes(item.title)
        binding.heroTitleArtwork.animate().cancel()
        binding.heroTitle.animate().cancel()
        Glide.with(this).clear(binding.heroTitleArtwork)
        binding.heroTitleArtwork.setImageDrawable(null)
        when {
            logoUrl != null -> {
                binding.heroTitleArtwork.visibility = View.VISIBLE
                binding.heroTitle.visibility = View.GONE
                Glide.with(this)
                    .load(logoUrl)
                    .apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).dontTransform())
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .override(1400, 560)
                    .dontAnimate()
                    .into(binding.heroTitleArtwork)
            }
            logoRes != 0 -> {
                binding.heroTitleArtwork.visibility = View.VISIBLE
                binding.heroTitleArtwork.setImageResource(logoRes)
                binding.heroTitle.visibility = View.GONE
            }
            else -> {
                binding.heroTitleArtwork.visibility = View.GONE
                binding.heroTitle.visibility = View.VISIBLE
                binding.heroTitle.text = item.title
            }
        }
    }

    private fun loadHeroBackdrop(item: TitleCard) {
        loadBackdropInto(
            imageView = binding.heroBackdrop,
            backdropUrl = item.backdropUrl,
            posterUrl = item.posterUrl,
            fallbackRes = item.backgroundRes
        )
    }

    private fun scheduleHeroCommit(item: TitleCard, delayMs: Long = 140L) {
        val requestKey = heroRequestKey(item)
        if (requestKey == committedHeroRequestKey) return
        pendingHeroCommitRunnable?.let(mainHandler::removeCallbacks)
        pendingHeroCommitRunnable = Runnable {
            if (isMotionBusy()) {
                scheduleHeroCommit(item, 160L)
            } else {
                commitHero(item)
            }
        }.also { mainHandler.postDelayed(it, delayMs) }
    }

    private fun commitHero(item: TitleCard) {
        if (isMotionBusy()) {
            scheduleHeroCommit(item, 180L)
            return
        }
        pendingHeroCommitRunnable?.let(mainHandler::removeCallbacks)
        pendingHeroCommitRunnable = null
        committedHeroRequestKey = heroRequestKey(item)
        loadHeroBackdrop(item)
        binding.heroMeta.animate().cancel()
        binding.heroDesc.animate().cancel()
        binding.statusBadge.animate().cancel()
        applyHeroTitleVisual(item)
        maybeResolveHeroLogoAsync(item)
        binding.heroMeta.text = item.meta
        binding.heroDesc.text = item.desc
        binding.statusBadge.text = item.badge
        animateHeroContentEntrance()
    }

    private fun maybeResolveHeroLogoAsync(item: TitleCard) {
        val tmdb = settingsRepository.loadTmdb()
        if (item.sourceKey != "tmdb" || item.tmdbId <= 0 || item.mediaType.isNullOrBlank() || tmdb.apiKey.isBlank()) return
        val requestKey = heroRequestKey(item)
        resolvedHeroLogoCache[requestKey]?.takeIf { it.isNotBlank() }?.let { resolved ->
            if (pendingHeroLogoRequestKey == requestKey) {
                binding.heroTitleArtwork.visibility = View.VISIBLE
                binding.heroTitle.visibility = View.GONE
                Glide.with(this).clear(binding.heroTitleArtwork)
                binding.heroTitleArtwork.setImageDrawable(null)
                Glide.with(this)
                    .load(resolved)
                    .apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).dontTransform())
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                     .override(1400, 560)
                    .dontAnimate()
                    .into(binding.heroTitleArtwork)
            }
            return
        }
        heroLogoExecutor.execute {
            val resolved = runCatching {
                tmdbLiveLoader.resolveLogoForItem(
                    apiKey = tmdb.apiKey,
                    type = item.mediaType,
                    tmdbId = item.tmdbId,
                    language = tmdb.language.ifBlank { "en-US" },
                    fanartApiKey = BuildConfig.FANART_API_KEY,
                    fanartClientKey = BuildConfig.FANART_CLIENT_KEY
                )
            }.getOrNull()
            if (resolved.isNullOrBlank()) return@execute
            resolvedHeroLogoCache[requestKey] = resolved
            runOnUiThread {
                if (isFinishing || pendingHeroLogoRequestKey != requestKey) return@runOnUiThread
                if (isMotionBusy()) {
                    scheduleHeroCommit(item, 200L)
                    return@runOnUiThread
                }
                binding.heroTitleArtwork.visibility = View.VISIBLE
                binding.heroTitle.visibility = View.GONE
                Glide.with(this).clear(binding.heroTitleArtwork)
                binding.heroTitleArtwork.setImageDrawable(null)
                Glide.with(this)
                    .load(resolved)
                    .apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).dontTransform())
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                     .override(1400, 560)
                    .dontAnimate()
                    .into(binding.heroTitleArtwork)
            }
        }
    }

    private fun heroRequestKey(item: TitleCard): String = "${item.sourceKey}:${item.mediaType}:${item.tmdbId}:${item.title}"

    private fun prefetchHeroAssets(items: List<TitleCard>) {
        if (items.isEmpty()) return
        items.take(3).forEach { item ->
            item.backdropUrl?.takeIf { it.isNotBlank() }?.let { backdrop ->
                Glide.with(this)
                    .load(backdrop)
                    .diskCacheStrategy(DiskCacheStrategy.DATA)
                    .preload(1280, 720)
            }
        }
    }

    private fun resolveHeroLogoRes(title: String): Int {
        val normalized = buildString {
            title.toLowerCase(java.util.Locale.ROOT).forEach { ch ->
                when {
                    ch.isLetterOrDigit() -> append(ch)
                    ch == ' ' || ch == '-' || ch == '–' || ch == '—' || ch == ':' || ch == '/' -> append('_')
                }
            }
        }.replace(Regex("_+"), "_").trim('_')
        if (normalized.isBlank()) return 0
        return resources.getIdentifier("logo_${normalized}", "drawable", packageName)
    }


    private fun bindCardLogo(imageView: ImageView, item: TitleCard, highQuality: Boolean) {
        val requestKey = heroRequestKey(item)
        val logoUrl = resolvedHeroLogoCache[requestKey]?.takeIf { it.isNotBlank() }
            ?: item.logoUrl?.takeIf { it.isNotBlank() }
        val cacheKey = requestKey + ":" + highQuality + ":" + (logoUrl ?: "none")
        val viewKey = System.identityHashCode(imageView)
        if (loadedCardLogoRequests[viewKey] == cacheKey) return
        loadedCardLogoRequests[viewKey] = cacheKey

        imageView.tag = heroRequestKey(item)
        Glide.with(this).clear(imageView)
        imageView.setImageDrawable(null)
        imageView.scaleType = ImageView.ScaleType.FIT_CENTER

        if (logoUrl != null) {
            imageView.visibility = View.VISIBLE
            Glide.with(this)
                .load(logoUrl)
                .apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).disallowHardwareConfig().dontTransform())
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .override(if (highQuality) 900 else 680, if (highQuality) 340 else 260)
                .dontAnimate()
                .into(imageView)
        } else {
            imageView.visibility = View.GONE
        }
    }

    private fun maybeResolveCardLogoAsync(item: TitleCard, imageView: ImageView, highQuality: Boolean) {
        val tmdb = settingsRepository.loadTmdb()
        if (item.sourceKey != "tmdb" || item.tmdbId <= 0 || item.mediaType.isNullOrBlank() || tmdb.apiKey.isBlank()) return
        val requestKey = heroRequestKey(item)
        resolvedHeroLogoCache[requestKey]?.takeIf { it.isNotBlank() }?.let { resolved ->
            if (isMotionBusy()) return
            imageView.visibility = View.VISIBLE
            Glide.with(this)
                .load(resolved)
                .apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).disallowHardwareConfig().dontTransform())
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                                     .override(if (highQuality) 900 else 680, if (highQuality) 340 else 260)
                .dontAnimate()
                .into(imageView)
            return
        }
        val expectedTag = imageView.tag?.toString()
        liveExecutor.execute {
            val resolved = runCatching {
                tmdbLiveLoader.resolveLogoForItem(
                    apiKey = tmdb.apiKey,
                    type = item.mediaType,
                    tmdbId = item.tmdbId,
                    language = tmdb.language.ifBlank { "en-US" },
                    fanartApiKey = BuildConfig.FANART_API_KEY,
                    fanartClientKey = BuildConfig.FANART_CLIENT_KEY
                )
            }.getOrNull() ?: return@execute
            resolvedHeroLogoCache[requestKey] = resolved
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (imageView.tag?.toString() != expectedTag) return@runOnUiThread
                imageView.visibility = View.VISIBLE
                Glide.with(this)
                    .load(resolved)
                    .apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).disallowHardwareConfig().dontTransform())
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                                         .override(if (highQuality) 900 else 680, if (highQuality) 340 else 260)
                    .dontAnimate()
                    .into(imageView)
            }
        }
    }

    private fun prefetchCardArtwork(items: List<TitleCard>) {
        items.take(12).forEach { item ->
            listOfNotNull(
                item.posterUrl?.takeIf { it.isNotBlank() },
                item.backdropUrl?.takeIf { it.isNotBlank() }
            ).distinct().forEach { targetUrl ->
                Glide.with(this)
                    .load(targetUrl)
                    .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                    .preload(520, 300)
            }
        }
    }

    private fun loadCardArtworkInto(imageView: ImageView, item: TitleCard, highQuality: Boolean) {
        val posterUrl = item.posterUrl?.takeIf { it.isNotBlank() }
        val wideUrl = item.backdropUrl?.takeIf { it.isNotBlank() }
        val primaryUrl = posterUrl ?: wideUrl
        val secondaryUrl = when {
            posterUrl != null && wideUrl != null && wideUrl != posterUrl -> wideUrl
            posterUrl == null -> null
            else -> null
        }
        val requestTag = "${item.sourceKey}:${item.mediaType}:${item.tmdbId}:${item.title}:$highQuality:$primaryUrl:$secondaryUrl"
        val viewKey = System.identityHashCode(imageView)
        if (loadedCardArtworkRequests[viewKey] == requestTag) return
        loadedCardArtworkRequests[viewKey] = requestTag

        Glide.with(this).clear(imageView)
        imageView.animate().cancel()
        imageView.tag = requestTag
        imageView.scaleType = ImageView.ScaleType.CENTER_CROP
        imageView.setImageResource(item.backgroundRes)

        if (primaryUrl == null) {
            return
        }

        val reqWidth = if (highQuality) 860 else 520
        val reqHeight = if (highQuality) 484 else 300
        val baseOptions = RequestOptions()
            .format(DecodeFormat.PREFER_ARGB_8888)
            .disallowHardwareConfig()
            .override(reqWidth, reqHeight)
            .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
            .skipMemoryCache(false)
            .centerCrop()

        val requestManager = Glide.with(this)
        val fallbackRequest = secondaryUrl?.let {
            requestManager.load(it)
                .apply(baseOptions)
                .transition(DrawableTransitionOptions.withCrossFade(120))
        }

        requestManager
            .load(primaryUrl)
            .apply(baseOptions)
            .thumbnail(requestManager.load(primaryUrl).apply(baseOptions.override(160, 92)))
            .transition(DrawableTransitionOptions.withCrossFade(120))
            .listener(object : RequestListener<Drawable> {
                override fun onLoadFailed(
                    e: GlideException?,
                    model: Any?,
                    target: Target<Drawable>,
                    isFirstResource: Boolean
                ): Boolean = false

                override fun onResourceReady(
                    resource: Drawable,
                    model: Any,
                    target: Target<Drawable>?,
                    dataSource: DataSource,
                    isFirstResource: Boolean
                ): Boolean {
                    imageView.post {
                        if (imageView.tag == requestTag) imageView.alpha = 1f
                    }
                    return false
                }
            })
            .error(fallbackRequest ?: requestManager.load(item.backgroundRes).apply(baseOptions))
            .into(imageView)
    }

    private fun loadBackdropInto(
        imageView: ImageView,
        backdropUrl: String?,
        posterUrl: String?,
        fallbackRes: Int
    ) {
        val backdrop = backdropUrl?.takeIf { it.isNotBlank() }
        val poster = posterUrl?.takeIf { it.isNotBlank() }
        val usePosterPreview = poster != null && (backdrop == null || backdrop == poster)
        val targetUrl = if (usePosterPreview) poster else backdrop ?: poster
        val requestTag = "hero:${targetUrl ?: fallbackRes}:${usePosterPreview}"
        imageView.tag = requestTag
        Glide.with(this).clear(imageView)
        imageView.animate().cancel()
        imageView.setImageDrawable(null)
        imageView.setBackgroundColor(0xFF06080F.toInt())
        imageView.scaleType = if (usePosterPreview) ImageView.ScaleType.FIT_CENTER else ImageView.ScaleType.CENTER_CROP
        if (targetUrl.isNullOrBlank()) {
            imageView.setImageDrawable(safeDrawable(fallbackRes))
            return
        }
        val requestManager = Glide.with(this)
        val requestOptions = RequestOptions()
            .format(DecodeFormat.PREFER_ARGB_8888)
            .disallowHardwareConfig()
            .override(if (usePosterPreview) 900 else 1280, if (usePosterPreview) 1200 else 720)
            .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
            .skipMemoryCache(false)
        val thumb = requestManager.load(targetUrl).apply(requestOptions.override(if (usePosterPreview) 240 else 320, if (usePosterPreview) 320 else 180))
        requestManager
            .load(targetUrl)
            .apply(if (usePosterPreview) requestOptions.fitCenter() else requestOptions.centerCrop())
            .thumbnail(thumb)
            .transition(DrawableTransitionOptions.withCrossFade(140))
            .placeholder(fallbackRes)
            .error(fallbackRes)
            .into(imageView)
    }

    private fun safeDrawable(resId: Int): Drawable? = ContextCompat.getDrawable(this, resId)
}
