# Rewrite Build Audit — v0.0.1 Stable Card Clip + Center Logo Fix

Base used: v0.0.1 stable full fixed source line.

Rule followed: clean rewrite/consolidation from the stable v0.0.1 source path. No broken v7.x build path was used.

Fixes in this rebuild:
- Preserved working single active row navigation.
- Preserved centered row-card clearlogo overlay.
- Added rounded clipping directly to the active card renderer so artwork can no longer draw square corners over rounded cards.
- Removed the extra square/white card edge caused by padded child images and heavy card stroke.
- Kept card images as clean landscape/backdrop/banner surfaces.
- Kept portrait/poster/thumbnail assets out of the row-card background pipeline when a landscape/backdrop/banner is not available.
- Kept versionName 0.0.1 and versionCode 1 for stable baseline tracking.

Verification markers:
- Visible marker remains DC_V0_0_1_STABLE_BASE.
- Logcat marker remains DC_V0_0_1_ACTIVE.
