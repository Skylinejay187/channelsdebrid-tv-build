package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.0.1 STABLE BASE";
    public static final String LOG_MARKER = "DC_V0_0_1_ACTIVE";
    private BuildMarkers() {}
}
