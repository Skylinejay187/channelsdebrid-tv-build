# Trailer endpoint

Added:

`GET /trailers/resolve?title=<title>&year=<year>&prefer4k=true`

Response:

```json
{
  "ok": true,
  "trailer": {
    "videoId": "...",
    "title": "...",
    "playbackUrl": "...",
    "mimeType": "application/dash+xml",
    "quality": "adaptive up to 4K",
    "source": "yt-dlp-dash-manifest"
  }
}
```

Requires `yt-dlp` available in PATH. The Dockerfile installs it automatically.
