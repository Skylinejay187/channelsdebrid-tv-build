
const { refreshCatalogs, refreshLiveData, loadLiveUsers } = require('./lib');

const catalogIntervalMs = Number(process.env.REFRESH_INTERVAL_MS || 1000 * 60 * 30);
const liveIntervalMs = Number(process.env.LIVE_REFRESH_INTERVAL_MS || 1000 * 60 * 5);

async function runCatalog() {
  try {
    const result = await refreshCatalogs();
    console.log('catalog refresh complete', {
      generatedAt: result.home.generatedAt,
      rails: result.home.rails.length
    });
  } catch (err) {
    console.error('catalog refresh failed', err);
  }
}

async function runLive() {
  try {
    const users = Object.keys(loadLiveUsers().users || {});
    if (!users.length) {
      console.log('live refresh skipped', { reason: 'no users configured' });
      return;
    }
    const result = await refreshLiveData();
    console.log('live refresh complete', {
      generatedAt: result.generatedAt,
      users: users.length
    });
  } catch (err) {
    console.error('live refresh failed', err);
  }
}

console.log('Channels Debrid worker started');
runCatalog();
runLive();
setInterval(runCatalog, catalogIntervalMs);
setInterval(runLive, liveIntervalMs);
