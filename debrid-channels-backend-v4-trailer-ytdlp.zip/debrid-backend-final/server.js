
const http = require('http');
const { URL } = require('url');
const { execFile } = require('child_process');
const {
  loadHomeRows,
  loadState,
  refreshCatalogs,
  DEFAULT_SOURCES,
  listLiveSources,
  upsertLiveSource,
  getLiveUserView,
  getChannelById,
  buildQuickGuide,
  resolvePlayback,
  refreshLiveData
} = require('./lib');

const port = Number(process.env.PORT || 8181);
const publicBaseUrl = process.env.PUBLIC_BASE_URL || `http://localhost:${port}`;


const trailerCache = new Map();

function execYtDlp(args, timeoutMs = 25000) {
  return new Promise((resolve, reject) => {
    execFile(process.env.YTDLP_BIN || 'yt-dlp', args, { timeout: timeoutMs, maxBuffer: 1024 * 1024 * 10 }, (err, stdout, stderr) => {
      if (err) {
        err.message = [err.message, stderr].filter(Boolean).join('\n');
        return reject(err);
      }
      resolve(stdout);
    });
  });
}

function trailerSearchQuery(title, year) {
  return [title, year, 'official trailer 4k'].filter(Boolean).join(' ');
}

function bestMuxedFormat(formats, prefer4k) {
  const withAudioVideo = (formats || []).filter(f => f.url && f.vcodec && f.vcodec !== 'none' && f.acodec && f.acodec !== 'none');
  const maxHeight = prefer4k ? 2160 : 1080;
  return withAudioVideo
    .filter(f => !f.height || f.height <= maxHeight)
    .sort((a, b) => (b.height || 0) - (a.height || 0) || (b.tbr || 0) - (a.tbr || 0))[0] || null;
}

function pickTrailerInfo(info, prefer4k) {
  const entries = Array.isArray(info.entries) ? info.entries.filter(Boolean) : [info];
  const chosen = entries.find(e => /trailer/i.test(e.title || '')) || entries[0];
  if (!chosen) throw new Error('No trailer results found');

  const manifestUrl = chosen.manifest_url || chosen.dash_url || '';
  if (manifestUrl) {
    return {
      videoId: chosen.id || '',
      title: chosen.title || '',
      playbackUrl: manifestUrl,
      mimeType: 'application/dash+xml',
      quality: prefer4k ? 'adaptive up to 4K' : 'adaptive up to 1080p',
      source: 'yt-dlp-dash-manifest'
    };
  }

  const muxed = bestMuxedFormat(chosen.formats || [], prefer4k);
  if (muxed) {
    return {
      videoId: chosen.id || '',
      title: chosen.title || '',
      playbackUrl: muxed.url,
      mimeType: muxed.ext === 'm3u8' ? 'application/x-mpegURL' : 'video/mp4',
      quality: muxed.format_note || (muxed.height ? String(muxed.height) + 'p' : 'best'),
      source: 'yt-dlp-direct-muxed'
    };
  }

  if (chosen.url) {
    return {
      videoId: chosen.id || '',
      title: chosen.title || '',
      playbackUrl: chosen.url,
      mimeType: 'video/mp4',
      quality: chosen.format_note || 'best',
      source: 'yt-dlp-direct'
    };
  }
  throw new Error('No playable trailer stream found');
}

async function resolveTrailer({ title, year, prefer4k }) {
  const cacheKey = (title + '|' + year + '|' + prefer4k).toLowerCase();
  const cached = trailerCache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) return cached.value;

  const query = trailerSearchQuery(title, year);
  const stdout = await execYtDlp([
    '--dump-single-json',
    '--no-playlist',
    '--no-warnings',
    '--skip-download',
    '--extractor-args', 'youtube:player_client=android,web',
    'ytsearch5:' + query
  ]);
  const info = JSON.parse(stdout);
  const value = pickTrailerInfo(info, prefer4k);
  trailerCache.set(cacheKey, { value, expiresAt: Date.now() + 20 * 60 * 1000 });
  return value;
}

function json(res, statusCode, payload, options = {}) {
  const body = JSON.stringify(payload, null, 2);
  const cacheControl = options.cacheControl || 'no-store';
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': cacheControl
  });
  res.end(body);
}

function notFound(res, url) {
  return json(res, 404, {
    ok: false,
    error: 'Not found',
    path: url.pathname
  });
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 1024 * 1024) {
        reject(new Error('Request body too large'));
        req.destroy();
      }
    });
    req.on('end', () => {
      if (!body) return resolve({});
      try {
        resolve(JSON.parse(body));
      } catch (err) {
        reject(new Error('Invalid JSON body'));
      }
    });
    req.on('error', reject);
  });
}

function getUserId(url, req) {
  return url.searchParams.get('user_id') || req.headers['x-user-id'] || '';
}

async function handle(req, res) {
  const url = new URL(req.url, publicBaseUrl);

  if (req.method === 'GET' && (url.pathname === '/health' || url.pathname === '/api/health')) {
    return json(res, 200, {
      ok: true,
      service: 'channels-debrid-backend',
      port,
      publicBaseUrl,
      lastRefreshAt: loadState().lastRefreshAt
    });
  }

  if (req.method === 'GET' && url.pathname === '/api/home') {
    return json(res, 200, loadHomeRows(), { cacheControl: 'public, max-age=60' });
  }

  if (req.method === 'GET' && url.pathname === '/api/sources') {
    return json(res, 200, {
      configuredSources: DEFAULT_SOURCES.map(({ preferredCatalogs, maxRails, ...rest }) => ({ ...rest, preferredCatalogs, maxRails })),
      state: loadState()
    });
  }

  if (req.method === 'POST' && url.pathname === '/api/refresh') {
    try {
      const result = await refreshCatalogs();
      return json(res, 200, { ok: true, ...result });
    } catch (err) {
      return json(res, 500, { ok: false, error: err.message });
    }
  }

  if (req.method === 'GET' && url.pathname === '/live/sources') {
    const userId = getUserId(url, req);
    if (!userId) return json(res, 400, { ok: false, error: 'user_id is required' });
    return json(res, 200, { ok: true, userId, sources: listLiveSources(userId) });
  }

  if (req.method === 'POST' && url.pathname === '/live/sources/connect') {
    try {
      const body = await readBody(req);
      const userId = body.userId || body.user_id;
      const sources = upsertLiveSource(userId, body);
      await refreshLiveData({ userId });
      return json(res, 200, { ok: true, userId, sources });
    } catch (err) {
      return json(res, 400, { ok: false, error: err.message });
    }
  }

  if (req.method === 'GET' && url.pathname === '/live/channels') {
    const userId = getUserId(url, req);
    if (!userId) return json(res, 400, { ok: false, error: 'user_id is required' });
    const view = getLiveUserView(userId);
    return json(res, 200, {
      ok: true,
      userId,
      generatedAt: view.generatedAt,
      source: 'live-control-plane',
      channels: view.channels,
      groups: view.groups
    });
  }

  if (req.method === 'GET' && url.pathname === '/live/guide') {
    const userId = getUserId(url, req);
    if (!userId) return json(res, 400, { ok: false, error: 'user_id is required' });
    const channelId = url.searchParams.get('channel_id') || '';
    const view = getLiveUserView(userId);
    const channels = channelId ? view.channels.filter(c => c.id === channelId) : view.channels;
    return json(res, 200, {
      ok: true,
      userId,
      generatedAt: view.generatedAt,
      channels: channels.map(channel => ({
        id: channel.id,
        number: channel.number,
        name: channel.name,
        current: channel.current,
        next: channel.next,
        logo: channel.logo,
        poster: channel.poster,
        backdrop: channel.backdrop
      }))
    });
  }

  if (req.method === 'GET' && url.pathname.startsWith('/live/channel/')) {
    const userId = getUserId(url, req);
    if (!userId) return json(res, 400, { ok: false, error: 'user_id is required' });
    const channelId = decodeURIComponent(url.pathname.split('/').pop() || '');
    const channel = getChannelById(userId, channelId);
    if (!channel) return json(res, 404, { ok: false, error: 'Channel not found' });
    return json(res, 200, { ok: true, userId, channel });
  }

  if (req.method === 'GET' && url.pathname === '/live/quick-guide') {
    const userId = getUserId(url, req);
    if (!userId) return json(res, 400, { ok: false, error: 'user_id is required' });
    const channelId = url.searchParams.get('channel_id') || '';
    const view = getLiveUserView(userId);
    return json(res, 200, {
      ok: true,
      userId,
      source: 'live-control-plane',
      quickGuide: buildQuickGuide(view.channels, channelId)
    });
  }

  if (req.method === 'POST' && url.pathname === '/live/playback/resolve') {
    try {
      const body = await readBody(req);
      const userId = body.userId || body.user_id;
      const channelId = body.channelId || body.channel_id;
      if (!userId || !channelId) return json(res, 400, { ok: false, error: 'userId and channelId are required' });
      return json(res, 200, { ok: true, playback: resolvePlayback(userId, channelId) });
    } catch (err) {
      return json(res, 400, { ok: false, error: err.message });
    }
  }

  if (req.method === 'POST' && url.pathname === '/live/refresh') {
    try {
      const body = await readBody(req).catch(() => ({}));
      const userId = body.userId || body.user_id || getUserId(url, req) || undefined;
      const result = await refreshLiveData({ userId });
      return json(res, 200, { ok: true, generatedAt: result.generatedAt, users: userId ? [userId] : Object.keys(result.users) });
    } catch (err) {
      return json(res, 500, { ok: false, error: err.message });
    }
  }


  if (req.method === 'GET' && url.pathname === '/trailers/resolve') {
    try {
      const title = (url.searchParams.get('title') || '').trim();
      const year = (url.searchParams.get('year') || '').trim();
      const prefer4k = url.searchParams.get('prefer4k') !== 'false';
      if (!title) return json(res, 400, { ok: false, error: 'title is required' });
      const trailer = await resolveTrailer({ title, year, prefer4k });
      return json(res, 200, { ok: true, trailer }, { cacheControl: 'private, max-age=600' });
    } catch (err) {
      return json(res, 502, { ok: false, error: err.message });
    }
  }

  if (req.method === 'GET' && url.pathname === '/') {
    return json(res, 200, {
      ok: true,
      message: 'Channels Debrid backend is running',
      endpoints: [
        '/health',
        '/api/health',
        '/api/home',
        '/api/sources',
        '/api/refresh',
        '/live/sources',
        '/live/channels',
        '/live/guide',
        '/live/quick-guide',
        '/live/playback/resolve',
        '/live/refresh'
      ]
    });
  }

  return notFound(res, url);
}

const server = http.createServer((req, res) => {
  handle(req, res).catch((err) => {
    json(res, 500, { ok: false, error: err.message });
  });
});

server.listen(port, '0.0.0.0', () => {
  console.log(`Channels Debrid backend listening on 0.0.0.0:${port}`);
  refreshCatalogs().then((result) => {
    console.log('Warm catalog refresh complete', result.generatedAt || 'ok');
  }).catch((err) => {
    console.warn('Warm catalog refresh failed:', err.message);
  });
});
