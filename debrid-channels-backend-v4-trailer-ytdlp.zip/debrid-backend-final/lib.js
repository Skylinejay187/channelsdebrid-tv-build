
const fs = require('fs');
const path = require('path');

const CACHE_DIR = path.join(__dirname, 'data');
const HOME_CACHE_PATH = path.join(CACHE_DIR, 'home-rows.json');
const STATE_PATH = path.join(CACHE_DIR, 'catalog-state.json');
const LIVE_USERS_PATH = path.join(CACHE_DIR, 'live-users.json');
const LIVE_PUBLIC_SOURCES_PATH = path.join(CACHE_DIR, 'live-public-sources.json');
const LIVE_CACHE_PATH = path.join(CACHE_DIR, 'live-cache.json');

const DEFAULT_SOURCES = [
  {
    key: 'cinemeta',
    title: 'Cinemeta',
    manifestUrl: process.env.CINEMETA_MANIFEST_URL || 'https://v3-cinemeta.strem.io/manifest.json',
    enabled: (process.env.CINEMETA_ENABLED || 'true') !== 'false',
    preferredCatalogs: (process.env.CINEMETA_CATALOG_IDS || 'top,year,imdbRating').split(',').map(s => s.trim()).filter(Boolean),
    maxRails: Number(process.env.CINEMETA_MAX_RAILS || 4)
  },
  {
    key: 'streaming_catalogs',
    title: 'Streaming Catalogs',
    manifestUrl: process.env.STREAMING_CATALOGS_MANIFEST_URL || 'https://7a82163c306e-stremio-netflix-catalog-addon.baby-beamup.club/ZG5wLGFtcCxhdHAsaGJtLG5meCxwbXAscGNwLGhsdSxzdHosY3J1OnQwLWZyZWUtcnBkYjpVUzoxNzY5Mzg5ODgyNjI3OjA6MDpVUw%3D%3D/manifest.json',
    enabled: (process.env.STREAMING_CATALOGS_ENABLED || 'true') !== 'false',
    preferredCatalogs: (process.env.STREAMING_CATALOGS_CATALOG_IDS || 'nfx,dnp,hbm,atp,hlu,pmp,pcp,stz,cru').split(',').map(s => s.trim()).filter(Boolean),
    maxRails: Number(process.env.STREAMING_CATALOGS_MAX_RAILS || 6)
  }
];

function ensureCacheDir() {
  fs.mkdirSync(CACHE_DIR, { recursive: true });
}

function readJson(filePath, fallback) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return fallback;
  }
}

function writeJson(filePath, value) {
  ensureCacheDir();
  fs.writeFileSync(filePath, JSON.stringify(value, null, 2));
}

function loadHomeRows() {
  return readJson(HOME_CACHE_PATH, {
    generatedAt: new Date(0).toISOString(),
    source: 'built-in-fallback',
    rails: []
  });
}

function loadState() {
  return readJson(STATE_PATH, { lastRefreshAt: null, sources: [] });
}

async function fetchJson(url, timeoutMs = 15000, headers = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      headers: { 'user-agent': 'Debrid-Channels-Backend/0.3', ...headers },
      signal: controller.signal
    });
    if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

async function fetchText(url, timeoutMs = 15000, headers = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      headers: { 'user-agent': 'Debrid-Channels-Backend/0.3', ...headers },
      signal: controller.signal
    });
    if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
    return await res.text();
  } finally {
    clearTimeout(timer);
  }
}

function buildAddonBase(manifestUrl) {
  return manifestUrl.replace(/\/manifest\.json(?:\?.*)?$/i, '');
}

function buildCatalogUrl(manifestUrl, type, id) {
  const base = buildAddonBase(manifestUrl);
  return `${base}/catalog/${encodeURIComponent(type)}/${encodeURIComponent(id)}.json`;
}

function pickCatalogs(manifest, source) {
  const catalogs = Array.isArray(manifest.catalogs) ? manifest.catalogs : [];
  const filtered = catalogs.filter(c => c && (c.type === 'movie' || c.type === 'series'));
  const pref = [];
  for (const catalogId of source.preferredCatalogs) {
    for (const c of filtered) {
      if (c.id === catalogId && !pref.includes(c)) pref.push(c);
    }
  }
  for (const c of filtered) {
    if (!pref.includes(c)) pref.push(c);
  }
  return pref.slice(0, source.maxRails);
}

function cleanText(value, fallback = '') {
  return typeof value === 'string' && value.trim() ? value.trim() : fallback;
}

function normalizeItem(item, sourceKey, sourceTitle) {
  const releaseInfo = cleanText(item.releaseInfo, '');
  const parsedYear = Number(String(releaseInfo).match(/\d{4}/)?.[0] || item.year || 0) || null;
  return {
    id: cleanText(item.id, `unknown-${Math.random().toString(36).slice(2, 9)}`),
    type: item.type === 'series' ? 'series' : 'movie',
    title: cleanText(item.name, cleanText(item.title, 'Untitled')),
    year: parsedYear,
    poster: cleanText(item.poster, cleanText(item.posterShape === 'landscape' ? item.background : '', '')),
    backdrop: cleanText(item.background, cleanText(item.poster, '')),
    logo: cleanText(item.logo, ''),
    imdbId: cleanText(item.imdb_id || item.imdbId || (typeof item.id === 'string' && item.id.startsWith('tt') ? item.id : ''), ''),
    overview: cleanText(item.description, ''),
    genres: Array.isArray(item.genres) ? item.genres : [],
    source: sourceTitle,
    sourceKey,
    streamLookupId: cleanText(item.id, ''),
    streamLookupType: item.type === 'series' ? 'series' : 'movie'
  };
}

function dedupeItems(items) {
  const out = [];
  const seen = new Set();
  for (const item of items) {
    const key = item.imdbId || `${item.type}:${item.title}:${item.year || ''}`.toLowerCase();
    if (!seen.has(key)) {
      seen.add(key);
      out.push(item);
    }
  }
  return out;
}

async function fetchCatalogRail(source, catalog) {
  const url = buildCatalogUrl(source.manifestUrl, catalog.type, catalog.id);
  const payload = await fetchJson(url);
  const metas = Array.isArray(payload?.metas) ? payload.metas : [];
  const items = dedupeItems(metas.map(item => normalizeItem(item, source.key, source.title))).slice(0, 24);
  return {
    slug: `${source.key}-${catalog.type}-${catalog.id}`,
    title: cleanText(catalog.name, `${source.title} ${catalog.type}`),
    type: catalog.type,
    catalogId: catalog.id,
    source: source.title,
    sourceKey: source.key,
    items
  };
}

async function refreshCatalogs() {
  const rails = [];
  const sourceStates = [];
  for (const source of DEFAULT_SOURCES.filter(s => s.enabled)) {
    const state = {
      key: source.key,
      title: source.title,
      manifestUrl: source.manifestUrl,
      ok: false,
      railsFetched: 0,
      error: null,
      catalogs: []
    };
    try {
      const manifest = await fetchJson(source.manifestUrl);
      const catalogs = pickCatalogs(manifest, source);
      state.catalogs = catalogs.map(c => ({ id: c.id, type: c.type, name: c.name || '' }));
      for (const catalog of catalogs) {
        try {
          const rail = await fetchCatalogRail(source, catalog);
          if (rail.items.length) {
            rails.push(rail);
            state.railsFetched += 1;
          }
        } catch (err) {
          state.error = state.error || `catalog ${catalog.id}: ${err.message}`;
        }
      }
      state.ok = state.railsFetched > 0;
    } catch (err) {
      state.error = err.message;
    }
    sourceStates.push(state);
  }

  const payload = {
    generatedAt: new Date().toISOString(),
    source: 'remote-catalog-ingestion',
    rails
  };
  writeJson(HOME_CACHE_PATH, payload);
  writeJson(STATE_PATH, {
    lastRefreshAt: payload.generatedAt,
    sources: sourceStates
  });
  return { home: payload, state: loadState() };
}

function loadLiveUsers() {
  return readJson(LIVE_USERS_PATH, { users: {} });
}

function saveLiveUsers(value) {
  writeJson(LIVE_USERS_PATH, value);
}

function loadLivePublicSources() {
  return readJson(LIVE_PUBLIC_SOURCES_PATH, { sources: [] });
}

function loadLiveCache() {
  return readJson(LIVE_CACHE_PATH, { generatedAt: null, users: {} });
}

function saveLiveCache(value) {
  writeJson(LIVE_CACHE_PATH, value);
}

function sanitizeUrl(input) {
  const value = cleanText(input, '');
  return value.replace(/\/$/, '');
}

function slugify(input) {
  return cleanText(input, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || 'source';
}

function normalizeSourcePayload(payload) {
  const type = cleanText(payload.type).toLowerCase();
  if (!['channels_dvr', 'm3u', 'public_demo'].includes(type)) {
    throw new Error('Unsupported source type');
  }
  const name = cleanText(payload.name, type === 'channels_dvr' ? 'Channels DVR' : type === 'm3u' ? 'M3U Source' : 'Public Demo');
  const sourceId = cleanText(payload.sourceId, `${slugify(type)}-${slugify(name)}-${Date.now().toString(36)}`);
  return {
    sourceId,
    type,
    name,
    url: sanitizeUrl(payload.url),
    username: cleanText(payload.username, ''),
    password: cleanText(payload.password, ''),
    headers: typeof payload.headers === 'object' && payload.headers ? payload.headers : {},
    enabled: payload.enabled !== false,
    visibility: cleanText(payload.visibility, 'private'),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
}

function listLiveSources(userId) {
  const users = loadLiveUsers().users || {};
  const publicSources = loadLivePublicSources().sources || [];
  return [
    ...((users[userId]?.sources || []).filter(s => s.enabled !== false)),
    ...publicSources.filter(s => s.enabled !== false)
  ];
}

function upsertLiveSource(userId, payload) {
  if (!userId) throw new Error('userId is required');
  const data = loadLiveUsers();
  if (!data.users[userId]) data.users[userId] = { sources: [] };
  const normalized = normalizeSourcePayload(payload);
  const idx = data.users[userId].sources.findIndex(s => s.sourceId === normalized.sourceId);
  if (idx >= 0) {
    normalized.createdAt = data.users[userId].sources[idx].createdAt || normalized.createdAt;
    data.users[userId].sources[idx] = { ...data.users[userId].sources[idx], ...normalized, updatedAt: new Date().toISOString() };
  } else {
    data.users[userId].sources.push(normalized);
  }
  saveLiveUsers(data);
  return data.users[userId].sources;
}

function parseM3U(text, source) {
  const lines = text.split(/\r?\n/);
  const channels = [];
  let pending = null;
  for (const line of lines) {
    if (line.startsWith('#EXTINF:')) {
      const tvgLogo = /tvg-logo="([^"]+)"/i.exec(line)?.[1] || '';
      const tvgId = /tvg-id="([^"]+)"/i.exec(line)?.[1] || '';
      const group = /group-title="([^"]+)"/i.exec(line)?.[1] || 'Other';
      const name = line.split(',').slice(1).join(',').trim() || 'Channel';
      pending = { tvgLogo, tvgId, group, name };
      continue;
    }
    if (pending && line && !line.startsWith('#')) {
      channels.push({
        id: `${source.sourceId}:${tvgSafe(pending.tvgId || pending.name)}`,
        externalId: pending.tvgId || pending.name,
        number: null,
        name: pending.name,
        logo: pending.tvgLogo || '',
        poster: pending.tvgLogo || '',
        backdrop: '',
        sourceType: source.type,
        sourceId: source.sourceId,
        sourceName: source.name,
        group: pending.group,
        streamUrl: line.trim(),
        current: {
          title: pending.name,
          description: '',
          start: null,
          end: null,
          progress: null
        },
        next: null
      });
      pending = null;
    }
  }
  return channels;
}

function tvgSafe(v) {
  return String(v || '').replace(/[^a-zA-Z0-9_-]+/g, '_');
}

function normalizeChannelsDvrItem(item, source) {
  const channelId = cleanText(String(item.id || item.channelId || item.slug || item.number || item.name), 'channel');
  const streamUrl = cleanText(item.streamUrl, `${source.url}/devices/ANY/channels/${encodeURIComponent(channelId)}/stream.m3u8`);
  const title = cleanText(item.title || item.programTitle || item.name || item.channel, 'Unknown Program');
  return {
    id: `${source.sourceId}:${channelId}`,
    externalId: channelId,
    number: cleanText(String(item.number || item.channelNumber || ''), ''),
    name: cleanText(item.channel || item.name || title, 'Channel'),
    logo: cleanText(item.logo || item.icon || '', ''),
    poster: cleanText(item.poster || item.image || item.logo || '', ''),
    backdrop: cleanText(item.backdrop || item.background || item.poster || '', ''),
    sourceType: source.type,
    sourceId: source.sourceId,
    sourceName: source.name,
    group: cleanText(item.group || item.category || 'Channels DVR', 'Channels DVR'),
    streamUrl,
    current: {
      title,
      description: cleanText(item.description || 'Now playing', ''),
      start: cleanText(item.startLabel || item.start || '', ''),
      end: cleanText(item.endLabel || item.end || '', ''),
      progress: typeof item.progress === 'number' ? item.progress : null
    },
    next: item.nextTitle ? {
      title: cleanText(item.nextTitle, ''),
      start: cleanText(item.nextStart || '', ''),
      end: cleanText(item.nextEnd || '', '')
    } : null
  };
}

async function fetchChannelsForSource(source) {
  if (source.type === 'channels_dvr') {
    if (!source.url) throw new Error('Channels DVR source requires url');
    const payload = await fetchJson(`${source.url}/devices/ANY/channels`, 15000, source.headers || {});
    const items = Array.isArray(payload) ? payload : Array.isArray(payload?.channels) ? payload.channels : [];
    return items.map(item => normalizeChannelsDvrItem(item, source));
  }
  if (source.type === 'm3u' || source.type === 'public_demo') {
    if (!source.url) throw new Error('M3U source requires url');
    const text = await fetchText(source.url, 15000, source.headers || {});
    return parseM3U(text, source);
  }
  return [];
}

function buildQuickGuide(channels, selectedChannelId) {
  const maxItems = Number(process.env.LIVE_MAX_QUICK_GUIDE_ITEMS || 12);
  const selectedIndex = Math.max(channels.findIndex(c => c.id === selectedChannelId), 0);
  const start = Math.max(0, Math.min(selectedIndex - 2, Math.max(0, channels.length - maxItems)));
  const slice = channels.slice(start, start + maxItems);
  const focused = slice.find(c => c.id === selectedChannelId) || slice[0] || null;
  return {
    generatedAt: new Date().toISOString(),
    selectedChannelId: focused?.id || null,
    items: slice,
    focused
  };
}

function groupChannels(channels) {
  const groups = new Map();
  for (const channel of channels) {
    const key = channel.group || 'Other';
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(channel);
  }
  return Array.from(groups.entries()).map(([title, items]) => ({ title, items }));
}

async function refreshLiveData({ userId } = {}) {
  const users = loadLiveUsers().users || {};
  const allUserIds = userId ? [userId] : Object.keys(users);
  const cache = loadLiveCache();
  const next = {
    generatedAt: new Date().toISOString(),
    users: cache.users || {}
  };
  for (const uid of allUserIds) {
    const sources = listLiveSources(uid);
    const channels = [];
    const sourceStates = [];
    for (const source of sources) {
      const state = { sourceId: source.sourceId, name: source.name, type: source.type, ok: false, channels: 0, error: null };
      try {
        const sourceChannels = await fetchChannelsForSource(source);
        channels.push(...sourceChannels);
        state.ok = sourceChannels.length > 0;
        state.channels = sourceChannels.length;
      } catch (err) {
        state.error = err.message;
      }
      sourceStates.push(state);
    }
    const normalized = channels
      .sort((a, b) => String(a.number || a.name).localeCompare(String(b.number || b.name), undefined, { numeric: true }))
      .map((ch, idx) => ({ ...ch, sortOrder: idx }));
    next.users[uid] = {
      generatedAt: next.generatedAt,
      sources: sourceStates,
      channels: normalized,
      groups: groupChannels(normalized)
    };
  }
  saveLiveCache(next);
  return next;
}

function getLiveUserView(userId) {
  const cache = loadLiveCache();
  return cache.users?.[userId] || { generatedAt: null, sources: [], channels: [], groups: [] };
}

function getChannelById(userId, channelId) {
  const view = getLiveUserView(userId);
  return view.channels.find(c => c.id === channelId) || null;
}

function resolvePlayback(userId, channelId) {
  const channel = getChannelById(userId, channelId);
  if (!channel) throw new Error('Channel not found');
  return {
    userId,
    channelId,
    sourceId: channel.sourceId,
    sourceName: channel.sourceName,
    streamUrl: channel.streamUrl,
    directPlay: true,
    headers: {},
    playbackType: 'direct',
    resolvedAt: new Date().toISOString()
  };
}

module.exports = {
  DEFAULT_SOURCES,
  loadHomeRows,
  loadState,
  refreshCatalogs,
  loadLiveUsers,
  listLiveSources,
  upsertLiveSource,
  loadLiveCache,
  refreshLiveData,
  getLiveUserView,
  getChannelById,
  buildQuickGuide,
  resolvePlayback
};
