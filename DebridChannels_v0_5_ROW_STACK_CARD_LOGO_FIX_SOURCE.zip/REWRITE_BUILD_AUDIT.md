# Rewrite Build Audit - v0.4

Base used: v0.3 Settings Scroll Fix, itself rebuilt from v0.2.1/v6.9 stable line.

Rule followed: clean consolidation from latest known-good stable base. Broken v7.1 code path was not used.

Fixes in this build:
- Repaired DPAD UP/DOWN row-to-row focus path in the active row engine.
- Added row navigation debug log markers using DC_V0_4_ROW_NAV_LANDSCAPE_FIX_ACTIVE.
- Added focused-row visibility adjustment so lower rows can be reached without the UI feeling frozen.
- Changed row-card artwork selection to prefer landscape/banner/backdrop artwork and avoid poster/thumbnail/logo URLs when possible.
- Updated versionCode to 5 and versionName to 0.4.

Preserved:
- v6.9 hero logo placement and rating badges.
- v0.3 Settings scrolling fix.
- Pro Layout Editor current working state.
- Backend default URL http://192.168.100.55:8181.
