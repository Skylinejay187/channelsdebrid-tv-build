# Debrid Channels v0.3 Settings Scroll Fix

Clean rewrite/consolidation from the known-good v0.2.1/v6.9 stable line.

Marker: DC_V0_3_SETTINGS_SCROLL_FIX_ACTIVE
