package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.4 ROW NAV LANDSCAPE FIX";
    public static final String LOG_MARKER = "DC_V0_4_ROW_NAV_LANDSCAPE_FIX_ACTIVE";
    private BuildMarkers() {}
}
