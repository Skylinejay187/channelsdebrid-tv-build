package com.channelsdebrid.tv

import com.channelsdebrid.tv.net.BackendEndpoint
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.channelsdebrid.tv.data.BackendHomeLoader
import com.channelsdebrid.tv.data.BackendlessArtworkProvider
import com.channelsdebrid.tv.data.StremioLiveLoader
import com.channelsdebrid.tv.data.UnifiedCatalogRepository
import com.channelsdebrid.tv.config.UIConfigManager
import com.channelsdebrid.tv.playback.MediaDetailsActivity
import com.channelsdebrid.tv.settings.HomeLayoutSettings
import com.channelsdebrid.tv.settings.SettingsRepository
import com.channelsdebrid.tv.settings.homeLayoutFontName
import com.channelsdebrid.tv.settings.homeLayoutTypeface
import com.channelsdebrid.tv.settings.homeLayoutRingColor
import java.util.concurrent.Executors

/**
 * NewtoOld v2.1 hard home rebuild.
 *
 * This file intentionally does not use the previous ScrollView + per-row binding system.
 * Rows are owned by one vertical RecyclerView and one explicit FocusGraph so DPAD DOWN/UP
 * cannot be stolen by legacy scroll recovery code.
 */
class MainActivity : AppCompatActivity() {
    private companion object {
        private const val BACKEND_BASE_URL = "https://api.skylinejay187.it.com"
        private const val TAG = "DebridChannels"
    }

    private lateinit var repository: SettingsRepository
    private var config = HomeLayoutSettings()
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val backendLoader = BackendHomeLoader()
    private val artworkProvider by lazy { BackendlessArtworkProvider(this) }
    private val stremioLoader = StremioLiveLoader()

    private lateinit var root: FrameLayout
    private lateinit var heroBackdrop: ImageView
    private lateinit var heroScrim: View
    private lateinit var heroLighting: View
    private lateinit var heroText: LinearLayout
    private lateinit var heroTitle: TextView
    private lateinit var heroMeta: TextView
    private lateinit var heroRatings: LinearLayout
    private lateinit var imdbBadge: TextView
    private lateinit var tmdbBadge: TextView
    private lateinit var heroDesc: TextView
    private lateinit var heroLogo: ImageView
    private lateinit var heroExtraArt: ImageView
    private lateinit var topMenu: LinearLayout
    private lateinit var rowsRecycler: RecyclerView
    private lateinit var stableRowsScroll: ScrollView
    private lateinit var stableRowsColumn: LinearLayout
    private lateinit var statusPill: TextView

    private val rowRecyclerByIndex = LinkedHashMap<Int, RecyclerView>()
    private val stableRowByIndex = LinkedHashMap<Int, LinearLayout>()
    private val stableScrollerByIndex = LinkedHashMap<Int, HorizontalScrollView>()
    private val stableCardByKey = LinkedHashMap<String, FrameLayout>()
    private var currentRows: List<HomeRow> = emptyList()
    private var lastFocusedRow = 0
    private var lastFocusedColumn = 0
    private var lastHeroBackdropKey: String = ""
    private var lastHeroLogoKey: String = ""
    private var lastHeroExtraKey: String = ""
    private var lastHeroIdentityKey: String = ""
    private var pendingHeroItem: TitleCard? = null
    private val heroUpdateRunnable = Runnable {
        pendingHeroItem?.let { applyHeroNow(it) }
        pendingHeroItem = null
    }

    data class TitleCard(
        val title: String,
        val meta: String,
        val desc: String,
        val backgroundRes: Int,
        val posterUrl: String? = null,
        val backdropUrl: String? = null,
        val logoUrl: String? = null,
        val mediaType: String = "movie",
        val externalId: String? = null,
        val year: Int = 0,
        val source: String = "Local"
    )

    data class HomeRow(val title: String, val items: List<TitleCard>)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.channelsdebrid.tv.config.UiModeApplier.apply(this)
        repository = SettingsRepository(this)
        config = repository.loadHomeLayout()
        applyNativeUiConfig()
        Log.i(TAG, "DC_BUILD_MARKER: NewtoOld_v2.8.20.5_MOVIES_SHOWS_PRELOAD_RELATED_CACHE_FIX")
        Log.i(TAG, "ROW_ENGINE: V10_DONOR_ONE_ROW_RESET_TO_FIRST_CARD_ON_ROW_CHANGE")
        Log.i(TAG, "FOCUS_EFFECTS_RESTORED: scale_ring_lift_active")
        Log.i(TAG, "FOCUS_GLOW_CONTROL: editor_slider_active strength_spread")
        Log.i(TAG, "STREMIO_LOGO_RESOLUTION: multi_key_meta_detail_metahub_fallback_active")
        Log.i(TAG, "HERO_BACKDROP_QUALITY: original_argb8888_no_card_override")
        Log.i(TAG, "ROW_ENGINE: OLD_NEWTOOLD_ROW_RENDERERS_DELETED_DONOR_ROW_CARD_PATH_ACTIVE")
        Log.i(TAG, "FOCUS_GRAPH: V10_ROW_CHANGE_RESETS_COLUMN_ZERO")
        Log.i(TAG, "CLEAN_CORE_AUDIT: old_row_stack_deleted active_donor_row_only cache_off_direct_player_preserved ui_preset_picker_view_apply")
        Log.i(TAG, "TOP_MENU_ENGINE: FULL_THEME_CHOOSER_ACTIVE noGlassOption=true")
        Log.i(TAG, "DEBRID_STATUS: NOT_PRESENT runtimeHome=false")
        Log.i(TAG, "BACKENDLESS_ARTWORK_PROVIDER: ACTIVE mode=${config.artworkSourceMode}")
        buildUi()
        applyMenuTheme()
        setRows(defaultRows())
        loadArtworkRows()
        warmMoviesShowsInBackground()
    }


    private fun warmMoviesShowsInBackground() {
        io.execute {
            runCatching {
                val catalogRepo = UnifiedCatalogRepository(this)
                val preloadItems = catalogRepo.prewarmDiscoverySections(listOf("movies", "shows"), 42)
                preloadItems.forEach { item ->
                    listOf(item.posterUrl, item.backdropUrl, item.logoUrl)
                        .filter { it.isNotBlank() }
                        .take(3)
                        .forEach { url ->
                            runCatching {
                                Glide.with(applicationContext)
                                    .downloadOnly()
                                    .load(BackendEndpoint.imageProxyUrl(url))
                                    .submit()
                            }
                        }
                }
                runCatching { java.net.URL(BackendEndpoint.route("/api/prewarm")).openConnection().apply { connectTimeout = 1200; readTimeout = 1600 }.getInputStream().close() }
                Log.i(TAG, "MOVIES_SHOWS_PREWARM: cached_items=${preloadItems.size} domain=${BackendEndpoint.baseUrl()}")
            }.onFailure { Log.w(TAG, "MOVIES_SHOWS_PREWARM_FAIL: ${it.message}") }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra("force_reload_layout", false)) {
            reloadHomeLayoutFromEditor()
        }
    }

    override fun onResume() {
        super.onResume()
        if (::repository.isInitialized) {
            val latest = repository.loadHomeLayout()
            if (latest != config) {
                config = latest
                reloadHomeLayoutFromEditor()
            }
        }
    }

    private fun reloadHomeLayoutFromEditor() {
        config = repository.loadHomeLayout()
        applyNativeUiConfig()
        buildUi()
        applyMenuTheme()
        setRows(defaultRows())
        loadArtworkRows()
        warmMoviesShowsInBackground()
        Log.i(TAG, "HOME_LAYOUT_RELOAD_FROM_EDITOR: applied_immediately=true build=NewtoOld_v2.8.20.5_MOVIES_SHOWS_PRELOAD_RELATED_CACHE_FIX")
    }


    private fun applyNativeUiConfig() {
        UIConfigManager.uiRenderMode = when (config.nativeUiResolutionMode.coerceIn(0, 2)) {
            1 -> UIConfigManager.UiRenderMode.NATIVE_1080P
            2 -> UIConfigManager.UiRenderMode.NATIVE_4K
            else -> UIConfigManager.UiRenderMode.AUTO
        }
        UIConfigManager.heroMenuPosition = heroMenuPosition()
        UIConfigManager.heroLightingEnabled = config.heroLightingEnabled == 1
        UIConfigManager.heroLightingIntensity = config.heroLightingIntensityPercent.coerceIn(0, 45) / 100f
        UIConfigManager.hdHomeRunAutoScanEnabled = repository.loadChannelsDvr().hdHomeRunAutoScan
        Log.i(TAG, "NATIVE_4K_UI_MODE: new_app_style active=${UIConfigManager.isNative4KActive(this)} mode=${UIConfigManager.uiRenderMode}")
        Log.i(TAG, "HERO_MENU_POSITION: ${UIConfigManager.heroMenuPosition}")
        Log.i(TAG, "HERO_LIGHTING: enabled=${UIConfigManager.heroLightingEnabled} intensity=${UIConfigManager.heroLightingIntensity}")
        Log.i(TAG, "HDHOMERUN_AUTO_SCAN_SETTING: ${UIConfigManager.hdHomeRunAutoScanEnabled}")
        Log.i(TAG, "HERO_BADGE_SYSTEM: imdb=${config.imdbBadgeVisible} tmdb=${config.tmdbBadgeVisible} ratings=${config.ratingNumbersVisible} theme=${config.heroBadgeTheme} position=${config.heroBadgePosition}")
        Log.i(TAG, "ROW_FOCUS_REWRITE: stableMode=${config.stableRowFocusMode}")
    }
    override fun onDestroy() {
        super.onDestroy()
        io.shutdownNow()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            clipChildren = false
            clipToPadding = false
        }
        heroBackdrop = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.88f
        }
        heroScrim = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xF2000000.toInt(), 0xAA000000.toInt(), 0x22000000)
            )
        }
        heroLighting = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x00000000, 0x1800AEEF, 0x33000000)
            )
            alpha = (config.heroLightingIntensityPercent.coerceIn(0, 45) / 100f)
            visibility = if (config.heroLightingEnabled == 1) View.VISIBLE else View.GONE
        }
        heroText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(34 + config.heroTextLeftDp), dp(118 + config.heroTextTopDp), dp(34), 0)
            clipChildren = false
        }
        heroTitle = TextView(this).apply {
            textSize = 48f * (config.heroTextSizePercent.coerceIn(60, 160) / 100f)
            setTextColor(Color.WHITE)
            typeface = homeLayoutTypeface(config.heroFontIndex)
            maxLines = 2
        }
        heroMeta = TextView(this).apply {
            textSize = 19f * (config.heroTextSizePercent.coerceIn(60, 160) / 100f)
            setTextColor(0xFFFFD84A.toInt())
            typeface = homeLayoutTypeface(config.heroFontIndex)
            setPadding(0, dp(12), 0, 0)
        }
        heroRatings = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        imdbBadge = ratingBadge("IMDb", 0xFFFFC400.toInt(), 0xFF101010.toInt())
        tmdbBadge = ratingBadge("TMDB", 0xFF01B4E4.toInt(), 0xFFFFFFFF.toInt())

        heroDesc = TextView(this).apply {
            textSize = 24f * (config.heroTextSizePercent.coerceIn(60, 160) / 100f)
            setTextColor(Color.WHITE)
            typeface = homeLayoutTypeface(config.heroFontIndex)
            maxLines = 3
            setPadding(0, dp(14), dp(380), 0)
        }
        heroText.addView(heroTitle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        heroText.addView(heroMeta, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        heroText.addView(heroRatings, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)))
        heroText.addView(heroDesc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        heroLogo = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            visibility = View.INVISIBLE
            elevation = dp(20).toFloat()
        }

        heroExtraArt = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            elevation = 0f
            visibility = View.INVISIBLE
        }

        topMenu = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            clipChildren = false
            clipToPadding = false
            translationX = dp(config.topMenuOffsetDp).toFloat()
        }
        buildTopMenuItems()

        // v2.8.16.1: donor new-app row/card renderer path.
        // Only the active row is attached; all cards in that active row remain available horizontally.
        rowsRecycler = RecyclerView(this).apply {
            id = View.generateViewId()
            layoutManager = LinearLayoutManager(this@MainActivity, RecyclerView.VERTICAL, false)
            itemAnimator = null
            overScrollMode = View.OVER_SCROLL_NEVER
            clipChildren = false
            clipToPadding = false
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
            setHasFixedSize(true)
            isFocusable = false
            visibility = View.GONE
            recycledViewPool.setMaxRecycledViews(0, 8)
        }

        stableRowsColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            setPadding(0, 0, 0, dp(80))
        }
        stableRowsScroll = ScrollView(this).apply {
            id = View.generateViewId()
            isFillViewport = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipChildren = false
            clipToPadding = false
            isFocusable = false
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
            elevation = dp(24).toFloat()
            addView(stableRowsColumn, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        statusPill = TextView(this).apply {
            text = "10:17 PM   •   No new favorites"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = rounded(0x66000000, 24, 0x55FFFFFF, 1)
        }

        root.addView(heroBackdrop, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(heroScrim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(heroLighting, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(heroText, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(430), Gravity.TOP or Gravity.START))
        root.addView(heroLogo, heroLogoParams())
        root.addView(heroExtraArt, extraArtHeroParams())
        root.addView(topMenu, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(58), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(UIConfigManager.menuTopMarginDp(this@MainActivity, heroMenuPosition())) })
        root.addView(rowsRecycler, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply {
            topMargin = dp(config.rowTopDp.coerceIn(360, 620))
            leftMargin = dp(config.rowLeftDp.coerceIn(0, 120))
            bottomMargin = dp(config.bottomSafeDp.coerceIn(24, 160))
        })
        root.addView(stableRowsScroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply {
            topMargin = dp(config.rowTopDp.coerceIn(360, 620))
            leftMargin = dp(config.rowLeftDp.coerceIn(0, 120))
            bottomMargin = dp(config.bottomSafeDp.coerceIn(24, 160))
        })
        stableRowsScroll.visibility = View.VISIBLE
        if (config.statusHubVisible == 1) {
            root.addView(statusPill, FrameLayout.LayoutParams(dp(490), dp(58), Gravity.BOTTOM or Gravity.END).apply {
                rightMargin = dp(26)
                bottomMargin = dp(26)
            })
        }
        Log.i(TAG, "STATUS_HUB_VISIBLE_APPLY: ${config.statusHubVisible == 1}")
        setContentView(root)
    }


    private fun ratingBadge(label: String, bgColor: Int, fgColor: Int): TextView = TextView(this).apply {
        text = label
        textSize = if (label == "IMDb") 12f else 11f
        setTextColor(fgColor)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = rounded(bgColor, if (label == "IMDb") 5 else 12, 0x33FFFFFF, 1)
        setPadding(dp(8), 0, dp(8), 0)
    }

    private fun heroMenuPosition(): UIConfigManager.HeroMenuPosition = when (config.heroMenuVerticalPosition.coerceIn(0, 3)) {
        0 -> UIConfigManager.HeroMenuPosition.TOP
        2 -> UIConfigManager.HeroMenuPosition.LOWER
        3 -> UIConfigManager.HeroMenuPosition.TOP_EDGE
        else -> UIConfigManager.HeroMenuPosition.CENTER
    }

    private data class RatingValues(val imdb: String, val tmdb: String)

    private fun bindHeroRatingBadges(item: TitleCard) {
        val values = extractHeroRatings(item)
        heroRatings.removeAllViews()
        if (config.imdbBadgeVisible == 1) addRatingBadge("IMDb", values.imdb, true, 0xFFF5C518.toInt(), 0xFF111111.toInt())
        if (config.tmdbBadgeVisible == 1) addRatingBadge("TMDB", values.tmdb, false, 0xFF01B4E4.toInt(), 0xFFFFFFFF.toInt())
        heroRatings.visibility = if (heroRatings.childCount > 0) View.VISIBLE else View.GONE
        placeRatingBadges()
        Log.i(TAG, "HERO_BADGE_THEME_APPLY: imdb=${values.imdb.ifBlank { "badge-only" }} tmdb=${values.tmdb.ifBlank { "badge-only" }} theme=${config.heroBadgeTheme} numbers=${config.ratingNumbersVisible} rawMeta=${item.meta}")
    }

    private fun placeRatingBadges() {
        if (heroRatings.parent === heroText) heroText.removeView(heroRatings)
        val index = when (config.heroBadgePosition.coerceIn(0, 3)) {
            1 -> 2
            2 -> 1
            3 -> heroText.childCount
            else -> 2
        }.coerceIn(0, heroText.childCount)
        heroText.addView(heroRatings, index, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)))
    }

    private fun extractHeroRatings(item: TitleCard): RatingValues {
        val raw = listOf(item.meta, item.source, item.desc).joinToString("  •  ")
        val imdb = extractRating(raw, listOf("IMDb", "IMDB", "imdbRating", "imdb_rating"))
        val tmdb = extractRating(raw, listOf("TMDB", "tmdbRating", "tmdb_rating", "vote_average", "voteAverage", "vote average"))
            .ifBlank { extractTmdbFallback(raw) }
        return RatingValues(imdb, tmdb)
    }

    private fun extractRating(raw: String, labels: List<String>): String {
        labels.forEach { label ->
            val rx = Regex("(?:^|[\\s•|,;])" + Regex.escape(label) + "\\s*(?:rating|score)?\\s*[:★⭐=/|-]?\\s*([0-9]+(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE)
            val found = rx.find(raw)?.groupValues?.getOrNull(1)
            if (!found.isNullOrBlank()) return normalizeRating(found)
        }
        return ""
    }

    private fun extractTmdbFallback(raw: String): String {
        val patterns = listOf(
            Regex("TMDB[^0-9]{0,18}([0-9]+(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE),
            Regex("vote[_ ]?average[^0-9]{0,18}([0-9]+(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE),
            Regex("tmdbRating[^0-9]{0,18}([0-9]+(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE)
        )
        patterns.forEach { rx ->
            val found = rx.find(raw)?.groupValues?.getOrNull(1)
            if (!found.isNullOrBlank()) return normalizeRating(found)
        }
        return ""
    }

    private fun normalizeRating(value: String): String {
        val n = value.toDoubleOrNull() ?: return value.trim()
        return java.lang.String.format(java.util.Locale.US, "%.1f", n.coerceIn(0.0, 10.0))
    }

    private fun addRatingBadge(label: String, value: String, imdb: Boolean, brandColor: Int, brandTextColor: Int) {
        val theme = config.heroBadgeTheme.coerceIn(0, 14)
        val showNumber = config.ratingNumbersVisible == 1 && value.isNotBlank()
        val badge = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            clipToPadding = false
            clipChildren = false
            elevation = dp(10).toFloat()
            background = badgeContainerBackground(theme, imdb, brandColor)
            setPadding(dp(3), dp(2), dp(8), dp(2))
        }
        val labelView = TextView(this).apply {
            text = when (theme) {
                7 -> if (imdb) "IMDb" else "TMDb"
                10 -> if (imdb) "IMDB" else "TMDB"
                11 -> if (imdb) "imdb" else "tmdb"
                else -> label.uppercase()
            }
            gravity = Gravity.CENTER
            includeFontPadding = false
            typeface = when (theme) {
                3, 9, 12 -> Typeface.create("sans-serif-condensed", Typeface.BOLD)
                4, 13 -> Typeface.create("serif", Typeface.BOLD)
                5, 14 -> Typeface.create("monospace", Typeface.BOLD)
                else -> Typeface.DEFAULT_BOLD
            }
            textSize = when (theme) { 3 -> 13f; 6 -> 16f; 10 -> 12f; 12 -> 15f; else -> 14f }
            setTextColor(if (theme in listOf(2,4,5,9,13)) Color.WHITE else brandTextColor)
            setPadding(dp(if (theme in listOf(6,12) ) 13 else 10), 0, dp(if (theme in listOf(6,12)) 13 else 10), 0)
            background = badgeLabelBackground(theme, brandColor, imdb)
        }
        val valueView = TextView(this).apply {
            text = value
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
            typeface = when (theme) {
                4, 13 -> Typeface.create("serif", Typeface.BOLD)
                5, 14 -> Typeface.create("monospace", Typeface.BOLD)
                7, 11 -> Typeface.create("sans-serif-light", Typeface.NORMAL)
                else -> homeLayoutTypeface(config.heroFontIndex)
            }
            textSize = when (theme) { 3 -> 17f; 6 -> 20f; 12 -> 19f; else -> 18f }
            setTextColor(when (theme) {
                0, 6, 10 -> Color.WHITE
                1 -> 0xFFE7EAEE.toInt()
                2 -> brandColor
                3 -> 0xFFF8FAFF.toInt()
                4 -> 0xFFFFF4C2.toInt()
                5 -> 0xFF9FFFE6.toInt()
                else -> 0xFFEFF4FA.toInt()
            })
            setPadding(dp(9), 0, dp(2), 0)
        }
        val labelHeight = when (theme) { 6, 12 -> 32; 10 -> 25; else -> 28 }
        badge.addView(labelView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(labelHeight)))
        if (showNumber) badge.addView(valueView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)))
        val outerHeight = when (theme) { 6, 12 -> 42; else -> 38 }
        heroRatings.addView(badge, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(outerHeight)).apply { rightMargin = dp(12) })
    }

    private fun badgeLabelBackground(theme: Int, brandColor: Int, imdb: Boolean): GradientDrawable = when (theme.coerceIn(0, 14)) {
        1 -> rounded(brandColor, 7, 0x55FFFFFF, 1)
        2 -> rounded(0x22000000, 10, brandColor, 2)
        3 -> rounded(brandColor, 2, 0x22FFFFFF, 1)
        4 -> rounded(0xAA111111.toInt(), 4, brandColor, 2)
        5 -> rounded(0x66000000, 4, brandColor, 2)
        6 -> rounded(brandColor, if (imdb) 6 else 10, 0x66FFFFFF, 1)
        7 -> rounded(brandColor, if (imdb) 4 else 8, 0x33FFFFFF, 1)
        8 -> rounded(0xAA05070B.toInt(), 14, brandColor, 2)
        9 -> rounded(0x33111111, 0, brandColor, 2)
        10 -> rounded(brandColor, 3, 0x33FFFFFF, 1)
        11 -> rounded(brandColor, 14, 0x33FFFFFF, 1)
        12 -> rounded(brandColor, 8, 0x66FFFFFF, 1)
        13 -> rounded(0x99101824.toInt(), 8, brandColor, 2)
        14 -> rounded(0xFF05070D.toInt(), 4, brandColor, 2)
        else -> rounded(brandColor, if (imdb) 5 else 8, 0x22FFFFFF, 1)
    }

    private fun badgeContainerBackground(theme: Int, imdb: Boolean, brandColor: Int): GradientDrawable = when (theme.coerceIn(0, 14)) {
        0 -> rounded(0x00000000, 0, Color.TRANSPARENT, 0)
        1 -> rounded(0xAA05070B.toInt(), 18, 0x22FFFFFF, 1)
        2 -> rounded(0x6605070B.toInt(), 18, brandColor, 1)
        3 -> rounded(0x33000000, 2, Color.TRANSPARENT, 0)
        4 -> rounded(0xCC05070B.toInt(), 12, 0x33FFFFFF, 1)
        5 -> rounded(0x99000203.toInt(), 6, brandColor, 1)
        6 -> rounded(0xCC05070B.toInt(), 12, 0x33FFFFFF, 1)
        7 -> rounded(Color.TRANSPARENT, 0, Color.TRANSPARENT, 0)
        8 -> rounded(Color.TRANSPARENT, 0, Color.TRANSPARENT, 0)
        9 -> rounded(0x44000000, 0, brandColor, 1)
        10 -> rounded(0x77000000, 9, Color.TRANSPARENT, 0)
        11 -> rounded(0x8805070B.toInt(), 18, 0x22FFFFFF, 1)
        12 -> rounded(0xDD05070B.toInt(), 14, 0x33FFFFFF, 1)
        13 -> rounded(0xAA101824.toInt(), 14, 0x33FFFFFF, 1)
        14 -> rounded(0xAA000000.toInt(), 6, brandColor, 1)
        else -> rounded(0x9905070B.toInt(), 8, 0x33FFFFFF, 1)
    }

    private fun buildTopMenuItems() {
        topMenu.removeAllViews()
        val labels = menuLabelsForStyle(config.topMenuIconStyle)
        labels.forEachIndexed { index, item ->
            val tab = TextView(this).apply {
                id = View.generateViewId()
                text = item.first
                tag = item.second
                textSize = if (config.topMenuIconStyle == 2) 25f else 18f
                setTextColor(Color.WHITE)
                typeface = homeLayoutTypeface(config.topMenuFontIndex)
                gravity = Gravity.CENTER
                isFocusable = true
                isClickable = true
                setPadding(dp(18), 0, dp(18), 0)
                background = menuItemBg(false)
                setOnFocusChangeListener { v, hasFocus ->
                    v.background = menuItemBg(hasFocus)
                    (v as? TextView)?.paint?.isUnderlineText = hasFocus
                    (v as? TextView)?.setShadowLayer(if (hasFocus) dp(10).toFloat() else 0f, 0f, 0f, if (hasFocus) 0xCCBFEFFF.toInt() else Color.TRANSPARENT)
                    animateMenuFocus(v, hasFocus)
                }
                setOnClickListener { handleMenuAction(item.second) }
                setOnKeyListener { _, keyCode, event ->
                    if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                    when (keyCode) {
                        KeyEvent.KEYCODE_DPAD_DOWN -> {
                            focusCard(0, lastFocusedColumn.coerceAtLeast(0))
                            true
                        }
                        KeyEvent.KEYCODE_DPAD_LEFT -> {
                            topMenu.getChildAt((index - 1).coerceAtLeast(0))?.requestFocus(); true
                        }
                        KeyEvent.KEYCODE_DPAD_RIGHT -> {
                            topMenu.getChildAt((index + 1).coerceAtMost(topMenu.childCount - 1))?.requestFocus(); true
                        }
                        else -> false
                    }
                }
            }
            topMenu.addView(tab, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT).apply {
                leftMargin = dp(4)
                rightMargin = dp(4)
            })
        }
    }

    private fun menuLabelsForStyle(style: Int): List<Pair<String, String>> = when (style.coerceIn(0, 5)) {
        1 -> listOf("◆ Home" to "home", "▶ Live TV" to "live", "▣ Movies" to "movies", "▤ Shows" to "shows", "⚙ Settings" to "settings", "⌕" to "search")
        2 -> listOf("⌂" to "home", "▶" to "live", "▣" to "movies", "▤" to "shows", "⚙" to "settings", "⌕" to "search")
        3 -> listOf("HOME" to "home", "LIVE" to "live", "MOVIES" to "movies", "SHOWS" to "shows", "SETTINGS" to "settings", "SEARCH" to "search")
        4 -> listOf("Home" to "home", "Live TV" to "live", "Movies" to "movies", "Shows" to "shows", "Settings" to "settings", "Search" to "search")
        5 -> listOf("⌂ Home" to "home", "◉ Live" to "live", "▰ Movies" to "movies", "▱ Shows" to "shows", "⚙ Settings" to "settings", "⌕ Search" to "search")
        else -> listOf("Home" to "home", "Live TV" to "live", "Movies" to "movies", "Shows" to "shows", "Settings" to "settings", "⌕" to "search")
    }

    private fun applyMenuTheme() {
        val theme = config.topMenuThemeStyle.coerceIn(0, 7)
        val bg: GradientDrawable? = when (theme) {
            0 -> null // true no-glass/no-pill mode
            1 -> rounded(0x00000000, 0, 0x00000000, 0) // flat transparent
            2 -> rounded(0x66000000, 24, 0x33FFFFFF, 1)
            3 -> rounded(0xCC06080F.toInt(), 18, 0xFFFFD84A.toInt(), 1)
            4 -> rounded(0xAA061A2A.toInt(), 34, 0x774DFFB8, 1)
            5 -> rounded(0xE60A0A10.toInt(), 8, 0x88FFFFFF.toInt(), 1)
            6 -> rounded(0x99111A2A.toInt(), 26, 0xFF76E4FF.toInt(), 1)
            else -> rounded(0xDD050507.toInt(), 30, 0x88B46CFF.toInt(), 2)
        }
        topMenu.background = bg
        topMenu.elevation = if (theme == 0 || theme == 1) 0f else dp(12).toFloat()
        topMenu.setPadding(if (theme <= 1) 0 else dp(12), 0, if (theme <= 1) 0 else dp(12), 0)
        Log.i(TAG, "TOP_MENU_THEME_VISIBLE_APPLY: theme=$theme noGlass=${theme == 0 || theme == 1}")
    }

    private fun menuItemBg(focused: Boolean): GradientDrawable {
        val theme = config.topMenuThemeStyle.coerceIn(0, 7)
        if (!focused) return rounded(Color.TRANSPARENT, 18, Color.TRANSPARENT, 0)
        return when (theme) {
            0, 1 -> rounded(Color.TRANSPARENT, 0, Color.TRANSPARENT, 0)
            3 -> rounded(0x11FFFFFF, 14, 0x88BFEFFF.toInt(), 1)
            4 -> rounded(0x224DFFB8, 22, 0xFF4DFFB8.toInt(), 2)
            6 -> rounded(0x2276E4FF, 22, 0xFF76E4FF.toInt(), 2)
            else -> rounded(0x22FFFFFF, 18, 0x99FFFFFF.toInt(), 1)
        }
    }

    private fun animateMenuFocus(view: View, focused: Boolean) {
        view.animate().cancel()
        val style = config.topMenuAnimationStyle.coerceIn(0, 4)
        if (!focused) {
            view.animate().scaleX(1f).scaleY(1f).translationY(0f).alpha(1f).setDuration(100).start()
            return
        }
        when (style) {
            0 -> view.scaleX = 1.06f
            1 -> view.animate().scaleX(1.08f).scaleY(1.08f).translationY(-dp(2).toFloat()).setDuration(120).start()
            2 -> view.animate().scaleX(1.16f).scaleY(1.16f).translationY(-dp(4).toFloat()).setDuration(90).withEndAction {
                view.animate().scaleX(1.09f).scaleY(1.09f).setDuration(110).start()
            }.start()
            3 -> view.animate().alpha(0.72f).setDuration(70).withEndAction { view.animate().alpha(1f).scaleX(1.1f).scaleY(1.1f).setDuration(120).start() }.start()
            else -> view.animate().scaleX(1.05f).scaleY(1.05f).translationY(dp(3).toFloat()).setDuration(110).start()
        }
    }

    private fun handleMenuAction(action: String) {
        when (action) {
            "live" -> startActivity(Intent(this, LiveTvActivity::class.java))
            "settings" -> startActivity(Intent(this, SettingsActivity::class.java))
            "search" -> startActivity(Intent(this, SearchActivity::class.java))
            "movies" -> startActivity(Intent(this, BrowseSectionActivity::class.java).putExtra("section", "movies"))
            "shows" -> startActivity(Intent(this, BrowseSectionActivity::class.java).putExtra("section", "shows"))
            else -> focusCard(0, 0)
        }
    }

    private fun setRows(rows: List<HomeRow>) {
        currentRows = rows.filter { it.items.isNotEmpty() }
        rowRecyclerByIndex.clear()
        stableRowByIndex.clear()
        stableScrollerByIndex.clear()
        stableCardByKey.clear()
        rowsRecycler.adapter = null
        rowsRecycler.visibility = View.GONE
        stableRowsScroll.visibility = View.VISIBLE
        lastFocusedRow = lastFocusedRow.coerceIn(0, currentRows.lastIndex.coerceAtLeast(0))
        lastFocusedColumn = 0
        renderNewAppViewportRows()
        currentRows.firstOrNull()?.items?.firstOrNull()?.let { applyHeroNow(it) }
        stableRowsScroll.postDelayed({ focusCard(lastFocusedRow, lastFocusedColumn) }, 90)
        Log.i(TAG, "ROW_ENGINE_V9_RENDER: rows=${currentRows.size} activeRowOnly=true itemLimit=none donorNewAppCards=true")
    }

    private fun renderStableRows() {
        renderNewAppViewportRows()
    }

    private fun renderNewAppViewportRows() {
        if (currentRows.isEmpty()) return
        stableRowsColumn.removeAllViews()
        stableRowByIndex.clear()
        stableScrollerByIndex.clear()
        stableCardByKey.clear()

        val rowIndex = lastFocusedRow.coerceIn(0, currentRows.lastIndex)
        val rowData = currentRows[rowIndex]
        val safeCol = lastFocusedColumn.coerceIn(0, rowData.items.lastIndex)
        lastFocusedRow = rowIndex
        lastFocusedColumn = safeCol

        val title = TextView(this).apply {
            visibility = if (config.rowTextVisible == 1) View.VISIBLE else View.GONE
            text = rowData.title
            textSize = 21f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(8), 0, 0, dp(8))
        }
        stableRowsColumn.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, if (config.rowTextVisible == 1) dp(34) else 0))

        val lane = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            clipToPadding = false
            setPadding(dp(8), dp(6), dp(320), dp(18))
        }
        val scroller = HorizontalScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            isHorizontalScrollBarEnabled = false
            isFocusable = false
            clipChildren = false
            clipToPadding = false
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
            addView(lane, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        rowData.items.forEachIndexed { column, item ->
            val card = createNewAppViewportCard(rowIndex, column, item)
            lane.addView(card)
            stableCardByKey["$rowIndex:$column"] = card
        }
        stableRowByIndex[rowIndex] = lane
        stableScrollerByIndex[rowIndex] = scroller
        stableRowsColumn.addView(scroller, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(config.cardHeightDp.coerceIn(110, 260) + 58)))
        Log.i(TAG, "ROW_ENGINE_V9_ACTIVE_ROW_BIND: row=$rowIndex title=${rowData.title} cards=${rowData.items.size} activeRowOnly=true")
    }

    private fun createNewAppViewportCard(rowIndex: Int, column: Int, item: TitleCard): FrameLayout {
        val w = dp(config.cardWidthDp.coerceIn(190, 420))
        val h = dp(config.cardHeightDp.coerceIn(110, 260))
        val frame = FrameLayout(this).apply {
            id = View.generateViewId()
            layoutParams = LinearLayout.LayoutParams(w, h).apply { rightMargin = dp(config.cardSpacingDp.coerceIn(0, 40)) }
            isFocusable = true
            isClickable = true
            clipToOutline = true
            outlineProvider = roundOutline(config.cornerRadiusDp)
            background = rounded(if (config.glassCardMode == 1) 0xAA121A26.toInt() else 0xFF0B0F18.toInt(), config.cornerRadiusDp, 0x22FFFFFF, 1)
        }
        val art = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(0xFF05070D.toInt()) }
        val logoGlow = View(this).apply { visibility = View.INVISIBLE; background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0xAA000000.toInt(), 0x00000000)) }
        val logo = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; adjustViewBounds = true; visibility = View.INVISIBLE; alpha = 0.98f }
        val label = TextView(this).apply {
            gravity = Gravity.CENTER
            text = item.title
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(14), 0, dp(14), dp(12))
            maxLines = 2
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x33000000, 0xBB000000.toInt()))
        }
        frame.addView(art, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.addView(logoGlow, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp((config.cardHeightDp * 0.46f).toInt()), Gravity.CENTER))
        frame.addView(logo, FrameLayout.LayoutParams(dp((config.cardWidthDp * 0.55f).toInt()), dp((config.cardHeightDp * 0.36f).toInt()), Gravity.CENTER))
        frame.addView(label, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        loadImage(art, item.backdropUrl ?: item.posterUrl, item.backgroundRes)
        val displayLogoUrl = resolveDisplayLogoUrl(item)
        if (config.cardLogoVisible == 1 && !displayLogoUrl.isNullOrBlank()) {
            Glide.with(this).load(upgradeArtworkUrl(displayLogoUrl))
                .override(dp((config.cardWidthDp * 0.55f).toInt()), dp((config.cardHeightDp * 0.36f).toInt()))
                .apply(RequestOptions().format(DecodeFormat.PREFER_RGB_565).diskCacheStrategy(DiskCacheStrategy.ALL).dontTransform())
                .into(logo)
            logo.visibility = View.VISIBLE
            logoGlow.visibility = View.VISIBLE
            label.visibility = View.GONE
        }
        frame.setOnClickListener { launchDetails(item) }
        frame.setOnFocusChangeListener { v, focused ->
            if (focused) {
                lastFocusedRow = rowIndex
                lastFocusedColumn = column
                updateHero(item)
                stableScrollerByIndex[rowIndex]?.smoothScrollTo((v.left - dp(32)).coerceAtLeast(0), 0)
            }
            applyCardFocus(v, focused)
        }
        frame.setOnKeyListener { _, keyCode, event ->
            if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_UP -> { if (rowIndex == 0) focusTopMenu() else focusCard(rowIndex - 1, 0); true }
                KeyEvent.KEYCODE_DPAD_DOWN -> { focusCard((rowIndex + 1).coerceAtMost(currentRows.lastIndex), 0); true }
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    if (column > 0) {
                        focusCard(rowIndex, column - 1)
                        true
                    } else {
                        false
                    }
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    if (column < currentRows[rowIndex].items.lastIndex) {
                        focusCard(rowIndex, column + 1)
                        true
                    } else {
                        false
                    }
                }
                else -> false
            }
        }
        return frame
    }

    private fun loadArtworkRows() {
        val mode = config.artworkSourceMode.coerceIn(0, 3)
        Log.i(TAG, "ARTWORK_SOURCE_MODE: ${artworkModeName(mode)}")
        io.execute {
            val directRows = if (mode in 0..2) {
                runCatching { artworkProvider.loadDirectRows(96) }.getOrDefault(emptyList())
            } else emptyList()

            val backendRows = emptyList<com.channelsdebrid.tv.data.BackendHomeLoader.BackendRow>()

            val mappedDirect = directRows.map { row ->
                HomeRow(row.title, row.items.mapIndexed { index, item ->
                    TitleCard(
                        title = item.title,
                        meta = item.meta.ifBlank { item.source },
                        desc = item.overview.ifBlank { "Direct metadata artwork item." },
                        backgroundRes = fallbackDrawable(index),
                        posterUrl = item.posterUrl,
                        backdropUrl = item.backdropUrl ?: item.posterUrl,
                        logoUrl = item.logoUrl,
                        mediaType = item.type.ifBlank { "movie" },
                        externalId = item.externalId.ifBlank { item.title },
                        source = item.source.ifBlank { "Direct" }
                    )
                })
            }

            val mappedBackend = backendRows.map { row ->
                HomeRow(row.title, row.items.mapIndexed { index, item ->
                    TitleCard(
                        title = item.title,
                        meta = listOfNotNull(item.year.takeIf { it > 0 }?.toString(), item.genre.takeIf { it.isNotBlank() }, item.source.takeIf { it.isNotBlank() }).joinToString("  •  "),
                        desc = item.overview.ifBlank { "Backend catalog item" },
                        backgroundRes = fallbackDrawable(index),
                        posterUrl = item.poster,
                        backdropUrl = item.backdrop ?: item.poster,
                        logoUrl = item.logo,
                        mediaType = item.type.ifBlank { "movie" },
                        externalId = item.imdbId ?: item.id,
                        year = item.year,
                        source = item.source.ifBlank { "Backend" }
                    )
                })
            }

            val stremioRows = if (repository.loadCatalogs().stremioCatalogRowsEnabled) {
                repository.loadStremioAddons()
                    .filter { it.enabled && it.manifestUrl.isNotBlank() }
                    .flatMap { addon ->
                        runCatching { stremioLoader.loadRows(addon.name.ifBlank { "Stremio" }, addon.manifestUrl, 96) }
                            .getOrDefault(emptyList())
                            .map { row ->
                                HomeRow("${addon.name.ifBlank { "Stremio" }} • ${row.title}", row.items.mapIndexed { index, item ->
                                    TitleCard(
                                        title = item.title,
                                        meta = item.meta.ifBlank { addon.name },
                                        desc = item.desc.ifBlank { "Stremio catalog item." },
                                        backgroundRes = fallbackDrawable(index),
                                        posterUrl = item.posterUrl,
                                        backdropUrl = item.backdropUrl ?: item.posterUrl,
                                        logoUrl = item.logoUrl,
                                        mediaType = item.mediaType ?: "movie",
                                        externalId = item.externalId ?: item.title,
                                        source = addon.name.ifBlank { "Stremio" }
                                    )
                                })
                            }
                    }
            } else emptyList()
            val finalRows = when (mode) {
                0 -> mappedDirect + stremioRows
                1 -> mappedDirect + stremioRows
                2 -> mappedDirect + stremioRows
                else -> stremioRows
            }

            main.post {
                if (!isFinishing && !isDestroyed && finalRows.isNotEmpty()) {
                    Log.i(TAG, "ARTWORK_ROWS_APPLIED_INCREMENTAL: mode=${artworkModeName(mode)} rows=${finalRows.size} backendRequired=false memorySafe=true")
                    setRows(finalRows)
                } else {
                    Log.i(TAG, "ARTWORK_ROWS_APPLIED: mode=${artworkModeName(mode)} rows=0 fallback=local")
                }
            }
        }
    }

    private fun artworkModeName(mode: Int): String = when (mode.coerceIn(0, 3)) {
        0 -> "Direct metadata"
        1 -> "Direct metadata + local cache"
        2 -> "Direct metadata"
        else -> "Offline/local fallback"
    }

    private inner class HomeRowsAdapter(private val rows: List<HomeRow>) : RecyclerView.Adapter<HomeRowsAdapter.RowHolder>() {
        init { setHasStableIds(true) }
        override fun getItemId(position: Int): Long = rows[position].title.hashCode().toLong()
        inner class RowHolder(val box: LinearLayout, val title: TextView, val row: RecyclerView) : RecyclerView.ViewHolder(box)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowHolder {
            val box = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                clipChildren = false
                clipToPadding = false
                setPadding(0, 0, 0, dp(16))
            }
            val title = TextView(parent.context).apply {
                setTextColor(Color.WHITE)
                textSize = 21f
                typeface = Typeface.DEFAULT_BOLD
                setPadding(0, 0, 0, dp(8))
            }
            val row = RecyclerView(parent.context).apply {
                layoutManager = LinearLayoutManager(parent.context, RecyclerView.HORIZONTAL, false)
                itemAnimator = null
                overScrollMode = View.OVER_SCROLL_NEVER
                clipChildren = false
                clipToPadding = false
                descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
                setHasFixedSize(true)
                isFocusable = false
            }
            box.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, if (config.rowTextVisible == 1) dp(34) else 0))
            box.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(config.cardHeightDp.coerceIn(110, 260) + 38)))
            return RowHolder(box, title, row)
        }
        override fun getItemCount(): Int = rows.size
        override fun onBindViewHolder(holder: RowHolder, position: Int) {
            val rowData = rows[position]
            holder.title.visibility = if (config.rowTextVisible == 1) View.VISIBLE else View.GONE
            holder.title.text = rowData.title
            holder.row.adapter = CardAdapter(position, rowData.items)
            rowRecyclerByIndex[position] = holder.row
            Log.i(TAG, "ROW_ENGINE_BIND_ROW: index=$position title=${rowData.title} oldAdapter=false")
        }
    }

    private inner class CardAdapter(private val rowIndex: Int, private val items: List<TitleCard>) : RecyclerView.Adapter<CardAdapter.CardHolder>() {
        init { setHasStableIds(true) }
        override fun getItemId(position: Int): Long = (items[position].externalId ?: items[position].title).hashCode().toLong()
        inner class CardHolder(
            val frame: FrameLayout,
            val art: ImageView,
            val logoGlow: View,
            val logo: ImageView,
            val label: TextView
        ) : RecyclerView.ViewHolder(frame)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardHolder {
            val w = dp(config.cardWidthDp.coerceIn(190, 420))
            val h = dp(config.cardHeightDp.coerceIn(110, 260))
            val frame = FrameLayout(parent.context).apply {
                id = View.generateViewId()
                layoutParams = RecyclerView.LayoutParams(w, h).apply { rightMargin = dp(config.cardSpacingDp.coerceIn(0, 40)) }
                isFocusable = true
                isClickable = true
                clipToOutline = true
                outlineProvider = roundOutline(config.cornerRadiusDp)
                background = rounded(if (config.glassCardMode == 1) 0xAA121A26.toInt() else 0xFF0B0F18.toInt(), config.cornerRadiusDp, 0x22FFFFFF, 1)
            }
            val art = ImageView(parent.context).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(0xFF05070D.toInt())
            }
            val logoGlow = View(parent.context).apply {
                visibility = View.INVISIBLE
                background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0xAA000000.toInt(), 0x00000000))
            }
            val logo = ImageView(parent.context).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                adjustViewBounds = true
                visibility = View.INVISIBLE
                alpha = 0.98f
                setLayerType(View.LAYER_TYPE_HARDWARE, null)
            }
            val label = TextView(parent.context).apply {
                gravity = Gravity.BOTTOM or Gravity.START
                textSize = 16f
                setTextColor(Color.WHITE)
                typeface = homeLayoutTypeface(config.contentFontIndex)
                setPadding(dp(14), 0, dp(14), dp(12))
                background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0x99000000.toInt()))
                maxLines = 2
            }
            frame.addView(art, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            frame.addView(logoGlow, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp((config.cardHeightDp * 0.46f).toInt()), Gravity.CENTER))
            frame.addView(logo, FrameLayout.LayoutParams(dp((config.cardWidthDp * 0.55f).toInt()), dp((config.cardHeightDp * 0.36f).toInt()), Gravity.CENTER))
            frame.addView(label, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            return CardHolder(frame, art, logoGlow, logo, label)
        }
        override fun getItemCount(): Int = items.size
        override fun onBindViewHolder(holder: CardHolder, position: Int) {
            val item = items[position]
            holder.label.text = item.title
            loadImage(holder.art, item.backdropUrl ?: item.posterUrl, item.backgroundRes)
            val displayLogoUrl = resolveDisplayLogoUrl(item)
            if (config.cardLogoVisible == 1 && !displayLogoUrl.isNullOrBlank()) {
                Glide.with(this@MainActivity).load(upgradeArtworkUrl(displayLogoUrl))
                    .override(dp((config.cardWidthDp * 0.55f).toInt()), dp((config.cardHeightDp * 0.36f).toInt()))
                    .apply(RequestOptions()
                        .format(DecodeFormat.PREFER_RGB_565)
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .dontTransform())
                    .into(holder.logo)
                holder.logo.visibility = View.VISIBLE
                holder.logoGlow.visibility = View.VISIBLE
                holder.label.gravity = Gravity.BOTTOM or Gravity.START
                holder.label.textSize = 16f
                holder.label.typeface = homeLayoutTypeface(config.contentFontIndex)
                holder.label.visibility = View.GONE
            } else {
                holder.logo.visibility = View.INVISIBLE
                holder.logoGlow.visibility = View.INVISIBLE
                holder.label.visibility = View.VISIBLE
                holder.label.gravity = Gravity.CENTER
                holder.label.textSize = 18f
                holder.label.typeface = Typeface.DEFAULT_BOLD
                holder.label.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x33000000, 0xBB000000.toInt()))
            }
            // Per-card logging removed for memory-safe recycled rows.
            holder.frame.setOnClickListener { launchDetails(item) }
            holder.frame.setOnFocusChangeListener { v, focused ->
                if (focused) {
                    lastFocusedRow = rowIndex
                    lastFocusedColumn = position
                    updateHero(item)
                }
                applyCardFocus(v, focused)
            }
            holder.frame.setOnKeyListener { _, keyCode, event ->
                if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP -> { if (rowIndex == 0) focusTopMenu() else focusCard(rowIndex - 1, 0); true }
                    KeyEvent.KEYCODE_DPAD_DOWN -> { focusCard((rowIndex + 1).coerceAtMost(currentRows.lastIndex), 0); true }
                    else -> false
                }
            }
        }
    }

    private fun focusTopMenu() {
        topMenu.getChildAt(0)?.requestFocus()
    }

    private fun focusCard(rowIndex: Int, column: Int) {
        if (currentRows.isEmpty()) return
        val safeRow = rowIndex.coerceIn(0, currentRows.lastIndex)
        val safeCol = column.coerceIn(0, currentRows[safeRow].items.lastIndex)
        val viewportKey = "$safeRow:$safeCol"
        lastFocusedRow = safeRow
        lastFocusedColumn = safeCol
        Log.i(TAG, "FOCUS_GRAPH_V9_MOVE: row=$safeRow col=$safeCol activeRowOnly=true")
        stableRowsScroll.post {
            if (!stableCardByKey.containsKey(viewportKey)) {
                renderNewAppViewportRows()
            }
            val target = stableCardByKey[viewportKey]
            if (target == null) {
                stableRowsScroll.postDelayed({ focusCard(safeRow, safeCol) }, 32)
                return@post
            }
            val rowTop = stableScrollerByIndex[safeRow]?.top ?: 0
            stableRowsScroll.smoothScrollTo(0, (rowTop - dp(18)).coerceAtLeast(0))
            target.requestFocus()
        }
    }

    private fun formatHeroRatings(item: TitleCard): String {
        val raw = item.meta.ifBlank { "Featured • ${item.source}" }
        fun findRating(label: String): String {
            val rx = Regex(label + "\\s*[:★⭐]?\\s*([0-9]+(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE)
            return rx.find(raw)?.groupValues?.getOrNull(1).orEmpty()
        }
        val imdb = findRating("IMDb")
        val tmdb = findRating("TMDB").ifBlank {
            Regex("★\\s*([0-9]+(?:\\.[0-9]+)?)").find(raw)?.groupValues?.getOrNull(1).orEmpty()
        }
        val cleanParts = raw.split("•").map { it.trim() }
            .filter { it.isNotBlank() && !it.contains("IMDb", true) && !it.contains("TMDB", true) && !it.startsWith("★") }
        val ratingParts = mutableListOf<String>()
        if (imdb.isNotBlank()) ratingParts += "IMDb ★ $imdb"
        if (tmdb.isNotBlank()) ratingParts += "TMDB ★ $tmdb"
        if (ratingParts.isEmpty()) return raw
        return (cleanParts + ratingParts).joinToString("   •   ")
    }


    private fun formatHeroMetaWithoutRatings(item: TitleCard): String {
        val raw = item.meta.ifBlank { "Featured • ${item.source}" }
        return raw.split("•")
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.contains("IMDb", true) && !it.contains("TMDB", true) && !it.startsWith("★") }
            .joinToString("   •   ")
            .ifBlank { item.source }
    }
    private fun updateHero(item: TitleCard) {
        val identity = listOf(item.externalId, item.title, item.backdropUrl, item.posterUrl).joinToString("|")
        if (identity == lastHeroIdentityKey) return
        pendingHeroItem = item
        main.removeCallbacks(heroUpdateRunnable)
        // V3 row rewrite rule: never rebind hero while DPAD movement is still settling.
        // This prevents the visible row/card jump caused by image/logo layout work racing focus.
        main.postDelayed(heroUpdateRunnable, 220L)
    }

    private fun applyHeroNow(item: TitleCard) {
        val identity = listOf(item.externalId, item.title, item.backdropUrl, item.posterUrl).joinToString("|")
        if (identity == lastHeroIdentityKey) return
        lastHeroIdentityKey = identity
        heroText.animate().cancel()
        heroTitle.text = item.title.uppercase()
        heroMeta.text = formatHeroMetaWithoutRatings(item)
        bindHeroRatingBadges(item)
        heroDesc.text = item.desc.ifBlank { "Select to open details." }
        val backdropKey = item.backdropUrl ?: item.posterUrl ?: "fallback:${item.backgroundRes}"
        if (backdropKey != lastHeroBackdropKey) {
            lastHeroBackdropKey = backdropKey
            loadHeroBackdropImage(heroBackdrop, item.backdropUrl ?: item.posterUrl, item.backgroundRes)
        }
        applyHeroQualityMode()
        applyHeroLogo(item)
        applyHeroExtraArt(item)
    }

    private fun applyHeroQualityMode() {
        val mode = config.heroQualityMode.coerceIn(0, 1)
        heroBackdrop.alpha = if (mode == 1) 0.96f else 0.88f
        heroBackdrop.scaleType = ImageView.ScaleType.CENTER_CROP
        Log.i(TAG, "HERO_QUALITY_MODE_APPLY: ${if (mode == 1) "4K" else "1080p"} uiResolution=${if (config.uiResolutionMode == 1) "4K" else "1080p"}")
    }


    private fun heroLogoParams(): FrameLayout.LayoutParams {
        return FrameLayout.LayoutParams(dp(config.heroLogoWidthDp), dp(config.heroLogoHeightDp), Gravity.TOP or Gravity.START).apply {
            leftMargin = dp(34 + config.heroTextLeftDp)
            topMargin = dp(78 + config.heroTextTopDp)
        }
    }

    private fun applyHeroLogo(item: TitleCard) {
        if (heroLogo.parent == null) root.addView(heroLogo, heroLogoParams())
        heroLogo.layoutParams = heroLogoParams()
        val displayLogoUrl = resolveDisplayLogoUrl(item)
        if (config.heroLogoVisible != 1 || displayLogoUrl.isNullOrBlank()) {
            heroLogo.visibility = View.INVISIBLE
            heroTitle.visibility = View.VISIBLE
            lastHeroLogoKey = ""
            Log.i(TAG, "HERO_LOGO_ARTWORK_APPLY: hidden fallbackTitle=true")
            return
        }
        if (displayLogoUrl != lastHeroLogoKey) {
            lastHeroLogoKey = displayLogoUrl
            Glide.with(this).load(upgradeArtworkUrl(displayLogoUrl))
                .apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).diskCacheStrategy(DiskCacheStrategy.ALL).dontTransform())
                .into(heroLogo)
        }
        heroLogo.visibility = View.VISIBLE
        heroTitle.visibility = View.INVISIBLE
        Log.i(TAG, "HERO_LOGO_ARTWORK_APPLY: visible cached=${displayLogoUrl == lastHeroLogoKey} fallback=${item.logoUrl.isNullOrBlank()}")
    }

    private fun applyHeroExtraArt(item: TitleCard) {
        if (heroExtraArt.parent == null) root.addView(heroExtraArt, extraArtHeroParams())
        heroExtraArt.layoutParams = extraArtHeroParams()
        val sourceMode = config.extraArtworkSourceMode.coerceIn(0, 4)
        val url = when (sourceMode) {
            1 -> item.logoUrl ?: item.posterUrl ?: item.backdropUrl
            2 -> item.backdropUrl ?: item.posterUrl ?: item.logoUrl
            3 -> item.posterUrl ?: item.logoUrl ?: item.backdropUrl
            4 -> item.logoUrl ?: item.backdropUrl ?: item.posterUrl
            else -> item.posterUrl ?: item.logoUrl ?: item.backdropUrl
        }
        val imageKey = url ?: "fallback:${item.backgroundRes}"
        if (imageKey != lastHeroExtraKey) {
            lastHeroExtraKey = imageKey
            if (url.isNullOrBlank()) {
                heroExtraArt.setImageDrawable(ContextCompat.getDrawable(this, item.backgroundRes))
            } else {
                Glide.with(this).load(upgradeArtworkUrl(url))
                    .override(com.bumptech.glide.request.target.Target.SIZE_ORIGINAL)
                    .apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).diskCacheStrategy(DiskCacheStrategy.ALL))
                    .into(heroExtraArt)
            }
        }
        heroExtraArt.visibility = View.VISIBLE
        applyExtraArtworkTilt()
        Log.i(TAG, "HERO_EXTRA_ART_LAYER_APPLY: placement=${config.extraArtworkPlacement} sourceMode=$sourceMode tiltEnabled=${config.extraArtwork3dEnabled} depth=${config.extraArtworkDepthPercent} cached=${imageKey == lastHeroExtraKey}")
    }

    private fun applyExtraArtworkTilt() {
        val depth = config.extraArtworkDepthPercent.coerceIn(0, 100)
        heroExtraArt.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        heroExtraArt.post {
            val density = resources.displayMetrics.density
            heroExtraArt.cameraDistance = density * 36000f
            heroExtraArt.pivotX = heroExtraArt.width / 2f
            heroExtraArt.pivotY = heroExtraArt.height / 2f
            if (config.extraArtwork3dEnabled == 1) {
                val normalized = depth / 100f
                heroExtraArt.rotationY = 0f
                heroExtraArt.rotationX = -(1.0f + normalized * 5.0f)
                heroExtraArt.rotation = 0f
                heroExtraArt.translationX = 0f
                heroExtraArt.translationY = 0f
                heroExtraArt.translationZ = 0f
                heroExtraArt.scaleX = 1.0f
                heroExtraArt.scaleY = 1.0f
                heroExtraArt.alpha = 1f
            } else {
                heroExtraArt.rotationY = 0f
                heroExtraArt.rotationX = 0f
                heroExtraArt.rotation = 0f
                heroExtraArt.translationX = 0f
                heroExtraArt.translationY = 0f
                heroExtraArt.translationZ = 0f
                heroExtraArt.scaleX = 1f
                heroExtraArt.scaleY = 1f
                heroExtraArt.alpha = 1f
            }
            heroExtraArt.invalidate()
        }
    }

    private fun extraArtHeroParams(): FrameLayout.LayoutParams {
        val w = dp(config.extraArtworkWidthDp)
        val h = dp(config.extraArtworkHeightDp)
        val placement = config.extraArtworkPlacement.coerceIn(0, 3)
        val gravity = when (placement) {
            1 -> Gravity.TOP or Gravity.START
            2 -> Gravity.TOP or Gravity.END
            3 -> Gravity.CENTER
            else -> Gravity.TOP or Gravity.END
        }
        return FrameLayout.LayoutParams(w, h, gravity).apply {
            topMargin = if (placement == 3) dp(config.extraArtworkOffsetYDp) else dp(150 + config.extraArtworkOffsetYDp)
            leftMargin = dp(52 + config.extraArtworkOffsetXDp)
            rightMargin = dp(86 - config.extraArtworkOffsetXDp)
        }
    }

    private fun launchDetails(item: TitleCard) {
        startActivity(Intent(this, MediaDetailsActivity::class.java).apply {
            putExtra(MediaDetailsActivity.EXTRA_TITLE, item.title)
            putExtra(MediaDetailsActivity.EXTRA_META_LINE, item.meta)
            putExtra(MediaDetailsActivity.EXTRA_DESC, item.desc)
            putExtra(MediaDetailsActivity.EXTRA_MEDIA_TYPE, item.mediaType)
            putExtra(MediaDetailsActivity.EXTRA_EXTERNAL_ID, item.externalId ?: item.title)
            putExtra(MediaDetailsActivity.EXTRA_POSTER_URL, item.posterUrl ?: "")
            putExtra(MediaDetailsActivity.EXTRA_BACKDROP_URL, item.backdropUrl ?: item.posterUrl ?: "")
            putExtra(MediaDetailsActivity.EXTRA_LOGO_URL, item.logoUrl ?: "")
        })
    }

    private fun applyCardFocus(view: View, focused: Boolean) {
        view.animate().cancel()
        val configuredScale = config.focusedScalePercent.coerceIn(100, 120) / 100f
        // v2.8.16.2: restore donor/new-app style card focus without changing row layout.
        // The card visually grows above neighboring cards using translationZ/elevation; layout size is unchanged.
        val scale = if (focused) configuredScale.coerceAtLeast(1.08f) else 1f
        val lift = if (focused) dp(config.cardLiftDp.coerceIn(0, 28).coerceAtLeast(10)).toFloat() else 0f
        val glowAlpha = ((config.glowStrengthPercent.coerceIn(0, 100) / 100f) * 255).toInt().coerceIn(0, 255)
        val baseRing = homeLayoutRingColor(config.focusRingColorIndex)
        val ringColor = if (focused && config.focusRingEnabled == 1) (baseRing and 0x00FFFFFF) or (glowAlpha shl 24) else 0x22FFFFFF
        val spreadExtra = if (focused) (config.focusGlowSpreadPercent.coerceIn(0, 100) / 25) else 0
        val ringWidth = if (focused && config.focusRingEnabled == 1) (config.focusRingThicknessDp.coerceIn(0, 8) + spreadExtra).coerceIn(0, 12) else 1
        view.background = rounded(
            if (focused) 0xF0182235.toInt() else if (config.glassCardMode == 1) 0xAA121A26.toInt() else 0xFF0B0F18.toInt(),
            config.cornerRadiusDp,
            ringColor,
            ringWidth
        )
        val glowElevation = if (focused) dp(6 + (config.focusGlowSpreadPercent.coerceIn(0, 100) * 0.22f).toInt()).toFloat() else dp(2).toFloat()
        view.elevation = glowElevation
        view.animate()
            .scaleX(scale)
            .scaleY(scale)
            .translationZ(lift)
            .setDuration(if (focused) 135 else 105)
            .start()
    }

    private fun loadHeroBackdropImage(target: ImageView, url: String?, fallbackRes: Int) {
        if (url.isNullOrBlank()) {
            target.setImageResource(fallbackRes)
        } else {
            val width = resources.displayMetrics.widthPixels.coerceAtLeast(1920)
            val height = resources.displayMetrics.heightPixels.coerceAtLeast(1080)
            Glide.with(this).load(upgradeArtworkUrl(url))
                .placeholder(fallbackRes)
                .error(fallbackRes)
                .override(width, height)
                .apply(RequestOptions()
                    .format(DecodeFormat.PREFER_ARGB_8888)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .dontTransform())
                .into(target)
        }
    }

    private fun loadImage(target: ImageView, url: String?, fallbackRes: Int) {
        if (url.isNullOrBlank()) {
            target.setImageResource(fallbackRes)
        } else {
            Glide.with(this).load(upgradeArtworkUrl(url))
                .placeholder(fallbackRes)
                .error(fallbackRes)
                .override(dp(config.cardWidthDp.coerceIn(190, 420)), dp(config.cardHeightDp.coerceIn(110, 260)))
                .apply(RequestOptions()
                    .format(DecodeFormat.PREFER_RGB_565)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .dontTransform())
                .into(target)
        }
    }


    private fun resolveDisplayLogoUrl(item: TitleCard): String? {
        val direct = item.logoUrl?.trim().orEmpty()
        if (direct.isNotBlank()) return direct
        val id = item.externalId?.trim().orEmpty()
        if (id.startsWith("tt") && id.length >= 5) {
            val type = if (item.mediaType.equals("series", true)) "series" else "movie"
            val metahub = "https://images.metahub.space/logo/large/$id/img"
            Log.i(TAG, "ROW_HERO_LOGO_FALLBACK: title=${item.title.take(40)} type=$type imdb=$id source=${item.source}")
            return metahub
        }
        return null
    }

    private fun upgradeArtworkUrl(url: String): String = BackendEndpoint.imageProxyUrl(url)

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int, strokeDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(dp(strokeDp).coerceAtLeast(0), strokeColor)
    }

    private fun roundOutline(radiusDp: Int): ViewOutlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, dp(radiusDp).toFloat())
        }
    }

    private fun fallbackDrawable(index: Int): Int = when (index % 9) {
        0 -> R.drawable.bg_shogun
        1 -> R.drawable.bg_batman
        2 -> R.drawable.bg_fallout
        3 -> R.drawable.bg_dune
        4 -> R.drawable.bg_halo
        5 -> R.drawable.bg_wonka
        6 -> R.drawable.bg_mayor
        7 -> R.drawable.bg_civilwar
        else -> R.drawable.bg_avatar
    }

    private fun defaultRows(): List<HomeRow> {
        val base = listOf(
            TitleCard("The Housemaid", "2025  •  Popular   IMDb 6.8", "A young woman enters a mansion of secrets, manipulation, and escalating psychological games.", R.drawable.bg_shogun, mediaType = "movie", externalId = "the-housemaid"),
            TitleCard("Michael", "2025  •  Music Drama", "A cinematic music-story spotlight with large landscape artwork.", R.drawable.bg_batman, mediaType = "movie", externalId = "michael"),
            TitleCard("Send Help", "2025  •  Thriller", "A bold poster-driven hero example for the rebuilt row engine.", R.drawable.bg_fallout, mediaType = "movie", externalId = "send-help"),
            TitleCard("Dune", "2024  •  Sci-Fi", "Expansive cinema artwork with clean DPAD navigation.", R.drawable.bg_dune, mediaType = "movie", externalId = "dune"),
            TitleCard("Halo", "Series  •  Action", "A series card using the same rebuilt card renderer.", R.drawable.bg_halo, mediaType = "series", externalId = "halo"),
            TitleCard("Wonka", "Movie  •  Family", "A bright colorful fallback card.", R.drawable.bg_wonka, mediaType = "movie", externalId = "wonka")
        )
        return listOf(
            HomeRow("Featured", base),
            HomeRow("Popular Movies", base.shuffled()),
            HomeRow("Popular Shows", base.reversed()),
            HomeRow("Recently Added", base.drop(1) + base.take(1)),
            HomeRow("Because You Watched", base.drop(2) + base.take(2))
        )
    }
}
