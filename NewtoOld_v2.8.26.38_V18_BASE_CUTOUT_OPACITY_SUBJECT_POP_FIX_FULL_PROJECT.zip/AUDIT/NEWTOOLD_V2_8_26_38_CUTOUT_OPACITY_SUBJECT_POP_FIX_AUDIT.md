# NewtoOld v2.8.26.38 Cutout Opacity Subject Pop Fix

Base: v2.8.26.37 / v18 clean path.

Changes:
- Fixed perceived opacity/flatness by bounding the raised hero plane to the subject zone instead of rendering it as a full-screen translucent sheet.
- Removed global glow/bloom remains unchanged.
- Added mild foreground-only contrast/saturation filter.
- Kept ghost rows visible and brought rows back above the bounded depth plane before metadata layers.
- Updated versionCode/versionName and DC_BUILD_MARKER.

Preserved: Live TV, backend compatibility, row scrolling/focus, focused logo placement, no old fullscreen hero backdrop renderer.
