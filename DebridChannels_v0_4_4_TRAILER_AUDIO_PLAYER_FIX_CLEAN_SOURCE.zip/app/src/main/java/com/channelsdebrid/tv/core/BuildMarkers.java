package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.4.4 TRAILER DEDICATED AUDIO PLAYER FIX";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.4.4_trailer_dedicated_audio_player_clean_base";
    private BuildMarkers() {}
}
