# v1.3.5 Dynamic Hero + Resume + Search Icon

Base: v1.3.4 live TV instant cache/IPTV sync fix package.

Included:
- Verified v1.3.4 instant Live TV cache code is still present in `LiveTvActivity` and backend `/live/bootstrap`.
- Replaced top-left Home icon with Search icon asset.
- Kept TV Shows in top menu and retained SearchActivity.
- Focused card default scale changed to 1.00 so the bounce/zoom-pop is neutral unless enabled.
- Kept IPTV sync/cache files from v1.3.4 as the package base.
