# Trailer backend patch

This build removes the in-app YouTube WebView embed that was causing YouTube error 152-4.

New flow:
1. Android TV app waits the existing autoplay delay.
2. App calls backend: `GET /trailers/resolve?title=...&year=...&prefer4k=true`.
3. Backend uses `yt-dlp` to resolve a fresh playable trailer stream.
4. App plays the returned DASH/direct stream with ExoPlayer.

Backend URL currently remains hardcoded in MainActivity as:
`http://192.168.100.55:8181`

Backend Dockerfile now installs `yt-dlp` and `ffmpeg`.
