# v1.4.3 Guide Focus State Fix

- Program blocks stay dark by default.
- The white Google TV-style pill only appears on the actively focused guide program.
- Moving focus immediately returns the previous program to dark.
- Clears stuck selected/activated states from rows and program cards.
- Keeps OK once for preview, OK twice for fullscreen behavior.
