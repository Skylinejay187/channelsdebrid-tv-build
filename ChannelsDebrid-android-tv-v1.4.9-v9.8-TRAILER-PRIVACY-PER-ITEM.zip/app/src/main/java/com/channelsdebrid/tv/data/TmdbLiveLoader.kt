package com.channelsdebrid.tv.data

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

class TmdbLiveLoader {

    private val logoCache = ConcurrentHashMap<String, String?>()
    private val externalIdCache = ConcurrentHashMap<String, Pair<String?, String?>>()
    private val heroArtCache = ConcurrentHashMap<String, ResolvedHeroArt?>()

    data class LiveCatalogItem(
        val title: String,
        val meta: String,
        val desc: String,
        val badge: String,
        val brand: String,
        val footer: String,
        val progress: Float,
        val posterUrl: String? = null,
        val backdropUrl: String? = null,
        val logoUrl: String? = null,
        val mediaType: String? = null,
        val tmdbId: Int = 0,
        val externalId: String? = null
    )

    data class LiveRow(
        val title: String,
        val subtitle: String,
        val items: List<LiveCatalogItem>
    )

    data class ResolvedHeroArt(
        val backdropUrl: String?,
        val logoUrl: String?
    )

    fun loadRows(apiKey: String, region: String, language: String, enabledKeys: List<String>, limit: Int = 24, fanartApiKey: String = "", fanartClientKey: String = ""): List<LiveRow> {
        if (apiKey.isBlank()) return emptyList()
        return enabledKeys.mapNotNull { key ->
            runCatching { loadRow(apiKey, region, language, key, limit, fanartApiKey, fanartClientKey) }.getOrNull()
        }
    }

    private fun loadRow(apiKey: String, region: String, language: String, key: String, limit: Int, fanartApiKey: String, fanartClientKey: String): LiveRow {
        val (title, subtitle, endpoint, type, brand) = when (key) {
            "trending_movies" -> Quint("Trending in Movies", "TMDB $region • live", "/trending/movie/week", "movie", "TMDB")
            "popular_movies" -> Quint("Popular Movies", "TMDB $region • live", "/movie/popular", "movie", "TMDB")
            "trending_shows" -> Quint("Trending in Shows", "$language • live", "/trending/tv/week", "tv", "tv")
            "popular_shows" -> Quint("Popular Shows", "$language • live", "/tv/popular", "tv", "tv")
            "platform_rows" -> Quint("Trending on Netflix", "Provider row • live", "/discover/movie?with_watch_providers=8&watch_region=${enc(region)}&sort_by=popularity.desc", "movie", "Netflix")
            "top_rated_movies" -> Quint("Top Rated Movies", "TMDB critics • live", "/movie/top_rated", "movie", "TMDB")
            else -> throw IllegalArgumentException("Unsupported catalog key: $key")
        }

        val url = buildUrl(apiKey, endpoint, language)
        val json = fetchJson(url)
        val results = json.optJSONArray("results") ?: throw IllegalStateException("Missing results")
        val items = mutableListOf<LiveCatalogItem>().apply {
            for (i in 0 until minOf(limit, results.length())) {
                val obj = results.optJSONObject(i) ?: continue
                val itemTitle = when (type) {
                    "movie" -> obj.optString("title")
                    else -> obj.optString("name")
                }.ifBlank { "Unknown" }
                val overview = obj.optString("overview").ifBlank { "Live TMDB catalog item." }
                val rating = obj.optDouble("vote_average", 0.0)
                val yearSource = when (type) {
                    "movie" -> obj.optString("release_date")
                    else -> obj.optString("first_air_date")
                }
                val year = yearSource.takeIf { it.length >= 4 }?.substring(0, 4).orEmpty()
                val footer = listOfNotNull(
                    year.takeIf { it.isNotBlank() },
                    if (rating > 0.0) "★ ${"%.1f".format(rating)}" else null
                ).joinToString("  •  ").ifBlank { brand }
                val posterPath = obj.optString("poster_path").takeIf { it.isNotBlank() }
                val backdropPath = obj.optString("backdrop_path").takeIf { it.isNotBlank() }
                val tmdbId = obj.optInt("id", 0)
                add(
                    LiveCatalogItem(
                        title = itemTitle,
                        meta = footer,
                        desc = overview,
                        badge = if (rating > 0.0) "⚑  TMDB ${"%.1f".format(rating)}" else "⚑  Live Catalog",
                        brand = brand,
                        footer = footer,
                        progress = 0.18f + ((i % 8) * 0.07f),
                        posterUrl = posterPath?.let { "https://image.tmdb.org/t/p/original$it" },
                        backdropUrl = backdropPath?.let { "https://image.tmdb.org/t/p/original$it" }
                            ?: posterPath?.let { "https://image.tmdb.org/t/p/original$it" },
                        logoUrl = null,
                        mediaType = type,
                        tmdbId = tmdbId
                    )
                )
            }
        }
        return LiveRow(title = title, subtitle = subtitle, items = items)
    }

    fun resolveLogoForItem(apiKey: String, type: String, tmdbId: Int, language: String, fanartApiKey: String = "", fanartClientKey: String = ""): String? {
        return resolveLogoUrl(apiKey, type, tmdbId, language, fanartApiKey, fanartClientKey)
    }

    fun resolveHeroArtForExternalId(apiKey: String, externalId: String, language: String, fanartApiKey: String = "", fanartClientKey: String = ""): ResolvedHeroArt? {
        if (apiKey.isBlank() || externalId.isBlank()) return null
        val cacheKey = "imdb:$externalId:${language.toLowerCase(java.util.Locale.ROOT)}"
        if (heroArtCache.containsKey(cacheKey)) return heroArtCache[cacheKey]

        val findEndpoint = "https://api.themoviedb.org/3/find/${enc(externalId)}?api_key=${enc(apiKey)}&external_source=imdb_id&language=${enc(language.ifBlank { "en-US" })}"
        val result = runCatching { fetchJson(findEndpoint) }.getOrNull() ?: return null

        val movie = result.optJSONArray("movie_results")?.optJSONObject(0)
        val tv = result.optJSONArray("tv_results")?.optJSONObject(0)
        val chosen = movie ?: tv ?: return null
        val type = if (movie != null) "movie" else "tv"
        val tmdbId = chosen.optInt("id", 0)
        if (tmdbId <= 0) return null

        val imagesEndpoint = "/${if (type == "movie") "movie" else "tv"}/$tmdbId/images?include_image_language=${enc(language)},en,null"
        val images = runCatching { fetchJson(buildUrl(apiKey, imagesEndpoint, "")) }.getOrNull()
        val externalIds = resolveExternalIds(apiKey, type, tmdbId, language)

        val backdrop = images?.let(::bestBackdropFromImages)
            ?: chosen.optString("backdrop_path").takeIf { it.isNotBlank() }?.let { "https://image.tmdb.org/t/p/original$it" }
            ?: resolveFanartBackdrop(type, tmdbId, externalIds.first, externalIds.second, fanartApiKey, fanartClientKey)

        val logo = images?.let(::bestLogoFromImages)
            ?: resolveFanartLogo(type, tmdbId, externalIds.first, externalIds.second, fanartApiKey, fanartClientKey)

        return ResolvedHeroArt(backdropUrl = backdrop, logoUrl = logo).also { heroArtCache[cacheKey] = it }
    }

    private fun resolveLogoUrl(apiKey: String, type: String, tmdbId: Int, language: String, fanartApiKey: String, fanartClientKey: String): String? {
        if (tmdbId <= 0) return null
        val cacheKey = "$type:$tmdbId:${language.toLowerCase(java.util.Locale.ROOT)}"
        if (logoCache.containsKey(cacheKey)) return logoCache[cacheKey]

        val endpointType = if (type == "movie") "movie" else "tv"
        val endpoint = "/$endpointType/$tmdbId/images?include_image_language=${enc(language)},en,null"
        val tmdbLogo = runCatching {
            val json = fetchJson(buildUrl(apiKey, endpoint, ""))
            bestLogoFromImages(json)
        }.getOrNull()
        if (!tmdbLogo.isNullOrBlank()) {
            logoCache[cacheKey] = tmdbLogo
            return tmdbLogo
        }

        val externalIds = resolveExternalIds(apiKey, type, tmdbId, language)
        val fanartLogo = resolveFanartLogo(type, tmdbId, externalIds.first, externalIds.second, fanartApiKey, fanartClientKey)
        logoCache[cacheKey] = fanartLogo
        return fanartLogo
    }

    private fun resolveExternalIds(apiKey: String, type: String, tmdbId: Int, language: String): Pair<String?, String?> {
        val cacheKey = "$type:$tmdbId"
        if (externalIdCache.containsKey(cacheKey)) return externalIdCache[cacheKey] ?: (null to null)
        val endpointType = if (type == "movie") "movie" else "tv"
        val endpoint = "/$endpointType/$tmdbId/external_ids"
        val ids = runCatching {
            val json = fetchJson(buildUrl(apiKey, endpoint, language))
            val imdbId = json.optString("imdb_id").takeIf { it.isNotBlank() }
            val tvdbId = json.optString("tvdb_id").takeIf { it.isNotBlank() && it != "0" }
            imdbId to tvdbId
        }.getOrDefault(null to null)
        externalIdCache[cacheKey] = ids
        return ids
    }

    private fun resolveFanartBackdrop(type: String, tmdbId: Int, imdbId: String?, tvdbId: String?, fanartApiKey: String, fanartClientKey: String): String? {
        if (fanartApiKey.isBlank()) return null
        val endpoint = when (type) {
            "movie" -> "/movies/${imdbId ?: tmdbId}"
            else -> {
                val tvId = tvdbId ?: return null
                "/tv/$tvId"
            }
        }
        return runCatching {
            val json = fetchJson("https://webservice.fanart.tv/v3$endpoint", buildFanartHeaders(fanartApiKey, fanartClientKey))
            bestBackdropFromFanart(json, type)
        }.getOrNull()
    }

    private fun resolveFanartLogo(type: String, tmdbId: Int, imdbId: String?, tvdbId: String?, fanartApiKey: String, fanartClientKey: String): String? {
        if (fanartApiKey.isBlank()) return null
        val endpoint = when (type) {
            "movie" -> "/movies/${imdbId ?: tmdbId}"
            else -> {
                val tvId = tvdbId ?: return null
                "/tv/$tvId"
            }
        }
        return runCatching {
            val json = fetchJson("https://webservice.fanart.tv/v3$endpoint", buildFanartHeaders(fanartApiKey, fanartClientKey))
            bestLogoFromFanart(json, type)
        }.getOrNull()
    }

    private fun bestBackdropFromFanart(json: JSONObject, type: String): String? {
        val candidateKeys = if (type == "movie") {
            listOf("moviebackground", "moviethumb")
        } else {
            listOf("showbackground", "tvthumb")
        }
        var bestUrl: String? = null
        var bestLikes = Int.MIN_VALUE
        for (key in candidateKeys) {
            val arr = json.optJSONArray(key) ?: continue
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val url = obj.optString("url")
                if (url.isBlank()) continue
                val likes = obj.optString("likes").toIntOrNull() ?: 0
                if (likes > bestLikes) {
                    bestLikes = likes
                    bestUrl = url
                }
            }
            if (bestUrl != null) return bestUrl
        }
        return null
    }

    private fun bestLogoFromFanart(json: JSONObject, type: String): String? {
        val candidateKeys = if (type == "movie") {
            listOf("hdmovielogo", "movielogo", "clearlogo")
        } else {
            listOf("hdtvlogo", "clearlogo", "tvlogo")
        }
        var bestUrl: String? = null
        var bestLikes = Int.MIN_VALUE
        for (key in candidateKeys) {
            val arr = json.optJSONArray(key) ?: continue
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val url = obj.optString("url")
                if (url.isBlank()) continue
                val likes = obj.optString("likes").toIntOrNull() ?: 0
                if (likes > bestLikes) {
                    bestLikes = likes
                    bestUrl = url
                }
            }
            if (bestUrl != null) return bestUrl
        }
        return null
    }

    private fun buildFanartHeaders(apiKey: String, clientKey: String): Map<String, String> {
        val headers = linkedMapOf("api-key" to apiKey)
        if (clientKey.isNotBlank()) headers["client-key"] = clientKey
        return headers
    }

    private fun bestBackdropFromImages(json: JSONObject): String? {
        val backdrops = json.optJSONArray("backdrops") ?: JSONArray()
        if (backdrops.length() == 0) return null

        var bestPath: String? = null
        var bestScore = Int.MIN_VALUE
        for (i in 0 until backdrops.length()) {
            val obj = backdrops.optJSONObject(i) ?: continue
            val filePath = obj.optString("file_path")
            if (filePath.isBlank()) continue
            val iso = obj.optString("iso_639_1").toLowerCase(java.util.Locale.ROOT)
            val vote = (obj.optDouble("vote_average", 0.0) * 100).toInt()
            val width = obj.optInt("width", 0)
            val langScore = when (iso) {
                "en" -> 300000
                "" -> 200000
                "null" -> 200000
                else -> 100000
            }
            val score = langScore + vote + width
            if (score > bestScore) {
                bestScore = score
                bestPath = filePath
            }
        }
        return bestPath?.let { "https://image.tmdb.org/t/p/original$it" }
    }

    private fun bestLogoFromImages(json: JSONObject): String? {
        val logos = json.optJSONArray("logos") ?: JSONArray()
        if (logos.length() == 0) return null

        var bestPath: String? = null
        var bestScore = Int.MIN_VALUE
        for (i in 0 until logos.length()) {
            val obj = logos.optJSONObject(i) ?: continue
            val filePath = obj.optString("file_path")
            if (filePath.isBlank()) continue
            val iso = obj.optString("iso_639_1").toLowerCase(java.util.Locale.ROOT)
            val vote = (obj.optDouble("vote_average", 0.0) * 100).toInt()
            val width = obj.optInt("width", 0)
            val langScore = when (iso) {
                "en" -> 300000
                "" -> 200000
                "null" -> 200000
                else -> 100000
            }
            val score = langScore + vote + width
            if (score > bestScore) {
                bestScore = score
                bestPath = filePath
            }
        }
        return bestPath?.let { "https://image.tmdb.org/t/p/original$it" }
    }

    private fun buildUrl(apiKey: String, endpoint: String, language: String): String {
        val joiner = if (endpoint.contains('?')) '&' else '?'
        val languagePart = language.takeIf { it.isNotBlank() }?.let { "&language=${enc(it)}" }.orEmpty()
        return "https://api.themoviedb.org/3$endpoint${joiner}api_key=${enc(apiKey)}$languagePart"
    }

    private fun fetchJson(url: String, headers: Map<String, String> = emptyMap()): JSONObject {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 8000
        connection.readTimeout = 8000
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("User-Agent", "ChannelsDebridTV/1.0")
        headers.forEach { (key, value) ->
            if (value.isNotBlank()) connection.setRequestProperty(key, value)
        }
        return try {
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (connection.responseCode !in 200..299) throw IllegalStateException("HTTP ${connection.responseCode}: $body")
            JSONObject(body)
        } finally {
            connection.disconnect()
        }
    }

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

    private data class Quint(
        val first: String,
        val second: String,
        val third: String,
        val fourth: String,
        val fifth: String,
    )
}
