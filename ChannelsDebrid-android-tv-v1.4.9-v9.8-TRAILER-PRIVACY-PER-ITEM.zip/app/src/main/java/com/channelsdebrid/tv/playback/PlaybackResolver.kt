package com.channelsdebrid.tv.playback

import com.channelsdebrid.tv.live.LiveSourceResolver
import com.channelsdebrid.tv.settings.ChannelsDvrSettings
import com.channelsdebrid.tv.settings.DebridSettings
import com.channelsdebrid.tv.settings.PlaybackSettings
import com.channelsdebrid.tv.settings.StremioAddonSettings
import com.channelsdebrid.tv.settings.XtreamSettings

class PlaybackResolver {
    private val streamingPipelineResolver = StreamingPipelineResolver()

    data class PlaybackTarget(
        val url: String,
        val sourceLabel: String,
        val title: String,
        val debugLabel: String = ""
    )

    fun resolvePreferredTarget(
        title: String,
        externalId: String?,
        mediaType: String?,
        addons: List<StremioAddonSettings>,
        debrid: DebridSettings,
        playback: PlaybackSettings,
        dvr: ChannelsDvrSettings,
        xtream: XtreamSettings
    ): PlaybackTarget? {
        val onDemand = externalId
            ?.takeIf { it.isNotBlank() }
            ?.let {
                streamingPipelineResolver.resolve(
                    title = title,
                    externalId = it,
                    mediaType = mediaType,
                    addons = addons,
                    debrid = debrid,
                    playback = playback
                )
            }
        if (onDemand != null) {
            return PlaybackTarget(onDemand.url, onDemand.sourceLabel, title, onDemand.debugLabel)
        }
        return resolveLiveTestTarget(title, dvr, xtream)
    }

    fun resolveLiveTestTarget(
        title: String,
        dvr: ChannelsDvrSettings,
        xtream: XtreamSettings
    ): PlaybackTarget? {
        return resolveChannelsDvr(title, dvr) ?: resolveXtream(title, xtream)
    }

    private fun resolveChannelsDvr(title: String, dvr: ChannelsDvrSettings): PlaybackTarget? {
        val base = dvr.baseUrl.trim().trimEnd('/')
        if (base.isBlank()) return null
        val first = LiveSourceResolver.resolveDvrPlayback(base, dvr.deviceId) ?: return null
        return PlaybackTarget(first.url, first.source, "${first.name} • $title", first.debug)
    }

    private fun resolveXtream(title: String, xtream: XtreamSettings): PlaybackTarget? {
        if (!xtream.enabled) return null
        val first = when {
            xtream.m3uUrl.trim().isNotBlank() -> LiveSourceResolver.loadM3uChannels(xtream.m3uUrl).first.firstOrNull()
            xtream.server.trim().isNotBlank() && xtream.username.trim().isNotBlank() && xtream.password.trim().isNotBlank() -> {
                LiveSourceResolver.loadXtreamChannels(xtream.server.trim().trimEnd('/'), xtream.username.trim(), xtream.password.trim()).first.firstOrNull()
            }
            else -> null
        } ?: return null
        return PlaybackTarget(first.url, first.source, "${first.name} • $title", first.debug)
    }
}
