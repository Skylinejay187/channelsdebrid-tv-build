package com.channelsdebrid.tv.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object HomeMockLoader {
    fun load(context: Context, assetName: String = "mock_home.json"): HomeResponseDto {
        val raw = context.assets.open(assetName).bufferedReader().use { it.readText() }
        val root = JSONObject(raw)
        val hero = root.optJSONObject("hero")?.let(::parseHero)
        val rows = root.optJSONArray("rows")?.let(::parseRows).orEmpty()
        return HomeResponseDto(hero = hero, rows = rows)
    }

    private fun parseHero(obj: JSONObject): HeroDto = HeroDto(
        id = obj.optString("id"),
        type = obj.optString("type"),
        title = obj.optString("title"),
        subtitle = obj.optString("subtitle"),
        description = obj.optString("description"),
        backdrop = obj.optString("backdrop"),
        logo = obj.optString("logo"),
        actions = obj.optJSONArray("actions")?.let { array ->
            mutableListOf<HeroActionDto>().apply {
                for (i in 0 until array.length()) {
                    val action = array.getJSONObject(i)
                    add(HeroActionDto(action.optString("id"), action.optString("label")))
                }
            }
        }.orEmpty()
    )

    private fun parseRows(array: JSONArray): List<HomeRowDto> = mutableListOf<HomeRowDto>().apply {
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            add(
                HomeRowDto(
                    id = obj.optString("id"),
                    title = obj.optString("title"),
                    type = obj.optString("type"),
                    style = obj.optString("style"),
                    source = obj.optString("source"),
                    catalogId = obj.optString("catalogId"),
                    provider = obj.optString("provider").takeIf { it.isNotBlank() },
                    addonId = obj.optString("addonId").takeIf { it.isNotBlank() },
                    items = obj.optJSONArray("items")?.let(::parseItems).orEmpty()
                )
            )
        }
    }

    private fun parseItems(array: JSONArray): List<CatalogItemDto> = mutableListOf<CatalogItemDto>().apply {
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            add(
                CatalogItemDto(
                    id = obj.optString("id"),
                    type = obj.optString("type"),
                    title = obj.optString("title"),
                    description = obj.optString("description"),
                    poster = obj.optString("poster"),
                    backdrop = obj.optString("backdrop"),
                    logo = obj.optString("logo"),
                    provider = obj.optJSONObject("provider")?.let {
                        ProviderDto(it.optString("id"), it.optString("name"), it.optString("logo"))
                    },
                    badges = obj.optJSONArray("badges")?.let { badges ->
                        mutableListOf<BadgeDto>().apply {
                            for (j in 0 until badges.length()) {
                                val badge = badges.getJSONObject(j)
                                add(BadgeDto(badge.optString("type"), badge.optString("label")))
                            }
                        }
                    }.orEmpty()
                )
            )
        }
    }
}
