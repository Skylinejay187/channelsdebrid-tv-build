package com.channelsdebrid.tv.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

class UnifiedCatalogRepository(private val context: Context) {
    data class MediaItem(
        val title: String,
        val type: String,
        val meta: String,
        val overview: String,
        val externalId: String,
        val posterUrl: String = "",
        val backdropUrl: String = "",
        val logoUrl: String = "",
        val progress: Float = 0f,
        val streamUrl: String = ""
    )

    private val prefs = context.getSharedPreferences("continue_watching", Context.MODE_PRIVATE)
    private val backendBaseUrl = "http://192.168.100.55:8181".trimEnd('/')

    fun section(section: String): List<MediaItem> {
        val path = when (section.lowercase(Locale.US)) {
            "movies" -> "/api/catalog/movies"
            "shows", "tv", "series" -> "/api/catalog/shows"
            else -> "/api/catalog/home"
        }
        return fetchItems("$backendBaseUrl$path").ifEmpty { fallback(section) }
    }

    fun search(query: String): List<MediaItem> {
        val q = query.trim()
        if (q.isBlank()) return fallback("search") + liveChannelResults("")
        val encoded = URLEncoder.encode(q, "UTF-8")
        return (fetchItems("$backendBaseUrl/api/search?q=$encoded") + liveChannelResults(q))
            .distinctBy { it.type + "|" + it.externalId + "|" + it.title }
            .ifEmpty { fallback("search").filter { it.title.contains(q, true) || it.type.contains(q, true) } }
    }

    fun continueWatching(): List<MediaItem> {
        val arr = JSONArray(prefs.getString("items", "[]") ?: "[]")
        val out = mutableListOf<MediaItem>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val progress = obj.optDouble("progress", 0.0).toFloat().coerceIn(0f, 1f)
            if (progress <= 0.02f || progress >= 0.92f) continue
            out += MediaItem(
                title = obj.optString("title").ifBlank { "Continue Watching" },
                type = obj.optString("type").ifBlank { "movie" },
                meta = obj.optString("meta").ifBlank { "${(progress * 100).toInt()}% watched" },
                overview = obj.optString("overview").ifBlank { "Resume from where you left off." },
                externalId = obj.optString("externalId").ifBlank { obj.optString("streamUrl") },
                posterUrl = obj.optString("posterUrl"),
                backdropUrl = obj.optString("backdropUrl"),
                logoUrl = obj.optString("logoUrl"),
                progress = progress,
                streamUrl = obj.optString("streamUrl")
            )
        }
        return out.sortedByDescending { it.progress }.ifEmpty { fallback("resume") }
    }

    private fun liveChannelResults(query: String): List<MediaItem> {
        val raw = context.getSharedPreferences("live_tv_cache", Context.MODE_PRIVATE).getString("channels_json", "[]").orEmpty()
        val arr = JSONArray(raw.ifBlank { "[]" })
        val out = mutableListOf<MediaItem>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val name = obj.optString("name")
            if (query.isNotBlank() && !name.contains(query, true)) continue
            out += MediaItem(
                title = name,
                type = "live",
                meta = obj.optString("source").ifBlank { "Live TV Channel" },
                overview = "Live TV channel from your synced lineup.",
                externalId = "live:${obj.optString("url")}",
                posterUrl = obj.optString("iconUrl"),
                logoUrl = obj.optString("iconUrl"),
                streamUrl = obj.optString("url")
            )
        }
        return out.take(50)
    }

    private fun fetchItems(url: String): List<MediaItem> = try {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 2500
            readTimeout = 3500
            requestMethod = "GET"
        }
        val body = conn.inputStream.bufferedReader().use { it.readText() }
        parseItems(body)
    } catch (_: Exception) { emptyList() }

    private fun parseItems(body: String): List<MediaItem> {
        if (body.isBlank()) return emptyList()
        val root = JSONObject(body)
        val arr = root.optJSONArray("items") ?: root.optJSONArray("results") ?: root.optJSONArray("metas") ?: JSONArray(body)
        val out = mutableListOf<MediaItem>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val type = obj.optString("type").ifBlank { obj.optString("mediaType") }.ifBlank { "movie" }
            out += MediaItem(
                title = obj.optString("title").ifBlank { obj.optString("name") },
                type = type,
                meta = obj.optString("meta").ifBlank { obj.optString("year") }.ifBlank { type.replaceFirstChar { it.uppercase() } },
                overview = obj.optString("overview").ifBlank { obj.optString("description") },
                externalId = obj.optString("externalId").ifBlank { obj.optString("id") },
                posterUrl = obj.optString("poster").ifBlank { obj.optString("posterUrl") },
                backdropUrl = obj.optString("background").ifBlank { obj.optString("backdropUrl") },
                logoUrl = obj.optString("logo").ifBlank { obj.optString("logoUrl") },
                progress = obj.optDouble("progress", 0.0).toFloat()
            )
        }
        return out.filter { it.title.isNotBlank() }
    }

    private fun fallback(section: String): List<MediaItem> {
        val shows = listOf("Shōgun", "Fallout", "Halo", "Mayor of Kingstown", "The Last of Us", "Silo")
        val movies = listOf("Dune: Part Two", "The Batman", "Civil War", "Avatar", "Wonka", "The Martian")
        val titles = when (section.lowercase(Locale.US)) {
            "shows", "tv", "series" -> shows
            "resume" -> listOf("No saved progress yet")
            else -> movies
        }
        return titles.mapIndexed { index, title ->
            MediaItem(
                title = title,
                type = if (section.lowercase(Locale.US) in listOf("shows", "tv", "series")) "series" else "movie",
                meta = if (section == "resume") "Continue Watching" else if (index % 2 == 0) "Popular" else "Trending",
                overview = if (section == "resume") "Paused movies and shows will appear here after playback progress is saved." else "Catalog item from your backend/addon row fallback.",
                externalId = "fallback:$section:$index",
                progress = if (section == "resume") 0f else 0.0f
            )
        }
    }
}
