package com.channelsdebrid.tv.data

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class StremioLiveLoader {

    data class LiveCatalogItem(
        val title: String,
        val meta: String,
        val desc: String,
        val badge: String,
        val brand: String,
        val footer: String,
        val progress: Float,
        val posterUrl: String? = null,
        val backdropUrl: String? = null,
        val logoUrl: String? = null,
        val mediaType: String? = null,
        val externalId: String? = null
    )

    data class LiveRow(
        val title: String,
        val subtitle: String,
        val items: List<LiveCatalogItem>
    )

    fun loadRows(addonName: String, manifestUrl: String, limit: Int = 24): List<LiveRow> {
        val manifest = fetchJson(manifestUrl)
        val catalogs = manifest.optJSONArray("catalogs") ?: JSONArray()
        val preferred = listOf(
            CatalogRequest("movie", "top", "Popular Movies", null),
            CatalogRequest("series", "top", "Popular Shows", null),
            CatalogRequest("movie", "imdbRating", "Featured Movies", null),
            CatalogRequest("series", "imdbRating", "Featured Series", null)
        )

        val selected = linkedMapOf<String, JSONObject>()
        preferred.forEach { request ->
            findCatalog(catalogs, request.type, request.id)?.let { selected["${request.type}:${request.id}"] = it }
        }
        if (selected.isEmpty()) {
            for (i in 0 until catalogs.length()) {
                val cat = catalogs.optJSONObject(i) ?: continue
                val type = cat.optString("type")
                val id = cat.optString("id")
                if ((type == "movie" || type == "series") && id.isNotBlank()) {
                    selected.putIfAbsent("$type:$id", cat)
                }
                if (selected.size >= 4) break
            }
        }

        return selected.values.mapNotNull { catalog ->
            runCatching { loadCatalogRow(addonName, manifestUrl, catalog, limit) }.getOrNull()
        }.filter { it.items.isNotEmpty() }
    }

    fun loadPrimaryRow(addonName: String, manifestUrl: String, limit: Int = 24): LiveRow {
        return loadRows(addonName, manifestUrl, limit).firstOrNull() ?: fallbackRow(addonName)
    }

    private fun findCatalog(catalogs: JSONArray, type: String, id: String): JSONObject? {
        for (i in 0 until catalogs.length()) {
            val cat = catalogs.optJSONObject(i) ?: continue
            if (cat.optString("type") == type && cat.optString("id") == id) return cat
        }
        return null
    }

    private fun loadCatalogRow(addonName: String, manifestUrl: String, catalog: JSONObject, limit: Int): LiveRow {
        val type = catalog.optString("type")
        val id = catalog.optString("id")
        val title = when {
            type == "movie" && id == "top" -> "Popular Movies"
            type == "series" && id == "top" -> "Popular Shows"
            type == "movie" && id == "imdbRating" -> "Featured Movies"
            type == "series" && id == "imdbRating" -> "Featured Series"
            else -> catalog.optString("name").ifBlank { "$addonName Catalog" }
        }
        val extra = chooseExtras(catalog)
        val endpoint = buildCatalogUrl(manifestUrl, type, id, extra)
        val catalogJson = fetchJson(endpoint)
        val metas = catalogJson.optJSONArray("metas") ?: JSONArray()
        val items = mutableListOf<LiveCatalogItem>()
        for (i in 0 until minOf(limit, metas.length())) {
            val meta = metas.optJSONObject(i) ?: continue
            val itemTitle = meta.optString("name").ifBlank { meta.optString("title") }.ifBlank { "Unknown" }
            val year = meta.optString("year")
            val genres = meta.optJSONArray("genres")?.let { arr ->
                buildList {
                    for (j in 0 until minOf(2, arr.length())) {
                        arr.optString(j).takeIf { it.isNotBlank() }?.let(::add)
                    }
                }.joinToString("  •  ")
            }.orEmpty()
            val rating = meta.optString("imdbRating").takeIf { it.isNotBlank() }?.let { "IMDb $it" }
            val footer = listOfNotNull(year.takeIf { it.isNotBlank() }, genres.takeIf { it.isNotBlank() }, rating).joinToString("  •  ")
                .ifBlank { addonName }
            val poster = normalizeArtUrl(meta.optString("poster"))
            val background = normalizeArtUrl(meta.optString("background")).takeIf { !it.isNullOrBlank() } ?: poster
            val logo = normalizeArtUrl(meta.optString("logo"))
            val metaId = meta.optString("id").trim()
            val externalId = meta.optString("imdb_id").trim().takeIf { it.startsWith("tt") }
                ?: meta.optString("imdbId").trim().takeIf { it.startsWith("tt") }
                ?: metaId.takeIf { it.isNotBlank() }
            items += LiveCatalogItem(
                title = itemTitle,
                meta = footer,
                desc = meta.optString("description").ifBlank { "Cinemeta catalog item." },
                badge = rating ?: "⚑  Cinemeta",
                brand = addonName.take(12),
                footer = footer,
                progress = 0.16f + ((i % 7) * 0.08f),
                posterUrl = poster,
                backdropUrl = background,
                logoUrl = logo,
                mediaType = type,
                externalId = externalId
            )
        }
        return LiveRow(
            title = title,
            subtitle = "$addonName • built-in catalog",
            items = items
        )
    }

    private fun chooseExtras(catalog: JSONObject): Map<String, String> {
        val extras = linkedMapOf<String, String>()
        val id = catalog.optString("id")
        val type = catalog.optString("type")
        if (id == "year") {
            val year = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR).toString()
            extras["genre"] = year
        } else if (id == "top") {
            extras["skip"] = "0"
        } else if (id == "imdbRating") {
            extras["skip"] = "0"
        }
        if (type == "movie" || type == "series") {
            return extras
        }
        return emptyMap()
    }

    private fun fallbackRow(addonName: String): LiveRow {
        return LiveRow(
            title = addonName,
            subtitle = "Manifest loaded • no compatible catalogs",
            items = List(12) { idx ->
                LiveCatalogItem(
                    title = "$addonName Item ${idx + 1}",
                    meta = "Addon ready",
                    desc = "Manifest loaded successfully.",
                    badge = "⚑  Addon Connected",
                    brand = addonName.take(10),
                    footer = "Catalog Ready",
                    progress = 0.2f + ((idx % 5) * 0.1f)
                )
            }
        )
    }

    private fun buildCatalogUrl(manifestUrl: String, type: String, catalogId: String, extra: Map<String, String> = emptyMap()): String {
        val base = if (manifestUrl.endsWith("/manifest.json")) manifestUrl.substring(0, manifestUrl.length - "/manifest.json".length) else manifestUrl.substringBeforeLast('/')
        val extraPath = if (extra.isEmpty()) {
            ""
        } else {
            val json = JSONObject(extra as Map<*, *>)
            "/${URLEncoder.encode(json.toString(), "UTF-8")}".replace("+", "%20")
        }
        return "$base/catalog/$type/$catalogId$extraPath.json"
    }

    private fun normalizeArtUrl(url: String?): String? {
        val value = url?.trim().orEmpty()
        if (value.isBlank()) return null
        val absolute = when {
            value.startsWith("//") -> "https:$value"
            value.startsWith("http://") || value.startsWith("https://") -> value
            else -> value
        }
        return absolute
            .replace("/poster/small/", "/poster/large/")
            .replace("/poster/medium/", "/poster/large/")
            .replace("/background/small/", "/background/large/")
            .replace("/background/medium/", "/background/large/")
            .replace("/logo/small/", "/logo/large/")
            .replace("/logo/medium/", "/logo/large/")
    }

    private fun fetchJson(url: String): JSONObject {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 8000
        connection.readTimeout = 8000
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("User-Agent", "ChannelsDebridTV/1.0")
        return try {
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (connection.responseCode !in 200..299) throw IllegalStateException("HTTP ${connection.responseCode}: $body")
            JSONObject(body)
        } finally {
            connection.disconnect()
        }
    }

    private data class CatalogRequest(
        val type: String,
        val id: String,
        val title: String,
        val genre: String?
    )
}
