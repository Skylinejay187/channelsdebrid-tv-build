package com.channelsdebrid.tv.data

data class HomeResponseDto(
    val hero: HeroDto?,
    val rows: List<HomeRowDto>
)

data class HeroDto(
    val id: String,
    val type: String,
    val title: String,
    val subtitle: String? = null,
    val description: String? = null,
    val backdrop: String? = null,
    val logo: String? = null,
    val actions: List<HeroActionDto> = emptyList()
)

data class HeroActionDto(
    val id: String,
    val label: String
)

data class HomeRowDto(
    val id: String,
    val title: String,
    val type: String,
    val style: String,
    val source: String,
    val catalogId: String,
    val provider: String? = null,
    val addonId: String? = null,
    val items: List<CatalogItemDto> = emptyList()
)

data class CatalogItemDto(
    val id: String,
    val type: String,
    val title: String,
    val description: String? = null,
    val poster: String? = null,
    val backdrop: String? = null,
    val logo: String? = null,
    val provider: ProviderDto? = null,
    val badges: List<BadgeDto> = emptyList()
)

data class ProviderDto(
    val id: String,
    val name: String,
    val logo: String? = null
)

data class BadgeDto(
    val type: String,
    val label: String
)
