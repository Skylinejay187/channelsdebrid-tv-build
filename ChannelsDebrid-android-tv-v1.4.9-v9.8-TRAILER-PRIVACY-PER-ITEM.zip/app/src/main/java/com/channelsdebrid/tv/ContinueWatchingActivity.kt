package com.channelsdebrid.tv

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.channelsdebrid.tv.data.UnifiedCatalogRepository
import com.channelsdebrid.tv.playback.MediaDetailsActivity
import com.channelsdebrid.tv.playback.PlayerActivity

class ContinueWatchingActivity : AppCompatActivity() {
    private lateinit var repo: UnifiedCatalogRepository
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = UnifiedCatalogRepository(this)
        setContentView(buildLayout())
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildLayout(): View {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(54), dp(38), dp(54), dp(30)); setBackgroundColor(Color.rgb(3,5,9)) }
        root.addView(TextView(this).apply { text = "Continue Watching"; textSize = 38f; setTextColor(Color.WHITE); typeface = android.graphics.Typeface.DEFAULT_BOLD })
        root.addView(TextView(this).apply { text = "Paused movies and shows saved from this device"; textSize = 15f; setTextColor(0xFFD7CCBF.toInt()); setPadding(0, dp(4), 0, dp(22)) })
        val scroll = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        return root
    }

    private fun render() {
        list.removeAllViews()
        repo.continueWatching().forEach { list.addView(row(it)) }
    }

    private fun row(item: UnifiedCatalogRepository.MediaItem): View {
        val root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; isFocusable = true; isClickable = true; setPadding(dp(12), dp(10), dp(12), dp(10)); background = rounded(0x18111111, 0, dp(20), 0); layoutParams = LinearLayout.LayoutParams(-1, dp(132)).apply { bottomMargin = dp(12) } }
        val poster = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = rounded(0xFF111827.toInt(), 0, dp(14), 0) }
        if (item.posterUrl.isNotBlank()) Glide.with(this).load(item.posterUrl).centerCrop().into(poster)
        root.addView(poster, LinearLayout.LayoutParams(dp(180), dp(102)))
        val textCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), 0, 0, 0) }
        textCol.addView(TextView(this).apply { text = item.title; textSize = 24f; setTextColor(Color.WHITE); typeface = android.graphics.Typeface.DEFAULT_BOLD })
        textCol.addView(TextView(this).apply { text = item.meta; textSize = 15f; setTextColor(0xFFD7CCBF.toInt()); setPadding(0, dp(4), 0, dp(8)) })
        textCol.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = (item.progress * 100).toInt().coerceIn(0, 100) }, LinearLayout.LayoutParams(dp(420), dp(8)))
        root.addView(textCol, LinearLayout.LayoutParams(0, -1, 1f))
        root.setOnFocusChangeListener { v, hasFocus -> v.background = if (hasFocus) rounded(0x33FFFFFF, 0xFFFFFFFF.toInt(), dp(20), dp(2)) else rounded(0x18111111, 0, dp(20), 0) }
        root.setOnClickListener { open(item) }
        return root
    }

    private fun open(item: UnifiedCatalogRepository.MediaItem) {
        if (item.streamUrl.isNotBlank()) startActivity(Intent(this, PlayerActivity::class.java).apply { putExtra(PlayerActivity.EXTRA_STREAM_URL, item.streamUrl); putExtra(PlayerActivity.EXTRA_TITLE, item.title); putExtra(PlayerActivity.EXTRA_VOD_MODE, item.type != "live") })
        else startActivity(Intent(this, MediaDetailsActivity::class.java).apply { putExtra(MediaDetailsActivity.EXTRA_TITLE, item.title); putExtra(MediaDetailsActivity.EXTRA_META_LINE, item.meta); putExtra(MediaDetailsActivity.EXTRA_DESC, item.overview); putExtra(MediaDetailsActivity.EXTRA_MEDIA_TYPE, item.type); putExtra(MediaDetailsActivity.EXTRA_EXTERNAL_ID, item.externalId) })
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int, strokeWidth: Int) = android.graphics.drawable.GradientDrawable().apply { shape = android.graphics.drawable.GradientDrawable.RECTANGLE; setColor(fill); cornerRadius = radius.toFloat(); if (strokeWidth > 0) setStroke(strokeWidth, stroke) }
}
