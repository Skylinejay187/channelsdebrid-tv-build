package com.channelsdebrid.tv.data

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class BackendHomeLoader {
    companion object {
        @Volatile private var cachedBaseUrl: String = ""
        @Volatile private var cachedRows: List<BackendRow> = emptyList()
        @Volatile private var cachedAtMs: Long = 0L
        private const val CACHE_TTL_MS = 15 * 60_000L
    }

    data class BackendItem(
        val id: String,
        val type: String,
        val title: String,
        val year: Int,
        val genre: String,
        val overview: String,
        val source: String,
        val poster: String?,
        val backdrop: String?,
        val logo: String?,
        val imdbId: String?
    )

    data class BackendRow(
        val slug: String,
        val title: String,
        val items: List<BackendItem>
    )

    fun loadCachedRows(context: Context, baseUrl: String, limitPerRow: Int = 12): List<BackendRow> {
        val normalized = baseUrl.trim().trimEnd('/')
        if (normalized.isBlank()) return cachedRows
        return if (cachedRows.isNotEmpty() && normalized == cachedBaseUrl) cachedRows else emptyList()
    }

    fun loadRows(context: Context, baseUrl: String, limitPerRow: Int = 12): List<BackendRow> {
        val normalized = baseUrl.trim().trimEnd('/')
        if (normalized.isBlank()) return loadCachedRows(context, baseUrl, limitPerRow)
        val now = System.currentTimeMillis()
        if (cachedRows.isNotEmpty() && normalized == cachedBaseUrl && now - cachedAtMs < CACHE_TTL_MS) {
            return cachedRows
        }
        val memoryRows = loadCachedRows(context, baseUrl, limitPerRow)
        val conn = runCatching {
            (URL("$normalized/api/home").openConnection() as HttpURLConnection).apply {
                connectTimeout = 3500
                readTimeout = 6000
                requestMethod = "GET"
                setRequestProperty("Accept", "application/json")
                setRequestProperty("Cache-Control", "max-age=900")
            }
        }.getOrNull() ?: return memoryRows
        return runCatching {
            conn.connect()
            if (conn.responseCode !in 200..299) return@runCatching memoryRows
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val root = JSONObject(body)
            val rows = parseHomeRows(root, limitPerRow)
            if (rows.isNotEmpty()) {
                cachedBaseUrl = normalized
                cachedRows = rows
                cachedAtMs = System.currentTimeMillis()
                rows
            } else memoryRows
        }.getOrDefault(memoryRows).also {
            runCatching { conn.disconnect() }
        }
    }

    private fun parseHomeRows(root: JSONObject, limitPerRow: Int): List<BackendRow> {
        val rails = root.optJSONArray("rails") ?: return emptyList()
        val rows = mutableListOf<BackendRow>()
        for (i in 0 until rails.length()) {
            val rowObj = rails.optJSONObject(i) ?: continue
            val itemsJson = rowObj.optJSONArray("items")
            val items = mutableListOf<BackendItem>()
            if (itemsJson != null) {
                for (j in 0 until itemsJson.length()) {
                    val itemObj = itemsJson.optJSONObject(j) ?: continue
                    val imdb = itemObj.optString("imdbId").takeIf { it.isNotBlank() }
                        ?: itemObj.optString("externalId").takeIf { it.isNotBlank() }
                    items += BackendItem(
                        id = itemObj.optString("id").ifBlank { imdb ?: "backend-$i-$j" },
                        type = itemObj.optString("type", "movie"),
                        title = itemObj.optString("title", "Unknown"),
                        year = itemObj.optInt("year", 0),
                        genre = itemObj.optString("genre", "Featured"),
                        overview = itemObj.optString("overview", ""),
                        source = itemObj.optString("source", "Backend"),
                        poster = itemObj.optString("poster").takeIf { it.isNotBlank() },
                        backdrop = itemObj.optString("backdrop").takeIf { it.isNotBlank() },
                        logo = itemObj.optString("logo").takeIf { it.isNotBlank() },
                        imdbId = imdb
                    )
                    if (items.size >= limitPerRow) break
                }
            }
            if (items.isNotEmpty()) {
                rows += BackendRow(
                    slug = rowObj.optString("slug", "backend-row-$i"),
                    title = rowObj.optString("title", "Featured"),
                    items = items
                )
            }
        }
        return rows
    }
}
