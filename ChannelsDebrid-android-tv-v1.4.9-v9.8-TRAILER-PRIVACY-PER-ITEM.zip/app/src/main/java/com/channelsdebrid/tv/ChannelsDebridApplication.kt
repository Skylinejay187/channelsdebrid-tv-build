package com.channelsdebrid.tv

import android.app.Application

class ChannelsDebridApplication : Application()
