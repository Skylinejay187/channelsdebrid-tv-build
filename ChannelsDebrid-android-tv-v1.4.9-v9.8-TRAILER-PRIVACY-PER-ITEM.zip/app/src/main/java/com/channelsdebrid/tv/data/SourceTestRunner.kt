package com.channelsdebrid.tv.data

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class SourceTestRunner {
    private val probe = SourceProbe()
    private val tmdb = TmdbLiveLoader()

    fun testTmdb(apiKey: String, region: String, language: String): String {
        if (apiKey.isBlank()) return "TMDB key missing"
        val enabled = listOf("trending_movies")
        val rows = tmdb.loadRows(apiKey, region.ifBlank { "US" }, language.ifBlank { "en-US" }, enabled, 5)
        val count = rows.firstOrNull()?.items?.size ?: 0
        return if (count > 0) "TMDB connected • $count items loaded" else "TMDB connected • no items"
    }

    fun testStremio(name: String, manifestUrl: String): String {
        return probe.probeStremio(manifestUrl) ?: "$name manifest unavailable"
    }

    fun testChannelsDvr(autoDetect: Boolean, baseUrl: String): String {
        return probe.probeChannelsDvr(autoDetect, baseUrl) ?: "Channels DVR not configured"
    }

    fun testXtream(server: String, username: String, password: String, m3uUrl: String = ""): String {
        return probe.probeXtream(server, username, password, m3uUrl) ?: "Xtream or M3U not configured"
    }

    fun testRealDebrid(apiKey: String): String {
        if (apiKey.isBlank()) return "Real-Debrid key missing"
        return runCatching {
            val connection = URL("https://api.real-debrid.com/rest/1.0/user").openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 6000
            connection.readTimeout = 6000
            connection.setRequestProperty("Authorization", "Bearer $apiKey")
            connection.setRequestProperty("Accept", "application/json")
            val code = connection.responseCode
            val body = (if (code in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            connection.disconnect()
            if (code in 200..299) {
                val json = JSONObject(body)
                val username = json.optString("username").ifBlank { "connected" }
                "Real-Debrid • $username"
            } else {
                "Real-Debrid failed • HTTP $code"
            }
        }.getOrElse { "Real-Debrid failed" }
    }

    fun testTorBox(apiKey: String): String {
        if (apiKey.isBlank()) return "TorBox key missing"
        return runCatching {
            val connection = URL("https://api.torbox.app/v1/api/user/me").openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 6000
            connection.readTimeout = 6000
            connection.setRequestProperty("Authorization", "Bearer $apiKey")
            connection.setRequestProperty("Accept", "application/json")
            val code = connection.responseCode
            val body = (if (code in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            connection.disconnect()
            if (code in 200..299) {
                val json = JSONObject(body)
                val data = json.optJSONObject("data") ?: json
                val email = data.optString("email").ifBlank { data.optString("username") }.ifBlank { "connected" }
                "TorBox • $email"
            } else {
                "TorBox failed • HTTP $code"
            }
        }.getOrElse { "TorBox failed" }
    }
}
