# v1.4.4.1 Guide Data Compile Fix

Fixes Kotlin build failure in `LiveSourceResolver.kt`:

- `Unresolved reference: tvgName` at HDHomeRun/Xtream mapping points.
- Replaced invalid out-of-scope `tvgName` usage with the already-resolved channel `name` for sources that do not expose `tvg-name` in that scope.
- Keeps valid M3U parsing behavior where `tvg-name` is actually parsed inside the M3U parser block.

Guide data lock-in behavior from v1.4.4 remains intact:

- M3U matching by `tvg-id`, `tvg-name`, and channel name.
- Xtream channel/EPG mapping fallback.
- Channels DVR guide support fallback.
- HDHomeRun lineup fallback.
- `No information` fallback instead of fake guide rows.
