# Live TV Low-Memory Kill Fix

This patch targets the confirmed logcat cause:

`lowmemorykiller: Kill 'com.channelsdebrid.tv' ... to free 1365736kB`

Changes:

- Live TV browsing no longer creates/feeds an ExoPlayer preview while scrolling.
- DPAD OK on a guide channel now opens the full player directly.
- Guide rows use lightweight text logo tiles instead of loading remote channel-logo bitmaps while scrolling.
- Hero/preview artwork updates use bundled drawables instead of remote artwork during guide navigation.
- Device-side XMLTV parsing/fallback is disabled in the app. Large XMLTV responses should be ingested by the backend, not parsed on Android TV.
- Backend EPG lookups are capped to a small initial channel batch so scrolling does not trigger heavy allocations.
- Cached Live TV channel list is capped at 300 channels to keep guide memory bounded.
- Category generation is capped to 60 explicit groups to prevent giant category rails from large IPTV lineups.
- HTTP guide responses are capped while reading to avoid accidental huge JSON/XML allocations.

Backend should remain the EPG owner. The Android TV app is now a lightweight renderer for channels and cached backend guide data.
