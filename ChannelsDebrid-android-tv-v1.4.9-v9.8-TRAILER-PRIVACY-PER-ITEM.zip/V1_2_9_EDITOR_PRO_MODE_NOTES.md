# Channels Debrid Android TV v1.2.9 - Editor Pro Mode

Built on top of `v1.2.8-layout-editor-preview-controls-fix`.

## Included

- Full-screen Pro Layout Editor, launched from the existing Settings layout editor button.
- Left-side control panel for Android TV / DPAD use.
- Right-side live preview panel.
- Local Save using `SharedPreferences` through `SettingsRepository`.
- Reset restores safe defaults.
- View saves the layout locally and returns to the main home screen.
- New preview card count control, default 4, range 1-8.
- Version bumped to `1.2.9` / versionCode `29`.

## Files changed

- `app/build.gradle`
- `app/src/main/java/com/channelsdebrid/tv/HomeLayoutEditorActivity.kt`
- `app/src/main/java/com/channelsdebrid/tv/settings/AppConfigModels.kt`
- `app/src/main/java/com/channelsdebrid/tv/settings/SettingsRepository.kt`

## Build note

This package includes the source changes. The included `gradlew` still uses the existing repository wrapper behavior, which prints: `Gradle is not installed. Install Gradle 8.7+ or use the provided GitHub Actions workflow.`
Use the included GitHub Actions workflow or install Gradle locally to build the APK.
