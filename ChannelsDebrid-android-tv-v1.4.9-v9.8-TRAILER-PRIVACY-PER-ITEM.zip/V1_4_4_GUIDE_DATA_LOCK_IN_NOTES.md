# v1.4.4 Guide Data Lock-In

This build focuses on real EPG/guide data wiring for the all-in-one Live TV guide.

## Added / fixed
- Live guide resolver now uses the saved Backend URL/User ID instead of the old hardcoded backend base.
- Added broader guide endpoint fallbacks:
  - /live/guide
  - /api/live/guide
  - /live/epg
  - /api/guide
  - /guide
- Sends channelName, channelNumber, tvgId, source, and userId to backend for better matching.
- Parses multiple backend guide response shapes: programs, guide, items, epg, data, results, airings, listings.
- Better program field parsing for title, start/end, description, image/backdrop/fanart.
- M3U and Channels DVR M3U parsing now keeps tvg-id/tvg-name metadata for guide matching.
- Xtream parsing now keeps epg_channel_id metadata for guide matching.
- Hero background can use program artwork/fanart when provided by guide data.
- If no EPG is available, guide shows No information instead of fake schedule data.

## Kept intact
- M3U support
- Xtream Codes support
- Channels DVR support
- HDHomeRun support
- Google TV style Live Guide skin
- Focus-only white guide state
- Instant channel cache behavior
