# Channels Debrid Android TV v1.3.3

## Fixed
- Fixed stuck Focus Bounce / zoom-pop animation.
- Corrected bounce math so Bounce = 0 truly means no bounce.
- Changed default Focused Card Scale to 1.00x.
- Changed default Focus Bounce to 0.
- Changed default Dim Unfocused Cards to 0.
- Changed default Glass Card Mode to Off.

## Added
- Added TV Shows to the top menu.
- Added Search to the top menu.
- Added a new Android TV-friendly Search screen.
- Search screen supports D-pad focus, title filtering, and launching Media Details.
- TV Shows top menu item jumps directly to the shows row.

## Notes
- Search is wired as a stable local UI shell first. Backend / Stremio / TMDB live search can feed the same screen next.
