# Trailer detail background + timing settings patch

Added:
- Movie/show detail page background trailers that autoplay behind the details UI.
- Settings toggles for focused-card trailers and detail-page background trailers separately.
- Separate delay settings for focused-card trailers and detail-page background trailers.
- Delays accept seconds (0-60) or raw milliseconds.
- Trailer playback remains muted in the background and stops immediately when Play is pressed or the screen closes.
- Existing backend trailer resolving remains 4K-first with fallback to 1080p.
