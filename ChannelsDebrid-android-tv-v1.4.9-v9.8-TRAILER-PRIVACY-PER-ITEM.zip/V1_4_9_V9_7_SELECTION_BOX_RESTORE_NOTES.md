# v9.7 Selection Box Restore

- Restores the visible white focused-channel/program selection box in Live TV guide.
- Keeps the v9.6 synced red current-program progress line unchanged.
- Does not remove HDHomeRun, full-channel/category loading, preview audio, or force-refresh fixes.
- Fixes the root issue where program cards are FrameLayout children but the focus styling code only tried to style LinearLayout children.
