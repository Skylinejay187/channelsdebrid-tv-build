Android source placeholder with guide + trailer wiring instructions
