# Trailer / 4K / Series fix

- Series/show Play opens season/episode browser before source selection.
- Episode selection passes episode metadata/artwork to player.
- Pair with backend v7 for improved trailer matching and 4K-first resolving.
