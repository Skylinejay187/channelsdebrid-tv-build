# v1.4.2 Real Sections + Guide Wiring Fix

Base: v1.4.1 Exact Google TV Live Guide Skin

## Fixed / Added

- Movies menu now opens a real Movies browse section instead of only scrolling the home rows.
- TV Shows menu now opens a real TV Shows browse section instead of only scrolling the home rows.
- Search now queries the unified catalog repository and includes:
  - movies
  - TV shows / series
  - cached Live TV channels
- Resume now opens a real Continue Watching screen backed by local playback progress.
- Player saves VOD progress to local storage while watching and removes completed items near the end.
- Live TV guide data is now routed through a guide resolver that attempts backend EPG endpoints before showing fallback.
- If real EPG data is unavailable, the guide now shows “No information” instead of fake synthetic program names.

## Backend guide endpoint support

The Live guide resolver attempts these endpoints:

- /api/live/guide?name=&number=&tvgId=
- /api/guide?name=&number=&tvgId=
- /live/guide?name=&number=&tvgId=

Expected response can include one of:

```json
{
  "programs": [
    { "title": "Program title", "startLabel": "8:00 PM", "endLabel": "9:00 PM", "durationMinutes": 60 }
  ]
}
```

or an array directly.

## Still supported

- M3U
- Xtream Codes
- Channels DVR
- HDHomeRun
- Live TV instant cache
- Google TV-style guide skin
