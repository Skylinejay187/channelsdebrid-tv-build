# Catalog + Sources Integration Package

This package extends the foundation build with concrete starter files for:

- backend `/api/home`
- row configuration JSON
- TMDB catalog source
- Stremio catalog source scaffold
- admin row config endpoints
- Android DTOs for dynamic home rows
- Android asset-backed mock loader for future `/api/home` wiring
- app configuration models for TMDB, Stremio, Channels DVR, IPTV/Xtream, storage, trailers, and playback

## Next implementation layer

1. Replace the asset-backed home loader with Retrofit `/api/home`
2. Bind returned rows into the existing TV rail renderer
3. Add Channels DVR discovery and channel models
4. Add IPTV/Xtream client and guide normalization
5. Add trailer popup UI and storage execution paths


## Fanart clearlogo support

Set `fanartApiKey` and optionally `fanartClientKey` in `gradle.properties` to enable real title-treatment/logo lookup. TMDB remains the fallback when Fanart is unavailable or a title has no clearlogo.
