Build notes:
- Unzip this package and commit the folder contents to your GitHub repo root.
- The workflow file is already included at .github/workflows/build-apk.yml.
- GitHub Actions will build the debug APK artifact automatically on push or workflow_dispatch.
