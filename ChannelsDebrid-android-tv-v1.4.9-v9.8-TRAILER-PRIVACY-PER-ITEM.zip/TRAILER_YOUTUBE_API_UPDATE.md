# Trailer YouTube API Update

Implemented in this zip:

- Added YouTube Data API v3 trailer lookup using the saved YouTube API key.
- Added Settings > Trailers field for the YouTube API key.
- Added Settings > Trailers switch: "Prefer 4K trailers, fallback to 1080p".
- Trailer autoplay still triggers after the configured focus delay, default 5000 ms.
- Clean in-app WebView trailer playback uses no YouTube controls (`controls=0`).
- Playback requests `hd2160` first when 4K preference is enabled, then asks the iframe player to fall back to `hd1080`.
- Caches resolved YouTube video IDs in memory so repeated focus on the same title does not re-query immediately.

Note: YouTube iframe playback quality is a request, not an absolute force. YouTube may still choose based on the trailer upload, device, network, and player policy. The app requests 4K first and falls back to 1080p when 4K is unavailable.
