# v1.1.9 compile stability fix

- Removed duplicated malformed Live TV key-handling block in PlayerActivity that broke Kotlin parsing.
- Restores PlayerActivity companion constants visibility for LiveTvActivity/MainActivity intent extras.
- Keeps v1.1.8 feature set intact.
