# Hero rating badges patch

- Replaced plain IMDb/TMDB metadata text with rendered pill badges.
- IMDb badge uses yellow background with black bold label.
- TMDB badge uses dark teal background with green label.
- Bumped Android app version to 1.1.1.
