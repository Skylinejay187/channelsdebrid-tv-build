# Channels Debrid Android TV v1.3.1

## Pro Layout Editor upgrades
- Added full font selector range for top menu, hero text, and all content/card text.
- Added content/card font setting so fonts apply to row titles, card titles, metadata, overlays, and the editor preview.
- Added font catalog metadata under `app/src/main/assets/fonts/font_catalog.json`.
- Added extra pro controls: focus bounce, glass card mode, hover info overlay, background dim on focus, and effect profiles.

## Effect fixes
- Fixed Pulse effect not visibly firing by restarting animation when a card gains focus.
- Fixed 3D tilt being immediately reset after focus; tilt now stays while focused.
- Fixed dim unfocused cards by using saved `dimUnfocusedPercent` on blur and saved `backgroundDimOnFocusPercent` on focus.
- Fixed card lift being overwritten after focus.

## Save/persistence
- Added persistence keys for content font, focus bounce, glass card mode, hover overlay, background dim, and effect profile.
- Settings are local SharedPreferences as requested.
