# Stremio Series Crash + HLS Fix Notes

Changes in this patch:

- Fixed startup crash caused by attempting to read the first Stremio addon when the addon list is empty.
- Restored a safe Cinemeta metadata fallback so series season/episode metadata can load even when a stream-only addon does not provide `/meta/series/{id}.json` data.
- Preserved user-entered Stremio addon URLs and only adds the fallback when no usable manifest exists.
- Kept Media3 HLS dependency in `app/build.gradle` so `.m3u8` playback has `HlsMediaSource.Factory` at runtime.
- Bumped app version to `1.0.1` / versionCode `2` so testers install the patched APK over the previous broken build.

Important: build a fresh APK from this zip before testing. The HLS class-not-found error means the installed APK did not contain `media3-exoplayer-hls` even though the source now declares it.
