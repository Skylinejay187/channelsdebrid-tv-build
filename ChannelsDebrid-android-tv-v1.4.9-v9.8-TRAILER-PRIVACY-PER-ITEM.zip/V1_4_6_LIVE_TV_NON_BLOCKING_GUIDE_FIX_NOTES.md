# V1.4.6 Live TV Non-Blocking Guide Fix

This patch fixes Live TV getting stuck on the loading screen when Channels DVR XMLTV/EPG data is large or slow.

## Changes

- Live TV now builds channel rows immediately without blocking on EPG/program resolution.
- Program guide data refreshes in the background after channels render.
- Channels DVR XMLTV initial guide window reduced from 14 days (`1209600`) to 24 hours (`86400`).
- EPG HTTP timeouts shortened so failed/slow guide sources do not hold the Live TV screen hostage.
- Cached lineup rendering no longer starts a guide refresh that could block the fresh source refresh queue.
- Status text now shows when guide data is loading in the background.

## Expected behavior

1. Open Live TV.
2. Channels should appear quickly as soon as the lineup is loaded.
3. EPG/program blocks may initially show `No information`.
4. Guide details fill in shortly after in the background.
5. The screen should no longer sit on loading for multiple minutes because XMLTV parsing is slow.
