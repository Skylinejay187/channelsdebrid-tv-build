# Season/Episode Crash + Trailer 1080p Patch

## Android TV fixes

- Wrapped the entire Stremio series metadata episode fetch path in `runCatching` so bad/slow addon responses cannot crash the season/episode screen.
- Added raw and URL-encoded series meta-id lookup attempts for `/meta/series/{id}.json` to better support addon ids containing special characters.
- Disconnects episode metadata HTTP connections after each attempt.
- Detail page trailer resolving now sends stricter backend hints: `type`, `externalId`, `quality`, `strictTitle=true`, and `officialOnly=true`.
- Trailer playback now defaults to 1080p standard behavior. 4K is only allowed when the `prefer4k` trailer setting is enabled.
- Default `prefer4k` setting changed from true to false.
- ExoPlayer trailer track selector now caps adaptive playback at 1920x1080 by default instead of forcing highest supported bitrate.
- Added a local title-sanity guard so older backend responses with an obviously mismatched trailer title are rejected instead of played.

## Build note

This zip still uses the repo's existing Gradle wrapper behavior. Local build verification was not possible in this environment because `./gradlew` exits with: `Gradle is not installed. Install Gradle 8.7+ or use the provided GitHub Actions workflow.`
