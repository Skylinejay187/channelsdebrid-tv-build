# Layout Engine Refactor v1.2.7

- Added default values to `HomeLayoutSettings` so new layout options cannot break older callers.
- Added `HomeLayoutDefaults` as the single source of truth for Arvio-style default positioning.
- Added `sanitized()` bounds to prevent impossible values from the live editor.
- SettingsRepository now saves/loads sanitized values only.
- Reset now clears every layout key, including menu offset and bottom safe spacing.
- HomeLayoutEditor now starts from `HomeLayoutSettings()` defaults instead of a hard-coded constructor list.
