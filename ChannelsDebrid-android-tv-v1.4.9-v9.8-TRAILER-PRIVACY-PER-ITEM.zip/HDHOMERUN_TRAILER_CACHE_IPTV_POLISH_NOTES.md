# v1.1.2 HDHomeRun + trailer/cache/IPTV reliability polish

- Added native HDHomeRun tuner discovery through SiliconDust discovery endpoints and `hdhomerun.local` fallback.
- Live TV now imports HDHomeRun lineup channels as a separate `HDHomeRun` tuner/source with HDHR categories and status badge.
- HDHomeRun stream URLs are treated as TS/native tuner streams for preview and player handoff.
- Removed the visible outer/border line from the Live TV preview box.
- Increased home artwork preloading windows for faster hero/card transitions while keeping controlled TV-safe limits.
- Tightened trailer backend policy so wrong/random trailers are rejected instead of silently playing mismatched results.
- Backend live source API now accepts `hdhomerun`/`hdhr`, has stable IDs, data-dir override, source remove route, and richer refresh response.
- Android settings backend push now retries source sync up to 3 times before reporting failure.
