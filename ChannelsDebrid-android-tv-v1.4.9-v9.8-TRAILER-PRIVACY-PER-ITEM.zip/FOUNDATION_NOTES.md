# Channels Debrid Foundation Package

This package keeps the current Android TV rail behavior and adds the first backend/catalog foundation files.

Included:
- Android TV app package from v8.19 UI baseline
- backend starter scaffold for dynamic catalogs
- `/api/home` starter endpoint
- TMDB-backed internal catalog source scaffold
- Stremio addon catalog source scaffold
- row configuration JSON
- Android DTO and settings scaffold models

Not fully wired yet:
- live Channels DVR playback
- IPTV/Xtream playback
- full guide UI
- real trailer popup implementation
- real timeshift/cache execution
- settings screens

This is the starter foundation requested before those next integration phases.
