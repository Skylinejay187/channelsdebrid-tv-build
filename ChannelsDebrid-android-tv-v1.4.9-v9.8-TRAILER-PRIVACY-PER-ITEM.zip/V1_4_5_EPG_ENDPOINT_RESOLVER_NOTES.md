# v1.4.5 EPG Endpoint Resolver

This build locks in the Live TV guide data pipeline across source types.

## Added
- Channels DVR XMLTV endpoint resolver:
  - `/devices/ANY/guide/xmltv?duration=1209600`
- In-memory XMLTV parsing and channel/program matching.
- Xtream Codes EPG resolver:
  - `get_short_epg`
  - fallback `get_simple_data_table`
- Smart guide key selection:
  - Channels DVR prefers `tvg-id`, guide number, channel number/name.
  - Xtream prefers `streamId` for EPG requests.
- Fallback still calls backend guide endpoints if direct source EPG fails.
- Missing EPG stays as `No information` instead of fake generated program titles.

## Matching order
1. Exact guide/tvg/channel ID.
2. Channel number.
3. Display name.
4. Normalized/fuzzy-safe name key.

## Kept
- M3U support.
- Xtream Codes support.
- Channels DVR support.
- HDHomeRun support.
- Live TV instant channel cache.
- Google TV-style guide layout.
