# v1.4.0 Google TV Style Live Guide

Base: v1.3.6 smart live source build.

## Live TV layout rebuild
- Full-screen guide opens immediately.
- Left category rail now shows category name and channel count from synced channel groups.
- Main guide hides channel numbers and uses channel logos/initial logo tiles only.
- Hero/program info area is visible above the guide like the Google TV Free Channels reference.
- Top-right preview window remains visible, but playback does not auto-start when moving focus.
- Press OK once on a channel/program row to start the top-right preview.
- Press OK again while preview is active to expand into full-screen playback.
- Focus bounce/zoom remains disabled.
- Existing M3U, Xtream Codes, Channels DVR, and HDHomeRun support remains intact.
- Existing instant Live TV cache behavior remains intact.

## Backend source aliases
The backend live source route now accepts additional aliases:
- xtream_codes / xc / stream_codes -> xtream
- playlist / m3u8 -> m3u
- hdhr / hd_home_run -> hdhomerun

Important: If the app points to an external backend at `192.168.x.x`, that backend must also be updated/restarted with this package for the alias fix to take effect.
