# Series Details Detection Fix

- Fixes TV shows that opened with a `Play` button instead of `Browse Episodes` when a catalog/backend row mislabeled series as movie/featured.
- MediaDetailsActivity now probes Cinemeta by title and upgrades the details page to series mode when a series match is found.
- SeasonEpisodeActivity now tries multiple series ID candidates: original ID, title-resolved Cinemeta ID, and base IMDb ID variants.
- Keeps movie playback unchanged.
