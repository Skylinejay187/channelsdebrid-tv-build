# v1.4.7 Live TV 12-hour Guide + Crash Guard Fix

Changes added:

- Changed Channels DVR XMLTV first-pass guide load from 24 hours to 12 hours (`duration=43200`).
- Added extended background guide cache pass using a 24-hour XMLTV window after the fast 12-hour guide is displayed.
- Kept the Live TV channel list non-blocking: channels render first, guide data fills in afterward.
- Added crash guards around guide program resolution and guide render merging.
- Ensured empty/missing program lists fall back to safe `No information` blocks instead of crashing when `channelPrograms[0]` is accessed.
- Cached channel lineups now also start a 12-hour guide refresh immediately instead of only waiting for a source refresh.

Reason:

The prior fix improved loading speed, but EPG merge/render could still show blank data or crash when XMLTV matching returned no programs for a channel. This patch makes the guide path fault-tolerant and faster.
