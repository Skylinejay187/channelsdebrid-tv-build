@ECHO OFF
SET DIR=%~dp0
CD /D %DIR%
where gradle >NUL 2>NUL
IF %ERRORLEVEL%==0 (
  gradle %*
  EXIT /B %ERRORLEVEL%
)
ECHO Gradle is not installed. Install Gradle 8.7+ or use the provided GitHub Actions workflow. 1>&2
EXIT /B 1
