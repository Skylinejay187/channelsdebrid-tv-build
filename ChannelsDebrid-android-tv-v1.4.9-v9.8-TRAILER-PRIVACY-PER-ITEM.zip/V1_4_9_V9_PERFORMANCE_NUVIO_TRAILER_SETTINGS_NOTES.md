# Android TV v1.4.9 - v9 Performance + Nuvio-style Trailer Settings

Added/expanded:

- Trailer Playback Location setting:
  - `details`
  - `hero`
  - `both`
  - `off`
- Hero background trailer autoplay is re-enabled behind the setting.
- Details page respects the same setting, so trailers can be details-only, hero-only, both, or disabled.
- Backend trailer cache remains the resolver/prewarm layer; Android uses Media3/ExoPlayer playback in the Nuvio-style framework approach.
- Build version bumped to `1.4.9-v9-performance`.

Important:

NuvioTV is GPL-3.0, so this patch follows its playback architecture conceptually using your existing Media3 implementation instead of directly copying Nuvio source files.
