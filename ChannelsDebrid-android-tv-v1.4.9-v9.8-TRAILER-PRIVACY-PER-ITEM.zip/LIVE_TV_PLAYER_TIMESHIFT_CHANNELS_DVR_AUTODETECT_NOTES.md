# Live TV player + Channels DVR auto-detect patch v1.1.5

- Added a dedicated Live TV Media3/ExoPlayer profile with lower live buffers and live offset targeting.
- Live playback controls now expose pause, rewind, fast-forward and timeshift status using the existing player control bar.
- Remote media keys now work in Live TV for pause/play, rewind and fast-forward.
- DPAD center opens the control bar or toggles pause/play when the controls are visible.
- DPAD left/right seek within the live timeshift window when the controls are visible; left/right still changes channels in Quick Guide.
- Channels DVR can now auto-detect common local servers when no manual IP is entered.
- Channels DVR auto-detect probes channels.local, channels-dvr.local, common local IPs, and current subnet candidates on port 8089.
