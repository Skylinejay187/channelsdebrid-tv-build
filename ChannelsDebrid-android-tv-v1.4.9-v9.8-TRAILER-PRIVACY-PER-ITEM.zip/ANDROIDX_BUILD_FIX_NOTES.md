# AndroidX Build Fix

Patched from the GitHub Actions log error: AndroidX dependencies were present but `android.useAndroidX` was not enabled.
