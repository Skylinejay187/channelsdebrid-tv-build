# v1.4.1 Exact Google TV Live Guide Skin

Base: v1.4.0 Google TV Style Live Guide.

Changes:
- Tightened the Live TV guide skin toward the Google TV Free Channels reference.
- Added hero/background artwork layer behind the guide.
- Hero background updates from focused channel artwork when available, with local artwork fallback.
- Added Google TV-style dark horizontal/vertical scrim overlay.
- Reworked category rail into icon + title + channel-count rows.
- Selected category now uses the bright white pill style.
- Unselected category icons use dark circular icon chips.
- Added red now/current-time color treatment.
- Updated guide program blocks to use bright focused card and dark unfocused blocks.
- Kept logo-only channel column.
- Kept OK once to preview, OK again to full-screen behavior.
- Preview frame stays hidden until the first OK press so the default guide matches the reference more closely.
- Source support remains unchanged: M3U, Xtream Codes, Channels DVR, and HDHomeRun.
- Live TV cache behavior is retained from v1.3.4/v1.4.0.

Notes:
- Real program fanart depends on backend/EPG metadata availability.
- Fallback order is channel artwork/logo, then bundled artwork.
