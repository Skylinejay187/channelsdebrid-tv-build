# v1.3.6 Smart Live Source + Build Fix

Base: v1.3.5 dynamic hero/resume/search icon package.

Included:
- Fixed Kotlin compile issue in SearchActivity (`singleLine` -> `setSingleLine(true)`).
- Keeps M3U, Xtream Codes, Channels DVR, and HDHomeRun support intact.
- Keeps instant Live TV cache behavior from v1.3.4/v1.3.5 base.
- Backend sync still posts to `/live/sources/connect` and refreshes `/live/refresh` after success.
- Better error-body display remains enabled for backend HTTP errors.

Live TV cache behavior:
- First successful Live TV load saves channel/category basics locally.
- Later app starts can preload/open from cache instantly while refreshing in background.

Next recommended step:
- Full Live TV layout rebuild without changing supported source types.
