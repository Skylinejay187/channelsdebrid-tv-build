Debrid Channels premium icon assets added automatically.

Included:
- Launcher icons: app/src/main/res/mipmap-*/ic_launcher.png
- Round icons: app/src/main/res/mipmap-*/ic_launcher_round.png
- Adaptive icons: app/src/main/res/mipmap-anydpi-v26/
- Android TV banner: app/src/main/res/drawable/banner.png
- Splash branding reference: app/src/main/res/drawable-nodpi/splash_branding.png

Source art used:
- Dark glass icon
- Retro black TV banner with antennas
