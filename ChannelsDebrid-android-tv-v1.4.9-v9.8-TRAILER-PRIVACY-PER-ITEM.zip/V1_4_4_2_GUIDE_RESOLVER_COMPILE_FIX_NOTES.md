# v1.4.4.2 Guide Resolver Compile Fix

- Fixed Kotlin expression-body return error in LiveGuideProgramResolver.
- Preserved guide endpoint fallback parsing and EPG mapping behavior.
- Continues v1.4.4.1 safe guide/channel matching work.
