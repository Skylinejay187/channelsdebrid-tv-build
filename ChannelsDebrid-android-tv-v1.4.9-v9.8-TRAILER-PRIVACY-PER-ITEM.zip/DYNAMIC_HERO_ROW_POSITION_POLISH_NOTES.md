# v1.1.6 Dynamic Hero + Row Position Polish

- Rows now sit lower near the bottom safe area to expose more hero artwork.
- Hero art auto-rotates from the daily loaded movie/show mix when idle.
- Focused content cards still immediately control the hero artwork.
- Auto-rotation pauses while a card is focused or navigation is moving.
