# Channels Debrid Android TV v1.3.0 - Pro Layout Editor Advanced Effects

Built on top of v1.2.9.1.

Added to Pro Layout Editor:
- Glow strength control
- Pulse strength control placeholder stored locally for future animation expansion
- Focus ring on/off
- Focus ring thickness
- Focus ring color presets
- 3D card tilt
- Card lift
- Corner radius
- Dim unfocused cards
- Top menu icon style options
- Top menu font selector
- Hero text font selector
- Row title icons on/off

Home UI cleanup:
- Removed ugly row subtitles like `Backend catalog • 12 items` from catalog rows.
- Row labels now support icons, for example Movies, Shows, Live, Featured, Popular, Catalog rows.
- Saved settings remain local through SharedPreferences.

Note:
- Font selector uses Android built-in font families for now to avoid bloating APK size. A larger bundled font asset library can be added later.
