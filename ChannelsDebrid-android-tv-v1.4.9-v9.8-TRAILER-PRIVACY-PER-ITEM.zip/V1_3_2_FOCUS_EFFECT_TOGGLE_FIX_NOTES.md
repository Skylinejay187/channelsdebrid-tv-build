# v1.3.2 Focus Effect Toggle Fix

This patch fixes the stuck cyan outline/glow seen on focused cards.

## Fixed
- Focus Ring OFF now fully removes the focused ring.
- Glow Strength 0 now fully removes the glow layer.
- Top sheen no longer forces a cyan outline when ring/glow are disabled.
- Unfocused cards keep only a subtle neutral border.
- Glass Card Mode still shows a light sheen only when enabled.

The visible stuck effect was the Focus Ring + Top Sheen layer.
