# Detail Trailer + Card Trailer Removal Patch

Changes in this zip:

- Removed home/focused-card trailer preview triggers.
  - Cards no longer autoplay trailer previews.
  - Cards no longer show the “Press OK to expand trailer” preview flow.
  - Card click/OK now goes straight to the normal launch flow.

- Kept trailers on the media detail page only.

- Moved the detail-page trailer mute control to a floating transparent top-right button.
  - Text toggles between `Unmute Trailer` and `Mute Trailer`.

- Added detail-page trailer mode setting.
  - `fullscreen`: current full-screen detail background trailer behavior.
  - `popup_button`: detail page shows a `Play Trailer` button and opens the trailer in a centered popup.

- Updated trailer settings UI copy to clarify trailers are detail-page only.

Build note: local APK build could not be run in this container because the Gradle wrapper reports that Gradle is not installed and directs builds to GitHub Actions.
