v9.8 Trailer privacy + per-item playback fix

- Removed the visible YouTube API key field from Settings.
- Removed the hardcoded YouTube API key default from SettingsRepository.
- Existing saved trailer YouTube API key is removed on trailer settings save.
- Home hero trailer requests now include mediaId/mediaType so backend cache is scoped per focused movie/show instead of reusing the first resolved trailer.
- Added hero trailer scheduling to the alternate card focus path so every focused card can request its own trailer, not only the first-row clean-card path.
- Kept v9.7 Live TV selection box, v9.6 red guide progress sync, preview audio behavior, HDHomeRun restore, channel icons, and full channel/category loading.
