import { Router } from "express"

function normalizeTitle(value: string): string[] {
  return value.toLowerCase().replace(/[^a-z0-9 ]/g, " ").split(/\s+/).filter(w => w.length > 2 && !["the", "and", "official", "trailer", "teaser", "clip", "movie", "series", "season"].includes(w))
}

export function trailersRouter() {
  const router = Router()

  router.get("/trailers/resolve", async (req, res) => {
    const title = String(req.query.title ?? "").trim()
    const year = String(req.query.year ?? "").trim()
    const quality = String(req.query.quality ?? "1080p")
    const prefer4k = String(req.query.prefer4k ?? "false") === "true"
    if (!title) {
      res.status(400).json({ ok: false, error: "title missing" })
      return
    }

    // This endpoint intentionally does not return a random/fuzzy trailer.
    // Native app-side matching will only play when a backend/plugin gives a direct, exact trailer stream.
    res.json({
      ok: false,
      error: "No exact direct trailer stream configured",
      policy: {
        title,
        year,
        requestedQuality: prefer4k ? "2160p-or-1080p" : "1080p",
        strictTitle: true,
        officialOnly: true,
        blockedFallbacks: ["fan", "clip", "teaser", "wrong-title", "random-result"]
      },
      normalizedWords: normalizeTitle(title),
      quality
    })
  })

  return router
}
