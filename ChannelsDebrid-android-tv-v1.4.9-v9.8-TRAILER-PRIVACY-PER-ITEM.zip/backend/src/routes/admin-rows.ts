import { Router } from "express"
import { loadRowConfig, saveRowConfig } from "../catalog/config-store"
import { CatalogRowDefinition } from "../catalog/types"

export function adminRowsRouter() {
  const router = Router()

  router.get("/api/admin/rows", async (_req, res, next) => {
    try {
      res.json({ rows: await loadRowConfig() })
    } catch (err) {
      next(err)
    }
  })

  router.post("/api/admin/rows", async (req, res, next) => {
    try {
      const rows = await loadRowConfig()
      const row = req.body as CatalogRowDefinition
      rows.push(row)
      await saveRowConfig(rows)
      res.json({ ok: true })
    } catch (err) {
      next(err)
    }
  })

  router.put("/api/admin/rows/:id", async (req, res, next) => {
    try {
      const rows = await loadRowConfig()
      const updated = rows.map(r => r.id === req.params.id ? { ...r, ...req.body } : r)
      await saveRowConfig(updated)
      res.json({ ok: true })
    } catch (err) {
      next(err)
    }
  })

  router.post("/api/admin/rows/reorder", async (req, res, next) => {
    try {
      const order = req.body.order as string[]
      const rows = await loadRowConfig()
      const updated = rows.map(r => ({ ...r, position: Math.max(0, order.indexOf(r.id)) + 1 }))
      await saveRowConfig(updated)
      res.json({ ok: true })
    } catch (err) {
      next(err)
    }
  })

  router.delete("/api/admin/rows/:id", async (req, res, next) => {
    try {
      const rows = await loadRowConfig()
      const updated = rows.filter(r => r.id !== req.params.id)
      await saveRowConfig(updated)
      res.json({ ok: true })
    } catch (err) {
      next(err)
    }
  })

  return router
}
