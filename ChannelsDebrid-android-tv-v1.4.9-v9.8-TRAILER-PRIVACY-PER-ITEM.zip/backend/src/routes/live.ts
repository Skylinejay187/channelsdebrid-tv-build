import { Router } from "express"
import fs from "node:fs/promises"
import path from "node:path"

interface LiveSource {
  id: string
  userId: string
  type: "m3u" | "xtream" | "channels_dvr" | "hdhomerun"
  name: string
  url: string
  username?: string
  password?: string
  updatedAt: string
}

type EpgRefreshState = "idle" | "running" | "complete" | "failed"

interface CachedProgram {
  channelId: string
  title: string
  start: string
  stop: string
  description?: string
  imageUrl?: string
  sourceId?: string
  sourceName?: string
}

interface EpgCache {
  userId: string
  generatedAt: string
  durationHours: number
  programsByKey: Record<string, CachedProgram[]>
  stats: { sourcesScanned: number; channelsMapped: number; programsCached: number; unmappedChannels: number }
}

interface EpgStatus {
  userId: string
  state: EpgRefreshState
  message: string
  startedAt?: string
  completedAt?: string
  lastUpdated?: string
  nextRefreshAt?: string
  refreshEveryHours: number
  durationHours: number
  sourcesScanned: number
  currentSource?: string
  channelsMapped: number
  programsCached: number
  unmappedChannels: number
  errors: string[]
}

const DATA_DIR = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(process.cwd(), "backend", "data")
const SOURCES_PATH = path.join(DATA_DIR, "live-sources.json")
const EPG_CACHE_PATH = path.join(DATA_DIR, "live-epg-cache.json")
const EPG_STATUS_PATH = path.join(DATA_DIR, "live-epg-status.json")
const EPG_SETTINGS_PATH = path.join(DATA_DIR, "live-epg-settings.json")

let epgRefreshRunning = false
let epgSchedulerStarted = false

async function readJsonFile<T>(file: string, fallback: T): Promise<T> {
  try { return JSON.parse(await fs.readFile(file, "utf8")) as T } catch { return fallback }
}

async function writeJsonFile(file: string, value: unknown): Promise<void> {
  await fs.mkdir(DATA_DIR, { recursive: true })
  await fs.writeFile(file, JSON.stringify(value, null, 2), "utf8")
}

async function loadSources(): Promise<LiveSource[]> {
  return readJsonFile<LiveSource[]>(SOURCES_PATH, [])
}

async function saveSources(sources: LiveSource[]): Promise<void> {
  await writeJsonFile(SOURCES_PATH, sources)
}

async function loadEpgSettings(): Promise<{ refreshEveryHours: number; durationHours: number }> {
  return readJsonFile(EPG_SETTINGS_PATH, { refreshEveryHours: 6, durationHours: 12 })
}

function normalizeGuideKey(value: string): string {
  return String(value || "").toLowerCase().replace(/\b(uhd|fhd|hd|4k|sd)\b/g, "").replace(/[^a-z0-9]+/g, "").trim()
}

function xmlUnescape(value: string): string {
  return String(value || "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'")
}

function attr(attrs: string, name: string): string {
  return xmlUnescape(new RegExp(`${name}="([^"]*)"`, "i").exec(attrs)?.[1] ?? "")
}

function tag(body: string, name: string): string {
  return xmlUnescape(new RegExp(`<${name}[^>]*>([\\s\\S]*?)</${name}>`, "i").exec(body)?.[1]?.trim() ?? "")
}

function addProgramKey(map: Record<string, CachedProgram[]>, key: string, program: CachedProgram) {
  const clean = String(key || "").trim()
  if (!clean) return
  for (const nextKey of [clean, normalizeGuideKey(clean)].filter(Boolean)) {
    const bucket = map[nextKey] ?? (map[nextKey] = [])
    if (!bucket.some(p => p.channelId === program.channelId && p.start === program.start && p.title === program.title)) bucket.push(program)
  }
}

function mergeProgramMaps(target: Record<string, CachedProgram[]>, incoming: Record<string, CachedProgram[]>) {
  for (const [key, programs] of Object.entries(incoming)) {
    const bucket = target[key] ?? (target[key] = [])
    for (const p of programs) {
      if (!bucket.some(existing => existing.channelId === p.channelId && existing.start === p.start && existing.title === p.title)) bucket.push(p)
    }
    target[key] = bucket.sort((a, b) => String(a.start).localeCompare(String(b.start))).slice(0, 24)
  }
}

async function fetchText(url: string, accept = "application/json,text/xml,*/*", timeoutMs = 45000): Promise<string> {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const response = await fetch(url, { headers: { Accept: accept }, signal: controller.signal })
    if (!response.ok) return ""
    return await response.text()
  } catch {
    return ""
  } finally {
    clearTimeout(timer)
  }
}

function parseXmltv(xml: string, source: LiveSource): Record<string, CachedProgram[]> {
  const namesById: Record<string, string[]> = {}
  const channelRegex = /<channel\s+[^>]*id="([^"]+)"[^>]*>([\s\S]*?)<\/channel>/gi
  let channelMatch: RegExpExecArray | null
  while ((channelMatch = channelRegex.exec(xml)) !== null) {
    const id = xmlUnescape(channelMatch[1].trim())
    const names = new Set<string>([id])
    const body = channelMatch[2]
    const displayRegex = /<display-name[^>]*>([\s\S]*?)<\/display-name>/gi
    let displayMatch: RegExpExecArray | null
    while ((displayMatch = displayRegex.exec(body)) !== null) names.add(xmlUnescape(displayMatch[1].trim()))
    namesById[id] = Array.from(names).filter(Boolean)
  }

  const programsByKey: Record<string, CachedProgram[]> = {}
  const programRegex = /<programme\s+([^>]*)>([\s\S]*?)<\/programme>/gi
  let programMatch: RegExpExecArray | null
  while ((programMatch = programRegex.exec(xml)) !== null) {
    const attrs = programMatch[1]
    const body = programMatch[2]
    const channelId = attr(attrs, "channel")
    if (!channelId) continue
    const program: CachedProgram = {
      channelId,
      title: tag(body, "title") || "No information",
      start: attr(attrs, "start"),
      stop: attr(attrs, "stop"),
      description: tag(body, "desc"),
      imageUrl: /<icon[^>]*src="([^"]+)"/i.exec(body)?.[1] ?? "",
      sourceId: source.id,
      sourceName: source.name,
    }
    for (const name of (namesById[channelId] ?? [channelId])) addProgramKey(programsByKey, name, program)
  }
  for (const key of Object.keys(programsByKey)) programsByKey[key] = programsByKey[key].sort((a, b) => String(a.start).localeCompare(String(b.start))).slice(0, 24)
  return programsByKey
}

async function saveStatus(status: EpgStatus) { await writeJsonFile(EPG_STATUS_PATH, status) }

async function runEpgRefresh(userId: string, durationHours = 12): Promise<EpgStatus> {
  const settings = await loadEpgSettings()
  if (epgRefreshRunning) {
    return readJsonFile<EpgStatus>(EPG_STATUS_PATH, { userId, state: "running", message: "EPG refresh already running", refreshEveryHours: settings.refreshEveryHours, durationHours, sourcesScanned: 0, channelsMapped: 0, programsCached: 0, unmappedChannels: 0, errors: [] })
  }
  epgRefreshRunning = true
  let status: EpgStatus = { userId, state: "running", message: "Starting EPG refresh", startedAt: new Date().toISOString(), refreshEveryHours: settings.refreshEveryHours, durationHours, sourcesScanned: 0, channelsMapped: 0, programsCached: 0, unmappedChannels: 0, errors: [] }
  await saveStatus(status)
  try {
    const sources = (await loadSources()).filter(s => s.userId === userId)
    const programsByKey: Record<string, CachedProgram[]> = {}
    for (const source of sources) {
      status.currentSource = source.name
      status.message = `Downloading ${source.name} guide data…`
      await saveStatus(status)
      if (source.type === "channels_dvr") {
        const base = source.url.trim().replace(/\/+$/, "")
        const xml = await fetchText(`${base}/devices/ANY/guide/xmltv?duration=${durationHours * 3600}`, "application/xml,text/xml,*/*")
        if (xml) mergeProgramMaps(programsByKey, parseXmltv(xml, source))
        else status.errors.push(`${source.name}: empty XMLTV response`)
      } else {
        status.errors.push(`${source.name}: ${source.type} cached EPG parser is queued for next pass`)
      }
      status.sourcesScanned += 1
      status.programsCached = Object.values(programsByKey).reduce((sum, items) => sum + items.length, 0)
      status.channelsMapped = Object.keys(programsByKey).length
      await saveStatus(status)
    }
    const completedAt = new Date()
    const cache: EpgCache = { userId, generatedAt: completedAt.toISOString(), durationHours, programsByKey, stats: { sourcesScanned: status.sourcesScanned, channelsMapped: Object.keys(programsByKey).length, programsCached: Object.values(programsByKey).reduce((sum, items) => sum + items.length, 0), unmappedChannels: 0 } }
    await writeJsonFile(EPG_CACHE_PATH, cache)
    status = { ...status, state: "complete", message: "EPG refresh complete", completedAt: completedAt.toISOString(), lastUpdated: completedAt.toISOString(), nextRefreshAt: settings.refreshEveryHours > 0 ? new Date(completedAt.getTime() + settings.refreshEveryHours * 3600_000).toISOString() : undefined, currentSource: undefined, channelsMapped: cache.stats.channelsMapped, programsCached: cache.stats.programsCached, unmappedChannels: cache.stats.unmappedChannels }
    await saveStatus(status)
    return status
  } catch (err: any) {
    status = { ...status, state: "failed", message: err?.message ?? "EPG refresh failed", completedAt: new Date().toISOString(), errors: [...status.errors, String(err?.message ?? err)] }
    await saveStatus(status)
    return status
  } finally {
    epgRefreshRunning = false
  }
}

function startEpgScheduler() {
  if (epgSchedulerStarted) return
  epgSchedulerStarted = true
  setInterval(async () => {
    const settings = await loadEpgSettings()
    if (settings.refreshEveryHours <= 0 || epgRefreshRunning) return
    const last = await readJsonFile<EpgStatus | null>(EPG_STATUS_PATH, null)
    const lastTime = last?.lastUpdated || last?.completedAt || ""
    const due = !lastTime || Date.now() - new Date(lastTime).getTime() >= settings.refreshEveryHours * 3600_000
    if (due) void runEpgRefresh(last?.userId || "demo", settings.durationHours)
  }, 5 * 60 * 1000)
}

export function liveRouter() {
  const router = Router()

  router.get("/live/sources", async (req, res, next) => {
    try {
      const userId = String(req.query.user_id ?? req.query.userId ?? "demo")
      const sources = (await loadSources()).filter(s => s.userId === userId)
      res.json({ ok: true, sources })
    } catch (err) { next(err) }
  })

  router.post("/live/sources/connect", async (req, res, next) => {
    try {
      const body = req.body ?? {}
      const userId = String(body.userId ?? body.user_id ?? "demo").trim() || "demo"
      let type = String(body.type ?? "").trim().toLowerCase() as LiveSource["type"]
      const url = String(body.url ?? body.sourceUrl ?? body.m3uUrl ?? body.server ?? body.baseUrl ?? "").trim()
      const name = String(body.name ?? (type ? type.toUpperCase() : "Live Source")).trim() || (type ? type.toUpperCase() : "Live Source")
      if (type === "iptv") type = "m3u" as LiveSource["type"]
      if (type === "hdhr" || type === "hd_home_run") type = "hdhomerun" as LiveSource["type"]
      if (type === "xtream_codes" || type === "xc" || type === "stream_codes") type = "xtream" as LiveSource["type"]
      if (type === "playlist" || type === "m3u8") type = "m3u" as LiveSource["type"]
      if (!["m3u", "xtream", "channels_dvr", "hdhomerun"].includes(type)) return res.status(400).json({ ok: false, error: "Unsupported live source type" })
      if (!url) return res.status(400).json({ ok: false, error: "Live source URL missing", received: Object.keys(body) })
      const sources = await loadSources()
      const stableKey = `${type}:${url}:${body.username ? String(body.username) : ""}`
      const id = `${userId}_${type}_${Buffer.from(stableKey).toString("base64url").slice(0, 24)}`
      const nextSource: LiveSource = { id, userId, type, name, url, username: body.username ? String(body.username) : undefined, password: body.password ? String(body.password) : undefined, updatedAt: new Date().toISOString() }
      const withoutOld = sources.filter(s => s.id !== id)
      withoutOld.push(nextSource)
      await saveSources(withoutOld)
      res.json({ ok: true, source: { ...nextSource, password: nextSource.password ? "***" : undefined } })
    } catch (err) { next(err) }
  })

  router.post("/live/sources/remove", async (req, res, next) => {
    try {
      const userId = String(req.body?.userId ?? req.body?.user_id ?? "demo")
      const id = String(req.body?.id ?? "")
      const before = await loadSources()
      const after = before.filter(s => !(s.userId === userId && s.id === id))
      await saveSources(after)
      res.json({ ok: true, removed: before.length - after.length, sources: after.filter(s => s.userId === userId) })
    } catch (err) { next(err) }
  })

  router.get("/live/bootstrap", async (req, res, next) => {
    try {
      const userId = String(req.query.user_id ?? req.query.userId ?? "demo")
      const sources = (await loadSources()).filter(s => s.userId === userId)
      const cache = await readJsonFile<EpgCache | null>(EPG_CACHE_PATH, null)
      res.json({ ok: true, userId, cached: !!cache, refreshedAt: cache?.generatedAt ?? new Date().toISOString(), sources: sources.map(s => ({ id: s.id, type: s.type, name: s.name, url: s.url, username: s.username, updatedAt: s.updatedAt })), categories: [], channels: [], nowPlaying: {}, nextPrograms: {} })
    } catch (err) { next(err) }
  })

  router.post("/live/refresh", async (req, res) => {
    const userId = String(req.body?.userId ?? req.body?.user_id ?? "demo")
    const sources = (await loadSources()).filter(s => s.userId === userId)
    res.json({ ok: true, userId, sourceCount: sources.length, sources: sources.map(s => ({ id: s.id, type: s.type, name: s.name, url: s.url, updatedAt: s.updatedAt })), refreshedAt: new Date().toISOString() })
  })

  router.get("/live/epg/status", async (req, res, next) => {
    try {
      const settings = await loadEpgSettings()
      const fallback: EpgStatus = { userId: String(req.query.user_id ?? req.query.userId ?? "demo"), state: "idle", message: "EPG has not been refreshed yet", refreshEveryHours: settings.refreshEveryHours, durationHours: settings.durationHours, sourcesScanned: 0, channelsMapped: 0, programsCached: 0, unmappedChannels: 0, errors: [] }
      res.json({ ok: true, status: await readJsonFile(EPG_STATUS_PATH, fallback) })
    } catch (err) { next(err) }
  })

  router.post("/live/epg/settings", async (req, res, next) => {
    try {
      const refreshEveryHours = Math.max(0, Number(req.body?.refreshEveryHours ?? req.body?.hours ?? 6) || 0)
      const durationHours = Math.max(1, Math.min(48, Number(req.body?.durationHours ?? 12) || 12))
      const settings = { refreshEveryHours, durationHours }
      await writeJsonFile(EPG_SETTINGS_PATH, settings)
      res.json({ ok: true, settings })
    } catch (err) { next(err) }
  })

  router.post("/live/epg/refresh", async (req, res, next) => {
    try {
      const userId = String(req.body?.userId ?? req.body?.user_id ?? "demo")
      const durationHours = Math.max(1, Math.min(48, Number(req.body?.durationHours ?? req.body?.hours ?? 12) || 12))
      void runEpgRefresh(userId, durationHours)
      res.json({ ok: true, status: { state: "running", message: "EPG refresh queued/running", durationHours } })
    } catch (err) { next(err) }
  })

  router.get("/live/guide", async (req, res, next) => {
    try {
      const cache = await readJsonFile<EpgCache | null>(EPG_CACHE_PATH, null)
      if (!cache) return res.json({ ok: true, cached: false, programs: [] })
      const keys = [String(req.query.tvgId ?? req.query.tvg_id ?? ""), String(req.query.channelNumber ?? req.query.number ?? ""), String(req.query.channelName ?? req.query.name ?? "")].flatMap(v => [v.trim(), normalizeGuideKey(v)]).filter(Boolean)
      const programs = keys.map(k => cache.programsByKey[k]).find(arr => arr && arr.length) ?? []
      res.json({ ok: true, cached: true, generatedAt: cache.generatedAt, programs })
    } catch (err) { next(err) }
  })

  startEpgScheduler()
  return router
}
