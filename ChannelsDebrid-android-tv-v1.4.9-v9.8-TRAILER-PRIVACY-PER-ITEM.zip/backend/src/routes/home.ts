import { Router } from "express"
import { loadRowConfig } from "../catalog/config-store"
import { CatalogManager } from "../catalog/catalog-manager"

export function homeRouter(catalogManager: CatalogManager) {
  const router = Router()

  router.get("/api/home", async (_req, res, next) => {
    try {
      const rowDefs = await loadRowConfig()
      const rows = await catalogManager.buildRows(rowDefs)
      const heroItem = rows[0]?.items?.[0]
      const hero = heroItem ? {
        id: heroItem.id,
        type: heroItem.type,
        title: heroItem.title,
        subtitle: heroItem.provider?.name ?? null,
        description: heroItem.description ?? null,
        backdrop: heroItem.backdrop ?? null,
        logo: heroItem.logo ?? null,
        actions: [
          { id: "play", label: "Continue" },
          { id: "details", label: "Details" }
        ]
      } : undefined

      res.json({ hero, rows })
    } catch (err) {
      next(err)
    }
  })

  return router
}
