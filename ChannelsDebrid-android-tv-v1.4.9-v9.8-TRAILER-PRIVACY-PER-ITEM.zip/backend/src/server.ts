import { createApp } from "./app.js"

const port = Number(process.env.PORT ?? 3000)

async function main() {
  const app = await createApp()
  app.listen(port, () => {
    console.log(`Channels Debrid backend listening on :${port}`)
  })
}

main().catch(err => {
  console.error(err)
  process.exit(1)
})
