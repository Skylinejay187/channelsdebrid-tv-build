import { CatalogItem, CatalogRowDefinition } from "./types"

export interface CatalogSource {
  canHandle(row: CatalogRowDefinition): boolean
  getItems(row: CatalogRowDefinition): Promise<CatalogItem[]>
}
