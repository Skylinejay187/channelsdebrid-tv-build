import fs from "node:fs/promises"
import path from "node:path"
import { CatalogRowDefinition } from "./types"

const CONFIG_PATH = path.join(process.cwd(), "backend", "data", "home-rows.json")

export async function loadRowConfig(): Promise<CatalogRowDefinition[]> {
  const raw = await fs.readFile(CONFIG_PATH, "utf8")
  return (JSON.parse(raw) as CatalogRowDefinition[])
    .filter(r => r.enabled)
    .sort((a, b) => a.position - b.position)
}

export async function saveRowConfig(rows: CatalogRowDefinition[]): Promise<void> {
  await fs.writeFile(CONFIG_PATH, JSON.stringify(rows, null, 2), "utf8")
}
