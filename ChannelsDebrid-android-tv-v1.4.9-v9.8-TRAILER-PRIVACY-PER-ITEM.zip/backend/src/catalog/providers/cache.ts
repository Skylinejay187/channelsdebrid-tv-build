const cache = new Map<string, { expiresAt: number; value: unknown }>()

export async function withCache<T>(key: string, ttlMs: number, loader: () => Promise<T>): Promise<T> {
  const current = cache.get(key)
  const now = Date.now()
  if (current && current.expiresAt > now) return current.value as T
  const value = await loader()
  cache.set(key, { expiresAt: now + ttlMs, value })
  return value
}
