# v1.4.8 Backend EPG Force Refresh + Scheduler

This patch moves Live TV guide refresh toward the backend-control-plane design:

- Settings > Live TV Backend now has an EPG refresh schedule selector.
- Settings > Live TV Backend now has a Load / Refresh EPG Guide Data button.
- Live TV now has a Force Refresh Guide quick action.
- Backend now exposes:
  - POST /live/epg/settings
  - POST /live/epg/refresh
  - GET /live/epg/status
  - GET /live/guide
- Backend refresh defaults to a 12-hour guide window.
- Backend scheduler defaults to every 6 hours.
- Backend parses Channels DVR XMLTV, force-maps XMLTV channel IDs/display names to guide keys, and stores cached JSON.
- Android guide resolver now checks backend cached guide first before falling back to direct XMLTV/Xtream lookup.

Current parser coverage:

- Channels DVR XMLTV: implemented.
- Xtream/M3U/HDHomeRun backend cached EPG parser: endpoint shell/status included, detailed parser queued for next pass.

Recommended first use:

1. Open Settings > Live TV Backend.
2. Confirm backend URL and user ID.
3. Set EPG schedule to Every 6 hours.
4. Press Load / Refresh EPG Guide Data.
5. Open Live TV. If needed later, use Force Refresh Guide from the Live TV screen.
