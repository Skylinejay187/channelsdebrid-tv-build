# Dolby Vision + Polish + IPTV Backend Push Patch

Base: season/episode focus-click working build.

## Playback
- Added Dolby Vision detection in source labels based on stream title/description.
- Added Android decoder capability check for `video/dolby-vision`.
- Dolby Vision streams are preferred only when the device advertises DV decode support.
- DV streams are deprioritized on non-DV devices so HDR10/SDR fallbacks are more likely to appear first.
- Player badge row now shows DV / HDR10+ / HDR / HEVC / Atmos where detected.

## Trailer polish
- Kept detail-page-only trailer behavior.
- Trailer resolving remains strict: title/year/type/external ID, official-only, and 1080p standard unless prefer-4K is enabled.

## Episode loading polish
- Cinemeta is now tried first for season/episode metadata to make season browsing faster and more reliable.
- Episode metadata request timeouts were reduced so bad addons fail faster instead of making the screen feel frozen.

## IPTV/backend push
- Added backend `/health` alias because the Android app tests `/health`.
- Added backend live routes used by Settings:
  - `GET /live/sources?user_id=...`
  - `POST /live/sources/connect`
  - `POST /live/refresh`
- IPTV M3U, Xtream, and Channels DVR source payloads are now accepted and saved to `backend/data/live-sources.json`.

## Version
- Android app bumped to 1.0.7 / versionCode 7.
