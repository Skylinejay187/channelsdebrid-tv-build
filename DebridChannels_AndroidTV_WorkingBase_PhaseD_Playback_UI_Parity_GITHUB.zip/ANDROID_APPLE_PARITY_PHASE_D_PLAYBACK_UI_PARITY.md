# Android / Apple UI Parity — Phase D Playback Presentation

**Build:** `NewtoOld_v2.8.26.80_APPLE_PARITY_PLAYBACK_UI_PHASE_D`  
**Base:** Phase C visual-precision project (`v2.8.26.79`) and its protected Android functional core.

## Scope

Phase D replaces the visible player presentation while leaving the existing playback and backend systems in place.

### VOD presentation
- Apple-style bottom presentation scrim.
- Thin pure-black timeline with a separate white position marker.
- Compact black-glass control dock with warm copper/orange focus treatment.
- Existing rewind, play/pause, forward, Switch Link, Episodes, and Player Settings actions remain wired to their prior implementations.
- In-player right-side Audio and Subtitle panels replace the generic track dialogs while retaining Media3 track-selection behavior.
- Dynamic Cast Wall presents one cast member at a time and rotates automatically when TMDB cast data is available.
- Cast control opens the existing media-details route rather than creating a second cast data system.
- Poster, title/logo, metadata, rating, overview, cache state, playback time, and time-of-day remain in the overlay.

### Live TV presentation
- Existing playback, timeshift controls, stream selection, and channel handoff remain unchanged.
- Quick Guide is restyled as the Phase D glass guide and remains an overlay over uninterrupted playback.
- Existing guide selection, immediate tune behavior, timeout, and DPAD routes remain in place.

## Functional-core protection

Not rewritten or replaced:
- Media3/ExoPlayer primary playback.
- VLC/libVLC compatibility fallback.
- Resolver and debrid source selection.
- HTTP headers, stream URLs, and source switching.
- VOD resume and continue-watching persistence.
- Live TV provider handling, guide data, DVR/timeshift, and storage.
- Audio route protection, lifecycle cleanup, watchdogs, cache, and error recovery.

## Test checklist

### VOD
1. Start a movie from a normal catalog, Search, and Favorites.
2. Confirm video starts exactly as in Phase C and the overlay does not trigger a player reopen.
3. Hide/show controls with OK and Back.
4. Test left/right hidden-overlay seeking and dock rewind/forward.
5. Test pause/resume and timeline/white-marker movement.
6. Open Audio and Subtitle panels; select a track; Back returns focus to the originating control.
7. Open Switch Link and verify playback resumes at the retained position.
8. Verify Episodes appears only for series.
9. Verify Cast Wall rotates and Cast opens media details.
10. Exit and reopen to verify resume position.
11. Repeat with a title that uses the VLC fallback.

### Live TV
1. Tune HDHomeRun, Channels DVR, M3U/XMLTV, and Xtream channels.
2. Open/close the Quick Guide and move left/right between channels.
3. Confirm playback continues behind the guide.
4. Test pause, rewind, forward, and Timeshift settings.
5. Exit playback and confirm Phase C exact-card focus restoration still works.

## Validation performed before packaging
- Kotlin PSI syntax parsing for all Kotlin source files.
- XML parsing for all resources.
- Cross-check of new Phase D IDs, layouts, drawables, and colors.
- Diff audit confirming the player engine/resolver/repository/storage implementations were not replaced.

A full Android Gradle compile was not possible in the local artifact container because the Android SDK and Gradle distribution are not installed and outbound shell downloads are disabled. The included GitHub Actions workflow provisions Gradle 8.7 and performs the authoritative `clean assembleDebug bundleRelease` build.
