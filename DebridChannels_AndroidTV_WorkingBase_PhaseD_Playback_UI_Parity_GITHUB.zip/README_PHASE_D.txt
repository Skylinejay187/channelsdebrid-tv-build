Debrid Channels Android TV — Phase D

Build: NewtoOld_v2.8.26.80_APPLE_PARITY_PLAYBACK_UI_PHASE_D
Base: Phase C v2.8.26.79

This ZIP advances the Apple-parity crossover migration to Phase D. It preserves the existing Android playback/resolver/live-TV core and replaces only the visible playback presentation with the new VOD overlay, compact dock, thin timeline, in-player track panels, Cast Wall, and Live TV Quick Guide styling.

See ANDROID_APPLE_PARITY_PHASE_D_PLAYBACK_UI_PARITY.md for the protected systems and device test checklist.
