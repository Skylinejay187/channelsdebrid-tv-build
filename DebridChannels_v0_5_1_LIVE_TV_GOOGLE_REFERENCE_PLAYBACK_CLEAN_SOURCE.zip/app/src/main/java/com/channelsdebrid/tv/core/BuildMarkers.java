package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.5.1 LIVE TV GOOGLE GUIDE PLAYBACK FIX";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.5.1_live_tv_google_reference_playback_clean_base";
    private BuildMarkers() {}
}
