package com.channelsdebrid.tv.playback

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.ui.PlayerView

class UnifiedPlayerManager(private val context: Context, private val ownerName: String) {
    enum class Mode { VOD, LIVE, PREVIEW }

    private var player: ExoPlayer? = null
    private var attachedView: PlayerView? = null
    private var mode: Mode = Mode.PREVIEW

    fun play(view: PlayerView, url: String, mode: Mode, muted: Boolean = false, playWhenReady: Boolean = true): ExoPlayer {
        release("switch-to-${mode.name}")
        this.mode = mode
        attachedView = view

        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("DebridChannelsTV/3.0.0 FullCleanCore")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(if (mode == Mode.VOD) 10000 else 7000)
            .setReadTimeoutMs(if (mode == Mode.VOD) 15000 else 12000)

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                if (mode == Mode.VOD) 5000 else 3500,
                if (mode == Mode.VOD) 30000 else 45000,
                1000,
                if (mode == Mode.VOD) 2500 else 1500
            )
            .setBackBuffer(if (mode == Mode.LIVE) 30 * 60 * 1000 else 0, true)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        val renderersFactory = DefaultRenderersFactory(context)
            .setEnableDecoderFallback(true)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)

        val exo = ExoPlayer.Builder(context, renderersFactory)
            .setMediaSourceFactory(DefaultMediaSourceFactory(httpFactory))
            .setLoadControl(loadControl)
            .setSeekBackIncrementMs(if (mode == Mode.VOD) 10_000 else 30_000)
            .setSeekForwardIncrementMs(if (mode == Mode.VOD) 10_000 else 30_000)
            .build()

        val itemBuilder = MediaItem.Builder().setUri(Uri.parse(url))
        inferMime(url)?.let { itemBuilder.setMimeType(it) }
        if (mode == Mode.LIVE) {
            itemBuilder.setLiveConfiguration(
                MediaItem.LiveConfiguration.Builder()
                    .setTargetOffsetMs(5000)
                    .setMinOffsetMs(1500)
                    .setMaxOffsetMs(30000)
                    .build()
            )
        }
        exo.setMediaItem(itemBuilder.build(), true)
        exo.volume = if (muted) 0f else 1f
        view.player = exo
        player = exo
        Log.i("DebridChannels", "PlayerManager[$ownerName] attach mode=${mode.name} muted=$muted url=${url.take(72)}")
        exo.prepare()
        exo.playWhenReady = playWhenReady
        return exo
    }

    fun current(): ExoPlayer? = player

    fun release(reason: String) {
        val p = player ?: return
        Log.i("DebridChannels", "PlayerManager[$ownerName] release mode=${mode.name} reason=$reason")
        runCatching { p.playWhenReady = false }
        runCatching { p.stop() }
        runCatching { attachedView?.player = null }
        runCatching { p.clearMediaItems() }
        runCatching { p.release() }
        player = null
        attachedView = null
    }

    private fun inferMime(url: String): String? {
        val lower = url.substringBefore('?').lowercase()
        return when {
            lower.endsWith(".m3u8") || lower.contains("m3u8") -> MimeTypes.APPLICATION_M3U8
            lower.endsWith(".mpd") -> MimeTypes.APPLICATION_MPD
            lower.endsWith(".ts") || lower.contains("/auto/v") -> MimeTypes.VIDEO_MP2T
            lower.endsWith(".mp4") -> MimeTypes.VIDEO_MP4
            else -> null
        }
    }
}
