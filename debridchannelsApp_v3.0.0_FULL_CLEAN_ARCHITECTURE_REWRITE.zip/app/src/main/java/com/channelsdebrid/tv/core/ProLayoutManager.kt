package com.channelsdebrid.tv.core

import android.content.Context
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.channelsdebrid.tv.settings.HomeLayoutSettings
import com.channelsdebrid.tv.settings.SettingsRepository
import com.channelsdebrid.tv.settings.homeLayoutTypeface

/**
 * V3 single owner for Pro Layout settings.
 * Keeps the editor, persisted values, and home renderer on the same model.
 */
class ProLayoutManager(context: Context) {
    private val repository = SettingsRepository(context.applicationContext)

    fun load(): HomeLayoutSettings = repository.loadHomeLayout()

    fun save(settings: HomeLayoutSettings) {
        repository.saveHomeLayout(settings)
        Log.i("DebridChannels", "V3_FULL_CLEAN_REWRITE_START component=ProLayoutManager saved menu=${settings.menuCompositionMode} search=${settings.searchItemPlacement} settings=${settings.settingsItemPlacement} rowTitle=${settings.rowTitleVisibility} art=${settings.extraArtworkEnabled}:${settings.extraArtworkType}")
    }

    fun reset() {
        repository.resetHomeLayout()
        Log.i("DebridChannels", "V3_FULL_CLEAN_REWRITE_START component=ProLayoutManager reset")
    }

    fun applyMenuComposition(
        topNav: ViewGroup,
        floatingSearch: View?,
        floatingSettings: View?,
        cfg: HomeLayoutSettings
    ) {
        val integrated = cfg.menuCompositionMode == 1 || cfg.menuCompositionMode == 2
        floatingSearch?.visibility = if (cfg.searchItemPlacement == 0 || (cfg.menuCompositionMode == 2 && cfg.searchItemPlacement != 3)) View.VISIBLE else View.GONE
        floatingSettings?.visibility = if (cfg.settingsItemPlacement == 0 || (cfg.menuCompositionMode == 2 && cfg.settingsItemPlacement != 3)) View.VISIBLE else View.GONE
        topNav.visibility = View.VISIBLE
        topNav.typefaceAll(homeLayoutTypeface(cfg.topMenuFontIndex))
        if (integrated) {
            renameNavItem(topNav, "navSearch", if (cfg.searchItemPlacement == 1) "⌕ Search" else null)
            renameNavItem(topNav, "navSettings", if (cfg.settingsItemPlacement == 1) "⚙ Settings" else null)
        }
        BuildMarkers.trace("ProLayoutManager", "apply menuMode=${cfg.menuCompositionMode} search=${cfg.searchItemPlacement} settings=${cfg.settingsItemPlacement}")
    }

    private fun renameNavItem(root: ViewGroup, resourceName: String, label: String?) {
        val id = root.resources.getIdentifier(resourceName, "id", root.context.packageName)
        if (id == 0) return
        val view = root.findViewById<TextView?>(id) ?: return
        if (label == null) {
            view.visibility = View.GONE
        } else {
            view.visibility = View.VISIBLE
            view.text = label
            view.isFocusable = true
            view.isClickable = true
        }
    }

    private fun ViewGroup.typefaceAll(typeface: android.graphics.Typeface) {
        for (i in 0 until childCount) {
            val child = getChildAt(i)
            if (child is TextView) child.typeface = typeface
            if (child is ViewGroup) child.typefaceAll(typeface)
        }
    }
}
