package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.9.1 Basic Live TV Layout Editor UI";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.9.1_basic_livetv_layout_editor_preview_clean_base";
}
