package com.channelsdebrid.tv.livetv;

import android.graphics.Color;

/**
 * v0.9.0 real Live TV layout engine.
 *
 * This class is the single source of truth for Live TV preset geometry and visual
 * styling. MainActivity must render from this config instead of using hidden
 * hard-coded layout numbers. v0.9.1/v0.9.2 editors will mutate the same fields.
 */
public final class LiveTvLayoutConfig {
    public final String id;
    public String name;
    public final boolean compact;

    public int catLeft, catTop, catWidth, catHeight;
    public int mainLeft, mainTop, mainWidth, mainHeight;
    public int fullLeft, fullTop, fullWidth, fullHeight;

    public int headerHeight;
    public int logoTileW, logoTileH;
    public int titleSp, metaSp, descSp;

    public int previewWidth, previewTop, previewRight;
    public int previewPadding, previewRadius;

    public int timelineHeight, timelineLeftPadding;
    public int[] tickWidths;
    public int redLineX;

    public int wideWidth;
    public int rowLogoWidth, nowCellWidth, nextCellWidth, laterCellWidth, farCellWidth;
    public int rowHeight, rowCellHeight, rowGap;
    public int visibleRows;

    public int categoryIconSize, categoryRowHeight, categoryTextSp, categorySubTextSp;
    public int refreshWidth, refreshHeight, refreshBottom;

    public int rootScrimLeft, rootScrimMid, rootScrimRight;
    public int guideCellColor, guideCellAltColor, guideFocusTextColor, guideFocusBgColor;
    public int categoryFocusBgColor, categoryFocusTextColor;
    public int radius;

    private LiveTvLayoutConfig(String id, String name, boolean compact) {
        this.id = id;
        this.name = name;
        this.compact = compact;
    }

    public static LiveTvLayoutConfig preset(int themeMode, boolean fourKCompact, int rows) {
        int theme = Math.max(0, Math.min(5, themeMode));
        LiveTvLayoutConfig c = base(theme, fourKCompact);
        c.visibleRows = Math.max(3, Math.min(7, rows));
        applyTheme(c, theme, fourKCompact);
        return c;
    }

    private static LiveTvLayoutConfig base(int theme, boolean fourK) {
        LiveTvLayoutConfig c = new LiveTvLayoutConfig(themeId(theme), themeName(theme), fourK);
        if (fourK) {
            c.catLeft=56; c.catTop=138; c.catWidth=404; c.catHeight=820;
            c.mainLeft=468; c.mainTop=120; c.mainWidth=1378; c.mainHeight=858;
            c.fullLeft=52; c.fullTop=112; c.fullWidth=1812; c.fullHeight=928;
            c.headerHeight=246; c.logoTileW=64; c.logoTileH=48;
            c.titleSp=46; c.metaSp=16; c.descSp=13;
            c.previewWidth=390; c.previewTop=124; c.previewRight=48; c.previewPadding=8; c.previewRadius=18;
            c.timelineHeight=42; c.timelineLeftPadding=96; c.tickWidths=new int[]{170,205,240,240,240,240}; c.redLineX=300;
            c.wideWidth=1780; c.rowLogoWidth=86; c.nowCellWidth=560; c.nextCellWidth=360; c.laterCellWidth=360; c.farCellWidth=340;
            c.rowHeight=68; c.rowCellHeight=54; c.rowGap=3;
            c.categoryIconSize=58; c.categoryRowHeight=74; c.categoryTextSp=18; c.categorySubTextSp=14;
            c.refreshWidth=300; c.refreshHeight=58; c.refreshBottom=28;
        } else {
            c.catLeft=34; c.catTop=132; c.catWidth=342; c.catHeight=902;
            c.mainLeft=392; c.mainTop=108; c.mainWidth=1508; c.mainHeight=948;
            c.fullLeft=34; c.fullTop=96; c.fullWidth=1852; c.fullHeight=972;
            c.headerHeight=218; c.logoTileW=64; c.logoTileH=48;
            c.titleSp=46; c.metaSp=16; c.descSp=13;
            c.previewWidth=330; c.previewTop=128; c.previewRight=38; c.previewPadding=8; c.previewRadius=18;
            c.timelineHeight=36; c.timelineLeftPadding=96; c.tickWidths=new int[]{132,165,195,195,195,195}; c.redLineX=245;
            c.wideWidth=1460; c.rowLogoWidth=72; c.nowCellWidth=455; c.nextCellWidth=300; c.laterCellWidth=300; c.farCellWidth=240;
            c.rowHeight=58; c.rowCellHeight=46; c.rowGap=3;
            c.categoryIconSize=48; c.categoryRowHeight=62; c.categoryTextSp=18; c.categorySubTextSp=14;
            c.refreshWidth=260; c.refreshHeight=50; c.refreshBottom=28;
        }
        c.rootScrimLeft=Color.argb(252,0,0,0);
        c.rootScrimMid=Color.argb(236,5,5,7);
        c.rootScrimRight=Color.argb(238,0,0,0);
        c.guideCellColor=Color.argb(118,22,23,29);
        c.guideCellAltColor=Color.argb(102,22,23,29);
        c.guideFocusBgColor=Color.rgb(238,240,246);
        c.guideFocusTextColor=Color.rgb(25,26,30);
        c.categoryFocusBgColor=Color.rgb(238,240,246);
        c.categoryFocusTextColor=Color.rgb(24,25,29);
        c.radius=12;
        return c;
    }

    private static void applyTheme(LiveTvLayoutConfig c, int theme, boolean fourK) {
        switch (theme) {
            case 1: // TiviMate style: denser guide, smaller preview, stronger cells
                c.name="TiviMate style";
                c.previewWidth -= fourK ? 34 : 26;
                c.headerHeight -= fourK ? 20 : 14;
                c.rowHeight -= fourK ? 6 : 4;
                c.rowCellHeight -= fourK ? 4 : 3;
                c.visibleRows = Math.max(5, c.visibleRows);
                c.guideCellColor=Color.argb(142,18,21,28);
                c.guideCellAltColor=Color.argb(120,18,21,28);
                c.radius=8;
                break;
            case 2: // iMPlayer style: glassy, bigger preview/info area
                c.name="iMPlayer style";
                c.previewWidth += fourK ? 28 : 18;
                c.headerHeight += fourK ? 18 : 12;
                c.guideCellColor=Color.argb(96,34,38,48);
                c.guideCellAltColor=Color.argb(76,34,38,48);
                c.radius=18;
                break;
            case 3: // Arvio style: compact category rail and more guide width
                c.name="Arvio style";
                c.catWidth -= fourK ? 40 : 28;
                c.mainLeft -= fourK ? 34 : 24;
                c.mainWidth += fourK ? 48 : 36;
                c.nowCellWidth += fourK ? 36 : 28;
                c.previewWidth -= fourK ? 18 : 10;
                c.guideCellColor=Color.argb(130,16,18,24);
                c.radius=10;
                break;
            case 4: // Minimal compact: no wasted space, smaller typography
                c.name="Minimal compact";
                c.catWidth -= fourK ? 70 : 48;
                c.mainLeft -= fourK ? 62 : 42;
                c.mainWidth += fourK ? 82 : 62;
                c.previewWidth -= fourK ? 64 : 48;
                c.headerHeight -= fourK ? 40 : 32;
                c.titleSp -= 8; c.metaSp -= 2; c.descSp -= 2;
                c.rowHeight -= fourK ? 10 : 8; c.rowCellHeight -= fourK ? 8 : 6;
                c.radius=6;
                break;
            case 5: // Custom editable starts as Google, then v0.9.1/v0.9.2 will save overrides
                c.name="Custom editable";
                break;
            default: // Google Free TV
                c.name="Google Free TV style";
                break;
        }
        if (c.previewWidth < (fourK ? 280 : 240)) c.previewWidth = fourK ? 280 : 240;
        if (c.rowHeight < 44) c.rowHeight = 44;
        if (c.rowCellHeight < 38) c.rowCellHeight = 38;
        if (c.headerHeight < 150) c.headerHeight = 150;
    }

    private static String themeId(int theme) {
        switch (theme) { case 1: return "tivimate"; case 2: return "implayer"; case 3: return "arvio"; case 4: return "minimal"; case 5: return "custom"; default: return "google_free_tv"; }
    }
    private static String themeName(int theme) {
        switch (theme) { case 1: return "TiviMate style"; case 2: return "iMPlayer style"; case 3: return "Arvio style"; case 4: return "Minimal compact"; case 5: return "Custom editable"; default: return "Google Free TV style"; }
    }
}
