package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v6.2 CATALOG_ARTWORK_HERO_BACKEND_READY";
    public static final String LOG_MARKER = "DC_V6_2_CATALOG_ARTWORK_HERO_BACKEND_READY";
    private BuildMarkers() {}
}
