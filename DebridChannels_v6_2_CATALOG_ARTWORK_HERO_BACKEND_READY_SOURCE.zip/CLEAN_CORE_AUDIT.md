# CLEAN CORE AUDIT — v6.2

Marker: `DC_V6_2_CATALOG_ARTWORK_HERO_BACKEND_READY`

Base line: continued from the v5/v6 clean-core source path, not copied from v2.1.3 legacy code.

Added in this increment:
- Top hero menu focus containment with wrap-around LEFT/RIGHT behavior.
- Backend `/api/home` catalog row loader.
- Poster card image loading for row cards.
- Focused card updates cinematic full-screen background with fade.
- Focused card updates title/logo layer.
- Right-side Banner/extra-art slot now loads from backend `banner`, `logo`, or `poster` fallback.
- Backend endpoint map documented from the uploaded backend zip.

No user TMDB API key is required in-app. Artwork is expected from backend normalized fields.
