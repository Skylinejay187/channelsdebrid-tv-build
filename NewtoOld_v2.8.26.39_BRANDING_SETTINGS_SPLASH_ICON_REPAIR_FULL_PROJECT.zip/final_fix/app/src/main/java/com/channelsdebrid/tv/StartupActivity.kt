package com.channelsdebrid.tv

import android.animation.ObjectAnimator
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class StartupActivity : AppCompatActivity() {
    private companion object { private const val TAG = "DebridChannels" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i(TAG, "STARTUP_FINAL_NO_TEXT: play_motion_logo=true orange_bar_only=true no_category_text=true")
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val bg = ImageView(this).apply {
            setImageResource(R.drawable.startup_splash_black)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = false
            alpha = 0f
        }
        val track = View(this).apply {
            background = rounded(0xFF1E1E20.toInt(), 8)
            alpha = 0.88f
        }
        val bar = View(this).apply {
            background = rounded(0xFFFF8700.toInt(), 8)
            pivotX = 0f
            scaleX = 0.04f
            alpha = 1f
        }
        root.addView(bg, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        val barWidth = dp(520)
        val barHeight = dp(5)
        root.addView(track, FrameLayout.LayoutParams(barWidth, barHeight, Gravity.CENTER).apply { topMargin = dp(305) })
        root.addView(bar, FrameLayout.LayoutParams(barWidth, barHeight, Gravity.CENTER).apply { topMargin = dp(305) })
        setContentView(root)
        ObjectAnimator.ofFloat(bg, "alpha", 0f, 1f).apply { duration = 420; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(bg, "scaleX", 0.995f, 1.0f).apply { duration = 1000; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(bg, "scaleY", 0.995f, 1.0f).apply { duration = 1000; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(bar, "scaleX", 0.04f, 1f).apply { duration = 1350; interpolator = AccelerateDecelerateInterpolator(); start() }
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }, 1450)
    }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
