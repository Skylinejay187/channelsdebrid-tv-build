package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.4.1 TRAILER PLAYER WIRING FIX";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.4.1_trailer_player_endpoint_resolve_clean_base";
    private BuildMarkers() {}
}
