package com.channelsdebrid.tv.storage

import jcifs.CIFSContext
import jcifs.config.PropertyConfiguration
import jcifs.context.BaseContext
import jcifs.smb.NtlmPasswordAuthenticator
import jcifs.smb.SmbFile
import jcifs.smb.SmbFileOutputStream
import java.util.Properties
import java.util.UUID

/**
 * Real SMB/NAS connector used by Settings and Timeshift storage validation.
 * It logs in with the supplied username/password, lists shares/folders, and verifies write access.
 */
class SmbNasBrowser(
    private val host: String,
    private val username: String,
    private val password: String,
    private val domain: String = ""
) {
    data class Entry(
        val name: String,
        val path: String,
        val isDirectory: Boolean
    )

    private val parsedDomain: String by lazy {
        when {
            domain.isNotBlank() -> domain
            username.contains("\\") -> username.substringBefore("\\")
            username.contains("@") -> username.substringAfter("@")
            else -> ""
        }
    }

    private val parsedUsername: String by lazy {
        username.substringAfter("\\").substringBefore("@")
    }

    private val ctx: CIFSContext by lazy {
        val props = Properties().apply {
            setProperty("jcifs.smb.client.enableSMB2", "true")
            setProperty("jcifs.smb.client.disableSMB1", "false")
            setProperty("jcifs.smb.client.responseTimeout", "8000")
            setProperty("jcifs.smb.client.soTimeout", "8000")
        }
        BaseContext(PropertyConfiguration(props))
            .withCredentials(NtlmPasswordAuthenticator(parsedDomain, parsedUsername, password))
    }

    fun testLogin(): Boolean {
        return runCatching {
            SmbFile(rootUrl(), ctx).listFiles()
            true
        }.getOrDefault(false)
    }

    fun list(path: String? = null): List<Entry> {
        val url = normalizeUrl(path ?: rootUrl())
        val file = SmbFile(url, ctx)
        return file.listFiles()
            .filter { it.isDirectory || !it.name.startsWith(".") }
            .map {
                Entry(
                    name = it.name.trimEnd('/'),
                    path = it.canonicalPath,
                    isDirectory = it.isDirectory
                )
            }
            .sortedWith(compareByDescending<Entry> { it.isDirectory }.thenBy { it.name.lowercase() })
    }

    fun ensureWritable(folderPath: String): Boolean {
        return runCatching {
            val folder = SmbFile(normalizeUrl(folderPath), ctx)
            if (!folder.exists()) folder.mkdirs()
            if (!folder.isDirectory) return@runCatching false
            val test = SmbFile(folder.canonicalPath.trimEnd('/') + "/.debrid_channels_write_test_${UUID.randomUUID()}.tmp", ctx)
            test.outputStream.use { out -> out.write("ok".toByteArray()) }
            val ok = test.exists() && test.length() >= 2L
            test.delete()
            ok
        }.getOrDefault(false)
    }

    fun writeFile(folderPath: String, fileName: String, bytes: ByteArray): Boolean {
        return runCatching {
            val folder = SmbFile(normalizeUrl(folderPath), ctx)
            if (!folder.exists()) folder.mkdirs()
            if (!folder.isDirectory) return@runCatching false
            val safeName = fileName.replace("/", "_").replace("\\", "_")
            val dest = SmbFile(folder.canonicalPath.trimEnd('/') + "/" + safeName, ctx)
            dest.outputStream.use { it.write(bytes) }
            dest.exists() && dest.length() == bytes.size.toLong()
        }.getOrDefault(false)
    }

    fun openWriteStream(folderPath: String, fileName: String, append: Boolean = false): java.io.OutputStream? {
        return runCatching {
            val folder = SmbFile(normalizeUrl(folderPath), ctx)
            if (!folder.exists()) folder.mkdirs()
            if (!folder.isDirectory) return@runCatching null
            val safeName = fileName.replace("/", "_").replace("\\", "_")
            val dest = SmbFile(folder.canonicalPath.trimEnd('/') + "/" + safeName, ctx)
            SmbFileOutputStream(dest, append) as java.io.OutputStream
        }.getOrNull()
    }

    fun writeTextFile(folderPath: String, fileName: String, text: String): Boolean {
        return writeFile(folderPath, fileName, text.toByteArray())
    }

    fun fileLength(folderPath: String, fileName: String): Long {
        return runCatching {
            val folder = SmbFile(normalizeUrl(folderPath), ctx)
            if (!folder.exists()) folder.mkdirs()
            val safeName = fileName.replace("/", "_").replace("\\", "_")
            val dest = SmbFile(folder.canonicalPath.trimEnd('/') + "/" + safeName, ctx)
            if (dest.exists()) dest.length() else 0L
        }.getOrDefault(0L)
    }

    fun ensureFolder(folderPath: String): Boolean {
        return runCatching {
            val folder = SmbFile(normalizeUrl(folderPath), ctx)
            if (!folder.exists()) folder.mkdirs()
            folder.exists() && folder.isDirectory
        }.getOrDefault(false)
    }

    private fun rootUrl(): String = "smb://${host.cleanHost()}/"

    private fun normalizeUrl(path: String): String {
        val p = if (path.startsWith("smb://", ignoreCase = true)) path else "smb://${host.cleanHost()}/${path.trimStart('/')}"
        return if (p.endsWith("/")) p else "$p/"
    }

    private fun String.cleanHost(): String = trim().removePrefix("smb://").substringBefore("/")
}
