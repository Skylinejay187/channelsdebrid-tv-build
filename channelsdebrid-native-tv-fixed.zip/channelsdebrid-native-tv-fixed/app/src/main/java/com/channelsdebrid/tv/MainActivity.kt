package com.channelsdebrid.tv

import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.channelsdebrid.tv.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var focusables: List<View>
    private var focusedIndex = 3

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        focusables = listOf(
            binding.menuButton,
            binding.homeButton,
            binding.navResume,
            binding.navSmartHome,
            binding.navLiveTv,
            binding.navMovies,
            binding.ctaContinue,
            binding.chipOne,
            binding.chipTwo,
            binding.chipThree,
            binding.cardOne,
            binding.cardTwo,
            binding.cardThree,
            binding.cardFour,
            binding.cardFive,
            binding.cardSix,
            binding.settingsButton
        )

        focusables.forEachIndexed { index, view ->
            view.isFocusable = true
            view.isFocusableInTouchMode = true
            view.setOnFocusChangeListener { v, hasFocus ->
                v.alpha = if (hasFocus) 1f else 0.92f
                v.scaleX = if (hasFocus) 1.05f else 1f
                v.scaleY = if (hasFocus) 1.05f else 1f
                if (hasFocus) focusedIndex = index
            }
        }

        binding.root.post { focusables[focusedIndex].requestFocus() }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_RIGHT -> move(1)
            KeyEvent.KEYCODE_DPAD_LEFT -> move(-1)
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun move(delta: Int) {
        val next = (focusedIndex + delta).coerceIn(0, focusables.lastIndex)
        if (next != focusedIndex) focusables[next].requestFocus()
    }
}
