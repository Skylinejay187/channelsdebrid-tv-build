package com.debridchannels.core.model

import org.junit.Assert.*
import org.junit.Test

class UnitySurfaceHandoffTest {
    @Test fun handoffSerializesFocusOwnership() {
        val c = UnitySurfaceHandoff()
        assertEquals(AppTab.LIVE_TV, c.activeTab)
        assertTrue(c.permitsNonessentialBackgroundWork)
        val token = c.beginTabHandoff(AppTab.LIVE_TV, AppTab.MOVIES)
        assertEquals(UnitySurfaceHandoff.Phase.HANDOFF, c.phase)
        assertEquals(AppTab.LIVE_TV, c.outgoingTab)
        assertEquals(AppTab.MOVIES, c.incomingTab)
        assertFalse(c.permitsNonessentialBackgroundWork)
        assertTrue(c.finishTabHandoff(token))
        assertEquals(AppTab.MOVIES, c.activeTab)
        assertFalse(c.handoffActive)
    }

    @Test fun lateCompletionCannotOverrideLatestTab() {
        val c = UnitySurfaceHandoff()
        val old = c.beginTabHandoff(AppTab.LIVE_TV, AppTab.MOVIES)
        val latest = c.beginTabHandoff(AppTab.MOVIES, AppTab.SHOWS)
        assertFalse(c.finishTabHandoff(old))
        assertTrue(c.finishTabHandoff(latest))
        assertEquals(AppTab.SHOWS, c.activeTab)
    }

    @Test fun cancellationKeepsMostRecentDestination() {
        val c = UnitySurfaceHandoff()
        val token = c.beginTabHandoff(AppTab.LIVE_TV, AppTab.HOME)
        c.cancelHandoff()
        assertEquals(AppTab.HOME, c.activeTab)
        assertFalse(c.finishTabHandoff(token))
    }
}
