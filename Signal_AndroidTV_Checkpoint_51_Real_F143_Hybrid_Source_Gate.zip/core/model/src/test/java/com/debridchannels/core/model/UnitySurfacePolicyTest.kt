package com.debridchannels.core.model

import org.junit.Assert.*
import org.junit.Test

class UnitySurfacePolicyTest {
    @Test fun matchesF143ForAllTabs() {
        for (tab in AppTab.entries) {
            val p = UnitySurfacePolicy.runtimePolicy(tab)
            assertTrue(p.stateResident)
            assertFalse(p.backgroundWorkWhenCovered)
            assertTrue(p.ownsGlobalTopNavigation)
            assertEquals(tab in setOf(AppTab.LIVE_TV, AppTab.HOME, AppTab.MOVIES, AppTab.SHOWS), p.pixelsResidentWhenCovered)
            assertEquals(tab !in setOf(AppTab.FAVORITES, AppTab.MEMBERSHIP, AppTab.SETTINGS), UnitySurfacePolicy.shouldCompositeLiveTVRoot(tab))
            assertEquals(if (tab in setOf(AppTab.HOME, AppTab.MOVIES, AppTab.SHOWS, AppTab.SPORTS)) AppTab.LIVE_TV else tab, UnitySurfacePolicy.backDestination(tab))
        }
    }
}
