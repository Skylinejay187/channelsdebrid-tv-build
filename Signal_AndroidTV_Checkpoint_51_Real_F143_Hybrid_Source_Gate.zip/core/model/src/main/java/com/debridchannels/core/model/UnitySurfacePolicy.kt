package com.debridchannels.core.model

/** Exact role and residency rules ported from F143 UnitySurfaceSystem.swift.
 * This is the pure Kotlin policy layer; it does not claim visual parity.
 */
object UnitySurfacePolicy {
    enum class Role { LIVE_ROOT, CATALOG_BRANCH, SPORTS_BRANCH, DEDICATED_SURFACE }
    data class RuntimePolicy(
        val stateResident: Boolean,
        val pixelsResidentWhenCovered: Boolean,
        val backgroundWorkWhenCovered: Boolean,
        val ownsGlobalTopNavigation: Boolean
    )

    fun role(tab: AppTab): Role = when (tab) {
        AppTab.LIVE_TV -> Role.LIVE_ROOT
        AppTab.HOME, AppTab.MOVIES, AppTab.SHOWS -> Role.CATALOG_BRANCH
        AppTab.SPORTS -> Role.SPORTS_BRANCH
        AppTab.FAVORITES, AppTab.MEMBERSHIP, AppTab.SETTINGS -> Role.DEDICATED_SURFACE
    }

    fun runtimePolicy(tab: AppTab): RuntimePolicy = RuntimePolicy(
        stateResident = true,
        pixelsResidentWhenCovered = role(tab) == Role.LIVE_ROOT || role(tab) == Role.CATALOG_BRANCH,
        backgroundWorkWhenCovered = false,
        ownsGlobalTopNavigation = true
    )

    fun keepsLiveTVRootMounted(tab: AppTab): Boolean = runtimePolicy(tab).stateResident
    fun shouldCompositeLiveTVRoot(tab: AppTab): Boolean = when (role(tab)) {
        Role.LIVE_ROOT, Role.CATALOG_BRANCH, Role.SPORTS_BRANCH -> true
        Role.DEDICATED_SURFACE -> false
    }
    fun catalogBranchActive(tab: AppTab): Boolean = role(tab) == Role.CATALOG_BRANCH
    fun quickPanelBranchActive(tab: AppTab): Boolean = when (role(tab)) {
        Role.CATALOG_BRANCH, Role.SPORTS_BRANCH -> true
        else -> false
    }
    fun backDestination(tab: AppTab): AppTab = when (role(tab)) {
        Role.CATALOG_BRANCH, Role.SPORTS_BRANCH -> AppTab.LIVE_TV
        else -> tab
    }
}
