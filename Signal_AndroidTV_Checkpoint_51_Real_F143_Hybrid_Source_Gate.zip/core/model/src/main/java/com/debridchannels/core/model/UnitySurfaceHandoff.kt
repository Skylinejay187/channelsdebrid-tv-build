package com.debridchannels.core.model

/**
 * Android counterpart of F143 UnitySurfaceLifecycleCoordinator.swift.
 * This is app-level state management: the actual tvOS frame budgeter remains platform-specific.
 * A generation guards a newly selected surface from a stale prior completion.
 */
class UnitySurfaceHandoff(initialTab: AppTab = AppTab.LIVE_TV) {
    enum class Phase { STABLE, HANDOFF }

    var phase: Phase = Phase.STABLE
        private set
    var activeTab: AppTab = initialTab
        private set
    var outgoingTab: AppTab? = null
        private set
    var incomingTab: AppTab? = null
        private set
    var generation: Long = 0
        private set

    val handoffActive: Boolean get() = phase == Phase.HANDOFF
    val permitsNonessentialBackgroundWork: Boolean get() = !handoffActive

    fun beginTabHandoff(from: AppTab, to: AppTab): Long {
        generation++
        outgoingTab = from
        incomingTab = to
        phase = Phase.HANDOFF
        return generation
    }

    fun finishTabHandoff(expectedGeneration: Long): Boolean {
        if (expectedGeneration != generation || phase != Phase.HANDOFF) return false
        activeTab = incomingTab ?: activeTab
        outgoingTab = null
        incomingTab = null
        phase = Phase.STABLE
        return true
    }

    fun cancelHandoff() {
        generation++
        activeTab = incomingTab ?: activeTab
        outgoingTab = null
        incomingTab = null
        phase = Phase.STABLE
    }
}
