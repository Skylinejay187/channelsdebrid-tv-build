package com.debridchannels.core.data

import com.debridchannels.core.model.MediaItem
import com.debridchannels.core.model.MediaType
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import org.junit.Assert.assertEquals
import org.junit.Test

class TmdbArtworkLookupTest {
    private val show = MediaItem("catalog:tt456", "Title", MediaType.SHOW, null, "", "", "", "", imdbId = " TT123 ")
    private val both = """{"movie_results":[{"id":11}],"tv_results":[{},{"id":0},{"id":22}]}"""

    private fun checkLookup(item: MediaItem, findBody: String, expected: List<String>, status: Int = 200, searchBody: String = "{}") {
        val requests = java.util.concurrent.CopyOnWriteArrayList<String>()
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/") { exchange ->
            val path = exchange.requestURI.path
            val finding = path.startsWith("/find/")
            requests.add(if (finding || path.startsWith("/search/")) exchange.requestURI.toString() else path)
            val body = if (finding) findBody else if (path.startsWith("/search/")) searchBody else """{"backdrops":[{"file_path":"/result.jpg"}]}"""
            val bytes = body.toByteArray()
            exchange.sendResponseHeaders(if (finding) status else 200, bytes.size.toLong())
            exchange.responseBody.use { it.write(bytes) }
        }
        server.start()
        try {
            val result = tmdbDetailBackdrops(item, "a+b", "http://127.0.0.1:${server.address.port}")
            assertEquals(expected, requests.toList())
            val hasImage = expected.lastOrNull()?.endsWith("/images") == true
            assertEquals(if (hasImage) listOf("https://image.tmdb.org/t/p/original/result.jpg") else emptyList(), result)
        } finally {
            server.stop(0)
        }
    }

    private fun find(id: String) = "/find/$id?api_key=a%2Bb&external_source=imdb_id&language=en-US"

    private val titleSearch = "/search/tv?api_key=a%2Bb&query=Title&include_adult=false&page=1&language=en-US"

    @Test fun findMissSearchesByFirstAirYearAndRanksRemakes() {
        val rows = """{"results":[{"id":1,"name":"Similar","first_air_date":"2020","vote_average":10},
            {"id":2,"name":"Title","first_air_date":"1990","vote_average":10},
            {"id":3,"name":"TITLE!","first_air_date":"2020","vote_average":3},
            {"id":4,"name":"Title","first_air_date":"2020-01-01","vote_average":7}]}"""
        checkLookup(show.copy(year = 2020), "{}", listOf(find("tt123"), "$titleSearch&first_air_date_year=2020", "/tv/4/images"),
            searchBody = rows)
    }

    @Test fun movieTitleOnlyEncodesQueryAndPreservesFirstTiedResult() {
        val search = "/search/movie?api_key=a%2Bb&query=A+%26+B&include_adult=false&page=1&language=en-US&year=1999"
        val rows = """{"results":[{"title":"A & B"},{"id":7,"title":"A B","release_date":"1999"},
            {"id":8,"title":"A&B","release_date":"1999"}]}"""
        checkLookup(show.copy(id = "unknown", imdbId = null, year = 1999, title = " A & B ", type = MediaType.MOVIE),
            "", listOf(search, "/movie/7/images"), searchBody = rows)
    }

    @Test fun chooseCatalogKindAndPreferExplicitImdb() {
        checkLookup(show, both, listOf(find("tt123"), "/tv/22/images"))
        checkLookup(show.copy(type = MediaType.MOVIE, imdbId = null), both, listOf(find("tt456"), "/movie/11/images"))
    }

    @Test fun fallbackUsesReturnedKind() {
        checkLookup(show, """{"movie_results":[{"id":11}]}""", listOf(find("tt123"), "/movie/11/images"))
        checkLookup(show.copy(type = MediaType.MOVIE), """{"tv_results":[{"id":22}]}""", listOf(find("tt123"), "/tv/22/images"))
    }

    @Test fun failedOrEmptyFindStopsBeforeImageRequest() {
        for (body in listOf("{}", "invalid")) checkLookup(show, body, listOf(find("tt123"), titleSearch))
        checkLookup(show, both, listOf(find("tt123")), 503)
    }

    @Test fun alternateIdsBypassDiscovery() {
        for (prefix in listOf("TMDB", "TheMovieDB")) {
            for (separator in listOf(":", "_", "/", "-")) {
                checkLookup(show.copy(id = "catalog/$prefix${separator}0042.suffix"), both, listOf("/tv/42/images"))
            }
        }
        checkLookup(show.copy(id = "42", type = MediaType.MOVIE), both, listOf("/movie/42/images"))
        checkLookup(show.copy(id = "tmdb-42/tmdb-84", tmdbId = "8"), both, listOf("/tv/8/images"))
        checkLookup(show.copy(id = "tmdb-42/tmdb-84"), both, listOf("/tv/42/images"))
    }

    @Test fun mixedRawIdsDeferToImdbEvenWhenEmbeddedInWords() {
        checkLookup(show.copy(id = "catalogTT12345suffix/tmdb_42", imdbId = null), both,
            listOf(find("tt12345"), "/tv/22/images"))
        checkLookup(show.copy(id = "tt12345/tmdb_42"), both, listOf(find("tt123"), "/tv/22/images"))
        checkLookup(show.copy(id = "tt1234/tmdb_42"), both, listOf("/tv/42/images"))
    }

    @Test fun invalidAlternateIdsFallThroughToDiscovery() {
        for (raw in listOf("1", "tmdb-1", "tmdb|42", " 42 ", "00", "tmdb-999999999999999999999")) {
            checkLookup(show.copy(id = raw), both, listOf(find("tt123"), "/tv/22/images"))
        }
    }

    @Test fun existingTmdbIdsBypassFind() {
        checkLookup(show.copy(tmdbId = "8"), both, listOf("/tv/8/images"))
        checkLookup(show.copy(type = MediaType.MOVIE, id = "tmdb:tv:9", tmdbId = "8"), both, listOf("/tv/9/images"))
        checkLookup(show.copy(id = "unknown", imdbId = "invalid", title = " "), both, emptyList())
    }
}
