package com.debridchannels.core.data

import org.junit.Assert.*
import org.junit.Test

class SignalLineupTest {
    @Test fun playlistKeepsLabelsGroupsNumbersAndDistinctSecureStreams() {
        val rows = signalStations("""
            #EXTM3U
            #EXTINF:-1 tvg-chno="23" group-title="Sports, USA" tvg-logo="https://test.example/logo",City, North
            https://test.example/live
            https://test.example/live
            file:///secret
            https://second.example/broadcast
        """.trimIndent())
        assertEquals(2, rows.size)
        val first = rows.first()
        assertEquals("23", first.channel.number)
        assertEquals("City, North", first.channel.name)
        assertTrue(first.channel.isSports)
        assertEquals("https://test.example/logo", first.logo)
        assertEquals("second.example", rows.last().channel.name)
        assertEquals(first.channel.id, signalStations(first.url).single().channel.id)
    }

    @Test fun rejectsHlsSegmentsAndUnsupportedSources() {
        assertTrue(runCatching { signalStations("#EXT-X-TARGETDURATION:6") }.isFailure)
        assertTrue(signalStations("bad\nhttp://clear.example/a\nfile:///x").isEmpty())
    }

    @Test fun seedMakesBothShelvesWithPlayableMovieIdentities() {
        val rows = signalSeedRows("""[{"id":"tt1","type":"movie","name":"Movie","poster":"https://example.com/a"},
            {"id":"tt2","type":"series","name":"Show","poster":"https://example.com/b"}]""")
        assertEquals(listOf("Movies", "TV Shows"), rows.map { it.title })
        assertEquals("tt1", rows.first().items.single().imdbId)
    }
}
