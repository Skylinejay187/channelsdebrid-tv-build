package com.debridchannels.core.data

import com.google.gson.JsonParser
import org.junit.Assert.*
import org.junit.Test

class OfficialCatalogRefreshTest {
    private var name = "Official"
    private var fullReads = 0
    private var time = 0L
    private var order = listOf("a" to "1", "b" to "1")
    private var changes = order
    private val requests = mutableListOf<Map<String, String>>()
    private fun row(id: String, title: String) =
        """{"id":"$id","name":"$title","type":"movie","metas":[{"id":"i","name":"Title","poster":"https://img.example/i.jpg"}]}"""
    private fun version(it: Pair<String, String>) = """"key":"${it.first}","revision":"${it.second}"""".trim()
    private val loader = OfficialCatalogRefresh(
        fetch = {
            if (it.path == "/manifest.json") """{"name":"$name","debridChannels":{"batchRowsURL":"/batch"}}"""
            else {
                fullReads++
                """{"rows":[${row("full","Full batch")}]}"""
            }
        },
        post = { url, body ->
            assertEquals("/api/catalog/rows/delta/v1", url.path)
            val json = JsonParser.parseString(body).asJsonObject
            assertEquals("https://catalog.skylinejay187.it.com/batch", json.get("source").asString)
            requests.add(json.getAsJsonObject("known").entrySet().associate { it.key to it.value.asString })
            val ordered = order.joinToString { "{${version(it)}}" }
            val changed = changes.joinToString { "{${version(it)},\"row\":${row(it.first, it.first + it.second)}}" }
            """{"order":[$ordered],"rows":[$changed]}"""
        }, nanos = { time },
    )

    private fun refresh() = loader.refresh { it.rows }.map { it.title }

    @Test fun changedAndUnchangedRowsFollowServerOrder() {
        assertEquals(listOf("a1", "b1"), refresh())
        order = listOf("b" to "2", "a" to "1")
        changes = order.take(1)
        assertEquals(listOf("b2", "a1"), refresh())
        changes = emptyList()
        assertEquals(listOf("b2", "a1"), refresh())
        assertEquals(mapOf("a" to "1", "b" to "2"), requests.last())
        assertEquals(0, fullReads)
    }

    @Test fun incompleteDeltaFallsBackAndDoesNotCommitBadRevision() {
        refresh()
        order = listOf("a" to "2")
        changes = emptyList()
        assertEquals(listOf("Full batch"), refresh())
        assertEquals(listOf("Full batch"), refresh())
        assertEquals(2, requests.size)
        time = 60_000_000_000L
        changes = order
        assertEquals(listOf("a2"), refresh())
        assertEquals("1", requests.last()["a"])
    }

    @Test fun manifestChangeInvalidatesKnownRevisions() {
        refresh()
        name = "Updated"
        refresh()
        assertTrue(requests.last().isEmpty())
    }

    @Test fun duplicateKeysAndReorderedChangesFallBack() {
        order = listOf("a" to "1", "a" to "1")
        changes = order
        assertEquals(listOf("Full batch"), refresh())
        time = 60_000_000_000L
        order = listOf("a" to "1", "b" to "1")
        changes = order.reversed()
        assertEquals(listOf("Full batch"), refresh())
    }

    @Test fun unchangedRevisionReusesTheSameMappedRowAndCards() {
        val first = loader.refresh { it.rows }
        changes = emptyList()
        val second = loader.refresh { it.rows }
        assertSame(first[0], second[0])
        assertSame(first[1].items[0], second[1].items[0])
        order = listOf("b" to "2", "a" to "1")
        changes = order.take(1)
        val third = loader.refresh { it.rows }
        assertSame(first[0], third[1])
        assertNotSame(first[1], third[0])
        assertEquals("b2", third[0].title)
    }

    @Test fun rejectedSnapshotCannotAdvanceTheCachedRevisionOrRow() {
        val first = loader.refresh { it.rows }
        order = listOf("a" to "2", "b" to "1")
        changes = order.take(1)
        assertThrows(IllegalStateException::class.java) {
            loader.refresh { error("snapshot unavailable") }
        }
        time = 60_000_000_000L
        order = listOf("a" to "1", "b" to "1")
        changes = emptyList()
        val recovered = loader.refresh { it.rows }
        assertEquals(mapOf("a" to "1", "b" to "1"), requests.last())
        assertSame(first[0], recovered[0])
    }
}
