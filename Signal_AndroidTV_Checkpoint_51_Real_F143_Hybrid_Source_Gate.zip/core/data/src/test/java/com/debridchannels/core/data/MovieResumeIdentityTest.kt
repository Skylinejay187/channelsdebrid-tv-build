package com.debridchannels.core.data

import com.debridchannels.core.model.*
import org.junit.Assert.*
import org.junit.Test

class MovieResumeIdentityTest {
    private val movie = MediaItem("addon:TMDB-movie-42", "Title", MediaType.MOVIE, 2026, "", "", "", "",
        imdbId = "IMDB:TT1234567", tmdbId = "99", tvdbId = " 123 ")

    @Test fun embeddedAndHydratedAliasesAreProviderQualified() {
        assertEquals(setOf("raw:" + movie.id, "tmdb:42", "imdb:tt1234567", "tvdb:123"),
            movieResumeAliases(movie.id, movie))
        assertEquals(setOf("raw:providerB", "tmdb:99", "imdb:tt1234567", "tvdb:123"),
            movieResumeAliases("providerB", movie.copy(id = "providerB")))
        assertEquals(setOf("raw:another"), movieResumeAliases("another", movie))
    }

    @Test fun identicalNamesAndMissingYearsCannotLinkRemakes() {
        val older = movie.copy(id = "old", year = null, tmdbId = null, tvdbId = null, imdbId = null)
        val newer = older.copy(id = "new")
        assertTrue(movieResumeAliases(older.id, older).intersect(movieResumeAliases(newer.id, newer)).isEmpty())
    }

    @Test fun hydrationJoinsPriorCatalogsAndUsesLatestSaveIncludingRewind() {
        val first = MovieResumeGroup(setOf("raw:a", "tmdb:42"), 90000L, 8L)
        val second = MovieResumeGroup(setOf("raw:b", "imdb:tt1234567"), 20000L, 9L)
        val index = first.aliases.associateWith { first } + second.aliases.associateWith { second }
        val keys = movieResumeAliases(movie.id, movie)
        val group = resolveMovieResume(keys, index::get)
        assertEquals(20000L, group.positionMs)
        assertEquals(first.aliases + second.aliases + keys, group.aliases)
    }

    @Test fun oldExactIdsWithSharedProviderIdMigrateTogether() {
        val groups = legacyMovieResumeGroups(mapOf("tt1234567" to 15000L,
            "catalog/TT1234567" to 22000L, "short" to 200L, "other" to 8500L))
        assertEquals(2, groups.size)
        val shared = groups.single { "imdb:tt1234567" in it.aliases }
        assertEquals(22000L, shared.positionMs)
        assertTrue("raw:tt1234567" in shared.aliases && "raw:catalog/TT1234567" in shared.aliases)
    }
}
