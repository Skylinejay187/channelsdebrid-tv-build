package com.debridchannels.core.data

import com.debridchannels.core.model.*
import org.junit.Assert.*
import org.junit.Test

class CatalogFavoritesTest {
    private val movie = MediaItem("one", "Film", MediaType.MOVIE, 2003, "", "", "", "",
        posterUrl = "https://example.org/art", imdbId = " TT123 ", tmdbId = "88", tvdbId = "55")

    @Test fun canonicalIdentityUsesStrongestAvailableProviderAcrossRows() {
        assertEquals("imdb::tt123::movie", movie.catalogFavoriteKey())
        assertEquals(movie.catalogFavoriteKey(), movie.copy(id = "two", title = "Localized").catalogFavoriteKey())
        assertEquals("tmdb::88::movie", movie.copy(imdbId = null).catalogFavoriteKey())
        assertEquals("tvdb::55::movie", movie.copy(imdbId = null, tmdbId = null).catalogFavoriteKey())
        assertEquals("imdb::tt123::series", movie.copy(type = MediaType.SHOW).catalogFavoriteKey())
        assertNull(movie.copy(type = MediaType.EPISODE).catalogFavoriteKey())
    }

    @Test fun fallbackUsesItemIdThenTitleAndYear() {
        val bare = movie.copy(imdbId = null, tmdbId = null, tvdbId = null, id = "A/B")
        assertEquals("id::a-b::movie", bare.catalogFavoriteKey())
        assertEquals("title::film-2003::movie", bare.copy(id = "").catalogFavoriteKey())
    }

    @Test fun offlineSnapshotRestoresArtworkAndRejectsInvalidEntries() {
        val key = movie.catalogFavoriteKey()!!
        val raw = encodeFavorite(movie)
        assertEquals(movie, restoreFavorite(key, raw))
        assertNull(restoreFavorite("wrong", raw))
        assertNull(restoreFavorite(key, "{"))
        assertNull(restoreFavorite(key, 42))
        assertNull(restoreFavorite(key, raw.replace("\"genres\"", "\"missing\"")))
    }

    @Test fun checkpoint29SnapshotStillResolvesWhenItsCanonicalKeyChanges() {
        val old = movie.copy(imdbId = null)
        val key = old.catalogFavoriteKey()!!
        val restored = mapOf(key to restoreFavorite(key, encodeFavorite(old))!!)
        assertEquals(key, restored.storedFavoriteKey(movie.copy(id = "new", title = "Localized")))
        assertTrue((restored - restored.storedFavoriteKey(movie)!!).isEmpty())
    }

    @Test fun itemIdBridgesTitleChangesWithoutProviderOverlap() {
        val old = movie.copy(imdbId = null, tmdbId = null, tvdbId = null)
        val saved = mapOf(old.catalogFavoriteKey()!! to old)
        assertEquals(old.catalogFavoriteKey(), saved.storedFavoriteKey(movie.copy(title = "New title")))
        assertNull(saved.storedFavoriteKey(movie.copy(type = MediaType.SHOW)))
    }

    @Test fun titleFallbackRequiresCompatibleYearsAndUnambiguousCandidates() {
        val old = movie.copy(imdbId = null, tmdbId = null, tvdbId = null, id = "old")
        val remake = old.copy(id = "remake", year = 2020)
        val saved = listOf(old, remake).associateBy { it.catalogFavoriteKey()!! }
        assertNull(saved.storedFavoriteKey(movie.copy(year = null)))
        assertNull(saved.storedFavoriteKey(movie.copy(year = 1992)))
        assertEquals(old.catalogFavoriteKey(), saved.storedFavoriteKey(movie))
        assertEquals(old.catalogFavoriteKey(), (saved - remake.catalogFavoriteKey()!!).storedFavoriteKey(movie.copy(year = null)))
    }

    @Test fun conflictingProviderCannotBridgeOnWeakerEvidence() {
        val old = movie.copy(imdbId = null)
        assertNull(mapOf(old.catalogFavoriteKey()!! to old).storedFavoriteKey(movie.copy(tmdbId = "99")))
    }

    @Test fun partialRefreshKeepsSavedBackdropAndMetadataWhileReplacingPoster() {
        val saved = movie.copy(landscapeUrl = "old-wide", description = "Original", genres = listOf("Drama"),
            rating = 8.0, runtimeMinutes = 125)
        val fresh = saved.copy(posterUrl = "new-poster", landscapeUrl = " ", imdbId = null,
            description = "", genres = emptyList(), rating = null, runtimeMinutes = null)
        assertEquals(saved.copy(posterUrl = "new-poster"), fresh.withSavedFavoriteFields(saved))
        assertEquals(saved.copy(description = "Updated"), saved.copy(description = "Updated").withSavedFavoriteFields(saved))
    }

    @Test fun upgradedFavoriteRestoresUnderItsNewKeyAfterMerge() {
        val old = movie.copy(imdbId = null)
        val originalKey = old.catalogFavoriteKey()!!
        val fresh = movie.copy(posterUrl = null)
        val library = mapOf(originalKey to old)
        val matched = library.storedFavoriteKey(fresh)!!
        val updated = fresh.withSavedFavoriteFields(library.getValue(matched)).compactFavorite()
        val newKey = updated.catalogFavoriteKey()!!
        val reopened = mapOf(newKey to restoreFavorite(newKey, encodeFavorite(updated))!!)
        assertEquals(movie, reopened.getValue(newKey))
        assertEquals(newKey, reopened.storedFavoriteKey(old))
    }

    @Test fun compactLimitsKeepFullUnicodeCharactersAndFirstEightGenres() {
        val description = "a".repeat(1399) + "🎥" + "z"
        val original = movie.copy(description = description, genres = (1..10).map(Int::toString))
        val compact = original.compactFavorite()
        assertEquals(description.dropLast(1), compact.description)
        assertEquals(original.genres.take(8), compact.genres)
        assertEquals(compact, compact.compactFavorite())
    }
}
