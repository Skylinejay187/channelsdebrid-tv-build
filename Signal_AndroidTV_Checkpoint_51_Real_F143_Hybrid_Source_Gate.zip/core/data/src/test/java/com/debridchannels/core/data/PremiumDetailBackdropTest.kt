package com.debridchannels.core.data

import com.debridchannels.core.model.MediaItem
import com.debridchannels.core.model.MediaType
import org.junit.Assert.*
import org.junit.Test
import java.net.URLDecoder

class PremiumDetailBackdropTest {
    private val item = MediaItem("abc", "A & B+", MediaType.SHOW, null, "", "", "", "",
        landscapeUrl = "https://example.org/current", imdbId = " tt123 ", tvdbId = " ")

    @Test fun fanartRequiresProviderSpecificIdAndIndependentKey() {
        val show = item.copy(tmdbId = "12", tvdbId = " 34 ")
        val movie = show.copy(type = MediaType.MOVIE)
        assertEquals("https://webservice.fanart.tv/v3/tv/34?api_key=a%2Bb", fanartBackdropEndpoint(show, " a+b ").toString())
        assertEquals("/v3/movies/12", fanartBackdropEndpoint(movie, "k")!!.path)
        assertNull(fanartBackdropEndpoint(show, " "))
        assertNull(fanartBackdropEndpoint(show.copy(tvdbId = null), "k"))
        assertNull(fanartBackdropEndpoint(movie.copy(tmdbId = "0"), "k"))
        assertNull(fanartBackdropEndpoint(show.copy(type = MediaType.LIVE_CHANNEL), "k"))
    }

    @Test fun fanartRanksLanguageBeforeLikesAndUsesCorrectBucket() {
        val json = """{"showbackground":[
            {"url":"https://example.org/fr","lang":"fr","likes":"900"},
            {"url":"http://example.org/en","lang":"EN","likes":"3"},
            {"url":"https://example.org/en","lang":"de","likes":"24"},
            {"url":"//example.org/plain","likes":"5"},
            {"url":"invalid","likes":"98"},
            {"url":"https://example.org/current","likes":"99"}],
            "moviebackground":[{"url":"https://example.org/movie"}]}"""
        assertEquals(listOf("plain", "en", "fr").map { "https://example.org/$it" },
            rankedFanartBackdrops(json.byteInputStream(), item))
        assertEquals(listOf("https://example.org/movie"),
            rankedFanartBackdrops(json.byteInputStream(), item.copy(type = MediaType.MOVIE)))
        assertTrue(rankedFanartBackdrops(ByteArray(4_000_001).inputStream(), item).isEmpty())
    }

    @Test fun threeProviderRotationSkipsSharedImagesAndWraps() {
        val urls = (1..5).map { "https://example.org/$it" }
        val pool = mergeBackdropPools(item, listOf(urls[0], urls[3]), listOf(urls[1], urls[0], urls[4]), listOf(urls[2]))
        assertEquals(urls, pool)
        val session = DetailBackdropSession()
        assertEquals(urls.first(), session.next(item, pool))
        assertEquals(urls.drop(1) + urls.first(), (1..5).map { session.next(item) })
    }

    @Test fun tmdbRequestNeedsKeyAndPositiveCatalogId() {
        val show = item.copy(tmdbId = " 42 ")
        assertEquals("/3/tv/42/images", tmdbBackdropEndpoint(show, "a+b")!!.path)
        assertEquals("api_key=a%2Bb&include_image_language=en,null", tmdbBackdropEndpoint(show, "a+b")!!.rawQuery)
        assertEquals("/3/movie/42/images", tmdbBackdropEndpoint(show.copy(type = MediaType.MOVIE), "k")!!.path)
        assertNull(tmdbBackdropEndpoint(show, " "))
        assertNull(tmdbBackdropEndpoint(show.copy(tmdbId = "-1"), "k"))
        assertNull(tmdbBackdropEndpoint(item, "k"))
    }

    @Test fun tmdbRanksByAreaVotesThenAverage() {
        fun image(path: String, width: Int, votes: Int, average: Int) =
            """{"file_path":"/$path","width":$width,"height":10,"vote_count":$votes,"vote_average":$average}"""
        val rows = listOf(image("a", 1, 8, 4), image("b", 2, 0, 0), image("c", 1, 8, 5),
            image("d", 1, 1, 9), image("a", 99, 0, 0), "null", "{}")
        val body = """{"backdrops":[${rows.joinToString(",")}]}"""
        assertEquals(listOf("b", "c", "a", "d").map { "https://image.tmdb.org/t/p/original/$it" },
            rankedTmdbBackdrops(body.byteInputStream()))
        assertTrue(rankedTmdbBackdrops("{}".byteInputStream()).isEmpty())
    }

    @Test fun providerMergeAlternatesAndFiltersAnchorsAndDuplicates() {
        val (a, b, c) = listOf("a", "b", "c").map { "https://example.org/$it" }
        assertEquals(listOf(a, b, c), mergeBackdropPools(item, listOf(a, item.landscapeUrl!!, c), listOf(b, a)))
        assertEquals(listOf(a, c), mergeBackdropPools(item, listOf(a, c), emptyList()))
    }

    @Test fun resolverEncodesTitleAndAvailableIdentifiers() {
        val uri = premiumArtworkEndpoint(item, "https://example.org/")!!
        assertEquals("/api/artwork/resolve", uri.path)
        val query = uri.rawQuery.split("&").associate {
            it.substringBefore("=") to URLDecoder.decode(it.substringAfter("="), "UTF-8")
        }
        assertEquals(mapOf("title" to "A & B+", "imdbId" to "tt123", "type" to "tv", "proxyImages" to "0"), query)
        assertNull(premiumArtworkEndpoint(item.copy(type = MediaType.LIVE_CHANNEL), artworkBackend))
    }

    @Test fun poolRanksSourcesThenPixelsAndSkipsCurrentAndRepeatedArtwork() {
        val body = """{"artworkPool":{"backdrops":[
            {"url":"https://example.org/current","source":"fanart"},
            {"url":"https://example.org/tmdb","source":"tmdb","width":9000,"height":9000},
            {"url":"https://example.org/small","source":"fanartTV","width":800,"height":600},
            {"url":"https://example.org/large","source":"fanart","width":1920,"height":1080}],
            "landscape":[{"url":"https://example.org/tv","source":"TVDB"},
            {"url":"https://example.org/tmdb","source":"fanart"},{"url":"invalid"}]}}"""
        assertEquals(listOf("large", "small", "tv", "tmdb").map { "https://example.org/$it" },
            rankedDetailBackdrops(body.byteInputStream(), item))
    }

    @Test fun oversizedStreamAndMissingBucketsYieldNoReplacement() {
        assertTrue(rankedDetailBackdrops(ByteArray(2_000_001).inputStream(), item).isEmpty())
        assertTrue(rankedDetailBackdrops("{}".byteInputStream(), item).isEmpty())
    }

    @Test fun transportHandlesSuccessUnavailableAndMalformedResponses() {
        fun request(status: String, body: String): List<String> {
            java.net.ServerSocket(0, 1, java.net.InetAddress.getByName("127.0.0.1")).use { server ->
                val worker = kotlin.concurrent.thread(isDaemon = true) {
                    server.accept().use { socket ->
                        val reader = socket.getInputStream().bufferedReader()
                        while (!reader.readLine().isNullOrEmpty()) { }
                        val response = "HTTP/1.1 $status\r\nContent-Length: ${body.length}\r\nConnection: close\r\n\r\n$body"
                        socket.getOutputStream().write(response.toByteArray())
                    }
                }
                val pool = backendDetailBackdrops(item, "http://127.0.0.1:${server.localPort}")
                worker.join(2000)
                return pool
            }
        }
        val json = """{"artworkPool":{"backdrops":[{"url":"https://art.example/alternate"}]}}"""
        assertEquals(listOf("https://art.example/alternate"), request("200 OK", json))
        assertTrue(request("503 Unavailable", json).isEmpty())
        assertTrue(request("200 OK", "{").isEmpty())
    }
}
