package com.debridchannels.core.data

import com.debridchannels.core.model.*
import org.junit.Assert.*
import org.junit.Test

class ContinueWatchingTest {
    private fun movie(id: String, name: String = id, year: Int = 2026) =
        MediaItem(id, name, MediaType.MOVIE, year, "", "", "poster", "backdrop")
    private fun recent(item: MediaItem, rev: Long, pos: Long = 8000L, duration: Long = 0L) =
        RecentMovie(MovieResumeGroup(movieResumeAliases(item.id, item), pos, rev, duration), item)

    @Test fun newestFirstAcrossAliasesAndRemakesWithTwentyFourCardLimit() {
        val entries = (1..30).map { recent(movie("m$it"), it.toLong()) } + listOf(
            recent(movie("old", "Café"), 50), recent(movie("new", "CAFE"), 51),
            recent(movie("remake", "Café", 1994), 49))
        val cards = continueWatchingRow(entries, emptyList())!!.items
        assertEquals(24, cards.size)
        assertEquals(listOf("new","remake","m30"), cards.take(3).map { it.id })
        assertFalse(cards.any { it.id == "old" })
    }

    @Test fun cutoffIncludesUnknownDurationAndExcludesFinishedAndTooShort() {
        val entries = listOf(recent(movie("short"), 3, 7999), recent(movie("ended"), 2, 9500, 10000))
        assertNull(continueWatchingRow(entries, emptyList()))
        assertEquals("eligible", continueWatchingRow(entries + recent(movie("eligible"), 1), emptyList())!!.items.single().id)
    }

    @Test fun catalogMatchKeepsSavedArtworkAndOlderTimingOnlyEntriesUseCatalogIdentity() {
        val watched = movie("provider-a").copy(imdbId = "tt1234567", posterUrl = "poster-a", landscapeUrl = "backdrop-a")
        val match = watched.copy(id = "provider-b", posterUrl = "poster-b", landscapeUrl = "")
        val entry = recent(watched, 2)
        val catalog = listOf(CatalogRow("movies", "Movies", items = listOf(match)))
        val card = continueWatchingRow(listOf(entry), catalog)!!.items.single()
        assertEquals("provider-b", card.id)
        assertEquals("poster-b", card.posterUrl)
        assertEquals("backdrop-a", card.landscapeUrl)
        assertEquals(match.id, continueWatchingRow(listOf(entry.copy(saved = null)), catalog)!!.items.single().id)
        assertEquals(watched, decodeResumeCard(encodeResumeCard(watched)))
        assertEquals(watched, continueWatchingRow(listOf(entry), emptyList())!!.items.single())
        assertNull(continueWatchingRow(listOf(entry.copy(saved = null)), emptyList()))
    }

    @Test fun removalPersistsAcrossLaterSavesAndCatalogIds() {
        val original = movie("a", "Café: Aurora", 2000)
        val hidden = movieVisibilityKeys(original)
        val replay = original.copy(id = "b", title = "CAFE Aurora", year = null)
        val remake = replay.copy(id = "c", year = 2025)
        val different = movie("other")
        val records = listOf(recent(replay, 8), recent(remake, 9), recent(different, 5))
        assertEquals(listOf(different), continueWatchingRow(records, emptyList(), hidden)!!.items)
        assertEquals(3, continueWatchingRow(records, emptyList())!!.items.size)
    }

    @Test fun hideOnlyChangesContinueShelvesAndSkipsEmptyShelf() {
        val film = movie("catalog-a", "Example").copy(imdbId = "tt1234567")
        val localized = film.copy(id = "catalog-b", title = "Ejemplo")
        val keep = movie("another")
        val ordinary = CatalogRow("all", "Movies", items = listOf(localized))
        val local = CatalogRow("dc-local-continue", "Continue Watching", items = listOf(film))
        val cached = CatalogRow("cached", "Resume Movies", items = listOf(localized, keep))
        assertEquals(listOf(ordinary, cached.copy(items = listOf(keep))),
            visibleContinueRows(listOf(ordinary, local, cached), movieVisibilityKeys(film)))
        assertNull(continueWatchingRow(listOf(recent(localized, 9)), emptyList(), movieVisibilityKeys(film)))
    }
}
