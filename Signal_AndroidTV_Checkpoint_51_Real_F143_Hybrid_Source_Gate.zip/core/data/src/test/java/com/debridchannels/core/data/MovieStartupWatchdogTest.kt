package com.debridchannels.core.data

import com.debridchannels.core.model.MediaType
import com.debridchannels.core.model.PlaybackRequest
import org.junit.Assert.*
import org.junit.Test

class MovieStartupWatchdogTest {
    private fun option(label: String, index: Int) = MovieSourceOption(label,
        PlaybackRequest("id", MediaType.MOVIE, "Title", "https://example.org/$index"), null, null)

    @Test fun graceMatchesCurrentSourceAndRequiresAlternate() {
        val cases = mapOf("RD+ 1080p" to 21, "cached 2160p" to 25, "instant 4K" to 25, "cache hit Remux" to 25, "TorBox UHD" to 25,
            "unknown" to 30, "TorBox not cached 👤 5" to 42, "download required S:12" to 36,
            "[Uncached] Remux" to 30, "cache-health=uncached seeders=10" to 42,
            "uncached seeders:11" to 36, "uncached seeders 25" to 36, "uncached seeders 26" to 30)
        for ((label, seconds) in cases) {
            val selected = option(label, 1)
            val options = listOf(selected, option("cached UHD", 2), option("last", 3))
            val session = MovieStartupRecovery(selected.playback, options)
            assertEquals(label, seconds * 1000L, session.startupGraceMs())
            session.failed(false, 10L)
            assertEquals(25_000L, session.startupGraceMs())
            session.failed(false, 10L)
            assertNull(session.startupGraceMs())
            val framed = MovieStartupRecovery(selected.playback, options)
            framed.firstFrame()
            assertNull(framed.startupGraceMs())
        }
    }

    private class Clock(var buffered: Long) {
        val timers = mutableListOf<Pair<Runnable, Long>>()
        var expirations = 0
        val watchdog = MovieStartupWatchdog(
            { task, delay -> timers.add(task to delay) },
            { task -> timers.removeAll { it.first === task } },
            { buffered }, { expirations++ })
        fun tick() = timers.removeAt(0).first.run()
    }

    @Test fun bufferedMediaGetsExactlyOneExtension() {
        val clock = Clock(351)
        clock.watchdog.arm(21_000L)
        clock.watchdog.arm(21_000L)
        assertEquals(listOf(21_000L),clock.timers.map { it.second })
        clock.tick()
        assertEquals(listOf(9000L),clock.timers.map { it.second })
        clock.tick()
        assertEquals(1, clock.expirations)
        assertTrue(clock.timers.isEmpty())
    }

    @Test fun thresholdDoesNotExtendAndCancelledCallbackCannotExpireNewAttempt() {
        val clock = Clock(350)
        clock.watchdog.arm(21_000L)
        val stale = clock.timers.single().first
        clock.watchdog.stop()
        clock.watchdog.arm(25_000L)
        stale.run()
        assertEquals(0, clock.expirations)
        clock.tick()
        assertEquals(1, clock.expirations)
    }
}
