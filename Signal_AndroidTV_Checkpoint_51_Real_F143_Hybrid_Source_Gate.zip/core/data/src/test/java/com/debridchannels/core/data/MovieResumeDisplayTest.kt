package com.debridchannels.core.data

import org.junit.Assert.*
import org.junit.Test

class MovieResumeDisplayTest {
    private fun entry(position: Long, duration: Long) = MovieResumeGroup(setOf("movie"), position, 1, duration)

    @Test fun eligibleKnownDurationRoundsClockAndFloorsRemainingMinutes() {
        val info = entry(599_500, 7_999_500).display()!!
        assertEquals("10:00", info.timestamp)
        assertEquals("2h 3m", info.remaining)
        assertEquals(7, info.percent)
        assertEquals("1:00:00", entry(3_599_500, 4_000_000).display()!!.timestamp)
        assertEquals("1m", entry(8_000, 30_000).display()!!.remaining)
    }

    @Test fun missingDurationCompletedAndClearedPositionsHideDisplay() {
        for (group in listOf(entry(70_000, 0), entry(9000, 9000), entry(7999, 60000), entry(0, 0))) {
            assertNull(group.display())
        }
    }

    @Test fun aliasResolutionCarriesDurationFromTheSameSaveAsThePosition() {
        val old = entry(60_000, 5_000_000)
        val newer = MovieResumeGroup(setOf("b"), 30_000, 2, 600_000)
        val merged = resolveMovieResume(setOf("movie","b"), mapOf("movie" to old, "b" to newer)::get)
        assertEquals("0:30", merged.display()!!.timestamp)
        assertEquals(5, merged.display()!!.percent)
    }
}
