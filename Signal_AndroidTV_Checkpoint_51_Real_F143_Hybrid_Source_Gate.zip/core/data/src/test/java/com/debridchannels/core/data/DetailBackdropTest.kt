package com.debridchannels.core.data

import com.debridchannels.core.model.MediaItem
import com.debridchannels.core.model.MediaType
import org.junit.Assert.*
import org.junit.Test

class DetailBackdropTest {
    private val film = MediaItem("fixture", "Movie", MediaType.MOVIE, 2026, "", "", "", "")

    @Test fun landscapeRelayAndOriginalPrecedePosterWithoutMaskRequest() {
        val wide = "https://image.tmdb.org/t/p/original/film.jpg?token=a%2Bb"
        val poster = "https://catalog.skylinejay187.it.com/assets/poster.jpg"
        val candidates = detailBackdropUrls(film.copy(landscapeUrl = wide.replace("original", "w500"), posterUrl = poster))
        val relay = catalogHeroArtwork(wide, artworkBackend, false, true)!!.baseUrl
        assertEquals(listOf(relay, wide, poster), candidates)
        assertEquals(candidates.take(2), detailBackdropUrls(film.copy(landscapeUrl = relay, posterUrl = wide)))
    }

    @Test fun invalidOrAbsentLandscapeUsesPosterOrLocalFallback() {
        val poster = "http://192.168.1.2/poster.jpg"
        for (wide in listOf(null, " ", "file:///invalid")) {
            assertEquals(listOf(poster), detailBackdropUrls(film.copy(landscapeUrl = wide, posterUrl = poster)))
        }
        assertTrue(detailBackdropUrls(film).isEmpty())
    }

    @Test fun relayWithLocalOriginDoesNotScheduleSecondRequest() {
        val relay = "$artworkBackend/api/image?url=http%3A%2F%2Flocalhost%2Fimage"
        assertEquals(listOf(relay), detailBackdropUrls(film.copy(landscapeUrl = relay)))
    }

    @Test fun selectedCatalogPosterPrecedesLandscapeRecoveredFromFavorite() {
        val prefix = "https://catalog.skylinejay187.it.com/assets/"
        val selected = film.copy(posterUrl = prefix + "selected.jpg")
        val saved = film.copy(landscapeUrl = prefix + "stored-wide.jpg")
        val detail = selected.withSavedFavoriteFields(saved)
        assertEquals(listOf(selected.posterUrl, saved.landscapeUrl), detailBackdropUrls(detail, selected))
        assertEquals(listOf(saved.landscapeUrl, selected.posterUrl), detailBackdropUrls(detail))
    }

    @Test fun anchorLandscapeAndPosterPrecedeNewArtAndSkipInvalidDuplicates() {
        val prefix = "https://catalog.skylinejay187.it.com/assets/"
        val selected = film.copy(landscapeUrl = prefix + "wide.jpg", posterUrl = prefix + "poster.jpg")
        val detail = selected.copy(landscapeUrl = prefix + "replacement.jpg")
        assertEquals(listOf(selected.landscapeUrl, selected.posterUrl, detail.landscapeUrl),
            detailBackdropUrls(detail, selected))
        assertEquals(detailBackdropUrls(detail), detailBackdropUrls(detail, film.copy(posterUrl = "file:///invalid")))
    }
}
