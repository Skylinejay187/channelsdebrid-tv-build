package com.debridchannels.core.data

import com.debridchannels.core.model.MediaItem
import com.debridchannels.core.model.MediaType
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import org.junit.Assert.*
import org.junit.Test
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class BackendTrailerTest {
    private val item = MediaItem("id", "A & B+", MediaType.SHOW, 2025, "", "", "", "",
        previewUrl = "https://youtu.be/abc123")
    private val url = "https://cdn.example/a.mp4?sig=a%2Fb"

    @Test fun watchPageResolvesByTitleAndReturnsSignedTrailer() = runBlocking {
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        val requests = java.util.concurrent.CopyOnWriteArrayList<String>()
        server.createContext("/") { exchange ->
            requests.add(exchange.requestURI.toString())
            val body = """{"result":{"playbackUrl":"$url"}}""".toByteArray()
            exchange.sendResponseHeaders(200, body.size.toLong())
            exchange.responseBody.use { it.write(body) }
        }
        server.start()
        try {
            val base = "http://127.0.0.1:${server.address.port}"
            assertEquals(url, resolveCatalogTrailer(item, base)?.sourceUrl)
            assertEquals(url, resolveCatalogTrailer(item.copy(previewUrl = url), base)?.sourceUrl)
            val query = requests.single()
            assertTrue(query.startsWith("/trailers/resolve?title=A+%26+B%2B&year=2025&type=series&"))
            assertTrue(query.contains("requireComplete=true"))
            assertTrue(query.contains("requireMuxedAudio=true"))
        } finally { server.stop(0) }
    }

    @Test fun productionTransportPollsLoopbackJobAndReturnsMedia3Request() = runBlocking {
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        val queries = java.util.concurrent.CopyOnWriteArrayList<String>()
        server.createContext("/trailers/resolve") { exchange ->
            val query = exchange.requestURI.rawQuery
            queries.add(query)
            val body = if ("&cacheOnly=true&" in query) url else """{"remuxPending":true}"""
            val bytes = body.toByteArray()
            exchange.sendResponseHeaders(200, bytes.size.toLong())
            exchange.responseBody.use { it.write(bytes) }
        }
        server.start()
        try {
            var preparing = 0
            val result = resolveCatalogTrailer(item, "http://127.0.0.1:${server.address.port}") { preparing++ }
            assertEquals(url, result?.sourceUrl)
            assertEquals("trailer:id", result?.mediaId)
            assertEquals(1, preparing)
            assertEquals(2, queries.size)
            assertEquals(queries.first().replace("&cacheOnly=false&", "&cacheOnly=true&"), queries.last())
        } finally { server.stop(0) }
    }

    @Test fun pollsOnlyCacheAndAcceptsReadyMediaAfterTransientFailures() = runBlocking {
        val queries = mutableListOf<String>()
        val waits = mutableListOf<Long>()
        var preparing = 0
        val result = resolveCatalogTrailer(item, "https://example.org", { preparing++ }, { waits.add(it) }) { uri, timeout ->
            queries.add(uri.rawQuery)
            assertEquals(if (queries.size == 1) 45_000 else 8000, timeout)
            when (queries.size) {
                1 -> """{"remuxPending":true}"""
                2 -> throw java.io.IOException("temporary")
                3 -> null
                4 -> "https://cdn.example/remux-cache/partial.mp4"
                else -> url
            }
        }
        assertEquals(url, result?.sourceUrl)
        assertEquals(1, preparing)
        assertEquals(List(4) { 1000L }, waits)
        assertTrue(queries.first().contains("&cacheOnly=false&"))
        assertEquals(List(4) { queries.first().replace("&cacheOnly=false&", "&cacheOnly=true&") }, queries.drop(1))
    }

    @Test fun stopsAfterFortyPollsWithReferenceCadence() = runBlocking {
        val waits = mutableListOf<Long>()
        var requests = 0
        val result = resolveCatalogTrailer(item, "https://example.org", {}, { waits.add(it) }) { _, _ ->
            requests++
            """{"needsRemux":true}"""
        }
        assertNull(result)
        assertEquals(41, requests)
        assertEquals(List(8) { 1000L } + List(32) { 1500L }, waits)
    }

    @Test fun cancellingWaitSuppressesNextRequest() = runBlocking {
        val waiting = CompletableDeferred<Unit>()
        var requests = 0
        val job = launch {
            resolveCatalogTrailer(item, "https://example.org", {}, {
                waiting.complete(Unit)
                awaitCancellation()
            }) { _, _ -> requests++; "{}" }
        }
        waiting.await()
        job.cancelAndJoin()
        assertEquals(1, requests)
    }

    @Test fun onlyReadyDirectMediaEntersPlayback() {
        assertEquals(url, readyTrailer(item, url)?.sourceUrl)
        for (body in listOf("""{"url":"$url","data":{"remux_pending":"yes"}}""",
            """{"videoUrl":"$url","audioUrl":"https://cdn.example/a.m4a"}""",
            "https://cdn.example/remux-cache/a.mp4", """{"url":"https://youtu.be/video"}""", "invalid"))
            assertNull(readyTrailer(item, body))
    }
}
