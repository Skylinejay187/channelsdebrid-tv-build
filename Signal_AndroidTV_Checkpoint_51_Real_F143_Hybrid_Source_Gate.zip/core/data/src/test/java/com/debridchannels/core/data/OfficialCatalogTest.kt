package com.debridchannels.core.data

import com.debridchannels.core.model.MediaType
import org.junit.Assert.*
import org.junit.Test

class OfficialCatalogTest {
    private val manifest = """{"catalogs":[{"id":"popular","type":"series"}],"debridChannels":{"batchRowsURL":"/api/catalog-rows"}}"""
    @Test fun mapsOfficialRowsAndSkipsUnusableCards() {
        val batch = """{"rows":[{"id":"popular","type":"movie","name":"Popular","metas":[null,{"id":1,"name":"Title","imdb_id":"tt123","tmdbId":42,"tmdb_id":99,"tvdb_id":"7","poster":"https://catalog.skylinejay187.it.com/assets/a.jpg","releaseInfo":"2020–2024"},{"id":"1","name":"Duplicate","poster":"https://a.example/a.jpg"},{"id":"bad","name":"Missing poster"}]}]}"""
        val loaded = loadOfficialCatalogBatch { if (it.path == "/manifest.json") manifest else batch }
        assertEquals(setOf("SHOW:popular"), loaded.uniquelyDeclaredRowIds)
        val row = loaded.rows.single()
        val item = row.items.single()
        assertEquals(MediaType.SHOW, item.type)
        assertEquals("1", item.id)
        assertEquals(2020, item.year)
        assertEquals("tt123", item.imdbId)
        assertEquals("42", item.tmdbId)
        assertEquals("7", item.tvdbId)
        assertEquals(item.posterUrl, item.landscapeUrl)
    }
    @Test fun previewMetadataPriorityAndFavoriteRoundTrip() {
        fun load(fields: String): com.debridchannels.core.model.MediaItem {
            val row = """{"rows":[{"id":"popular","metas":[{"id":"1","name":"Title","poster":"https://a.example/p",$fields}]}]}"""
            return loadOfficialCatalogBatch { if (it.path == "/manifest.json") manifest else row }.rows.single().items.single()
        }
        val direct = load(""""previewVideo":"https://e/first","preview":"https://e/second","trailer":"https://e/third" """)
        assertEquals("https://e/first", direct.previewUrl)
        assertEquals("https://e/second", load(""""preview":"https://e/second","trailer":"https://e/third" """).previewUrl)
        assertEquals("https://e/third", load(""""trailer":"https://e/third" """).previewUrl)
        val trailer = load(""""trailers":[{"source":"bad!"},{"source":" abc_12 "}],"videos":[{"url":"https://e/video"}]""")
        assertEquals("https://www.youtube.com/watch?v=abc_12", trailer.previewUrl)
        assertEquals("https://e/trailer", load(""""trailers":[{"source":"https://e/trailer"}]""").previewUrl)
        assertEquals("https://e/video", load(""""videos":[{"url":"invalid","src":"https://e/skipped"},{"src":"https://e/video"}]""").previewUrl)
        val missing = load(""""videos":[]""")
        assertNull(missing.previewUrl)
        val saved = restoreFavorite(requireNotNull(trailer.catalogFavoriteKey()), encodeFavorite(trailer.compactFavorite()))!!
        assertEquals(trailer.previewUrl, missing.withSavedFavoriteFields(saved).previewUrl)
        assertEquals(direct.previewUrl, direct.withSavedFavoriteFields(saved).previewUrl)
    }

    @Test fun rejectsExternalEndpointBeforeFetching() {
        var requests = 0
        assertThrows(IllegalArgumentException::class.java) {
            loadOfficialCatalog { requests++; manifest.replace("/api/catalog-rows", "https://unexpected.example/batch") }
        }
        assertEquals(1, requests)
    }
}
