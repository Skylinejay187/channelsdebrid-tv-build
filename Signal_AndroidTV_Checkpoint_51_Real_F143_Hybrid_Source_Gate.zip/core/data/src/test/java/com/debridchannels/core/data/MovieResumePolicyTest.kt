package com.debridchannels.core.data

import com.debridchannels.core.data.MovieResumePolicy.Update.*
import org.junit.Assert.assertEquals
import org.junit.Test

class MovieResumePolicyTest {
    @Test fun eligibilityStartsAtEightSecondsIncludingUnknownDuration() {
        val policy = MovieResumePolicy(0)
        assertEquals(KEEP, policy.update(7999, 100000, true))
        assertEquals(SAVE, policy.update(8000, -1, false))
        assertEquals(SAVE, policy.update(94999, 100000, true))
    }

    @Test fun nearCompletionClearsOnlyOnExitAndInvalidClockNeverClears() {
        val policy = MovieResumePolicy(0)
        assertEquals(KEEP, policy.update(95000, 100000, false))
        assertEquals(CLEAR, policy.update(95000, 100000, true))
        assertEquals(SAVE, policy.update(95000, 100001, true))
        assertEquals(CLEAR, policy.update(105000, 100000, true))
        assertEquals(KEEP, policy.update(105001, 100000, true))
    }

    @Test fun restoredTargetSurvivesPrematureClocksAndAllowsDeliberateRewind() {
        val policy = MovieResumePolicy(60000)
        assertEquals(KEEP, policy.update(8000, 100000, true))
        assertEquals(KEEP, policy.update(55999, 100000, false))
        assertEquals(SAVE, policy.update(56000, 100000, false))
        policy.seekTo(15000)
        assertEquals(SAVE, policy.update(15000, 100000, true))
    }
}
