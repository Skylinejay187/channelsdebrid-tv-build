package com.debridchannels.core.data

import org.junit.Assert.*
import org.junit.Test
import java.net.URI
import java.util.concurrent.CancellationException

class OfficialCatalogPagingTest {
    private fun meta(n: Int) = """{"id":"id$n","name":"Movie $n","poster":"https://example.com/$n.jpg"}"""
    private fun page(ids: Iterable<Int>) = ids.joinToString(",", """{"metas":[""", "]}") { meta(it) }

    private fun fixture(url: URI, next: (URI) -> String): String = when (url.path) {
        "/manifest.json" -> """{"debridChannels":{"batchRowsURL":"/rows"},"catalogs":[{"type":"movie","id":"action hits"}]}"""
        "/rows" -> """{"rows":[{"id":"action hits","metas":[${(1..12).joinToString(",") { meta(it) }}]}]}"""
        else -> next(url)
    }

    @Test fun fallbackDeduplicatesAndAdvancesByRawCount() {
        val paths = mutableListOf<String>()
        val result = reloadOfficialCatalog(fetch = { url -> fixture(url) {
            paths.add(it.rawPath + (it.query?.let { query -> "?$query" } ?: ""))
            when (paths.size) {
                1 -> page(1..12)
                2 -> page(listOf(12, 13, 13, 14, 15, 16, 17, 18))
                3 -> page(listOf(19))
                else -> error("Unexpected fetch")
            }
        } })
        assertEquals(listOf("/catalog/movie/action%20hits.json?skip=12", "/catalog/movie/action%20hits/skip=12.json",
            "/catalog/movie/action%20hits.json?skip=20"), paths)
        assertEquals((1..19).map { "id$it" }, result.batch.rows.single().items.map { it.id })
        assertTrue(result.failedRows.isEmpty())
    }

    @Test fun bothEndpointsFailAndSeedSurvives() {
        val result = reloadOfficialCatalog(fetch = { fixture(it) { error("Offline") } })
        assertEquals(listOf("MOVIE:action hits at offset 12"), result.failedRows)
        assertEquals(12, result.batch.rows.single().items.size)
    }

    @Test fun repeatPagesTerminateNormally() {
        var calls = 0
        val result = reloadOfficialCatalog(fetch = { fixture(it) { calls++; page(1..12) } })
        assertEquals(2, calls)
        assertTrue(result.failedRows.isEmpty())
    }

    @Test fun longRowStopsAfterEightPages() {
        var calls = 0
        val result = reloadOfficialCatalog(fetch = { fixture(it) { url ->
            val offset = url.query.substringAfter('=').toInt()
            calls++
            page(offset + 1..offset + 10)
        } })
        assertEquals(8, calls)
        assertEquals(92, result.batch.rows.single().items.size)
    }

    @Test(expected = CancellationException::class)
    fun cancelledPageDoesNotReturnPartialReload() {
        reloadOfficialCatalog(fetch = { fixture(it) { throw CancellationException() } })
    }
}
