package com.debridchannels.core.data

import com.debridchannels.core.model.MediaItem
import com.debridchannels.core.model.MediaType
import com.sun.net.httpserver.HttpServer
import kotlinx.coroutines.*
import java.net.InetSocketAddress
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import org.junit.Assert.*
import org.junit.Test

class SharedArtworkLookupTest {
    private val movie = MediaItem("tt123", "Title", MediaType.MOVIE, null, "", "", "", "")
    private val fan = "https://art.example/f.jpg"
    private val tmdb = "https://image.tmdb.org/t/p/original/m.jpg"

    private fun fixture(fail: String = "", gate: Pair<CountDownLatch, CountDownLatch>? = null,
                        check: (String, List<String>) -> Unit) {
        val paths = CopyOnWriteArrayList<String>()
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/") { exchange ->
            val path = exchange.requestURI.path
            paths.add(path)
            val body = when (path) {
                "/find/tt123" -> {
                    gate?.first?.countDown()
                    gate?.second?.await(3, TimeUnit.SECONDS)
                    """{"movie_results":[{"id":42}]}"""
                }
                "/movies/42" -> """{"moviebackground":[{"url":"$fan"}]}"""
                "/movie/42/images" -> """{"backdrops":[{"file_path":"/m.jpg"}]}"""
                else -> "{}"
            }.toByteArray()
            exchange.sendResponseHeaders(if (path == fail) 503 else 200, body.size.toLong())
            exchange.responseBody.use { it.write(body) }
        }
        server.start()
        try { check("http://127.0.0.1:${server.address.port}", paths) }
        finally { server.stop(0) }
    }

    @Test fun oneFindSuppliesBothProvidersAndFailuresAreIndependent() {
        for ((failure, expected) in listOf("" to listOf(fan, tmdb), "/movies/42" to listOf(tmdb),
            "/movie/42/images" to listOf(fan))) {
            fixture(failure) { base, paths ->
                assertEquals(expected, runBlocking { premiumDetailBackdrops(movie, "t", "f", base, base, base) })
                assertEquals(listOf("/api/artwork/resolve", "/find/tt123", "/movie/42/images", "/movies/42").sorted(), paths.sorted())
            }
        }
    }

    @Test fun catalogMovieIdWorksWithOnlyFanartKey() {
        fixture { base, paths ->
            assertEquals(listOf(fan), runBlocking { premiumDetailBackdrops(movie.copy(tmdbId = "42"), "", "f", base, base, base) })
            assertEquals(listOf("/api/artwork/resolve", "/movies/42"), paths.sorted())
        }
    }

    @Test fun cancellationDuringDiscoveryNeverStartsImageLookups() {
        val started = CountDownLatch(1)
        val release = CountDownLatch(1)
        fixture(gate = started to release) { base, paths ->
            runBlocking {
                val request = async(Dispatchers.Default) { premiumDetailBackdrops(movie, "t", "f", base, base, base) }
                try { assertTrue(started.await(3, TimeUnit.SECONDS)); request.cancel() }
                finally { release.countDown() }
                request.join()
                assertTrue(request.isCancelled)
            }
            assertFalse(paths.any { it.startsWith("/movies/") || it.endsWith("/images") })
        }
    }
}
