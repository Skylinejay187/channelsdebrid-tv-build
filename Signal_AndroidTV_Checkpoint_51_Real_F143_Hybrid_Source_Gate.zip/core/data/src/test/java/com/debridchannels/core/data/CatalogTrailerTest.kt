package com.debridchannels.core.data

import com.debridchannels.core.model.MediaItem
import com.debridchannels.core.model.MediaType
import org.junit.Assert.*
import org.junit.Test

class CatalogTrailerTest {
    private val item = MediaItem("a", "Title", MediaType.MOVIE, null, "", "", "", "")

    @Test fun directMovieAndSeriesTrailersStartAtZeroWithTheirOwnIdentity() {
        for (kind in listOf(MediaType.MOVIE, MediaType.SHOW)) {
            for (path in listOf("clip.MP4", "a.m3u8", "a.mov", "a.m4v", "playback/42", "preview/42", "video/42")) {
                val url = "https://cdn.example/$path?sig=A%2FB"
                val request = requireNotNull(item.copy(type = kind, previewUrl = url).directTrailerRequest())
                val session = MovieStartupRecovery(request, emptyList())
                assertEquals(url, session.current.sourceUrl)
                assertEquals("trailer:a", request.mediaId)
                assertEquals(0L, session.current.resumePositionMs)
            }
        }
    }

    @Test fun webPagesAndInvalidCatalogUrlsNeverLaunch() {
        for (url in listOf(null, "", "file:///tmp/a.mp4", "bad", "https://cdn.example/page?next=a.mp4",
            "https://m.youtube.com/watch?v=preview", "https://youtu.be/video", "https://player.vimeo.com/video/123",
            "https://www.youtube-nocookie.com/embed/video", "https://user@cdn.example/video")) {
            assertNull(item.copy(previewUrl = url).directTrailerRequest())
        }
        assertNull(item.copy(type = MediaType.LIVE_CHANNEL, previewUrl = "https://e/clip.mp4").directTrailerRequest())
    }
}
