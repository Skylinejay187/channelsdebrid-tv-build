package com.debridchannels.core.data

import com.debridchannels.core.model.*
import org.junit.Assert.*
import org.junit.Test

class CatalogFocusReturnTest {
    private val title = MediaItem("selected", "Title", MediaType.MOVIE, 2026, "", "", "", "")
    private val other = title.copy(id = "other", title = "Another film")
    private val origin = CatalogFocusReturn("source", title, CatalogCardPosition(1, 5))
    private fun row(id: String, vararg items: MediaItem) = CatalogRow(id, id, items = items.toList())

    @Test fun removalFavorsAdjacentCardEvenWhenAnotherShelfContainsRemovedMovie() {
        val rows = listOf(row("duplicate", title), row("source", other, other.copy(id = "next")))
        assertEquals(CatalogCardPosition(1, 0),
            origin.copy(position = CatalogCardPosition(1, 0)).nearestRemainingCard(rows))
        assertEquals(CatalogCardPosition(1, 1), origin.nearestRemainingCard(rows))
    }

    @Test fun removingFinalShelfCardUsesNearestPopulatedRowOrNoTarget() {
        assertEquals(CatalogCardPosition(2, 0), origin.nearestRemainingCard(
            listOf(row("empty"), row("empty2"), row("next", other), row("later", title))))
        assertNull(origin.nearestRemainingCard(emptyList()))
    }

    @Test fun duplicateOnAnotherShelfDoesNotStealReturn() {
        val rows = listOf(row("source", other, title.copy(title = "New metadata")), row("duplicate", title))
        assertEquals(CatalogCardPosition(0, 1), origin.resolve(rows))
    }

    @Test fun movedItemUsesCorrectTypeAfterSourceRowDisappears() {
        val rows = listOf(row("series", title.copy(type = MediaType.SHOW)), row("movies", title))
        assertEquals(CatalogCardPosition(1, 0), origin.resolve(rows))
    }

    @Test fun missingCardUsesClosestPositionOnSourceShelf() {
        assertEquals(CatalogCardPosition(1, 0), origin.resolve(listOf(row("empty"), row("source", other))))
    }

    @Test fun missingShelfFallsBackToNearestNonemptyShelf() {
        assertEquals(CatalogCardPosition(2, 0), origin.resolve(listOf(row("one"), row("two"), row("three", other))))
    }

    @Test fun emptyShelvesHaveNoFocusTarget() = assertNull(origin.resolve(listOf(row("empty"))))

    @Test fun providerAliasOnSourceShelfBeatsExactCopyElsewhere() {
        val selected = title.copy(id = "addon:TT123")
        val alias = title.copy(id = "new", imdbId = "tt123")
        val rows = listOf(row("duplicate", selected), row("source", other, alias, other))
        assertEquals(CatalogCardPosition(1, 1), origin.copy(item = selected).resolve(rows))
    }

    @Test fun conflictingProviderPreventsAliasedMatch() {
        val selected = title.copy(imdbId = "tt123", tmdbId = "1")
        val different = selected.copy(id = "new", tmdbId = "2")
        assertEquals(CatalogCardPosition(0, 1), origin.copy(item = selected).resolve(
            listOf(row("source", different, other))))
    }

    @Test fun episodeNumbersPreventSeriesIdCollision() {
        val selected = title.copy(id = "tt456:1:2", type = MediaType.EPISODE)
        val rows = listOf(row("source", selected.copy(id = "p:tt456:1:3"), selected.copy(id = "p:tt456:1:2"), other))
        assertEquals(CatalogCardPosition(0, 1), origin.copy(item = selected).resolve(rows))
    }

    @Test fun crossProviderTitleYearReturnsToOriginalShelf() {
        val selected = title.copy(title = "L’été: 2049!")
        val alias = selected.copy(id = "provider-b", title = "L’ÉTÉ 2049")
        val rows = listOf(row("duplicate", selected), row("source", other, alias, other))
        assertEquals(CatalogCardPosition(1, 1), origin.copy(item = selected).resolve(rows))
    }

    @Test fun missingYearRemakeAndEmptyTitleCannotBridge() {
        for (candidate in listOf(title.copy(year = null), title.copy(year = 1994), title.copy(title = "---"))) {
            assertEquals(CatalogCardPosition(0, 1), origin.resolve(listOf(row("source", candidate.copy(id = "new"), other))))
        }
        val empty = title.copy(title = "!!!")
        assertEquals(CatalogCardPosition(0, 1), origin.copy(item = empty).resolve(
            listOf(row("source", empty.copy(id = "new", title = "..."), other))))
    }

    @Test fun strongerProviderIdentityWinsOverEarlierTitleYearOnSameShelf() {
        val selected = title.copy(imdbId = "tt123")
        val weak = title.copy(id = "weak")
        val strong = title.copy(id = "strong", imdbId = "tt123")
        assertEquals(CatalogCardPosition(0, 1), origin.copy(item = selected).resolve(
            listOf(row("source", weak, strong, other))))
    }

    @Test fun titleYearOnlyEpisodeMatchRequiresMatchingSeasonAndEpisode() {
        val episode = title.copy(id = "a:01:02", type = MediaType.EPISODE)
        val rows = listOf(row("source", episode.copy(id = "b:1:3"), episode.copy(id = "b:1:2"), other))
        assertEquals(CatalogCardPosition(0, 1), origin.copy(item = episode).resolve(rows))
    }

    @Test fun titleYearCannotOverrideAConflictingIdentifierFromAnyProvider() {
        val selected = title.copy(imdbId = "tt123", tmdbId = "2", tvdbId = "3")
        for (conflict in listOf(selected.copy(imdbId = "tt456"), selected.copy(tmdbId = "7"),
            selected.copy(tvdbId = "8"))) {
            val rows = listOf(row("source", conflict.copy(id = "changed"), other))
            assertEquals(CatalogCardPosition(0, 1), origin.copy(item = selected).resolve(rows))
        }
    }

    @Test fun unnumberedEpisodesDoNotMatchByTitleYearAlone() {
        val selected = title.copy(type = MediaType.EPISODE)
        val rows = listOf(row("source", selected.copy(id = "changed"), other))
        assertEquals(CatalogCardPosition(0, 1), origin.copy(item = selected).resolve(rows))
    }
}
