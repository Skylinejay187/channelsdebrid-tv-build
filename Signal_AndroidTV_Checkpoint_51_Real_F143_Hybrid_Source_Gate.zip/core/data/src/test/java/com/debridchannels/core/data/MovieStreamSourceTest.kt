package com.debridchannels.core.data

import com.debridchannels.core.model.*
import org.junit.Assert.*
import org.junit.Test

class MovieStreamSourceTest {
    private val movie = MediaItem("custom/a?b", "Film", MediaType.MOVIE, null, "", "", "", "", imdbId = "tt123")
    private val manifest = sourceManifestUri("https://provider.example/config/manifest.json?key=x%2By")!!

    @Test fun honorsResourceRestrictionsAndForwardsSignedUrlAndRequestHeaders() {
        val urls = mutableListOf<String>()
        val result = resolveMoviePlayback(movie, manifest) {
            urls.add(it.toString())
            if (it == manifest) """{"resources":[{"name":"stream","types":["movie"],"idPrefixes":["tt"]}]}"""
            else """{"streams":[{"externalUrl":"https://site.example/watch"},{"url":"https://cdn.example/downloading.mp4"},{"url":"https://cdn.example/signed?sig=x%2By","behaviorHints":{"proxyHeaders":{"request":{"Referer":"https://source.example/"}}}}]}"""
        }
        assertEquals(listOf(manifest.toString(),"https://provider.example/config/stream/movie/tt123.json?key=x%2By"), urls)
        assertEquals("https://cdn.example/signed?sig=x%2By", result?.sourceUrl)
        assertEquals(mapOf("Referer" to "https://source.example/"), result?.headers)
        assertEquals(movie.id, result?.mediaId)
    }

    @Test fun escapedItemIdStaysInOneSegmentAndEmptyResponseTriesAlias() {
        val paths = mutableListOf<String>()
        assertNull(resolveMoviePlayback(movie, manifest) {
            if (it == manifest) """{"resources":["stream"],"types":["movie"]}"""
            else { paths.add(it.rawPath); """{"streams":[{"infoHash":"hash"},{"url":"https://host/configure"}]}""" }
        })
        assertEquals(listOf("/config/stream/movie/custom%2Fa%3Fb.json", "/config/stream/movie/tt123.json"), paths)
    }

    @Test fun catalogOnlyManifestDoesNotReceiveStreamRequests() {
        assertNull(resolveMoviePlayback(movie, manifest) { assertEquals(manifest,it); """{"resources":["catalog"]}""" })
    }

    @Test fun unavailableFirstIdFallsBackToImdbAlias() {
        val result = resolveMoviePlayback(movie, manifest) {
            when {
                it == manifest -> """{"resources":["stream"]}"""
                it.path.endsWith("tt123.json") -> """{"streams":[{"url":"https://cdn.example/direct","behaviorHints":null}]}"""
                else -> throw java.io.IOException("HTTP 404")
            }
        }
        assertEquals("https://cdn.example/direct", result?.sourceUrl)
    }

    @Test(expected = java.io.IOException::class)
    fun failedEndpointsAreReportedAsProviderErrors() {
        resolveMoviePlayback(movie, manifest) {
            if (it == manifest) """{"resources":["stream"]}""" else throw java.io.IOException("offline")
        }
    }

    @Test fun rejectsConfigurationPageAndUnencryptedManifest() {
        assertNull(sourceManifestUri("https://provider.example/configure"))
        assertNull(sourceManifestUri("http://provider.example/manifest.json"))
    }

    @Test fun manualSelectionKeepsProviderOrderAndTheSelectedRequestsHeaders() {
        val results = findMovieSources(movie, manifest, 25) {
            if (it == manifest) """{"name":"Fixture","resources":["stream"]}"""
            else """{"streams":[{"externalUrl":"https://site.example"},
                {"title":"First","url":"https://cdn.example/one","behaviorHints":{"proxyHeaders":{"request":{"Referer":"one"}}}},
                {"title":"Repeat","url":"https://cdn.example/one"},
                {"name":"Second","url":"https://cdn.example/two?sig=a%2Fb","behaviorHints":{"videoSize":1200,"proxyHeaders":{"request":{"Referer":"two"}}}}]}"""
        }
        assertEquals(listOf("First", "Second"), results.map { it.label })
        val selected = results[1]
        assertEquals(movie.id, selected.playback.mediaId)
        assertEquals("https://cdn.example/two?sig=a%2Fb", selected.playback.sourceUrl)
        assertEquals(mapOf("Referer" to "two"), selected.playback.headers)
        assertEquals("Fixture", selected.provider)
        assertEquals(1200L, selected.sizeBytes)
    }

    @Test fun limitCountsPlayableUniqueFilesAndSkipsRedundantIdLookups() {
        for (limit in listOf(1, 25, 50)) {
            var requests = 0
            val results = findMovieSources(movie, manifest, limit) {
                if (it == manifest) """{"resources":["stream"]}"""
                else {
                    requests++
                    (1..55).joinToString(",", """{"streams":[""", "]}") { n ->
                        """{"url":"https://cdn.example/video","fileIdx":$n,"behaviorHints":{"filename":"File $n"}}"""
                    }
                }
            }
            assertEquals(1, requests)
            assertEquals(limit, results.size)
            assertEquals("File $limit", results.last().label)
        }
    }
}
