package com.debridchannels.core.data

import com.debridchannels.core.model.MediaItem
import com.debridchannels.core.model.MediaType
import org.junit.Assert.*
import org.junit.Test

class DetailBackdropSessionTest {
    private val movie = MediaItem("addon:tt123", "One", MediaType.MOVIE, 2025, "", "", "", "")

    @Test fun reopeningThroughAnotherCatalogUsesCachedPoolInOrder() {
        val session = DetailBackdropSession()
        var fetches = 0
        fun open(item: MediaItem) = session.next(item) ?: run {
            fetches++
            session.next(item, listOf("a", "b", "c"))
        }
        assertEquals("a", open(movie))
        val alias = movie.copy(id = "catalog2", imdbId = "tt123")
        assertEquals("b", open(alias))
        assertEquals("c", open(movie))
        assertEquals("a", open(alias))
        assertEquals(1, fetches)
    }

    @Test fun missesAndNewSessionsCanRetryAndTitlesHaveIndependentCursors() {
        val session = DetailBackdropSession()
        assertNull(session.next(movie, emptyList()))
        assertEquals("a", session.next(movie, listOf("a", "b")))
        assertNull(session.next(movie.copy(type = MediaType.SHOW)))
        assertNull(session.next(movie.copy(id = "tt999")))
        assertEquals("b", session.next(movie))
        assertNull(DetailBackdropSession().next(movie))
    }

    @Test fun titleFallbackSeparatesRemakesAndSingleImageRepeatsSafely() {
        val session = DetailBackdropSession()
        val bare = movie.copy(id = "")
        assertEquals("only", session.next(bare, listOf("only")))
        assertNull(session.next(bare.copy(year = 1950)))
        assertEquals("only", session.next(bare))
    }
}
