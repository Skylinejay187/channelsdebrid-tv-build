package com.debridchannels.core.data

import com.debridchannels.core.model.*
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class OfficialCatalogSnapshotsTest {
    @get:Rule val folder = TemporaryFolder()
    private fun store() = OfficialCatalogSnapshots(folder.root)
    private fun row(n: Int, count: Int = 10, name: String = "Row $n") = CatalogRow(
        "movie:$n", name, items = (1..count).map {
            MediaItem("$n-$it", "Movie $it", MediaType.MOVIE, null, "", "", "", "", posterUrl = "https://image.example/$it")
        })
    private val rows = (1..46).map { row(it) }
    @Test fun restartsOfflineWithProvisionalRows() {
        store().accept(OfficialCatalogBatch(rows, 83))
        assertEquals(rows, store().restore())
    }
    @Test fun rejectsIncompleteColdStartWithoutWriting() {
        assertThrows(IllegalArgumentException::class.java) { store().accept(OfficialCatalogBatch(rows.take(45), 83)) }
        assertTrue(store().restore().isEmpty())
    }
    @Test fun partialRefreshKeepsMissingAndTruncatedRows() {
        store().accept(OfficialCatalogBatch(rows, 83))
        val revised = row(3, 7, "Updated")
        val next = store().accept(OfficialCatalogBatch(listOf(row(1, 6), revised, row(47)), 83))
        assertEquals(rows.toMutableList().apply { set(2, revised); add(row(47)) }, next)
        assertEquals(next, store().restore())
    }
    @Test fun corruptCurrentRestoresPreviousAndRecoversOnNextWrite() {
        store().accept(OfficialCatalogBatch(rows, 83))
        store().accept(OfficialCatalogBatch(rows + row(47), 83))
        folder.root.resolve("official-catalog-v1.json").writeText("{")
        assertEquals(rows, store().restore())
        val recovered = store().accept(OfficialCatalogBatch(rows + row(48), 83))
        assertEquals(recovered, store().restore())
    }

    @Test fun changedIdAndNormalizedTitleKeepPositionAcrossRestart() {
        store().accept(OfficialCatalogBatch(rows, 83))
        val replacement = row(92, name = " rOw_-2 ")
        val merged = store().accept(OfficialCatalogBatch(listOf(replacement), 83))
        assertEquals(rows.toMutableList().apply { set(1, replacement) }, merged)
        assertEquals(merged, store().restore())
    }

    @Test fun exactMatchWinsOverEarlierRowWithSameTitle() {
        val baseline = rows.toMutableList().apply { set(0, row(1, name = "Row 2")) }
        store().accept(OfficialCatalogBatch(baseline, 83))
        val exact = row(2, 8)
        val merged = store().accept(OfficialCatalogBatch(listOf(exact), 83))
        assertEquals(baseline.toMutableList().apply { set(1, exact) }, merged)
    }

    @Test fun ambiguousTitlesRetainBothOriginals() {
        val baseline = rows.toMutableList().apply { set(0, row(1, name = "Row 2")) }
        store().accept(OfficialCatalogBatch(baseline, 83))
        val incoming = row(91, name = "Row 2")
        assertEquals(baseline + incoming, store().accept(OfficialCatalogBatch(listOf(incoming), 83)))
    }

    @Test fun manifestConfirmedTypeCorrectionCanReplaceLargerRow() {
        store().accept(OfficialCatalogBatch(rows, 83))
        val old = rows.first()
        val corrected = old.copy(id = "SHOW:1", items = old.items.take(2).map { it.copy(type = MediaType.SHOW) })
        val merged = store().accept(OfficialCatalogBatch(listOf(corrected), 83, setOf(corrected.id)))
        assertEquals(listOf(corrected) + rows.drop(1), merged)
        assertEquals(merged, store().restore())
    }

    @Test fun sharedManifestIdCannotMergeMoviesAndShows() {
        store().accept(OfficialCatalogBatch(rows, 83))
        val old = rows.first()
        val show = old.copy(id = "SHOW:1", items = old.items.map { it.copy(type = MediaType.SHOW) })
        assertEquals(rows + show, store().accept(OfficialCatalogBatch(listOf(show), 83)))
    }

    @Test fun fullerRollbackRepairsValidButShorterCurrentWithoutNetwork() {
        store().accept(OfficialCatalogBatch(rows, 83))
        val current = folder.root.resolve("official-catalog-v1.json")
        val smaller = current.readBytes()
        val fuller = rows + row(47)
        store().accept(OfficialCatalogBatch(fuller, 83))
        val previous = folder.root.resolve("official-catalog-v1.previous.json")
        current.copyTo(previous, overwrite = true)
        current.writeBytes(smaller)
        assertEquals(fuller.map { it.id }, store().restore().map { it.id })
        assertArrayEquals(previous.readBytes(), current.readBytes())
    }

    @Test fun corruptCopyHealsBeforeAnotherRefresh() {
        store().accept(OfficialCatalogBatch(rows, 83))
        store().accept(OfficialCatalogBatch(rows + row(47), 83))
        val current = folder.root.resolve("official-catalog-v1.json")
        current.writeText("{")
        assertEquals(rows, store().restore())
        assertTrue(folder.root.resolve("official-catalog-v1.previous.json").delete())
        assertEquals(rows, store().restore())
    }

    @Test fun fullCatalogPromotionLeavesRecoverableProvisionalCopy() {
        store().accept(OfficialCatalogBatch(rows, 83))
        val full = (1..83).map { row(it) }
        store().accept(OfficialCatalogBatch(full, 83))
        val updated = full.toMutableList().apply { set(0, row(1, name = "Updated metadata")) }
        store().accept(OfficialCatalogBatch(updated, 83))
        assertEquals(updated, store().restore())
        folder.root.resolve("official-catalog-v1.protected.json").writeText("{")
        assertEquals(full, store().restore())
        folder.root.resolve("official-catalog-v1.protected.json").writeText("{")
        folder.root.resolve("official-catalog-v1.protected.previous.json").writeText("{")
        assertEquals(rows, store().restore())
    }

    @Test fun legacyFullSnapshotPromotesOnAnUnchangedRefresh() {
        val legacy = folder.root.resolve("official-catalog-v1.json")
        val full = (1..83).map { row(it) }
        legacy.writeText(com.google.gson.Gson().toJson(full))
        assertEquals(full, store().restore())
        assertEquals(full, store().accept(OfficialCatalogBatch(full, 83)))
        assertTrue(legacy.delete())
        assertEquals(full, store().restore())
    }

    @Test fun refreshUsesFullerRollbackEvenBeforeOfflineRestore() {
        val legacy = folder.root.resolve("official-catalog-v1.json")
        val previous = folder.root.resolve("official-catalog-v1.previous.json")
        legacy.writeText(com.google.gson.Gson().toJson(rows))
        previous.writeText(com.google.gson.Gson().toJson(rows + row(47)))
        val refreshed = store().accept(OfficialCatalogBatch(listOf(row(48)), 83))
        assertEquals((1..48).map { "movie:$it" }, refreshed.map { it.id })
        assertEquals(refreshed, store().restore())
        assertEquals(47, com.google.gson.JsonParser.parseString(previous.readText()).asJsonArray.size())
    }
}
