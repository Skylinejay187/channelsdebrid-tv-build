package com.debridchannels.core.data

import com.debridchannels.core.model.*
import org.junit.Assert.*
import org.junit.Test

class CatalogHeroFocusTest {
    private fun movie(id: String) = MediaItem(id, id, MediaType.MOVIE, 2026, "", "", "", "")
    private val first = movie("first")
    private val second = movie("second")
    private val rows = listOf(CatalogRow("empty", "", items = emptyList()), CatalogRow("movies", "", items = listOf(first, second)))

    @Test fun initialFocusSkipsEmptyRows() = assertEquals(first, focusedCatalogItem(rows, null))
    @Test fun focusTracksCardAndRefresh() {
        assertEquals(second, focusedCatalogItem(rows, second.id))
        val refreshed = second.copy(title = "New title")
        assertEquals(refreshed, focusedCatalogItem(listOf(CatalogRow("new", "", items = listOf(refreshed))), second.id))
    }
    @Test fun removedItemFallsBack() = assertEquals(first, focusedCatalogItem(rows, "removed"))
    @Test fun emptyCatalogClearsHero() = assertNull(focusedCatalogItem(emptyList(), second.id))
}
