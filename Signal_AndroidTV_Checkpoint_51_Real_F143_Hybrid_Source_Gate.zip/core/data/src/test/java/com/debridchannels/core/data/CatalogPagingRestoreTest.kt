package com.debridchannels.core.data

import java.net.URI
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class CatalogPagingRestoreTest {
    @get:Rule val folder = TemporaryFolder()
    private val store get() = OfficialCatalogSnapshots(folder.root)
    private var firstTitle = "Original"
    private var firstId = 1
    private var extra = 3

    private fun meta(id: Int, title: String = "Title $id") =
        """{"id":"$id","name":"$title","poster":"https://art.example/$id.jpg"}"""

    private fun row(id: Int): String {
        val cards = if (id == 1) listOf(meta(firstId, firstTitle)) + (2..12).map { meta(it) }
            else listOf(meta(1), meta(2))
        return """{"id":"$id","type":"movie","metas":[${cards.joinToString()}]}"""
    }

    private fun fetch(uri: URI): String = when (uri.path) {
        "/manifest.json" -> """{"debridChannels":{"batchRowsURL":"/batch"}}"""
        "/batch" -> (1..46).joinToString(",", """{"rows":[""", "]}") { row(it) }
        "/catalog/movie/1.json" -> (13 until 13 + extra).joinToString(",", """{"metas":[""", "]}") { meta(it) }
        else -> error("Unexpected URL $uri")
    }

    private fun refresh() = OfficialCatalogRefresh(fetch = { uri ->
        check(uri.path == "/manifest.json") { "Unexpected full-batch fallback" }
        fetch(uri)
    }, post = { _, _ ->
        val order = (1..46).map { """{"key":"$it","revision":"2"}""" }
        val changes = (1..46).map { """{"key":"$it","revision":"2","row":${row(it)}}""" }
        """{"order":[${order.joinToString()}],"rows":[${changes.joinToString()}]}"""
    }).refresh(store::accept)

    @Test fun pagedTailAndFreshMetadataSurviveDeltaAndOfflineRestart() {
        val loaded = store.accept(reloadOfficialCatalog(fetch = ::fetch).batch)
        assertEquals(15, loaded.first().items.size)
        firstTitle = "Revised"
        val refreshed = refresh()
        assertEquals(loaded.first().items.map { it.id }, refreshed.first().items.map { it.id })
        assertEquals(firstTitle, refreshed.first().items.first().title)
        assertEquals(refreshed, store.restore())
    }

    @Test fun changedSeedDropsUnverifiedTail() {
        store.accept(reloadOfficialCatalog(fetch = ::fetch).batch)
        firstId = 99
        val row = refresh().first()
        assertEquals(listOf("99") + (2..12).map { it.toString() }, row.items.map { it.id })
        assertEquals(row, store.restore().first())
    }

    @Test fun successfulManualReloadWithEmptyPagesClearsTail() {
        store.accept(reloadOfficialCatalog(fetch = ::fetch).batch)
        extra = 0
        val row = store.accept(reloadOfficialCatalog(fetch = {
            if (it.path.endsWith("/skip=12.json")) """{"metas":[]}""" else fetch(it)
        }).batch).first()
        assertEquals(12, row.items.size)
        assertEquals(row, store.restore().first())
    }

    @Test fun shorterSuccessfulManualPageReplacesTail() {
        store.accept(reloadOfficialCatalog(fetch = ::fetch).batch)
        extra = 1
        val row = store.accept(reloadOfficialCatalog(fetch = ::fetch).batch).first()
        assertEquals((1..13).map { it.toString() }, row.items.map { it.id })
        assertEquals(row, store.restore().first())
    }
}
