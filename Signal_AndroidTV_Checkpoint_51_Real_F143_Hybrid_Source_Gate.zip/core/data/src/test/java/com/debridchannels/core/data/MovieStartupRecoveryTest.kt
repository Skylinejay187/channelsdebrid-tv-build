package com.debridchannels.core.data

import com.debridchannels.core.model.MediaType
import com.debridchannels.core.model.PlaybackRequest
import com.debridchannels.core.data.MovieStartupRecovery.Action
import org.junit.Assert.*
import org.junit.Test

class MovieStartupRecoveryTest {
    private fun option(token: String, id: String = "movie") = MovieSourceOption(
        token, PlaybackRequest(id, MediaType.MOVIE, "Title", "https://example.org/video?sig=$token",
            headers = mapOf("Authorization" to token)), null, null)

    @Test fun selectedFirstAndOnlyThreeUniqueSameMovieAlternates() {
        val selected = option("chosen").playback.copy(resumePositionMs = 8000)
        val recovery = MovieStartupRecovery(selected, listOf(option("wrong", "other"), option("a"),
            option("chosen"), option("a"), option("b"), option("c"), option("d")))
        assertEquals(selected, recovery.current)
        for (token in listOf("a", "b", "c")) {
            assertEquals(Action.ADVANCE, recovery.failed(false, 550))
            assertEquals(option(token).playback.copy(resumePositionMs = 8000), recovery.current)
        }
        assertEquals(Action.STOP, recovery.failed(false, 0))
    }

    @Test fun transientRetryOncePerSourceKeepsCurrentPosition() {
        val a = option("a").playback
        val b = option("b")
        val recovery = MovieStartupRecovery(a, listOf(b))
        assertEquals(Action.RETRY, recovery.failed(true, 3200))
        assertEquals(a.copy(resumePositionMs = 3200), recovery.current)
        assertEquals(Action.ADVANCE, recovery.failed(true, 0))
        assertEquals(b.playback.copy(resumePositionMs = 3200), recovery.current)
        assertEquals(Action.RETRY, recovery.failed(true, 4100))
        assertEquals(Action.STOP, recovery.failed(true, 0))
        assertEquals(4100L, recovery.current.resumePositionMs)
    }

    @Test fun firstRenderedFrameDisablesRetryAndSwitch() {
        val a = option("a").playback
        val recovery = MovieStartupRecovery(a, listOf(option("b")))
        recovery.firstFrame()
        assertEquals(Action.STOP, recovery.failed(true, 100))
        assertEquals(Action.STOP, recovery.failed(false, 100))
        assertEquals(a, recovery.current)
    }

    @Test fun backgroundDuringStartupKeepsRequestedPositionOnEachSource() {
        val a = option("a").playback.copy(resumePositionMs = 8000)
        val b = option("b")
        val recovery = MovieStartupRecovery(a, listOf(b))
        recovery.savePosition(0, positionEstablished = false)
        assertEquals(a, recovery.current)
        recovery.savePosition(9100, positionEstablished = false)
        assertEquals(Action.ADVANCE, recovery.failed(false, 0))
        recovery.savePosition(0, positionEstablished = false)
        assertEquals(b.playback.copy(resumePositionMs = 9100), recovery.current)
    }

    @Test fun viewerCanRewindBeforeBackgroundOrDuringStartup() {
        val a = option("a").playback.copy(resumePositionMs = 8000)
        val recovery = MovieStartupRecovery(a, listOf(option("b")))
        recovery.savePosition(1200, positionEstablished = true)
        assertEquals(Action.ADVANCE, recovery.failed(false, 1200))
        assertEquals(1200L, recovery.current.resumePositionMs)
        recovery.firstFrame()
        recovery.savePosition(0, positionEstablished = true)
        assertEquals(0L, recovery.current.resumePositionMs)
    }
}
