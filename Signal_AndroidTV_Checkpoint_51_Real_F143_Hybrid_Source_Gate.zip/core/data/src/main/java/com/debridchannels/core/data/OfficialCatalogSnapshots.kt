package com.debridchannels.core.data

import com.debridchannels.core.model.CatalogRow
import com.google.gson.Gson
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import kotlin.math.ceil

/** Current and previous files live on the same private Android filesystem. */
class OfficialCatalogSnapshots(private val directory: File) {
    private data class Slot(val current: File, val previous: File)
    private data class Saved(val rows: List<CatalogRow>, val file: File, val slot: Slot)

    private val full = Slot(
        File(directory, "official-catalog-v1.protected.json"),
        File(directory, "official-catalog-v1.protected.previous.json"),
    )
    // These original paths also support full snapshots created before the split.
    private val provisional = Slot(
        File(directory, "official-catalog-v1.json"),
        File(directory, "official-catalog-v1.previous.json"),
    )
    private val gson = Gson()
    private val maxBytes = 24_000_000

    private fun read(file: File): List<CatalogRow>? {
        if (file.length() !in 1L..maxBytes.toLong()) return null
        return try {
            file.bufferedReader().use {
                gson.fromJson(it, Array<CatalogRow>::class.java).toList()
            }.takeIf { rows ->
                rows.size >= 24 && rows.distinctBy { it.id }.size == rows.size &&
                    rows.all { row ->
                        row.id.isNotBlank() && row.title.isNotBlank() && row.items.isNotEmpty() &&
                            row.items.all { it.id.isNotBlank() && it.title.isNotBlank() && !it.posterUrl.isNullOrBlank() }
                    }
            }
        } catch (_: RuntimeException) {
            null
        } catch (_: IOException) {
            null
        }
    }

    private fun bestSaved(): Saved? {
        var best: Saved? = null
        for (slot in listOf(full, provisional)) {
            for (file in listOf(slot.current, slot.previous)) {
                val rows = read(file) ?: continue
                // Equal row counts favor current, preserving deliberate page shrinkage
                // and newer metadata after an accepted refresh.
                if (rows.size > (best?.rows?.size ?: 0)) best = Saved(rows, file, slot)
            }
        }
        return best
    }

    private fun repair(saved: Saved) {
        if (saved.file == saved.slot.current) return
        val temp = File.createTempFile("official-catalog-repair-", ".tmp", directory)
        try {
            FileOutputStream(temp).use { output ->
                saved.file.inputStream().use { it.copyTo(output) }
                output.fd.sync()
            }
            if (!temp.renameTo(saved.slot.current)) throw IOException("Cannot restore catalog snapshot")
        } finally {
            temp.delete()
        }
    }

    fun restore(): List<CatalogRow> = synchronized(lock) {
        val saved = bestSaved() ?: return@synchronized emptyList()
        try {
            repair(saved)
        } catch (_: IOException) {
            // A read-only or full disk still permits browsing the rollback file.
        }
        saved.rows
    }

    fun accept(batch: OfficialCatalogBatch): List<CatalogRow> = synchronized(lock) {
        val saved = bestSaved()
        val baseline = saved?.rows.orEmpty()
        val merged = mergeCatalogRows(baseline, batch)
        val minimumRows = if (baseline.isEmpty()) {
            ceil(maxOf(batch.expectedRows, 83) * 0.55).toInt().coerceIn(24, 83)
        } else baseline.size
        require(merged.size >= minimumRows && merged.sumOf { it.items.size } >=
            maxOf(merged.size * 2, (baseline.sumOf { it.items.size } * 0.70).toInt())) {
            "Incomplete official catalog"
        }
        val slot = if (merged.size >= 83) full else provisional
        if (saved?.slot == slot && merged == baseline) {
            repair(saved)
            return@synchronized merged
        }
        val temp = File.createTempFile("official-catalog-", ".tmp", directory)
        try {
            FileOutputStream(temp).use { stream ->
                val writer = stream.bufferedWriter()
                gson.toJson(merged, writer)
                writer.flush()
                stream.fd.sync()
            }
            if (temp.length() > maxBytes) throw IOException("Catalog snapshot exceeds size limit")
            if (saved?.file == slot.current && !slot.current.renameTo(slot.previous)) throw IOException("Cannot retain previous catalog")
            if (!temp.renameTo(slot.current)) throw IOException("Cannot publish catalog snapshot")
        } finally {
            temp.delete()
        }
        merged
    }

    private fun mergeCatalogRows(baseline: List<CatalogRow>, batch: OfficialCatalogBatch): List<CatalogRow> {
        val fresh = batch.rows.associateBy { it.id }
        val replacements = mutableMapOf<String, CatalogRow>()
        val reserved = mutableSetOf<String>()
        fun match(old: CatalogRow, new: CatalogRow) {
            replacements[old.id] = new
            reserved.add(new.id)
        }
        for (old in baseline) fresh[old.id]?.let { match(old, it) }

        // Resolve only one-to-one groups. A shared label must never steal an exact ID match.
        fun matchUnique(key: (CatalogRow) -> String, allowed: (CatalogRow) -> Boolean) {
            val missing = baseline.filter { it.id !in replacements }.groupBy(key)
            val available = batch.rows.filter { it.id !in reserved }.groupBy(key)
            for ((identity, group) in missing) {
                val old = group.singleOrNull() ?: continue
                val new = available[identity]?.singleOrNull() ?: continue
                if (allowed(new)) match(old, new)
            }
        }
        fun title(row: CatalogRow) = row.title.trim().lowercase().filterNot { it == ' ' || it == '-' || it == '_' }
        // Android embeds the manifest type in the ID. Confirm a type correction via the
        // untyped manifest ID before matching changed IDs by title within a media type.
        matchUnique({ it.id.substringAfter(':') }, { it.id in batch.uniquelyDeclaredRowIds })
        matchUnique({ "${it.items.first().type}:${title(it)}" }, { title(it).isNotEmpty() })

        val retained = baseline.map { old ->
            val new = replacements[old.id] ?: return@map old
            val correctedType = new.items.first().type != old.items.first().type
            // An ordinary delta contains only the first page, even after a manual reload.
            // Require the same row, boundary and ordered IDs before reusing its saved tail.
            val boundary = old.pageSeedSize
            if (!correctedType && old.id == new.id && new.pageSeedSize == null &&
                boundary != null && boundary == new.items.size && boundary in 1 until old.items.size &&
                new.items.indices.all { old.items[it].id == new.items[it].id }) {
                return@map new.copy(items = new.items + old.items.drop(boundary), pageSeedSize = boundary)
            }
            if (correctedType || new.items.size >= maxOf(2, ceil(old.items.size * 0.70).toInt())) new else old
        }
        return retained + batch.rows.filter { it.id !in reserved }
    }

    private companion object { val lock = Any() }
}
