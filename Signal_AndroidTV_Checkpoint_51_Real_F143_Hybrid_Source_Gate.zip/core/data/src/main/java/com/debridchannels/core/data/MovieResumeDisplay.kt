package com.debridchannels.core.data

import java.util.Locale
import kotlin.math.roundToInt

data class MovieResumeDisplay(val timestamp: String, val remaining: String, val fraction: Float) {
    val percent: Int get() = (fraction * 100).roundToInt()
}

fun MovieResumeGroup.display(): MovieResumeDisplay? {
    if (positionMs < 8000L || durationMs <= positionMs) return null
    val seconds = positionMs / 1000 + if (positionMs % 1000 >= 500) 1 else 0
    val timestamp = if (seconds >= 3600) {
        String.format(Locale.ROOT, "%d:%02d:%02d", seconds / 3600, seconds / 60 % 60, seconds % 60)
    } else String.format(Locale.ROOT, "%d:%02d", seconds / 60, seconds % 60)
    val minutes = (durationMs - positionMs) / 60000
    val remaining = if (minutes >= 60) "${minutes / 60}h ${minutes % 60}m" else "${minutes.coerceAtLeast(1)}m"
    return MovieResumeDisplay(timestamp, remaining, positionMs.toFloat() / durationMs)
}
