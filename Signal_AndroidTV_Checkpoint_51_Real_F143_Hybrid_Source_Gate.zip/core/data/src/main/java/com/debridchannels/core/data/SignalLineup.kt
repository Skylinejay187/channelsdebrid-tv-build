package com.debridchannels.core.data

import com.debridchannels.core.model.LiveChannel
import java.net.URI
import java.util.UUID

data class SignalStation(val channel: LiveChannel, val url: String, val logo: String?)

private fun secureUrl(value: String?): String? = value?.takeIf {
    runCatching { URI(it).let { uri -> uri.scheme == "https" && !uri.host.isNullOrBlank() } }.getOrDefault(false)
}

private val m3uAttribute = Regex("""([\w-]+)="([^"]*)"""".trimIndent())

/** Extended M3U channel lists only. HLS manifests describe segments of a single stream. */
fun signalStations(text: String): List<SignalStation> {
    require(text.length <= 2_000_000 && !text.contains("#EXT-X-"))
    val stations = linkedMapOf<String, SignalStation>()
    var info: String? = null
    for (raw in text.lineSequence()) {
        val line = raw.trim().removePrefix("\uFEFF")
        if (line.startsWith("#EXTINF:")) { info = line; continue }
        if (line.isEmpty() || line.startsWith("#")) continue
        val metadata = info
        info = null
        val url = secureUrl(line) ?: continue
        val attrs = m3uAttribute.findAll(metadata.orEmpty()).associate { it.groupValues[1] to it.groupValues[2] }
        val title = metadata?.replace(m3uAttribute, "")?.substringAfter(',', "")?.trim().orEmpty()
            .ifEmpty { attrs["tvg-name"].orEmpty() }.ifEmpty { URI(url).host }
        val group = attrs["group-title"].orEmpty()
        val id = UUID.nameUUIDFromBytes(url.toByteArray()).toString()
        val channel = LiveChannel(id, attrs["tvg-chno"] ?: (stations.size + 1).toString(), title,
            "IPTV", "", title, "", "", group, isSports = Regex("sport|espn|nba|nfl|nhl|mlb|soccer", RegexOption.IGNORE_CASE).containsMatchIn("$group $title"))
        stations.putIfAbsent(url, SignalStation(channel, url, secureUrl(attrs["tvg-logo"])))
    }
    return stations.values.toList()
}
