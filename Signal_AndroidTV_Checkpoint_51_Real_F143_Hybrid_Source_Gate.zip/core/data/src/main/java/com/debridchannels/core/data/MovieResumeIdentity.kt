package com.debridchannels.core.data

import com.debridchannels.core.model.MediaItem
import com.debridchannels.core.model.MediaType

private val tmdbToken = Regex("""tmdb[:_/|-]?(?:movie|tv|show|series)?[:_/|-]?([0-9]+)""", RegexOption.IGNORE_CASE)
private val imdbToken = Regex("""tt[0-9]{6,}""", RegexOption.IGNORE_CASE)
private val digits = Regex("[0-9]+")

/** Exact provider IDs can be linked even when two catalogs use different display titles. */
fun movieResumeAliases(id: String, item: MediaItem? = null): Set<String> = buildSet {
    if (id.isBlank()) return@buildSet
    add("raw:$id")
    val metadata = item?.takeIf { it.type == MediaType.MOVIE && it.id == id }
    val tmdb = tmdbToken.find(id)?.groupValues?.get(1) ?: metadata?.tmdbId?.let { digits.find(it)?.value }
    val imdb = imdbToken.find(id) ?: metadata?.imdbId?.let(imdbToken::find)
    tmdb?.let { add("tmdb:$it") }
    imdb?.let { add("imdb:" + it.value.lowercase()) }
    metadata?.tvdbId?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }?.let { add("tvdb:$it") }
}

data class MovieResumeGroup(val aliases: Set<String>, val positionMs: Long, val revision: Long, val durationMs: Long = 0L)

/** All members point to one record. A newly discovered bridge can join two older records. */
fun resolveMovieResume(aliases: Set<String>, lookup: (String) -> MovieResumeGroup?): MovieResumeGroup {
    val matches = aliases.mapNotNull(lookup).distinct()
    val newest = matches.maxByOrNull { it.revision }
    val members = matches.flatMapTo(aliases.toMutableSet()) { it.aliases }
    return MovieResumeGroup(members, newest?.positionMs ?: 0L, newest?.revision ?: 0L, newest?.durationMs ?: 0L)
}

/** CP23 had no write timestamps. Keep the furthest position when two legacy IDs converge. */
fun legacyMovieResumeGroups(values: Map<String, *>): List<MovieResumeGroup> {
    val index = mutableMapOf<String, MovieResumeGroup>()
    for ((id, position) in values) {
        if (id.isBlank() || position !is Long || position < 8000L) continue
        val aliases = movieResumeAliases(id)
        val previous = aliases.mapNotNull(index::get)
        val members = previous.flatMapTo(aliases.toMutableSet()) { it.aliases }
        val group = MovieResumeGroup(members, maxOf(position, previous.maxOfOrNull { it.positionMs } ?: 0L), 0L)
        for (key in members) index[key] = group
    }
    return index.values.distinct()
}
