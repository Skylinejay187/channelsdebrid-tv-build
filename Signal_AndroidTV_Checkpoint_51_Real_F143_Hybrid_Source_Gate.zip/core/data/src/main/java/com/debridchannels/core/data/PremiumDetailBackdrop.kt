package com.debridchannels.core.data

import com.debridchannels.core.model.MediaItem
import com.debridchannels.core.model.MediaType
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.runInterruptible
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URI
import java.net.URLEncoder

private const val maxResponseBytes = 2_000_000

internal fun premiumArtworkEndpoint(item: MediaItem, backend: String): URI? {
    val type = when (item.type) {
        MediaType.MOVIE -> "movie"
        MediaType.SHOW -> "tv"
        else -> return null
    }
    val fields = linkedMapOf("title" to item.title, "type" to type, "proxyImages" to "0")
    for ((name, value) in listOf("imdbId" to item.imdbId, "tmdbId" to item.tmdbId, "tvdbId" to item.tvdbId)) {
        value?.trim()?.takeIf { it.isNotEmpty() }?.let { fields[name] = it }
    }
    val query = fields.entries.joinToString("&") { (key, value) -> "$key=" + URLEncoder.encode(value, "UTF-8") }
    return URI(backend.trimEnd('/') + "/api/artwork/resolve?" + query)
}

private data class Candidate(val url: String, val priority: Int, val pixels: Long)

private fun readArtworkJson(body: InputStream, limit: Int = maxResponseBytes): com.google.gson.JsonElement? {
    val bytes = ByteArrayOutputStream()
    val buffer = ByteArray(8192)
    while (true) {
        if (Thread.currentThread().isInterrupted) throw InterruptedException()
        val count = body.read(buffer)
        if (count < 0) break
        if (bytes.size() + count > limit) return null
        bytes.write(buffer, 0, count)
    }
    return JsonParser.parseString(bytes.toString("UTF-8"))
}

internal fun rankedDetailBackdrops(body: InputStream, item: MediaItem): List<String> {
    val root = readArtworkJson(body) ?: return emptyList()
    val pool = root.takeIf { it.isJsonObject }?.asJsonObject?.get("artworkPool")
        ?.takeIf { it.isJsonObject }?.asJsonObject ?: return emptyList()
    val seen = detailBackdropUrls(item).toMutableSet()
    val candidates = mutableListOf<Candidate>()
    fun JsonObject.text(key: String) = get(key)?.takeIf { it.isJsonPrimitive }?.asString.orEmpty().trim()
    for (bucket in listOf("backdrops", "landscape")) {
        val values = pool[bucket]?.takeIf { it.isJsonArray }?.asJsonArray ?: continue
        for (element in values) {
            val row = element.takeIf { it.isJsonObject }?.asJsonObject ?: continue
            val raw = row.text("url")
            if (!raw.startsWith("https://", true) && !raw.startsWith("http://", true)) continue
            val routed = catalogHeroArtwork(raw, artworkBackend, false, true)?.baseUrl ?: continue
            if (!seen.add(routed)) continue
            val source = row.text("source").lowercase()
            val priority = when {
                "fanart" in source -> 0
                "tvdb" in source -> 1
                "tmdb" in source -> 2
                else -> 3
            }
            fun pixels(name: String) = row.text(name).toIntOrNull()?.coerceAtLeast(0)?.toLong() ?: 0L
            candidates += Candidate(raw, priority, pixels("width") * pixels("height"))
        }
    }
    return candidates.sortedWith(compareBy<Candidate> { it.priority }.thenByDescending { it.pixels }.thenBy { it.url })
        .map { it.url }
}

fun backendDetailBackdrops(item: MediaItem, backend: String = artworkBackend): List<String> {
    val endpoint = premiumArtworkEndpoint(item, backend) ?: return emptyList()
    return fetchArtwork(endpoint, 10_000) { rankedDetailBackdrops(it, item) }.orEmpty()
}

private fun <T> fetchArtwork(endpoint: URI, timeout: Int, limit: Int = maxResponseBytes, onReadFailure: T? = null, parse: (InputStream) -> T?): T? {
    val connection = endpoint.toURL().openConnection() as HttpURLConnection
    try {
        connection.connectTimeout = timeout
        connection.readTimeout = timeout
        connection.useCaches = false
        connection.setRequestProperty("Accept", "application/json")
        if (connection.responseCode !in 200..299 || connection.contentLength > limit) return null
        return connection.inputStream.use(parse)
    } catch (_: IOException) {
        return onReadFailure
    } catch (_: com.google.gson.JsonParseException) {
        return onReadFailure
    } finally {
        connection.disconnect()
    }
}

private const val fanartResponseLimit = 4_000_000

private const val fanartApi = "https://webservice.fanart.tv/v3"

internal fun fanartBackdropEndpoint(item: MediaItem, key: String, base: String = fanartApi): URI? {
    if (key.isBlank()) return null
    val (category, rawId) = when (item.type) {
        MediaType.MOVIE -> "movies" to item.tmdbId
        MediaType.SHOW -> "tv" to item.tvdbId
        else -> return null
    }
    val id = rawId?.trim()?.toLongOrNull()?.takeIf { it > 0 } ?: return null
    return URI("$base/$category/$id?api_key=" + URLEncoder.encode(key.trim(), "UTF-8"))
}

internal fun rankedFanartBackdrops(body: InputStream, item: MediaItem): List<String> {
    val bucket = when (item.type) {
        MediaType.MOVIE -> "moviebackground"
        MediaType.SHOW -> "showbackground"
        else -> return emptyList()
    }
    val root = readArtworkJson(body, fanartResponseLimit) ?: return emptyList()
    val rows = root.takeIf { it.isJsonObject }?.asJsonObject?.get(bucket)
        ?.takeIf { it.isJsonArray }?.asJsonArray ?: return emptyList()
    data class Image(val url: String, val preferredLanguage: Boolean, val likes: Int)
    val excluded = detailBackdropUrls(item).toHashSet()
    return rows.mapNotNull { element ->
        val row = element.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
        fun field(name: String) = row[name]?.takeIf { it.isJsonPrimitive }?.asString.orEmpty().trim()
        val url = catalogHeroArtwork(field("url"), "", false, true)?.baseUrl ?: return@mapNotNull null
        val lang = field("lang")
        Image(url, lang.isEmpty() || lang.equals("en", true), field("likes").toIntOrNull() ?: 0)
    }.sortedWith(compareByDescending<Image> { it.preferredLanguage }.thenByDescending { it.likes })
        .map { it.url }.filter { catalogHeroArtwork(it, artworkBackend, false, true)?.baseUrl !in excluded }.distinct()
}

fun fanartDetailBackdrops(item: MediaItem, key: String): List<String> {
    val endpoint = fanartBackdropEndpoint(item, key) ?: return emptyList()
    return fanartDetailBackdrops(item, endpoint)
}

private fun fanartDetailBackdrops(item: MediaItem, endpoint: URI): List<String> {
    return fetchArtwork(endpoint, 9_000, fanartResponseLimit) { rankedFanartBackdrops(it, item) }.orEmpty()
}

internal fun tmdbBackdropEndpoint(item: MediaItem, key: String, base: String = tmdbApi): URI? {
    val kind = when (item.type) {
        MediaType.MOVIE -> "movie"
        MediaType.SHOW -> "tv"
        else -> return null
    }
    val id = item.tmdbId?.trim()?.toLongOrNull()?.takeIf { it > 0 } ?: return null
    if (key.isBlank()) return null
    val encoded = URLEncoder.encode(key.trim(), "UTF-8")
    return URI("$base/$kind/$id/images?api_key=$encoded&include_image_language=en,null")
}

internal fun rankedTmdbBackdrops(body: InputStream): List<String> {
    val root = readArtworkJson(body) ?: return emptyList()
    val images = root.takeIf { it.isJsonObject }?.asJsonObject?.get("backdrops")
        ?.takeIf { it.isJsonArray }?.asJsonArray ?: return emptyList()
    data class Image(val url: String, val pixels: Long, val votes: Int, val average: Double)
    val seen = mutableSetOf<String>()
    return images.mapNotNull { element ->
        val row = element.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
        fun field(name: String) = row[name]?.takeIf { it.isJsonPrimitive }?.asString
        val path = field("file_path")?.takeIf { it.startsWith("/") && !it.startsWith("//") } ?: return@mapNotNull null
        if (!seen.add(path)) return@mapNotNull null
        fun dimension(name: String) = field(name)?.toIntOrNull()?.coerceAtLeast(0)?.toLong() ?: 0L
        Image("https://image.tmdb.org/t/p/original$path", dimension("width") * dimension("height"),
            field("vote_count")?.toIntOrNull() ?: 0, field("vote_average")?.toDoubleOrNull() ?: 0.0)
    }.sortedWith(compareByDescending<Image> { it.pixels }.thenByDescending { it.votes }.thenByDescending { it.average })
        .map { it.url }
}

private const val tmdbApi = "https://api.themoviedb.org/3"

private data class TmdbArtworkTarget(val kind: MediaType, val id: String)

private fun imdbArtworkTarget(body: InputStream, type: MediaType): TmdbArtworkTarget? {
    val root = readArtworkJson(body)?.takeIf { it.isJsonObject }?.asJsonObject ?: return null
    fun first(bucket: String, kind: MediaType): TmdbArtworkTarget? {
        val rows = root[bucket]?.takeIf { it.isJsonArray }?.asJsonArray ?: return null
        for (row in rows) {
            val id = row.takeIf { it.isJsonObject }?.asJsonObject?.get("id")
                ?.takeIf { it.isJsonPrimitive }?.asString?.toLongOrNull() ?: continue
            if (id > 0) return TmdbArtworkTarget(kind, id.toString())
        }
        return null
    }
    val movie = first("movie_results", MediaType.MOVIE)
    val show = first("tv_results", MediaType.SHOW)
    return if (type == MediaType.SHOW) show ?: movie else movie ?: show
}

private fun titleYearArtworkTarget(item: MediaItem, encodedKey: String, base: String): TmdbArtworkTarget? {
    val title = item.title.trim()
    if (title.isEmpty()) return null
    val isShow = item.type == MediaType.SHOW
    val kind = if (isShow) "tv" else "movie"
    val query = URLEncoder.encode(title, "UTF-8")
    val yearParam = if (isShow) "first_air_date_year" else "year"
    val yearQuery = item.year?.let { "&$yearParam=$it" }.orEmpty()
    val endpoint = URI("$base/search/$kind?api_key=$encodedKey&query=$query&include_adult=false&page=1&language=en-US$yearQuery")
    val titleKey = title.lowercase().filter(Char::isLetterOrDigit)
    data class Candidate(val id: Long, val exactTitle: Boolean, val exactYear: Boolean, val score: Double)
    return fetchArtwork(endpoint, 8_000) { body ->
        val root = readArtworkJson(body)?.takeIf { it.isJsonObject }?.asJsonObject
        val rows = root?.get("results")?.takeIf { it.isJsonArray }?.asJsonArray ?: return@fetchArtwork null
        val candidates = rows.mapNotNull { element ->
            val row = element.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
            fun field(name: String) = row[name]?.takeIf { it.isJsonPrimitive }?.asString
            val id = field("id")?.toLongOrNull()?.takeIf { it > 0 } ?: return@mapNotNull null
            val name = (field("title") ?: field("name")).orEmpty().lowercase().filter(Char::isLetterOrDigit)
            val year = (field("release_date") ?: field("first_air_date"))?.take(4)?.toIntOrNull()
            Candidate(id, name == titleKey, item.year != null && year == item.year,
                field("vote_average")?.toDoubleOrNull() ?: 0.0)
        }
        candidates.maxWithOrNull(compareBy<Candidate> { it.exactTitle }.thenBy { it.exactYear }.thenBy { it.score })
            ?.let { TmdbArtworkTarget(item.type, it.id.toString()) }
    }
}

fun tmdbDetailBackdrops(item: MediaItem, key: String): List<String> =
    tmdbDetailBackdrops(item, key, tmdbApi)

internal fun tmdbDetailBackdrops(item: MediaItem, key: String, base: String): List<String> {
    val match = resolveArtworkTarget(item, key, base) ?: return emptyList()
    return tmdbTargetBackdrops(item, match, key, base)
}

private fun tmdbTargetBackdrops(item: MediaItem, match: TmdbArtworkTarget, key: String, base: String): List<String> {
    val endpoint = tmdbBackdropEndpoint(item.copy(type = match.kind, tmdbId = match.id), key, base) ?: return emptyList()
    return fetchArtwork(endpoint, 9_000, parse = ::rankedTmdbBackdrops).orEmpty()
}

private val embeddedImdbId = Regex("""tt\p{Nd}{5,}""", RegexOption.IGNORE_CASE)
private val embeddedTmdbId = Regex("""(?:tmdb|themoviedb)[:_/\-](\p{Nd}{2,})""", RegexOption.IGNORE_CASE)
private val numericTmdbId = Regex("""\p{Nd}{2,}""")

private fun resolveArtworkTarget(item: MediaItem, key: String, base: String): TmdbArtworkTarget? {
    if (key.isBlank() || item.type !in setOf(MediaType.MOVIE, MediaType.SHOW)) return null
    val parts = item.id.split(':')
    val typedId = parts.getOrNull(2)?.toLongOrNull()?.takeIf { it > 0 && parts[0].equals("tmdb", true) }
    val direct = if (typedId == null) item else item.copy(tmdbId = typedId.toString(),
        type = if (parts[1].equals("tv", true)) MediaType.SHOW else item.type)
    val directId = direct.tmdbId?.trim()?.toLongOrNull()
    if (directId != null && directId > 0) return TmdbArtworkTarget(direct.type, directId.toString())
    val embeddedImdb = embeddedImdbId.find(item.id)?.value?.lowercase()
    if (embeddedImdb == null) {
        val digits = embeddedTmdbId.find(item.id)?.groupValues?.get(1) ?: numericTmdbId.matchEntire(item.id)?.value
        val parsed = digits?.toLongOrNull()
        if (parsed != null && parsed > 0) return TmdbArtworkTarget(item.type, parsed.toString())
    }
    val encoded = URLEncoder.encode(key.trim(), "UTF-8")
    val imdb = item.catalogImdbId() ?: embeddedImdb
    val found = if (imdb == null) null else {
        val find = URI("$base/find/$imdb?api_key=$encoded&external_source=imdb_id&language=en-US")
        // A rejected HTTP request ends the lookup. A read error or missing match permits title search.
        data class FindResult(val target: TmdbArtworkTarget?)
        val result = fetchArtwork(find, 8_000, onReadFailure = FindResult(null)) {
            FindResult(imdbArtworkTarget(it, item.type))
        } ?: return null
        result.target
    }
    return found ?: titleYearArtworkTarget(item, encoded, base)
}

suspend fun premiumDetailBackdrops(item: MediaItem, tmdbKey: String, fanartKey: String): List<String> =
    premiumDetailBackdrops(item, tmdbKey, fanartKey, tmdbApi, fanartApi, artworkBackend)

internal suspend fun premiumDetailBackdrops(
    item: MediaItem, tmdbKey: String, fanartKey: String, tmdbBase: String, fanartBase: String, backendBase: String
): List<String> = coroutineScope {
    val backend = async { runInterruptible(Dispatchers.IO) { backendDetailBackdrops(item, backendBase) } }
    val target = async { runInterruptible(Dispatchers.IO) { resolveArtworkTarget(item, tmdbKey, tmdbBase) } }
    val fanart = async {
        val endpoint = fanartBackdropEndpoint(item, fanartKey, fanartBase) ?: run {
            if (fanartKey.isBlank() || item.type != MediaType.MOVIE) return@async emptyList<String>()
            val match = target.await()
            if (match?.kind != MediaType.MOVIE) return@async emptyList<String>()
            fanartBackdropEndpoint(item.copy(tmdbId = match.id), fanartKey, fanartBase) ?: return@async emptyList<String>()
        }
        runInterruptible(Dispatchers.IO) { fanartDetailBackdrops(item, endpoint) }
    }
    val match = target.await()
    val tmdb = if (match == null) emptyList() else runInterruptible(Dispatchers.IO) {
        tmdbTargetBackdrops(item, match, tmdbKey, tmdbBase)
    }
    mergeBackdropPools(item, fanart.await(), backend.await(), tmdb)
}

fun mergeBackdropPools(item: MediaItem, vararg pools: List<String>): List<String> {
    val seen = detailBackdropUrls(item).toMutableSet()
    return buildList {
        for (index in 0 until (pools.maxOfOrNull { it.size } ?: 0)) {
            for (pool in pools) {
                val url = pool.getOrNull(index) ?: continue
                val normalized = catalogHeroArtwork(url, artworkBackend, false, true)?.baseUrl ?: continue
                if (seen.add(normalized)) add(url)
            }
        }
    }
}

/** Owned by the app composition. Both lookup and publication run on the UI thread. */
class DetailBackdropSession {
    private data class Pool(val urls: List<String>, var cursor: Int = 0)
    private val pools = mutableMapOf<String, Pool>()

    fun next(item: MediaItem, resolved: List<String> = emptyList()): String? {
        val key = item.backdropCacheKey()
        val pool = pools[key] ?: run {
            if (resolved.isEmpty()) return null
            Pool(resolved.toList()).also { pools[key] = it }
        }
        val url = pool.urls[pool.cursor]
        pool.cursor = (pool.cursor + 1) % pool.urls.size
        return url
    }
}
