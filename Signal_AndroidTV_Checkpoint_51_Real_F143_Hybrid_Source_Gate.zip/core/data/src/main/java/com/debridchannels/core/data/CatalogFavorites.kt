package com.debridchannels.core.data

import com.debridchannels.core.model.MediaItem
import com.debridchannels.core.model.MediaType
import com.google.gson.Gson
import com.google.gson.JsonParser

private val favoriteSeparators = Regex("[^a-z0-9]+")
private val favoriteJson = Gson()

private fun favoriteToken(value: String?) = value.orEmpty().lowercase().replace(favoriteSeparators, "-").trim('-')

fun MediaItem.catalogFavoriteKey(): String? {
    val kind = when (type) {
        MediaType.MOVIE -> "movie"
        MediaType.SHOW -> "series"
        else -> return null
    }
    for ((provider, value) in listOf("imdb" to imdbId, "tmdb" to tmdbId, "tvdb" to tvdbId, "id" to id)) {
        val token = favoriteToken(value)
        if (token.isNotEmpty()) return "$provider::$token::$kind"
    }
    return "title::${favoriteToken(title)}-${year ?: ""}::$kind"
}

/** Returns the original preference key, including for a card saved before its provider ID arrived. */
fun Map<String, MediaItem>.storedFavoriteKey(item: MediaItem): String? {
    val canonical = item.catalogFavoriteKey() ?: return null
    if (containsKey(canonical)) return canonical
    val title = favoriteToken(item.title)
    val id = favoriteToken(item.id)
    val providers = listOf(item.imdbId, item.tmdbId, item.tvdbId).map(::favoriteToken)
    var bestRank = 0
    var bestKey: String? = null
    for ((key, saved) in this) {
        if (saved.type != item.type) continue
        val stored = listOf(saved.imdbId, saved.tmdbId, saved.tvdbId).map(::favoriteToken)
        val comparable = providers.indices.filter { providers[it].isNotEmpty() && stored[it].isNotEmpty() }
        if (comparable.any { providers[it] != stored[it] }) continue
        val rank = when {
            comparable.isNotEmpty() -> 4
            id.isNotEmpty() && id == favoriteToken(saved.id) -> 3
            title.isEmpty() || title != favoriteToken(saved.title) -> continue
            item.year == null || saved.year == null -> 1
            item.year == saved.year -> 2
            else -> continue
        }
        if (rank > bestRank) {
            bestRank = rank
            bestKey = key
        } else if (rank == bestRank) {
            bestKey = null // An ambiguous fallback cannot identify a single favorite to remove.
        }
    }
    return bestKey
}

/** Fill gaps independently so a fresh poster can accompany a previously saved backdrop. */
fun MediaItem.withSavedFavoriteFields(saved: MediaItem): MediaItem = copy(
    imdbId = imdbId?.takeIf(String::isNotBlank) ?: saved.imdbId,
    tmdbId = tmdbId?.takeIf(String::isNotBlank) ?: saved.tmdbId,
    tvdbId = tvdbId?.takeIf(String::isNotBlank) ?: saved.tvdbId,
    posterUrl = posterUrl?.takeIf(String::isNotBlank) ?: saved.posterUrl,
    landscapeUrl = landscapeUrl?.takeIf(String::isNotBlank) ?: saved.landscapeUrl,
    previewUrl = previewUrl?.takeIf(String::isNotBlank) ?: saved.previewUrl,
    description = description.ifBlank { saved.description },
    genres = genres.ifEmpty { saved.genres },
    rating = rating ?: saved.rating,
    year = year ?: saved.year,
    runtimeMinutes = runtimeMinutes ?: saved.runtimeMinutes,
    subtitle = subtitle.ifBlank { saved.subtitle },
    posterKey = posterKey.ifBlank { saved.posterKey },
    landscapeKey = landscapeKey.ifBlank { saved.landscapeKey },
)

fun MediaItem.compactFavorite(): MediaItem {
    // Avoid splitting a surrogate pair at the description limit.
    val end = description.offsetByCodePoints(0, minOf(1400, description.codePointCount(0, description.length)))
    return copy(description = description.substring(0, end), genres = genres.take(8))
}

fun encodeFavorite(item: MediaItem): String = favoriteJson.toJson(item)

fun restoreFavorite(key: String, value: Any?): MediaItem? {
    if (value !is String) return null
    return runCatching {
        val json = JsonParser.parseString(value).asJsonObject
        val required = listOf("id", "title", "subtitle", "description", "posterKey", "landscapeKey", "logoText", "type")
        if (required.any { json[it]?.isJsonPrimitive != true } || json["genres"]?.isJsonArray != true) return null
        favoriteJson.fromJson(json, MediaItem::class.java).takeIf {
            it.title.isNotBlank() && it.catalogFavoriteKey() == key
        }
    }.getOrNull()
}
