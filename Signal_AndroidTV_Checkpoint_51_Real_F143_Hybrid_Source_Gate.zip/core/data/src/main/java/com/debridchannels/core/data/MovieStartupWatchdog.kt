package com.debridchannels.core.data

/** A main-thread deadline for one player, with a single extension for buffered media. */
class MovieStartupWatchdog(
    private val schedule: (Runnable, Long) -> Unit,
    private val cancel: (Runnable) -> Unit,
    private val bufferedMs: () -> Long,
    private val expired: () -> Unit,
) {
    private var pending: Runnable? = null

    fun arm(graceMs: Long) {
        if (pending == null) start(graceMs, allowExtension = true)
    }

    fun stop() {
        pending?.let(cancel)
        pending = null
    }

    private fun start(delayMs: Long, allowExtension: Boolean) {
        val timer = object : Runnable {
            override fun run() {
                if (pending !== this) return
                pending = null
                if (allowExtension && bufferedMs() > 350L) {
                    start(9_000L, allowExtension = false)
                } else expired()
            }
        }
        pending = timer
        schedule(timer, delayMs)
    }
}
