package com.debridchannels.core.data

import com.debridchannels.core.model.MediaItem
import com.debridchannels.core.model.MediaType
import com.debridchannels.core.model.PlaybackRequest
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.net.URI
import java.net.URLEncoder

fun sourceManifestUri(value: String): URI? = runCatching { URI(value.trim()) }.getOrNull()?.takeIf {
    it.scheme == "https" && !it.host.isNullOrBlank() && it.rawUserInfo == null &&
        it.fragment == null && it.path.endsWith("/manifest.json")
}

private fun JsonObject.strings(name: String): List<String> =
    get(name)?.takeIf { it.isJsonArray }?.asJsonArray?.mapNotNull {
        it.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }?.asString?.trim()
    }.orEmpty()

private fun JsonObject.supportsMovie(id: String): Boolean {
    val resources = get("resources")?.takeIf { it.isJsonArray }?.asJsonArray ?: return false
    return resources.any { entry ->
        val resource = when {
            entry.isJsonObject -> entry.asJsonObject
            entry.isJsonPrimitive && entry.asJsonPrimitive.isString -> JsonObject().apply { add("name", entry) }
            else -> return@any false
        }
        if (!resource.get("name")?.takeIf { it.isJsonPrimitive }?.asString.equals("stream", true)) return@any false
        val types = resource.strings("types").ifEmpty { strings("types") }
        val prefixes = resource.strings("idPrefixes").ifEmpty { strings("idPrefixes") }
        (types.isEmpty() || types.any { it.equals("movie", true) }) &&
            (prefixes.isEmpty() || prefixes.any { id.startsWith(it) })
    }
}

private fun JsonObject.objectField(name: String): JsonObject? =
    get(name)?.takeIf { it.isJsonObject }?.asJsonObject

private val headerName = Regex("[A-Za-z0-9-]+")
private val nonVideoPaths = listOf("/configure", "youtube.com", "youtu.be", "/manifest.json", "/catalog/",
    "/meta/", "imdb.com/title", "themoviedb.org")

data class MovieSourceOption(
    val label: String,
    val playback: PlaybackRequest,
    val provider: String?,
    val sizeBytes: Long?,
)

private fun JsonObject.text(name: String): String? =
    get(name)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }?.asString?.trim()?.takeIf { it.isNotEmpty() }

fun resolveMoviePlayback(
    item: MediaItem,
    manifestUrl: URI,
    fetch: (URI) -> String = ::readCatalog,
): PlaybackRequest? = findMovieSources(item, manifestUrl, 1, fetch).firstOrNull()?.playback

fun findMovieSources(
    item: MediaItem,
    manifestUrl: URI,
    limit: Int,
    fetch: (URI) -> String = ::readCatalog,
): List<MovieSourceOption> {
    require(limit in 1..50)
    require(item.type == MediaType.MOVIE && sourceManifestUri(manifestUrl.toString()) != null)
    val manifest = JsonParser.parseString(fetch(manifestUrl)).asJsonObject
    val provider = manifest.text("name") ?: manifestUrl.host
    val ids = listOfNotNull(item.id, item.imdbId).map { it.trim() }.filter { it.isNotEmpty() }.distinct()
    var lastFailure: Exception? = null
    var receivedStreams = false
    for (id in ids.filter(manifest::supportsMovie)) {
        val encoded = URLEncoder.encode(id, "UTF-8").replace("+", "%20").replace("%3A", ":")
        val endpoint = manifestUrl.resolve("stream/movie/$encoded.json").toString()
        val uri = URI(endpoint + (manifestUrl.rawQuery?.let { "?$it" } ?: ""))
        val streams = try {
            val response = JsonParser.parseString(fetch(uri)).asJsonObject
            requireNotNull(response.get("streams")?.takeIf { it.isJsonArray }?.asJsonArray)
        } catch (e: java.util.concurrent.CancellationException) {
            throw e
        } catch (e: Exception) {
            lastFailure = e
            continue
        }
        receivedStreams = true
        val options = mutableListOf<MovieSourceOption>()
        val seen = mutableSetOf<Pair<String, Int?>>()
        for (entry in streams) {
            if (!entry.isJsonObject) continue
            val stream = entry.asJsonObject
            val url = stream.get("url")?.takeIf { it.isJsonPrimitive }?.asString?.trim().orEmpty()
            val media = runCatching { URI(url) }.getOrNull() ?: continue
            if (media.scheme !in setOf("http", "https") || media.host.isNullOrBlank() ||
                nonVideoPaths.any(url.lowercase()::contains) ||
                media.path.substringAfterLast('/').equals("downloading.mp4", true)) continue
            val fileIndex = stream.get("fileIdx")?.takeIf { it.isJsonPrimitive }?.asString?.toIntOrNull()
            if (!seen.add(url to fileIndex)) continue
            val headers = stream.objectField("behaviorHints")?.objectField("proxyHeaders")
                ?.objectField("request")?.entrySet().orEmpty().filter { (key, value) ->
                    headerName.matches(key) && value.isJsonPrimitive &&
                        value.asJsonPrimitive.isString && value.asString.none { it < ' ' || it == '\u007f' }
                }.associate { it.key to it.value.asString }
            val label = stream.text("title") ?: stream.text("name") ?: stream.objectField("behaviorHints")?.text("filename")
                ?: "Stream ${options.size + 1}"
            val size = stream.objectField("behaviorHints")?.get("videoSize")?.takeIf { it.isJsonPrimitive }
                ?.asString?.toLongOrNull()?.takeIf { it > 0 }
            options.add(MovieSourceOption(label, PlaybackRequest(item.id, item.type, item.title, url, headers), provider, size))
            if (options.size == limit) break
        }
        if (options.isNotEmpty()) return options
    }
    if (!receivedStreams && lastFailure != null) throw lastFailure
    return emptyList()
}
