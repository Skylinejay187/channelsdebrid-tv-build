package com.debridchannels.core.data

import com.debridchannels.core.model.MediaItem
import com.debridchannels.core.model.MediaType
import com.debridchannels.core.model.PlaybackRequest
import com.google.gson.JsonElement
import com.google.gson.JsonParser
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URI
import java.net.URLEncoder
import java.io.IOException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.runInterruptible

private const val trailerBodyLimit = 1024 * 1024
private val pendingKeys = setOf("needsRemux", "needs_remux", "remuxPending", "remux_pending", "requiresRemux", "requires_remux")
private val urlKeys = listOf("playbackUrl", "muxedUrl", "playback_url", "muxed_url",
    "streamUrl", "stream_url", "trailerUrl", "trailer_url", "url", "src")
private val containers = listOf("trailer", "preview", "data", "result", "stream", "source")

internal fun trailerEndpoint(item: MediaItem, base: String, cacheOnly: Boolean = false): URI? {
    val kind = when (item.type) {
        MediaType.MOVIE -> "movie"
        MediaType.SHOW -> "series"
        else -> return null
    }
    if (item.title.isBlank()) return null
    val title = URLEncoder.encode(item.title.trim(), "UTF-8")
    return URI(base.trimEnd('/') + "/trailers/resolve?title=$title&year=${item.year ?: ""}&type=$kind" +
        "&prefer4k=false&minHeight=720&maxHeight=1080&allow4k=false&fast=true&reuseCache=true&singleFlight=true" +
        "&cacheOnly=$cacheOnly&requireMuxedAudio=true&requireComplete=true&cacheVersion=677-fast-hd-remux" +
        "&fastNoCookieHD=true&preferProgressiveHD=true")
}

private fun pending(value: JsonElement, depth: Int = 0): Boolean {
    if (depth > 48) return true
    if (value.isJsonArray) return value.asJsonArray.any { pending(it, depth + 1) }
    if (!value.isJsonObject) return false
    val row = value.asJsonObject
    if ((row.has("audioUrl") || row.has("audio_url")) && (row.has("videoUrl") || row.has("video_url"))) return true
    return row.entrySet().any { (key, child) ->
        val flag = if (key in pendingKeys && child.isJsonPrimitive) child.asString.trim().lowercase() else ""
        flag in setOf("true", "yes", "pending", "required", "processing", "preparing") ||
            (flag.toDoubleOrNull() ?: 0.0) != 0.0 || pending(child, depth + 1)
    }
}

private data class TrailerReply(val request: PlaybackRequest? = null, val poll: Boolean = false)

private fun trailerReply(item: MediaItem, body: String): TrailerReply {
    fun direct(url: String): PlaybackRequest? {
        if (url.contains("remux-cache", ignoreCase = true)) return null
        return item.copy(previewUrl = url).directTrailerRequest()
    }
    val plain = body.trim()
    if (plain.startsWith("http")) return TrailerReply(direct(plain))
    val json = try { JsonParser.parseString(plain) } catch (_: com.google.gson.JsonParseException) { return TrailerReply() }
    if (pending(json)) return TrailerReply(poll = true)
    fun select(node: JsonElement): PlaybackRequest? = when {
        node.isJsonPrimitive && node.asJsonPrimitive.isString -> direct(node.asString)
        node.isJsonArray -> node.asJsonArray.firstNotNullOfOrNull(::select)
        node.isJsonObject -> (urlKeys + containers).firstNotNullOfOrNull { node.asJsonObject[it]?.let(::select) }
        else -> null
    }
    return TrailerReply(select(json), poll = json.isJsonObject || json.isJsonArray)
}

internal fun readyTrailer(item: MediaItem, body: String): PlaybackRequest? = trailerReply(item, body).request

suspend fun resolveCatalogTrailer(item: MediaItem, base: String = artworkBackend, onPreparing: () -> Unit = {}): PlaybackRequest? =
    resolveCatalogTrailer(item, base, onPreparing, ::delay, ::readTrailerReply)

internal suspend fun resolveCatalogTrailer(
    item: MediaItem, base: String, onPreparing: () -> Unit,
    wait: suspend (Long) -> Unit, read: suspend (URI, Int) -> String?
): PlaybackRequest? {
    item.directTrailerRequest()?.let { return it }
    val endpoint = trailerEndpoint(item, base) ?: return null
    val first = read(endpoint, 45_000)?.let { withContext(Dispatchers.Default) { trailerReply(item, it) } } ?: return null
    if (first.request != null || !first.poll) return first.request
    val pollEndpoint = trailerEndpoint(item, base, cacheOnly = true) ?: return null
    onPreparing()
    for (attempt in 1..40) {
        wait(if (attempt <= 8) 1000L else 1500L)
        val body = try { read(pollEndpoint, 8000) } catch (_: IOException) { null }
        if (body != null) withContext(Dispatchers.Default) { readyTrailer(item, body) }?.let { return it }
    }
    return null
}

private suspend fun readTrailerReply(endpoint: URI, timeout: Int): String? =
    runInterruptible(Dispatchers.IO) { readTrailerBody(endpoint, timeout) }

private fun readTrailerBody(endpoint: URI, timeout: Int): String? {
    val connection = endpoint.toURL().openConnection() as HttpURLConnection
    try {
        connection.connectTimeout = minOf(10_000, timeout)
        connection.readTimeout = timeout
        connection.useCaches = false
        connection.instanceFollowRedirects = false
        connection.setRequestProperty("Accept", "application/json,text/plain,*/*")
        if (connection.responseCode !in 200..299 || connection.contentLength >= trailerBodyLimit) return null
        val bytes = ByteArrayOutputStream()
        connection.inputStream.use { stream ->
            val buffer = ByteArray(8192)
            while (true) {
                if (Thread.currentThread().isInterrupted) throw InterruptedException()
                val count = stream.read(buffer)
                if (count < 0) break
                if (bytes.size() + count >= trailerBodyLimit) return null
                bytes.write(buffer, 0, count)
            }
        }
        return bytes.toString("UTF-8")
    } finally {
        connection.disconnect()
    }
}
