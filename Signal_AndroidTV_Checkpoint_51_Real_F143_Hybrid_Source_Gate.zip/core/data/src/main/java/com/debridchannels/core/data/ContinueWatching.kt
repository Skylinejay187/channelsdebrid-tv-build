package com.debridchannels.core.data

import com.debridchannels.core.model.CatalogRow
import com.debridchannels.core.model.MediaItem
import com.debridchannels.core.model.MediaType
import com.google.gson.Gson
import java.text.Normalizer

private val gson = Gson()
private val accents = Regex("\\p{M}+")

fun encodeResumeCard(item: MediaItem): String = gson.toJson(item)

fun decodeResumeCard(raw: String?): MediaItem? = raw?.let {
    runCatching { gson.fromJson(it, MediaItem::class.java).takeIf { card ->
        card.type == MediaType.MOVIE && card.id.isNotBlank() && card.title.isNotBlank()
    } }.getOrNull()
}

fun MediaItem.withResumeArtwork(saved: MediaItem?): MediaItem = copy(
    posterUrl = posterUrl?.takeIf { it.isNotBlank() } ?: saved?.posterUrl,
    landscapeUrl = landscapeUrl?.takeIf { it.isNotBlank() } ?: saved?.landscapeUrl,
)

data class RecentMovie(val progress: MovieResumeGroup, val saved: MediaItem?)

private val episodeTail = Regex("""\s+(?:s\s*\d{1,2}\s*e\s*\d{1,3}|\d{1,2}\s*x\s*\d{1,3})(?:\b.*)?$""", RegexOption.IGNORE_CASE)
private val separators = Regex("[^a-z0-9]+")

fun movieVisibilityKeys(item: MediaItem): Set<String> {
    if (item.type != MediaType.MOVIE) return emptySet()
    val title = Normalizer.normalize(item.title.replace(episodeTail, "").lowercase(), Normalizer.Form.NFD)
        .replace(accents, "").replace(separators, " ").trim()
    return buildSet {
        addAll(movieResumeAliases(item.id, item))
        if (title.isNotEmpty()) {
            add("movie:$title")
            add("movie:$title:" + (item.year ?: ""))
        }
    }
}

fun CatalogRow.isContinueShelf(): Boolean = id == "dc-local-continue" ||
    id == "trakt-movie-continue" || id == "trakt-show-continue" ||
    title.contains("continue watching", true) || title.contains("resume", true)

fun visibleContinueRows(rows: List<CatalogRow>, hidden: Set<String>): List<CatalogRow> {
    if (hidden.isEmpty()) return rows
    return rows.mapNotNull { row ->
        if (!row.isContinueShelf()) return@mapNotNull row
        val items = row.items.filter { movieVisibilityKeys(it).none(hidden::contains) }
        when {
            items.isEmpty() -> null
            items.size == row.items.size -> row
            else -> row.copy(items = items)
        }
    }
}

fun continueWatchingRow(entries: List<RecentMovie>, catalog: List<CatalogRow>, hidden: Set<String> = emptySet()): CatalogRow? {
    val eligible = entries.filter { (progress, _) ->
        progress.positionMs >= 8000L && (progress.durationMs <= 0 ||
            progress.positionMs < progress.durationMs - progress.durationMs / 20)
    }.sortedByDescending { it.progress.revision }.take(60)
    if (eligible.isEmpty()) return null
    val catalogByAlias = mutableMapOf<String, MediaItem>()
    for (row in catalog) for (item in row.items) {
        if (item.type == MediaType.MOVIE) for (alias in movieResumeAliases(item.id, item)) {
            if (alias !in catalogByAlias) catalogByAlias[alias] = item
        }
    }
    val ids = mutableSetOf<String>()
    val titles = mutableSetOf<Pair<String, Int?>>()
    val cards = mutableListOf<MediaItem>()
    for ((group, saved) in eligible) {
        if (hidden.isNotEmpty() && (group.aliases.any(hidden::contains) ||
                saved?.let { movieVisibilityKeys(it).any(hidden::contains) } == true)) continue
        val match = saved?.let { catalogByAlias["raw:" + it.id] }
            ?: group.aliases.sorted().firstNotNullOfOrNull(catalogByAlias::get)
        val item = match?.withResumeArtwork(saved) ?: saved ?: continue
        if (hidden.isNotEmpty() && movieVisibilityKeys(item).any(hidden::contains)) continue
        val title = Normalizer.normalize(item.title.trim().lowercase(), Normalizer.Form.NFD).replace(accents, "")
        val key = title.ifEmpty { item.id } to item.year
        if (item.id in ids || key in titles) continue
        ids.add(item.id)
        titles.add(key)
        cards.add(item)
        if (cards.size == 24) break
    }
    return if (cards.isEmpty()) null else CatalogRow("dc-local-continue", "Continue Watching", items = cards)
}
