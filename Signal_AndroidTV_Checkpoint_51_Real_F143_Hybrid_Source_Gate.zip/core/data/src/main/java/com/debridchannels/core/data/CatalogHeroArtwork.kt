package com.debridchannels.core.data

import com.debridchannels.core.model.CatalogRow
import com.debridchannels.core.model.MediaItem
import java.net.URI
import java.net.URLDecoder
import java.net.URLEncoder

internal const val artworkBackend = "https://api.skylinejay187.it.com"

data class CatalogHeroArtwork(val baseUrl: String, val foregroundUrl: String?)

private val tmdbSize = Regex("^/t/p/(w45|w92|w154|w185|w300|w342|w500|h632|w780|w1280)(?=/|$)")
private fun httpUri(value: String): URI? = runCatching { URI(value) }.getOrNull()?.takeIf {
    it.scheme?.lowercase() in setOf("http", "https") && it.host != null && it.rawUserInfo == null
}

private fun isLocalArtworkHost(host: String): Boolean {
    val parts = host.split('.')
    return host == "localhost" || host == "127.0.0.1" || host.endsWith(".local") ||
        host.startsWith("10.") || host.startsWith("192.168.") ||
        (parts.size == 4 && parts.first() == "172" && parts[1].toIntOrNull() in 16..31)
}

private fun encoded(value: String) = URLEncoder.encode(value, "UTF-8").replace("+", "%20")

fun catalogHeroArtwork(source: String, backend: String, masking: Boolean, fullResolution: Boolean): CatalogHeroArtwork? {
    val trimmed = source.trim()
    val image = httpUri(if (trimmed.startsWith("//")) "https:$trimmed" else trimmed) ?: return null
    val host = image.host.lowercase()
    val local = isLocalArtworkHost(host)
    val scheme = if (!local && image.scheme.equals("http", true)) "https" else image.scheme
    val path = if (host == "image.tmdb.org") image.rawPath.replace(tmdbSize, "/t/p/original") else image.rawPath
    val origin = buildString {
        append(scheme).append("://").append(image.rawAuthority).append(path)
        image.rawQuery?.let { append('?').append(it) }
        image.rawFragment?.let { append('#').append(it) }
    }
    val endpoint = httpUri(backend.trim()) ?: return CatalogHeroArtwork(origin, null)
    val prefix = endpoint.scheme + "://" + endpoint.rawAuthority + endpoint.rawPath.trimEnd('/')
    val catalogAsset = path.startsWith("/assets/") &&
        (host == "catalog.skylinejay187.it.com" || host.endsWith(".catalog.debridchannels"))
    val base = if (local || catalogAsset || endpoint.host.equals(host, true)) origin
        else "$prefix/api/image?url=" + encoded(origin)
    val size = if (fullResolution) "master" else "browse"
    val mask = if (masking) "$prefix/api/artwork/foreground/v1?url=" + encoded(base) + "&size=$size&model=hrsod1" else null
    return CatalogHeroArtwork(base, mask)
}

/** Ordered base images for the detail backdrop. A catalog can already contain routed URLs. */
fun detailBackdropUrls(item: MediaItem, catalogAnchor: MediaItem? = null): List<String> = buildSet {
    val sources = listOfNotNull(catalogAnchor?.landscapeUrl, catalogAnchor?.posterUrl, item.landscapeUrl, item.posterUrl)
    for (source in sources.distinct()) {
        val base = catalogHeroArtwork(source, artworkBackend, masking = false, fullResolution = true)?.baseUrl ?: continue
        add(base)
        val uri = URI(base)
        if (uri.host.equals(URI(artworkBackend).host, true) && uri.path == "/api/image") {
            val raw = uri.rawQuery?.split('&')?.firstOrNull { it.startsWith("url=") }?.substringAfter('=')
            val origin = raw?.let { runCatching { URLDecoder.decode(it, "UTF-8") }.getOrNull() }?.let(::httpUri)
            if (origin != null && !isLocalArtworkHost(origin.host.lowercase())) add(origin.toString())
        }
    }
}.toList()

fun focusedCatalogItem(rows: List<CatalogRow>, focusedId: String?): MediaItem? {
    val items = rows.asSequence().flatMap { it.items.asSequence() }
    return focusedId?.let { id -> items.firstOrNull { it.id == id } } ?: items.firstOrNull()
}
