package com.debridchannels.core.data

import com.debridchannels.core.model.MediaItem
import com.debridchannels.core.model.MediaType
import com.debridchannels.core.model.PlaybackRequest
import java.net.URI

/** Direct remote trailers use a private, transient VOD session for either catalog kind. */
fun MediaItem.directTrailerRequest(): PlaybackRequest? {
    if (type != MediaType.MOVIE && type != MediaType.SHOW) return null
    val url = previewUrl?.trim() ?: return null
    val uri = runCatching { URI(url) }.getOrNull() ?: return null
    val host = uri.host?.lowercase()?.trimEnd('.') ?: return null
    if (uri.scheme !in listOf("http", "https") || uri.rawUserInfo != null) return null
    if (listOf("youtube.com", "youtu.be", "youtube-nocookie.com", "vimeo.com").any { host == it || host.endsWith(".$it") }) return null
    val path = uri.path.orEmpty().lowercase()
    val direct = listOf(".m3u8", ".mp4", ".mov", ".m4v").any(path::endsWith) ||
        listOf("video", "playback", "preview").any(path::contains)
    if (!direct) return null
    return PlaybackRequest("trailer:$id", MediaType.MOVIE, "$title · Trailer", sourceUrl = url)
}
