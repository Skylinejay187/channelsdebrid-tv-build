package com.debridchannels.core.data

/** F143 movie progress rules, using Media3's millisecond clock. One instance per source open. */
class MovieResumePolicy(initialPositionMs: Long) {
    private var floorMs = initialPositionMs

    fun seekTo(positionMs: Long) { floorMs = positionMs }

    enum class Update { KEEP, SAVE, CLEAR }

    fun update(positionMs: Long, durationMs: Long, exiting: Boolean): Update {
        if (positionMs < 8_000L || (durationMs > 0 && positionMs - durationMs > 5_000L)) return Update.KEEP
        if (floorMs >= 8_000L && floorMs - positionMs > 4_000L) return Update.KEEP
        floorMs = 0L
        if (durationMs > 0 && positionMs >= durationMs - durationMs / 20) {
            return if (exiting) Update.CLEAR else Update.KEEP
        }
        return Update.SAVE
    }
}
