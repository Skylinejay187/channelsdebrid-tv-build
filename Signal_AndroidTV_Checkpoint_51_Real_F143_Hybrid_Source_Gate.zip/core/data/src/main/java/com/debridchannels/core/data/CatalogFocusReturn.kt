package com.debridchannels.core.data

import com.debridchannels.core.model.CatalogRow
import com.debridchannels.core.model.MediaType
import com.debridchannels.core.model.MediaItem

private val imdbToken = Regex("""(?<![\p{L}\p{N}])tt[0-9]+(?![\p{L}\p{N}])""")
private val episodeSuffix = Regex(""":(-?\d+):(-?\d+)$""")

private val nonTitleCharacters = Regex("""[^\p{L}\p{N}]+""")

private enum class Match { NONE, TITLE_YEAR, PROVIDER, EXACT }

private data class CatalogIdentity(
    val id: String,
    val imdb: String?,
    val tmdb: String?,
    val tvdb: String?,
    val titleYear: Pair<String, Int>?,
    val episode: Pair<Int, Int>?,
) {
    fun match(other: CatalogIdentity, type: MediaType): Match {
        if (episode != other.episode) return Match.NONE
        if (imdb != null && other.imdb != null && imdb != other.imdb) return Match.NONE
        if (tmdb != null && other.tmdb != null && tmdb != other.tmdb) return Match.NONE
        if (tvdb != null && other.tvdb != null && tvdb != other.tvdb) return Match.NONE
        if (id.isNotEmpty() && id == other.id) return Match.EXACT
        if (type == MediaType.EPISODE && episode == null) return Match.NONE
        if ((imdb != null && imdb == other.imdb) || (tmdb != null && tmdb == other.tmdb) ||
            (tvdb != null && tvdb == other.tvdb)) return Match.PROVIDER
        return if (titleYear != null && titleYear == other.titleYear) Match.TITLE_YEAR else Match.NONE
    }
}

internal fun MediaItem.catalogImdbId(): String? =
    imdbId?.trim()?.lowercase()?.takeIf(imdbToken::matches) ?: imdbToken.find(id.lowercase())?.value

private fun MediaItem.catalogIdentity(): CatalogIdentity {
    val raw = id.trim().lowercase()
    fun clean(value: String?) = value?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }
    fun infer(provider: String): String? {
        if (!raw.startsWith("$provider:")) return null
        return raw.split(':').lastOrNull { it.isNotEmpty() && it.all(Char::isDigit) }
    }
    val imdb = catalogImdbId()
    val titleYear = year?.takeIf { it in 1000..9999 }?.let { releaseYear ->
        title.lowercase().replace(nonTitleCharacters, "").takeIf { it.isNotEmpty() }?.let { it to releaseYear }
    }
    val episode = episodeSuffix.find(raw)?.let { match ->
        val season = match.groupValues[1].toIntOrNull()
        val number = match.groupValues[2].toIntOrNull()
        if (season != null && number != null) season to number else null
    }
    return CatalogIdentity(raw, imdb, clean(tmdbId) ?: infer("tmdb"), clean(tvdbId) ?: infer("tvdb"), titleYear, episode)
}

internal fun MediaItem.backdropCacheKey(): String {
    val identity = catalogIdentity()
    val key = when {
        identity.imdb != null -> "imdb|${identity.imdb}"
        identity.tmdb != null -> "tmdb|${identity.tmdb}"
        identity.tvdb != null -> "tvdb|${identity.tvdb}"
        identity.id.isNotEmpty() -> "id|${identity.id}"
        else -> "title|${title.lowercase().replace(nonTitleCharacters, "")}|${year ?: "unknown"}"
    }
    return "${type.name}|$key"
}

data class CatalogCardPosition(val row: Int, val card: Int)

data class CatalogFocusReturn(val rowId: String, val item: MediaItem, val position: CatalogCardPosition) {
    fun resolve(rows: List<CatalogRow>): CatalogCardPosition? {
        val source = rows.indexOfFirst { it.id == rowId }
        val identity = item.catalogIdentity()
        fun matchingCard(row: CatalogRow): Int {
            var best = Match.NONE
            var bestIndex = -1
            for ((index, candidate) in row.items.withIndex()) {
                if (candidate.type != item.type) continue
                val match = identity.match(candidate.catalogIdentity(), item.type)
                if (match == Match.EXACT) return index
                if (match > best) {
                    best = match
                    bestIndex = index
                }
            }
            return bestIndex
        }
        if (source >= 0) {
            val exact = matchingCard(rows[source])
            if (exact >= 0) return CatalogCardPosition(source, exact)
        }
        for ((index, row) in rows.withIndex()) {
            if (index == source) continue
            val card = matchingCard(row)
            if (card >= 0) return CatalogCardPosition(index, card)
        }
        return nearestRemainingCard(rows)
    }

    fun nearestRemainingCard(rows: List<CatalogRow>): CatalogCardPosition? {
        val source = rows.indexOfFirst { it.id == rowId }
        val nearest = if (source >= 0 && rows[source].items.isNotEmpty()) source else
            rows.indices.filter { rows[it].items.isNotEmpty() }.minByOrNull { kotlin.math.abs(it - position.row) }
                ?: return null
        return CatalogCardPosition(nearest, position.card.coerceIn(0, rows[nearest].items.lastIndex))
    }
}
