package com.debridchannels.core.data

import com.debridchannels.core.model.MediaType
import com.debridchannels.core.model.PlaybackRequest

/** One movie launch, advanced on the player's main thread. */
class MovieStartupRecovery(selected: PlaybackRequest, options: List<MovieSourceOption>) {
    init { require(selected.mediaType == MediaType.MOVIE && !selected.sourceUrl.isNullOrBlank()) }

    private val selectedOption = options.firstOrNull { it.playback == selected }
        ?: MovieSourceOption("", selected, null, null)
    private val candidates = (sequenceOf(selectedOption) + options.asSequence())
        .filter {
            val request = it.playback
            request.mediaId == selected.mediaId && request.mediaType == selected.mediaType && !request.sourceUrl.isNullOrBlank()
        }
        .distinctBy { it.playback.sourceUrl }
        .take(MAX_SOURCES)
        .toList()
    private var index = 0
    private var retried = false
    private var rendered = false
    var current = selected
        private set

    fun startupGraceMs(): Long? {
        if (rendered || index >= candidates.lastIndex) return null
        val source = candidates[index]
        val hint = (source.label + " " + source.provider.orEmpty()).lowercase()
        val cached = uncachedTags.none(hint::contains) && cachedTags.any(hint::contains)
        if (!cached) {
            val seeds = seederPatterns.firstNotNullOfOrNull { it.find(hint)?.groupValues?.get(1)?.toIntOrNull() }
            return when {
                seeds == null -> 30_000L
                seeds <= 10 -> 42_000L
                seeds <= 25 -> 36_000L
                else -> 30_000L
            }
        }
        return if (highBandwidthTags.any(hint::contains)) 25_000L else 21_000L
    }

    fun firstFrame() { rendered = true }

    /** Before a fresh player renders or the viewer seeks, its initial position can still be zero. */
    fun savePosition(positionMs: Long, positionEstablished: Boolean) {
        val target = if (positionEstablished) positionMs.coerceAtLeast(0L)
            else maxOf(0L, current.resumePositionMs, positionMs)
        current = current.copy(resumePositionMs = target)
    }

    enum class Action { RETRY, ADVANCE, STOP }

    fun failed(transient: Boolean, positionMs: Long): Action {
        if (rendered) return Action.STOP
        val action = when {
            transient && !retried -> {
                retried = true
                Action.RETRY
            }
            index < candidates.lastIndex -> {
                index++
                retried = false
                Action.ADVANCE
            }
            else -> return Action.STOP
        }
        current = candidates[index].playback.copy(resumePositionMs = maxOf(0L, positionMs, current.resumePositionMs))
        return action
    }

    companion object {
        const val MAX_SOURCES = 4
        private val uncachedTags = listOf("uncached", "not cached", "download required")
        private val cachedTags = listOf("cached", "cache hit", "cache-hit", "instant", "rd+", "real-debrid",
            "alldebrid", "all-debrid", "premiumize", "debrid-link", "debridlink", "easydebrid",
            "offcloud", "put.io", "putio", "torbox")
        private val seederPatterns = listOf(
            Regex("""(?:seeders?|seeds?|peers?)\s*[:=+\-]?\s*(\d{1,6})"""),
            Regex("""(?:👤|👥)\s*(\d{1,6})"""),
            Regex("""(?:^|\s)s\s*[:=]\s*(\d{1,6})(?:\s|$)"""),
        )
        private val highBandwidthTags = listOf("remux", "2160", "4k", "uhd")
    }
}
