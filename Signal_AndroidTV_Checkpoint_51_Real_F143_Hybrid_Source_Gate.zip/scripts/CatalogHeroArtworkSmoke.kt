import com.debridchannels.core.data.catalogHeroArtwork
import java.net.URI
import java.net.URLDecoder

private fun params(url: String) = URI(url).rawQuery.split("&").associate {
    it.substringBefore("=") to URLDecoder.decode(it.substringAfter("="), "UTF-8")
}

fun main() {
    val server = "https://signal.example:8181/prefix/"
    val image = "//image.tmdb.org/t/p/w500/test.jpg?a=1&b=%2B"
    val art = checkNotNull(catalogHeroArtwork(image, server, true, false))
    check(params(art.baseUrl)["url"] == "https://image.tmdb.org/t/p/original/test.jpg?a=1&b=%2B")
    val mask = checkNotNull(art.foregroundUrl)
    check(URI(mask).path == "/prefix/api/artwork/foreground/v1")
    check(params(mask) == mapOf("url" to art.baseUrl, "size" to "browse", "model" to "hrsod1"))
    for (raw in listOf("http://192.168.1.3/p", "https://signal.example/p", "https://catalog.skylinejay187.it.com/assets/p")) {
        val direct = checkNotNull(catalogHeroArtwork(raw, server, true, true))
        check(direct.baseUrl == raw)
        check(params(checkNotNull(direct.foregroundUrl))["size"] == "master")
    }
    check(catalogHeroArtwork(image, server, false, true)?.let { it.baseUrl == art.baseUrl && it.foregroundUrl == null } == true)
    check(catalogHeroArtwork("file:///tmp/image", server, true, false) == null)
    check(catalogHeroArtwork("https://user:pw@image.example/p", server, true, false) == null)
    check(catalogHeroArtwork(image, "https://user@backend.example", true, false)?.foregroundUrl == null)
    println("Catalog hero artwork URL checks passed")
}
