# Checkpoint 50 — Original F143 Unity lifecycle port

## Original Apple TV files read
- `reference/apple-original/Sources/UnitySurfaceLifecycleCoordinator.swift`
- `reference/apple-original/Sources/UnitySurfaceSystem.swift`
- `reference/apple-original/Sources/UnityAppCore.swift`

## Implemented in Kotlin
- `core/model/src/main/java/com/debridchannels/core/model/UnitySurfaceHandoff.kt`: real generation-based, stale-safe tab handoff derived from `UnitySurfaceLifecycleCoordinator.swift`.
- `core/model/src/test/java/com/debridchannels/core/model/UnitySurfaceHandoffTest.kt`: serial handoff, stale completion, cancel tests.
- `app/src/main/java/com/debridchannels/tv/ui/DebridChannelsApp.kt`: navigation enters a Unity handoff, completes after next Compose frame, and suppresses Live TV interactivity during transitions. Back destinations now call the F143 Unity policy; dedicated surfaces hide covered Live TV pixels while retaining root composition/state.

## Verification
- Kotlin-only core source compiled successfully with kotlinc.
- Full Android Gradle and APK build NOT VERIFIED locally: Gradle wrapper requires `services.gradle.org`, unavailable due DNS in this environment.
- No actual Skip Hybrid transpilation or native Fuse compilation was run in this checkpoint. This is a direct, source-grounded Kotlin translation of an original F143 lifecycle module.
- UI 3D cards, original tvOS focus effects, and complete Unity parity are NOT complete. Do not claim visual parity from this checkpoint.

## Next step
- Build ZIP through existing GitHub APK workflow and inspect build logs.
- For Skip Hybrid: run a true mixed-mode test with real Swift units on GitHub macOS, **not** merely a new empty Skip model, and save generated Kotlin/native artifact plus compatibility errors.
- Integrate original F143 catalog presentation/3D cover flow, typography and artwork values only after they are extracted and compared against real Android TV screenshots.

## Non-negotiable product rule
> Our app is Unity, not separate screens.
