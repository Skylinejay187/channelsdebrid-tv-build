package com.debridchannels.tv

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import androidx.annotation.OptIn
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.debridchannels.core.data.PlaybackController
import com.debridchannels.core.model.MediaType
import com.debridchannels.core.model.PlaybackRequest
import com.debridchannels.tv.playback.Media3PlaybackController

/** Debug-only fixture for the real playback boundary and remote controls. */
@OptIn(UnstableApi::class)
class PlaybackSmokeActivity : Activity() {
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    private var controller: PlaybackController? = null
    private var positionMs = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        positionMs = (savedInstanceState?.getLong("positionMs")
            ?: intent.getLongExtra("positionMs", 0L)).coerceAtLeast(0L)

        playerView = PlayerView(this)
        status = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xCC000000.toInt())
        }
        setContentView(FrameLayout(this).apply {
            addView(playerView, FrameLayout.LayoutParams(-1, -1))
            addView(status, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        })
    }

    override fun onStart() {
        super.onStart()
        status.visibility = View.VISIBLE
        status.text = "Preparing playback"
        val player = ExoPlayer.Builder(this).build()
        val playback = Media3PlaybackController(player)
        controller = playback
        playerView.player = player
        playerView.requestFocus()
        playerView.showController()

        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_BUFFERING -> {
                        status.text = "Buffering"
                        status.visibility = View.VISIBLE
                    }
                    Player.STATE_READY -> status.visibility = View.GONE
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                status.text = "Playback failed (${error.errorCodeName})"
                status.visibility = View.VISIBLE
            }
        })
        val result = playback.openVod(PlaybackRequest(
            mediaId = "signal-playback-smoke-test",
            mediaType = MediaType.MOVIE,
            title = "Big Buck Bunny",
            sourceUrl = "https://storage.googleapis.com/exoplayer-test-media-0/BigBuckBunny_320x180.mp4",
            resumePositionMs = positionMs,
        ))
        if (!result.accepted) status.text = result.message ?: "Playback could not start"
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putLong("positionMs", playerView.player?.currentPosition ?: positionMs)
        super.onSaveInstanceState(outState)
    }

    override fun onStop() {
        positionMs = playerView.player?.currentPosition ?: positionMs
        playerView.player = null
        controller?.release()
        controller = null
        super.onStop()
    }
}
