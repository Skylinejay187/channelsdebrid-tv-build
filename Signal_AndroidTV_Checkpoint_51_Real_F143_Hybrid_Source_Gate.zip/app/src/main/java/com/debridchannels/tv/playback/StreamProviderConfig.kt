package com.debridchannels.tv.playback

import android.content.Context
import android.util.AtomicFile
import java.io.File
import java.io.FileNotFoundException

internal class StreamProviderConfig(context: Context) {
    private val file = AtomicFile(File(context.noBackupFilesDir, "stream-provider.txt"))

    private val settings = context.getSharedPreferences("movie-source-options", Context.MODE_PRIVATE)
    var resultLimit: Int
        get() = if (settings.getInt("result-limit", 25) == 50) 50 else 25
        set(value) { settings.edit().putInt("result-limit", if (value == 50) 50 else 25).apply() }

    private val artworkKeyFile = AtomicFile(File(context.noBackupFilesDir, "tmdb-artwork-key.txt"))
    private val fanartKeyFile = AtomicFile(File(context.noBackupFilesDir, "fanart-artwork-key.txt"))
    fun readFanartKey() = read(fanartKeyFile)
    fun saveFanartKey(value: String) = save(fanartKeyFile, value.trim())
    fun readArtworkKey() = read(artworkKeyFile)
    fun saveArtworkKey(value: String) = save(artworkKeyFile, value.trim())
    fun read() = read(file)
    fun save(value: String) = save(file, value)

    private fun read(file: AtomicFile): String = try {
        file.openRead().bufferedReader().use { it.readText() }
    } catch (_: FileNotFoundException) {
        ""
    }

    private fun save(file: AtomicFile, value: String) {
        val output = file.startWrite()
        try {
            output.write(value.toByteArray(Charsets.UTF_8))
            file.finishWrite(output)
        } catch (e: Exception) {
            file.failWrite(output)
            throw e
        }
    }
}
