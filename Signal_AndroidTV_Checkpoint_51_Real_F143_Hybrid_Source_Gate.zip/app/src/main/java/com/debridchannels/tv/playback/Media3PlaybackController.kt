package com.debridchannels.tv.playback

import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.debridchannels.core.data.PlaybackController
import com.debridchannels.core.model.LivePlaybackRequest
import com.debridchannels.core.model.PlaybackLaunchResult
import com.debridchannels.core.model.PlaybackRequest

/** Owns the supplied player. Call from the player's application looper. */
@OptIn(UnstableApi::class)
class Media3PlaybackController(private val player: ExoPlayer) : PlaybackController {
    private var released = false

    override fun openVod(request: PlaybackRequest): PlaybackLaunchResult =
        openVod(request, playWhenReady = true)

    fun openVod(request: PlaybackRequest, playWhenReady: Boolean): PlaybackLaunchResult =
        open(request.mediaId, request.title, request.sourceUrl, request.headers,
            request.resumePositionMs.coerceAtLeast(0L), request.mimeType, playWhenReady)

    override fun openLive(request: LivePlaybackRequest): PlaybackLaunchResult =
        open(request.channelId, request.channelName, request.sourceUrl, request.headers,
            null, request.mimeType, playWhenReady = true)

    private fun open(
        id: String,
        title: String,
        url: String?,
        headers: Map<String, String>,
        positionMs: Long?,
        mimeType: String?,
        playWhenReady: Boolean,
    ): PlaybackLaunchResult {
        if (released) return PlaybackLaunchResult(false, "Playback has been released.")
        val uri = url?.trim()?.let(Uri::parse)
        if (uri == null || uri.host.isNullOrBlank() ||
            uri.scheme !in listOf("http", "https")
        ) {
            return PlaybackLaunchResult(false, "No playable HTTP stream is available.")
        }

        val item = MediaItem.Builder()
            .setMediaId(id)
            .setUri(uri)
            .setMimeType(mimeType)
            .setMediaMetadata(MediaMetadata.Builder().setTitle(title).build())
            .build()
        val sourceFactory = DefaultMediaSourceFactory(
            DefaultHttpDataSource.Factory().setDefaultRequestProperties(headers.toMap())
        )
        val source = sourceFactory.createMediaSource(item)
        if (positionMs == null) {
            player.setMediaSource(source)
        } else {
            player.setMediaSource(source, positionMs)
        }
        player.playWhenReady = playWhenReady
        player.prepare()
        return PlaybackLaunchResult(true)
    }

    override fun release() {
        if (released) return
        released = true
        player.release()
    }
}
