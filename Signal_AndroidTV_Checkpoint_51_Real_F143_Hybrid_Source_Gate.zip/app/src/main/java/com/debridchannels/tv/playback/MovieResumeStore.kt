package com.debridchannels.tv.playback

import android.content.Context
import com.debridchannels.core.data.MovieResumeGroup
import com.debridchannels.core.data.MovieResumePolicy.Update
import com.debridchannels.core.data.MovieStartupRecovery
import com.debridchannels.core.data.legacyMovieResumeGroups
import com.debridchannels.core.data.movieResumeAliases
import com.debridchannels.core.data.resolveMovieResume
import com.debridchannels.core.data.movieVisibilityKeys
import com.debridchannels.core.data.RecentMovie
import com.debridchannels.core.data.encodeResumeCard
import com.debridchannels.core.data.decodeResumeCard
import com.debridchannels.core.data.withResumeArtwork
import com.debridchannels.core.model.MediaItem

/** All calls originate on the playback/UI thread. Each group mutation uses one preferences edit. */
class MovieResumeStore(context: Context, private val item: MediaItem? = null) {
    private val prefs = context.getSharedPreferences("movie_resume_v2", Context.MODE_PRIVATE)
    private val boundId = item?.id
    private val boundAliases = item?.let { movieResumeAliases(it.id, it) }.orEmpty()

    init {
        if (!prefs.getBoolean("migrated", false)) {
            val old = context.getSharedPreferences("movie_resume_v1", Context.MODE_PRIVATE)
            val edit = prefs.edit()
            for (group in legacyMovieResumeGroups(old.all)) {
                val owner = group.aliases.first()
                edit.putLong("position:$owner", group.positionMs)
                edit.putStringSet("members:$owner", group.aliases)
                for (alias in group.aliases) edit.putString("owner:$alias", owner)
            }
            edit.putBoolean("migrated", true).apply()
        }
    }

    private fun aliases(id: String) = if (id == boundId) boundAliases else movieResumeAliases(id)

    private fun lookup(alias: String): MovieResumeGroup? {
        val owner = prefs.getString("owner:$alias", null) ?: return null
        val members = prefs.getStringSet("members:$owner", null) ?: return null
        return MovieResumeGroup(members, prefs.getLong("position:$owner", 0), prefs.getLong("revision:$owner", 0),
            prefs.getLong("duration:$owner", 0))
    }

    fun snapshot(mediaId: String) = resolveMovieResume(aliases(mediaId), ::lookup)

    fun read(mediaId: String): Long {
        val keys = aliases(mediaId)
        val group = resolveMovieResume(keys, ::lookup)
        if (group.positionMs >= 8000 && keys.any { lookup(it) != group }) write(group, group.positionMs, group.revision)
        return group.positionMs
    }

    fun restore(session: MovieStartupRecovery) {
        val saved = read(session.current.mediaId)
        if (saved >= 8000L) session.savePosition(saved, positionEstablished = true)
    }

    fun applyUpdate(mediaId: String, positionMs: Long, update: Update, durationMs: Long = 0L) {
        if (mediaId.isBlank() || update == Update.KEEP) return
        val group = resolveMovieResume(aliases(mediaId), ::lookup)
        write(group.copy(durationMs = durationMs.coerceAtLeast(0)), if (update == Update.CLEAR) 0 else positionMs)
    }

    fun hiddenMovies(): Set<String> = prefs.getStringSet("hidden_movies", emptySet()).orEmpty().toSet()

    fun hideMovie(movie: MediaItem): Set<String> {
        val keys = movieVisibilityKeys(movie)
        val linked = resolveMovieResume(movieResumeAliases(movie.id, movie), ::lookup)
        val hidden = hiddenMovies() + keys + linked.aliases
        prefs.edit().putStringSet("hidden_movies", hidden).apply()
        return hidden
    }

    /** Read one immutable preferences snapshot, so a shelf never mixes two save revisions. */
    fun recentMovies(): List<RecentMovie> {
        val values = prefs.all
        return values.mapNotNull { (key, position) ->
            if (!key.startsWith("position:") || position !is Long) return@mapNotNull null
            val owner = key.removePrefix("position:")
            val members = (values["members:$owner"] as? Set<*>)?.filterIsInstance<String>()?.toSet()
                ?: return@mapNotNull null
            val group = MovieResumeGroup(members, position, values["revision:$owner"] as? Long ?: 0L,
                values["duration:$owner"] as? Long ?: 0L)
            RecentMovie(group, decodeResumeCard(values["card:$owner"] as? String))
        }
    }

    private fun write(group: MovieResumeGroup, positionMs: Long, inheritedRevision: Long? = null) {
        val edit = prefs.edit()
        val owners = group.aliases.mapNotNull { prefs.getString("owner:$it", null) }.distinct()
        val previousCard = owners.sortedByDescending { prefs.getLong("revision:$it", 0) }
            .firstNotNullOfOrNull { prefs.getString("card:$it", null) }
        for (old in owners) {
            edit.remove("position:$old").remove("members:$old").remove("revision:$old").remove("duration:$old").remove("card:$old")
        }
        if (positionMs < 8000L) {
            for (alias in group.aliases) edit.remove("owner:$alias")
        } else {
            val owner = owners.firstOrNull() ?: group.aliases.first()
            val revision = inheritedRevision ?: (prefs.getLong("clock", 0) + 1)
            if (inheritedRevision == null) edit.putLong("clock", revision)
            val card = item?.takeIf { "raw:" + it.id in group.aliases }
                ?.withResumeArtwork(decodeResumeCard(previousCard))?.let(::encodeResumeCard) ?: previousCard
            if (card != null) edit.putString("card:$owner", card)
            edit.putLong("revision:$owner", revision)
            edit.putLong("duration:$owner", group.durationMs)
            edit.putLong("position:$owner", positionMs).putStringSet("members:$owner", group.aliases)
            for (alias in group.aliases) edit.putString("owner:$alias", owner)
        }
        edit.apply()
    }
}
