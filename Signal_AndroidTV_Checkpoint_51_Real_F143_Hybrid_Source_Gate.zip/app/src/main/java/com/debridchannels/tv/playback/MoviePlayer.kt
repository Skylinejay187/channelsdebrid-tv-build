package com.debridchannels.tv.playback

import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.LocalActivity
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.tv.material3.Text
import com.debridchannels.core.data.MovieResumePolicy
import com.debridchannels.core.data.MovieStartupWatchdog
import com.debridchannels.core.data.MovieStartupRecovery
import android.os.Handler
import android.os.Looper

@OptIn(UnstableApi::class)
@Composable
fun MoviePlayer(session: MovieStartupRecovery, resumeStore: MovieResumeStore? = null, onEnded: (() -> Unit)? = null, onBack: () -> Unit) {
    val owner = LocalActivity.current as ComponentActivity
    val context = LocalContext.current
    val view = remember(context) { PlayerView(context) }
    var message by remember(session) { mutableStateOf<String?>("Opening stream…") }
    val currentOnEnded by rememberUpdatedState(onEnded)
    BackHandler(onBack = onBack)
    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        AndroidView(factory = { view }, modifier = Modifier.fillMaxSize())
        message?.let { Text(it, color = Color.White) }
    }
    DisposableEffect(owner, view, session, resumeStore) {
        var controller: Media3PlaybackController? = null
        val handler = Handler(Looper.getMainLooper())
        var positionEstablished = false
        var playWhenReady = true
        var activeWatchdog: MovieStartupWatchdog? = null
        var saveOnExit: (() -> Unit)? = null
        fun release(savePosition: Boolean = true) {
            if (savePosition) saveOnExit?.invoke()
            saveOnExit = null
            activeWatchdog?.stop()
            activeWatchdog = null
            handler.removeCallbacksAndMessages(null)
            view.player?.let {
                if (savePosition) session.savePosition(it.currentPosition, positionEstablished)
                playWhenReady = it.playWhenReady
            }
            view.player = null
            controller?.release()
            controller = null
        }
        val observer = object : DefaultLifecycleObserver {
            override fun onStart(owner: LifecycleOwner) = open()

            private fun open() {
                positionEstablished = false
                val player = ExoPlayer.Builder(context).build()
                val playback = Media3PlaybackController(player)
                controller = playback
                view.player = player
                view.requestFocus()
                val mediaId = session.current.mediaId
                val resume = MovieResumePolicy(session.current.resumePositionMs)
                fun checkpoint(exiting: Boolean) {
                    if (view.player !== player || !positionEstablished || player.playbackState == Player.STATE_ENDED) return
                    val position = player.currentPosition
                    resumeStore?.applyUpdate(mediaId, position, resume.update(position, player.duration, exiting), player.duration)
                }
                saveOnExit = { checkpoint(true) }
                val periodicSave = object : Runnable {
                    override fun run() {
                        if (view.player !== player || !player.isPlaying) return
                        checkpoint(false)
                        handler.postDelayed(this, 5000L)
                    }
                }
                fun recover(transient: Boolean, reason: String) {
                    if (view.player !== player) return
                    val action = session.failed(transient, player.currentPosition)
                    if (action == MovieStartupRecovery.Action.STOP) {
                        message = "Playback failed ($reason). Press Back to return."
                        return
                    }
                    release(savePosition = false)
                    val retry = action == MovieStartupRecovery.Action.RETRY
                    message = if (retry) "Retrying selected link…" else "Trying next movie source…"
                    handler.postDelayed({ open() }, if (retry) 1200L else 0L)
                }
                val watchdog = MovieStartupWatchdog(
                    schedule = { callback, delay -> handler.postDelayed(callback, delay) },
                    cancel = { callback -> handler.removeCallbacks(callback) },
                    bufferedMs = { player.totalBufferedDuration },
                    expired = { recover(false, "No video frame") },
                )
                activeWatchdog = watchdog
                fun updateWatchdog() {
                    if (view.player !== player) return
                    if (player.playWhenReady && player.playerError == null) {
                        session.startupGraceMs()?.let(watchdog::arm)
                    } else watchdog.stop()
                }
                player.addListener(object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        watchdog.stop()
                        val transient = error.errorCode in setOf(
                            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
                            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT,
                            PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS,
                            PlaybackException.ERROR_CODE_IO_UNSPECIFIED,
                        )
                        recover(transient, error.errorCodeName)
                    }
                    override fun onRenderedFirstFrame() {
                        watchdog.stop()
                        if (view.player === player) {
                            positionEstablished = true
                            session.firstFrame()
                        }
                    }
                    override fun onPositionDiscontinuity(
                        oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int,
                    ) {
                        if (view.player === player && reason == Player.DISCONTINUITY_REASON_SEEK) {
                            positionEstablished = true
                            resume.seekTo(newPosition.positionMs)
                            session.savePosition(newPosition.positionMs, positionEstablished = true)
                        }
                    }
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        if (view.player !== player || resumeStore == null) return
                        handler.removeCallbacks(periodicSave)
                        if (isPlaying) handler.postDelayed(periodicSave, 5000L)
                    }
                    override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                        if (!playWhenReady) checkpoint(false)
                        updateWatchdog()
                    }
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (view.player !== player) return
                        if (playbackState == Player.STATE_ENDED) {
                            resumeStore?.applyUpdate(mediaId, 0L, MovieResumePolicy.Update.CLEAR)
                            currentOnEnded?.invoke()
                        }
                        if (playbackState == Player.STATE_READY) message = null
                        if (playbackState == Player.STATE_BUFFERING) message = "Buffering…"
                    }
                })
                val result = playback.openVod(session.current, playWhenReady)
                if (!result.accepted) message = result.message
                if (result.accepted) updateWatchdog()
                view.showController()
            }
            override fun onStop(owner: LifecycleOwner) = release()
        }
        owner.lifecycle.addObserver(observer)
        onDispose {
            owner.lifecycle.removeObserver(observer)
            release()
        }
    }
}
