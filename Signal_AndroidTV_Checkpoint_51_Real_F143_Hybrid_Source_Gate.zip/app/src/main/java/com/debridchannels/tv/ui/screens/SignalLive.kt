package com.debridchannels.tv.ui.screens

import android.util.AtomicFile
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.LocalActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.tv.material3.Button
import androidx.tv.material3.Text
import coil.compose.AsyncImage
import com.debridchannels.core.data.SignalStation
import com.debridchannels.core.data.signalStations
import com.debridchannels.core.model.LivePlaybackRequest
import com.debridchannels.tv.R
import com.debridchannels.tv.playback.Media3PlaybackController
import kotlinx.coroutines.*
import java.io.File
import java.io.InputStream

private fun readLineup(stream: InputStream): String = stream.bufferedReader().use { reader ->
    val result = StringBuilder()
    val buffer = CharArray(8192)
    while (true) {
        val count = reader.read(buffer)
        if (count < 0) break
        require(result.length + count <= 2_000_000)
        result.append(buffer, 0, count)
    }
    result.toString()
}

internal class SignalLineupStore(directory: File) {
    private val file = AtomicFile(File(directory, "signal-lineup.m3u"))
    fun restore(): List<SignalStation> = try {
        signalStations(readLineup(file.openRead()))
    } catch (_: java.io.FileNotFoundException) { emptyList() }

    fun replace(text: String): List<SignalStation> {
        val stations = signalStations(text)
        require(stations.isNotEmpty())
        val output = file.startWrite()
        try {
            output.write(text.toByteArray())
            file.finishWrite(output)
        } catch (e: Exception) {
            file.failWrite(output)
            throw e
        }
        return stations
    }
}

@Composable
internal fun SignalLiveScreen(stations: List<SignalStation>, sports: Boolean, notice: String,
    busy: Boolean, onImport: (() -> String) -> Unit, onPlay: (SignalStation?) -> Unit) {
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onImport { readLineup(requireNotNull(context.contentResolver.openInputStream(uri))) }
    }
    var address by remember { mutableStateOf("") }
    var pickerFailure by remember { mutableStateOf(false) }
    val visible = remember(stations, sports) { if (sports) stations.filter { it.channel.isSports } else stations }
    Column(Modifier.fillMaxSize().background(Color.Black.copy(alpha = if (sports) 0.78f else 0.94f)).padding(horizontal = 28.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (sports) "Sports channels" else "Live TV", color = Color.White)
        if (!sports) {
            Text("Import an M3U channel list or enter a direct HTTPS stream. Saving replaces your lineup.", color = Color.LightGray)
            BasicTextField(address, { address = it }, singleLine = true, textStyle = TextStyle(color = Color.White),
                modifier = Modifier.fillMaxWidth().background(Color.DarkGray).padding(8.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (!sports) {
                Button(enabled = !busy, onClick = {
                    try { picker.launch(arrayOf("*/*")) } catch (_: android.content.ActivityNotFoundException) { pickerFailure = true }
                }) { Text("Import M3U file") }
                Button(enabled = !busy && address.isNotBlank(), onClick = {
                    val input = address.trim()
                    onImport { input }
                }) { Text("Save stream") }
            }
            Button(onClick = { onPlay(null) }) { Text("Test picture & sound") }
        }
        if (pickerFailure) Text("No file picker is installed. Enter a direct stream above.", color = Color.White)
        if (notice.isNotBlank()) Text(notice, color = Color.White)
        if (visible.isEmpty()) Text(if (sports) "Import sports channels in Live TV." else "No channels configured.", color = Color.LightGray)
        LazyVerticalGrid(GridCells.Fixed(3), horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(visible, key = { it.channel.id }) { station ->
                Button(onClick = { onPlay(station) }) {
                    station.logo?.let { AsyncImage(it, null, Modifier.size(35.dp), contentScale = ContentScale.Fit) }
                    Text("${station.channel.number}  ${station.channel.name}", maxLines = 2)
                }
            }
        }
    }
}

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
internal fun SignalStationPlayer(station: SignalStation?, onBack: () -> Unit) {
    val context = LocalContext.current
    val owner = LocalActivity.current as ComponentActivity
    val view = remember(context) { PlayerView(context) }
    var status by remember(station) { mutableStateOf("Opening stream…") }
    var attempt by remember(station) { mutableIntStateOf(0) }
    var failed by remember(station) { mutableStateOf(false) }
    BackHandler(onBack = onBack)
    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        AndroidView({ view }, Modifier.fillMaxSize())
        if (failed) Button(onClick = { attempt++ }) { Text("$status · Retry") }
        else if (status.isNotEmpty()) Text(status, color = Color.White)
    }
    DisposableEffect(owner, station, attempt) {
        val observer = object : DefaultLifecycleObserver {
            var player: ExoPlayer? = null
            override fun onStart(owner: LifecycleOwner) {
                failed = false
                status = "Opening stream…"
                val exo = ExoPlayer.Builder(context).build()
                player = exo
                view.player = exo
                view.requestFocus()
                exo.addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(state: Int) {
                        if (!failed) status = if (state == Player.STATE_BUFFERING) "Buffering…" else ""
                    }
                    override fun onPlayerError(error: PlaybackException) {
                        failed = true
                        status = error.errorCodeName
                    }
                })
                if (station == null) {
                    exo.setMediaItem(androidx.media3.common.MediaItem.fromUri("android.resource://${context.packageName}/${R.raw.signal_playback_check}"))
                    exo.repeatMode = Player.REPEAT_MODE_ONE
                    exo.prepare()
                    exo.playWhenReady = true
                } else {
                    val result = Media3PlaybackController(exo).openLive(LivePlaybackRequest(station.channel.id, station.channel.name, station.url))
                    if (!result.accepted) { failed = true; status = result.message.orEmpty() }
                }
            }
            override fun onStop(owner: LifecycleOwner) {
                view.player = null
                player?.release()
                player = null
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer); observer.onStop(owner) }
    }
}
