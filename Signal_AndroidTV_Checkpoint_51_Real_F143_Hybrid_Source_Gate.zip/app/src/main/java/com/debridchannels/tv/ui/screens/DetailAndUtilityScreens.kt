package com.debridchannels.tv.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import com.debridchannels.core.data.MovieResumeDisplay
import com.debridchannels.core.data.display
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import com.debridchannels.core.model.MediaType
import com.debridchannels.core.data.MovieStartupRecovery
import com.debridchannels.core.data.findMovieSources
import com.debridchannels.core.data.MovieSourceOption
import com.debridchannels.core.data.sourceManifestUri
import com.debridchannels.tv.playback.MovieResumeStore
import com.debridchannels.tv.playback.MoviePlayer
import com.debridchannels.tv.playback.StreamProviderConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.remember
import androidx.compose.runtime.key
import androidx.compose.ui.graphics.painter.Painter
import com.debridchannels.core.data.DetailBackdropSession
import com.debridchannels.core.data.resolveCatalogTrailer
import com.debridchannels.core.data.premiumDetailBackdrops
import kotlinx.coroutines.runInterruptible
import com.debridchannels.core.data.detailBackdropUrls
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import com.debridchannels.core.designsystem.DebridColors
import com.debridchannels.core.designsystem.FocusSurface
import com.debridchannels.core.model.LiveChannel
import com.debridchannels.core.model.MediaItem
import com.debridchannels.core.model.SourceResult
import com.debridchannels.tv.ui.artworkResource

@Composable
fun DetailScreen(
    item: MediaItem,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    isFavorite: Boolean = false,
    onToggleFavorite: ((MediaItem) -> Unit)? = null,
    catalogAnchor: MediaItem? = null,
    backdropSession: DetailBackdropSession = remember { DetailBackdropSession() },
) {
    val entry = remember { FocusRequester() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var request by remember(item) { mutableStateOf<MovieStartupRecovery?>(null) }
    var finding by remember(item) { mutableStateOf(false) }
    var status by remember(item) { mutableStateOf("") }
    var sources by remember(item) { mutableStateOf(emptyList<MovieSourceOption>()) }
    var selectedIndex by remember(item) { mutableStateOf(0) }
    var returnToSources by remember(item) { mutableStateOf(false) }
    val canWatchTrailer = item.type == MediaType.MOVIE || item.type == MediaType.SHOW
    var resolvingTrailer by remember(item) { mutableStateOf(false) }
    var trailerSession by remember(item) { mutableStateOf<MovieStartupRecovery?>(null) }
    var returnToTrailer by remember(item) { mutableStateOf(false) }
    val trailerChip = remember { FocusRequester() }
    val sourceChip = remember { FocusRequester() }

    val resumeStore = remember(context, item) { MovieResumeStore(context, item) }
    fun launchMovie(option: MovieSourceOption, results: List<MovieSourceOption>) {
        val session = MovieStartupRecovery(option.playback, results)
        resumeStore.restore(session)
        request = session
    }

    LaunchedEffect(item, resolvingTrailer) {
        if (resolvingTrailer) {
            try {
                val resolved = resolveCatalogTrailer(item) { status = "Preparing trailer…" }
                if (resolved == null) status = "No playable trailer is ready. Try again later."
                else {
                    status = ""
                    trailerSession = MovieStartupRecovery(resolved, emptyList())
                }
            } catch (_: java.io.IOException) {
                status = "Could not reach the trailer service. Try again."
            } finally {
                resolvingTrailer = false
            }
        }
    }

    fun search(choose: Boolean) {
        if (finding || resolvingTrailer) return
        if (item.type != MediaType.MOVIE) {
            status = "Episode playback is pending."
            return
        }
        returnToTrailer = false
        returnToSources = choose
        finding = true
        status = "Checking movie stream provider…"
        scope.launch {
            try {
                val results = withContext(Dispatchers.IO) {
                    val config = StreamProviderConfig(context)
                    val uri = sourceManifestUri(config.read())
                    uri?.let { findMovieSources(item, it, config.resultLimit) }
                }
                when {
                    results == null -> status = "Add a movie stream provider in Settings → Source Intelligence."
                    results.isEmpty() -> status = "This provider returned no direct movie stream."
                    choose -> {
                        status = ""
                        selectedIndex = 0
                        sources = results
                    }
                    else -> launchMovie(results.first(), results)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                status = "Could not load the stream provider. Check its configuration and retry."
            } finally {
                finding = false
            }
        }
    }
    var premium by remember(catalogAnchor) { mutableStateOf<String?>(null) }
    var lookupFinished by remember(catalogAnchor) { mutableStateOf(false) }
    val preview = trailerSession
    if (preview != null) {
        val close = { trailerSession = null }
        MoviePlayer(preview, onEnded = close, onBack = close)
        return
    }
    val playing = request
    if (playing != null) {
        MoviePlayer(playing, resumeStore, onBack = { request = null; status = "" })
        return
    }
    LaunchedEffect(catalogAnchor, backdropSession) {
        if (catalogAnchor != null && !lookupFinished) {
            premium = backdropSession.next(catalogAnchor) ?: run {
                val (tmdbKey, fanartKey) = runInterruptible(Dispatchers.IO) {
                    val config = StreamProviderConfig(context)
                    val tmdb = try { config.readArtworkKey() } catch (_: java.io.IOException) { "" }
                    val fanart = try { config.readFanartKey() } catch (_: java.io.IOException) { "" }
                    tmdb to fanart
                }
                val pool = premiumDetailBackdrops(catalogAnchor, tmdbKey, fanartKey)
                backdropSession.next(catalogAnchor, pool)
            }
            lookupFinished = true
        }
    }
    var resumeDisplay by remember(resumeStore) { mutableStateOf<MovieResumeDisplay?>(null) }
    LaunchedEffect(resumeStore) {
        if (item.type == MediaType.MOVIE) resumeDisplay = resumeStore.snapshot(item.id).display()
    }
    val choosing = sources.isNotEmpty()
    LaunchedEffect(item.id, choosing) {
        if (!choosing) {
            val target = when {
                returnToTrailer && canWatchTrailer -> trailerChip
                returnToSources -> sourceChip
                else -> entry
            }
            target.requestFocus()
        }
    }
    Box(modifier.fillMaxSize().background(DebridColors.Black)) {
        DetailBackdrop(item, catalogAnchor, premium)
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.Black, Color.Black.copy(alpha = 0.78f), Color.Transparent))))
        Column(Modifier.fillMaxWidth(0.58f).align(Alignment.CenterStart).padding(start = 72.dp)) {
            Text(item.logoText, color = Color.White, fontSize = 52.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Text(item.year?.toString().orEmpty(), color = Color.White.copy(alpha = 0.72f), fontSize = 16.sp)
                item.rating?.let { Text("★ $it", color = DebridColors.Orange, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                item.runtimeMinutes?.let { Text("${it}m", color = Color.White.copy(alpha = 0.72f), fontSize = 16.sp) }
            }
            Spacer(Modifier.height(14.dp))
            Text(item.description, color = Color.White.copy(alpha = 0.82f), fontSize = 18.sp)
            Spacer(Modifier.height(28.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                ActionChip("Play", Modifier.weight(1f)) { search(false) }
                ActionChip("Source Intelligence", Modifier.weight(1.5f).focusRequester(sourceChip)) { search(true) }
                ActionChip("Back", Modifier.weight(1f).focusRequester(entry), onBack)
            }
            if (canWatchTrailer) {
                Spacer(Modifier.height(12.dp))
                ActionChip("Watch Trailer", Modifier.focusRequester(trailerChip)) {
                    if (!finding && !resolvingTrailer) {
                        returnToTrailer = true
                        status = "Finding trailer…"
                        resolvingTrailer = true
                    }
                }
            }
            if (onToggleFavorite != null && (item.type == MediaType.MOVIE || item.type == MediaType.SHOW)) {
                Spacer(Modifier.height(12.dp))
                ActionChip(if (isFavorite) "Remove from Favorites" else "Add to Favorites") {
                    onToggleFavorite(item)
                }
            }
            resumeDisplay?.let { resume ->
                Column(Modifier.padding(top = 8.dp).clearAndSetSemantics {
                    contentDescription = "Resume at ${resume.timestamp}, ${resume.remaining} remaining"
                }) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(Modifier.width(132.dp).height(6.dp).background(Color.White.copy(alpha = 0.16f), RoundedCornerShape(3.dp))) {
                            Box(Modifier.width((132f * resume.fraction).coerceAtLeast(8f).dp).height(6.dp).background(
                                Brush.horizontalGradient(listOf(DebridColors.Cyan, Color.White)), RoundedCornerShape(3.dp)))
                        }
                        Text("${resume.percent}%", color = Color.White, fontSize = 10.sp)
                    }
                    Text("RESUME ${resume.timestamp} • ${resume.remaining} LEFT", color = DebridColors.Cyan,
                        fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
            if (status.isNotEmpty()) Text(status, color = Color.White)
        }
    }
    if (choosing) {
        MovieSourcePicker(item.title, sources, selectedIndex, resume = resumeDisplay, onDismiss = { sources = emptyList() },
            onPlay = { index ->
                selectedIndex = index
                launchMovie(sources[index], sources)
            })
    }
}

@Composable
private fun DetailBackdrop(item: MediaItem, catalogAnchor: MediaItem?, premium: String?) = key<Unit>(item.type, item.id) {
    val base = remember(item, catalogAnchor) { detailBackdropUrls(item, catalogAnchor) }
    var baseReady by remember(base) { mutableStateOf(base.isEmpty()) }
    val urls = remember(base, premium, baseReady) {
        val alternate = premium
        if (baseReady && alternate != null) {
            (detailBackdropUrls(item.copy(landscapeUrl = alternate, posterUrl = null)) + base).distinct()
        } else base
    }
    var index by remember(urls) { mutableStateOf(0) }
    var lastImage by remember { mutableStateOf<Painter?>(null) }
    val localKey = catalogAnchor?.landscapeKey.orEmpty().ifBlank { catalogAnchor?.posterKey.orEmpty() }
        .ifBlank { item.landscapeKey }.ifBlank { item.posterKey }
    val fallback = lastImage ?: if (localKey.isNotBlank()) painterResource(artworkResource(localKey)) else null
    val url = urls.getOrNull(index)
    if (url != null) key(urls, index) {
        coil.compose.AsyncImage(model = url, contentDescription = null, modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop, alpha = 0.50f, placeholder = fallback, error = fallback,
            onSuccess = {
                lastImage = it.painter
                baseReady = true
            }, onError = {
                index++
                if (index >= urls.size) baseReady = true
            })
    } else if (fallback != null) {
        Image(fallback, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alpha = 0.50f)
    }
}

@Composable
fun SearchScreen(rows: List<com.debridchannels.core.model.CatalogRow>,
    stations: List<com.debridchannels.core.data.SignalStation>, query: String, onQuery: (String) -> Unit, onItem: (MediaItem) -> Unit,
    onStation: (com.debridchannels.core.data.SignalStation) -> Unit, onBack: () -> Unit) {
    val term = query.trim()
    val titles = remember(rows, term) {
        rows.asSequence().flatMap { it.items.asSequence() }.filter { it.title.contains(term, true) }
            .distinctBy { it.type to it.id }.take(80).toList()
    }
    val channels = remember(stations, term) { stations.filter { it.channel.name.contains(term, true) }.take(80) }
    val field = remember { FocusRequester() }
    LaunchedEffect(Unit) { field.requestFocus() }
    Column(Modifier.fillMaxSize().background(Color.Black).padding(28.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Search movies, shows and channels", color = Color.White, fontSize = 22.sp)
        androidx.compose.foundation.text.BasicTextField(query, onQuery, singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 18.sp),
            modifier = Modifier.focusRequester(field).fillMaxWidth().background(Color.DarkGray).padding(10.dp))
        ActionChip("Back", onClick = onBack)
        if (titles.isEmpty() && channels.isEmpty()) Text("No matches", color = Color.White)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(channels) { station -> ActionChip(station.channel.name, onClick = { onStation(station) }) }
            items(titles) { item -> ActionChip(item.title, onClick = { onItem(item) }) }
        }
    }
}

@Composable
fun SourceResultsScreen(results: List<SourceResult>, limit: Int, onBack: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().background(DebridColors.Black).padding(58.dp)) {
        Text("Source Intelligence", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Black)
        Text("Best ranked links ready (${results.size}/$limit max).", color = DebridColors.Cyan, fontSize = 14.sp)
        Spacer(Modifier.height(22.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth(0.72f)) {
            items(results, key = { it.id }) { source ->
                Box(Modifier.fillMaxWidth().background(Color.White.copy(alpha = 0.07f), RoundedCornerShape(16.dp)).padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(source.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("${source.provider} • ${source.sizeLabel}", color = Color.White.copy(alpha = 0.48f), fontSize = 12.sp)
                        }
                        Text(if (source.cached) "CACHED" else "UNCACHED", color = if (source.cached) DebridColors.Green else DebridColors.Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        ActionChip("Back", onClick = onBack)
    }
}

@Composable
internal fun ActionChip(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    FocusSurface(
        onClick = onClick,
        modifier = modifier.width(220.dp).height(56.dp),
        shape = RoundedCornerShape(18.dp),
        focusedScale = 1.03f,
    ) { focused ->
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(text, color = if (focused) Color.White else Color.White.copy(alpha = 0.82f), fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}
