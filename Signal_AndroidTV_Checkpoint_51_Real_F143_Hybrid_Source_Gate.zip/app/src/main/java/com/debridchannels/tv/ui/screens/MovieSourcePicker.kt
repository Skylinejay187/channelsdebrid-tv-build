package com.debridchannels.tv.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.tv.material3.Text
import com.debridchannels.core.data.MovieResumeDisplay
import com.debridchannels.core.data.MovieSourceOption
import com.debridchannels.core.designsystem.DebridColors
import com.debridchannels.core.designsystem.FocusSurface

@Composable
internal fun MovieSourcePicker(
    movie: String, options: List<MovieSourceOption>, initialIndex: Int,
    resume: MovieResumeDisplay? = null, onDismiss: () -> Unit, onPlay: (Int) -> Unit,
) {
    var confirming by remember { mutableStateOf<Int?>(null) }
    var restoreIndex by remember { mutableStateOf<Int?>(initialIndex) }
    val list = rememberLazyListState(initialFirstVisibleItemIndex = initialIndex)
    fun back() {
        val index = confirming
        if (index == null) onDismiss() else {
            restoreIndex = index
            confirming = null
        }
    }
    Dialog(onDismissRequest = ::back, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxWidth(0.75f).background(Color(0xFF171719)).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(movie, color = Color.White, fontSize = 24.sp, maxLines = 1)
            val index = confirming
            if (index == null) {
                Row(verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("Choose a source", color = Color.White)
                    resume?.let { Text("RESUME ${it.timestamp} • ${it.remaining.uppercase()} LEFT",
                        color = DebridColors.Cyan, fontSize = 12.sp) }
                }
                LazyColumn(state = list, modifier = Modifier.heightIn(max = 300.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    itemsIndexed(options) { i, option ->
                        val modifier = if (restoreIndex == i) {
                            val focus = remember { FocusRequester() }
                            LaunchedEffect(focus) { focus.requestFocus(); restoreIndex = null }
                            Modifier.focusRequester(focus)
                        } else Modifier
                        FocusSurface(onClick = { confirming = i }, modifier = modifier.fillMaxWidth()) {
                            Text(option.label, Modifier.padding(12.dp), color = Color.White,
                                maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            } else {
                val selected = options[index]
                selected.provider?.let { Text(it, color = Color.LightGray) }
                selected.sizeBytes?.let {
                    Text(android.text.format.Formatter.formatFileSize(androidx.compose.ui.platform.LocalContext.current, it), color = Color.LightGray)
                }
                Text(selected.label, color = Color.White, maxLines = 4, overflow = TextOverflow.Ellipsis)
                val focus = remember { FocusRequester() }
                LaunchedEffect(index) { focus.requestFocus() }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ActionChip("Play source", Modifier.focusRequester(focus)) { onPlay(index) }
                    ActionChip("Back", onClick = ::back)
                }
            }
        }
    }
}
