package com.debridchannels.tv

import android.content.Context
import android.os.SystemClock
import android.view.InputDevice
import android.view.ViewConfiguration
import android.view.KeyEvent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.platform.app.InstrumentationRegistry
import com.debridchannels.core.data.encodeFavorite
import com.debridchannels.core.data.restoreFavorite
import com.debridchannels.tv.ui.DebridChannelsApp
import com.debridchannels.core.data.storedFavoriteKey
import com.debridchannels.core.data.catalogFavoriteKey
import com.debridchannels.core.designsystem.DebridChannelsTheme
import com.debridchannels.core.model.CatalogRow
import com.debridchannels.core.model.MediaItem
import com.debridchannels.core.model.MediaType
import com.debridchannels.tv.ui.screens.CatalogScreen
import com.debridchannels.tv.ui.screens.DetailScreen
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test

class CatalogDetailFocusTest {
    @get:Rule val compose = createComposeRule()

    private fun remote(key: Int) {
        InstrumentationRegistry.getInstrumentation().sendKeyDownUpSync(key)
        compose.waitForIdle()
    }

    private fun holdCenter() {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val start = SystemClock.uptimeMillis()
        fun send(action: Int, repeat: Int = 0, flags: Int = 0) {
            instrumentation.sendKeySync(KeyEvent(start, SystemClock.uptimeMillis(), action,
                KeyEvent.KEYCODE_DPAD_CENTER, repeat, 0, -1, 0, flags, InputDevice.SOURCE_DPAD))
        }
        send(KeyEvent.ACTION_DOWN)
        try {
            SystemClock.sleep(ViewConfiguration.getLongPressTimeout().toLong() + 100)
            send(KeyEvent.ACTION_DOWN, 1, KeyEvent.FLAG_LONG_PRESS)
        } finally {
            send(KeyEvent.ACTION_UP)
        }
        compose.waitForIdle()
    }

    @Test fun backRestoresRefreshedDuplicateToOriginalShelfAndCenterReopensIt() {
        verifyReturnToRefreshedCard("provider:tt123")
    }

    @Test fun backRestoresByTitleAndYearWhenTheProviderIdChanges() {
        verifyReturnToRefreshedCard("other-catalog:42")
    }

    @Test fun continueWatchingHoldTargetsTheSelectedCardAndCancelPreservesIt() {
        val film = MediaItem("fixture", "Movie fixture", MediaType.MOVIE, 2026, "", "", "poster_01", "live_01")
        val shelf = CatalogRow("dc-local-continue", "Continue Watching", items = listOf(film))
        val next = film.copy(id = "next", title = "Next movie")
        var rows by mutableStateOf(listOf(shelf, CatalogRow("popular", "Popular", items = listOf(next, film))))
        var removed: MediaItem? = null
        compose.setContent {
            DebridChannelsTheme {
                CatalogScreen("Movies", rows, onItemSelected = { error("Unexpected short click") },
                    onRemoveMovie = {
                        removed = it
                        rows = rows.drop(1)
                    })
            }
        }
        val card = compose.onNode(hasAnyAncestor(hasTestTag("catalog-row-dc-local-continue")) and hasClickAction())
        card.performSemanticsAction(SemanticsActions.RequestFocus)
        holdCenter()
        compose.onNodeWithText("Cancel").assertIsFocused()
        remote(KeyEvent.KEYCODE_BACK)
        compose.runOnIdle { assertEquals(null, removed) }
        card.performSemanticsAction(SemanticsActions.OnLongClick)
        compose.onNodeWithText("Remove from Continue Watching").performClick()
        compose.runOnIdle { assertEquals(film, removed) }
        compose.onNode(hasAnyAncestor(hasTestTag("catalog-row-popular")) and hasText(next.title) and hasClickAction())
            .assertIsFocused()
    }

    @Test fun showCanBeAddedAndRemovedFromItsCatalogMenu() {
        val show = MediaItem("series", "Series fixture", MediaType.SHOW, 2026, "", "", "poster_01", "live_01")
        var shelf by mutableStateOf(CatalogRow("shows", "Shows", items = listOf(show)))
        var saved by mutableStateOf(emptyMap<String, MediaItem>())
        compose.setContent {
            DebridChannelsTheme {
                CatalogScreen("Shows", listOf(shelf), onItemSelected = { error("Unexpected short click") },
                    favorites = saved, onToggleFavorite = { item ->
                        val key = item.catalogFavoriteKey()!!
                        val stored = saved.storedFavoriteKey(item)
                        saved = if (stored == null) saved + (key to item) else saved - stored
                    })
            }
        }
        val card = compose.onNode(hasAnyAncestor(hasTestTag("catalog-row-shows")) and hasClickAction())
        card.performSemanticsAction(SemanticsActions.OnLongClick)
        compose.onNodeWithText("Remove from Continue Watching").assertDoesNotExist()
        compose.onNodeWithText("Add to Favorites").performClick()
        compose.runOnIdle { shelf = shelf.copy(items = listOf(show.copy(imdbId = "tt123"))) }
        card.performSemanticsAction(SemanticsActions.OnLongClick)
        compose.onNodeWithText("Remove from Favorites").performClick()
        compose.runOnIdle { assertEquals(emptyMap<String, MediaItem>(), saved) }
    }

    @Test fun detailAndShelfToggleTheSamePersistedFavorite() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val prefs = context.getSharedPreferences("catalog_favorites", Context.MODE_PRIVATE)
        val film = MediaItem("test-" + java.util.UUID.randomUUID(), "Detail favorite fixture", MediaType.MOVIE,
            2026, "", "", "poster_01", "live_01")
        val key = film.catalogFavoriteKey()!!
        check(prefs.edit().putString(key, encodeFavorite(film)).commit())
        try {
            compose.setContent { DebridChannelsTheme { DebridChannelsApp() } }
            compose.onNode(hasText("Favorites") and hasClickAction()).performClick()
            val shelf = hasAnyAncestor(hasTestTag("catalog-row-catalog-favorites-quick-panel"))
            val card = compose.onNode(shelf and hasText(film.title) and hasClickAction())
            card.performClick()
            val remove = compose.onNodeWithText("Remove from Favorites")
            remove.performSemanticsAction(SemanticsActions.RequestFocus)
            remote(KeyEvent.KEYCODE_DPAD_CENTER)
            compose.onNodeWithText("Add to Favorites").assertIsFocused()
            compose.runOnIdle { assertEquals(false, prefs.contains(key)) }
            remote(KeyEvent.KEYCODE_DPAD_CENTER)
            remove.assertIsFocused()
            compose.runOnIdle { assertEquals(film, restoreFavorite(key, prefs.getString(key, null))) }
            remote(KeyEvent.KEYCODE_BACK)
            card.assertIsFocused()
            card.performSemanticsAction(SemanticsActions.OnLongClick)
            compose.onNodeWithText("Remove from Favorites").performClick()
            card.assertDoesNotExist()
            compose.runOnIdle { assertEquals(false, prefs.contains(key)) }
        } finally {
            prefs.edit().remove(key).commit()
        }
    }

    private fun verifyReturnToRefreshedCard(refreshedId: String) {
        val title = MediaItem("tt123", "Shared title", MediaType.MOVIE, 2026, "", "", "poster_01", "live_01")
        val other = title.copy(id = "other", title = "Other title")
        val first = CatalogRow("first", "First shelf", items = listOf(title))
        val source = CatalogRow("source", "Second shelf", items = listOf(title, other))
        val refreshed = title.copy(id = refreshedId, description = "Updated on source shelf")
        var rows by mutableStateOf(listOf(first, source))
        var detail by mutableStateOf<MediaItem?>(null)
        compose.setContent {
            DebridChannelsTheme {
                BackHandler(enabled = detail != null) { detail = null }
                Box {
                    CatalogScreen("Movies", rows, onItemSelected = { detail = it }, detailOpen = detail != null)
                    detail?.let { DetailScreen(it, onBack = { detail = null }) }
                }
            }
        }

        val sourceShelf = hasTestTag("catalog-row-source")
        val sourceCard = hasAnyAncestor(sourceShelf) and hasText(title.title) and hasClickAction()
        remote(KeyEvent.KEYCODE_DPAD_RIGHT)
        compose.onNodeWithTag("catalog-rows").performScrollToKey(source.id)
        compose.onNode(sourceCard).performSemanticsAction(SemanticsActions.RequestFocus)
        compose.onNode(sourceCard).assertIsFocused()
        remote(KeyEvent.KEYCODE_DPAD_CENTER)
        compose.onNodeWithText("Back").assertIsFocused()
        compose.runOnIdle {
            assertEquals(title, detail)
            // Leave an exact copy on the other shelf and move the source copy offscreen.
            val fillers = (1..12).map { other.copy(id = "card-$it") }
            rows = listOf(source.copy(items = fillers + refreshed + other), first)
        }

        remote(KeyEvent.KEYCODE_BACK)
        compose.onNode(sourceCard).assertIsFocused()
        remote(KeyEvent.KEYCODE_DPAD_CENTER)
        compose.onNodeWithText("Back").assertIsFocused()
        compose.runOnIdle { assertEquals(refreshed, detail) }
    }
}
