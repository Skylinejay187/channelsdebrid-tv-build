package com.debridchannels.tv

import java.io.Closeable
import java.io.DataOutputStream
import java.io.IOException
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.concurrent.thread

/** Two loopback sources. The first sends MP4 container padding but never a video sample. */
internal class MovieFixtureServer(private val movie: ByteArray) : Closeable {
    data class Request(val path: String, val headers: Map<String, String>, val timeNs: Long)

    private val listener = ServerSocket(0, 8, InetAddress.getByName("127.0.0.1"))
    val base = "http://127.0.0.1:" + listener.localPort
    val requests = ConcurrentLinkedQueue<Request>()
    private val clients = CopyOnWriteArrayList<Socket>()
    private val acceptor = thread(isDaemon = true) {
        while (!listener.isClosed) {
            val socket = try { listener.accept() } catch (_: IOException) { break }
            clients.add(socket)
            thread(isDaemon = true) {
                try { socket.use(::serve) } catch (_: IOException) {
                    // Media3 closes its connection when switching sources.
                } finally { clients.remove(socket) }
            }
        }
    }

    private fun serve(socket: Socket) {
        val reader = socket.getInputStream().bufferedReader(Charsets.US_ASCII)
        val path = reader.readLine()?.split(' ')?.getOrNull(1) ?: return
        val headers = mutableMapOf<String, String>()
        while (true) {
            val line = reader.readLine()?.takeIf { it.isNotEmpty() } ?: break
            headers[line.substringBefore(':').lowercase()] = line.substringAfter(':').trim()
        }
        requests.add(Request(path, headers, System.nanoTime()))
        val output = DataOutputStream(socket.getOutputStream())
        when (path) {
            "/stall.mp4" -> {
                output.writeBytes("HTTP/1.1 200 OK\r\nContent-Type: video/mp4\r\nConnection: close\r\n\r\n")
                val ftypSize = java.nio.ByteBuffer.wrap(movie).int
                output.write(movie, 0, ftypSize)
                output.writeInt(65_536)
                output.writeBytes("free")
                while (!socket.isClosed) {
                    output.write(ByteArray(64))
                    output.flush()
                    Thread.sleep(250)
                }
            }
            "/play.mp4" -> {
                val range = headers["range"]
                val offset = range?.removePrefix("bytes=")?.substringBefore('-')?.toIntOrNull() ?: 0
                if (offset !in movie.indices) {
                    output.writeBytes("HTTP/1.1 416 Range Not Satisfiable\r\nConnection: close\r\n\r\n")
                    return
                }
                if (range == null) output.writeBytes("HTTP/1.1 200 OK\r\n") else {
                    output.writeBytes("HTTP/1.1 206 Partial Content\r\n")
                    output.writeBytes("Content-Range: bytes $offset-${movie.lastIndex}/${movie.size}\r\n")
                }
                val length = movie.size - offset
                output.writeBytes("Content-Type: video/mp4\r\nContent-Length: $length\r\nConnection: close\r\n\r\n")
                output.write(movie, offset, length)
            }
            else -> output.writeBytes("HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n")
        }
    }

    override fun close() {
        listener.close()
        acceptor.join()
        clients.forEach { it.close() }
    }
}
