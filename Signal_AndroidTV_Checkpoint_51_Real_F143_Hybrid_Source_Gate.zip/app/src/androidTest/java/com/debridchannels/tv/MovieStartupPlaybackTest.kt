package com.debridchannels.tv

import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.annotation.OptIn
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.assertIsFocused
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.assertIsDisplayed
import com.debridchannels.core.data.display
import com.debridchannels.core.model.MediaItem
import com.debridchannels.tv.ui.screens.DetailScreen
import androidx.lifecycle.Lifecycle
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.test.platform.app.InstrumentationRegistry
import com.debridchannels.core.data.MovieSourceOption
import com.debridchannels.core.data.MovieStartupRecovery
import com.debridchannels.core.designsystem.DebridChannelsTheme
import com.debridchannels.core.model.MediaType
import com.debridchannels.core.model.PlaybackRequest
import com.debridchannels.tv.playback.MovieResumeStore
import com.debridchannels.core.data.MovieResumePolicy
import androidx.compose.runtime.mutableStateOf
import com.debridchannels.tv.playback.MoviePlayer
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import java.util.concurrent.atomic.AtomicBoolean

@OptIn(UnstableApi::class)
class MovieStartupPlaybackTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()

    private fun playerView(view: View): PlayerView? = when (view) {
        is PlayerView -> view
        is ViewGroup -> (0 until view.childCount).firstNotNullOfOrNull { playerView(view.getChildAt(it)) }
        else -> null
    }

    private fun withMovieFixture(test: (MovieFixtureServer, MovieStartupRecovery) -> Unit) {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val clip = instrumentation.context.assets.open("movie-recovery.mp4").use { it.readBytes() }
        MovieFixtureServer(clip).use { server ->
            fun option(name: String) = MovieSourceOption("Cached 1080p", PlaybackRequest(
                "test-movie", MediaType.MOVIE, "Movie", "${server.base}/$name.mp4",
                mapOf("X-Source" to name), resumePositionMs = if (name == "stall") 8000L else 0L), "Fixture", null)
            val selected = option("stall")
            val alternate = option("play")
            val session = MovieStartupRecovery(selected.playback, listOf(selected, alternate))
            test(server, session)
        }
    }

    @Test fun trailerReturnsToItsActionWithoutChangingMovieResume() {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val clip = instrumentation.context.assets.open("movie-recovery.mp4").use { it.readBytes() }
        MovieFixtureServer(clip).use { server ->
            val id = "trailer-test-" + java.util.UUID.randomUUID()
            val item = MediaItem(id, "Trailer fixture", MediaType.MOVIE, 2026, "", "", "poster_01", "live_01",
                previewUrl = "${server.base}/play.mp4")
            val store = MovieResumeStore(instrumentation.targetContext, item)
            store.applyUpdate(id, 10_000L, MovieResumePolicy.Update.SAVE, 90_000L)
            try {
                compose.setContent { DebridChannelsTheme { DetailScreen(item, onBack = {}) } }
                val action = compose.onNodeWithText("Watch Trailer")
                for (finish in listOf(false, true)) {
                    action.performClick()
                    compose.waitUntil(timeoutMillis = 8000) {
                        compose.runOnUiThread {
                            val player = playerView(compose.activity.window.decorView)?.player as? ExoPlayer
                            (player?.videoDecoderCounters?.renderedOutputBufferCount ?: 0) > 0
                        }
                    }
                    if (finish) compose.runOnUiThread {
                        val player = requireNotNull(playerView(compose.activity.window.decorView)?.player)
                        player.seekTo((player.duration - 500).coerceAtLeast(0L))
                    } else instrumentation.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK)
                    compose.waitUntil(timeoutMillis = 8000) {
                        compose.runOnUiThread { playerView(compose.activity.window.decorView) == null }
                    }
                    action.assertIsFocused()
                    assertEquals(10_000L, store.read(id))
                }
            } finally { store.applyUpdate(id, 0L, MovieResumePolicy.Update.CLEAR) }
        }
    }

    @Test fun reopeningMovieRestoresSavedPositionAndEofClearsIt() {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val context = instrumentation.targetContext
        val clip = instrumentation.context.assets.open("movie-recovery.mp4").use { it.readBytes() }
        MovieFixtureServer(clip).use { server ->
            val id = "resume-test-" + java.util.UUID.randomUUID()
            val item = MediaItem(id, "Resume test", MediaType.MOVIE, 2026, "", "", "poster_01", "live_01")
            val store = MovieResumeStore(context, item)
            val request = PlaybackRequest(id, MediaType.MOVIE, "Resume test", "${server.base}/play.mp4")
            val active = mutableStateOf<MovieStartupRecovery?>(MovieStartupRecovery(
                request.copy(resumePositionMs = 10_000L), emptyList()))
            try {
                compose.setContent {
                    DebridChannelsTheme {
                        val session = active.value
                        if (session == null) DetailScreen(item, onBack = {})
                        else MoviePlayer(session, store) { active.value = null }
                    }
                }
                fun hasFrame() = compose.runOnUiThread {
                    val player = playerView(compose.activity.window.decorView)?.player as? ExoPlayer
                    (player?.videoDecoderCounters?.renderedOutputBufferCount ?: 0) > 0
                }
                compose.waitUntil(timeoutMillis = 8000) { hasFrame() }
                instrumentation.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK)
                compose.waitUntil { store.read(id) >= 10_000L && active.value == null }
                val display = requireNotNull(store.snapshot(id).display())
                val resumeLabel = "Resume at ${display.timestamp}, ${display.remaining} remaining"
                compose.onNodeWithContentDescription(resumeLabel).assertIsDisplayed()
                val reopened = MovieStartupRecovery(request, emptyList())
                MovieResumeStore(context).restore(reopened)
                assertEquals(store.read(id), reopened.current.resumePositionMs)
                compose.runOnUiThread { active.value = reopened }
                compose.waitUntil(timeoutMillis = 8000) { hasFrame() }
                compose.waitUntil(timeoutMillis = 18_000) { store.read(id) == 0L }
                instrumentation.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK)
                compose.waitUntil { active.value == null }
                assertEquals(0L, store.read(id))
                compose.onNodeWithContentDescription("Resume at ", substring = true).assertDoesNotExist()
            } finally {
                compose.runOnUiThread { active.value = null }
                compose.waitForIdle()
                store.applyUpdate(id, 0L, MovieResumePolicy.Update.CLEAR)
            }
        }
    }

    @Test fun pausedStartupSurvivesActivityStopAndOnlyRecoversAfterPlay() {
        withMovieFixture { server, session ->
            compose.setContent { DebridChannelsTheme { MoviePlayer(session) {} } }
            compose.waitUntil(timeoutMillis = 8000) { server.requests.any { it.path == "/stall.mp4" } }
            val original = compose.runOnUiThread {
                requireNotNull(playerView(compose.activity.window.decorView)?.player).also { it.pause() }
            }
            val scenario = compose.activityRule.scenario
            scenario.moveToState(Lifecycle.State.CREATED)
            // Use real time because Handler deadlines run independently of the Compose clock.
            SystemClock.sleep(22_000)
            assertEquals(listOf("/stall.mp4"), server.requests.map { it.path })
            scenario.moveToState(Lifecycle.State.RESUMED)
            compose.waitUntil(timeoutMillis = 8000) { server.requests.count { it.path == "/stall.mp4" } >= 2 }
            SystemClock.sleep(22_000)
            assertEquals(listOf("/stall.mp4", "/stall.mp4"), server.requests.map { it.path })
            compose.runOnUiThread {
                val restored = requireNotNull(playerView(compose.activity.window.decorView)?.player)
                assertNotSame(original, restored)
                assertFalse(restored.playWhenReady)
                assertEquals(8000L, session.current.resumePositionMs)
                restored.play()
            }
            compose.waitUntil(timeoutMillis = 35_000) { server.requests.any { it.path == "/play.mp4" } }
            assertEquals("play", server.requests.first { it.path == "/play.mp4" }.headers["x-source"])
            compose.runOnUiThread { assertTrue(session.current.resumePositionMs >= 8000L) }
        }
    }

    @Test fun stalledMovieSwitchesOnceAndRendersAlternateAtResumePosition() {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        withMovieFixture { server, session ->
            val back = AtomicBoolean()
            compose.setContent { DebridChannelsTheme { MoviePlayer(session) { back.set(true) } } }
            compose.waitUntil(timeoutMillis = 40_000) { server.requests.any { it.path == "/play.mp4" } }
            val first = server.requests.first { it.path == "/stall.mp4" }
            val replacement = server.requests.first { it.path == "/play.mp4" }
            val elapsedMs = (replacement.timeNs - first.timeNs) / 1_000_000
            assertTrue("Switch after ${elapsedMs}ms", elapsedMs in 18_000L..32_000L)
            assertEquals(1, server.requests.count { it.path == "/stall.mp4" })
            assertEquals("stall", first.headers["x-source"])
            assertEquals("play", replacement.headers["x-source"])
            compose.waitUntil(timeoutMillis = 7_000) {
                compose.runOnUiThread {
                    val player = playerView(compose.activity.window.decorView)?.player as? ExoPlayer
                    player != null && (player.videoDecoderCounters?.renderedOutputBufferCount ?: 0) > 0 &&
                        player.currentPosition >= 8000
                }
            }
            instrumentation.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK)
            compose.waitUntil { back.get() }
        }
    }
}
