package com.debridchannels.tv

import android.view.View
import android.view.ViewGroup
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.media3.ui.PlayerView
import org.junit.Rule
import org.junit.Test

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class SignalLaunchTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()

    private fun playerView(view: View): PlayerView? = when (view) {
        is PlayerView -> view
        is ViewGroup -> (0 until view.childCount).firstNotNullOfOrNull { playerView(view.getChildAt(it)) }
        else -> null
    }

    @Test fun launchToLocalPlaybackThroughLiveTab() {
        compose.onNodeWithContentDescription("Signal").assertExists()
        compose.onNodeWithText("Minute to Win It").assertExists()
        compose.onNodeWithText("Movies").performClick()
        compose.activityRule.scenario.onActivity { it.onBackPressedDispatcher.onBackPressed() }
        compose.onNodeWithText("Minute to Win It").performClick()
        compose.onNodeWithText("Test picture & sound").performClick()
        compose.waitUntil(timeoutMillis = 30_000) {
            compose.runOnUiThread {
                val player = playerView(compose.activity.window.decorView)?.player
                player != null && player.isPlaying && player.currentPosition > 250 && player.videoSize.width > 0
            }
        }
    }
}
