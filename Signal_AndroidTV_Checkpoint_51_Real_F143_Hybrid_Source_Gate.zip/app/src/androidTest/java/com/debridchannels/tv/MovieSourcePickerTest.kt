package com.debridchannels.tv

import android.view.KeyEvent
import androidx.compose.ui.test.assertIsFocused
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.test.platform.app.InstrumentationRegistry
import com.debridchannels.core.data.MovieSourceOption
import com.debridchannels.core.designsystem.DebridChannelsTheme
import com.debridchannels.core.model.MediaType
import com.debridchannels.core.model.PlaybackRequest
import com.debridchannels.tv.ui.screens.MovieSourcePicker
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

class MovieSourcePickerTest {
    @get:Rule val compose = createComposeRule()

    @Test fun backFromConfirmationRestoresSecondSourceAndPlayUsesIt() {
        val options = listOf("First", "Second").map { name ->
            MovieSourceOption(name, PlaybackRequest("movie", MediaType.MOVIE, "Film",
                "https://fixture.example/$name", mapOf("Referer" to name)), "Fixture", null)
        }
        var launched: PlaybackRequest? = null
        compose.setContent {
            DebridChannelsTheme {
                MovieSourcePicker("Film", options, 0, onDismiss = { error("Unexpected dismissal") },
                    onPlay = { launched = options[it].playback })
            }
        }
        fun press(key: Int) {
            InstrumentationRegistry.getInstrumentation().sendKeyDownUpSync(key)
            compose.waitForIdle()
        }
        compose.onNodeWithText("First").assertIsFocused()
        press(KeyEvent.KEYCODE_DPAD_DOWN)
        compose.onNodeWithText("Second").assertIsFocused()
        press(KeyEvent.KEYCODE_DPAD_CENTER)
        compose.onNodeWithText("Play source").assertIsFocused()
        press(KeyEvent.KEYCODE_BACK)
        compose.onNodeWithText("Second").assertIsFocused()
        compose.runOnIdle { assertNull(launched) }
        press(KeyEvent.KEYCODE_DPAD_CENTER)
        press(KeyEvent.KEYCODE_DPAD_CENTER)
        compose.runOnIdle { assertEquals(options[1].playback, launched) }
    }
}
