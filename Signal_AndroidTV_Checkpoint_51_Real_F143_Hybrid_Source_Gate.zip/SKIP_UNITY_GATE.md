# Checkpoint 48 — Unity policy + Skip feasibility gate

**Slogan: Our app is Unity, not separate screens.**

## Included and verified locally
- Original Checkpoint 47 Android project preserved.
- Three original F143 Swift Unity files copied under `reference/tvos-unity/` for comparison.
- Pure Kotlin translation of `UnitySurfaceSystem.swift` role/runtime/back policies added under `core/model`.
- Kotlin JUnit test checks every AppTab against the original policy matrix.
- Separate manually triggered macOS Skip feasibility workflow added. It does **not** change existing Android APK workflow.

## Not yet verified
- No Skip transpilation of original Unity source has occurred.
- No macOS GitHub Actions workflow run or APK build was executed in this environment.
- No Compose UI, focus or 3D visuals were changed in this checkpoint.

## Next gate
Run `Skip Unity Feasibility (macOS)` in GitHub Actions and inspect `skip-unity-feasibility` diagnostics. If successful, create a Skip Lite **library** wrapper around a representative dependency-light Unity module, transpile it, and compare generated Kotlin with the checked-in policy. Do not treat the sample-app verification as proof of Unity conversion.

Skip docs: https://skip.dev/docs/skip-cli/ ; https://skip.dev/docs/gettingstarted/
