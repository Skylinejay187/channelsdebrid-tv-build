# CP51: Real F143 Skip Lite + Fuse conversion

**Input:** Exact Swift source bytes originally embedded from Signal_F143_1252_Main_Catalog_Masking.zip. The existing CP50 Kotlin Android application is retained. This is a real-source feasibility build, not the completed Signal UI conversion.

## Source modules used
- Lite: `UnitySurfaceSystem.swift` plus exact `AppTab` enum extracted from `CatalogStore.swift` (not rewritten Kotlin). Transpilation target: Kotlin from the original Swift logic.
- Fuse: `SignalUpNextDismissalState.swift` (actual original Swift). Native compilation target: Android Swift/bridge.

## Workflow
- `.github/workflows/signal-real-f143-hybrid.yml` in this archive can be installed on the repository *root* to run in GitHub Actions. A workflow file **inside the uploaded ZIP does not register with GitHub Actions**.
- `tools/real_f143_hybrid_gate.py`: extracts exact Swift source into Skip-generated Lite and Fuse projects; checks embedded Apple source manifest; records source hashes.
- The CI job runs **both** `skip verify` passes and uploads generated sources / errors, whether successful or not.

## Not yet done
- Full app is not converted. CatalogStore is 750 KB and depends on Apple-only APIs; real SwiftUI rendering, 3D Cover Flow, tvOS focus, AVFoundation, third party modules, and application-level Android integration require source-driven adaptations.
- The existing Android APK does **not** automatically gain the Fuse module, and no new APK is claimed from this gate.
- Do not delete the working `build-apk.yml` workflow until a true mixed-module APK is proven.

## Acceptance criteria for expanding beyond the gate
1. Source manifest matches.
2. Lite emits real `UnitySurfaceSystem` Kotlin artifacts and behavior tests pass.
3. Fuse compiles actual `SignalUpNextDismissalState` Swift for Android.
4. Both modules are callable from one mixed application.
5. Actual F143 SwiftUI catalog components render with matching Unity layout and navigation on Android TV.
