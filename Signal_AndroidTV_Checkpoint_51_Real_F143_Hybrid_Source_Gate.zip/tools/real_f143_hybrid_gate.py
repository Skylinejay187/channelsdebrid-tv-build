#!/usr/bin/env python3
"""Stages real F143 Swift files into Skip's generated model projects (no substitutes)."""
import argparse
import hashlib
import json
import pathlib
import sys

p = argparse.ArgumentParser()
p.add_argument('--checkpoint-root', type=pathlib.Path, required=True)
p.add_argument('--lite-project', type=pathlib.Path, required=True)
p.add_argument('--fuse-project', type=pathlib.Path, required=True)
p.add_argument('--diagnostics', type=pathlib.Path, required=True)
a = p.parse_args()
a.diagnostics.mkdir(parents=True, exist_ok=True)
manifest = json.loads((a.checkpoint_root/'reference/apple-original-manifest.json').read_text())
files = manifest['files']
for rel, digest in files.items():
    path=a.checkpoint_root/rel
    if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
        sys.exit(f'F143 Swift source hash mismatch or missing: {rel}')
if len(files)<200: sys.exit('Incomplete F143 Swift source')
original = a.checkpoint_root/'reference/apple-original/Sources'

def destination(project, module):
    d=project/'Sources'/module
    if not d.is_dir(): sys.exit(f'Skip generated layout not found: {d}')
    return d

lite=destination(a.lite_project,'SignalUnityLite')
fuse=destination(a.fuse_project,'SignalPlayerFuse')
(lite/'UnitySurfaceSystem.swift').write_bytes((original/'UnitySurfaceSystem.swift').read_bytes())
s=(original/'CatalogStore.swift').read_text()
start=s.index('enum AppTab:')
brace=s.index('{',start)
depth=0
end=None
for i in range(brace,len(s)):
    if s[i]=='{': depth+=1
    elif s[i]=='}':
        depth-=1
        if depth==0:
            end=i+1
            break
if end is None: sys.exit('Could not extract original AppTab enum')
(lite/'AppTab.swift').write_text('import Foundation\n'+s[start:end]+'\n')
(fuse/'SignalUpNextDismissalState.swift').write_bytes((original/'SignalUpNextDismissalState.swift').read_bytes())
report={
    'verified_original_swift_files':len(files),
    'apple_zip_sha256_recorded':manifest.get('apple_master_sha256'),
    'skip_lite_original_sources':[str(lite/'UnitySurfaceSystem.swift'),str(lite/'AppTab.swift')],
    'skip_fuse_original_sources':[str(fuse/'SignalUpNextDismissalState.swift')],
    'note':'Actual original Swift source; success requires external skip verify and output inspection.'
}
(a.diagnostics/'source-evidence.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
