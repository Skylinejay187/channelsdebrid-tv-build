# Signal for Android TV

Checkpoint 47 ports the F143 build 1252 tvOS reference to Kotlin and Media3. Settings shows the installed version, 1.0.1252-cp47-debug.

## Build and install

Extract the ZIP at the repository root, including .github/workflows. Push to main or master, or manually run **Build Signal Android TV** in Actions. Download **Signal-AndroidTV-debug-APK** from the run, extract app-debug.apk, and sideload it on Android TV. The workflow verifies the debug signature before uploading. Select the TV emulator option on a manual run for instrumentation results. A different debug signing certificate prevents an in-place update over an earlier installation.

## Test on the TV

- Signal starts on the four-column Live TV dashboard. Sample program cards provide the first-launch layout until you import channels. Movies, Home and TV Shows overlay the dashboard. Back returns to Live TV. Home includes the 24-title starter catalog. Movies and TV Shows also use this catalog until the saved or online official catalog is available. Poster downloads need a network connection.
- Open Search and type a title or imported channel name. Select a result to open details or play the channel. Back returns to the query.
- Open Settings → Live TV → Channel setup and choose **Test picture & sound** to loop the bundled 12-second H.264/AAC clip. Back returns to browsing.
- In Channel setup, import an extended M3U file using the system picker, or enter one direct HTTPS stream and choose **Save stream**. Each successful save replaces the lineup. Select a channel to open Media3. Sports shows stations whose group or name matches a sports keyword. EPG data, Xtream, DRM and per-stream authentication headers are pending.
- In Settings → Catalog layout, select **3D Cover Flow** and return to Movies. Move focus along a shelf to see the selected landscape card and angled poster neighbors.
- Configure a movie stream manifest under Settings → Source Intelligence to test provider-backed movies. A starter catalog title supplies metadata, not a movie stream.

See PORT_CHECKPOINT.md and docs/F143_SOURCE_COVERAGE.csv for verification and outstanding paths.
