import Foundation
import Network
import Security

struct SignalNNTPSettings: Codable, Equatable {
    var host = ""
    var port = "563"
    var username = ""
    var password = ""

    private static let query: [String: String] = [
        kSecClass as String: kSecClassGenericPassword as String,
        kSecAttrService as String: "Signal.NativeUsenet",
        kSecAttrAccount as String: "news-server"
    ]

    static func read() -> Self {
        var query: [String: Any] = Self.query
        query[kSecReturnData as String] = true
        var item: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess,
              let data = item as? Data, let settings = try? JSONDecoder().decode(Self.self, from: data) else { return Self() }
        return settings
    }

    func save() -> Bool {
        guard let data = try? JSONEncoder().encode(self) else { return false }
        let query = Self.query as CFDictionary
        let status = SecItemUpdate(query, [kSecValueData as String: data] as CFDictionary)
        if status == errSecSuccess { return true }
        guard status == errSecItemNotFound else { return false }
        var entry: [String: Any] = Self.query
        entry[kSecValueData as String] = data
        entry[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        return SecItemAdd(entry as CFDictionary, nil) == errSecSuccess
    }

    var configured: Bool { !host.isEmpty || !username.isEmpty || !password.isEmpty }

    func endpoint() throws -> (NWEndpoint.Host, NWEndpoint.Port) {
        let server = host.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !server.isEmpty,
              server.utf8.allSatisfy({ (48...57).contains($0) || (65...90).contains($0) || (97...122).contains($0) || $0 == 46 || $0 == 45 }),
              let value = UInt16(port.trimmingCharacters(in: .whitespacesAndNewlines)),
              value > 0, let endpointPort = NWEndpoint.Port(rawValue: value),
              !username.isEmpty, !password.isEmpty,
              !username.utf8.contains(where: { $0 < 32 || $0 == 127 }),
              !password.utf8.contains(where: { $0 < 32 || $0 == 127 }) else {
            throw SignalNativeUsenetError.configuration
        }
        return (NWEndpoint.Host(server), endpointPort)
    }
}

enum SignalNativeUsenetError: LocalizedError {
    case configuration, login, unavailable, archived, invalid, network

    var errorDescription: String? {
        switch self {
        case .configuration: return "Enter the news server’s TLS host, port, username, and password in Streaming Catalogs."
        case .login: return "The Usenet news server rejected the login. Check the NNTP username and password."
        case .unavailable: return "An article for this release is unavailable on your news server. Try another release."
        case .archived: return "Native streaming needs a directly posted video. This release requires unpacking or has no identifiable video file."
        case .invalid: return "The Usenet release has invalid or incomplete article data."
        case .network: return "The Usenet connection timed out or closed. Check the TLS server details and try again."
        }
    }
}

/// Parses only standalone media files. Archives and parity recovery require a separate reader.
final class SignalUsenetNZB: NSObject, XMLParserDelegate {
    struct Video {
        let suffix: String
        let articles: [String]
    }

    private var videos: [(Int64, Video)] = []
    private var suffix: String?
    private var size: Int64 = 0
    private var segments: [(Int, String)] = []
    private var number: Int?
    private var text = ""
    private var sawNZB = false

    static func video(in data: Data) throws -> Video {
        let reader = SignalUsenetNZB()
        let parser = XMLParser(data: data)
        parser.shouldResolveExternalEntities = false
        parser.delegate = reader
        guard parser.parse(), reader.sawNZB else { throw SignalNativeUsenetError.invalid }
        guard let video = reader.videos.max(by: { $0.0 < $1.0 })?.1 else { throw SignalNativeUsenetError.archived }
        return video
    }

    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?,
                qualifiedName: String?, attributes: [String: String]) {
        switch elementName {
        case "nzb": sawNZB = true
        case "file":
            let subject = (attributes["subject"] ?? "").lowercased()
            let videoPattern = #"\.(mkv|mp4|m4v|m2ts|ts|avi|mov|webm)(?=["'\s]|$)"#
            let archivePattern = #"\.(rar|r[0-9]{2}|7z|zip|par2|nfo)(?=["'\s]|$)"#
            suffix = nil
            if subject.range(of: archivePattern, options: .regularExpression) == nil,
               subject.range(of: #"(?i)(?:^|[ ._/-])(?:sample|trailer|proof)(?:[ ._/-]|$)"#, options: .regularExpression) == nil,
               let match = subject.range(of: videoPattern, options: .regularExpression) {
                suffix = String(subject[match].dropFirst())
            }
            size = 0
            segments.removeAll(keepingCapacity: true)
        case "segment":
            guard suffix != nil else { return }
            number = Int(attributes["number"] ?? "")
            text = ""
            let bytes = min(max(Int64(attributes["bytes"] ?? "") ?? 0, 0), 32 * 1024 * 1024)
            size += bytes
        default: break
        }
    }

    func parser(_ parser: XMLParser, foundCharacters string: String) {
        if number != nil && text.utf8.count <= 1000 { text += string }
    }

    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName: String?) {
        if elementName == "segment", let number {
            self.number = nil
            let id = text.trimmingCharacters(in: .whitespacesAndNewlines)
            guard id.utf8.count <= 1000, id.contains("@"),
                  id.utf8.allSatisfy({ (33...126).contains($0) && $0 != 60 && $0 != 62 }) else { return }
            segments.append((number, id))
        }
        if elementName == "file", let suffix {
            let ordered = segments.sorted { $0.0 < $1.0 }
            if !ordered.isEmpty, ordered.enumerated().allSatisfy({ $0.offset + 1 == $0.element.0 }) {
                videos.append((size, Video(suffix: suffix, articles: ordered.map { $0.1 })))
            }
            self.suffix = nil
        }
    }
}

struct SignalUsenetArticle {
    let total: Int64
    let start: Int64
    let bytes: Data
    var end: Int64 { start + Int64(bytes.count) }

    static func decode(_ lines: [Data]) throws -> Self {
        func header(_ line: Data) -> [Substring] {
            String(decoding: line, as: UTF8.self).split(separator: " ")
        }
        func value(_ key: String, in fields: [Substring]) -> Int64? {
            let prefix = key + "="
            return fields.first { $0.hasPrefix(prefix) }.flatMap { Int64($0.dropFirst(prefix.count)) }
        }

        guard let first = lines.firstIndex(where: { $0.starts(with: "=ybegin ".utf8) }),
              let last = lines.lastIndex(where: { $0.starts(with: "=yend ".utf8) }),
              first < last, let total = value("size", in: header(lines[first])), total > 0,
              let declaredSize = value("size", in: header(lines[last])), declaredSize > 0,
              declaredSize <= 8 * 1024 * 1024 else { throw SignalNativeUsenetError.invalid }
        var begin = Int64(1)
        var finish = total
        var firstPayload = first + 1
        if lines[firstPayload].starts(with: "=ypart ".utf8) {
            let fields = header(lines[firstPayload])
            guard let lower = value("begin", in: fields), let upper = value("end", in: fields) else {
                throw SignalNativeUsenetError.invalid
            }
            begin = lower
            finish = upper
            firstPayload += 1
        }
        guard begin > 0, finish >= begin, finish <= total, finish - begin + 1 == declaredSize else {
            throw SignalNativeUsenetError.invalid
        }
        var decoded = Data()
        decoded.reserveCapacity(Int(declaredSize))
        for line in lines[firstPayload..<last] {
            var escaped = false
            for byte in line {
                if escaped {
                    decoded.append(byte &- 64 &- 42)
                    escaped = false
                } else if byte == 61 {
                    escaped = true
                } else {
                    decoded.append(byte &- 42)
                }
            }
            guard !escaped, decoded.count <= declaredSize else { throw SignalNativeUsenetError.invalid }
        }
        guard decoded.count == declaredSize else { throw SignalNativeUsenetError.invalid }
        let footer = header(lines[last])
        let checksum = footer.first { $0.hasPrefix("pcrc32=") || (begin == 1 && finish == total && $0.hasPrefix("crc32=")) }
        if let checksum {
            guard let expected = checksum.split(separator: "=").last.flatMap({ UInt32($0, radix: 16) }),
                  crc32(decoded) == expected else { throw SignalNativeUsenetError.invalid }
        }
        return Self(total: total, start: begin - 1, bytes: decoded)
    }

    private static let crcTable: [UInt32] = (0..<256).map { index in
        var entry = UInt32(index)
        for _ in 0..<8 { entry = (entry >> 1) ^ ((entry & 1) == 0 ? 0 : 0xedb88320) }
        return entry
    }

    private static func crc32(_ bytes: Data) -> UInt32 {
        var crc = UInt32.max
        for byte in bytes { crc = (crc >> 8) ^ crcTable[Int((crc ^ UInt32(byte)) & 255)] }
        return ~crc
    }
}

private final class SignalUsenetSocket {
    let connection: NWConnection
    private static let queue = DispatchQueue(label: "signal.usenet.socket", qos: .userInitiated)
    private var buffer = Data()
    private var consumed = 0

    init(_ connection: NWConnection) { self.connection = connection }
    deinit { connection.cancel() }
    func start() { connection.start(queue: Self.queue) }

    func send(_ data: Data) async throws {
        let _: Bool = try await operation { completion in
            self.connection.send(content: data, completion: .contentProcessed({ error in
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.success(true))
                }
            }))
        }
    }

    private func read() async throws -> Data {
        try await operation { completion in
            self.connection.receive(minimumIncompleteLength: 1, maximumLength: 65_536) { data, _, _, error in
                if let data, !data.isEmpty { completion(.success(data)) }
                else { completion(.failure(error.map { $0 as Error } ?? SignalNativeUsenetError.network)) }
            }
        }
    }

    private func operation<T>(_ start: (@escaping (Result<T, Error>) -> Void) -> Void) async throws -> T {
        let connection = connection
        return try await withTaskCancellationHandler {
            try Task.checkCancellation()
            return try await withCheckedThrowingContinuation { continuation in
                let timeout = DispatchWorkItem { connection.cancel() }
                Self.queue.asyncAfter(deadline: .now() + 12, execute: timeout)
                start { result in
                    timeout.cancel()
                    switch result {
                    case .success(let value): continuation.resume(returning: value)
                    case .failure: continuation.resume(throwing: SignalNativeUsenetError.network)
                    }
                }
            }
        } onCancel: { connection.cancel() }
    }

    func line() async throws -> Data {
        let crlf = Data([13, 10])
        while true {
            let start = buffer.startIndex + consumed
            if let separator = buffer.range(of: crlf, in: start..<buffer.endIndex) {
                let line = buffer.subdata(in: start..<separator.lowerBound)
                consumed = separator.upperBound - buffer.startIndex
                return line
            }
            if consumed > 0 {
                buffer = buffer.subdata(in: start..<buffer.endIndex)
                consumed = 0
            }
            guard buffer.count < 65_536 else { throw SignalNativeUsenetError.invalid }
            let data = try await read()
            buffer.append(data)
        }
    }
}

private final class SignalNNTPReader {
    private let socket: SignalUsenetSocket

    init(settings: SignalNNTPSettings) throws {
        let (host, port) = try settings.endpoint()
        let tls = NWProtocolTLS.Options()
        let serverName = settings.host.trimmingCharacters(in: .whitespacesAndNewlines)
        sec_protocol_options_set_tls_server_name(tls.securityProtocolOptions, serverName)
        let parameters = NWParameters(tls: tls, tcp: NWProtocolTCP.Options())
        socket = SignalUsenetSocket(NWConnection(host: host, port: port, using: parameters))
        socket.start()
    }

    func login(_ settings: SignalNNTPSettings) async throws {
        let greeting = try await response()
        guard greeting == 200 || greeting == 201 else { throw SignalNativeUsenetError.network }
        try await command("AUTHINFO USER \(settings.username)")
        let reply = try await response()
        if reply == 281 { return }
        guard reply == 381 else { throw SignalNativeUsenetError.login }
        try await command("AUTHINFO PASS \(settings.password)")
        guard try await response() == 281 else { throw SignalNativeUsenetError.login }
    }

    func article(_ id: String) async throws -> SignalUsenetArticle {
        try await command("BODY <\(id)>")
        guard try await response() == 222 else { throw SignalNativeUsenetError.unavailable }
        var lines: [Data] = []
        var received = 0
        while true {
            let line = try await socket.line()
            if line == Data([46]) { break }
            received += line.count + 2
            guard received <= 12 * 1024 * 1024, lines.count < 160_000 else { throw SignalNativeUsenetError.invalid }
            lines.append(line.starts(with: [46, 46]) ? Data(line.dropFirst()) : line)
        }
        return try SignalUsenetArticle.decode(lines)
    }

    private func command(_ text: String) async throws { try await socket.send(Data((text + "\r\n").utf8)) }
    private func response() async throws -> Int {
        let line = try await socket.line()
        return Int(String(decoding: line.prefix(3), as: UTF8.self)) ?? 0
    }
}

/// A range-capable HTTP endpoint bound only to the Apple TV's loopback address.
/// Aether retains ownership of demuxing, playback and VOD buffering.
actor SignalNativeUsenet {
    static let shared = SignalNativeUsenet()
    private var sessions: [String: Session] = [:]

    nonisolated static func isLocalStream(_ url: URL?) -> Bool {
        guard let url, url.scheme == "http", url.host == "127.0.0.1", url.port != nil,
              url.user == nil, url.password == nil, url.query == nil else { return false }
        let parts = url.pathComponents
        return parts.count == 4 && parts[1] == "signal-usenet" && UUID(uuidString: parts[2]) != nil
    }

    func open(nzb: Data, settings: SignalNNTPSettings) async throws -> URL {
        let video = try SignalUsenetNZB.video(in: nzb)
        let reader = try SignalNNTPReader(settings: settings)
        try await reader.login(settings)
        let first = try await reader.article(video.articles[0])
        guard first.start == 0, (first.end == first.total) == (video.articles.count == 1) else {
            throw SignalNativeUsenetError.invalid
        }
        try Task.checkCancellation()
        let next = try Session(video: video, first: first, settings: settings, reader: reader)
        let url = try await next.start()
        do { try Task.checkCancellation() }
        catch { await next.stop(); throw error }
        sessions[url.path] = next
        Task { [weak self, weak next] in
            while !Task.isCancelled {
                try? await Task.sleep(for: .seconds(300))
                guard let next, let self else { return }
                if await next.isIdle() { await self.close(url: url); return }
            }
        }
        return url
    }

    func retainForPlayback(url: URL) async {
        await sessions[url.path]?.retainForPlayback()
    }

    func close(url: URL) async {
        guard let session = sessions.removeValue(forKey: url.path) else { return }
        await session.stop()
    }

    static func test(_ settings: SignalNNTPSettings) async throws {
        let reader = try SignalNNTPReader(settings: settings)
        try await reader.login(settings)
    }

    private actor Session {
        nonisolated let path: String
        let video: SignalUsenetNZB.Video
        let first: SignalUsenetArticle
        let settings: SignalNNTPSettings
        let listener: NWListener
        private var peers: [UUID: Task<Void, Never>] = [:]
        private var sockets: [UUID: SignalUsenetSocket] = [:]
        private var closed = false
        private var playbackOwned = false
        private var startupReader: SignalNNTPReader?
        private var lastActivity = Date()

        init(video: SignalUsenetNZB.Video, first: SignalUsenetArticle, settings: SignalNNTPSettings, reader: SignalNNTPReader) throws {
            self.video = video
            self.first = first
            self.settings = settings
            startupReader = reader
            path = "/signal-usenet/\(UUID().uuidString)/video.\(video.suffix)"
            let parameters = NWParameters.tcp
            parameters.requiredLocalEndpoint = .hostPort(host: "127.0.0.1", port: .any)
            listener = try NWListener(using: parameters)
        }

        func start() async throws -> URL {
            let listener = listener
            return try await withTaskCancellationHandler {
                try await withCheckedThrowingContinuation { continuation in
                    let queue = DispatchQueue(label: "signal.usenet.listener")
                    let timeout = DispatchWorkItem { listener.cancel() }
                    queue.asyncAfter(deadline: .now() + 5, execute: timeout)
                    listener.newConnectionHandler = { [weak self] connection in
                        Task {
                            guard let self else { connection.cancel(); return }
                            await self.accept(connection)
                        }
                    }
                    listener.stateUpdateHandler = { [path] state in
                        switch state {
                        case .ready:
                            listener.stateUpdateHandler = nil
                            timeout.cancel()
                            guard let port = listener.port, let url = URL(string: "http://127.0.0.1:\(port.rawValue)\(path)") else {
                                listener.cancel()
                                continuation.resume(throwing: SignalNativeUsenetError.network)
                                return
                            }
                            continuation.resume(returning: url)
                        case .failed, .cancelled:
                            listener.stateUpdateHandler = nil
                            timeout.cancel()
                            listener.cancel()
                            continuation.resume(throwing: SignalNativeUsenetError.network)
                        default: break
                        }
                    }
                    listener.start(queue: queue)
                }
            } onCancel: { listener.cancel() }
        }

        func retainForPlayback() { playbackOwned = true }

        func isIdle() -> Bool {
            !playbackOwned && sockets.isEmpty && Date().timeIntervalSince(lastActivity) >= 300
        }

        func stop() {
            closed = true
            startupReader = nil
            listener.newConnectionHandler = nil
            listener.cancel()
            for task in peers.values { task.cancel() }
            for socket in sockets.values { socket.connection.cancel() }
            peers.removeAll()
            sockets.removeAll()
        }

        private func accept(_ connection: NWConnection) {
            guard !closed, peers.count < 6 else { connection.cancel(); return }
            let id = UUID()
            let socket = SignalUsenetSocket(connection)
            sockets[id] = socket
            socket.start()
            peers[id] = Task { [weak self] in
                guard let self else { return }
                await self.serve(socket)
                await self.finish(id)
            }
        }

        private func finish(_ id: UUID) {
            lastActivity = Date()
            peers[id] = nil
            sockets.removeValue(forKey: id)?.connection.cancel()
        }

        private func serve(_ socket: SignalUsenetSocket) async {
            do {
                let request = String(decoding: try await socket.line(), as: UTF8.self).split(separator: " ")
                guard request.count == 3, request[1] == path, request[0] == "GET" || request[0] == "HEAD" else {
                    try await socket.send(Data("HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".utf8))
                    return
                }
                var rangeHeader: String?
                var headerCount = 0
                while true {
                    let data = try await socket.line()
                    if data.isEmpty { break }
                    headerCount += 1
                    guard headerCount <= 64 else { throw SignalNativeUsenetError.invalid }
                    let line = String(decoding: data, as: UTF8.self)
                    if line.lowercased().hasPrefix("range:") {
                        rangeHeader = String(line.dropFirst(6)).trimmingCharacters(in: .whitespaces)
                    }
                }
                let total = first.total
                guard let range = SignalUsenetHTTPRange.parse(rangeHeader, size: total) else {
                    try await socket.send(Data("HTTP/1.1 416 Range Not Satisfiable\r\nContent-Range: bytes */\(total)\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".utf8))
                    return
                }
                let partial = rangeHeader != nil
                let type = ["mp4": "video/mp4", "m4v": "video/mp4", "mkv": "video/x-matroska", "ts": "video/mp2t"]
                let contentRange = partial ? "Content-Range: bytes \(range.lowerBound)-\(range.upperBound - 1)/\(total)\r\n" : ""
                let header = "HTTP/1.1 \(partial ? "206 Partial Content" : "200 OK")\r\nConnection: close\r\nAccept-Ranges: bytes\r\nContent-Type: \(type[video.suffix] ?? "application/octet-stream")\r\nContent-Length: \(range.upperBound - range.lowerBound)\r\n\(contentRange)\r\n"
                try await socket.send(Data(header.utf8))
                if request[0] == "HEAD" { return }
                try await stream(range, to: socket)
            } catch {
                // Aether may cancel probes and reopen at a new byte offset. Closing
                // a partial response lets the player retry without fabricating bytes.
                socket.connection.cancel()
            }
        }

        private func stream(_ range: Range<Int64>, to socket: SignalUsenetSocket) async throws {
            var offset = range.lowerBound
            var article = first
            var index = 0
            var reader: SignalNNTPReader?
            if offset == 0, range.upperBound > first.end {
                reader = startupReader
                startupReader = nil
            }
            if offset >= first.end {
                let active = try SignalNNTPReader(settings: settings)
                reader = active
                try await active.login(settings)
                (index, article) = try await locate(offset, reader: active)
            }
            while offset < range.upperBound {
                try Task.checkCancellation()
                guard article.total == first.total, (article.start..<article.end).contains(offset) else {
                    throw SignalNativeUsenetError.invalid
                }
                let end = min(article.end, range.upperBound)
                if end == range.upperBound {
                    try await socket.send(article.bytes.subdata(in: Int(offset - article.start)..<Int(end - article.start)))
                    return
                }
                if reader == nil {
                    // Send the prefetched first article before opening another NNTP session.
                    try await socket.send(article.bytes.subdata(in: Int(offset - article.start)..<Int(end - article.start)))
                    let active = try SignalNNTPReader(settings: settings)
                    reader = active
                    try await active.login(settings)
                    index += 1
                    article = try await active.article(video.articles[index])
                } else if let reader {
                    index += 1
                    guard index < video.articles.count else { throw SignalNativeUsenetError.invalid }
                    let nextID = video.articles[index]
                    async let following = reader.article(nextID)
                    try await socket.send(article.bytes.subdata(in: Int(offset - article.start)..<Int(end - article.start)))
                    article = try await following
                }
                guard article.start == end else { throw SignalNativeUsenetError.invalid }
                offset = end
            }
        }

        private func locate(_ offset: Int64, reader: SignalNNTPReader) async throws -> (Int, SignalUsenetArticle) {
            var low = 1
            var high = video.articles.count - 1
            guard high >= low else { throw SignalNativeUsenetError.invalid }
            var index = Int(min(Int64(high), max(Int64(low), offset / first.end)))
            while low <= high {
                let article = try await reader.article(video.articles[index])
                guard article.total == first.total else { throw SignalNativeUsenetError.invalid }
                if (article.start..<article.end).contains(offset) { return (index, article) }
                if offset < article.start { high = index - 1 } else { low = index + 1 }
                index = low + (high - low) / 2
            }
            throw SignalNativeUsenetError.invalid
        }
    }
}

enum SignalUsenetHTTPRange {
    static func parse(_ value: String?, size: Int64) -> Range<Int64>? {
        guard size > 0 else { return nil }
        guard let value else { return 0..<size }
        guard value.lowercased().hasPrefix("bytes=") else { return nil }
        let parts = value.dropFirst(6).split(separator: "-", omittingEmptySubsequences: false)
        guard parts.count == 2 else { return nil }
        if parts[0].isEmpty {
            guard let tail = Int64(parts[1]), tail > 0 else { return nil }
            return (size - min(tail, size))..<size
        }
        guard let start = Int64(parts[0]), start >= 0, start < size else { return nil }
        if parts[1].isEmpty { return start..<size }
        guard let last = Int64(parts[1]), last >= start else { return nil }
        return start..<(min(last, size - 1) + 1)
    }
}
