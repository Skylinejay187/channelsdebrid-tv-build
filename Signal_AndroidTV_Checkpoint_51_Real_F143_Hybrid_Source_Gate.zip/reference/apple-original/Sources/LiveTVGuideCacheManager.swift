import Foundation
import SQLite3


struct LiveTVPersistedGuideSnapshot: Sendable {
    let channels: [LiveTVLoadedChannel]
    let guide: [String: [LiveProgram]]
    let indexedGuideAvailable: Bool
}

// v783 Architecture Migration Step 9
// Centralizes Live TV lineup + guide cache persistence/refresh timing so the
// LiveTVSourceModel can keep owning provider loading and UI state only.
final class LiveTVGuideCacheManager {
    static let guideWindowSeconds = 6 * 60 * 60
    static let channelCacheKey = "liveTVLoadedChannelsV165"
    static let guideCacheKey = "liveTVGuideProgramsV191"
    static let lastRefreshKey = "liveTVLastRefreshV191"
    static let lastHealthyGuideKey = "liveTVLastHealthyGuideV322"
    static let channelCacheFileName = "liveTVLoadedChannelsV165.json"
    static let guideCacheFileName = "liveTVGuideProgramsV191.json"
    private static let guideIndexFileName = "liveTVGuideIndexV1.sqlite"

    // vBRDC119: Live TV can persist tens of thousands of channels/program rows. The old
    // implementation JSON-encoded and atomically wrote those snapshots synchronously from
    // LiveTVSourceModel's MainActor. That made an otherwise-complete guide refresh capable
    // of stealing several animation frames. One utility queue now owns all large-state IO,
    // while pending snapshots are coalesced so an Xtream batch burst writes the newest state
    // instead of building a backlog of obsolete encodes.
    private static let persistenceQueue = DispatchQueue(label: "com.debridchannels.livetv-guide-cache", qos: .utility)
    private static let guideReadQueue = DispatchQueue(label: "com.debridchannels.livetv-guide-read", qos: .userInitiated)
    private static let persistenceLock = NSLock()
    private static var pendingChannels: [LiveTVLoadedChannel]?
    private static var pendingGuide: (guide: [String: [LiveProgram]], maxRows: Int)?
    private static var channelWorkerScheduled = false
    private static var guideWorkerScheduled = false

    let refreshTTL: TimeInterval

    init(refreshTTL: TimeInterval = 3 * 60 * 60) {
        self.refreshTTL = refreshTTL
    }

    var shouldRefreshNow: Bool {
        let last = UserDefaults.standard.double(forKey: Self.lastRefreshKey)
        guard last > 0 else { return true }
        return Date().timeIntervalSince1970 - last >= refreshTTL
    }

    func markRefreshed(_ date: Date = Date()) {
        let stamp = date.timeIntervalSince1970
        UserDefaults.standard.set(stamp, forKey: Self.lastRefreshKey)
        UserDefaults.standard.set(stamp, forKey: Self.lastHealthyGuideKey)
    }

    var lastHealthyGuideDate: Date? {
        let stamp = UserDefaults.standard.double(forKey: Self.lastHealthyGuideKey)
        return stamp > 0 ? Date(timeIntervalSince1970: stamp) : nil
    }

    func resetRefreshClock() {
        UserDefaults.standard.removeObject(forKey: Self.lastRefreshKey)
    }

    func loadChannelSnapshots() -> [LiveTVLoadedChannel]? {
        // Atomic file replacement lets readers consume the last complete snapshot without
        // waiting behind an in-flight large guide encode on the utility writer queue.
        let data = Self.loadLargeStateDataUnlocked(defaultsKey: Self.channelCacheKey, fileName: Self.channelCacheFileName)
        guard let data,
              let saved = try? JSONDecoder().decode([LiveTVLoadedChannel].self, from: data),
              !saved.isEmpty else { return nil }
        return saved
    }

    func persistChannels(_ channels: [LiveTVLoadedChannel]) {
        var shouldSchedule = false
        Self.persistenceLock.lock()
        Self.pendingChannels = channels
        if !Self.channelWorkerScheduled {
            Self.channelWorkerScheduled = true
            shouldSchedule = true
        }
        Self.persistenceLock.unlock()

        guard shouldSchedule else { return }
        Self.persistenceQueue.async {
            Self.drainChannelWrites()
        }
    }

    func loadGuidePrograms() -> [String: [LiveProgram]]? {
        let data = Self.loadLargeStateDataUnlocked(defaultsKey: Self.guideCacheKey, fileName: Self.guideCacheFileName)
        guard let data,
              let cached = try? JSONDecoder().decode([String: [CachedLiveProgram]].self, from: data) else { return nil }
        let now = Date().timeIntervalSince1970
        let cutoff = now + Double(Self.guideWindowSeconds)
        let staleCutoff = now - 10 * 60
        var restored: [String: [LiveProgram]] = [:]
        for (key, programs) in cached {
            let visible = programs.filter {
                ($0.startTimestamp ?? -.infinity) < cutoff && ($0.endTimestamp ?? .infinity) >= staleCutoff
            }.map(\.liveProgram)
            if !visible.isEmpty { restored[key] = visible }
        }
        return restored.isEmpty ? nil : restored
    }


    /// vBRDC203: persisted EPG payloads can be very large. Read + JSON-decode both lineup
    /// and guide on the same utility lane that owns their writes so LiveTVSourceModel never
    /// blocks tvOS MainActor while restoring a multi-megabyte Gracenote/XMLTV snapshot.
    func loadPersistedStateAsync() async -> LiveTVPersistedGuideSnapshot? {
        await withCheckedContinuation { continuation in
            Self.persistenceQueue.async {
                guard let channels = self.loadChannelSnapshots(), !channels.isEmpty else {
                    continuation.resume(returning: nil)
                    return
                }
                if Self.readGuideIndex(keys: []) != nil {
                    continuation.resume(returning: LiveTVPersistedGuideSnapshot(
                        channels: channels, guide: [:], indexedGuideAvailable: true))
                    return
                }

                let legacy = self.loadGuidePrograms() ?? [:]
                if !legacy.isEmpty, Self.writeGuideIndex(legacy, maxRows: 96) {
                    Self.removeLegacyGuide()
                    continuation.resume(returning: LiveTVPersistedGuideSnapshot(
                        channels: channels, guide: [:], indexedGuideAvailable: true))
                } else {
                    continuation.resume(returning: LiveTVPersistedGuideSnapshot(
                        channels: channels, guide: legacy, indexedGuideAvailable: false))
                }
            }
        }
    }

    func loadGuideWindow(keys: [String]) async -> [String: [LiveProgram]]? {
        guard !keys.isEmpty else { return [:] }
        return await withCheckedContinuation { continuation in
            Self.guideReadQueue.async {
                continuation.resume(returning: Self.readGuideIndex(keys: keys))
            }
        }
    }

    func storeGuideSnapshot(_ guide: [String: [LiveProgram]], maxRows: Int) async -> Bool {
        guard !guide.isEmpty else { return false }
        return await withCheckedContinuation { continuation in
            Self.persistenceQueue.async {
                let stored = Self.writeGuideIndex(guide, maxRows: maxRows)
                if stored { Self.removeLegacyGuide() }
                continuation.resume(returning: stored)
            }
        }
    }

    func persistGuidePrograms(_ guide: [String: [LiveProgram]], maxRows: Int) {
        var shouldSchedule = false
        Self.persistenceLock.lock()
        if let pending = Self.pendingGuide {
            Self.pendingGuide = (pending.guide.merging(guide) { _, latest in latest }, maxRows)
        } else {
            Self.pendingGuide = (guide, maxRows)
        }
        if !Self.guideWorkerScheduled {
            Self.guideWorkerScheduled = true
            shouldSchedule = true
        }
        Self.persistenceLock.unlock()

        guard shouldSchedule else { return }
        Self.persistenceQueue.async {
            Self.drainGuideWrites()
        }
    }

    static func clearPersistedCache() {
        // Cancel any not-yet-encoded snapshots first. `sync` then waits behind an encode that
        // is already in flight, so the final operation is guaranteed to be the clear rather
        // than a stale write resurrecting the previous provider mode afterward.
        persistenceLock.lock()
        pendingChannels = nil
        pendingGuide = nil
        persistenceLock.unlock()

        persistenceQueue.sync {
            let defaults = UserDefaults.standard
            defaults.removeObject(forKey: channelCacheKey)
            defaults.removeObject(forKey: guideCacheKey)
            defaults.removeObject(forKey: lastRefreshKey)
            defaults.removeObject(forKey: lastHealthyGuideKey)
            removeLargeStateFile(named: channelCacheFileName)
            removeLargeStateFile(named: guideCacheFileName)
            guideReadQueue.sync {
                for suffix in ["", "-wal", "-shm", "-journal"] {
                    removeLargeStateFile(named: guideIndexFileName + suffix)
                }
            }
        }
    }

    private static func drainChannelWrites() {
        while true {
            persistenceLock.lock()
            guard let snapshot = pendingChannels else {
                channelWorkerScheduled = false
                persistenceLock.unlock()
                return
            }
            pendingChannels = nil
            persistenceLock.unlock()

            guard !snapshot.isEmpty, let data = try? JSONEncoder().encode(snapshot) else {
                saveLargeStateDataUnlocked(Data(), defaultsKey: channelCacheKey, fileName: channelCacheFileName)
                continue
            }
            saveLargeStateDataUnlocked(data, defaultsKey: channelCacheKey, fileName: channelCacheFileName)
        }
    }

    private static func drainGuideWrites() {
        while true {
            persistenceLock.lock()
            guard let pending = pendingGuide else {
                guideWorkerScheduled = false
                persistenceLock.unlock()
                return
            }
            pendingGuide = nil
            persistenceLock.unlock()

            guard !pending.guide.isEmpty else { continue }
            if writeGuideIndex(pending.guide, maxRows: pending.maxRows) {
                removeLegacyGuide()
                continue
            }
            let cached = pending.guide.mapValues { programs in
                programs.prefix(pending.maxRows).map(CachedLiveProgram.init)
            }
            if let data = try? JSONEncoder().encode(cached) {
                saveLargeStateDataUnlocked(data, defaultsKey: guideCacheKey, fileName: guideCacheFileName)
            }
        }
    }

    // The serial writer commits one batch at a time. WAL lets viewport reads use
    // the last committed version while the next batch is being written.
    private static var hasGuideIndex: Bool {
        guard let url = largeStateFile(named: guideIndexFileName) else { return false }
        return FileManager.default.fileExists(atPath: url.path)
    }

    private static func removeLegacyGuide() {
        UserDefaults.standard.removeObject(forKey: guideCacheKey)
        removeLargeStateFile(named: guideCacheFileName)
    }

    private static func openGuideIndex(readOnly: Bool) -> OpaquePointer? {
        guard let url = largeStateFile(named: guideIndexFileName) else { return nil }
        var db: OpaquePointer?
        let flags = readOnly ? SQLITE_OPEN_READONLY : SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE
        guard sqlite3_open_v2(url.path, &db, flags, nil) == SQLITE_OK, let db else {
            if let db { sqlite3_close(db) }
            return nil
        }
        return db
    }

    private static let copySQLiteValue = unsafeBitCast(-1, to: sqlite3_destructor_type.self)

    private static func writeGuideIndex(_ guide: [String: [LiveProgram]], maxRows: Int) -> Bool {
        guard let db = openGuideIndex(readOnly: false) else { return false }
        defer { sqlite3_close(db) }
        let schema = """
            CREATE TABLE IF NOT EXISTS listings (
                channel TEXT NOT NULL, ordinal INTEGER NOT NULL, starts REAL NOT NULL,
                ends REAL NOT NULL, imported REAL NOT NULL, payload BLOB NOT NULL,
                PRIMARY KEY (channel, ordinal)
            ) WITHOUT ROWID;
            CREATE INDEX IF NOT EXISTS listings_expiry ON listings (ends);
            """
        guard sqlite3_exec(db, "PRAGMA journal_mode=WAL", nil, nil, nil) == SQLITE_OK,
              sqlite3_exec(db, schema, nil, nil, nil) == SQLITE_OK,
              sqlite3_exec(db, "BEGIN IMMEDIATE", nil, nil, nil) == SQLITE_OK else { return false }
        var committed = false
        defer { if !committed { sqlite3_exec(db, "ROLLBACK", nil, nil, nil) } }
        var remove: OpaquePointer?
        var insert: OpaquePointer?
        var prune: OpaquePointer?
        defer { sqlite3_finalize(remove); sqlite3_finalize(insert); sqlite3_finalize(prune) }
        guard sqlite3_prepare_v2(db, "DELETE FROM listings WHERE channel = ?", -1, &remove, nil) == SQLITE_OK,
              sqlite3_prepare_v2(db, "INSERT INTO listings VALUES (?, ?, ?, ?, ?, ?)", -1, &insert, nil) == SQLITE_OK,
              sqlite3_prepare_v2(db, "DELETE FROM listings WHERE ends < ? OR imported < ?", -1, &prune, nil) == SQLITE_OK else { return false }
        let encoder = JSONEncoder()
        let now = Date().timeIntervalSince1970
        for (key, programs) in guide where !programs.isEmpty {
            sqlite3_reset(remove)
            guard sqlite3_bind_text(remove, 1, key, -1, copySQLiteValue) == SQLITE_OK,
                  sqlite3_step(remove) == SQLITE_DONE else { return false }
            for (ordinal, program) in programs.prefix(maxRows).enumerated() {
                let starts = program.startDate?.timeIntervalSince1970 ?? -1
                let ends = program.endDate?.timeIntervalSince1970 ?? (now + Double(guideWindowSeconds))
                guard starts < now + Double(guideWindowSeconds), ends >= now - 600 else { continue }
                guard let payload = try? encoder.encode(CachedLiveProgram(program)) else { return false }
                sqlite3_reset(insert)
                guard sqlite3_bind_text(insert, 1, key, -1, copySQLiteValue) == SQLITE_OK,
                      sqlite3_bind_int(insert, 2, Int32(ordinal)) == SQLITE_OK,
                      sqlite3_bind_double(insert, 3, starts) == SQLITE_OK,
                      sqlite3_bind_double(insert, 4, ends) == SQLITE_OK,
                      sqlite3_bind_double(insert, 5, now) == SQLITE_OK else { return false }
                let bound = payload.withUnsafeBytes { bytes in
                    sqlite3_bind_blob(insert, 6, bytes.baseAddress, Int32(bytes.count), copySQLiteValue)
                }
                guard bound == SQLITE_OK, sqlite3_step(insert) == SQLITE_DONE else { return false }
            }
        }
        guard sqlite3_bind_double(prune, 1, now - 600) == SQLITE_OK,
              sqlite3_bind_double(prune, 2, now - 24 * 3600) == SQLITE_OK,
              sqlite3_step(prune) == SQLITE_DONE else { return false }
        committed = sqlite3_exec(db, "COMMIT", nil, nil, nil) == SQLITE_OK
        return committed
    }

    private static func readGuideIndex(keys: [String]) -> [String: [LiveProgram]]? {
        guard hasGuideIndex, let db = openGuideIndex(readOnly: true) else { return nil }
        defer { sqlite3_close(db) }
        guard sqlite3_exec(db, "BEGIN", nil, nil, nil) == SQLITE_OK else { return nil }
        defer { sqlite3_exec(db, "ROLLBACK", nil, nil, nil) }
        var query: OpaquePointer?
        defer { sqlite3_finalize(query) }
        let sql = "SELECT payload FROM listings WHERE channel = ? AND starts < ? AND ends >= ? ORDER BY ordinal"
        guard sqlite3_prepare_v2(db, sql, -1, &query, nil) == SQLITE_OK else { return nil }
        let now = Date().timeIntervalSince1970
        let decoder = JSONDecoder()
        var result: [String: [LiveProgram]] = [:]
        for key in Set(keys) {
            sqlite3_reset(query)
            guard sqlite3_bind_text(query, 1, key, -1, copySQLiteValue) == SQLITE_OK,
                  sqlite3_bind_double(query, 2, now + Double(guideWindowSeconds)) == SQLITE_OK,
                  sqlite3_bind_double(query, 3, now - 600) == SQLITE_OK else { return nil }
            var status = sqlite3_step(query)
            while status == SQLITE_ROW {
                if let bytes = sqlite3_column_blob(query, 0) {
                    let data = Data(bytes: bytes, count: Int(sqlite3_column_bytes(query, 0)))
                    if let item = try? decoder.decode(CachedLiveProgram.self, from: data) {
                        result[key, default: []].append(item.liveProgram)
                    }
                }
                status = sqlite3_step(query)
            }
            guard status == SQLITE_DONE else { return nil }
        }
        return result
    }

    private static func largeStateDirectory() -> URL? {
        guard let base = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first else { return nil }
        let dir = base.appendingPathComponent("DebridChannelsLargeState", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    private static func largeStateFile(named name: String) -> URL? {
        largeStateDirectory()?.appendingPathComponent(name)
    }

    private static func removeLargeStateFile(named name: String) {
        guard let url = largeStateFile(named: name) else { return }
        try? FileManager.default.removeItem(at: url)
    }

    private static func loadLargeStateDataUnlocked(defaultsKey: String, fileName: String) -> Data? {
        if let url = largeStateFile(named: fileName),
           let data = try? Data(contentsOf: url),
           !data.isEmpty {
            return data
        }
        let data = UserDefaults.standard.data(forKey: defaultsKey)
        if let data, !data.isEmpty {
            if let url = largeStateFile(named: fileName) {
                try? data.write(to: url, options: [.atomic])
            }
            UserDefaults.standard.removeObject(forKey: defaultsKey)
        }
        return data
    }

    private static func saveLargeStateDataUnlocked(_ data: Data, defaultsKey: String, fileName: String) {
        guard !data.isEmpty else {
            UserDefaults.standard.removeObject(forKey: defaultsKey)
            removeLargeStateFile(named: fileName)
            return
        }
        if let url = largeStateFile(named: fileName) {
            try? data.write(to: url, options: [.atomic])
        }
        UserDefaults.standard.removeObject(forKey: defaultsKey)
    }
}
