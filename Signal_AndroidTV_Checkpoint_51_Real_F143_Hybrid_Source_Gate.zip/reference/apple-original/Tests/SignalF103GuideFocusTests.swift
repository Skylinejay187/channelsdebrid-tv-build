import Foundation

@main struct SignalF103GuideFocusTests {
    static func main() {
        var focus = SignalFullGuideFocusController()
        focus.enter(categoryIndex: 2, selectedChannelID: 20)
        precondition(focus.region == .categories)
        focus.move(.right, channelIDs: [10, 20, 30], categoryCount: 4)
        precondition(focus.region == .timeline && focus.selectedChannelID == 20)
        focus.move(.down, channelIDs: [10, 20, 30], categoryCount: 4)
        precondition(focus.selectedChannelID == 30)
        focus.move(.down, channelIDs: [10, 20, 30], categoryCount: 4)
        precondition(focus.selectedChannelID == 30)
        focus.move(.left, channelIDs: [10, 20, 30], categoryCount: 4)
        precondition(focus.region == .categories)
        focus.move(.up, channelIDs: [], categoryCount: 4)
        precondition(focus.selectedCategoryIndex == 1)
        focus.move(.right, channelIDs: [], categoryCount: 4)
        precondition(focus.region == .categories)
        focus.move(.right, channelIDs: [99], categoryCount: 4)
        precondition(focus.region == .timeline && focus.selectedChannelID == 99)
        print("F103 Guide focus controller transition tests passed")
    }
}
