import Foundation

extension AetherEngine {
    /// Re-read the producer's contiguous cache coverage without changing transport or time.
    /// Clock sinks alone cannot report a growing reservoir while presentation is stationary.
    @MainActor public func refreshSignalBufferFrontier() {
        guard !isLive, clock.currentTime.isFinite else { return }
        let current = max(0, clock.currentTime)
        let endpoint: Double
        if let host = softwareHost {
            endpoint = SoftwareBufferFrontier.bufferedPosition(
                currentTime: current, liveFrontier: host.bufferedSessionTime,
                cushion: host.displayCushionSeconds, cachedVODFrontier: host.cachedVODSessionTime)
        } else if let host = nativeHost {
            let hostTime = host.currentTime
            guard hostTime.isFinite else { return }
            // Both frontiers are contiguous from the same host position.
            // A producer reporting zero must not hide AVPlayer's loaded range.
            let hostAhead = host.signalCachedBufferEnd() - hostTime
            let diskAhead = nativeVideoSession?.contiguousForwardReadAheadSeconds(playlistSeconds: hostTime) ?? 0
            endpoint = current + max(0, hostAhead.isFinite ? hostAhead : 0, diskAhead.isFinite ? diskAhead : 0)
        } else {
            return
        }
        guard endpoint.isFinite else { return }
        let bounded = duration.isFinite && duration > 0 ? min(duration, max(current, endpoint)) : max(current, endpoint)
        if abs(clock.bufferedPosition - bounded) >= 0.01 { clock.bufferedPosition = bounded }
    }
}
