# Real Apple TV Swift Source (F143 / 1252)

This checkpoint includes the **203 exact Swift source files** from the uploaded `Signal_F143_1252_Main_Catalog_Masking.zip` archive, under `reference/apple-original/`, with individual SHA-256 hashes.

The uploaded complete Apple master ZIP SHA-256 is `57f254fb1284d677812767017bb5a653a5471d70a547e74513dfa2a635ec008e`. The outer source archive contains non-Swift assets and project metadata that have **not** been copied; it remains the source of truth for visuals/assets and full project structure.

The provenance manifest maps the original paths and proves embedded Swift bytes match the original uploaded archive. A workflow must use `reference/apple-original/Sources/UnitySurfaceSystem.swift` directly and must not use the older `reference/tvos-unity/` copies as evidence of original source conversion.

No Swift code has yet been converted by Skip; no APK parity is claimed.
