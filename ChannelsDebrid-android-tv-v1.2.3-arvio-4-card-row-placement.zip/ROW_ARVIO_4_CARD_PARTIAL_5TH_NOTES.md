# Row Arvio 4-card + partial 5th positioning

- Restored the lower cinematic row feel while moving the row start high enough to avoid clipping.
- Card sizing is now calculated from screen width to show 4 full landscape cards plus a partial 5th card on the right.
- Reduced card radius slightly and tightened card gaps to better match the Arvio-style reference.
- Reduced focused scale so the selected card keeps the ultra-thin glow without pushing layout out of alignment.
- Version bumped to 1.2.3.
