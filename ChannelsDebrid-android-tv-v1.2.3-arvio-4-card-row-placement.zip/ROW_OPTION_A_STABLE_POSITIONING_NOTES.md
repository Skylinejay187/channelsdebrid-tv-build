# Row Option A Stable Positioning

- Reverted the Option B floating/translation row system.
- Uses controlled heroHost height to place the row stack around the lower-middle/bottom-safe area.
- Removes negative row translation that caused unstable placement.
- Keeps rows close to bottom with breathing room and no clipping.
- Version bumped to 1.2.2.
