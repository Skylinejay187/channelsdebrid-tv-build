# v1.2.1 Row Option B floating positioning

- Applies Option B row placement.
- Keeps the row system anchored, then floats the whole row stack upward by 86dp.
- Adds extra bottom padding so the first row remains fully visible and does not clip while sitting above the bottom edge.
- Version bumped to 1.2.1.
