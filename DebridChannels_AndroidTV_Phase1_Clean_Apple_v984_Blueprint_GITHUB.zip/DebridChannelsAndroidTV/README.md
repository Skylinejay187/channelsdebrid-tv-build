# Debrid Channels Android TV — Clean Foundation

This is a brand-new Android TV project created from scratch. It does not reuse the previously modified Android project lineage.

The Apple TV **DebridChannels v984** project is the authoritative visual and behavioral blueprint. The Android implementation uses native Kotlin and Compose for TV while preserving the Apple product structure.

## What Phase 1 contains

- New Gradle project and wrapper
- New GitHub Actions Android TV build workflow
- Native Android TV manifest and launcher banner
- Compose for TV dark/orange Debrid Channels design system
- Apple-style top navigation: Home, Movies, TV Shows, Sports, Favorites, Live TV, Membership and Settings
- Catalog hero and horizontal media rows
- Poster and landscape cards with remote focus states
- Four-column Live TV grid
- Media details shell
- Live channel full-screen preview shell
- Search shell
- Settings category rail
- Source Intelligence 25/50 setting UI and limit contract
- Standalone / Home Server / Automatic mode foundation
- Shared model, data and design-system modules
- Local blueprint artwork so the project runs without API keys

## Deliberately not implemented yet

This first clean build proves the Android UI foundation and build pipeline. It does not claim full Apple feature parity yet.

- Media3 playback
- Real-Debrid or TorBox authentication
- Stremio add-on networking
- Real Source Intelligence requests
- HDHomeRun, Channels DVR, M3U, XMLTV or Xtream networking
- Server discovery and pairing
- DVR recording
- Episode alert scheduling
- Persistent favorites and progress

Those systems should be added in controlled phases after UI/focus validation.

## Local build

Requirements:

- JDK 17
- Android SDK Platform 36
- Android SDK Build Tools 35.0.0

Run:

```bash
./gradlew :app:assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## GitHub Actions

Upload the project to GitHub and run **Build Debrid Channels Android TV**. The workflow installs the Android SDK, runs unit tests and lint, and uploads debug/release APKs plus the release AAB.

## Architecture

```text
app                 Android TV screens and application shell
core:model          Cross-client domain models and enums
core:data           Standalone/server repository contracts and blueprint data
core:designsystem   Colors, shapes and focus surfaces mapped from Apple v984
```

See `docs/APPLE_V984_UI_BLUEPRINT.md` and `docs/IMPLEMENTATION_PHASES.md`.
