import express from "express"
import { homeRouter } from "./routes/home"
import { adminRowsRouter } from "./routes/admin-rows"
import { CatalogManager } from "./catalog/catalog-manager"
import { InternalCatalogSource } from "./catalog/sources/internal-catalog-source"
import { StremioCatalogSource } from "./catalog/sources/stremio-catalog-source"
import { createTmdbClient } from "./catalog/providers/tmdb-client"
import { createAddonRegistry } from "./stremio/addon-registry"
import { trailersRouter } from "./routes/trailers"
import { liveRouter } from "./routes/live"

export async function createApp() {
  const app = express()
  app.use(express.json())

  const tmdb = createTmdbClient(process.env.TMDB_API_KEY ?? "")
  const addonRegistry = createAddonRegistry()

  const catalogManager = new CatalogManager([
    new InternalCatalogSource(tmdb),
    new StremioCatalogSource(addonRegistry),
  ])

  app.use(homeRouter(catalogManager))
  app.use(adminRowsRouter())
  app.use(liveRouter())
  app.use("/api", liveRouter())
  app.use(trailersRouter())

  app.get("/health", (_req, res) => {
    res.json({ ok: true, service: "channels-debrid-foundation" })
  })

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, service: "channels-debrid-foundation" })
  })

  return app
}
