# Debrid Channels v5.3 FULL RESOURCE + FEATURE COMPLETION

Use `gradle assembleDebug` in CI pinned to Gradle 8.7.

Marker: `DC_V5_3_FULL_RESOURCE_FEATURE_COMPLETION`
