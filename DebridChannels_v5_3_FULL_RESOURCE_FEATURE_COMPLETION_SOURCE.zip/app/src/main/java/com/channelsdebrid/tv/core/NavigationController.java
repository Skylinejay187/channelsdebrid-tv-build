package com.channelsdebrid.tv.core;
public final class NavigationController { public enum Screen{HOME,LIVE_TV,MOVIES,SHOWS,SETTINGS,LAYOUT_EDITOR,PLAYER,LINKS} private Screen current=Screen.HOME; public Screen current(){return current;} public void go(Screen s){current=s;} }
