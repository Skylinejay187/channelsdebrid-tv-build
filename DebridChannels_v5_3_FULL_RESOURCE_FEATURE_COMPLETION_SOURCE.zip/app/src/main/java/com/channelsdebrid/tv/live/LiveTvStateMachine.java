package com.channelsdebrid.tv.live;
public final class LiveTvStateMachine{ public enum Mode{CATEGORIES,GUIDE,PLAYER} private Mode mode=Mode.CATEGORIES; public Mode mode(){return mode;} public void onUp(){mode=Mode.CATEGORIES;} public void onRight(){mode=Mode.GUIDE;} public void onLeft(){mode=Mode.CATEGORIES;} public void play(){mode=Mode.PLAYER;} }
