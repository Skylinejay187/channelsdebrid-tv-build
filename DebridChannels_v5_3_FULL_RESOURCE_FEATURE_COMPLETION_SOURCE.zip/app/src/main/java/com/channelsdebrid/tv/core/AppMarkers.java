package com.channelsdebrid.tv.core; public final class AppMarkers{ public static final String BUILD="DC_V5_3_FULL_RESOURCE_FEATURE_COMPLETION"; private AppMarkers(){} }
