package com.channelsdebrid.tv.player;
public final class TimeshiftEngine{ private boolean enabled; public void setEnabled(boolean e){enabled=e;} public boolean enabled(){return enabled;} }
