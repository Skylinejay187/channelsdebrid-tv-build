package com.channelsdebrid.tv.live;
import java.util.*;
public final class GuideCacheOwner{ public static final class Channel{public final String name,url,group; public Channel(String n,String u,String g){name=n;url=u;group=g;}} private final List<Channel> channels=new ArrayList<>(); public void replace(List<Channel> c){channels.clear();channels.addAll(c);} public List<Channel> all(){return new ArrayList<>(channels);} }
