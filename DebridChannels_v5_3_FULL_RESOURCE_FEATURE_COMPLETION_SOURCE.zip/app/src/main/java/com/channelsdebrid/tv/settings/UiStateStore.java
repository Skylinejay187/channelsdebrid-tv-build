package com.channelsdebrid.tv.settings;
import android.content.*;
public final class UiStateStore{ private final SharedPreferences p; public UiStateStore(Context c){p=c.getSharedPreferences("dc_v5_2_state",0);} public String get(String k,String d){return p.getString(k,d);} public boolean getBool(String k,boolean d){return p.getBoolean(k,d);} public void set(String k,String v){p.edit().putString(k,v).apply();} public void setBool(String k,boolean v){p.edit().putBoolean(k,v).apply();}}
