package com.channelsdebrid.tv.data;
import java.io.*; import java.net.*; import org.json.*; import java.util.*;
public final class StremioClient{ public interface Callback{void ok(JSONArray a); void err(String m);} public void loadCatalog(String base, Callback cb){new Thread(()->{try{String manifest=get(base); JSONObject j=new JSONObject(manifest); JSONArray catalogs=j.optJSONArray("catalogs"); cb.ok(catalogs==null?new JSONArray():catalogs);}catch(Exception e){cb.err(e.getMessage());}}).start();}
public void loadStreams(String streamUrl, Callback cb){new Thread(()->{try{JSONObject j=new JSONObject(get(streamUrl)); JSONArray a=j.optJSONArray("streams"); cb.ok(a==null?new JSONArray():a);}catch(Exception e){cb.err(e.getMessage());}}).start();}
private String get(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection(); c.setConnectTimeout(8000); c.setReadTimeout(12000); try(BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream()))){StringBuilder b=new StringBuilder(); String l; while((l=r.readLine())!=null)b.append(l); return b.toString();}}
}
