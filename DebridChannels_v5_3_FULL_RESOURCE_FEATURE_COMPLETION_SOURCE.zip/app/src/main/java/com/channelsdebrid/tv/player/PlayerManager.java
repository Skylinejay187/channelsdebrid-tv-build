package com.channelsdebrid.tv.player;
import android.net.Uri; import android.widget.VideoView;
public final class PlayerManager{ private VideoView view; public void attach(VideoView v){view=v; view.setFocusable(false); view.setFocusableInTouchMode(false);} public void play(String url){ if(view!=null && url!=null && url.length()>0){ view.setVideoURI(Uri.parse(url)); view.start(); }} public void stop(){ if(view!=null) view.stopPlayback(); }}
