package com.channelsdebrid.tv.live

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object LiveSourceResolver {

    data class HttpResult(
        val body: String?,
        val error: String?
    )

    data class ChannelItem(
        val name: String,
        val url: String,
        val source: String,
        val debug: String = ""
    )

    data class DvrResult(
        val channels: List<ChannelItem>,
        val message: String,
        val deviceId: String? = null
    )

    fun loadDvrChannels(baseUrl: String, preferredDeviceId: String = ""): DvrResult {
        val base = baseUrl.trim().trimEnd('/')
        if (base.isBlank()) return DvrResult(emptyList(), "Channels DVR base URL missing.")

        val candidates = linkedSetOf<String>()
        if (preferredDeviceId.isNotBlank()) candidates += preferredDeviceId

        val deviceProbe = getJson("$base/devices")
        if (deviceProbe.body != null) {
            candidates.addAll(parseDeviceNames(deviceProbe.body))
        }
        if (!candidates.contains("ANY")) candidates += "ANY"

        val combined = mutableListOf<ChannelItem>()
        val successfulDevices = mutableListOf<String>()

        for (device in candidates) {
            val encodedDevice = encodeURIComponent(device)
            val probe = getJson("$base/devices/$encodedDevice/channels")
            if (probe.error != null) continue
            val parsed = parseDvrChannels(base, device, probe.body ?: "")
            if (parsed.isNotEmpty()) {
                combined += parsed
                successfulDevices += device
            }
        }

        val deduped = combined.distinctBy { it.name + "|" + it.url }
        if (deduped.isNotEmpty()) {
            val label = when {
                successfulDevices.isEmpty() -> "Channels DVR"
                successfulDevices.size == 1 -> successfulDevices.first()
                else -> "${successfulDevices.size} devices"
            }
            val savedDevice = successfulDevices.firstOrNull { !it.equals("ANY", ignoreCase = true) } ?: preferredDeviceId
            return DvrResult(deduped, "Channels DVR connected  -  ${deduped.size} channels found ($label)", savedDevice)
        }

        return when {
            deviceProbe.error != null -> DvrResult(emptyList(), "Channels DVR failed: ${deviceProbe.error}")
            preferredDeviceId.isNotBlank() -> DvrResult(emptyList(), "Channels DVR connected, but no channels were returned for saved device '$preferredDeviceId'.")
            else -> DvrResult(emptyList(), "Channels DVR connected, but no channels were returned.")
        }
    }

    fun loadXtreamChannels(server: String, user: String, pass: String): Pair<List<ChannelItem>, String> {
        val base = server.trim().trimEnd('/')
        if (base.isBlank() || user.isBlank() || pass.isBlank()) {
            return emptyList<ChannelItem>() to "Xtream is missing server or credentials."
        }
        val probe = getJson("$base/player_api.php?username=$user&password=$pass&action=get_live_streams")
        if (probe.error != null) {
            return emptyList<ChannelItem>() to "Xtream failed: ${probe.error}"
        }
        val json = probe.body ?: return emptyList<ChannelItem>() to "Xtream returned no data."
        val arr = try {
            JSONArray(json)
        } catch (_: Exception) {
            return emptyList<ChannelItem>() to "Xtream returned invalid JSON."
        }
        val items = mutableListOf<ChannelItem>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val id = obj.optString("stream_id")
            if (id.isBlank()) continue
            val ext = obj.optString("container_extension").ifBlank { "m3u8" }
            val name = obj.optString("name").ifBlank { "Channel $id" }
            val url = "$base/live/$user/$pass/$id.$ext"
            items += ChannelItem(name, url, "Xtream/IPTV", "streamId=$id  -  ext=$ext")
        }
        return if (items.isEmpty()) {
            emptyList<ChannelItem>() to "Xtream connected, but no channels were returned."
        } else {
            items to "Xtream connected  -  ${items.size} channels found"
        }
    }

    fun resolveDvrPlayback(baseUrl: String, preferredDeviceId: String = ""): ChannelItem? {
        return loadDvrChannels(baseUrl, preferredDeviceId).channels.firstOrNull()
    }

    private fun parseDeviceNames(json: String): List<String> {
        val names = linkedSetOf<String>()
        fun addName(raw: String?) {
            val value = raw?.trim().orEmpty()
            if (value.isNotBlank()) names += value
        }
        fun addFromObject(obj: JSONObject?) {
            if (obj == null) return
            addName(obj.optString("Name"))
            addName(obj.optString("name"))
            addName(obj.optString("FriendlyName"))
            addName(obj.optString("friendlyName"))
            addName(obj.optString("DeviceID"))
            addName(obj.optString("deviceId"))
            addName(obj.optString("ID"))
            addName(obj.optString("id"))
        }
        try {
            if (json.trim().startsWith("[")) {
                val arr = JSONArray(json)
                for (i in 0 until arr.length()) {
                    when (val item = arr.opt(i)) {
                        is JSONObject -> addFromObject(item)
                        is String -> addName(item)
                    }
                }
            } else {
                val root = JSONObject(json)
                val arr = root.optJSONArray("devices")
                    ?: root.optJSONArray("Devices")
                    ?: root.optJSONArray("results")
                    ?: root.optJSONArray("Results")
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        when (val item = arr.opt(i)) {
                            is JSONObject -> addFromObject(item)
                            is String -> addName(item)
                        }
                    }
                }
                addFromObject(root)
            }
        } catch (_: Exception) {
        }
        return names.filterNot { it.equals("ANY", ignoreCase = true) }
    }

    private fun parseDvrChannels(base: String, device: String, json: String): List<ChannelItem> {
        val out = mutableListOf<ChannelItem>()
        try {
            val arr = if (json.trim().startsWith("[")) {
                JSONArray(json)
            } else {
                val root = JSONObject(json)
                root.optJSONArray("channels")
                    ?: root.optJSONArray("Channels")
                    ?: JSONArray()
            }

            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue

                val guideNumber = obj.optString("GuideNumber")
                    .ifBlank { obj.optString("Number") }
                    .ifBlank { obj.optString("number") }

                val id = obj.optString("id")
                    .ifBlank { obj.optString("ID") }
                    .ifBlank { guideNumber }

                val name = obj.optString("GuideName")
                    .ifBlank { obj.optString("Name") }
                    .ifBlank { obj.optString("name") }
                    .ifBlank { obj.optString("channel") }
                    .ifBlank { "Channel ${if (guideNumber.isNotBlank()) guideNumber else id}" }

                val playbackKey = guideNumber.ifBlank { id }
                if (playbackKey.isBlank()) continue

                val encodedDevice = encodeURIComponent(device)
                val encodedChannel = encodeURIComponent(playbackKey)
                val url = "$base/devices/$encodedDevice/channels/$encodedChannel/stream.mpg?format=ts&codec=copy"

                val debug = buildString {
                    append("device=")
                    append(device)
                    if (guideNumber.isNotBlank()) {
                        append("  -  guide=")
                        append(guideNumber)
                    }
                    if (id.isNotBlank()) {
                        append("  -  id=")
                        append(id)
                    }
                    append("  -  playKey=")
                    append(playbackKey)
                }
                out += ChannelItem(name, url, "Channels DVR", debug)
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun getJson(url: String): HttpResult {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 6000
        connection.readTimeout = 6000
        connection.instanceFollowRedirects = true
        connection.requestMethod = "GET"
        return try {
            connection.connect()
            val code = connection.responseCode
            if (code !in 200..299) {
                HttpResult(null, "HTTP $code")
            } else {
                val body = BufferedReader(InputStreamReader(connection.inputStream)).use { it.readText() }
                HttpResult(body, null)
            }
        } catch (e: Exception) {
            HttpResult(null, e.javaClass.simpleName + (e.message?.let { ": $it" } ?: ""))
        } finally {
            connection.disconnect()
        }
    }

    private fun encodeURIComponent(value: String): String = URLEncoder.encode(value, "UTF-8")
}
