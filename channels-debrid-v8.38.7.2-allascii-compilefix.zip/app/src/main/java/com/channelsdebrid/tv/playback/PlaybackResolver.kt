package com.channelsdebrid.tv.playback

import com.channelsdebrid.tv.live.LiveSourceResolver
import com.channelsdebrid.tv.settings.ChannelsDvrSettings
import com.channelsdebrid.tv.settings.XtreamSettings

class PlaybackResolver {

    data class PlaybackTarget(
        val url: String,
        val sourceLabel: String,
        val title: String,
        val debugLabel: String = ""
    )

    fun resolveLiveTestTarget(
        title: String,
        dvr: ChannelsDvrSettings,
        xtream: XtreamSettings
    ): PlaybackTarget? {
        return resolveChannelsDvr(title, dvr) ?: resolveXtream(title, xtream)
    }

    private fun resolveChannelsDvr(title: String, dvr: ChannelsDvrSettings): PlaybackTarget? {
        val base = dvr.baseUrl.trim().trimEnd('/')
        if (base.isBlank()) return null
        val first = LiveSourceResolver.resolveDvrPlayback(base, dvr.deviceId) ?: return null
        return PlaybackTarget(first.url, first.source, "${first.name}  -  $title", first.debug)
    }

    private fun resolveXtream(title: String, xtream: XtreamSettings): PlaybackTarget? {
        if (!xtream.enabled) return null
        val server = xtream.server.trim().trimEnd('/')
        val user = xtream.username.trim()
        val pass = xtream.password.trim()
        if (server.isBlank() || user.isBlank() || pass.isBlank()) return null

        val first = LiveSourceResolver.loadXtreamChannels(server, user, pass).first.firstOrNull() ?: return null
        return PlaybackTarget(first.url, first.source, "${first.name}  -  $title", first.debug)
    }
}
