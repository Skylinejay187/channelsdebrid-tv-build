package com.channelsdebrid.tv.data

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class SourceProbe {

    fun probeStremio(manifestUrl: String): String? {
        if (manifestUrl.isBlank()) return null
        return runCatching {
            val json = fetchJson(normalizeUrl(manifestUrl))
            val name = json.optString("name").ifBlank { "Stremio" }
            val count = json.optJSONArray("catalogs")?.length() ?: 0
            "$name  -  $count catalogs"
        }.getOrNull()
    }

    fun probeChannelsDvr(autoDetect: Boolean, baseUrl: String): String? {
        if (baseUrl.isBlank()) return if (autoDetect) "Channels DVR auto-detect" else null
        return runCatching {
            val normalized = normalizeBase(baseUrl)
            val channels = fetchJsonArrayOrObject("$normalized/channels")
            val count = channels.first ?: channels.second?.optJSONArray("channels")?.length() ?: 0
            "Channels DVR  -  $count channels"
        }.getOrElse {
            "Channels DVR configured"
        }
    }

    fun probeXtream(server: String, username: String, password: String): String? {
        if (server.isBlank() || username.isBlank() || password.isBlank()) return null
        return runCatching {
            val sep = if (server.contains('?')) '&' else '?'
            val url = "${normalizeBase(server)}/player_api.php${sep}username=${enc(username)}&password=${enc(password)}"
            val json = fetchJson(url)
            val auth = json.optJSONObject("user_info")?.optInt("auth", 0) == 1
            val status = json.optJSONObject("user_info")?.optString("status").orEmpty()
            if (auth || status.equals("Active", true)) "Xtream  -  account active" else "Xtream configured"
        }.getOrElse { "Xtream configured" }
    }

    private fun normalizeUrl(url: String): String = if (url.startsWith("http")) url else "https://$url"

    private fun normalizeBase(url: String): String = normalizeUrl(url).trimEnd('/')

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

    private fun fetchJson(url: String): JSONObject {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 5000
        connection.readTimeout = 5000
        connection.setRequestProperty("Accept", "application/json")
        return connection.inputStream.bufferedReader().use { JSONObject(it.readText()) }
            .also { connection.disconnect() }
    }

    private fun fetchJsonArrayOrObject(url: String): Pair<Int?, JSONObject?> {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 5000
        connection.readTimeout = 5000
        connection.setRequestProperty("Accept", "application/json")
        return connection.inputStream.bufferedReader().use {
            val text = it.readText().trim()
            when {
                text.startsWith("[") -> Pair(org.json.JSONArray(text).length(), null)
                text.startsWith("{") -> Pair(null, JSONObject(text))
                else -> Pair(null, null)
            }
        }.also { connection.disconnect() }
    }
}
