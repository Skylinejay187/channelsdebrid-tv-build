package com.channelsdebrid.tv

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import com.channelsdebrid.tv.data.SourceTestRunner
import com.channelsdebrid.tv.settings.CatalogSettings
import com.channelsdebrid.tv.settings.ChannelsDvrSettings
import com.channelsdebrid.tv.settings.DebridSettings
import com.channelsdebrid.tv.settings.PlaybackSettings
import com.channelsdebrid.tv.settings.SettingsRepository
import com.channelsdebrid.tv.settings.StorageSettings
import com.channelsdebrid.tv.settings.StremioAddonSettings
import com.channelsdebrid.tv.settings.TmdbSettings
import com.channelsdebrid.tv.settings.TrailerSettings
import com.channelsdebrid.tv.settings.XtreamSettings

class SettingsActivity : AppCompatActivity() {
    private lateinit var repository: SettingsRepository

    private lateinit var backButton: Button
    private lateinit var cancelButton: Button
    private lateinit var saveButton: Button
    private val sourceTestRunner = SourceTestRunner()

    private lateinit var tmdbTestButton: Button
    private lateinit var stremioTestButton: Button
    private lateinit var channelsTestButton: Button
    private lateinit var xtreamTestButton: Button
    private lateinit var debridTestButton: Button

    private lateinit var tmdbStatusText: TextView
    private lateinit var stremioStatusText: TextView
    private lateinit var channelsStatusText: TextView
    private lateinit var xtreamStatusText: TextView
    private lateinit var debridStatusText: TextView

    private lateinit var tmdbApiKeyInput: EditText
    private lateinit var tmdbRegionInput: EditText
    private lateinit var tmdbLanguageInput: EditText

    private lateinit var catalogTrendingMoviesSwitch: SwitchCompat
    private lateinit var catalogPopularMoviesSwitch: SwitchCompat
    private lateinit var catalogTrendingShowsSwitch: SwitchCompat
    private lateinit var catalogPopularShowsSwitch: SwitchCompat
    private lateinit var catalogPlatformSwitch: SwitchCompat
    private lateinit var catalogStremioSwitch: SwitchCompat

    private lateinit var stremioEnabledSwitch: SwitchCompat
    private lateinit var stremioNameInput: EditText
    private lateinit var stremioManifestInput: EditText

    private lateinit var realDebridEnabledSwitch: SwitchCompat
    private lateinit var realDebridApiKeyInput: EditText
    private lateinit var torBoxEnabledSwitch: SwitchCompat
    private lateinit var torBoxApiKeyInput: EditText
    private lateinit var preferredDebridInput: AutoCompleteTextView
    private lateinit var autoFallbackSwitch: SwitchCompat

    private lateinit var channelsAutoDetectSwitch: SwitchCompat
    private lateinit var channelsBaseUrlInput: EditText
    private lateinit var channelsUsernameInput: EditText
    private lateinit var channelsPasswordInput: EditText

    private lateinit var xtreamEnabledSwitch: SwitchCompat
    private lateinit var xtreamServerInput: EditText
    private lateinit var xtreamUsernameInput: EditText
    private lateinit var xtreamPasswordInput: EditText

    private lateinit var storageTargetInput: AutoCompleteTextView
    private lateinit var storageUsbInput: EditText
    private lateinit var storageNasInput: EditText
    private lateinit var timeshiftMinutesInput: EditText
    private lateinit var movieCacheSwitch: SwitchCompat

    private lateinit var trailerEnabledSwitch: SwitchCompat
    private lateinit var trailerAutoplaySwitch: SwitchCompat
    private lateinit var trailerDelayInput: EditText
    private lateinit var trailerModeInput: AutoCompleteTextView

    private lateinit var frameRateSwitch: SwitchCompat
    private lateinit var autoPlayBestSwitch: SwitchCompat
    private lateinit var preferExternalSwitch: SwitchCompat
    private lateinit var timeshiftEnabledSwitch: SwitchCompat
    private lateinit var fileSizeLimitInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        repository = SettingsRepository(this)
        bindViews()

        storageTargetInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("internal", "usb", "nas")))
        trailerModeInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("center_modal", "fullscreen")))
        preferredDebridInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("realdebrid", "torbox")))

        loadAll()
        backButton.setOnClickListener { finish() }
        cancelButton.setOnClickListener { finish() }
        saveButton.setOnClickListener {
            saveAll()
            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
            finish()
        }
        wireTestButtons()
    }

    private fun bindViews() {
        backButton = findViewById(R.id.backButton)
        cancelButton = findViewById(R.id.cancelButton)
        saveButton = findViewById(R.id.saveButton)
        tmdbTestButton = findViewById(R.id.tmdbTestButton)
        stremioTestButton = findViewById(R.id.stremioTestButton)
        channelsTestButton = findViewById(R.id.channelsTestButton)
        xtreamTestButton = findViewById(R.id.xtreamTestButton)
        debridTestButton = findViewById(R.id.debridTestButton)
        tmdbStatusText = findViewById(R.id.tmdbStatusText)
        stremioStatusText = findViewById(R.id.stremioStatusText)
        channelsStatusText = findViewById(R.id.channelsStatusText)
        xtreamStatusText = findViewById(R.id.xtreamStatusText)
        debridStatusText = findViewById(R.id.debridStatusText)

        tmdbApiKeyInput = findViewById(R.id.tmdbApiKeyInput)
        tmdbRegionInput = findViewById(R.id.tmdbRegionInput)
        tmdbLanguageInput = findViewById(R.id.tmdbLanguageInput)

        catalogTrendingMoviesSwitch = findViewById(R.id.catalogTrendingMoviesSwitch)
        catalogPopularMoviesSwitch = findViewById(R.id.catalogPopularMoviesSwitch)
        catalogTrendingShowsSwitch = findViewById(R.id.catalogTrendingShowsSwitch)
        catalogPopularShowsSwitch = findViewById(R.id.catalogPopularShowsSwitch)
        catalogPlatformSwitch = findViewById(R.id.catalogPlatformSwitch)
        catalogStremioSwitch = findViewById(R.id.catalogStremioSwitch)

        stremioEnabledSwitch = findViewById(R.id.stremioEnabledSwitch)
        stremioNameInput = findViewById(R.id.stremioNameInput)
        stremioManifestInput = findViewById(R.id.stremioManifestInput)

        realDebridEnabledSwitch = findViewById(R.id.realDebridEnabledSwitch)
        realDebridApiKeyInput = findViewById(R.id.realDebridApiKeyInput)
        torBoxEnabledSwitch = findViewById(R.id.torBoxEnabledSwitch)
        torBoxApiKeyInput = findViewById(R.id.torBoxApiKeyInput)
        preferredDebridInput = findViewById(R.id.preferredDebridInput)
        autoFallbackSwitch = findViewById(R.id.autoFallbackSwitch)

        channelsAutoDetectSwitch = findViewById(R.id.channelsAutoDetectSwitch)
        channelsBaseUrlInput = findViewById(R.id.channelsBaseUrlInput)
        channelsUsernameInput = findViewById(R.id.channelsUsernameInput)
        channelsPasswordInput = findViewById(R.id.channelsPasswordInput)

        xtreamEnabledSwitch = findViewById(R.id.xtreamEnabledSwitch)
        xtreamServerInput = findViewById(R.id.xtreamServerInput)
        xtreamUsernameInput = findViewById(R.id.xtreamUsernameInput)
        xtreamPasswordInput = findViewById(R.id.xtreamPasswordInput)

        storageTargetInput = findViewById(R.id.storageTargetInput)
        storageUsbInput = findViewById(R.id.storageUsbInput)
        storageNasInput = findViewById(R.id.storageNasInput)
        timeshiftMinutesInput = findViewById(R.id.timeshiftMinutesInput)
        movieCacheSwitch = findViewById(R.id.movieCacheSwitch)

        trailerEnabledSwitch = findViewById(R.id.trailerEnabledSwitch)
        trailerAutoplaySwitch = findViewById(R.id.trailerAutoplaySwitch)
        trailerDelayInput = findViewById(R.id.trailerDelayInput)
        trailerModeInput = findViewById(R.id.trailerModeInput)

        frameRateSwitch = findViewById(R.id.frameRateSwitch)
        autoPlayBestSwitch = findViewById(R.id.autoPlayBestSwitch)
        preferExternalSwitch = findViewById(R.id.preferExternalSwitch)
        timeshiftEnabledSwitch = findViewById(R.id.timeshiftEnabledSwitch)
        fileSizeLimitInput = findViewById(R.id.fileSizeLimitInput)
    }

    private fun loadAll() {
        val tmdb = repository.loadTmdb()
        tmdbApiKeyInput.setText(tmdb.apiKey)
        tmdbRegionInput.setText(tmdb.region)
        tmdbLanguageInput.setText(tmdb.language)

        val catalogs = repository.loadCatalogs()
        catalogTrendingMoviesSwitch.isChecked = catalogs.trendingMoviesEnabled
        catalogPopularMoviesSwitch.isChecked = catalogs.popularMoviesEnabled
        catalogTrendingShowsSwitch.isChecked = catalogs.trendingShowsEnabled
        catalogPopularShowsSwitch.isChecked = catalogs.popularShowsEnabled
        catalogPlatformSwitch.isChecked = catalogs.platformRowsEnabled
        catalogStremioSwitch.isChecked = catalogs.stremioCatalogRowsEnabled

        val addon = repository.loadPrimaryAddon()
        stremioEnabledSwitch.isChecked = addon.enabled
        stremioNameInput.setText(addon.name)
        stremioManifestInput.setText(addon.manifestUrl)

        val debrid = repository.loadDebrid()
        realDebridEnabledSwitch.isChecked = debrid.realDebridEnabled
        realDebridApiKeyInput.setText(debrid.realDebridApiKey)
        torBoxEnabledSwitch.isChecked = debrid.torBoxEnabled
        torBoxApiKeyInput.setText(debrid.torBoxApiKey)
        preferredDebridInput.setText(debrid.preferredProvider, false)
        autoFallbackSwitch.isChecked = debrid.autoFallback

        val dvr = repository.loadChannelsDvr()
        channelsAutoDetectSwitch.isChecked = dvr.autoDetect
        channelsBaseUrlInput.setText(dvr.baseUrl)
        channelsUsernameInput.setText(dvr.username)
        channelsPasswordInput.setText(dvr.password)

        val xtream = repository.loadXtream()
        xtreamEnabledSwitch.isChecked = xtream.enabled
        xtreamServerInput.setText(xtream.server)
        xtreamUsernameInput.setText(xtream.username)
        xtreamPasswordInput.setText(xtream.password)

        val storage = repository.loadStorage()
        storageTargetInput.setText(storage.preferredTarget, false)
        storageUsbInput.setText(storage.usbPath)
        storageNasInput.setText(storage.nasPath)
        timeshiftMinutesInput.setText(storage.timeshiftMinutes.toString())
        movieCacheSwitch.isChecked = storage.movieCacheEnabled

        val trailers = repository.loadTrailers()
        trailerEnabledSwitch.isChecked = trailers.enabled
        trailerAutoplaySwitch.isChecked = trailers.autoplayOnFocus
        trailerDelayInput.setText(trailers.autoplayDelayMs.toString())
        trailerModeInput.setText(trailers.popupMode, false)

        val playback = repository.loadPlayback()
        frameRateSwitch.isChecked = playback.frameRateMatching
        autoPlayBestSwitch.isChecked = playback.autoPlayBestStream
        preferExternalSwitch.isChecked = playback.preferExternalStorageForCache
        timeshiftEnabledSwitch.isChecked = playback.timeshiftEnabled
        fileSizeLimitInput.setText(playback.fileSizeLimitGb.toString())
    }

    private fun wireTestButtons() {
        tmdbTestButton.setOnClickListener {
            runSourceTest(tmdbStatusText, "Testing TMDB...") {
                sourceTestRunner.testTmdb(
                    tmdbApiKeyInput.text.toString().trim(),
                    tmdbRegionInput.text.toString().trim(),
                    tmdbLanguageInput.text.toString().trim()
                )
            }
        }
        stremioTestButton.setOnClickListener {
            runSourceTest(stremioStatusText, "Testing Stremio...") {
                sourceTestRunner.testStremio(
                    stremioNameInput.text.toString().trim().ifEmpty { "Stremio" },
                    stremioManifestInput.text.toString().trim()
                )
            }
        }
        channelsTestButton.setOnClickListener {
            runSourceTest(channelsStatusText, "Testing Channels DVR...") {
                sourceTestRunner.testChannelsDvr(
                    channelsAutoDetectSwitch.isChecked,
                    channelsBaseUrlInput.text.toString().trim()
                )
            }
        }
        xtreamTestButton.setOnClickListener {
            runSourceTest(xtreamStatusText, "Testing Xtream...") {
                sourceTestRunner.testXtream(
                    xtreamServerInput.text.toString().trim(),
                    xtreamUsernameInput.text.toString().trim(),
                    xtreamPasswordInput.text.toString().trim()
                )
            }
        }
        debridTestButton.setOnClickListener {
            runSourceTest(debridStatusText, "Testing Debrid...") {
                when {
                    realDebridEnabledSwitch.isChecked && realDebridApiKeyInput.text.toString().trim().isNotBlank() -> {
                        sourceTestRunner.testRealDebrid(realDebridApiKeyInput.text.toString().trim())
                    }
                    torBoxEnabledSwitch.isChecked && torBoxApiKeyInput.text.toString().trim().isNotBlank() -> {
                        sourceTestRunner.testTorBox(torBoxApiKeyInput.text.toString().trim())
                    }
                    else -> "Enable Real-Debrid or TorBox and enter an API key"
                }
            }
        }
    }

    private fun runSourceTest(statusView: TextView, runningText: String, block: () -> String) {
        statusView.text = runningText
        Thread {
            val result = runCatching(block).getOrElse { "Test failed" }
            runOnUiThread { statusView.text = result }
        }.start()
    }

    private fun saveAll() {
        repository.saveTmdb(
            TmdbSettings(
                apiKey = tmdbApiKeyInput.text.toString().trim(),
                region = tmdbRegionInput.text.toString().trim().ifEmpty { "US" },
                language = tmdbLanguageInput.text.toString().trim().ifEmpty { "en-US" }
            )
        )

        repository.saveCatalogs(
            CatalogSettings(
                trendingMoviesEnabled = catalogTrendingMoviesSwitch.isChecked,
                popularMoviesEnabled = catalogPopularMoviesSwitch.isChecked,
                trendingShowsEnabled = catalogTrendingShowsSwitch.isChecked,
                popularShowsEnabled = catalogPopularShowsSwitch.isChecked,
                platformRowsEnabled = catalogPlatformSwitch.isChecked,
                stremioCatalogRowsEnabled = catalogStremioSwitch.isChecked
            )
        )

        repository.savePrimaryAddon(
            StremioAddonSettings(
                id = "primary",
                name = stremioNameInput.text.toString().trim().ifEmpty { "Primary Addon" },
                manifestUrl = stremioManifestInput.text.toString().trim(),
                enabled = stremioEnabledSwitch.isChecked
            )
        )

        repository.saveDebrid(
            DebridSettings(
                realDebridEnabled = realDebridEnabledSwitch.isChecked,
                realDebridApiKey = realDebridApiKeyInput.text.toString().trim(),
                torBoxEnabled = torBoxEnabledSwitch.isChecked,
                torBoxApiKey = torBoxApiKeyInput.text.toString().trim(),
                preferredProvider = preferredDebridInput.text.toString().trim().ifEmpty { "realdebrid" },
                autoFallback = autoFallbackSwitch.isChecked
            )
        )

        val existingDvr = repository.loadChannelsDvr()
        val newBaseUrl = channelsBaseUrlInput.text.toString().trim()
        repository.saveChannelsDvr(
            ChannelsDvrSettings(
                autoDetect = channelsAutoDetectSwitch.isChecked,
                baseUrl = newBaseUrl,
                username = channelsUsernameInput.text.toString().trim(),
                password = channelsPasswordInput.text.toString().trim(),
                deviceId = if (existingDvr.baseUrl.trim().trimEnd('/') == newBaseUrl.trim().trimEnd('/')) existingDvr.deviceId else ""
            )
        )

        repository.saveXtream(
            XtreamSettings(
                server = xtreamServerInput.text.toString().trim(),
                username = xtreamUsernameInput.text.toString().trim(),
                password = xtreamPasswordInput.text.toString().trim(),
                enabled = xtreamEnabledSwitch.isChecked
            )
        )

        repository.saveStorage(
            StorageSettings(
                preferredTarget = storageTargetInput.text.toString().trim().ifEmpty { "internal" },
                usbPath = storageUsbInput.text.toString().trim(),
                nasPath = storageNasInput.text.toString().trim(),
                timeshiftMinutes = timeshiftMinutesInput.text.toString().toIntOrNull() ?: 90,
                movieCacheEnabled = movieCacheSwitch.isChecked
            )
        )

        repository.saveTrailers(
            TrailerSettings(
                enabled = trailerEnabledSwitch.isChecked,
                autoplayOnFocus = trailerAutoplaySwitch.isChecked,
                autoplayDelayMs = trailerDelayInput.text.toString().toLongOrNull() ?: 1500L,
                popupMode = trailerModeInput.text.toString().trim().ifEmpty { "center_modal" }
            )
        )

        repository.savePlayback(
            PlaybackSettings(
                frameRateMatching = frameRateSwitch.isChecked,
                preferExternalStorageForCache = preferExternalSwitch.isChecked,
                timeshiftEnabled = timeshiftEnabledSwitch.isChecked,
                autoPlayBestStream = autoPlayBestSwitch.isChecked,
                fileSizeLimitGb = fileSizeLimitInput.text.toString().toIntOrNull() ?: 40
            )
        )
    }
}
