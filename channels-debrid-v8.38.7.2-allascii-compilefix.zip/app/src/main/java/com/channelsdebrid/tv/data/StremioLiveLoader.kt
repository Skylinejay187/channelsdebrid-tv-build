package com.channelsdebrid.tv.data

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class StremioLiveLoader {

    data class LiveCatalogItem(
        val title: String,
        val meta: String,
        val desc: String,
        val badge: String,
        val brand: String,
        val footer: String,
        val progress: Float,
        val posterUrl: String? = null,
        val backdropUrl: String? = null,
        val logoUrl: String? = null
    )

    data class LiveRow(
        val title: String,
        val subtitle: String,
        val items: List<LiveCatalogItem>
    )

    fun loadPrimaryRow(addonName: String, manifestUrl: String, limit: Int = 24): LiveRow {
        val manifest = fetchJson(manifestUrl)
        val catalogs = manifest.optJSONArray("catalogs") ?: JSONArray()
        var chosen: JSONObject? = null
        for (i in 0 until catalogs.length()) {
            val cat = catalogs.optJSONObject(i) ?: continue
            val type = cat.optString("type")
            if (type == "movie" || type == "series") {
                chosen = cat
                break
            }
        }
        if (chosen == null) {
            return LiveRow(
                title = addonName,
                subtitle = "Manifest loaded  -  no compatible catalogs",
                items = List(12) { idx ->
                    LiveCatalogItem(
                        title = "$addonName Item ${idx + 1}",
                        meta = "Addon ready",
                        desc = "Manifest loaded successfully.",
                        badge = "*  Addon Connected",
                        brand = addonName.take(10),
                        footer = "Catalog Ready",
                        progress = 0.2f + ((idx % 5) * 0.1f)
                    )
                }
            )
        }
        val type = chosen.optString("type")
        val id = chosen.optString("id")
        val name = chosen.optString("name").ifBlank { "$addonName Catalog" }
        val endpoint = buildCatalogUrl(manifestUrl, type, id)
        val catalogJson = fetchJson(endpoint)
        val metas = catalogJson.optJSONArray("metas") ?: JSONArray()
        val items = mutableListOf<LiveCatalogItem>().apply {
            for (i in 0 until minOf(limit, metas.length())) {
                val meta = metas.optJSONObject(i) ?: continue
                val title = meta.optString("name").ifBlank { meta.optString("title") }.ifBlank { "Unknown" }
                val year = meta.optString("year")
                val desc = meta.optString("description").ifBlank { "Stremio catalog item." }
                val logo = meta.optString("imdbRating").takeIf { it.isNotBlank() }?.let { "IMDb $it" } ?: "Addon"
                val footer = listOfNotNull(year.takeIf { it.isNotBlank() }, meta.optString("genres").takeIf { it.isNotBlank() }).joinToString("   -   ").ifBlank { addonName }
                add(
                    LiveCatalogItem(
                        title = title,
                        meta = footer,
                        desc = desc,
                        badge = "*  Stremio Live",
                        brand = addonName.take(12),
                        footer = footer,
                        progress = 0.16f + ((i % 7) * 0.08f),
                        posterUrl = meta.optString("poster").takeIf { it.isNotBlank() },
                        backdropUrl = meta.optString("background").takeIf { it.isNotBlank() } ?: meta.optString("poster").takeIf { it.isNotBlank() },
                        logoUrl = meta.optString("logo").takeIf { it.isNotBlank() }
                    )
                )
            }
        }
        return LiveRow(
            title = name,
            subtitle = "$addonName  -  live catalog",
            items = if (items.isEmpty()) List(8) { idx ->
                LiveCatalogItem(
                    title = "$name ${idx + 1}",
                    meta = "Catalog empty",
                    desc = "The addon responded but returned no items.",
                    badge = "*  Addon Connected",
                    brand = addonName.take(12),
                    footer = "No Metas",
                    progress = 0.18f
                )
            } else items
        )
    }

    private fun buildCatalogUrl(manifestUrl: String, type: String, catalogId: String): String {
        val base = if (manifestUrl.endsWith("/manifest.json")) manifestUrl.substring(0, manifestUrl.length - "/manifest.json".length) else manifestUrl.substringBeforeLast('/')
        return "$base/catalog/$type/$catalogId.json"
    }

    private fun fetchJson(url: String): JSONObject {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 8000
        connection.readTimeout = 8000
        connection.setRequestProperty("Accept", "application/json")
        return connection.inputStream.bufferedReader().use { JSONObject(it.readText()) }
            .also { connection.disconnect() }
    }
}
