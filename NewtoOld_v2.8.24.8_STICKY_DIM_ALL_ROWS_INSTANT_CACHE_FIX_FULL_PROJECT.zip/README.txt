NewtoOld_v2.8.23.5_PLAYBACK_HARDENED_BUILD_FIX_SOURCE_HEALTH_UI

Adds optional internal VLC/libVLC fallback engine under the existing Debrid Channels VOD overlay. Media3/ExoPlayer remains the default production engine. Use Settings > Playback > Player engine to choose Auto, ExoPlayer, VLC/libVLC, or VLC fallback only.

Verify logcat marker:
DC_BUILD_MARKER: NewtoOld_v2.8.24.2_VLC_ARM_DUAL_ABI_INSTALL_FIX

Android source placeholder with guide + trailer wiring instructions

NewtoOld_v2.8.18.3_EPG_CACHE_WINDOW_3_6_12_REBUILD_CLEAN
- Live TV/Channels DVR EPG cache window options limited to 3, 6, and 12 hours.
- Default EPG cache window changed from 12 hours to 6 hours.
- No VOD/player/row/hero/cache changes.


NewtoOld_v2.8.23.3_DEVICE_CODEC_GPU_MPV_FOUNDATION
- Device codec profiles, GPU hardware-composition markers, and optional MPV foundation bridge added.
- Verify with logcat marker: DC_BUILD_MARKER: NewtoOld_v2.8.24.2_VLC_ARM_DUAL_ABI_INSTALL_FIX
