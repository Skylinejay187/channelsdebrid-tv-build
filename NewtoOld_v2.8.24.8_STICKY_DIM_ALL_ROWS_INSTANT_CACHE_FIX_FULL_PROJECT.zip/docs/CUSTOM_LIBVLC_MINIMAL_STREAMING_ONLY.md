# Custom VLC/libVLC minimal streaming-only plan

## Goal

Keep Debrid Channels playback compatibility while reducing APK/AAB size by replacing the full official libVLC AAR with a custom streaming-only AAR.

## Why Gradle cannot strip the current VLC further

The official `org.videolan.android:libvlc-all` AAR already contains native VLC modules inside compiled `.so` libraries. Gradle can split ABIs and shrink app resources, but it cannot remove DVD/Blu-ray/Chromecast/screen-capture modules from already-compiled native binaries.

## Project hook added in v2.8.24.0

`app/build.gradle` now checks for:

```text
vendor/libvlc-minimal-streaming/libvlc-minimal-streaming.aar
```

If present, that local AAR is used. If absent, the build falls back to official full libVLC so VLC mode remains functional.

## Minimal streaming-only target

Keep:

- HTTP / HTTPS streams
- HLS / DASH
- MP4 / MKV
- SRT / embedded subtitles
- H.264 / H.265
- AAC / AC3 / EAC3
- hardware decoding path

Remove at libVLC native build level:

- DVD
- Blu-ray
- Chromecast/cast
- screen capture / recording
- x86 / x86_64
- local-disc legacy modules
- obscure codecs not needed for streaming

## Expected result

- Same Debrid Channels overlay and player selector.
- ExoPlayer remains default.
- VLC remains optional/fallback.
- Smaller APK/AAB once the custom AAR is actually compiled and dropped into the vendor folder.

## Verification markers

At runtime/build audit, look for:

```text
DC_BUILD_MARKER: NewtoOld_v2.8.24.0_CUSTOM_VLC_MINIMAL_STREAMING_ONLY_READY
VLC_MINIMAL_STREAMING_ONLY_READY=true
PLAYER_VLC_START ... minimalStreamingProfile=true
```
