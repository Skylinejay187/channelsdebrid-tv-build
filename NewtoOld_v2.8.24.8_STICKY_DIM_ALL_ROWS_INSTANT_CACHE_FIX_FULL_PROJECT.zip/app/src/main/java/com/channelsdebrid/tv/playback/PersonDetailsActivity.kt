package com.channelsdebrid.tv.playback

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.channelsdebrid.tv.R
import com.channelsdebrid.tv.net.BackendEndpoint
import com.channelsdebrid.tv.settings.SettingsRepository
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors

class PersonDetailsActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_NAME = "person_name"
        const val EXTRA_ROLE = "person_role"
        const val EXTRA_IMAGE_URL = "person_image_url"
        const val EXTRA_SOURCE = "person_source"
        const val EXTRA_PERSON_ID = "person_id"
    }

    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var knownForRow: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var subtitleView: TextView
    private lateinit var bioView: TextView
    private var name: String = ""
    private var personId: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        name = intent.getStringExtra(EXTRA_NAME).orEmpty()
        personId = intent.getIntExtra(EXTRA_PERSON_ID, 0)
        val role = intent.getStringExtra(EXTRA_ROLE).orEmpty()
        val imageUrl = intent.getStringExtra(EXTRA_IMAGE_URL).orEmpty()
        android.util.Log.i("DebridChannels", "PERSON_DETAILS_OPEN: name=${name.take(40)} role=${role.take(40)} personId=$personId")
        buildLayout(name, role, imageUrl)
        loadKnownFor()
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    private fun buildLayout(name: String, role: String, imageUrl: String) {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val scroll = ScrollView(this)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(64), dp(42), dp(64), dp(42))
        }
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val photo = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = pill(0x33FFFFFF, 0x55FFFFFF)
        }
        hero.addView(photo, LinearLayout.LayoutParams(dp(156), dp(156)).apply { marginEnd = dp(28) })
        if (imageUrl.isNotBlank()) Glide.with(this).load(BackendEndpoint.imageProxyUrl(imageUrl)).centerCrop().into(photo)
        val textCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleView = TextView(this).apply {
            text = name.ifBlank { "Cast & Crew" }
            setTextColor(Color.WHITE)
            textSize = 42f
            setTypeface(typeface, Typeface.BOLD)
        }
        subtitleView = TextView(this).apply {
            text = role.ifBlank { "Cast / Crew" }
            setTextColor(0xCCFFFFFF.toInt())
            textSize = 18f
        }
        bioView = TextView(this).apply {
            text = "Loading filmography…"
            setTextColor(0xAAFFFFFF.toInt())
            textSize = 16f
            maxLines = 3
        }
        textCol.addView(titleView)
        textCol.addView(subtitleView, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        textCol.addView(bioView, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        hero.addView(textCol, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        panel.addView(hero)
        val header = TextView(this).apply {
            text = "Known For / Filmography"
            setTextColor(Color.WHITE)
            textSize = 24f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(30), 0, dp(12))
        }
        panel.addView(header)
        val hScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        knownForRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        hScroll.addView(knownForRow)
        panel.addView(hScroll, LinearLayout.LayoutParams.MATCH_PARENT, dp(260))
        scroll.addView(panel)
        root.addView(scroll)
        setContentView(root)
    }

    private fun loadKnownFor() {
        knownForRow.removeAllViews()
        knownForRow.addView(label("Loading…"), LinearLayout.LayoutParams(dp(220), dp(230)))
        executor.execute {
            val items = resolveKnownFor()
            runOnUiThread {
                knownForRow.removeAllViews()
                if (items.isEmpty()) {
                    bioView.text = "No filmography source available yet. Add a TMDB key in Settings for richer cast and crew results."
                    knownForRow.addView(label("No results"), LinearLayout.LayoutParams(dp(220), dp(230)))
                } else {
                    bioView.text = "Select a title to open its media information page."
                    items.take(18).forEach { addKnownForCard(it) }
                }
            }
        }
    }

    private fun resolveKnownFor(): List<KnownForItem> {
        val tmdb = SettingsRepository(this).loadTmdb()
        val apiKey = tmdb.apiKey.trim()
        if (apiKey.isBlank() || name.isBlank()) return emptyList()
        return runCatching {
            val lang = tmdb.language.ifBlank { "en-US" }
            val id = if (personId > 0) personId else {
                val search = JSONObject(fetch("https://api.themoviedb.org/3/search/person?api_key=${enc(apiKey)}&language=${enc(lang)}&query=${enc(name)}&include_adult=false&page=1"))
                search.optJSONArray("results")?.optJSONObject(0)?.optInt("id", 0) ?: 0
            }
            if (id <= 0) return@runCatching emptyList<KnownForItem>()
            val combined = JSONObject(fetch("https://api.themoviedb.org/3/person/$id/combined_credits?api_key=${enc(apiKey)}&language=${enc(lang)}"))
            val cast = combined.optJSONArray("cast") ?: return@runCatching emptyList<KnownForItem>()
            val out = mutableListOf<KnownForItem>()
            for (i in 0 until cast.length()) {
                val obj = cast.optJSONObject(i) ?: continue
                val mediaType = obj.optString("media_type").ifBlank { "movie" }
                if (mediaType != "movie" && mediaType != "tv") continue
                val title = obj.optString("title").ifBlank { obj.optString("name") }.trim()
                if (title.isBlank()) continue
                val poster = obj.optString("poster_path").takeIf { it.isNotBlank() }?.let { "https://image.tmdb.org/t/p/w500$it" }.orEmpty()
                val backdrop = obj.optString("backdrop_path").takeIf { it.isNotBlank() }?.let { "https://image.tmdb.org/t/p/w780$it" }.orEmpty()
                val year = obj.optString("release_date").ifBlank { obj.optString("first_air_date") }.take(4)
                val rating = obj.optDouble("vote_average", 0.0)
                out += KnownForItem(title, if (mediaType == "tv") "series" else "movie", "${year.ifBlank { "" }} • TMDB ${String.format(Locale.US, "%.1f", rating)}", obj.optString("overview"), poster, backdrop)
            }
            out.distinctBy { it.title.lowercase(Locale.US) }.sortedByDescending { it.meta }
        }.getOrDefault(emptyList())
    }

    private fun addKnownForCard(item: KnownForItem) {
        val frame = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isFocusable = true
            isClickable = true
            background = pill(0x22000000, 0x44FFFFFF)
            setPadding(dp(6), dp(6), dp(6), dp(6))
            setOnFocusChangeListener { v, hasFocus ->
                v.animate().scaleX(if (hasFocus) 1.06f else 1f).scaleY(if (hasFocus) 1.06f else 1f).setDuration(120).start()
            }
            setOnClickListener {
                startActivity(Intent(this@PersonDetailsActivity, MediaDetailsActivity::class.java).apply {
                    putExtra(MediaDetailsActivity.EXTRA_TITLE, item.title)
                    putExtra(MediaDetailsActivity.EXTRA_MEDIA_TYPE, item.mediaType)
                    putExtra(MediaDetailsActivity.EXTRA_META_LINE, item.meta)
                    putExtra(MediaDetailsActivity.EXTRA_DESC, item.overview)
                    putExtra(MediaDetailsActivity.EXTRA_POSTER_URL, item.posterUrl)
                    putExtra(MediaDetailsActivity.EXTRA_BACKDROP_URL, item.backdropUrl)
                })
            }
        }
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = pill(0x33FFFFFF, 0x44FFFFFF) }
        if (item.posterUrl.isNotBlank()) Glide.with(this).load(BackendEndpoint.imageProxyUrl(item.posterUrl)).centerCrop().into(img)
        val label = TextView(this).apply {
            text = item.title
            setTextColor(Color.WHITE)
            textSize = 13f
            maxLines = 2
            gravity = Gravity.CENTER
        }
        frame.addView(img, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(178)))
        frame.addView(label, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        knownForRow.addView(frame, LinearLayout.LayoutParams(dp(132), dp(230)).apply { marginEnd = dp(12) })
    }

    private fun label(textValue: String): TextView = TextView(this).apply {
        text = textValue
        setTextColor(0xAAFFFFFF.toInt())
        gravity = Gravity.CENTER
        textSize = 18f
    }

    private fun pill(color: Int, stroke: Int): android.graphics.drawable.GradientDrawable = android.graphics.drawable.GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(18).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun fetch(urlValue: String): String {
        val conn = (URL(urlValue).openConnection() as HttpURLConnection)
        conn.connectTimeout = 7000
        conn.readTimeout = 9000
        conn.setRequestProperty("Accept", "application/json")
        return conn.inputStream.bufferedReader().use { it.readText() }.also { conn.disconnect() }
    }

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8").replace("+", "%20")
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private data class KnownForItem(val title: String, val mediaType: String, val meta: String, val overview: String, val posterUrl: String, val backdropUrl: String)
}
