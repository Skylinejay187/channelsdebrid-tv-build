package com.channelsdebrid.tv.playback

import android.content.Context
import android.net.Uri
import android.os.SystemClock
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import java.util.ArrayList
import java.util.Locale

/**
 * Optional internal libVLC engine for VOD fallback/advanced playback.
 *
 * This deliberately uses reflection so the app can still compile/run with Media3 if the
 * libVLC AAR is missing or removed by a build variant. When libVLC is present, it owns only
 * the video surface; Debrid Channels keeps its existing poster/ratings/cast overlay above it.
 */
class VlcPlayerBridge(
    private val context: Context,
    private val surfaceHost: FrameLayout
) {
    data class Availability(val available: Boolean, val reason: String)

    private var libVlc: Any? = null
    private var mediaPlayer: Any? = null
    private var videoLayout: View? = null
    private var startedAtMs: Long = 0L

    val isActive: Boolean get() = mediaPlayer != null

    fun availability(): Availability = companionAvailability()

    fun start(url: String, title: String, startPositionMs: Long = 0L): Boolean {
        val available = availability()
        if (!available.available) {
            Log.w(TAG, "PLAYER_VLC_UNAVAILABLE: reason=${available.reason}")
            return false
        }
        return runCatching {
            release()
            val libVlcClass = Class.forName("org.videolan.libvlc.LibVLC")
            val mediaPlayerClass = Class.forName("org.videolan.libvlc.MediaPlayer")
            val mediaClass = Class.forName("org.videolan.libvlc.Media")
            val layoutClass = Class.forName("org.videolan.libvlc.util.VLCVideoLayout")

            val options = ArrayList<String>().apply {
                add("--aout=opensles")
                add("--audio-time-stretch")
                add("--network-caching=5000")
                add("--file-caching=3000")
                add("--live-caching=3000")
                add("--clock-jitter=0")
                add("--clock-synchro=0")
                add("--drop-late-frames")
                add("--skip-frames")
                add("--avcodec-hw=any")
                add("--no-video-title-show")
                add("--no-osd")
            }
            libVlc = libVlcClass.getConstructor(Context::class.java, ArrayList::class.java)
                .newInstance(context.applicationContext, options)
            mediaPlayer = mediaPlayerClass.getConstructor(libVlcClass).newInstance(libVlc)
            videoLayout = layoutClass.getConstructor(Context::class.java).newInstance(context) as View
            surfaceHost.removeAllViews()
            surfaceHost.addView(videoLayout, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            surfaceHost.visibility = View.VISIBLE

            mediaPlayerClass.methods.firstOrNull { it.name == "attachViews" && it.parameterTypes.size == 4 }
                ?.invoke(mediaPlayer, videoLayout, null, false, false)

            val media = mediaClass.getConstructor(libVlcClass, Uri::class.java).newInstance(libVlc, Uri.parse(url))
            mediaClass.methods.firstOrNull { it.name == "setHWDecoderEnabled" && it.parameterTypes.size == 2 }
                ?.invoke(media, true, false)
            mediaClass.methods.firstOrNull { it.name == "addOption" && it.parameterTypes.size == 1 }
                ?.let { addOption ->
                    listOf(
                        ":network-caching=5000",
                        ":file-caching=3000",
                        ":avcodec-hw=any",
                        ":no-drop-late-frames=false",
                        ":no-skip-frames=false"
                    ).forEach { addOption.invoke(media, it) }
                }
            mediaPlayerClass.methods.firstOrNull { it.name == "setMedia" && it.parameterTypes.size == 1 }
                ?.invoke(mediaPlayer, media)
            mediaClass.methods.firstOrNull { it.name == "release" && it.parameterTypes.isEmpty() }?.invoke(media)
            mediaPlayerClass.methods.firstOrNull { it.name == "play" && it.parameterTypes.isEmpty() }?.invoke(mediaPlayer)
            if (startPositionMs > 0L) {
                surfaceHost.postDelayed({ seekTo(startPositionMs) }, 900L)
            }
            startedAtMs = SystemClock.elapsedRealtime()
            Log.i(TAG, "PLAYER_VLC_START: title=${title.take(60)} urlHost=${runCatching { Uri.parse(url).host }.getOrNull().orEmpty()} startMs=$startPositionMs overlay=debrid_channels_existing hwDecode=any minimalStreamingProfile=true")
            true
        }.onFailure {
            Log.e(TAG, "PLAYER_VLC_START_FAILED: ${it.javaClass.simpleName}:${it.message}", it)
            release()
        }.getOrDefault(false)
    }

    fun play() { invokeNoArg("play") }
    fun pause() { invokeNoArg("pause") }
    fun stop() { invokeNoArg("stop") }

    fun isPlaying(): Boolean = runCatching {
        mediaPlayer?.javaClass?.methods?.firstOrNull { it.name == "isPlaying" && it.parameterTypes.isEmpty() }?.invoke(mediaPlayer) as? Boolean ?: false
    }.getOrDefault(false)

    fun positionMs(): Long = runCatching {
        (mediaPlayer?.javaClass?.methods?.firstOrNull { it.name == "getTime" && it.parameterTypes.isEmpty() }?.invoke(mediaPlayer) as? Number)?.toLong() ?: 0L
    }.getOrDefault(0L).coerceAtLeast(0L)

    fun durationMs(): Long = runCatching {
        (mediaPlayer?.javaClass?.methods?.firstOrNull { it.name == "getLength" && it.parameterTypes.isEmpty() }?.invoke(mediaPlayer) as? Number)?.toLong() ?: 0L
    }.getOrDefault(0L).coerceAtLeast(0L)

    fun seekTo(positionMs: Long) {
        val target = positionMs.coerceAtLeast(0L)
        runCatching {
            mediaPlayer?.javaClass?.methods?.firstOrNull { it.name == "setTime" && it.parameterTypes.size == 1 }
                ?.invoke(mediaPlayer, target)
            Log.i(TAG, "PLAYER_VLC_SEEK: targetMs=$target")
        }.onFailure { Log.w(TAG, "PLAYER_VLC_SEEK_FAILED: ${it.message}") }
    }

    fun release() {
        runCatching { stop() }
        runCatching {
            mediaPlayer?.javaClass?.methods?.firstOrNull { it.name == "detachViews" && it.parameterTypes.isEmpty() }?.invoke(mediaPlayer)
        }
        runCatching {
            mediaPlayer?.javaClass?.methods?.firstOrNull { it.name == "release" && it.parameterTypes.isEmpty() }?.invoke(mediaPlayer)
        }
        runCatching {
            libVlc?.javaClass?.methods?.firstOrNull { it.name == "release" && it.parameterTypes.isEmpty() }?.invoke(libVlc)
        }
        mediaPlayer = null
        libVlc = null
        videoLayout = null
        runCatching { surfaceHost.removeAllViews(); surfaceHost.visibility = View.GONE }
        Log.i(TAG, "PLAYER_VLC_RELEASE: active=false")
    }

    private fun invokeNoArg(name: String) {
        runCatching { mediaPlayer?.javaClass?.methods?.firstOrNull { it.name == name && it.parameterTypes.isEmpty() }?.invoke(mediaPlayer) }
            .onFailure { Log.w(TAG, "PLAYER_VLC_${name.uppercase(Locale.US)}_FAILED: ${it.message}") }
    }

    companion object {
        private const val TAG = "DebridChannels"
        fun companionAvailability(): Availability {
            val hasLib = runCatching { Class.forName("org.videolan.libvlc.LibVLC") }.isSuccess
            val hasPlayer = runCatching { Class.forName("org.videolan.libvlc.MediaPlayer") }.isSuccess
            val hasLayout = runCatching { Class.forName("org.videolan.libvlc.util.VLCVideoLayout") }.isSuccess
            return if (hasLib && hasPlayer && hasLayout) {
                Availability(true, "libvlc_present minimalStreamingHookReady=true")
            } else {
                Availability(false, "libvlc_classes_missing lib=$hasLib player=$hasPlayer layout=$hasLayout")
            }.also { Log.i(TAG, "PLAYER_VLC_AVAILABILITY: available=${it.available} reason=${it.reason}") }
        }
    }
}
