package com.channelsdebrid.tv.playback

import android.content.Context
import android.os.Build
import android.util.Log
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MimeTypes
import java.util.Locale

/**
 * Production playback reliability layer for VOD.
 *
 * This is intentionally conservative. It does not change image/video quality,
 * but it does rank risky streams lower, records source failures, and applies
 * per-device codec safety rules before playback starts. v2 adds adaptive buffers, session stability memory, and safe silent-rebuffer decisions.
 */
object PlayerReliabilitySystem {
    private const val PREFS = "dc_player_reliability_v2"
    private const val TAG = "DebridChannels"

    data class SourceHealth(
        val score: Int,
        val tier: String,
        val reasons: List<String>,
        val risky: Boolean
    )

    data class DeviceProfile(
        val name: String,
        val maxStability: Boolean,
        val forceStereo: Boolean,
        val avoidAv1: Boolean,
        val avoidOpus: Boolean,
        val avoidTunneling: Boolean,
        val preferAvcHevc: Boolean
    )

    data class BufferPlan(
        val minBufferMs: Int,
        val maxBufferMs: Int,
        val bufferForPlaybackMs: Int,
        val bufferForPlaybackAfterRebufferMs: Int,
        val label: String
    )

    data class SessionStability(
        val safeMode: Boolean,
        val reason: String,
        val minSilentRebufferMs: Long,
        val audioRouteDebounceMs: Long
    )

    fun deviceProfile(): DeviceProfile {
        val device = listOf(Build.MANUFACTURER, Build.BRAND, Build.MODEL, Build.DEVICE, Build.PRODUCT)
            .joinToString(" ") { it.orEmpty() }
            .lowercase(Locale.US)
        val xgimi = device.contains("xgimi") || device.contains("galileo") || device.contains("xk03h")
        val deviceProfile = PlayerDeviceProfileSystem.current()
        return DeviceProfile(
            name = deviceProfile.id,
            maxStability = true,
            forceStereo = xgimi || deviceProfile.forceStereoOnRisk,
            avoidAv1 = xgimi || deviceProfile.avoidAv1,
            avoidOpus = xgimi || deviceProfile.avoidVorbisOpus,
            avoidTunneling = deviceProfile.forceNoTunneling,
            preferAvcHevc = true
        )
    }

    fun scoreSource(label: String, title: String, url: String = "", storedPenalty: Int = 0): SourceHealth {
        val haystack = listOf(label, title, url).joinToString(" ").lowercase(Locale.US)
        var score = 70 - storedPenalty.coerceIn(0, 60)
        val reasons = mutableListOf<String>()
        fun add(points: Int, reason: String) {
            score += points
            reasons += reason
        }

        when {
            haystack.contains("remux") -> add(6, "remux")
            haystack.contains("bluray") || haystack.contains("blu-ray") -> add(8, "bluray")
            haystack.contains("web-dl") || haystack.contains("webdl") -> add(7, "web-dl")
            haystack.contains("webrip") -> add(3, "webrip")
        }
        if (haystack.contains("h264") || haystack.contains("x264") || haystack.contains("avc")) add(12, "safe h264")
        if (haystack.contains("h265") || haystack.contains("x265") || haystack.contains("hevc")) add(6, "hevc")
        if (haystack.contains("aac")) add(8, "safe aac")
        if (haystack.contains("ac3") || haystack.contains("eac3") || haystack.contains("dd+")) add(4, "dolby audio")

        if (haystack.contains("av1")) add(-22, "risky av1 on some TVs")
        if (haystack.contains("vorbis")) add(-16, "risky vorbis on some TVs")
        if (haystack.contains("opus")) add(-14, "risky opus on some TVs")
        if (haystack.contains("truehd")) add(-8, "truehd may require passthrough")
        if (haystack.contains("dts-hd") || haystack.contains("dts hd")) add(-8, "dts-hd may require passthrough")
        if (haystack.contains("cam") || haystack.contains("telesync") || haystack.contains("ts ")) add(-20, "low reliability encode")
        if (storedPenalty > 0) reasons += "history penalty $storedPenalty"

        score = score.coerceIn(0, 100)
        val tier = when {
            score >= 82 -> "Best"
            score >= 68 -> "Stable"
            score >= 50 -> "Usable"
            else -> "Risky"
        }
        return SourceHealth(score, tier, reasons.distinct().take(5), tier == "Risky")
    }

    fun sourceKey(url: String, label: String): String {
        val clean = (url.ifBlank { label }).lowercase(Locale.US)
        return clean.hashCode().toUInt().toString(16)
    }

    fun storedPenalty(context: Context, sourceKey: String): Int {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val fails = prefs.getInt("fail_$sourceKey", 0)
        val stalls = prefs.getInt("stall_$sourceKey", 0)
        return (fails * 18 + stalls * 8).coerceAtMost(60)
    }

    fun recordSourceEvent(context: Context, sourceKey: String, event: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val key = when (event) {
            "error", "idle", "decoder" -> "fail_$sourceKey"
            "stall" -> "stall_$sourceKey"
            else -> "ok_$sourceKey"
        }
        val current = prefs.getInt(key, 0)
        prefs.edit().putInt(key, (current + 1).coerceAtMost(25)).apply()
        Log.w(TAG, "PLAYER_SOURCE_HEALTH_EVENT: key=$sourceKey event=$event count=${current + 1}")
    }

    fun recordSuccessfulStart(context: Context, sourceKey: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val failKey = "fail_$sourceKey"
        val stallKey = "stall_$sourceKey"
        prefs.edit()
            .putInt(failKey, (prefs.getInt(failKey, 0) - 1).coerceAtLeast(0))
            .putInt(stallKey, (prefs.getInt(stallKey, 0) - 1).coerceAtLeast(0))
            .apply()
        Log.i(TAG, "PLAYER_SOURCE_HEALTH_SUCCESS: key=$sourceKey")
    }

    fun isRiskySelectedFormat(format: Format): Boolean {
        val raw = listOf(format.sampleMimeType, format.codecs).filterNotNull().joinToString(" ").lowercase(Locale.US)
        return raw.contains("av01") || raw.contains("av1") || raw.contains("opus") || raw.contains("vorbis") || raw.contains("truehd") || raw.contains("dts")
    }

    fun preferredVideoMimes(profile: DeviceProfile): Array<String> {
        return if (profile.avoidAv1) {
            arrayOf(MimeTypes.VIDEO_DOLBY_VISION, MimeTypes.VIDEO_H265, MimeTypes.VIDEO_H264)
        } else {
            arrayOf(MimeTypes.VIDEO_DOLBY_VISION, MimeTypes.VIDEO_H265, MimeTypes.VIDEO_H264, MimeTypes.VIDEO_AV1)
        }
    }

    fun preferredAudioMimes(profile: DeviceProfile, forceStereo: Boolean): Array<String> {
        return if (forceStereo || profile.avoidOpus) {
            arrayOf(MimeTypes.AUDIO_AAC, MimeTypes.AUDIO_AC3, MimeTypes.AUDIO_E_AC3, MimeTypes.AUDIO_MPEG)
        } else {
            arrayOf(MimeTypes.AUDIO_E_AC3_JOC, MimeTypes.AUDIO_E_AC3, MimeTypes.AUDIO_AC3, MimeTypes.AUDIO_AAC, MimeTypes.AUDIO_OPUS)
        }
    }

    fun trackRoleFlagsDescription(): String = "stable-first no-tunneling decoder-fallback source-scoring safe-checkpoints adaptive-buffering silent-rebuffer"


    fun adaptiveVodBufferPlan(profile: DeviceProfile, health: SourceHealth, nasVodCacheActive: Boolean): BufferPlan {
        if (nasVodCacheActive) {
            return BufferPlan(300_000, 28_800_000, 1_500, 3_000, "nas_full_ahead_final")
        }
        val risky = health.risky || health.score < 68 || profile.maxStability
        return if (risky) {
            BufferPlan(45_000, 300_000, 2_500, 5_000, "adaptive_stability_safe")
        } else {
            BufferPlan(24_000, 210_000, 1_500, 3_500, "adaptive_balanced_stable")
        }
    }

    fun sessionStability(profile: DeviceProfile, health: SourceHealth, routeRisk: Boolean): SessionStability {
        val safe = profile.maxStability || health.risky || routeRisk || health.score < 68
        val reason = when {
            routeRisk -> "audio_route_risk"
            health.risky -> "source_risky"
            health.score < 68 -> "source_score_${health.score}"
            profile.maxStability -> "device_max_stability"
            else -> "normal"
        }
        return SessionStability(
            safeMode = safe,
            reason = reason,
            minSilentRebufferMs = if (safe) 7_000L else 4_000L,
            audioRouteDebounceMs = if (routeRisk) 1_500L else 800L
        )
    }

    fun shouldSilentRebuffer(
        isVodMode: Boolean,
        firstFrameRendered: Boolean,
        playbackState: Int,
        isPlaying: Boolean,
        bufferedPercentage: Int,
        stalledTicks: Int
    ): Boolean {
        if (!isVodMode || !firstFrameRendered) return false
        if (playbackState == androidx.media3.common.Player.STATE_IDLE) return false
        return !isPlaying && bufferedPercentage < 8 && stalledTicks >= 2
    }

}
