package com.channelsdebrid.tv.playback

import android.os.Build
import android.util.Log
import java.util.Locale

/**
 * Device-specific playback profile layer for v2.8.23.3.
 *
 * This is the safe, production path: keep Android MediaCodec hardware acceleration active
 * through Media3/ExoPlayer, but bias codec/audio/renderer choices away from paths that
 * are known to destabilize Android TV projectors and low-memory TV boxes.
 */
object PlayerDeviceProfileSystem {
    private const val TAG = "DebridChannels"

    enum class DecodePreference { AUTO_SAFE, HARDWARE_FIRST, SOFTWARE_FALLBACK_READY }
    enum class GpuOutputMode { ANDROID_SURFACEVIEW_HW_COMPOSITION, MPV_GPU_NEXT_FOUNDATION }
    enum class InternalPlayer { MEDIA3_DEFAULT, MPV_OPTIONAL_FOUNDATION }

    data class DevicePlaybackProfile(
        val id: String,
        val decodePreference: DecodePreference,
        val gpuOutputMode: GpuOutputMode,
        val internalPlayer: InternalPlayer,
        val preferSurfaceView: Boolean,
        val forceNoTunneling: Boolean,
        val forceStereoOnRisk: Boolean,
        val avoidAv1: Boolean,
        val avoidVorbisOpus: Boolean,
        val avoidDtsTrueHd: Boolean,
        val preferDolbyVisionFallbackToHevc: Boolean,
        val maxVideoStartupHeight: Int,
        val notes: String
    )

    fun current(): DevicePlaybackProfile {
        val raw = listOf(Build.MANUFACTURER, Build.BRAND, Build.MODEL, Build.DEVICE, Build.PRODUCT)
            .joinToString(" ") { it.orEmpty() }
            .lowercase(Locale.US)
        val isXgimi = raw.contains("xgimi") || raw.contains("galileo") || raw.contains("xk03h")
        val isShield = raw.contains("nvidia") || raw.contains("shield")
        val isFireTv = raw.contains("amazon") || raw.contains("aft") || raw.contains("fire")
        return when {
            isXgimi -> DevicePlaybackProfile(
                id = "XGIMI_MAX_STABILITY_GPU_HW_SAFE",
                decodePreference = DecodePreference.AUTO_SAFE,
                gpuOutputMode = GpuOutputMode.ANDROID_SURFACEVIEW_HW_COMPOSITION,
                internalPlayer = InternalPlayer.MEDIA3_DEFAULT,
                preferSurfaceView = true,
                forceNoTunneling = true,
                forceStereoOnRisk = true,
                avoidAv1 = true,
                avoidVorbisOpus = true,
                avoidDtsTrueHd = true,
                preferDolbyVisionFallbackToHevc = true,
                maxVideoStartupHeight = 2160,
                notes = "XGIMI/MediaTek route: hardware acceleration on, tunneling/offload avoided, risky audio/video codecs deprioritized."
            )
            isShield -> DevicePlaybackProfile(
                id = "SHIELD_TV_HW_PLUS_STABLE",
                decodePreference = DecodePreference.HARDWARE_FIRST,
                gpuOutputMode = GpuOutputMode.ANDROID_SURFACEVIEW_HW_COMPOSITION,
                internalPlayer = InternalPlayer.MEDIA3_DEFAULT,
                preferSurfaceView = true,
                forceNoTunneling = false,
                forceStereoOnRisk = false,
                avoidAv1 = false,
                avoidVorbisOpus = false,
                avoidDtsTrueHd = false,
                preferDolbyVisionFallbackToHevc = true,
                maxVideoStartupHeight = 2160,
                notes = "Shield profile: hardware-first while preserving decoder fallback."
            )
            isFireTv -> DevicePlaybackProfile(
                id = "FIRE_TV_BALANCED_STABILITY",
                decodePreference = DecodePreference.AUTO_SAFE,
                gpuOutputMode = GpuOutputMode.ANDROID_SURFACEVIEW_HW_COMPOSITION,
                internalPlayer = InternalPlayer.MEDIA3_DEFAULT,
                preferSurfaceView = true,
                forceNoTunneling = true,
                forceStereoOnRisk = false,
                avoidAv1 = false,
                avoidVorbisOpus = true,
                avoidDtsTrueHd = true,
                preferDolbyVisionFallbackToHevc = true,
                maxVideoStartupHeight = 2160,
                notes = "Fire TV profile: balanced hardware acceleration with safe audio routing."
            )
            else -> DevicePlaybackProfile(
                id = "GENERIC_ANDROID_TV_SAFE_HW",
                decodePreference = DecodePreference.AUTO_SAFE,
                gpuOutputMode = GpuOutputMode.ANDROID_SURFACEVIEW_HW_COMPOSITION,
                internalPlayer = InternalPlayer.MEDIA3_DEFAULT,
                preferSurfaceView = true,
                forceNoTunneling = true,
                forceStereoOnRisk = false,
                avoidAv1 = false,
                avoidVorbisOpus = true,
                avoidDtsTrueHd = true,
                preferDolbyVisionFallbackToHevc = true,
                maxVideoStartupHeight = 2160,
                notes = "Generic Android TV: hardware acceleration on through MediaCodec, decoder fallback preserved."
            )
        }
    }

    fun logActiveProfile() {
        val p = current()
        Log.i(TAG, "PLAYER_DEVICE_PROFILE_ACTIVE: id=${p.id} decode=${p.decodePreference} gpu=${p.gpuOutputMode} internalPlayer=${p.internalPlayer} surfaceView=${p.preferSurfaceView} noTunneling=${p.forceNoTunneling} avoidAv1=${p.avoidAv1} avoidVorbisOpus=${p.avoidVorbisOpus} avoidDtsTrueHd=${p.avoidDtsTrueHd}")
        Log.i(TAG, "PLAYER_GPU_HW_ACCELERATION_ACTIVE: androidSurfaceViewHardwareComposition=true mediaCodecHardwareDecode=auto fallbackEnabled=true forcedSoftware=false forcedHardwareOnly=false")
    }
}
