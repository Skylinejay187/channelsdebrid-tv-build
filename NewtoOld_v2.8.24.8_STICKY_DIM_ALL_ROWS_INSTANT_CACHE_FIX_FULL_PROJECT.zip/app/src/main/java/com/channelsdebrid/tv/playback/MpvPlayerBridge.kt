package com.channelsdebrid.tv.playback

import android.content.Context
import android.util.Log

/**
 * Optional MPV internal-player foundation for v2.8.23.3.
 *
 * Nuvio-style MPV playback needs native libmpv binaries and Gradle packaging for each ABI.
 * This bridge is intentionally safe: it exposes the app-side selection point and diagnostics
 * without adding an unbundled native dependency that would break APK builds. When libmpv is
 * added later, this bridge is where MPV GPU/HW/SW decode modes should be connected.
 */
object MpvPlayerBridge {
    private const val TAG = "DebridChannels"

    enum class MpvDecodeMode { AUTO, HARDWARE, SOFTWARE }

    data class Availability(
        val available: Boolean,
        val reason: String,
        val recommendedDecodeMode: MpvDecodeMode
    )

    fun availability(context: Context): Availability {
        // Keep this reflection-based so the app compiles without native MPV artifacts.
        val hasMpv = runCatching { Class.forName("is.xyz.mpv.MPVLib") }.isSuccess ||
            runCatching { Class.forName("com.nuvoioplayer.mpv.MPVLib") }.isSuccess
        return if (hasMpv) {
            Availability(true, "native_libmpv_found", MpvDecodeMode.AUTO)
        } else {
            Availability(false, "native_libmpv_not_bundled_media3_active", MpvDecodeMode.AUTO)
        }.also {
            Log.i(TAG, "PLAYER_MPV_FOUNDATION: available=${it.available} reason=${it.reason} decodeMode=${it.recommendedDecodeMode} gpuNext=true safeFallbackToMedia3=true")
        }
    }
}
