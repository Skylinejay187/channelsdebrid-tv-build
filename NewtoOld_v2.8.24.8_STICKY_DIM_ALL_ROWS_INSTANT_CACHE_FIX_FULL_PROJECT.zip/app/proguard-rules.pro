# Debrid Channels release shrink rules
# Keep VLC/libVLC JNI-facing classes and native entry points.
-keep class org.videolan.** { *; }
-keep class libcore.** { *; }
-dontwarn org.videolan.**
-dontwarn androidx.media3.**

# Keep app model classes used reflectively by simple JSON parsing / intents.
-keep class com.channelsdebrid.tv.** { *; }
