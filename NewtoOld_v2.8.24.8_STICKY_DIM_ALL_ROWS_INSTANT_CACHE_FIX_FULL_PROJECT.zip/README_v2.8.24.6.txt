NewtoOld v2.8.24.6 CLEAN_CORE_FULL_REWRITE_STABLE

Fixes compile errors from v2.8.24.5 and wires Pro Layout Editor dim-unfocused-cards into actual row card alpha. Preserves VLC dual ARM ABI, player engine selector, persistent cache, search fix, and Live TV guide artwork support.
