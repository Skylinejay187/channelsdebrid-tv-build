# NewtoOld v2.8.22.4 VOD Unexpected Idle Recovery Audit

Base: v2.8.22.3 clean source.

Fixes:
- Added VOD unexpected IDLE detection after first frame.
- If ExoPlayer silently drops to IDLE with playWhenReady=true, playback now retries safely instead of staying stopped.
- XGIMI/A2DP route-risk path now triggers safe stereo fallback before normal reprepare.
- Preserved Cast & Crew / person-detail foundation and all previous hero/row/media info fixes.

Markers:
- PLAYER_UNEXPECTED_IDLE_AFTER_FIRST_FRAME
- PLAYER_UNEXPECTED_IDLE_RECOVERY
- PLAYER_UNEXPECTED_IDLE_REPREPARE

Version: 282124 / NewtoOld_v2.8.22.4_VOD_UNEXPECTED_IDLE_RECOVERY_FIX
