# NewtoOld v2.8.24.7 Menu Hold Last Card Highlight Fix

- Preserves latest clean-core v2.8.24.6 base and all previously added features.
- Fixes top-row DPAD_UP behavior so the last focused row card keeps its visual focus ring/scale/logo/genre state while the top/side menu has actual focus.
- Clears the visual hold when focus returns to a card or a menu action launches a new section.
- Adds log marker: MENU_HOLD_LAST_CARD_HIGHLIGHT.
- Version updated to 282147 / NewtoOld_v2.8.24.7_MENU_HOLD_LAST_CARD_HIGHLIGHT_FIX.
