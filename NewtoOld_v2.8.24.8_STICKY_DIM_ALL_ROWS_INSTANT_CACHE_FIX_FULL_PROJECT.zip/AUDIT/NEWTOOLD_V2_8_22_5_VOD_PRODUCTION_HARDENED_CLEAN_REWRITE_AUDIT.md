# NewtoOld v2.8.22.5 VOD Production Hardened Clean Rewrite Audit

Base used: NewtoOld_v2.8.22.4_VOD_UNEXPECTED_IDLE_RECOVERY_FIX_FULL_PROJECT.zip.

Clean rewrite scope:
- Consolidated VOD stop/idle recovery into a production recovery path instead of one-shot patch behavior.
- Added audio route protection for Android TV / XGIMI Bluetooth and headset route events.
- Added last-known-good VOD position tracking and automatic resume after route/player stalls.
- Added bounded recovery window, debounce, and full ExoPlayer rebuild fallback after repeated IDLE/stall events.
- Preserved hero renderer, inline episodes, cast/crew person foundation, row focus behavior, Pro Layout Editor settings, artwork loading, and version/log markers.
- Updated versionName/versionCode to v2.8.22.5 / 282125.

Known runtime verification required:
- Test on XGIMI Horizon Pro with and without Bluetooth/A2DP.
- Capture log markers: PLAYER_AUDIO_ROUTE_EVENT, PLAYER_ROUTE_RESUME_CHECK, PLAYER_VOD_RECOVERY_START, PLAYER_VOD_RECOVERY_APPLIED, PLAYER_VOD_FULL_REBUILD.
