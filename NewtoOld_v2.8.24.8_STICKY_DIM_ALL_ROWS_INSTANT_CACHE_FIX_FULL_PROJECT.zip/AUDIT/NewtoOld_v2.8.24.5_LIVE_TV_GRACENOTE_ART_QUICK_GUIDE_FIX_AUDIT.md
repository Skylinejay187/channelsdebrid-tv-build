# NewtoOld v2.8.24.5 — Live TV Gracenote-style Artwork / Quick Guide Fix

Base: NewtoOld_v2.8.24.4_PERSISTENT_ARTWORK_CATALOG_CACHE_SPEED_FIX

Clean-core intent:
- Preserve existing VOD player hardening, Exo/VLC fallback selector, persistent catalog/artwork cache, search fix, Pro Layout Editor features, DPAD behavior, hero/focus systems, and all previous UI fixes.
- Add Live TV guide artwork support without direct Gracenote scraping.

Implemented:
- Quick Guide now accepts current-program artwork via `programImageUrl` in PlayerActivity channel JSON.
- Player live overlay backdrop uses current program artwork when available.
- Regular Live TV guide program cards can show program thumbnail art behind text when `imageUrl` exists in XMLTV/EPG program data.
- LiveTvActivity now serializes `programImageUrl` and `nextImageUrl` for PlayerActivity.
- Live TV selection preview prefers current program artwork before local fallback backgrounds.
- Artwork loads through existing image proxy/cache path and uses Glide disk caching.

Important licensing/data rule:
- This does not scrape Gracenote. It displays guide artwork only when a provider/backend/XMLTV feed supplies image URLs or when your backend maps programs to licensed artwork.

VLC size note:
- VLC size is already reduced to ARM-only/x86 removed in prior builds. The remaining real reduction requires a custom-built minimal libVLC AAR. Gradle cannot remove DVD/Blu-ray/Chromecast/screen-capture modules from the full prebuilt libVLC AAR.

Markers:
- DC_BUILD_MARKER: NewtoOld_v2.8.24.5_LIVE_TV_GRACENOTE_ART_QUICK_GUIDE_FIX
- LIVE_GUIDE_PROGRAM_ART_PREWARM
