# NewtoOld v2.8.24.2 VLC ARM dual-ABI install fix

- Restores armeabi-v7a alongside arm64-v8a because the XGIMI install failed with INSTALL_FAILED_NO_MATCHING_ABIS when arm64-only was packaged.
- Keeps x86 and x86_64 excluded to reduce size.
- Keeps no ABI split block to avoid Gradle conflict with ndk abiFilters.
- Preserves ExoPlayer + VLC fallback/player-engine selector and previous playback hardening.
- Version marker updated to DC_BUILD_MARKER: NewtoOld_v2.8.24.2_VLC_ARM_DUAL_ABI_INSTALL_FIX.
