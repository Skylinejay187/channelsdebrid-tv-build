# NewtoOld v2.8.22.3 Cast/Crew Person + XGIMI Audio Route Audit

Base: NewtoOld_v2.8.22.2_FINAL_COMPILE_FIX_GLIDE_LOCKED_FULL_PROJECT.zip

Rules honored:
- Clean additive/stabilizing build from latest known-good source zip.
- Preserved previous hero fade, inline episodes, media info, Pro Layout Editor, row focus, and Glide listener removal fixes.
- Updated app versionName/versionCode to match zip naming.

Changes:
- Media information cast avatars are now focusable/clickable.
- Added PersonDetailsActivity to show cast/crew person info and TMDB known-for / filmography cards when a TMDB key is configured.
- Person filmography cards open the media information page for the selected movie/show.
- Added VOD player overlay Cast button that opens the cast/crew flow from playback without changing source selection code.
- Added XGIMI/A2DP safer audio-route behavior by disabling extension renderers when XGIMI/safe-stereo route mode is active and logging the route state.

Log interpretation from supplied device log:
- The log does not show a DebridChannels fatal crash near playback.
- It does show system-level A2DP/audio stack warnings/errors:
  - AS.AudioDeviceInventory command error
  - audio_hw_primary A2DP open
  - AE_primary_process bytes/frames zero
  - BTAudioHalDeviceProxy A2DP software encoding path
- This points more toward XGIMI/Android audio-route instability than an app UI crash.
