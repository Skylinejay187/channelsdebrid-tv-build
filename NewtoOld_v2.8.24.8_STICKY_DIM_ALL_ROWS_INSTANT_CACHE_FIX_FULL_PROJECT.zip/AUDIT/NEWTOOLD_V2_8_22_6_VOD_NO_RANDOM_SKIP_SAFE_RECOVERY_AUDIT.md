# NewtoOld v2.8.22.6 VOD No-Random-Skip Safe Recovery Audit

Base used: v2.8.22.5 hardened clean rewrite.

Reason: User reported playback randomly skipped ahead. Log also showed the installed device was still running v2.8.21.9, so this build adds unmistakable markers and removes the risky recovery paths that can create false-positive seeks.

Changes:
- Removed watchdog-driven seek/reprepare/rebuild behavior for VOD. Watchdog is now log/play-only.
- Removed audio-route/noisy broadcast auto-resume seeking. Route events are log-only to avoid false positives on XGIMI/A2DP firmware.
- READY-but-not-playing path now calls play only and never seekTo.
- Recovery position now uses a safe current position, never max(current,lastKnownGood), to prevent forward jumps from bogus player positions.
- Actual STATE_IDLE and PlayerError remain the only controlled recovery paths.

Verification markers:
- DC_BUILD_MARKER should show NewtoOld_v2.8.22.6_VOD_NO_RANDOM_SKIP_SAFE_RECOVERY.
- PLAYER_VOD_SAFE_RECOVERY_MODE: no_watchdog_seek no_route_seek safe_resume_position actual_idle_only.
- PLAYBACK_STALL_WATCHDOG_LOG_ONLY should appear instead of PLAYBACK_STALL_RECOVERY if a stall is suspected.

Preserved:
- Cast/Crew person details foundation, inline episodes, hero fade work, row systems, Pro Layout Editor, speed/image cache fixes, and previous compile fixes.

Version: 282126 / NewtoOld_v2.8.22.6_VOD_NO_RANDOM_SKIP_SAFE_RECOVERY
