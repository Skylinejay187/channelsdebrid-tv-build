NewtoOld_v2.8.23.2_FINAL_PLAYBACK_HARDENING

versionCode: 282156
versionName: NewtoOld_v2.8.25.6_VOD_OVERLAY_REMOVE_CAST_ZOOM_VISIBLE_FIX

Final playback hardening build with adaptive buffering, safe watchdog, silent rebuffer, decoder/source reliability memory, audio-route debounce, and session stability mode.

Verify logcat marker:
DC_BUILD_MARKER: NewtoOld_v2.8.25.6_VOD_OVERLAY_REMOVE_CAST_ZOOM_VISIBLE_FIX
