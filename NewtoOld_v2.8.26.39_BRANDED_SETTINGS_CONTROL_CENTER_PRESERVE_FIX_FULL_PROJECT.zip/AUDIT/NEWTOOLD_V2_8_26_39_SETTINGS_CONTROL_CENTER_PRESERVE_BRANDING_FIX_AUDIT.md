# NewtoOld v2.8.26.39 Settings Control Center Preserve Branding Fix

Base: NewtoOld_v2.8.26.39_BRANDING_ICON_STARTUP_FINAL_FIX_FULL_PROJECT.zip.

Rules followed:
- Preserved approved launcher/startup branding assets from the branded build.
- Did not use the broken settings branch as base.
- Did not touch Live TV loaders, provider-direct streaming, BunnyCDN wiring, backend URLs, playback, row renderer, or low-end performance mode.

Settings fixes:
- Enlarged TV sidebar rows and made them focusable/clickable.
- Added focus-safe orange/black sidebar selector states.
- Added clickable/focusable Quick Access cards.
- Added stale-reference-safe Kotlin wiring for sidebar and quick cards.
- Escaped XML entities and avoided drawable-nodpi references in XML attributes.
- Preserved existing settings section includes so old functional setting fields still exist.

Verification:
- activity_settings.xml parses successfully as XML.
- Gradle is not installed in this sandbox; project is prepared for the user's GitHub Action build pipeline.
