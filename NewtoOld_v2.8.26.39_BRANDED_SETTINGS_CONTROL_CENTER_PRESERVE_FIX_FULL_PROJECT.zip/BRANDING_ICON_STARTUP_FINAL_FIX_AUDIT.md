# Debrid Channels branding/icon/startup final fix audit

Base: NewtoOld v2.8.26.39 low-end performance/settings control center line.

Fixes in this package:
- Replaced launcher mipmap icons at mdpi/hdpi/xhdpi/xxhdpi/xxxhdpi.
- Replaced round launcher mipmaps.
- Replaced adaptive icon foreground resource at `res/drawable/ic_launcher_foreground.png`.
- Preserved adaptive XML references to `@drawable/ic_launcher_foreground` and `@color/launcher_black`.
- Replaced Android TV banner with dark Debrid Channels branding.
- Added `startup_logo_clean.png` for the startup animation.
- Rebuilt `StartupActivity` to use a black cinematic background, centered Debrid Channels logo, and animated orange loading bar.
- Removed the visible LOADING text from the startup screen.
- Avoided using the full brand sheet as a splash image to prevent cropping.
- XML resource text was checked for raw ampersand entity issues.

Preserved:
- Low-end Android TV performance mode work.
- Live TV systems.
- Provider-direct IPTV behavior.
- Bunny artwork systems.
- Existing package name and app label.

Install/testing note:
Android TV launchers cache icons aggressively. If the launcher still shows the old icon after installing, uninstall the previous app build first or clear the launcher cache, then reinstall.
