package com.channelsdebrid.tv

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class StartupActivity : AppCompatActivity() {
    private companion object { private const val TAG = "DebridChannels" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i(TAG, "STARTUP_BRANDING_V2_8_26_39: cinematic-logo animated-orange-bar no-loading-text")

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        val glow = View(this).apply {
            alpha = 0f
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                0x00FF8A00,
                0x33FF8A00,
                0x00FF8A00
            )).apply {
                shape = GradientDrawable.OVAL
                gradientType = GradientDrawable.RADIAL_GRADIENT
                gradientRadius = dp(440).toFloat()
            }
        }
        root.addView(glow, FrameLayout.LayoutParams(dp(920), dp(520), Gravity.CENTER))

        val logo = ImageView(this).apply {
            setImageResource(resources.getIdentifier("startup_logo_clean", "drawable", packageName))
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            alpha = 0f
            translationY = dp(10).toFloat()
        }
        root.addView(logo, FrameLayout.LayoutParams(dp(760), dp(420), Gravity.CENTER).apply {
            bottomMargin = dp(38)
        })

        val barTrack = View(this).apply {
            alpha = 0f
            background = rounded(0x332A2A2A, dp(7).toFloat())
        }
        root.addView(barTrack, FrameLayout.LayoutParams(dp(520), dp(7), Gravity.CENTER).apply {
            topMargin = dp(330)
        })

        val barFill = View(this).apply {
            alpha = 0f
            scaleX = 0.12f
            pivotX = 0f
            background = roundedGradient()
        }
        root.addView(barFill, FrameLayout.LayoutParams(dp(520), dp(7), Gravity.CENTER).apply {
            topMargin = dp(330)
        })

        val flare = View(this).apply {
            alpha = 0f
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(
                0x00FF8A00,
                0xFFFFB04A.toInt(),
                0x00FF8A00
            )).apply { cornerRadius = dp(3).toFloat() }
        }
        root.addView(flare, FrameLayout.LayoutParams(dp(70), dp(5), Gravity.CENTER).apply {
            topMargin = dp(330)
        })

        setContentView(root)

        AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(glow, "alpha", 0f, 1f).setDuration(450),
                ObjectAnimator.ofFloat(logo, "alpha", 0f, 1f).setDuration(520),
                ObjectAnimator.ofFloat(logo, "translationY", dp(14).toFloat(), 0f).setDuration(520),
                ObjectAnimator.ofFloat(barTrack, "alpha", 0f, 1f).setDuration(560),
                ObjectAnimator.ofFloat(barFill, "alpha", 0f, 1f).setDuration(560),
                ObjectAnimator.ofFloat(flare, "alpha", 0f, 1f).setDuration(560)
            )
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
        ObjectAnimator.ofFloat(barFill, "scaleX", 0.10f, 0.82f).apply {
            duration = 1150
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
        ObjectAnimator.ofFloat(flare, "translationX", -dp(220).toFloat(), dp(175).toFloat()).apply {
            duration = 1150
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
        ObjectAnimator.ofFloat(glow, "rotation", 0f, 8f).apply {
            duration = 1300
            interpolator = LinearInterpolator()
            start()
        }

        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }, 1250)
    }

    private fun rounded(color: Int, radius: Float): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private fun roundedGradient(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.LEFT_RIGHT,
        intArrayOf(0xFFFF7A00.toInt(), 0xFFFFB24A.toInt(), 0xFFFF7A00.toInt())
    ).apply { cornerRadius = dp(7).toFloat() }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
