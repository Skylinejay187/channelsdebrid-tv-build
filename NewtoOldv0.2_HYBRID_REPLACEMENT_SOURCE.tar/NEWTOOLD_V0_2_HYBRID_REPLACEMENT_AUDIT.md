# NewtoOldv0.2 Hybrid Replacement Audit

Base: `debridchannelsApp_v2.1.0_TRUE_CLEAN_CORE_FULL_REWRITE.zip`.
Donor/reference: `DebridChannels_v0_9_8_3_CI_JSON_EXCEPTION_FIX_CLEAN_SOURCE.zip`.

## Requested replacement/add scope
1. Replace row card system behavior bridge with new-app style row adapter helpers/logging.
2. Replace Live TV stream logic only. UI/layout is intentionally untouched; endpoints are normalized before the existing UI/player receives channels.
3. Replace top menu bar chrome while preserving existing IDs and DPAD routes.
4. Add 3D extra artwork controls to the old app layout editor.
5. Add the ability to hide/remove row text from the old app layout editor.
6. Preserve trailers only for the media information/details section; hero trailer autoplay is disabled.

## Do not remove / untouched scope
Everything else was intentionally left in place: player, existing Live TV UI/layout, DPAD navigation IDs, backend/artwork loading, media details trailer path, settings framework, and all other old app behavior unless explicitly listed above.

## Carry-forward cleanup from NewtoOldv0.1
- Channels DVR auto-detect disabled.
- Timeshift defaults disabled for future rewrite.
- Hero trailers disabled.
- Real Debrid / Torbox should remain out of the active resolver path from the cleanup branch.

## Debug markers
- `DC_BUILD_MARKER: NewtoOldv0.2`
- `ROW_SYSTEM: NEW_APP_STRUCTURE_ACTIVE`
- `LIVE_STREAM_LOGIC: DONOR_ENDPOINT_RESOLVER_ACTIVE`
- `TOP_MENU_SYSTEM: DONOR_STYLE_ACTIVE`
- `EXTRA_ARTWORK_3D: ENABLED`
- `ROW_TEXT_VISIBILITY_CONTROL: ENABLED`
- `DETAIL_TRAILERS_ONLY: ENABLED`
