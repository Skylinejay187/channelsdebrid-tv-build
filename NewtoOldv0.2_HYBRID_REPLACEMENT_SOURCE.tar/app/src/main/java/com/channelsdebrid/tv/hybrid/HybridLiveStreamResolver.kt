package com.channelsdebrid.tv.hybrid
import android.util.Log
import com.channelsdebrid.tv.live.LiveSourceResolver
object HybridLiveStreamResolver {
    fun normalizeChannel(item: LiveSourceResolver.ChannelItem): LiveSourceResolver.ChannelItem {
        val url = normalizeUrl(item.url)
        Log.i("NewtoOldLive", "LIVE_STREAM_LOGIC: endpoint source=${item.source} name=${item.name}")
        return item.copy(url = url, debug = item.debug + " • newtoold-stream")
    }
    fun normalizeChannels(items: List<LiveSourceResolver.ChannelItem>): List<LiveSourceResolver.ChannelItem> =
        items.map(::normalizeChannel).distinctBy { it.source + "|" + it.number + "|" + it.name + "|" + it.url }
    fun normalizeUrl(raw: String): String {
        val url = raw.trim()
        if (url.startsWith("//")) return "https:$url"
        return url
    }
}
