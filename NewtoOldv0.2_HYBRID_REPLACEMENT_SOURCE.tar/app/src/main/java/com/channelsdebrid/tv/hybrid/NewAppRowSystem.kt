package com.channelsdebrid.tv.hybrid
import android.util.Log
import android.view.View
import android.widget.TextView
object NewAppRowSystem {
    fun applyRowTextVisibility(title: TextView, subtitle: TextView, visible: Boolean) {
        val state = if (visible) View.VISIBLE else View.GONE
        title.visibility = state
        subtitle.visibility = state
        Log.i("NewtoOldRows", "ROW_TEXT_VISIBILITY: ${if (visible) "VISIBLE" else "HIDDEN"}")
    }
    fun rowActivated(title: String, count: Int) {
        Log.i("NewtoOldRows", "ROW_SYSTEM: NEW_ACTIVE title=$title count=$count")
    }
}
