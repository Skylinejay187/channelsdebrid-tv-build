package com.channelsdebrid.tv.hybrid
import android.util.Log
object HybridBuildMarkers {
    const val BUILD = "NewtoOldv0.2"
    fun logStartup() {
        Log.i("NewtoOld", "DC_BUILD_MARKER: NewtoOldv0.2")
        Log.i("NewtoOld", "ROW_SYSTEM: NEW_APP_STRUCTURE_ACTIVE")
        Log.i("NewtoOld", "LIVE_STREAM_LOGIC: DONOR_ENDPOINT_RESOLVER_ACTIVE")
        Log.i("NewtoOld", "TOP_MENU_SYSTEM: DONOR_STYLE_ACTIVE")
        Log.i("NewtoOld", "EXTRA_ARTWORK_3D: ENABLED")
        Log.i("NewtoOld", "ROW_TEXT_VISIBILITY_CONTROL: ENABLED")
        Log.i("NewtoOld", "DETAIL_TRAILERS_ONLY: ENABLED")
    }
}
