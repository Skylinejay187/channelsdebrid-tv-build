package com.channelsdebrid.tv.playback

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.ui.PlayerView
import com.channelsdebrid.tv.R
import org.json.JSONArray
import org.json.JSONObject

class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var titleView: TextView
    private lateinit var statusView: TextView
    private lateinit var guideOverlay: View
    private lateinit var guideModeView: TextView
    private lateinit var guideTitleView: TextView
    private lateinit var guideMetaView: TextView
    private lateinit var guideHintView: TextView
    private lateinit var guideList: LinearLayout

    private val overlayHandler = Handler(Looper.getMainLooper())
    private val hideOverlayRunnable = Runnable {
        if (player?.isPlaying == true) hideGuideOverlay()
    }

    private var channels: List<GuideChannel> = emptyList()
    private var currentIndex: Int = 0
    private var selectedGuideIndex: Int = 0
    private var guideMode: GuideMode = GuideMode.QUICK

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        playerView = findViewById(R.id.playerView)
        titleView = findViewById(R.id.playerTitle)
        statusView = findViewById(R.id.playerStatus)
        guideOverlay = findViewById(R.id.guideOverlay)
        guideModeView = findViewById(R.id.guideMode)
        guideTitleView = findViewById(R.id.guideTitle)
        guideMetaView = findViewById(R.id.guideMeta)
        guideHintView = findViewById(R.id.guideHint)
        guideList = findViewById(R.id.guideChannelList)

        val streamUrl = intent.getStringExtra(EXTRA_STREAM_URL)
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val sourceLabel = intent.getStringExtra(EXTRA_SOURCE_LABEL).orEmpty()
        val debugLabel = intent.getStringExtra(EXTRA_DEBUG_LABEL).orEmpty()

        channels = decodeChannels(intent.getStringExtra(EXTRA_CHANNELS_JSON))
        currentIndex = intent.getIntExtra(EXTRA_CHANNEL_INDEX, 0).coerceIn(0, (channels.size - 1).coerceAtLeast(0))
        selectedGuideIndex = currentIndex

        titleView.text = if (title.isBlank()) "Playback" else title
        statusView.text = when {
            sourceLabel.isBlank() -> "Connecting…"
            debugLabel.isBlank() -> "Connecting to $sourceLabel…"
            else -> "Connecting to $sourceLabel…\n$debugLabel"
        }

        if (streamUrl.isNullOrBlank()) {
            Toast.makeText(this, "No stream URL available", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        initializePlayer(streamUrl, sourceLabel, debugLabel)
        renderGuideOverlay()
    }

    private fun initializePlayer(streamUrl: String, sourceLabel: String, debugLabel: String) {
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("ChannelsDebridTV/1.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10000)
            .setReadTimeoutMs(15000)

        val mediaSourceFactory = DefaultMediaSourceFactory(httpFactory)

        val exoPlayer = ExoPlayer.Builder(this)
            .setMediaSourceFactory(mediaSourceFactory)
            .build()
            .also { player = it }

        playerView.player = exoPlayer
        playerView.keepScreenOn = true

        val mediaItemBuilder = MediaItem.Builder().setUri(Uri.parse(streamUrl))
        if (looksLikeTsStream(streamUrl)) {
            mediaItemBuilder.setMimeType(MimeTypes.VIDEO_MP2T)
        }
        val mediaItem = mediaItemBuilder.build()

        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.addListener(object : androidx.media3.common.Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                statusView.visibility =
                    if (playbackState == androidx.media3.common.Player.STATE_READY) View.GONE else View.VISIBLE
                if (playbackState == androidx.media3.common.Player.STATE_BUFFERING) {
                    statusView.text = if (sourceLabel.isBlank()) "Buffering…" else "Buffering $sourceLabel…"
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                statusView.visibility = View.VISIBLE
                statusView.text = buildString {
                    append("Playback error: ")
                    append(error.errorCodeName)
                    if (sourceLabel.isNotBlank()) {
                        append("\nSource: ")
                        append(sourceLabel)
                    }
                    if (debugLabel.isNotBlank()) {
                        append("\n")
                        append(debugLabel)
                    }
                    append("\nURL: ")
                    append(streamUrl.take(140))
                }
                showGuideOverlay(GuideMode.FULL)
            }
        })
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)

        return when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> {
                moveGuideSelection(-1)
                true
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                moveGuideSelection(1)
                true
            }
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_GUIDE, KeyEvent.KEYCODE_G -> {
                toggleGuideMode()
                true
            }
            KeyEvent.KEYCODE_BACK -> {
                if (guideOverlay.isVisible) {
                    hideGuideOverlay()
                    true
                } else {
                    super.dispatchKeyEvent(event)
                }
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                if (guideOverlay.isVisible) {
                    playSelectedChannel()
                    true
                } else {
                    showGuideOverlay(GuideMode.QUICK)
                    true
                }
            }
            else -> super.dispatchKeyEvent(event)
        }
    }

    private fun moveGuideSelection(delta: Int) {
        if (channels.isEmpty()) return
        if (!guideOverlay.isVisible) {
            selectedGuideIndex = currentIndex
            showGuideOverlay(GuideMode.QUICK)
        }
        selectedGuideIndex = (selectedGuideIndex + delta).coerceIn(0, channels.lastIndex)
        renderGuideOverlay()
        scheduleOverlayHide()
    }

    private fun toggleGuideMode() {
        val next = if (guideOverlay.isVisible && guideMode == GuideMode.QUICK) GuideMode.FULL else GuideMode.QUICK
        showGuideOverlay(next)
    }

    private fun showGuideOverlay(mode: GuideMode) {
        guideMode = mode
        guideOverlay.visibility = View.VISIBLE
        renderGuideOverlay()
        scheduleOverlayHide()
    }

    private fun hideGuideOverlay() {
        overlayHandler.removeCallbacks(hideOverlayRunnable)
        guideOverlay.visibility = View.GONE
    }

    private fun scheduleOverlayHide() {
        overlayHandler.removeCallbacks(hideOverlayRunnable)
        if (guideMode == GuideMode.QUICK) {
            overlayHandler.postDelayed(hideOverlayRunnable, 4500)
        }
    }

    private fun playSelectedChannel() {
        val target = channels.getOrNull(selectedGuideIndex) ?: return
        currentIndex = selectedGuideIndex
        titleView.text = target.name
        statusView.visibility = View.VISIBLE
        statusView.text = "Switching to ${target.name}…\n${target.debug}"
        val mediaItemBuilder = MediaItem.Builder().setUri(Uri.parse(target.url))
        if (looksLikeTsStream(target.url)) {
            mediaItemBuilder.setMimeType(MimeTypes.VIDEO_MP2T)
        }
        player?.apply {
            setMediaItem(mediaItemBuilder.build())
            prepare()
            playWhenReady = true
        }
        hideGuideOverlay()
    }

    private fun renderGuideOverlay() {
        val selected = channels.getOrNull(selectedGuideIndex)
        guideModeView.text = if (guideMode == GuideMode.QUICK) "QUICK GUIDE" else "FULL GUIDE"
        guideTitleView.text = selected?.name ?: "Live TV Guide"
        guideMetaView.text = selected?.let {
            buildString {
                append(it.source)
                if (it.debug.isNotBlank()) {
                    append(" • ")
                    append(it.debug)
                }
            }
        } ?: "Browse channels while video keeps playing"
        guideHintView.text = if (guideMode == GuideMode.QUICK) {
            "↑/↓ browse • OK switch • MENU full guide • BACK close"
        } else {
            "Glass overlay mode • video stays behind guide • OK switch • BACK close"
        }

        guideList.removeAllViews()
        if (channels.isEmpty()) {
            guideList.addView(makeGuideRow("No guide data available", false, "Add Channels DVR or IPTV in Settings"))
            return
        }

        val visibleItems = if (guideMode == GuideMode.QUICK) {
            val start = (selectedGuideIndex - 2).coerceAtLeast(0)
            val end = (selectedGuideIndex + 2).coerceAtMost(channels.lastIndex)
            (start..end).map { index -> index to channels[index] }
        } else {
            channels.take(18).mapIndexed { index, channel -> index to channel }
        }

        visibleItems.forEach { (index, channel) ->
            guideList.addView(makeGuideRow(channel.name, index == selectedGuideIndex, "${channel.source} • ${channel.debug}"))
        }
    }

    private fun makeGuideRow(title: String, selected: Boolean, subtitle: String): View {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14))
            background = getDrawable(if (selected) R.drawable.focus_ring_pill_pulse else R.drawable.pill_dark)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.bottomMargin = dp(10)
            layoutParams = lp
        }
        val titleView = TextView(this).apply {
            text = title
            textSize = if (selected) 19f else 16f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val subtitleView = TextView(this).apply {
            text = subtitle
            textSize = 12f
            setTextColor(0xFFCAD4E2.toInt())
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        container.addView(titleView)
        container.addView(subtitleView)
        return container
    }

    private fun decodeChannels(json: String?): List<GuideChannel> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(json)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    add(
                        GuideChannel(
                            name = obj.optString("name"),
                            url = obj.optString("url"),
                            source = obj.optString("source"),
                            debug = obj.optString("debug")
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun looksLikeTsStream(url: String): Boolean {
        val lower = url.lowercase()
        return lower.contains("format=ts") || lower.endsWith(".ts") || lower.endsWith(".mpg")
    }

    override fun onStart() {
        super.onStart()
        player?.playWhenReady = true
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        overlayHandler.removeCallbacksAndMessages(null)
        playerView.player = null
        player?.release()
        player = null
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    data class GuideChannel(
        val name: String,
        val url: String,
        val source: String,
        val debug: String
    )

    enum class GuideMode { QUICK, FULL }

    companion object {
        const val EXTRA_STREAM_URL = "stream_url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_SOURCE_LABEL = "source_label"
        const val EXTRA_DEBUG_LABEL = "debug_label"
        const val EXTRA_CHANNELS_JSON = "channels_json"
        const val EXTRA_CHANNEL_INDEX = "channel_index"
    }
}
