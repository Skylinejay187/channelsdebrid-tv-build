# Debrid Channels v0.8.1 — Live TV Scale Verification + Guide Cache

Base used: v0.8.0 clean consolidated build.

Build method: clean consolidation from the latest known-good clean base. Preserved all previously agreed features unless explicitly changed.

## Added
- Live TV scale verification logs for source counts, total channel count, cached matches, hydrated guide rows, and guide-cache writes.
- Local guide cache under app files `guide-cache-v5`.
- Cache apply before XMLTV/manual guide parsing so guide rows can hydrate faster after first successful scan.
- Cache write after DVR/Xtream/XMLTV guide hydration.
- Settings option: `Live TV: Clear guide cache`.
- v0.8.1 build marker.

## Preserved
- 2500+ channel memory-safe XMLTV parser and smaller DVR guide windows.
- Image quality modes, extra artwork 3D, hero alignment, Live TV UI, VOD, trailers, and Pro Layout Editor.
- Hero/UI density rules and clean-core rules.

## Verification logs
Look for:
- `DC_BUILD_MARKER: v0.8.1_livetv_scale_verification_guide_cache_clean_base`
- `LIVE_TV_V081: scale_verify ...`
- `LIVE_TV_V081: guide_hydration ...`
- `LIVE_TV_V081: guide_cache_apply ...`
- `LIVE_TV_V081: guide_cache_write ...`
