# Debrid Channels v0.7.1 Audit

Base used: v0.7.0 Live TV Guide Source Selector + XMLTV Fallback + Ghost Fix.

Build method: clean consolidation from latest known-good source. No old non-Live-TV app code reused. Old app Live TV behavior is reference only.

Included:
- Reworked XMLTV guide parser to use Android XmlPullParser streaming instead of line/block buffering.
- Kept guide source selector: Auto, Channels DVR, Xtream Codes, XMLTV Manual.
- Added stronger channel/display-name alias matching through streaming channel parsing.
- Replaced endless Guide data loading wording with No guide data fallbacks.
- Added Live TV preview player lifecycle hard release and view detach.
- Added activity stop release guard for live/fullscreen players to prevent audio bleed.
- Preserved highlight preview + OK fullscreen playback behavior.
- Preserved Hero 1080p / rest-of-app 4K mixed density.
- Reduced startup ghosting by removing the old verbose fallback hero placeholder copy.

Marker:
DC_BUILD_MARKER: v0.7.1_full_livetv_core_rewrite_preview_player_guide_clean_base
