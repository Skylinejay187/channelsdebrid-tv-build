# Debrid Channels v0.7.4 Full UI Root Cleanup + Hero Density Toggle

Base: v0.7.3 Live TV Polish + Hero Text Themes.

## Fixes
- Removed seeded startup hero placeholder content from app startup.
- App now starts from one clean root FrameLayout and waits for real backend rows before showing hero text/logo/metadata.
- Removed the runtime placeholder text: “Focused card updates background, logo, banner and metadata...”
- Hero title/logo/rating/description are hidden until real content is loaded.
- Hero themes now apply to the visible hero layer instead of a stale startup under-layer.
- Added Hero UI Density option: 4K style by default, optional 1080p style.
- Preserved 4K scaling for Pro Layout Editor, Media Info, Movies/Shows, Settings, Live TV, and Player overlays.

## Verification
- Search result: only one `setContentView(root)` remains; no XML layout inflation path is used.
- Search result: no seeded `Debrid Channels / Loading catalogs` hero row remains.

## Build marker
`DC_BUILD_MARKER: v0.7.4_full_ui_root_cleanup_hero_density_toggle_default_4k_clean_base`
