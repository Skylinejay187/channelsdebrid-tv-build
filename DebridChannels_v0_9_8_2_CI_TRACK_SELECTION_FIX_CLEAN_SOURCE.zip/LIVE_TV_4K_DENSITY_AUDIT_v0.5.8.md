# Debrid Channels v0.5.8 — Live TV 4K Density + Layout Fix

Base used: v0.5.7 old-app Live TV layout port clean source.

Build method: clean consolidation from latest known-good source. No old non-Live-TV systems were changed.

Preserved:
- Dynamic Hero + Theme Engine
- Pro Layout Editor
- Playback system
- Stremio addon manager
- Trailer/player fixes
- Top menu visibility in Live TV
- BACK returns Home
- Live TV OK playback path

Changed:
- Added Live TV 4K density detection using display pixels + density + the existing 4K UI toggle.
- Added Live TV-specific scaled dp/sp helpers so Live TV no longer inflates into oversized spacing on 4K/high-density Android TV displays.
- Tightened category rail, guide row height, preview card, header, timeline, and grid proportions.
- Added log marker with display resolution/density so screenshots/logcat can confirm whether the 4K density path is active.

Known backlog intentionally parked:
- Weather Status Hub display issue
- Trailer stream no-audio-track fallback/resolution
- Media info text overflow final polish
- VOD Dolby Vision/audio/frame-rate/resolution matching before final app completion
