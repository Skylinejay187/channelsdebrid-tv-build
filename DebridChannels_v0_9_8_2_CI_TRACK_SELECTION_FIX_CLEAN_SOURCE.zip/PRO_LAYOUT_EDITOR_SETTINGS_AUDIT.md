# Pro Layout Editor Settings Audit - v6.5

Reference inspected: `debridchannelsApp_v2.1.3_PRO_LAYOUT_MENU_ART_LIVEFIX_FULL.zip`.

No legacy editor code was copied. The v2.1.3 Pro Layout Editor setting list was used only as a feature checklist and reimplemented against the current v6 clean-core `UiStateStore` / overlay editor.

Restored settings:
- Preview cards
- Row vertical position
- Row left / right
- Card width
- Card height
- Card spacing
- Focused card scale
- Glow strength
- Pulse effect
- Focus ring on/off
- Focus ring thickness
- Focus ring color
- 3D tilt effect
- Card lift
- Rounded corners
- Dim unfocused cards
- Top menu icon style
- Menu composition
- Search icon placement
- Settings icon placement
- Show row title text
- Hero extra artwork on/off
- Hero artwork type
- Hero artwork X
- Hero artwork Y
- Hero artwork width
- Hero artwork height
- Hero artwork opacity
- Hero artwork 3D pop
- Top menu font
- Hero text font
- Content/card font
- Row title icons
- Focus bounce
- Glass card mode
- Hover info overlay
- Background dim on focus
- Effect profile
- Hero text left / right
- Hero text up / down
- Top menu left / right
- Bottom safe space

Preserved controls:
- Save layout
- Reset layout
- View Home
- DPAD up/down scrolling
- DPAD left/right value adjustment
- Focused editor item auto-scroll into view
- Default card size 286 x 160
- Default backend URL: http://192.168.100.55:8181
