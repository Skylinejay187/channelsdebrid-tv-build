# v0.6.0 Live TV Preview + Full Guide Expansion Audit

Base: v0.5.9 FULL APP 4K SYSTEM clean base.

Changes:
- Kept old-app Live TV layout structure.
- Fixed top-right preview/logo card clipping by moving normal guide shell inside safe screen bounds.
- Added FIT_CENTER + adjustViewBounds + padding on the preview image so channel logos/art remain fully visible.
- Stretched guide rows further toward the bottom of the screen.
- Added full-guide expansion behavior: DPAD RIGHT from a focused category hides the category rail and expands the guide across the screen.
- DPAD LEFT from guide restores category rail.
- Top app menu remains visible.
- OK/ENTER playback path preserved.

Marker:
DC_BUILD_MARKER: v0.6.0_live_tv_preview_full_guide_expand_clean_base
