# v0.8.6 Live TV Preview Visibility + 5 Row Rollback Fix

Base: v0.8.5 clean source.

Scope approved by user:
- Fix Live TV preview being cropped/off-screen.
- Revert/avoid unwanted 1080p guide-frame extension behavior.
- Show 5 guide rows down in normal guide view.

Changes:
- Preview card is anchored to root safe area using actual screen pixel bounds.
- Preview is no longer placed inside the header row where it could be clipped by panel overflow.
- Preview uses `bringToFront()` so guide layers cannot cover it.
- Normal guide viewport is constrained to 5 visible rows while preserving scrolling for additional channels.
- Force Refresh remains hidden in full-guide mode.

Preserved:
- Live TV source loading, guide cache, XMLTV memory-safe parser, DVR/Xtream/XMLTV modes.
- Hero/pro-editor/image-quality systems.
- VOD/trailer/player systems.

Marker:
`DC_BUILD_MARKER: v0.8.6_livetv_preview_visibility_5row_rollback_clean_base`
