# Debrid Channels v0.4.1 Trailer Player Wiring Fix

Base used: v0.4.0 clean source from v0.3.0 Dynamic Hero + Theme Engine.

Build method: clean consolidation fix, no old app code copied, no stale patch stacking.

Fixed:
- Trailer button/auto popup now resolves backend trailer responses into a playable Media3 ExoPlayer overlay.
- Replaced the trailer preview playback path with a dedicated ExoPlayer/PlayerView overlay instead of relying on Android VideoView.
- Added recursive trailer JSON parsing for backend response shapes including url, trailerUrl, playUrl, streamUrl, resolvedUrl, videoUrl, embedUrl, youtubeUrl, arrays, data objects, and nested trailer objects.
- Added two-stage resolve support: extract/find trailer candidate first, then /trailers/resolve candidate into direct playable stream when needed.
- Sends richer backend payloads with id, mediaId, imdbId, title, name, year, type, and mediaType.
- Tries imdb id, app id, title, and title + year candidate lookups against /api/trailer/:id.
- Keeps trailer popup settings: enabled/disabled, delay, muted, and complete disable.

Preserved:
- Hero system
- Theme engine
- Pro Layout Editor
- Extra Artwork Slot
- Status Hub
- Row navigation
- Movie playback
- Episode browsing/playback hooks
- Backend base URL compatibility

Marker:
DC_BUILD_MARKER: v0.4.1_trailer_player_endpoint_resolve_clean_base
