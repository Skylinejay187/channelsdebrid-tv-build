# Debrid Channels v0.5.0 Live TV Guide Rebuild Audit

Base used: v0.4.4 Trailer Dedicated Audio Player Fix clean source.

Build method: clean consolidation from latest known-good base; no old app code reused; no stale generated code carried forward intentionally.

Preserved systems:
- Dynamic hero + theme engine
- Pro Layout Editor
- Extra Artwork Slot
- Status Hub base
- VOD playback / Media3 player path
- TV shows season/episode navigation
- Trailer overlay system
- Unlimited Stremio addon manager
- Backend base URL compatibility: http://192.168.100.55:8181

Added / changed:
- Rebuilt Live TV guide surface into a Google Free Cable style layout.
- Added left category rail based on channel groups.
- Added guide grid with Channel / Now / Next / Later columns.
- RIGHT from categories expands/focuses guide rows.
- Added top connection/status line for Channels DVR / IPTV source and channel count.
- Added preview information card on top-right without the old gray player tint or focus ring around preview.
- Added v0.5.0 build marker and logcat marker.

Known backlog intentionally parked by user request:
- Weather Status Hub display still needs a final pass.
- Trailer resolver may still select video-only streams; backend/player should prefer muxed audio+video trailer URLs.
- Media info centered layout needs text-overflow readability polish.
