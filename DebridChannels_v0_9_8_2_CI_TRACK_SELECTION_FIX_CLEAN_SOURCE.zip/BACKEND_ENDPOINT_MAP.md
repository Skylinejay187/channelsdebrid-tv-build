# Backend endpoint map used by v6.2

Default backend URL: `http://192.168.100.55:8181`

Routes inspected from `bacEnd_v1.8.2_backend_web_dash_no_android_client(2).zip`:

- `GET /api/home` — home rails/catalog rows.
  - Expected: `{ rails: [{ title, slug, source, items: [...] }] }`
  - Item fields supported by app: `title/name`, `year`, `source`, `overview/description`, `poster/posterUrl`, `background/backdrop/backdropUrl`, `logo/clearlogo/logoUrl`, `banner/thumb`.
- `GET /api/catalog/movies` — flat movies list.
- `GET /api/catalog/shows` — flat shows list.
- `GET /api/search?q=...` — media search.
- `GET /trailers/resolve?title=&year=&mediaId=&mediaType=` — trailer prep for the next trailer build.
- `GET /api/trailer/:id?title=&year=&mediaType=` — alternate trailer lookup.
- `GET /trailers/extractor/status` — yt-dlp extractor status.
- `GET /trailers/extract?url=&quality=4k` — direct trailer stream extraction.

Live TV note: the backend README says live provider handling moved to Android app, so v6.2 keeps local M3U/Channels DVR app-side wiring and does not depend on backend live endpoints.
