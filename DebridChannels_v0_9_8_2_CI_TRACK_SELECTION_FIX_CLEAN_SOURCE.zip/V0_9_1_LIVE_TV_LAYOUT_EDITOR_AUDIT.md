# v0.9.1 Basic Live TV Layout Editor UI

Base: v0.9.0 Live TV Layout Engine + Real Theme Application.

Included:
- Separate Live TV Layout Editor screen.
- Live preview/mockup visible while editing.
- Basic controls for theme, Live TV density, rows, red current-time line, timeline labels, channel logos, preview window, preview size, and preview corner.
- Reset and clear actions for Live TV layout defaults.
- Live TV controls removed from Pro Layout Editor path.

Preserved: Live TV playback, guide cache/source modes, VOD, trailers, Stremio, Home, and Pro Layout Editor.

Marker: DC_BUILD_MARKER: v0.9.1_basic_livetv_layout_editor_preview_clean_base
