# Debrid Channels v0.7.9 Full Guide Memory-Safe Rewrite

Base: v0.7.8 image quality modes + extra art 3D + hero alignment.

Clean consolidation notes:
- Fixed missing helper methods that caused v0.7.8 compile failure: imageQualityModeName() and heroLogoAlignName().
- Reworked Live TV source loading to honor Guide Source mode: Auto, Channels DVR, Xtream Codes, XMLTV Manual.
- Manual XMLTV fallback applies after channels load in Auto/XMLTV modes.
- Channels DVR XMLTV requests now use memory-safe windows: 6h, 12h, 24h. No 14-day XMLTV request by default.
- XMLTV guide parser remains streaming/pull-parser based and does not load the entire XMLTV file into memory.
- High-scale channel protection: guide parser caps processed programmes for 2500+ channel libraries.
- Preserved Live TV UI, image quality modes, Pro Editor, VOD, trailers, Stremio, and mixed-density UI.

Build marker:
`DC_BUILD_MARKER: v0.7.9_full_guide_memory_safe_rewrite_clean_base`
