# Debrid Channels v0.6.4 Live TV Sources + Player Wiring Audit

Base used: v0.6.3 clean source.
Build method: clean consolidation from latest known-good project, no stale patch stacking.

Preserved:
- Hero/theme/pro layout/editor systems
- Stremio addon manager
- Trailer overlay/video restore behavior
- Global 4K scaling system
- Old-app/Google-style Live TV shell structure

Added/fixed:
- Live TV source loader merges M3U, Channels DVR, and Xtream Codes.
- Channels DVR base URL support attempts /devices/ANY/channels.m3u first, then JSON channel fallback.
- Xtream Codes settings: host, username, password.
- Xtream live categories and streams are loaded via player_api.php.
- Live TV guide Force Refresh reloads all configured Live TV sources.
- OK on channel now opens a dedicated Media3 Live TV player.
- BACK from Live TV player returns to the guide; BACK from guide returns home.

Known backlog carried forward:
- Row-card image quality still needs a focused artwork pipeline pass.
- Weather/status hub polish remains parked.
- Trailer audio depends on source stream containing a usable audio track.
- Before final completion: verify Dolby Vision, audio formats, frame-rate matching, and resolution matching.
