# Debrid Channels v0.6.9 — Live TV XMLTV Streaming OOM Fix

Base used: v0.6.8 Mixed Density Hero 1080 / Rest 4K clean source.

Fixes:
- Stops loading full XMLTV guide files into a single String/ByteArrayOutputStream.
- Streams XMLTV line-by-line and parses programme blocks incrementally.
- Tries smaller Channels DVR guide windows before larger guide windows.
- Adds guard limits so very large guides cannot crash low-memory Android TV devices.
- Preserves mixed density behavior: Hero/Home 1080p-style UI, all other sections 4K.
- Preserves Live TV player, Channels DVR, M3U, Xtream, preview, and audio-release fixes.

Crash fixed:
- java.lang.OutOfMemoryError at MainActivity.httpGetText -> applyXmltvGuide -> applyChannelsDvrXmltvGuide.

Build marker:
DC_BUILD_MARKER: v0.6.9_livetv_xmltv_streaming_oom_fix_clean_base
