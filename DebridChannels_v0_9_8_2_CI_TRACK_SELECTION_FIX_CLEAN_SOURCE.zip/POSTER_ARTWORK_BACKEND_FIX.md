# v6.6 Poster/Artwork Backend Loader Fix

- Preserves v6.5 Pro Layout Editor and carousel behavior.
- Enables Android cleartext HTTP for the LAN backend at http://192.168.100.55:8181.
- Adds network security config for local backend access.
- Loads backend `/api/home`; if empty, calls `/api/refresh` and retries.
- Reads poster/background/logo/banner fields from backend/Stremio naming variants.
- Supports nested `artwork` and `images` objects.
