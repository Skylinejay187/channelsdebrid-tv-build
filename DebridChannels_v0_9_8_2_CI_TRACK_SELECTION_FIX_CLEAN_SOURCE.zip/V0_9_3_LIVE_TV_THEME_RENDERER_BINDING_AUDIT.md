# v0.9.3 Live TV Theme Renderer Binding Fix

Clean consolidation from v0.9.2.

## Fixed
- Theme presets now produce clearly different layout geometry, not placeholder names.
- Live TV renderer log marker updated to `LIVE_TV_THEME_APPLIED_RENDERER_V093`.
- Preview visibility now follows the applied theme config; themes that disable preview do not leave a 1px view.
- Force Refresh Guide remains removed from visible guide UI and cannot reappear after exiting full-guide mode.
- Reference images are treated as layout/style references only: no profile pictures, unrelated menus, TV borders, or screenshot artifacts are copied.

## Preserved
- DVR/Xtream/XMLTV guide pipeline.
- Guide cache and memory-safe XMLTV parsing.
- Live TV Layout Editor separation.
- Pro Layout Editor separation.
- VOD, trailers, image quality modes, and hero settings.

## Marker
DC_BUILD_MARKER: v0.9.3_livetv_theme_renderer_binding_fix_clean_base
