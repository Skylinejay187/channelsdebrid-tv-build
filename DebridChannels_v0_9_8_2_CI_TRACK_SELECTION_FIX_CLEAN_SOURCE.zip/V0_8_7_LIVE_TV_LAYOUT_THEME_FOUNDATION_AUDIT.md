# Debrid Channels v0.8.7 Live TV Layout Stabilization + Theme Foundation

Base used: v0.8.6 clean source.

Build method: clean consolidation on latest known source; no old UI layer restored; no non-Live-TV systems removed.

Included:
- Live TV preview is locked into the top-right header zone and shrinks before overlapping guide rows.
- Guide viewport is bottom-anchored and keeps a configurable visible row count, default 5 rows.
- Added Live TV theme preset framework:
  - Google Free TV style (default)
  - TiviMate style
  - iMPlayer style
  - Arvio style
  - Minimal compact
  - Custom editable
- Added Live TV add-on toggles:
  - red current-time line ON/OFF
  - timeline labels ON/OFF
  - channel logos ON/OFF
  - preview window ON/OFF
  - visible guide rows 3-7
- Settings and Pro Layout Editor both expose the new Live TV layout/theme controls.

Preserved:
- 2500+ channel optimization/windowing/cache
- XMLTV memory-safe parser
- DVR/Xtream/XMLTV guide source modes
- Live TV density modes
- VOD, trailers, Stremio addon manager, Pro Layout Editor, image quality modes

Marker:
DC_BUILD_MARKER: v0.8.7_livetv_layout_stabilization_theme_foundation_clean_base
