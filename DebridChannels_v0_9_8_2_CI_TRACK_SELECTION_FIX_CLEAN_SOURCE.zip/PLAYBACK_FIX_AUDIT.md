# v0.1.2 Playback Control Fix Audit

Base: clean consolidation from v0.1.1 real Media3 VOD rebuild and stable v0.0.1 visual/card baseline.

Fixes:
- Preserved stable home rows, card/logo visuals, hero ratings, and Pro Layout Editor.
- Keeps Stremio Addons as current playback source mode; Backend Resolver remains reserved for later.
- Prevents external web links from opening the in-app player.
- Adds Media3 ExoPlayer state/error log markers.
- Makes cinematic overlay controls focusable and wired to pause/play and seek.
- Player overlay opens only after selecting a direct in-app playable stream.

Marker: DC_V0_1_2_PLAYBACK_CONTROL_FIX_ACTIVE
Version: 0.1.2 / versionCode 12
