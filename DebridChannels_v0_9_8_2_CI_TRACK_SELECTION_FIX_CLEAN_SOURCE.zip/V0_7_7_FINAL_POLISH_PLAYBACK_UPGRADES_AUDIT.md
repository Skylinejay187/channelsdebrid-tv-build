# Debrid Channels v0.7.7 — Final Polish + Playback Upgrades Audit

Base used: v0.7.5 / v0.7.x clean consolidated source.
Build method: clean consolidation, preserving current Live TV, VOD, trailers, Stremio, Pro Layout Editor, mixed-density UI, and backend compatibility.

## Added / Changed

### Extra artwork placement
- Added `extraArtworkPosition` setting:
  - Current / manual
  - Top left
  - Top right
- Added Pro Layout Editor control for the placement.
- Kept manual X/Y sliders for the existing/current position.

### 4K artwork pipeline
- Added smart artwork loading with bounded byte caps and safe downscaling.
- Hero backdrops can decode up to 3840x2160.
- Hero logos and extra artwork can decode up to 2560x1440.
- Row/card artwork decodes at a safer 1280x720 tier.
- Added ARTWORK_4K_V077 logs for decoded dimensions.
- Prevents brute-force full-image loading that previously risked OOM crashes.

### Playback upgrades
- Added quality preference hooks to Media3 players.
- Forces highest supported video track where Media3/device supports it.
- Adds explicit media audio attributes/audio focus.
- Adds resize/framerate/resolution hook logs for player attach points.

### Live TV polish / guide direction
- Preserved high-scale channel guide optimizations.
- Preserved XMLTV streaming parser and guide source selector foundation.
- Preserved preview lifecycle/audio release fixes.

### VOD/trailers/player direction
- Preserved trailer overlay and VOD player pipeline.
- Added shared playback preference hooks so VOD/trailer/live players follow the same quality policy.

## Known backlog still requiring device validation
- Dolby Vision handling must be verified on actual compatible media/device.
- Dolby/DTS-style audio handling/passthrough depends on Android TV firmware and Media3/device capabilities.
- True frame-rate/resolution switching requires device-level display mode validation.
- Row-card quality is improved safely, but final quality still depends on backend-provided artwork URLs.

## Marker
`DC_BUILD_MARKER: v0.7.7_final_polish_playback_upgrades_visual_pipeline_clean_base`
