# Debrid Channels v0.6.8 Mixed Density Audit

Base used: v0.6.7 Live TV Guide + Audio Release clean source.

Build method: clean consolidation from latest known-good source. No old app code reuse and no stacked broken architecture.

## Density Rule
- Hero/Home section: forced 1080p-style spacing and typography.
- Everything else remains controlled by the global 4K UI system when enabled.
- Pro Layout Editor remains 4K.
- Media Info remains 4K.
- Movies/Shows grids remain 4K.
- Live TV remains 4K/tight-density.
- Player overlays remain 4K.

## Implementation
- Added scoped density flag `hero1080DensityActive`.
- `dp()` / `sp4k()` now honor the scoped flag.
- `showHome()` enables hero 1080p scope.
- `clear()` resets the scope so all non-home screens return to 4K.
- Live TV uses its own `ldp()` / `lsp()` and remains 4K-aware.

## Preserved
- Live TV guide/source/player work from v0.6.7.
- Trailer system state preserved.
- Stremio unlimited addon manager preserved.
- Pro Layout Editor preserved and remains 4K.
- VOD playback quality is not changed by UI density.

Marker: `DC_BUILD_MARKER: v0.6.8_mixed_density_hero_1080_rest_4k_clean_base`
