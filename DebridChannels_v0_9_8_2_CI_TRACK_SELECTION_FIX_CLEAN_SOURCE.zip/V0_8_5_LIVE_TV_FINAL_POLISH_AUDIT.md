# Debrid Channels v0.8.5 - Live TV Final Polish

Base used: v0.8.3 clean source with v0.8.x Live TV rules preserved.
Build method: clean consolidation / no old UI layer restored.

Changes included:
- Preserved separate Live TV density modes: 1080p Auto Fit and 4K compact.
- Added hard preview sizing helper so preview remains inside screen bounds and logs calculated size.
- Tightened Live TV spacing to better match Google Free TV / Arvio-style guide density.
- Reduced row heights and rail width for better 1080p fit.
- Extended guide frame closer to the bottom of the screen.
- Polished guide row focus behavior with subtle whole-row highlight and no heavy focus-ring stroke.
- Kept Force Refresh hidden in full-guide mode.
- Preserved guide cache, XMLTV memory-safe parser, DVR/Xtream/XMLTV source modes, player release lifecycle, and image quality modes.

Marker:
DC_BUILD_MARKER: v0.8.5_livetv_final_polish_preview_smooth_logo_clean_base
