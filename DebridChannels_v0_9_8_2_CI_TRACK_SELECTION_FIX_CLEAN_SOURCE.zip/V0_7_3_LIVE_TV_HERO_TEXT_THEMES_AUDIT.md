# v0.7.3 Live TV Polish + Hero Text Themes

Base used: latest clean v0.7.x Live TV core.
Build method: clean consolidation, no old code carryover.

Included requested work streams:
1. Live TV polish path: preserves Google/old-app style guide shell and increases visible high-scale guide window.
2. Image quality path: preserves landscape/backdrop/banner preference and avoids heavy logo backgrounds.
3. DVR/Xtream/XMLTV guide merge path: preserves guide source selector and XMLTV fallback pipeline.
4. VOD/trailer/player polish path: preserves dedicated player lifecycle fixes and playback overlay work.
5. Hero text controls: adds Hero Text Size and Hero Text Theme/Layout controls to Pro Layout Editor.

Hero controls added:
- Size: Tiny, Small, Default, Large, XL
- Theme/layout: Classic left, Compact logo-first, Wide cinematic, Bottom-left poster, Glass card, Minimal metadata
- Additional styles: Minimal small, Poster stack, Wide cinematic, Glass capsule, Ultra compact

Backlog reminder: Dolby Vision, Dolby/DTS-style audio, frame-rate matching, and resolution matching must be revisited before final completion.
