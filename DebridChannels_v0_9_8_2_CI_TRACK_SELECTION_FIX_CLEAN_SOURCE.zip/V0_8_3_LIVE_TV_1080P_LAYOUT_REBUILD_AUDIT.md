# v0.8.3 Live TV 1080p Layout Rebuild Audit

Base used: v0.8.2 clean source.
Build method: clean consolidation from latest known-good source; no old broken layout stacking.

Changes:
- Merged Live TV Auto Fit and 1080p into one mode: 1080p Auto Fit.
- Live TV density options are now 1080p Auto Fit and 4K compact.
- Rebuilt the Live TV 1080p layout using safe 1920x1080-style dimensions instead of scaling the oversized 4K layout after the fact.
- Added dp-aware fit math so devices with non-1.0 density do not overflow/crop the guide.
- Reduced 1080p category rail, preview, timeline, guide row height, and guide cell widths to keep the section on-screen.
- Preserved full-guide behavior: RIGHT from categories expands guide, LEFT returns categories, Force Refresh hides in full-guide mode.
- Preserved Live TV player, guide cache, XMLTV memory-safe parser, DVR/Xtream/XMLTV sources, Pro Editor, VOD, trailers, and hero/image systems.

Marker: DC_BUILD_MARKER: v0.8.3_livetv_1080p_layout_rebuild_clean_base
