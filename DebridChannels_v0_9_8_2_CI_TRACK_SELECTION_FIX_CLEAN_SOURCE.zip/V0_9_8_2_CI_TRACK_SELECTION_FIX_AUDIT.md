# v0.9.8.2 CI Track Selection Compile Fix Audit

Base used: `DebridChannels_v0_9_8_1_CI_COMPILE_FIX_CLEAN_SOURCE` clean-source base.

Fix applied:
- Rewrote Media3 `TrackSelectionOverride` creation for audio/subtitle track selection to use `Collections.singletonList(trackIndex)` for Media3 1.3.1 compatibility.
- This addresses the two Java compile errors shown in GitHub Actions during `:app:compileDebugJavaWithJavac`.

Preserved:
- Pro Layout Editor
- DPAD scrolling/focus behavior
- Hero 1080p default
- Live TV layout/theme/editor systems
- Backend/artwork loading
- Poster background lighting controls
- Existing clean-core rules and audit files

Rule followed:
- Clean-source stabilization from the latest known-good clean base; no stale generated architecture carried forward.
