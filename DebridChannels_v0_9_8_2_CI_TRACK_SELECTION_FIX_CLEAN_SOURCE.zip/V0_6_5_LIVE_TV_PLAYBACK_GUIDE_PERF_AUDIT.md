# v0.6.5 Live TV Playback + Guide Performance Fix

Base: v0.6.4 Live TV Sources + Player Wiring clean source.

Fixes:
- Added Media3 HLS and DASH modules so HLS streams no longer fail with `No suitable media source factory found for content type: 2`.
- Live TV player now infers common MIME types for HLS, DASH, MP4, TS/MPEG-TS, and Channels DVR stream.mpg URLs.
- Removed channel-logo background painting from the Live TV guide. Logos stay inside the row logo tile and preview card only, preventing ghosting and scroll slowdown.
- Replaced fake guide wording with safe guide-data placeholders while real EPG/source guide data loads.
- Updated logging markers to v0.6.5.

Known follow-up:
- True EPG/program schedules still require source guide data from Channels DVR XMLTV, Xtream short EPG, backend guide endpoints, or an XMLTV URL pipeline. This build focuses on playback factory support and guide performance regression fixes.
