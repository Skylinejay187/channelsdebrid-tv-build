# Rewrite Build Audit — v0.3.0 Dynamic Hero + Theme Engine

Base used: v0.2.3 STATUS HUB + HERO LOGO CONTROLS stable line.

Rule followed: clean rewrite/consolidation from the latest known-good stable base. Broken later or stale generated code was not used as a base.

Preserved:
- Working row/card visual baseline
- Centered card logos
- VOD playback/resolver line as present in stable base
- Pro Layout Editor live preview
- Status Hub controls
- Hero logo movement controls
- Backend default URL compatibility

Added:
- Hero text mode selector
- Hero text style selector
- Hero letter-spacing control
- Dynamic hero rotation controls
- Expanded Extra Artwork Slot type selector with 15 modes
- Extra slot continues to use one powerful layer, per user choice A

Marker:
- Visible/About marker: DC_V0_3_0_DYNAMIC_HERO_THEME_ENGINE
- Logcat marker: DC_V0_3_0_DYNAMIC_HERO_THEME_ENGINE_ACTIVE
