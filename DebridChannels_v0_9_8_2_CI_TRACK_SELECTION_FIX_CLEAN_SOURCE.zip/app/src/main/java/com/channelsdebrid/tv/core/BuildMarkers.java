package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.9.8.1 Pro Poster Background Lighting CI Compile Fix";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.9.8.1_pro_poster_background_lighting_ci_compile_fix_clean_source";
}
