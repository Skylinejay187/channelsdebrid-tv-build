package com.channelsdebrid.tv.core;
public final class NavigationController {
    public enum Screen { HOME, LIVE_TV, VOD, SETTINGS, SEARCH, LAYOUT_EDITOR }
    private Screen current = Screen.HOME;
    public Screen current(){ return current; }
    public void go(Screen s){ current = s; AppLogger.mark("NAV -> "+s); }
}
