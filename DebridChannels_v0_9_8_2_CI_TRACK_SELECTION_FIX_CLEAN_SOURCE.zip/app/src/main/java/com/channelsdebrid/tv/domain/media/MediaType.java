package com.channelsdebrid.tv.domain.media;
public enum MediaType { MOVIE, SERIES }
