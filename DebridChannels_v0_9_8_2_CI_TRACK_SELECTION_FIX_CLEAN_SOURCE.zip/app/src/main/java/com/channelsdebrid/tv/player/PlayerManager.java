package com.channelsdebrid.tv.player;
import android.content.Context;import android.view.SurfaceView;import com.channelsdebrid.tv.core.AppLogger;
public final class PlayerManager {
    private final Context context; private SurfaceView surface;
    public PlayerManager(Context c){ context=c.getApplicationContext(); }
    public SurfaceView attachSurface(Context ctx){ surface=new SurfaceView(ctx); surface.setFocusable(false); surface.setFocusableInTouchMode(false); AppLogger.mark("PlayerManager single owner attached"); return surface; }
    public void play(String url){ AppLogger.mark("PlayerManager play requested: "+url); }
    public void release(){ AppLogger.mark("PlayerManager release"); }
}
