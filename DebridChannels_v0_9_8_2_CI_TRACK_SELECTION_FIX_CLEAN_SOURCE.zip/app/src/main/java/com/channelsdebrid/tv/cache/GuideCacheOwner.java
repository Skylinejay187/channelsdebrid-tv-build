package com.channelsdebrid.tv.cache;
import android.content.Context;import java.io.File;import com.channelsdebrid.tv.core.AppLogger;
public final class GuideCacheOwner {
    private final File cacheDir;
    public GuideCacheOwner(Context c){ cacheDir=new File(c.getFilesDir(),"guide-cache-v5"); if(!cacheDir.exists()) cacheDir.mkdirs(); AppLogger.mark("GuideCacheOwner ready: "+cacheDir.getAbsolutePath()); }
    public File dir(){ return cacheDir; }
}
