package com.channelsdebrid.tv.livetv;
import com.channelsdebrid.tv.core.AppLogger;
public final class LiveTvStateMachine {
    public enum State { CATEGORIES, GUIDE, PLAYER, HERO_MENU }
    private State state = State.CATEGORIES;
    public State state(){ return state; }
    public void up(){ state=State.HERO_MENU; AppLogger.mark("LiveTV DPAD_UP -> HERO_MENU"); }
    public void right(){ state=State.GUIDE; AppLogger.mark("LiveTV DPAD_RIGHT -> GUIDE_EXPANDED"); }
    public void left(){ state=State.CATEGORIES; AppLogger.mark("LiveTV DPAD_LEFT -> CATEGORIES"); }
}
