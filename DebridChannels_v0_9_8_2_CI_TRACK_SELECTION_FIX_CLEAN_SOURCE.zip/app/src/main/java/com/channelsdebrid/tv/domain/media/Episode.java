package com.channelsdebrid.tv.domain.media;
public final class Episode {
    public final String id, title, description, thumbnail, airDate;
    public final int seasonNumber, episodeNumber, runtimeMinutes;
    public Episode(String id,int seasonNumber,int episodeNumber,String title,String description,String thumbnail,int runtimeMinutes,String airDate){this.id=id;this.seasonNumber=seasonNumber;this.episodeNumber=episodeNumber;this.title=title;this.description=description;this.thumbnail=thumbnail;this.runtimeMinutes=runtimeMinutes;this.airDate=airDate;}
}
