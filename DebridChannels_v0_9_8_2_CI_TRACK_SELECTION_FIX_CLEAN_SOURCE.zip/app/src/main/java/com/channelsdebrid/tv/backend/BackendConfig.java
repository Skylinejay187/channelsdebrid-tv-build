package com.channelsdebrid.tv.backend;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Clean-core backend/resolver configuration owner.
 * All user-editable backend/catalog/live-TV/resolver endpoints persist here.
 */
public final class BackendConfig {
    private final SharedPreferences prefs;

    public BackendConfig(Context context) {
        prefs = context.getSharedPreferences("dc_v5_backend", Context.MODE_PRIVATE);
    }

    public String baseUrl() { return prefs.getString("baseUrl", "http://192.168.100.55:8181"); }
    public String m3uUrl() { return prefs.getString("m3uUrl", ""); }
    public String xmltvGuideUrl() { return prefs.getString("xmltvGuideUrl", ""); }
    public String catalogUrl() { return prefs.getString("catalogUrl", ""); }
    public String channelsDvrUrl() { return prefs.getString("channelsDvrUrl", baseUrl()); }
    public String playbackResolverMode() { return prefs.getString("playbackResolverMode", "direct"); }
    public String realDebridApiKey() { return prefs.getString("realDebridApiKey", ""); }
    public String torboxApiKey() { return prefs.getString("torboxApiKey", ""); }
    public String weatherLocation() { return prefs.getString("weatherLocation", "Youngstown, Ohio"); }
    public String xtreamHost() { return prefs.getString("xtreamHost", ""); }
    public String xtreamUsername() { return prefs.getString("xtreamUsername", ""); }
    public String xtreamPassword() { return prefs.getString("xtreamPassword", ""); }
    public String liveGuideSourceMode() { return prefs.getString("liveGuideSourceMode", "auto"); }

    public void saveBaseUrl(String url) { prefs.edit().putString("baseUrl", clean(url)).apply(); }
    public void saveM3uUrl(String url) { prefs.edit().putString("m3uUrl", clean(url)).apply(); }
    public void saveXmltvGuideUrl(String url) { prefs.edit().putString("xmltvGuideUrl", clean(url)).apply(); }
    public void saveCatalogUrl(String url) { prefs.edit().putString("catalogUrl", clean(url)).apply(); }
    public void saveChannelsDvrUrl(String url) { prefs.edit().putString("channelsDvrUrl", clean(url)).apply(); }
    public void saveRealDebridApiKey(String key) { prefs.edit().putString("realDebridApiKey", clean(key)).apply(); }
    public void saveTorboxApiKey(String key) { prefs.edit().putString("torboxApiKey", clean(key)).apply(); }
    public void saveWeatherLocation(String location) { String v = clean(location); prefs.edit().putString("weatherLocation", v.isEmpty() ? "Youngstown, Ohio" : v).apply(); }
    public void saveXtreamHost(String url) { prefs.edit().putString("xtreamHost", clean(url)).apply(); }
    public void saveXtreamUsername(String value) { prefs.edit().putString("xtreamUsername", clean(value)).apply(); }
    public void saveXtreamPassword(String value) { prefs.edit().putString("xtreamPassword", clean(value)).apply(); }
    public void saveLiveGuideSourceMode(String mode) {
        String m = clean(mode).toLowerCase();
        if (!m.equals("auto") && !m.equals("channelsdvr") && !m.equals("xtream") && !m.equals("xmltv")) m = "auto";
        prefs.edit().putString("liveGuideSourceMode", m).apply();
    }

    public void savePlaybackResolverMode(String mode) {
        String m = clean(mode).toLowerCase();
        if (!m.equals("direct") && !m.equals("auto") && !m.equals("realdebrid") && !m.equals("torbox")) m = "direct";
        prefs.edit().putString("playbackResolverMode", m).apply();
    }

    private String clean(String value) { return value == null ? "" : value.trim(); }
}
