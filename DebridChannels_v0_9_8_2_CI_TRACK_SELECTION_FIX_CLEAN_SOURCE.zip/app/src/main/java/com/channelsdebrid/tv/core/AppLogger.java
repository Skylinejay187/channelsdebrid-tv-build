package com.channelsdebrid.tv.core;
import android.util.Log;
public final class AppLogger {
    public static void mark(String msg){ Log.i(BuildMarkers.LOG_MARKER, msg); }
}
