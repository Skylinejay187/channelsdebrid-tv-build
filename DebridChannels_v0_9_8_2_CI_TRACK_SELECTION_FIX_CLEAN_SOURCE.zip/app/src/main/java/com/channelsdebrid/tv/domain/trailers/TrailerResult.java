package com.channelsdebrid.tv.domain.trailers;
public final class TrailerResult { public final String mediaId, trailerUrl, provider; public final boolean resolved; public TrailerResult(String mediaId,String trailerUrl,String provider,boolean resolved){this.mediaId=mediaId;this.trailerUrl=trailerUrl;this.provider=provider;this.resolved=resolved;} }
