package com.channelsdebrid.tv.stremio;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Locale;

/**
 * Unlimited Stremio addon registry.
 * Stores any number of manifest URLs and automatically hydrates display name/icon
 * from each addon's manifest.json. This intentionally does not build addons; it
 * only consumes user-provided Stremio addon manifests and streams/catalogs.
 */
public final class StremioAddonRegistry {
    private final SharedPreferences p;

    public static final class AddonManifest {
        public final String manifestUrl;
        public final String name;
        public final String description;
        public final String iconUrl;
        public final String version;
        public AddonManifest(String manifestUrl, String name, String description, String iconUrl, String version) {
            this.manifestUrl = manifestUrl == null ? "" : manifestUrl;
            this.name = name == null || name.trim().isEmpty() ? hostFallback(this.manifestUrl) : name.trim();
            this.description = description == null ? "" : description.trim();
            this.iconUrl = iconUrl == null ? "" : iconUrl.trim();
            this.version = version == null ? "" : version.trim();
        }
    }

    public StremioAddonRegistry(Context c){ p=c.getSharedPreferences("dc_v5_stremio",Context.MODE_PRIVATE); }

    public String getJsonLinks(){ return p.getString("jsonLinks",""); }
    public void saveJsonLinks(String links){ p.edit().putString("jsonLinks", links == null ? "" : links).apply(); }

    public ArrayList<String> getManifestUrls(){ return parseManifestUrls(getJsonLinks()); }

    public ArrayList<AddonManifest> getAddons(){
        ArrayList<AddonManifest> out = new ArrayList<>();
        JSONObject meta = storedMeta();
        for(String url : getManifestUrls()){
            JSONObject o = meta.optJSONObject(url);
            if(o == null) out.add(new AddonManifest(url, hostFallback(url), "Not refreshed yet", "", ""));
            else out.add(new AddonManifest(url, o.optString("name", hostFallback(url)), o.optString("description",""), o.optString("icon",""), o.optString("version","")));
        }
        return out;
    }

    public String addonNameFor(String manifestUrl){
        JSONObject o = storedMeta().optJSONObject(manifestUrl == null ? "" : manifestUrl.trim());
        if(o != null){ String n=o.optString("name",""); if(!n.trim().isEmpty()) return n.trim(); }
        return hostFallback(manifestUrl);
    }

    public int refreshAll(){
        JSONObject meta = storedMeta();
        int ok = 0;
        for(String url : getManifestUrls()){
            try{
                JSONObject manifest = new JSONObject(httpGet(url));
                JSONObject item = new JSONObject();
                item.put("name", manifest.optString("name", hostFallback(url)));
                item.put("description", manifest.optString("description", manifest.optString("contactEmail", "")));
                item.put("icon", first(manifest.optString("logo", ""), manifest.optString("icon", ""), manifest.optString("background", "")));
                item.put("version", manifest.optString("version", ""));
                meta.put(url, item);
                ok++;
            }catch(Exception e){
                try{
                    JSONObject item = new JSONObject();
                    item.put("name", hostFallback(url));
                    item.put("description", "Manifest refresh failed: " + e.getMessage());
                    item.put("icon", "");
                    item.put("version", "");
                    meta.put(url, item);
                }catch(Exception ignored){}
            }
        }
        p.edit().putString("addonMeta", meta.toString()).apply();
        return ok;
    }

    private JSONObject storedMeta(){
        try{return new JSONObject(p.getString("addonMeta","{}"));}catch(Exception e){return new JSONObject();}
    }

    public static ArrayList<String> parseManifestUrls(String raw){
        LinkedHashSet<String> set = new LinkedHashSet<>();
        if(raw == null) raw = "";
        String trimmed = raw.trim();
        if(trimmed.startsWith("[")){
            try{
                JSONArray arr = new JSONArray(trimmed);
                for(int i=0;i<arr.length();i++) addUrl(set, arr.optString(i,""));
            }catch(Exception ignored){}
        }
        String[] parts = raw.split("[\\n\\r\\t,; ]+");
        for(String part : parts) addUrl(set, part);
        return new ArrayList<>(set);
    }

    private static void addUrl(LinkedHashSet<String> set, String value){
        if(value == null) return;
        String u = value.trim();
        while(u.startsWith("\"")) u = u.substring(1);
        while(u.endsWith("\"") || u.endsWith(",")) u = u.substring(0,u.length()-1);
        if(!u.startsWith("http://") && !u.startsWith("https://")) return;
        if(!u.toLowerCase(Locale.US).contains("manifest.json")){
            while(u.endsWith("/")) u = u.substring(0,u.length()-1);
            u = u + "/manifest.json";
        }
        set.add(u);
    }

    private static String httpGet(String u)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();
        c.setConnectTimeout(7000); c.setReadTimeout(12000);
        c.setRequestProperty("Accept","application/json");
        c.setRequestProperty("User-Agent","DebridChannelsAndroidTV/0.4.2");
        try(InputStream in=c.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0)out.write(buf,0,n); return out.toString("UTF-8");
        }
    }

    private static String first(String...v){ for(String s:v) if(s!=null&&!s.trim().isEmpty())return s.trim(); return ""; }
    private static String hostFallback(String url){try{return new URL(url).getHost().replace("www.","");}catch(Exception e){return "Stremio Addon";}}
}
