package com.channelsdebrid.tv.domain.trailers;
public final class TrailerSettings { public final boolean autoPopup, mutedByDefault, disabled; public final int delaySeconds; public TrailerSettings(boolean autoPopup,int delaySeconds,boolean mutedByDefault,boolean disabled){this.autoPopup=autoPopup;this.delaySeconds=delaySeconds;this.mutedByDefault=mutedByDefault;this.disabled=disabled;} }
