package com.channelsdebrid.tv.domain.media;
import java.util.*;
public final class ShowDetails { public final String id,title,logo,poster,backdrop,description; public final List<Season> seasons; public ShowDetails(String id,String title,String logo,String poster,String backdrop,String description,List<Season> seasons){this.id=id;this.title=title;this.logo=logo;this.poster=poster;this.backdrop=backdrop;this.description=description;this.seasons=seasons==null?Collections.emptyList():seasons;} }
