package com.channelsdebrid.tv.prolayout;

public final class ProLayoutItem {
    public final String id;
    public final String label;
    public int xDp, yDp, widthDp, heightDp;
    public ProLayoutItem(String id, String label, int xDp, int yDp, int widthDp, int heightDp) {
        this.id = id; this.label = label; this.xDp = xDp; this.yDp = yDp; this.widthDp = widthDp; this.heightDp = heightDp;
    }
    public ProLayoutItem copy(){ return new ProLayoutItem(id, label, xDp, yDp, widthDp, heightDp); }
}
