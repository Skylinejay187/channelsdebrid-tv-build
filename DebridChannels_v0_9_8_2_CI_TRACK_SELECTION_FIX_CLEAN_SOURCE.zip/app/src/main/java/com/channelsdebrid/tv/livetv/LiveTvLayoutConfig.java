package com.channelsdebrid.tv.livetv;

import android.graphics.Color;

/** v0.9.4 Live TV config-routed renderer audit. Reference screenshots are used for layout only. */
public final class LiveTvLayoutConfig {
    public String id;
    public String name;
    public final boolean compact;
    public int catLeft, catTop, catWidth, catHeight;
    public int mainLeft, mainTop, mainWidth, mainHeight;
    public int fullLeft, fullTop, fullWidth, fullHeight;
    public int headerHeight, logoTileW, logoTileH, titleSp, metaSp, descSp;
    public int previewWidth, previewTop, previewRight, previewPadding, previewRadius;
    public int timelineHeight, timelineLeftPadding;
    public int[] tickWidths;
    public int redLineX, wideWidth, rowLogoWidth, nowCellWidth, nextCellWidth, laterCellWidth, farCellWidth;
    public int rowHeight, rowCellHeight, rowGap, visibleRows;
    public int guideViewportExtra, guideRowsBottomPadding, categoryHeaderHeight, categorySectionHeaderHeight;
    public int activeThemeLabelLeft, activeThemeLabelTop, activeThemeLabelWidth, activeThemeLabelHeight, activeThemeLabelTextSp;
    public int liveBadgeWidth, liveBadgeHeight, liveBadgeLeft, liveBadgeTop;
    public int previewMinWidth, previewSafeMargin, previewImagePadding;
    public int categoryIconSize, categoryRowHeight, categoryTextSp, categorySubTextSp;
    public int refreshWidth, refreshHeight, refreshBottom;
    public int rootScrimLeft, rootScrimMid, rootScrimRight;
    public int guideCellColor, guideCellAltColor, guideFocusTextColor, guideFocusBgColor;
    public int categoryFocusBgColor, categoryFocusTextColor, radius;
    public boolean forceRefreshVisible, showTopMenuArtifacts, copyReferenceProfileImages;

    private LiveTvLayoutConfig(String id, String name, boolean compact) { this.id=id; this.name=name; this.compact=compact; }

    public static LiveTvLayoutConfig preset(int themeMode, boolean fourKCompact, int rows) {
        int theme=Math.max(0,Math.min(5,themeMode));
        LiveTvLayoutConfig c=base(theme,fourKCompact);
        c.visibleRows=Math.max(3,Math.min(7,rows));
        applyTheme(c,theme,fourKCompact);
        c.forceRefreshVisible=false;
        c.showTopMenuArtifacts=false;
        c.copyReferenceProfileImages=false;
        return c;
    }

    private static LiveTvLayoutConfig base(int theme, boolean fourK) {
        LiveTvLayoutConfig c=new LiveTvLayoutConfig(themeId(theme),themeName(theme),fourK);
        if(fourK){
            c.catLeft=56;c.catTop=132;c.catWidth=390;c.catHeight=828;c.mainLeft=468;c.mainTop=100;c.mainWidth=1392;c.mainHeight=900;c.fullLeft=44;c.fullTop=88;c.fullWidth=1836;c.fullHeight=958;
            c.headerHeight=268;c.logoTileW=64;c.logoTileH=48;c.titleSp=48;c.metaSp=17;c.descSp=14;c.previewWidth=384;c.previewTop=104;c.previewRight=58;c.previewPadding=8;c.previewRadius=18;
            c.timelineHeight=42;c.timelineLeftPadding=94;c.tickWidths=new int[]{170,210,242,242,242,242};c.redLineX=300;c.wideWidth=1788;c.rowLogoWidth=86;c.nowCellWidth=560;c.nextCellWidth=362;c.laterCellWidth=362;c.farCellWidth=340;
            c.rowHeight=68;c.rowCellHeight=54;c.rowGap=3;c.guideViewportExtra=20;c.guideRowsBottomPadding=12;c.categoryHeaderHeight=36;c.categorySectionHeaderHeight=44;c.activeThemeLabelLeft=58;c.activeThemeLabelTop=58;c.activeThemeLabelWidth=470;c.activeThemeLabelHeight=34;c.activeThemeLabelTextSp=13;c.liveBadgeWidth=52;c.liveBadgeHeight=20;c.liveBadgeLeft=12;c.liveBadgeTop=10;c.previewMinWidth=280;c.previewSafeMargin=96;c.previewImagePadding=8;c.categoryIconSize=58;c.categoryRowHeight=74;c.categoryTextSp=18;c.categorySubTextSp=14;
        }else{
            c.catLeft=34;c.catTop=124;c.catWidth=330;c.catHeight=902;c.mainLeft=388;c.mainTop=92;c.mainWidth=1500;c.mainHeight=956;c.fullLeft=28;c.fullTop=84;c.fullWidth=1864;c.fullHeight=978;
            c.headerHeight=242;c.logoTileW=60;c.logoTileH=46;c.titleSp=46;c.metaSp=16;c.descSp=13;c.previewWidth=322;c.previewTop=104;c.previewRight=38;c.previewPadding=8;c.previewRadius=18;
            c.timelineHeight=38;c.timelineLeftPadding=88;c.tickWidths=new int[]{132,168,196,196,196,196};c.redLineX=245;c.wideWidth=1460;c.rowLogoWidth=72;c.nowCellWidth=455;c.nextCellWidth=300;c.laterCellWidth=300;c.farCellWidth=240;
            c.rowHeight=58;c.rowCellHeight=46;c.rowGap=3;c.guideViewportExtra=16;c.guideRowsBottomPadding=12;c.categoryHeaderHeight=36;c.categorySectionHeaderHeight=44;c.activeThemeLabelLeft=48;c.activeThemeLabelTop=58;c.activeThemeLabelWidth=460;c.activeThemeLabelHeight=34;c.activeThemeLabelTextSp=13;c.liveBadgeWidth=52;c.liveBadgeHeight=20;c.liveBadgeLeft=12;c.liveBadgeTop=10;c.previewMinWidth=240;c.previewSafeMargin=96;c.previewImagePadding=8;c.categoryIconSize=48;c.categoryRowHeight=62;c.categoryTextSp=18;c.categorySubTextSp=14;
        }
        c.refreshWidth=0;c.refreshHeight=0;c.refreshBottom=0;c.forceRefreshVisible=false;
        c.rootScrimLeft=Color.argb(252,0,0,0);c.rootScrimMid=Color.argb(236,5,5,7);c.rootScrimRight=Color.argb(238,0,0,0);
        c.guideCellColor=Color.argb(122,22,23,29);c.guideCellAltColor=Color.argb(104,22,23,29);c.guideFocusBgColor=Color.rgb(238,240,246);c.guideFocusTextColor=Color.rgb(25,26,30);
        c.categoryFocusBgColor=Color.rgb(238,240,246);c.categoryFocusTextColor=Color.rgb(24,25,29);c.radius=12;
        return c;
    }

    private static void applyTheme(LiveTvLayoutConfig c, int theme, boolean fourK) {
        switch(theme){
            case 1: // Google Free TV hybrid cinematic guide
                c.name="Google Free TV";
                c.catLeft=fourK?130:98; c.catTop=fourK?150:138; c.catWidth=fourK?355:305; c.catHeight=fourK?780:820;
                c.mainLeft=fourK?500:420; c.mainTop=fourK?92:88; c.mainWidth=fourK?1320:1430; c.mainHeight=fourK?900:930;
                c.fullLeft=fourK?118:90; c.fullTop=fourK?86:82; c.fullWidth=fourK?1718:1770; c.fullHeight=fourK?930:952;
                c.headerHeight=fourK?318:282; c.logoTileW=fourK?72:60; c.logoTileH=fourK?54:46; c.titleSp=fourK?54:48; c.metaSp=fourK?18:16; c.descSp=fourK?15:13;
                c.previewWidth=fourK?430:330; c.previewTop=fourK?118:110; c.previewRight=fourK?72:48;
                c.timelineHeight=fourK?44:40; c.timelineLeftPadding=fourK?108:92; c.tickWidths=fourK?new int[]{170,210,245,245,245,245}:new int[]{132,168,200,200,200,200}; c.redLineX=fourK?302:246;
                c.wideWidth=fourK?1760:1500; c.rowLogoWidth=fourK?92:76; c.nowCellWidth=fourK?610:470; c.nextCellWidth=fourK?350:305; c.laterCellWidth=fourK?350:305; c.farCellWidth=fourK?330:250;
                c.rowHeight=fourK?72:60; c.rowCellHeight=fourK?58:48; c.categoryRowHeight=fourK?82:68; c.categoryIconSize=fourK?60:50;
                c.radius=14; break;
            case 2: // TiviMate Pro full EPG grid
                c.name="TiviMate Pro";
                c.catLeft=0; c.catTop=fourK?292:282; c.catWidth=fourK?440:405; c.catHeight=fourK?668:700;
                c.mainLeft=0; c.mainTop=fourK?42:36; c.mainWidth=fourK?1880:1900; c.mainHeight=fourK?958:980;
                c.fullLeft=0; c.fullTop=fourK?42:36; c.fullWidth=fourK?1880:1900; c.fullHeight=fourK?958:980;
                c.headerHeight=fourK?292:282; c.logoTileW=0; c.logoTileH=0; c.titleSp=30; c.metaSp=18; c.descSp=16;
                c.previewWidth=fourK?540:500; c.previewTop=fourK?54:48; c.previewRight=fourK?1280:1370;
                c.timelineHeight=fourK?42:40; c.timelineLeftPadding=fourK?450:410; c.tickWidths=fourK?new int[]{120,170,280,280,280,280}:new int[]{115,160,260,260,260,260}; c.redLineX=fourK?600:570;
                c.wideWidth=fourK?1920:1860; c.rowLogoWidth=fourK?96:88; c.nowCellWidth=fourK?560:520; c.nextCellWidth=fourK?320:300; c.laterCellWidth=fourK?320:300; c.farCellWidth=fourK?300:260;
                c.rowHeight=fourK?70:66; c.rowCellHeight=fourK?58:54; c.categoryRowHeight=fourK?70:66; c.categoryIconSize=fourK?48:46;
                c.guideFocusBgColor=Color.rgb(55,123,245); c.guideFocusTextColor=Color.WHITE; c.categoryFocusBgColor=Color.rgb(55,123,245); c.categoryFocusTextColor=Color.WHITE; c.radius=6; break;
            case 3: // Minimal Grid dark layout
                c.name="Minimal Grid";
                c.catLeft=fourK?22:12; c.catTop=fourK?90:86; c.catWidth=fourK?260:230; c.catHeight=fourK?870:890;
                c.mainLeft=fourK?300:255; c.mainTop=fourK?112:106; c.mainWidth=fourK?1570:1610; c.mainHeight=fourK?860:880;
                c.fullLeft=0; c.fullTop=fourK?108:104; c.fullWidth=fourK?1880:1880; c.fullHeight=fourK?870:890;
                c.headerHeight=fourK?210:198; c.previewWidth=1; c.titleSp=fourK?36:34; c.metaSp=fourK?15:14; c.descSp=fourK?13:12;
                c.timelineHeight=fourK?40:38; c.timelineLeftPadding=fourK?260:240; c.redLineX=fourK?340:320; c.tickWidths=fourK?new int[]{130,180,260,260,260,260}:new int[]{120,170,250,250,250,250};
                c.wideWidth=fourK?1840:1780; c.rowLogoWidth=fourK?90:82; c.nowCellWidth=fourK?620:590; c.nextCellWidth=fourK?380:350; c.laterCellWidth=fourK?380:350; c.farCellWidth=fourK?340:300;
                c.rowHeight=fourK?76:72; c.rowCellHeight=fourK?62:58; c.categoryRowHeight=fourK?58:56; c.categoryIconSize=fourK?42:40;
                c.guideCellColor=Color.argb(70,18,20,24); c.guideCellAltColor=Color.argb(54,18,20,24); c.guideFocusBgColor=Color.argb(62,255,255,255); c.guideFocusTextColor=Color.WHITE; c.categoryFocusBgColor=Color.argb(46,255,255,255); c.categoryFocusTextColor=Color.WHITE; c.radius=4; break;
            case 4: // Cinematic Overlay / purple style
                c.name="Cinematic Overlay";
                c.catLeft=fourK?54:36; c.catTop=fourK?322:310; c.catWidth=fourK?370:330; c.catHeight=fourK?620:640;
                c.mainLeft=fourK?430:372; c.mainTop=fourK?60:58; c.mainWidth=fourK?1440:1500; c.mainHeight=fourK?920:930;
                c.fullLeft=fourK?46:32; c.fullTop=fourK?60:58; c.fullWidth=fourK?1824:1840; c.fullHeight=fourK?940:948;
                c.headerHeight=fourK?286:268; c.previewWidth=fourK?460:360; c.previewTop=fourK?72:70; c.previewRight=fourK?72:48; c.titleSp=fourK?36:34; c.metaSp=fourK?16:15; c.descSp=fourK?14:13;
                c.timelineHeight=fourK?44:42; c.timelineLeftPadding=fourK?92:84; c.redLineX=fourK?300:280; c.tickWidths=fourK?new int[]{150,190,240,240,240,240}:new int[]{135,178,230,230,230,230};
                c.wideWidth=fourK?1800:1700; c.rowLogoWidth=fourK?96:86; c.nowCellWidth=fourK?560:520; c.nextCellWidth=fourK?340:320; c.laterCellWidth=fourK?340:320; c.farCellWidth=fourK?300:280;
                c.rowHeight=fourK?64:60; c.rowCellHeight=fourK?52:48; c.categoryRowHeight=fourK?60:58; c.categoryIconSize=fourK?50:48;
                c.rootScrimMid=Color.argb(236,38,5,66); c.rootScrimRight=Color.argb(236,78,14,118); c.guideCellColor=Color.argb(130,80,24,120); c.guideCellAltColor=Color.argb(106,65,20,96); c.guideFocusBgColor=Color.rgb(215,225,255); c.guideFocusTextColor=Color.rgb(42,28,58); c.categoryFocusBgColor=Color.rgb(142,86,236); c.categoryFocusTextColor=Color.WHITE; c.radius=10; break;
            case 5: c.name="Custom editable"; break;
            case 0: applyDebridChannelsBaseTheme(c, fourK); break;
            default: applyDebridChannelsBaseTheme(c, fourK); break;
        }
        if(c.previewWidth<(fourK?250:200) && c.previewWidth>1)c.previewWidth=fourK?250:200;
        if(c.rowHeight<44)c.rowHeight=44; if(c.rowCellHeight<38)c.rowCellHeight=38; if(c.headerHeight<150)c.headerHeight=150;
        c.forceRefreshVisible=false; c.showTopMenuArtifacts=false; c.copyReferenceProfileImages=false;
    }
    private static void applyDebridChannelsBaseTheme(LiveTvLayoutConfig c, boolean fourK) {
        // Base theme is a normal config preset. It is not a fallback renderer path.
        c.name="DebridChannels Base Theme";
        c.id="debridchannels_base";
    }
    private static String themeId(int theme){switch(theme){case 1:return"google_free_tv";case 2:return"tivimate_pro";case 3:return"minimal_grid";case 4:return"cinematic_overlay";case 5:return"custom";default:return"debridchannels_base";}}
    private static String themeName(int theme){switch(theme){case 1:return"Google Free TV";case 2:return"TiviMate Pro";case 3:return"Minimal Grid";case 4:return"Cinematic Overlay";case 5:return"Custom editable";default:return"DebridChannels Base Theme";}}
}
