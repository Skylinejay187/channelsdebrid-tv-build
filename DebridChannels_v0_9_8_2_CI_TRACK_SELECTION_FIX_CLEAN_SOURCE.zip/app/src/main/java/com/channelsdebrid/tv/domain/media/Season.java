package com.channelsdebrid.tv.domain.media;
import java.util.*;
public final class Season { public final int number; public final String title; public final List<Episode> episodes; public Season(int number,String title,List<Episode> episodes){this.number=number;this.title=title;this.episodes=episodes==null?Collections.emptyList():episodes;} }
