package com.channelsdebrid.tv.livetv.editor;
import android.graphics.RectF;
public final class SnapGrid { public final float size; public SnapGrid(float s){size=Math.max(1f,s);} public float snap(float v){return Math.round(v/size)*size;} public RectF snapRect(RectF r, boolean resize){ if(resize)return new RectF(r.left,r.top,snap(r.right),snap(r.bottom)); return new RectF(snap(r.left),snap(r.top),snap(r.right),snap(r.bottom));}}
