package com.channelsdebrid.tv.livetv.editor;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import com.channelsdebrid.tv.livetv.layout.LiveTvLayoutModel;

public final class LiveTvLayoutRepository {
    private static final String PREF="dc_live_tv_layout_v096";
    private static final String KEY="custom_json";
    public static void save(Context c, LiveTvLayoutModel m){c.getSharedPreferences(PREF,0).edit().putString(KEY,m.toJson()).apply();Log.i("DebridChannels","LIVE_TV_LAYOUT_SAVE_OK name="+m.name);}    
    public static LiveTvLayoutModel load(Context c){SharedPreferences p=c.getSharedPreferences(PREF,0);return LiveTvLayoutModel.fromJson(p.getString(KEY,""));}
    public static String exportJson(Context c){String json=load(c).toJson();Log.i("DebridChannels","LIVE_TV_LAYOUT_EXPORT_OK bytes="+json.length());return json;}
    public static void importJson(Context c,String json){LiveTvLayoutModel m=LiveTvLayoutModel.fromJson(json);save(c,m);Log.i("DebridChannels","LIVE_TV_LAYOUT_IMPORT_OK name="+m.name);}    
    public static void clear(Context c){c.getSharedPreferences(PREF,0).edit().clear().apply();Log.i("DebridChannels","LIVE_TV_LAYOUT_CLEAR_OK");}
}
