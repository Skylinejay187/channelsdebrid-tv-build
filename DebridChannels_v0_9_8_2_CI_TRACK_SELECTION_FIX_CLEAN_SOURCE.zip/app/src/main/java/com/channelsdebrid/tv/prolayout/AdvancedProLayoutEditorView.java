package com.channelsdebrid.tv.prolayout;

import android.content.*;
import android.graphics.*;
import android.view.*;
import java.util.*;

public final class AdvancedProLayoutEditorView extends View {
    public interface Listener { void onChanged(ArrayList<ProLayoutItem> items, ProLayoutItem selected); }
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ArrayList<ProLayoutItem> items;
    private Listener listener;
    private int selected = 0;
    private boolean resizeMode = false;
    private float scale = 1f;

    public AdvancedProLayoutEditorView(Context c) { super(c); items = ProLayoutRepository.load(c); setFocusable(true); setFocusableInTouchMode(true); }
    public void setListener(Listener l){ listener = l; }
    public ProLayoutItem selectedItem(){ return items.get(Math.max(0, Math.min(selected, items.size()-1))); }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        scale = Math.max(.1f, getWidth() / 1280f);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(188, 6, 12, 24));
        canvas.drawRoundRect(0,0,getWidth(),getHeight(),18,18,p);
        drawGrid(canvas);
        for (int i=0;i<items.size();i++) drawItem(canvas, items.get(i), i==selected);
        drawAlignmentGuides(canvas, selectedItem());
        p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE); p.setTextSize(14f * getResources().getDisplayMetrics().scaledDensity);
        canvas.drawText("Advanced Pro Layout Editor • OK selects • DPAD moves • long OK toggles resize • snap=8dp", 20, getHeight()-20, p);
    }

    private void drawGrid(Canvas c){
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(Color.argb(34,255,255,255));
        float step = 32 * scale;
        for(float x=0;x<getWidth();x+=step)c.drawLine(x,0,x,getHeight(),p);
        for(float y=0;y<getHeight();y+=step)c.drawLine(0,y,getWidth(),y,p);
    }

    private void drawItem(Canvas c, ProLayoutItem item, boolean active){
        RectF r = rect(item);
        p.setStyle(Paint.Style.FILL); p.setColor(active ? Color.argb(110,34,132,220) : Color.argb(70,60,70,92));
        c.drawRoundRect(r,14,14,p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(active ? 4 : 2); p.setColor(active ? Color.argb(240,95,190,255) : Color.argb(120,255,255,255));
        c.drawRoundRect(r,14,14,p);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE); p.setTextSize(15f * getResources().getDisplayMetrics().scaledDensity);
        c.drawText((active ? (resizeMode ? "↔ " : "✥ ") : "") + item.label, r.left+12, r.top+26, p);
        p.setTextSize(11f * getResources().getDisplayMetrics().scaledDensity); p.setColor(Color.argb(210,235,244,255));
        c.drawText(item.xDp+","+item.yDp+"  "+item.widthDp+"×"+item.heightDp+"dp", r.left+12, r.top+46, p);
    }

    private void drawAlignmentGuides(Canvas c, ProLayoutItem item){
        RectF r = rect(item); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(Color.argb(175,80,210,255));
        c.drawLine(r.centerX(), 0, r.centerX(), getHeight(), p); c.drawLine(0, r.centerY(), getWidth(), r.centerY(), p);
    }

    private RectF rect(ProLayoutItem item){ return new RectF(item.xDp*scale, item.yDp*scale, (item.xDp+item.widthDp)*scale, (item.yDp+item.heightDp)*scale); }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        int step = event.isShiftPressed() ? 32 : 8;
        ProLayoutItem item = selectedItem();
        if(keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) { selected = (selected + 1) % items.size(); notifyChange(); invalidate(); return true; }
        if(keyCode == KeyEvent.KEYCODE_MENU || keyCode == KeyEvent.KEYCODE_BUTTON_Y) { resizeMode = !resizeMode; invalidate(); return true; }
        if(keyCode == KeyEvent.KEYCODE_DPAD_LEFT) { if(resizeMode)item.widthDp=Math.max(40, item.widthDp-step); else item.xDp=Math.max(0, item.xDp-step); snapItem(item); notifyChange(); invalidate(); return true; }
        if(keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) { if(resizeMode)item.widthDp+=step; else item.xDp+=step; snapItem(item); notifyChange(); invalidate(); return true; }
        if(keyCode == KeyEvent.KEYCODE_DPAD_UP) { if(resizeMode)item.heightDp=Math.max(30, item.heightDp-step); else item.yDp=Math.max(0, item.yDp-step); snapItem(item); notifyChange(); invalidate(); return true; }
        if(keyCode == KeyEvent.KEYCODE_DPAD_DOWN) { if(resizeMode)item.heightDp+=step; else item.yDp+=step; snapItem(item); notifyChange(); invalidate(); return true; }
        return super.onKeyDown(keyCode, event);
    }

    private void snapItem(ProLayoutItem item){ item.xDp=ProLayoutRepository.snap(item.xDp); item.yDp=ProLayoutRepository.snap(item.yDp); item.widthDp=ProLayoutRepository.snap(item.widthDp); item.heightDp=ProLayoutRepository.snap(item.heightDp); }
    public ArrayList<ProLayoutItem> snapshot(){ ArrayList<ProLayoutItem> out=new ArrayList<>(); for(ProLayoutItem i:items)out.add(i.copy()); return out; }
    public void save(){ ProLayoutRepository.save(getContext(), snapshot()); }
    private void notifyChange(){ if(listener!=null) listener.onChanged(snapshot(), selectedItem()); }
}
