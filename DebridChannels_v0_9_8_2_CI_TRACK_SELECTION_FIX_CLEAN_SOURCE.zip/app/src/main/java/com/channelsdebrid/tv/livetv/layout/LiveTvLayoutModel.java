package com.channelsdebrid.tv.livetv.layout;

import android.graphics.RectF;
import org.json.JSONObject;

public final class LiveTvLayoutModel {
    public static final class RectPct {
        public float left, top, width, height;
        public RectPct(float l,float t,float w,float h){left=l;top=t;width=w;height=h;}
        public RectF toPx(float sw,float sh){return new RectF(left*sw,top*sh,(left+width)*sw,(top+height)*sh);}        
        public static RectPct fromPx(RectF r,float sw,float sh){return new RectPct(r.left/sw,r.top/sh,r.width()/sw,r.height()/sh);}        
        public JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("left",left);o.put("top",top);o.put("width",width);o.put("height",height);return o;}
        public static RectPct from(JSONObject o){return new RectPct((float)o.optDouble("left"),(float)o.optDouble("top"),(float)o.optDouble("width"),(float)o.optDouble("height"));}
    }
    public String name="Custom";
    public int guideRows=5;
    public int snapGridDp=8;
    public boolean showAlignmentGuides=true;
    public RectPct preview=new RectPct(.70f,.09f,.25f,.25f);
    public RectPct guideGrid=new RectPct(.20f,.48f,.76f,.42f);
    public RectPct categoryRail=new RectPct(.03f,.22f,.16f,.68f);
    public RectPct timeline=new RectPct(.20f,.43f,.76f,.04f);
    public LiveTvLayoutModel enforce(){
        guideRows=Math.max(3,Math.min(7,guideRows));
        if(preview.left<0)preview.left=0; if(preview.top<0)preview.top=0;
        if(preview.left+preview.width>1)preview.left=1-preview.width; if(preview.top+preview.height>1)preview.top=1-preview.height;
        guideGrid.top=Math.max(.40f,guideGrid.top); guideGrid.height=Math.min(.50f,Math.max(.24f,guideGrid.height)); guideGrid.top=1f-guideGrid.height-.05f;
        timeline.left=guideGrid.left; timeline.width=guideGrid.width; timeline.top=Math.max(.34f,guideGrid.top-.055f); timeline.height=.04f;
        return this;
    }
    public JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("name",name);o.put("guideRows",guideRows);o.put("snapGridDp",snapGridDp);o.put("showAlignmentGuides",showAlignmentGuides);o.put("preview",preview.json());o.put("guideGrid",guideGrid.json());o.put("categoryRail",categoryRail.json());o.put("timeline",timeline.json());return o;}
    public String toJson(){try{return json().toString(2);}catch(Exception e){return "{}";}}
    public static LiveTvLayoutModel fromJson(String s){try{JSONObject o=new JSONObject(s);LiveTvLayoutModel m=new LiveTvLayoutModel();m.name=o.optString("name","Custom");m.guideRows=o.optInt("guideRows",5);m.snapGridDp=o.optInt("snapGridDp",8);m.showAlignmentGuides=o.optBoolean("showAlignmentGuides",true);if(o.has("preview"))m.preview=RectPct.from(o.getJSONObject("preview"));if(o.has("guideGrid"))m.guideGrid=RectPct.from(o.getJSONObject("guideGrid"));if(o.has("categoryRail"))m.categoryRail=RectPct.from(o.getJSONObject("categoryRail"));if(o.has("timeline"))m.timeline=RectPct.from(o.getJSONObject("timeline"));return m.enforce();}catch(Exception e){return new LiveTvLayoutModel().enforce();}}
}
