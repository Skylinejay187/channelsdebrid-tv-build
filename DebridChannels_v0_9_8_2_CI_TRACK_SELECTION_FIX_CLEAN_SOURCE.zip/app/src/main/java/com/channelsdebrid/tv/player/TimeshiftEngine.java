package com.channelsdebrid.tv.player;
import android.content.Context;import java.io.File;import com.channelsdebrid.tv.core.AppLogger;
public final class TimeshiftEngine {
    private final File dir;
    public TimeshiftEngine(Context c){ dir=new File(c.getCacheDir(),"timeshift-v5"); if(!dir.exists()) dir.mkdirs(); AppLogger.mark("TimeshiftEngine single owner ready"); }
    public File dir(){ return dir; }
}
