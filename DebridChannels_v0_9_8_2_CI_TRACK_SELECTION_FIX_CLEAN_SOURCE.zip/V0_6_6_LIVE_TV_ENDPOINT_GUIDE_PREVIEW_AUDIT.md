# v0.6.6 Live TV Endpoint + Guide + Preview Fix

Base: v0.6.5 clean source.

Changes:
- Added dedicated muted live preview Media3 player in the guide preview card.
- Preview starts when a channel row is focused/highlighted.
- OK/ENTER still expands the highlighted channel into fullscreen Live TV playback.
- Replaced generic MediaSource playback with explicit HLS/DASH/Progressive media source factories to fix source-factory errors.
- Channels DVR stream URLs now use format=ts&codec=copy.
- M3U parsing now keeps tvg-id/channel-number metadata for future EPG matching.
- Removed guide-logo background behavior remains preserved for performance.

Known next step:
- Full XMLTV/short-EPG program matching should be expanded if guide placeholders are still shown for providers without embedded guide data.
