# Debrid Channels v0.4.3 — Weather + Trailer Audio + Media Info + Hero Responsiveness Fix

Base used: v0.4.2 Unlimited Addons + Weather Hub clean source, originally consolidated from v0.3.0 Dynamic Hero + Theme Engine.

Build method: clean consolidation only. No old app code reused.

Preserved:
- Dynamic Hero + Theme Engine
- Pro Layout Editor
- Unlimited Stremio Addon Manager
- Automatic Stremio manifest name/icon detection
- Trailer endpoint resolver/player wiring
- TV show seasons/episodes system
- Existing Media3 playback pipeline
- RD / Torbox / Stremio compatibility
- Backend base URL behavior

Fixed/changed:
- Weather Status Hub now uses Open-Meteo current temperature API with fallback current_weather endpoint.
- Weather hub now displays city + temperature instead of a blank placeholder.
- Trailer audio now starts unmuted by default; the mute toggle remains available.
- Trailer player user-agent/build marker updated to v0.4.3.
- Media info screen no longer shows portrait poster art for movies or shows.
- Media info content is centered after poster removal to avoid empty left-side layout.
- Hero focus update delay reduced from 210ms to 35ms.
- Hero updates now use a sequence guard so older delayed focus events cannot override the newest focused card.

Build marker:
DC_BUILD_MARKER: v0.4.3_weather_audio_media_info_hero_fix_clean_base
