# Debrid Channels v0.4.4 Trailer Audio Audit

Base used: v0.4.3 clean source.

Build method: clean consolidation from the latest known-good clean base. No old app code reused.

Fix target: trailers were visually playing but audio did not come through even after pressing Unmute.

Changes:
- Trailer overlay now creates a dedicated Media3 ExoPlayer instance for trailer playback.
- Trailer player uses explicit Media3 AudioAttributes with USAGE_MEDIA and AUDIO_CONTENT_TYPE_MOVIE.
- Trailer player requests audio focus through setAudioAttributes(..., true).
- Trailer player force-applies volume 1.0 when unmuted and 0.0 only when muted.
- Trailer player attempts to clear device mute when applying trailer audio state.
- Trailer player no longer depends on the main VOD player audio state.
- Added decoder fallback renderers factory for trailer streams.
- Added audio diagnostics through AppLogger.

New log markers:
- DC_TRAILER_AUDIO: player_create
- DC_TRAILER_AUDIO: apply
- DC_TRAILER_AUDIO: prepared
- DC_TRAILER_AUDIO: tracks_changed audioGroups=...
- DC_TRAILER_AUDIO: player_error

Preserved:
- v0.4.3 weather/status hub work
- v0.4.3 media info centered/no poster layout
- v0.4.3 hero focus update guard
- v0.4.2 unlimited Stremio addons
- v0.4.1 trailer endpoint resolving
- v0.4.0 TV show/episode navigation
- v0.3.0 hero/theme/editor/playback base systems

Build marker:
DC_BUILD_MARKER: v0.4.4_trailer_dedicated_audio_player_clean_base
