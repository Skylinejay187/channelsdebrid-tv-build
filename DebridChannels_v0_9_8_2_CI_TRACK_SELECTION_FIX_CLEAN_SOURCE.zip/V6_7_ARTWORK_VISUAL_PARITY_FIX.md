# v6.7 Artwork Mapping + Visual Parity Fix

Base: v6.6 poster artwork backend loader.

Changes:
- Removed visible Banner placeholder text from hero extra-art slot.
- Banner slot now stays empty unless backend provides banner/logo artwork.
- Row cards prefer banner/landscape artwork, then poster, then background.
- Hero background uses background/backdrop first, then poster fallback.
- Hero clearlogo loads separately and hides plain title only when available.
- Tightened hero metadata/description spacing.
- Improved rounded landscape card styling, focus glow/elevation, and focused-card scale.
- Added lightweight in-memory image cache to reduce flicker while moving across cards.
- Top menu intentionally unchanged; future theme system can customize it later.

Marker: DC_V6_7_ARTWORK_VISUAL_PARITY_FIX
