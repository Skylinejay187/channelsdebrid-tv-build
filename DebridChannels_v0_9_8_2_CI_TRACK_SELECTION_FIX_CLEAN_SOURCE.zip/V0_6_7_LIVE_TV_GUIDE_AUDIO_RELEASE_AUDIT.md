# v0.6.7 Live TV Guide + Audio Release Fix

Base: v0.6.6 Live TV Endpoint + Guide + Preview Fix.

Clean rebuild/consolidation rules preserved:
- No stale patch stacking intentionally carried forward.
- Preserve global 4K system, hero, VOD, trailer, Stremio addon manager, and current Live TV shell.

Fixes:
- Releases fullscreen Live TV player when returning to the guide.
- Releases any previous Media3 player before starting another channel.
- Stops preview/player audio bleed when leaving or changing Live TV views.
- Adds Channels DVR XMLTV guide loading from `/devices/ANY/guide/xmltv`.
- Adds M3U XMLTV discovery from `url-tvg`, `x-tvg-url`, and `tvg-url` headers.
- Adds limited Xtream short EPG hydration from `get_short_epg`.
- Uses real EPG titles in guide rows and hero info when available.
- Keeps channel logos out of guide background for performance.

Marker:
DC_BUILD_MARKER: v0.6.7_livetv_guide_audio_release_clean_base
