# Debrid Channels v0.6.1 Trailer Audio Stream Fallback Audit

Base used: v0.6.0 Live TV Preview + Full Guide Expand clean source.

Build method: clean consolidation from latest source, no stale generated code carryover.

Preserved:
- Full app 4K UI system
- Live TV old-app/reference layout work
- Preview/full guide expansion behavior
- Playback systems
- Stremio unlimited addon manager
- Media info and trailer overlay behavior

Fixed/Added:
- Trailer resolver now collects multiple playable trailer URLs instead of stopping at the first URL.
- HLS `.m3u8` candidates are preferred before MP4/direct candidates when available.
- Trailer overlay stores fallback trailer source list.
- If Media3 reports zero audio track groups, the player automatically switches to the next resolved trailer source.
- Added logs for candidate count, fallback index, and no-more-source cases.

Important note:
If every resolved trailer candidate is video-only, the app will still report no detected audio track. That means backend resolver needs to expose an audio+video/muxed source for that specific title.

Marker:
DC_BUILD_MARKER: v0.6.1_trailer_audio_stream_fallback_clean_base
