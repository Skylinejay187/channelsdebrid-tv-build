# v0.5.7 Old App Live TV Layout Port Audit

Base: v0.5.6 clean source.

Change: replaced the failed wide/spaced Live TV guide with an old-app-style structural port: compact left category rail, main guide panel starting beside it, old-style info panel, preview card, timeline row, continuous guide rows, and focus-reactive metadata.

Old app usage: Live TV layout/structure reference only, ported into the current Java app shell. Non-Live-TV systems preserved.

Preserved: hero, Stremio addon manager, trailers, playback, settings, top menu visibility, BACK-to-home behavior, and live channel playback hook.

Marker: DC_BUILD_MARKER: v0.5.7_old_app_live_tv_layout_port_clean_base
