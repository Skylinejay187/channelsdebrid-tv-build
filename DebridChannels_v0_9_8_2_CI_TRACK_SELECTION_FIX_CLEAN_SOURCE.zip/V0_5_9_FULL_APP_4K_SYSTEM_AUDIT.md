# Debrid Channels v0.5.9 — Full App 4K System Audit

Base used: v0.5.8 Live TV 4K Density + Layout Fix.
Build method: clean consolidation from latest known-good source; no old broken build stacking.

## Added
- Global 4K/high-density UI detection used by all screens.
- Global dp scaling layer for Home, Movies, Shows, Settings, Media Info, Player overlay, and Live TV.
- Global text scaling layer for consistent 4K typography.
- Preserved Live TV-specific tighter density through `ldp/lsp` while using the same global 4K mode switch.
- Boot log marker for display width, height, density, and 4K active state.

## Preserved
- Dynamic Hero + Theme Engine
- Pro Layout Editor and 4K toggle
- Stremio unlimited addon manager
- Trailer overlay system
- VOD playback pipeline
- Live TV old-app/reference structure
- Back behavior and top menu visibility

## Known Backlog Still Parked
- Weather status hub final polish
- Trailer audio/no-audio-track edge cases
- Media info overflow polish if still visible after global scale
- VOD player Dolby Vision/audio/frame-rate/resolution matching verification before final app completion

## Marker
DC_BUILD_MARKER: v0.5.9_full_app_4k_system_clean_base
