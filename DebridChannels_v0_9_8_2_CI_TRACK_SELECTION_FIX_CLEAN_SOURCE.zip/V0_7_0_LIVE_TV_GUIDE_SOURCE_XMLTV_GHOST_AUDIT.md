# Debrid Channels v0.7.0 Audit

Base used: latest clean v0.6.9 XMLTV OOM fix source.

Build method: clean consolidation; no old broken generated code carried forward.

Changes:
- Added user-selectable Live TV guide source mode: Auto, Channels DVR, Xtream Codes, XMLTV Manual.
- Added XMLTV Guide URL setting as a manual fallback/primary guide source.
- XMLTV parser remains streaming line-by-line to avoid OOM.
- XMLTV parser now also reads `<channel>` display-name aliases so program `channel` ids can match app channel names/tvg ids more reliably.
- Manual XMLTV is applied after channel sources load when guide mode is Auto or XMLTV Manual.
- Force Refresh Guide button hides in full-guide mode and returns when categories are visible.
- Removed visible boot/demo hero placeholder text that caused the original UI “focus a card...” ghost layer to appear at startup.

Preserved:
- Hero/Home forced 1080p UI scaling.
- Rest of app stays 4K UI scaling, including Pro Layout Editor, Media Info, Live TV, Settings, and Player overlays.
- Live TV playback and preview structure from current clean branch.
- HLS/DASH/progressive player support and audio release fixes.

Marker:
DC_BUILD_MARKER: v0.7.0_livetv_guide_source_selector_xmltv_fallback_startup_ghost_fix_clean_base
