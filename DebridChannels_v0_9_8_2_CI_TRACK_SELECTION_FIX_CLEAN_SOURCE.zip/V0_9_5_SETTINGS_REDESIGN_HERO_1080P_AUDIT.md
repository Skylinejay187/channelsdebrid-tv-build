# v0.9.5 Settings Redesign + Hero 1080p Default Audit

Base used: `DebridChannels_v0_9_4_LIVE_TV_CONFIG_ROUTING_AUDIT_SOURCE`.

Clean consolidation rule:
- This pass is additive/stabilizing only from the accepted v0.9.4 audit source.
- No Live TV renderer fallback was reintroduced.
- Live TV theme/config routing and visible ACTIVE THEME / THEME_APPLY logging from v0.9.4 are preserved.

Changes:
- Added startup default initializer so `heroDensityMode` defaults to `0` (`1080p style`) on first launch of this base.
- Added boot log marker: `DC_HERO_DEFAULT: heroDensityMode=1080p_style startup_default_v095`.
- Updated all Hero UI Density fallback reads to `0` so fresh installs start in 1080p-style hero mode.
- Rebuilt Settings as a modern two-pane UI:
  - left rail categories
  - right detail panel
  - organized sections: General, Live TV, Playback, Appearance, Accounts, Advanced
  - DPAD-focusable category rail and setting rows
- Preserved existing setting actions by moving them into organized categories.

Live TV regression guard:
- No Force Refresh button added.
- Existing Live TV Layout Editor entry remains available.
- Live TV reload, cache clear, guide source, XMLTV, M3U, Channels DVR and Xtream settings remain available.
- Existing Live TV config renderer code was not replaced.

Build marker:
- `DC_BUILD_MARKER: v0.9.5_settings_redesign_hero_1080p_default_clean_base`
