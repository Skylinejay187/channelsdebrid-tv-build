# Debrid Channels v0.3.0 — Dynamic Hero + Theme Engine

Clean rewrite/consolidation from v0.2.3 stable base.

Adds hero typography controls, dynamic hero rotation, and expanded Extra Artwork Slot options while preserving the existing playback/UI baseline.

## v0.8.5 Live TV Final Polish
Preview bounds, guide spacing, row focus polish, and density-safe Live TV layout refinements.


## v0.9.8
Added Pro Layout Editor poster/background lighting slider to brighten dim hero poster/backdrop lighting without touching Live TV player logic.
