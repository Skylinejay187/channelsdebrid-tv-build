# Debrid Channels v0.7.8 — Image Quality Modes + Extra Art 3D + Hero Alignment

Base used: v0.7.7 clean source.
Build method: clean consolidation / no old under-layout restore.

Added:
- Image Quality Mode setting: Balanced, Pro Quality, Advanced Quality, Ultra / old-app full source.
- Ultra mode keeps source artwork resolution whenever memory allows, matching the old app's visually aggressive artwork behavior.
- Pro and Advanced modes provide higher 4K quality for better hardware without forcing Ultra everywhere.
- Extra Artwork 3D tilt option and tilt strength.
- Hero logo alignment option, default locked to the same left axis as hero text/meta/description.
- Focus ring default changed off, and disabled ring now truly removes the stroke path.

Preserved:
- Live TV high-scale guide work.
- VOD/trailer/player upgrades.
- Pro Layout Editor.
- Stremio addon manager.
- Clean single-root UI cleanup.

Marker:
DC_BUILD_MARKER: v0.7.8_image_quality_modes_extra_art_3d_focus_hero_alignment_clean_base
