# v0.6.3 Trailer Video Restore + Hero Alignment + HQ Artwork Audit

Base used: v0.6.2 clean source.

Clean-base rule: preserved existing app systems and only changed the trailer overlay player selection behavior, hero logo/text alignment, startup underlay clearing, and image decode quality.

Fixes:
- Disabled automatic trailer audio-source fallback that caused black/blank trailer video after switching sources.
- Trailer overlay now keeps the working video visible when Media3 reports no audio track.
- Trailer URL priority restored toward direct playable video before HLS variants to avoid black HLS regressions.
- Trailer overlay resize mode changed from ZOOM to FIT.
- Hero logo default left edge now shares the same left axis as hero text/meta/description.
- Startup hero backdrop now starts from a clean black base and clears stale art on every URL change.
- Row-card artwork decoding upgraded to ARGB_8888 for best available image quality.
- Row-card artwork selection prefers landscape/banner/backdrop first, poster only as fallback.

Known backlog still parked:
- Weather hub polish.
- Trailer audio may still require backend-side muxed audio+video selection if source stream truly has no audio track.
- VOD Dolby Vision/audio/frame-rate/resolution matching before final app completion.
