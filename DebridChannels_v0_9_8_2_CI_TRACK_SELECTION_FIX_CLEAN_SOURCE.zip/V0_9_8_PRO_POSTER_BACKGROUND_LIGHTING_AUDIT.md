# v0.9.8 Pro Layout Editor Poster/Background Lighting Control

Base: v0.9.7 Live TV Reference Layout Rewrite clean source.

## Added
- Added Pro Layout Editor slider: `Poster/background lighting`.
- Range: 40–140 percent.
- Default: 100 percent, preserving existing look until changed.
- Applies live during editor preview.
- Reduces hero backdrop/tone/side/bottom overlay darkness when raised so poster/backdrop art is less dim.
- Added log marker: `PRO_POSTER_LIGHTING_APPLY: percent=...`.

## Preserved
- Live TV player logic untouched.
- Live TV reference layout rewrite untouched.
- v0.9.5 hero 1080p default/settings redesign preserved.
- v0.9.6 advanced Live TV editor source preserved.
- No Force Refresh button added.
- Dolby Vision / Dolby-DTS / frame-rate / resolution matching backlog compatibility preserved only; not implemented here.
