# Debrid Channels v0.9.0 — Live TV Layout Engine + Real Theme Application

## Base
Clean consolidation from v0.8.7 Live TV Layout Stabilization + Theme Foundation.

## What changed
- Added `LiveTvLayoutConfig` as the single source of truth for Live TV preset geometry and theme styling.
- Live TV renderer now reads layout values from `LiveTvLayoutConfig.preset(...)` instead of using hidden hard-coded theme values.
- Theme changes now alter real rendered values such as category rail size, main guide shell, preview width/placement, timeline spacing, guide cell colors, row height, header height, and radius.
- Added clear log marker for applied theme/config:
  - `LIVE_TV_V090_ENGINE: applied theme=... id=... main=... previewW=...`
- Removed Live TV theme/layout controls from the Pro Layout Editor path. Live TV controls remain in Settings until v0.9.1 introduces the dedicated Live TV Layout Editor.

## Preserved
- Live TV guide cache and 2500+ channel scaling work.
- XMLTV memory-safe parser and source modes.
- DVR/Xtream/XMLTV settings.
- Preview/player lifecycle fixes.
- Home/VOD/Trailers/Pro Layout Editor.

## Marker
`DC_BUILD_MARKER: v0.9.0_livetv_layout_engine_real_theme_application_clean_base`

## Next planned step
v0.9.1 — Basic Live TV Layout Editor UI that edits this config path.
