# v0.8.2 Live TV Density Fit Mode Audit

Base: v0.8.1 clean consolidated scale verification + guide cache source.

Changes:
- Added separate Live TV UI Density setting.
- Live TV density options: Auto Fit (default), 1080p style, 4K compact.
- Auto Fit calculates a Live-TV-only scale from the actual display width/height so the guide fits the visible screen instead of cropping in 1080p mode.
- Hero UI Density remains separate from Live TV UI Density.
- Everything else remains under the existing 4K/mixed-density rules.
- Existing full-guide behavior preserved: RIGHT from categories expands guide; LEFT returns categories; Force Refresh stays hidden in full-guide mode.

Preserved:
- Live TV source loading, guide cache, XMLTV memory-safe parsing, Channels DVR/Xtream/M3U support.
- VOD, trailers, Pro Layout Editor, image quality modes, extra artwork options.

Build marker: DC_BUILD_MARKER: v0.8.2_livetv_density_fit_mode_clean_base
