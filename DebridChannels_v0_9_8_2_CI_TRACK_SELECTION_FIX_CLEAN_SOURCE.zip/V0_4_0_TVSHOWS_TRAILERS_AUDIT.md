# Debrid Channels v0.4.0 TV Shows + Trailer Overlay System

Base used: v0.3.0 Dynamic Hero + Theme Engine.

Build method: clean consolidation from latest stable base. No old app code was copied. No stale generated code was carried forward.

Preserved systems:
- Dynamic hero + theme engine
- Pro Layout Editor and live preview
- Extra Artwork Slot behavior
- Status/navigation behavior
- Existing Media3 VOD player and resolver pipeline
- Stremio addon link loading
- Real-Debrid / Torbox resolver parity
- Backend base URL default: http://192.168.100.55:8181

Added systems:
- TV show detection using media type series/show/tv
- Show episode browser with season selector and DPAD-friendly episode rows
- Episode-to-stream selection using the existing playback resolver path
- Media Info actions: Episodes/Play, Trailer, Favorite, Back
- Trailer overlay preview on Media Info / Episodes screens
- Trailer backend wiring: /api/trailer/:id, /trailers/resolve, /trailers/extract
- Trailer settings: auto popup, delay 0/2/5/10s, muted default, disable completely
- Updated build marker: DC_BUILD_MARKER: v0.4.0_tvshows_trailers_clean_base

Next target: v0.5.0 Live TV Guide Rebuild.
