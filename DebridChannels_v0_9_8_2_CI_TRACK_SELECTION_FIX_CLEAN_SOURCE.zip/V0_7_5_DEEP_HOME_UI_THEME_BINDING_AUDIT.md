# v0.7.5 Deep Home UI Rebuild + Pro Editor Theme Binding Audit

Base used: v0.7.4 clean source.

## Fixes
- Deep cleaned the Home/Hero theme path so Pro Layout Editor writes directly to the visible Home/Hero UI.
- Wired Hero text theme/layout options into the actual visible hero title, logo, metadata row, description, and optional glass panel.
- Removed stale Java temp source file from the package.
- Added startup marker confirming the app is using one programmatic root and no XML placeholder/under-layout startup path.
- Added live apply path for hero sliders so changes immediately update the visible hero preview.

## Preserved
- Live TV high-scale guide system.
- DVR/Xtream/XMLTV guide source selector.
- Hero 1080p/4K density setting with 4K default.
- Pro Layout Editor.
- Playback, trailers, VOD, Stremio addon manager.

Marker: DC_BUILD_MARKER: v0.7.5_deep_home_ui_rebuild_pro_editor_theme_binding_clean_base
