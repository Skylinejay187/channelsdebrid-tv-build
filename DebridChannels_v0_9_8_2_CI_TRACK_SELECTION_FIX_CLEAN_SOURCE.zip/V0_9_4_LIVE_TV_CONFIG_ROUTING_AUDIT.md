# v0.9.4 Live TV Config Routing Audit

Base used:
- DebridChannels_v0_9_3_LIVE_TV_THEME_RENDERER_BINDING_FIX_CLEAN_SOURCE.zip

Goal:
- Audit Live TV view creation paths before advanced drag/resize editor work.
- Remove remaining fixed Live TV geometry from renderer hot paths where possible.
- Route visible Live TV component geometry through `LiveTvLayoutConfig`.
- Keep DebridChannels Base Theme as a normal config preset, not as fallback renderer behavior.

Implemented:
- Added visible temporary `ACTIVE THEME: <name>` label on the Live TV screen.
- Updated renderer debug marker to:
  - `LIVE_TV_THEME_APPLIED_RENDERER: ACTIVE THEME: ...`
- Added required per-component log lines:
  - `THEME_APPLY: categoryRail=...`
  - `THEME_APPLY: guide=...`
  - `THEME_APPLY: preview=...`
  - `THEME_APPLY: timeline=...`
- Added config fields for visible Live TV renderer geometry that was still fixed in code:
  - guide viewport extra height
  - guide row bottom padding
  - category header heights
  - active theme label bounds/text size
  - live preview badge bounds
  - preview minimum width / safe margin / image padding
- Preserved hard-locked Live TV rules:
  - Preview remains `RESIZE_MODE_FIT` and root-anchored to prevent crop.
  - Guide remains bottom anchored.
  - Default guide rows remain 5 through `liveTvVisibleRows` default.
  - Force Refresh Guide stays removed from visible Live TV UI.
  - Reference artifacts remain disabled: profile images/top menus are not copied.
- Converted DebridChannels Base Theme into explicit config application via `applyDebridChannelsBaseTheme(...)`.

Preserved:
- Existing Live TV theme modes.
- Basic Live TV Layout Editor.
- Pro Layout Editor entry point.
- DPAD navigation behavior.
- Existing Live TV source loading / guide cache / preview playback behavior.
- Backend/artwork/carousel systems were not touched.

Build marker:
- `DC_BUILD_MARKER: v0.9.4_live_tv_theme_config_audit_clean_base`

Verification:
- Source audit completed.
- Full Gradle build could not be executed in this container because the uploaded project wrapper calls a system `gradle` binary and this environment does not have `gradle` installed.
