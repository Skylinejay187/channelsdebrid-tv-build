# v0.9.6 Advanced Live TV Layout Editor Audit

Base used: `v0.9.5_settings_redesign_hero_1080p_default_clean_base`.

Clean consolidation rule followed: v0.9.6 is additive on the accepted v0.9.5 base. It preserves Hero 1080p default, redesigned Settings left rail/right panel, organized categories, DPAD navigation, Live TV theme routing, per-component THEME_APPLY logging, backend/artwork/carousel systems, and Pro Layout Editor separation.

Implemented source layer:
- Advanced Live TV drag/resize editor view.
- Preview window drag and resize.
- Guide grid move/resize with bottom-anchor hard rule enforcement.
- Category rail move/resize.
- Snap-to-grid system.
- Visual alignment guide lines while editing.
- Save/load custom layout repository.
- Export/import JSON repository methods.
- Debug markers: `DC_BUILD_MARKER: v0.9.6...`, `LIVE_TV_ADVANCED_EDITOR_READY`, `LIVE_TV_LAYOUT_EXPORT_OK`, `LIVE_TV_LAYOUT_IMPORT_OK`.

Hard locks preserved:
- Preview clamped fully visible.
- Guide remains bottom anchored.
- Default guide rows remain 5, configurable 3-7.
- No Force Refresh button added.
- No profile/menu/random reference artifacts added.

Backlog preserved, not implemented:
- Dolby Vision support.
- Dolby/DTS audio handling.
- Frame-rate matching.
- Resolution matching.
