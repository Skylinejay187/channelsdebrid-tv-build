# v0.6.2 Hero Logo Alignment + Startup Underlay Fix

Base used: v0.6.1 Trailer Audio Stream Fallback clean base.

Changes:
- Hero logo now uses the same default left alignment axis as hero title/metadata text.
- Added runtime alignment log marker: HERO_ALIGNMENT.
- Fixed startup/hero-change ghost underlay by clearing stale hero backdrop/logo before loading new uncached art.
- Changed cinematic image swap to set the new bitmap before fade-in instead of fading the old image down first.
- Added HERO_IMAGE_SWAP log marker for verification.

Preserved:
- Live TV v0.6.0 full-guide expand behavior.
- Trailer v0.6.1 fallback behavior.
- Full app 4K scaling system.
- Pro Layout Editor and all existing settings.
