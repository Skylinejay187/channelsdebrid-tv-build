# v0.9.8.1 CI Compile Fix Audit

Base used: DebridChannels_v0_9_8_PRO_POSTER_BACKGROUND_LIGHTING_CONTROL_CLEAN_SOURCE.zip.

Clean-core rule followed: this patch only fixes the GitHub Actions Java compile failure and preserves the existing v0.9.8 app structure/features.

Fix applied:
- Removed the direct Media3 Builder call to `setForceHighestSupportedBitrate(true)` from `applyPlaybackQualityPreferences()` because the CI dependency set is pinned to Media3 1.3.1 and can fail Java compilation when that API is unavailable.
- Kept max video size preference and audio attribute application intact.
- Updated build marker to `DC_BUILD_MARKER: v0.9.8.1_pro_poster_background_lighting_ci_compile_fix_clean_source`.

Preserved:
- Pro Layout Editor
- Advanced Live TV Layout Editor
- DPAD/focus behavior
- backend artwork loading
- poster/background lighting slider
- hero 1080p startup default
- Live TV theme/config routing
- clean consolidated source layout
