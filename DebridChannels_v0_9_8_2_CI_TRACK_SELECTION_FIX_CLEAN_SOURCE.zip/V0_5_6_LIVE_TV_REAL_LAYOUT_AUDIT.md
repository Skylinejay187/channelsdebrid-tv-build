# v0.5.6 Live TV Real Layout Correction Audit

Base: v0.5.5 clean source package.
Method: clean consolidation of the Live TV screen behavior; no old app code copied.

Fixes:
- Removed fake sample Live TV fallback channels from the seed data.
- Auto-loads the saved M3U/Channels DVR URL on app start.
- Force Refresh Guide reloads the saved URL and refreshes the Live TV screen when loaded.
- Tightened the category rail width/position so it no longer consumes the guide area.
- Repositioned hero info, preview card, timeline, and guide shell closer to the Google reference structure.
- Updated marker to v0.5.6.

Known remaining work:
- Real EPG program metadata/timeline duration mapping still needs a dedicated guide-data parser pass.
- Top-right live preview can be upgraded from logo preview to true muted live preview.
