# Debrid Channels v0.9.2 — Real Theme Pack + Force Refresh Removal

Base used: v0.9.1 Basic Live TV Layout Editor UI clean source.

## Scope
- Replaced placeholder Live TV theme labels with real layout-config presets.
- Added `DebridChannels Base Theme` as the default old-app/Arvio-inspired baseline.
- Added image-reference layout themes:
  - Google Free TV
  - TiviMate Pro
  - Minimal Grid
  - Cinematic Overlay
  - Custom editable
- Removed the visible `Force Refresh Guide` button from the guide UI.
- Kept guide refresh actions in Settings only.
- Added logs to prove real theme application:
  - `LIVE_TV_V092_THEME_ENGINE: applied_real_theme=...`
  - `forceRefreshVisible=false`
  - `referenceArtifacts=false`

## Reference image rule
Screenshots are used only for guide layout structure, spacing, focus behavior, preview placement, and timeline styling. This build does not intentionally copy unrelated screenshot artifacts such as profile pictures, foreign top menus, TV bezels, device wallpaper, or other non-guide UI elements.

## Preserved
- Live TV Layout Editor screen
- Live preview/mockup editor screen
- DVR/Xtream/XMLTV source support
- Guide cache and memory-safe XMLTV behavior
- Live TV density settings
- VOD, trailers, Stremio, Pro Layout Editor, artwork settings
