package com.channelsdebrid.tv.net

import java.net.URLEncoder

/**
 * Backend/CDN routing for Debrid Channels.
 *
 * Primary backend is the active local test backend for cutout generation.
 * External URL is kept for future CDN routing after cutout service deployment.
 */
object BackendEndpoint {
    const val EXTERNAL_BASE_URL: String = "https://api.skylinejay187.it.com"
    const val LOCAL_BASE_URL: String = "http://192.168.100.55:8181"

    fun baseUrl(): String = LOCAL_BASE_URL

    fun route(path: String): String {
        val cleanPath = if (path.startsWith("/")) path else "/$path"
        return baseUrl().trimEnd('/') + cleanPath
    }

    fun imageProxyUrl(rawUrl: String?): String {
        val upgraded = upgradeArtworkUrl(rawUrl.orEmpty().trim())
        if (upgraded.isBlank()) return upgraded
        if (!upgraded.startsWith("http://", true) && !upgraded.startsWith("https://", true)) return upgraded
        if (upgraded.startsWith(baseUrl(), true)) return upgraded
        val encoded = URLEncoder.encode(upgraded, "UTF-8").replace("+", "%20")
        return route("/api/image?url=$encoded")
    }

    private fun upgradeArtworkUrl(url: String): String = url
        .replace("/t/p/w92/", "/t/p/original/")
        .replace("/t/p/w154/", "/t/p/original/")
        .replace("/t/p/w185/", "/t/p/original/")
        .replace("/t/p/w342/", "/t/p/original/")
        .replace("/t/p/w500/", "/t/p/original/")
        .replace("/t/p/w780/", "/t/p/original/")
        .replace("/poster/small/", "/poster/large/")
        .replace("/poster/medium/", "/poster/large/")
}
