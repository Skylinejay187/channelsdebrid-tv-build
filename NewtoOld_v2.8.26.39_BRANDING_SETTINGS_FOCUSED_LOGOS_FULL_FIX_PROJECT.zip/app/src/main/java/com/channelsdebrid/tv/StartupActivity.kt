package com.channelsdebrid.tv

import android.animation.ObjectAnimator
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class StartupActivity : AppCompatActivity() {
    private companion object { private const val TAG = "DebridChannels" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i(TAG, "STARTUP_BRANDING_FINAL: cinematic_logo=true orange_bar_only=true no_loading_text=true")
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.startup_splash_black)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = false
            alpha = 0f
        }
        val track = View(this).apply {
            background = rounded(0xFF242426.toInt(), 10)
            alpha = 0.92f
        }
        val bar = View(this).apply {
            background = rounded(0xFFFF8700.toInt(), 10)
            pivotX = 0f
            scaleX = 0.08f
            alpha = 1f
        }
        root.addView(logo, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        val barWidth = dp(440)
        val barTop = dp(438)
        root.addView(track, FrameLayout.LayoutParams(barWidth, dp(6), Gravity.CENTER).apply { topMargin = barTop })
        root.addView(bar, FrameLayout.LayoutParams(barWidth, dp(6), Gravity.CENTER).apply { topMargin = barTop })
        setContentView(root)
        ObjectAnimator.ofFloat(logo, "alpha", 0f, 1f).apply { duration = 360; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(logo, "scaleX", 0.985f, 1f).apply { duration = 850; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(logo, "scaleY", 0.985f, 1f).apply { duration = 850; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(bar, "scaleX", 0.08f, 1f).apply { duration = 1150; interpolator = AccelerateDecelerateInterpolator(); start() }
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }, 1250)
    }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
