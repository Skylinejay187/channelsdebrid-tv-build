package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v5.4 TRUE VISUAL PARITY NEW CORE";
    public static final String LOG_MARKER = "DC_V5_4_TRUE_VISUAL_PARITY_NEW_CORE";
    private BuildMarkers() {}
}
