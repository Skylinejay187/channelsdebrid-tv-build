package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.5.8 LIVE TV 4K DENSITY + LAYOUT FIX";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.5.8_live_tv_4k_density_layout_fix_clean_base";
}
