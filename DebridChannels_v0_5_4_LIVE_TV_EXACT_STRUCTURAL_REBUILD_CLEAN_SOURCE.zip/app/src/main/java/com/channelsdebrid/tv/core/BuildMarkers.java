package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.5.4 LIVE TV EXACT GOOGLE STRUCTURAL REBUILD";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.5.4_live_tv_exact_google_structural_rebuild_clean_base";
    private BuildMarkers() {}
}
