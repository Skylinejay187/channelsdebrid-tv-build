package com.channelsdebrid.tv.perf

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.util.Log

/**
 * Adaptive renderer profile for low-end Android TV devices.
 * This keeps the same layout/visual design, but lowers decode pressure,
 * preview churn, and huge Live TV list work on devices such as Xgimi.
 */
object DevicePerformanceProfile {
    data class Profile(
        val lowEndMode: Boolean,
        val memoryClassMb: Int,
        val lowRamDevice: Boolean,
        val renderWindowSize: Int,
        val renderWindowBuffer: Int,
        val firstScreenChannelLimit: Int,
        val guideHydrationChunkSize: Int,
        val logoLazyLoadDelayMs: Long,
        val gracenoteLazyDelayMs: Long,
        val heroBackdropWidth: Int,
        val heroBackdropHeight: Int,
        val maxConcurrentArtworkHint: Int
    )

    fun resolve(context: Context): Profile {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memoryClass = am?.memoryClass ?: 192
        val lowRam = am?.isLowRamDevice == true
        val model = (Build.MODEL ?: "").lowercase()
        val manufacturer = (Build.MANUFACTURER ?: "").lowercase()
        val xgimiLike = model.contains("xgimi") || manufacturer.contains("xgimi") || model.contains("galileo")
        val strongEnoughForPremium = !lowRam && memoryClass >= 384
        // v81: Auto mode should select Premium on faster boxes/TVs when memory profile is strong.
        // Keep known weak Xgimi/Galileo-style devices in Performance unless they report a clearly
        // stronger memory class. This only affects Auto; manual Performance/Premium still overrides.
        val lowEnd = !strongEnoughForPremium && (lowRam || memoryClass <= 256 || xgimiLike)
        val p = if (lowEnd) {
            Profile(
                lowEndMode = true,
                memoryClassMb = memoryClass,
                lowRamDevice = lowRam,
                renderWindowSize = 8,
                renderWindowBuffer = 3,
                firstScreenChannelLimit = 28,
                guideHydrationChunkSize = 72,
                logoLazyLoadDelayMs = 420L,
                gracenoteLazyDelayMs = 1250L,
                heroBackdropWidth = 1920,
                heroBackdropHeight = 1080,
                maxConcurrentArtworkHint = 3
            )
        } else {
            Profile(
                lowEndMode = false,
                memoryClassMb = memoryClass,
                lowRamDevice = lowRam,
                renderWindowSize = 14,
                renderWindowBuffer = 5,
                firstScreenChannelLimit = 48,
                guideHydrationChunkSize = 160,
                logoLazyLoadDelayMs = 220L,
                gracenoteLazyDelayMs = 900L,
                heroBackdropWidth = 3840,
                heroBackdropHeight = 2160,
                maxConcurrentArtworkHint = 8
            )
        }
        Log.i("DebridChannels", "LOW_END_ANDROID_TV_PERFORMANCE_MODE: enabled=${p.lowEndMode} memoryClass=${p.memoryClassMb} lowRam=${p.lowRamDevice} model=${Build.MANUFACTURER}/${Build.MODEL} renderWindow=${p.renderWindowSize} firstScreen=${p.firstScreenChannelLimit} hydrationChunk=${p.guideHydrationChunkSize} heroDecode=${p.heroBackdropWidth}x${p.heroBackdropHeight}")
        return p
    }
}
