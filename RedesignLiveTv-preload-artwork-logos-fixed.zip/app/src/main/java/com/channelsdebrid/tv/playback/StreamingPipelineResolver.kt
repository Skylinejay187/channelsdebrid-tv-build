package com.channelsdebrid.tv.playback

import com.channelsdebrid.tv.settings.DebridSettings
import com.channelsdebrid.tv.settings.PlaybackSettings
import com.channelsdebrid.tv.settings.StremioAddonSettings
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.Locale

class StreamingPipelineResolver {

    data class StreamCandidate(
        val addonName: String,
        val title: String,
        val url: String? = null,
        val magnet: String? = null,
        val infoHash: String? = null,
        val fileIdx: Int? = null,
        val sizeBytes: Long? = null,
        val qualityScore: Int = 0,
        val debug: String = ""
    )

    data class ResolvedStream(
        val url: String,
        val sourceLabel: String,
        val debugLabel: String
    )

    fun resolve(
        title: String,
        externalId: String,
        mediaType: String?,
        addons: List<StremioAddonSettings>,
        debrid: DebridSettings,
        playback: PlaybackSettings
    ): ResolvedStream? {
        val normalizedType = when (mediaType?.lowercase(Locale.US)) {
            "movie" -> "movie"
            "series", "show", "tv" -> "series"
            else -> "movie"
        }
        val candidates = addons
            .asSequence()
            .filter { it.enabled && it.manifestUrl.isNotBlank() }
            .flatMap { addon -> loadCandidates(addon, normalizedType, externalId).asSequence() }
            .filter { candidate ->
                val limitGb = playback.fileSizeLimitGb.coerceAtLeast(1)
                val sizeGb = candidate.sizeBytes?.toDouble()?.div(1024.0 * 1024.0 * 1024.0)
                sizeGb == null || sizeGb <= limitGb + 0.01
            }
            .sortedWith(compareByDescending<StreamCandidate> { it.qualityScore }.thenByDescending { it.sizeBytes ?: 0L })
            .toList()

        if (candidates.isEmpty()) return null

        val providers = buildProviderOrder(debrid)
        for (provider in providers) {
            for (candidate in candidates) {
                val resolved = when (provider) {
                    "realdebrid" -> resolveWithRealDebrid(candidate, debrid.realDebridApiKey)
                    "torbox" -> resolveWithTorBox(candidate, debrid.torBoxApiKey)
                    else -> resolveDirect(candidate)
                }
                if (resolved != null) return resolved
            }
            if (!debrid.autoFallback) break
        }

        return candidates.firstNotNullOfOrNull { resolveDirect(it) }
    }

    private fun buildProviderOrder(debrid: DebridSettings): List<String> {
        val order = mutableListOf<String>()
        val preferred = debrid.preferredProvider.trim().lowercase(Locale.US)
        fun add(provider: String, enabled: Boolean) {
            if (enabled && provider !in order) order += provider
        }
        when (preferred) {
            "torbox", "tor box" -> {
                add("torbox", debrid.torBoxEnabled && debrid.torBoxApiKey.isNotBlank())
                add("realdebrid", debrid.realDebridEnabled && debrid.realDebridApiKey.isNotBlank())
            }
            else -> {
                add("realdebrid", debrid.realDebridEnabled && debrid.realDebridApiKey.isNotBlank())
                add("torbox", debrid.torBoxEnabled && debrid.torBoxApiKey.isNotBlank())
            }
        }
        order += "direct"
        return order
    }

    private fun resolveDirect(candidate: StreamCandidate): ResolvedStream? {
        val direct = candidate.url?.takeIf { it.startsWith("http://") || it.startsWith("https://") } ?: return null
        return ResolvedStream(
            url = direct,
            sourceLabel = "${candidate.addonName} • Direct",
            debugLabel = candidate.debug.ifBlank { candidate.title }
        )
    }

    private fun resolveWithRealDebrid(candidate: StreamCandidate, apiKey: String): ResolvedStream? {
        if (apiKey.isBlank()) return null
        val direct = candidate.url?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
        if (direct != null && candidate.magnet == null && candidate.infoHash == null) {
            val unlocked = realDebridUnrestrict(apiKey, direct) ?: return null
            return ResolvedStream(unlocked, "${candidate.addonName} • Real-Debrid", candidate.debug)
        }
        val magnet = candidate.magnet ?: candidate.infoHash?.let { "magnet:?xt=urn:btih:$it" } ?: return null
        val torrentId = realDebridAddMagnet(apiKey, magnet) ?: return null
        val infoBeforeSelect = realDebridTorrentInfo(apiKey, torrentId)
        val filesToSelect = chooseRealDebridFiles(infoBeforeSelect, candidate.fileIdx)
        if (!realDebridSelectFiles(apiKey, torrentId, filesToSelect)) return null
        repeat(6) {
            Thread.sleep(if (it == 0) 1200L else 2000L)
            val info = realDebridTorrentInfo(apiKey, torrentId) ?: return@repeat
            val links = info.optJSONArray("links") ?: JSONArray()
            for (i in 0 until links.length()) {
                val link = links.optString(i).takeIf { it.startsWith("http") } ?: continue
                val unrestricted = realDebridUnrestrict(apiKey, link)
                if (!unrestricted.isNullOrBlank()) {
                    return ResolvedStream(unrestricted, "${candidate.addonName} • Real-Debrid", candidate.debug)
                }
            }
        }
        return null
    }

    private fun chooseRealDebridFiles(info: JSONObject?, desiredFileIdx: Int?): String {
        if (info == null) return "all"
        val files = info.optJSONArray("files") ?: return "all"
        if (files.length() == 0) return "all"
        if (desiredFileIdx != null) {
            val fileObj = files.optJSONObject(desiredFileIdx)
            val id = fileObj?.optInt("id") ?: 0
            if (id > 0) return id.toString()
        }
        val firstVideoId = (0 until files.length())
            .mapNotNull { idx -> files.optJSONObject(idx) }
            .firstOrNull { isLikelyVideoFile(it.optString("path")) }
            ?.optInt("id") ?: 0
        return if (firstVideoId > 0) firstVideoId.toString() else "all"
    }

    private fun resolveWithTorBox(candidate: StreamCandidate, apiKey: String): ResolvedStream? {
        if (apiKey.isBlank()) return null
        val direct = candidate.url?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
        if (direct != null && candidate.magnet == null && candidate.infoHash == null) {
            return ResolvedStream(direct, "${candidate.addonName} • Direct", candidate.debug)
        }
        val magnet = candidate.magnet ?: candidate.infoHash?.let { "magnet:?xt=urn:btih:$it" } ?: return null
        val torrentId = torBoxCreateTorrent(apiKey, magnet) ?: return null
        repeat(6) {
            Thread.sleep(if (it == 0) 1200L else 2000L)
            val info = torBoxTorrentInfo(apiKey, torrentId) ?: return@repeat
            val fileId = chooseTorBoxFileId(info, candidate.fileIdx)
            val requestUrl = torBoxRequestDl(apiKey, torrentId, fileId)
            if (!requestUrl.isNullOrBlank()) {
                return ResolvedStream(requestUrl, "${candidate.addonName} • TorBox", candidate.debug)
            }
        }
        return null
    }

    private fun chooseTorBoxFileId(info: JSONObject, desiredFileIdx: Int?): Int {
        val fileArrays = listOf(info.optJSONArray("files"), info.optJSONArray("download_files"), info.optJSONArray("file_list"))
        for (files in fileArrays) {
            if (files == null || files.length() == 0) continue
            if (desiredFileIdx != null) {
                val file = files.optJSONObject(desiredFileIdx)
                val fileId = file?.optInt("id") ?: file?.optInt("file_id") ?: 0
                if (fileId > 0) return fileId
            }
            val firstVideo = (0 until files.length())
                .mapNotNull { files.optJSONObject(it) }
                .firstOrNull {
                    isLikelyVideoFile(it.optString("short_name").ifBlank { it.optString("name") }.ifBlank { it.optString("path") })
                }
            val fileId = firstVideo?.optInt("id") ?: firstVideo?.optInt("file_id") ?: 0
            if (fileId > 0) return fileId
        }
        return 0
    }

    private fun loadCandidates(addon: StremioAddonSettings, mediaType: String, externalId: String): List<StreamCandidate> {
        val base = addon.manifestUrl.removeSuffix("/manifest.json").trimEnd('/')
        val streamUrl = "$base/stream/$mediaType/${URLEncoder.encode(externalId, "UTF-8")}.json".replace("+", "%20")
        val response = httpGetJson(streamUrl) ?: return emptyList()
        val streams = response.optJSONArray("streams") ?: return emptyList()
        val results = mutableListOf<StreamCandidate>()
        for (i in 0 until streams.length()) {
            val stream = streams.optJSONObject(i) ?: continue
            val title = buildCandidateTitle(stream)
            val debug = buildDebug(stream)
            val sizeBytes = parseSizeBytes(title + " " + stream.optString("description") + " " + stream.optString("name"))
            val qualityScore = scoreQuality(title + " " + stream.optString("description") + " " + stream.optString("name"))
            val behaviorHints = stream.optJSONObject("behaviorHints")
            val directUrl = stream.optString("url").takeIf { it.startsWith("http://") || it.startsWith("https://") }
            val magnet = stream.optString("externalUrl").takeIf { it.startsWith("magnet:") }
                ?: stream.optString("infoHash").takeIf { it.isNotBlank() }?.let { "magnet:?xt=urn:btih:$it" }
                ?: behaviorHints?.optString("magnet")?.takeIf { it.startsWith("magnet:") }
            val infoHash = stream.optString("infoHash").ifBlank {
                behaviorHints?.optString("infoHash").orEmpty()
            }.ifBlank { null }
            val fileIdx = when {
                stream.has("fileIdx") -> stream.optInt("fileIdx")
                behaviorHints?.has("fileIdx") == true -> behaviorHints.optInt("fileIdx")
                else -> -1
            }.takeIf { it >= 0 }
            if (directUrl == null && magnet == null && infoHash == null) continue
            results += StreamCandidate(
                addonName = addon.name.ifBlank { "Stremio" },
                title = title,
                url = directUrl,
                magnet = magnet,
                infoHash = infoHash,
                fileIdx = fileIdx,
                sizeBytes = sizeBytes,
                qualityScore = qualityScore,
                debug = debug
            )
        }
        return results
    }

    private fun buildCandidateTitle(stream: JSONObject): String {
        val parts = listOf(
            stream.optString("name").takeIf { it.isNotBlank() },
            stream.optString("title").takeIf { it.isNotBlank() },
            stream.optString("description").takeIf { it.isNotBlank() }
        )
        return parts.joinToString(" • ").ifBlank { "Addon stream" }
    }

    private fun buildDebug(stream: JSONObject): String {
        val behavior = stream.optJSONObject("behaviorHints")
        val infoHash = stream.optString("infoHash").ifBlank { behavior?.optString("infoHash").orEmpty() }
        val fileIdx = if (stream.has("fileIdx")) stream.optInt("fileIdx") else behavior?.optInt("fileIdx") ?: -1
        return buildString {
            append(stream.optString("title").ifBlank { stream.optString("name").ifBlank { "Stremio stream" } })
            if (infoHash.isNotBlank()) append("\nHash: ${infoHash.take(12)}…")
            if (fileIdx >= 0) append("\nFile index: $fileIdx")
        }
    }

    private fun scoreQuality(text: String): Int {
        val lower = text.lowercase(Locale.US)
        return when {
            listOf("2160", "4k", "uhd").any { it in lower } -> 400
            listOf("1080", "fhd").any { it in lower } -> 300
            listOf("720").any { it in lower } -> 200
            else -> 100
        } + when {
            "remux" in lower -> 40
            "bluray" in lower || "blu-ray" in lower -> 30
            "web-dl" in lower || "webrip" in lower -> 20
            else -> 0
        }
    }

    private fun parseSizeBytes(text: String): Long? {
        val regex = Regex("(\\d+(?:\\.\\d+)?)\\s*(gb|gib|mb|mib)", RegexOption.IGNORE_CASE)
        val match = regex.find(text) ?: return null
        val value = match.groupValues[1].toDoubleOrNull() ?: return null
        return when (match.groupValues[2].lowercase(Locale.US)) {
            "gb", "gib" -> (value * 1024 * 1024 * 1024).toLong()
            "mb", "mib" -> (value * 1024 * 1024).toLong()
            else -> null
        }
    }

    private fun isLikelyVideoFile(path: String): Boolean {
        val lower = path.lowercase(Locale.US)
        return listOf(".mkv", ".mp4", ".avi", ".ts", ".m2ts", ".mov", ".wmv").any { lower.endsWith(it) || it in lower }
    }

    private fun realDebridAddMagnet(apiKey: String, magnet: String): String? {
        val json = httpFormJson(
            url = "https://api.real-debrid.com/rest/1.0/torrents/addMagnet",
            method = "POST",
            headers = mapOf("Authorization" to "Bearer $apiKey"),
            form = linkedMapOf("magnet" to magnet)
        ) ?: return null
        return json.optString("id").ifBlank { null }
    }

    private fun realDebridSelectFiles(apiKey: String, torrentId: String, files: String): Boolean {
        val connection = openFormConnection(
            url = "https://api.real-debrid.com/rest/1.0/torrents/selectFiles/$torrentId",
            method = "POST",
            headers = mapOf("Authorization" to "Bearer $apiKey"),
            form = linkedMapOf("files" to files)
        )
        return try {
            val code = connection.responseCode
            code in 200..299 || code == 202
        } finally {
            connection.disconnect()
        }
    }

    private fun realDebridTorrentInfo(apiKey: String, torrentId: String): JSONObject? {
        return httpGetJson("https://api.real-debrid.com/rest/1.0/torrents/info/$torrentId", mapOf("Authorization" to "Bearer $apiKey"))
    }

    private fun realDebridUnrestrict(apiKey: String, link: String): String? {
        val json = httpFormJson(
            url = "https://api.real-debrid.com/rest/1.0/unrestrict/link",
            method = "POST",
            headers = mapOf("Authorization" to "Bearer $apiKey"),
            form = linkedMapOf("link" to link)
        ) ?: return null
        return json.optString("download").ifBlank { json.optString("link") }.ifBlank { null }
    }

    private fun torBoxCreateTorrent(apiKey: String, magnet: String): Int? {
        val json = httpFormJson(
            url = "https://api.torbox.app/v1/api/torrents/createtorrent",
            method = "POST",
            headers = mapOf("Authorization" to "Bearer $apiKey"),
            form = linkedMapOf("magnet" to magnet, "seed" to "1", "allow_zip" to "true", "as_queued" to "false")
        ) ?: return null
        val data = json.optJSONObject("data")
        return data?.optInt("torrent_id")?.takeIf { it > 0 }
            ?: data?.optInt("id")?.takeIf { it > 0 }
            ?: json.optInt("torrent_id").takeIf { it > 0 }
    }

    private fun torBoxTorrentInfo(apiKey: String, torrentId: Int): JSONObject? {
        val json = httpGetJson(
            "https://api.torbox.app/v1/api/torrents/mylist?id=$torrentId&bypass_cache=true",
            mapOf("Authorization" to "Bearer $apiKey")
        ) ?: return null
        val data = json.opt("data")
        return when (data) {
            is JSONObject -> data
            is JSONArray -> data.optJSONObject(0)
            else -> null
        }
    }

    private fun torBoxRequestDl(apiKey: String, torrentId: Int, fileId: Int): String? {
        val suffix = "token=${URLEncoder.encode(apiKey, "UTF-8")}&torrent_id=$torrentId&file_id=$fileId&zip_link=false&redirect=false"
        val json = httpGetJson("https://api.torbox.app/v1/api/torrents/requestdl?$suffix") ?: return null
        val data = json.opt("data")
        return when (data) {
            is String -> data
            is JSONObject -> data.optString("download").ifBlank { data.optString("url") }.ifBlank { data.optString("link") }.ifBlank { null }
            else -> null
        }
    }

    private fun httpGetJson(url: String, headers: Map<String, String> = emptyMap()): JSONObject? {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 12000
        connection.readTimeout = 20000
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("User-Agent", "ChannelsDebridTV/1.0")
        headers.forEach { (key, value) -> connection.setRequestProperty(key, value) }
        return try {
            val body = (if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (connection.responseCode !in 200..299 || body.isBlank()) return null
            JSONObject(body)
        } catch (_: Exception) {
            null
        } finally {
            connection.disconnect()
        }
    }

    private fun httpFormJson(url: String, method: String, headers: Map<String, String>, form: LinkedHashMap<String, String>): JSONObject? {
        val connection = openFormConnection(url, method, headers, form)
        return try {
            val body = (if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (connection.responseCode !in 200..299 || body.isBlank()) return null
            JSONObject(body)
        } catch (_: Exception) {
            null
        } finally {
            connection.disconnect()
        }
    }

    private fun openFormConnection(url: String, method: String, headers: Map<String, String>, form: LinkedHashMap<String, String>): HttpURLConnection {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = method
        connection.doOutput = true
        connection.connectTimeout = 12000
        connection.readTimeout = 30000
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        connection.setRequestProperty("User-Agent", "ChannelsDebridTV/1.0")
        headers.forEach { (key, value) -> connection.setRequestProperty(key, value) }
        val body = form.entries.joinToString("&") { (k, v) -> "${URLEncoder.encode(k, "UTF-8") }=${URLEncoder.encode(v, "UTF-8")}" }
        OutputStreamWriter(connection.outputStream).use { it.write(body) }
        return connection
    }
}
