import express from "express"
import { pipeline } from "node:stream/promises"
import { homeRouter } from "./routes/home"
import { adminRowsRouter } from "./routes/admin-rows"
import { CatalogManager } from "./catalog/catalog-manager"
import { InternalCatalogSource } from "./catalog/sources/internal-catalog-source"
import { StremioCatalogSource } from "./catalog/sources/stremio-catalog-source"
import { createTmdbClient } from "./catalog/providers/tmdb-client"
import { createAddonRegistry } from "./stremio/addon-registry"

export async function createApp() {
  const app = express()
  app.use(express.json())

  const tmdb = createTmdbClient(process.env.TMDB_API_KEY ?? "")
  const addonRegistry = createAddonRegistry()

  const catalogManager = new CatalogManager([
    new InternalCatalogSource(tmdb),
    new StremioCatalogSource(addonRegistry),
  ])

  app.use(homeRouter(catalogManager))
  app.use(adminRowsRouter())

  app.get(["/api/image/fetch", "/api/image", "/image", "/proxy/image"], async (req, res) => {
    const rawUrl = typeof req.query.url === "string" ? req.query.url.trim() : ""
    if (!rawUrl) {
      res.status(400).json({ ok: false, error: "Missing url" })
      return
    }

    try {
      const upstream = await fetch(rawUrl, {
        headers: {
          "user-agent": "ChannelsDebridImageProxy/1.0",
          accept: "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
        },
      })
      if (!upstream.ok || !upstream.body) {
        res.status(upstream.status || 502).json({ ok: false, error: `Upstream image failed: ${upstream.status}` })
        return
      }

      res.setHeader("Content-Type", upstream.headers.get("content-type") ?? "image/jpeg")
      res.setHeader("Cache-Control", "public, max-age=86400, stale-while-revalidate=604800")
      const etag = upstream.headers.get("etag")
      if (etag) res.setHeader("ETag", etag)
      const len = upstream.headers.get("content-length")
      if (len) res.setHeader("Content-Length", len)
      await pipeline(upstream.body as any, res)
    } catch (error) {
      res.status(502).json({ ok: false, error: error instanceof Error ? error.message : "Image proxy failed" })
    }
  })

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, service: "channels-debrid-foundation" })
  })

  return app
}
