package com.channelsdebrid.tv

import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.KeyEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.channelsdebrid.tv.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var grid: List<List<View>>
    private var rowIndex = 0
    private var colIndex = 3

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        grid = listOf(
            listOf(binding.menuButton, binding.homeButton, binding.navResume, binding.navSmartHome, binding.navLiveTv, binding.navMovies),
            listOf(binding.ctaContinue),
            listOf(binding.cardContinue1, binding.cardContinue2, binding.cardContinue3),
            listOf(binding.cardSpot1, binding.cardSpot2, binding.cardSpot3, binding.cardSpot4, binding.settingsButton)
        )

        val clickables = grid.flatten()
        clickables.forEach { view ->
            view.isFocusable = true
            view.isFocusableInTouchMode = true
            view.setOnClickListener {
                Toast.makeText(this, "Native action placeholder", Toast.LENGTH_SHORT).show()
            }
        }

        binding.root.post { focusCurrent() }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_RIGHT -> { moveHorizontal(1); return true }
            KeyEvent.KEYCODE_DPAD_LEFT -> { moveHorizontal(-1); return true }
            KeyEvent.KEYCODE_DPAD_DOWN -> { moveVertical(1); return true }
            KeyEvent.KEYCODE_DPAD_UP -> { moveVertical(-1); return true }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                currentView().performClick(); return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun moveHorizontal(delta: Int) {
        val row = grid[rowIndex]
        colIndex = (colIndex + delta).coerceIn(0, row.lastIndex)
        focusCurrent()
    }

    private fun moveVertical(delta: Int) {
        rowIndex = (rowIndex + delta).coerceIn(0, grid.lastIndex)
        colIndex = colIndex.coerceIn(0, grid[rowIndex].lastIndex)
        focusCurrent()
    }

    private fun currentView(): View = grid[rowIndex][colIndex]

    private fun focusCurrent() {
        val target = currentView()
        target.requestFocus()
        val loc = IntArray(2)
        target.getLocationOnScreen(loc)
        val rootLoc = IntArray(2)
        binding.focusOverlay.getLocationOnScreen(rootLoc)

        val params = binding.focusRing.layoutParams as FrameLayout.LayoutParams
        params.width = target.width
        params.height = target.height
        params.leftMargin = loc[0] - rootLoc[0]
        params.topMargin = loc[1] - rootLoc[1]
        binding.focusRing.layoutParams = params
        binding.focusRing.background = focusDrawable()
    }

    private fun focusDrawable(): GradientDrawable {
        val stroke = dp(2)
        val radius = dp(20).toFloat()
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(0x11FFFFFF)
            setStroke(stroke, 0xFF78B8FF.toInt())
            cornerRadius = radius
        }
    }

    private fun dp(value: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP,
        value.toFloat(),
        resources.displayMetrics
    ).toInt()
}
