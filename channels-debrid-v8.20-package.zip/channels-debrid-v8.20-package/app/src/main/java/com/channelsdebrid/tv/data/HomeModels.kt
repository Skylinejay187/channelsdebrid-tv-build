package com.channelsdebrid.tv.data

data class HomeResponseDto(
    val hero: HeroDto?,
    val rows: List<HomeRowDto>
)

data class HeroDto(
    val id: String,
    val type: String,
    val title: String,
    val subtitle: String?,
    val description: String?,
    val backdrop: String?,
    val logo: String?,
    val actions: List<HeroActionDto>
)

data class HeroActionDto(
    val id: String,
    val label: String
)

data class HomeRowDto(
    val id: String,
    val title: String,
    val type: String,
    val style: String,
    val source: String,
    val catalogId: String,
    val provider: String?,
    val addonId: String?,
    val items: List<CatalogItemDto>
)

data class CatalogItemDto(
    val id: String,
    val type: String,
    val title: String,
    val originalTitle: String?,
    val year: Int?,
    val rating: Double?,
    val runtime: Int?,
    val genres: List<String>?,
    val description: String?,
    val poster: String?,
    val backdrop: String?,
    val logo: String?,
    val provider: ProviderDto?,
    val badges: List<BadgeDto>?,
    val playback: PlaybackDto?,
    val meta: MetaIdsDto?
)

data class ProviderDto(val id: String, val name: String, val logo: String?)
data class BadgeDto(val type: String, val label: String)
data class PlaybackDto(val available: Boolean, val sourceType: String?, val sourceId: String?, val deepLink: String?)
data class MetaIdsDto(val tmdbId: Int?, val imdbId: String?, val traktId: Int?)
