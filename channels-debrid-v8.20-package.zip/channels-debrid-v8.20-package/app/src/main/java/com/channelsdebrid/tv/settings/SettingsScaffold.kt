package com.channelsdebrid.tv.settings

data class TmdbSettings(
    val apiKey: String = ""
)

data class StremioAddonSettings(
    val manifestUrl: String = "",
    val enabled: Boolean = true
)

data class ChannelsDvrSettings(
    val autoDiscover: Boolean = true,
    val serverUrl: String = ""
)

data class XtreamSettings(
    val serverUrl: String = "",
    val username: String = "",
    val password: String = ""
)

data class StorageTargetSettings(
    val type: String,
    val pathOrHost: String,
    val allowTimeshift: Boolean,
    val allowVodCache: Boolean
)

data class TrailerSettings(
    val autoPopup: Boolean = true,
    val popupDelayMs: Long = 1200,
    val preferFullscreen: Boolean = false
)

data class PlaybackSettings(
    val frameRateMatching: Boolean = true,
    val preferExternalCache: Boolean = true
)
