package com.channelsdebrid.tv

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.channelsdebrid.tv.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val navViews = mutableListOf<View>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.trendingRow.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.recentRow.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)

        binding.trendingRow.adapter = MediaCardAdapter(
            listOf(
                MediaCard("The Last Samurai", "More shows like SHŌGUN", R.drawable.card_poster_a),
                MediaCard("Marco Polo", "Period epics & war", R.drawable.card_poster_b),
                MediaCard("Shōgun Extra", "Samurai drama", R.drawable.card_poster_c),
                MediaCard("Troy", "Ancient warfare", R.drawable.card_poster_d)
            )
        )

        binding.recentRow.adapter = MediaCardAdapter(
            listOf(
                MediaCard("Civil War", "Recently added", R.drawable.card_poster_d),
                MediaCard("Fallout", "Trending now", R.drawable.card_poster_c),
                MediaCard("Challengers", "New this week", R.drawable.card_poster_b),
                MediaCard("X-Men '97", "Fresh episodes", R.drawable.card_poster_a),
                MediaCard("Hit Man", "New arrival", R.drawable.card_poster_c),
                MediaCard("Avatar", "Popular titles", R.drawable.card_poster_d)
            )
        )

        navViews += listOf(
            binding.navResume,
            binding.navSmart,
            binding.navLive,
            binding.navMovies
        )
        setupTopNav()
        setupButtons()
        binding.continueButton.requestFocus()
    }

    private fun setupButtons() {
        val focusableButtons = listOf<View>(
            binding.menuButton,
            binding.homeButton,
            binding.continueButton,
            binding.settingsButton
        )
        focusableButtons.forEach { view ->
            attachFocusScale(view)
            view.setOnClickListener {
                Toast.makeText(this, "Demo action: ${(it as? TextView)?.text ?: it.contentDescription ?: "button"}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupTopNav() {
        navViews.forEach { view ->
            attachFocusScale(view, 1.05f)
            view.setOnClickListener {
                navViews.forEach { v ->
                    v.isSelected = false
                    if (v is TextView) v.setTextColor(getColor(R.color.text_primary))
                }
                it.isSelected = true
                if (it is TextView) {
                    it.setTextColor(Color.parseColor("#111318"))
                    binding.heroTitle.text = when (it.id) {
                        binding.navResume.id -> "SHŌGUN"
                        binding.navSmart.id -> "SHŌGUN"
                        binding.navLive.id -> "LIVE TV"
                        else -> "MOVIES"
                    }
                    binding.heroDescription.text = when (it.id) {
                        binding.navLive.id -> "Live TV shell placeholder for the native rebuild. Backend wiring comes in step two."
                        binding.navMovies.id -> "Movie discovery layout placeholder built to match the same cinematic ARVIO-style composition."
                        else -> "A premium lean-back presentation for your media center, with live TV, trending shows, smart recommendations, trailer popups, and instant playback."
                    }
                }
            }
        }
    }

    private fun attachFocusScale(view: View, scale: Float = 1.07f) {
        view.isFocusable = true
        view.isFocusableInTouchMode = true
        ViewCompat.setElevation(view, 0f)
        view.setOnFocusChangeListener { v, hasFocus ->
            v.animate().scaleX(if (hasFocus) scale else 1f).scaleY(if (hasFocus) scale else 1f).setDuration(120).start()
            v.alpha = if (hasFocus) 1f else 0.98f
        }
    }
}
