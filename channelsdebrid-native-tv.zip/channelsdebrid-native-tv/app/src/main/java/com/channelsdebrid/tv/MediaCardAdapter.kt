package com.channelsdebrid.tv

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class MediaCardAdapter(
    private val items: List<MediaCard>
) : RecyclerView.Adapter<MediaCardAdapter.CardViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_media_card, parent, false)
        return CardViewHolder(view)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: CardViewHolder, position: Int) {
        val item = items[position]
        holder.title.text = item.title
        holder.meta.text = item.meta
        holder.posterFrame.background = ContextCompat.getDrawable(holder.itemView.context, item.posterRes)
        holder.posterFrame.setOnClickListener {
            Toast.makeText(holder.itemView.context, "Demo item: ${item.title}", Toast.LENGTH_SHORT).show()
        }
        holder.posterFrame.setOnFocusChangeListener { v, hasFocus ->
            v.animate().scaleX(if (hasFocus) 1.08f else 1f).scaleY(if (hasFocus) 1.08f else 1f).setDuration(120).start()
            v.alpha = if (hasFocus) 1f else 0.97f
        }
    }

    class CardViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val posterFrame: FrameLayout = view.findViewById(R.id.posterFrame)
        val title: TextView = view.findViewById(R.id.posterTitle)
        val meta: TextView = view.findViewById(R.id.posterMeta)
    }
}
