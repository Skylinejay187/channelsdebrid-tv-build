package com.channelsdebrid.tv

data class MediaCard(
    val title: String,
    val meta: String,
    val posterRes: Int
)
