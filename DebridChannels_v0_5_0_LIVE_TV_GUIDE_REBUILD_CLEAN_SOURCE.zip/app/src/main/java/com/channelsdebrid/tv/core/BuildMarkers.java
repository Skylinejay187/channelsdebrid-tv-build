package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.5.0 LIVE TV GUIDE REBUILD";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.5.0_live_tv_google_guide_clean_base";
    private BuildMarkers() {}
}
