package com.channelsdebrid.tv;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import android.widget.*;
import android.net.Uri;
import android.view.Display;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.util.Xml;
import org.xmlpull.v1.XmlPullParser;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

import com.channelsdebrid.tv.core.*;
import com.channelsdebrid.tv.player.*;
import com.channelsdebrid.tv.livetv.*;
import com.channelsdebrid.tv.cache.*;
import com.channelsdebrid.tv.layout.*;
import com.channelsdebrid.tv.backend.*;
import com.channelsdebrid.tv.stremio.*;
import androidx.media3.common.MediaItem;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.Tracks;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.Player;
import androidx.media3.common.PlaybackException;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.hls.HlsMediaSource;
import androidx.media3.exoplayer.dash.DashMediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.ui.PlayerView;
import androidx.media3.ui.AspectRatioFrameLayout;

public class MainActivity extends Activity {
    FrameLayout root;
    NavigationController nav;
    PlayerManager player;
    LiveTvStateMachine live;
    GuideCacheOwner guideCache;
    TimeshiftEngine timeshift;
    UiStateStore ui;
    BackendConfig backend;
    StremioAddonRegistry stremio;
    LinearLayout heroMenu;
    final ArrayList<View> menuItems = new ArrayList<>();
    final ArrayList<HomeRow> homeRows = new ArrayList<>();
    final ArrayList<LinearLayout> rowLists = new ArrayList<>();
    final ArrayList<HorizontalScrollView> rowScrolls = new ArrayList<>();
    final ArrayList<TextView> rowTitleViews = new ArrayList<>();
    final ArrayList<Movie> movies = new ArrayList<>();
    final ArrayList<Channel> channels = new ArrayList<>();
    ImageView heroBackdropImage, heroLogoImage, heroBannerImage;
    View heroTextPanel;
    ScrollView editorScroll;
    TextView heroTitle, heroDesc, heroMeta;
    Movie currentHeroMovie;
    LinearLayout heroRatingRow;
    boolean suppressRowAutoFocus = false;
    int activeRowIndex = 0;
    final Handler heroHandler = new Handler(Looper.getMainLooper());
    Runnable pendingHeroRunnable;
    int heroUpdateSeq = 0;
    String currentHeroBackdropUrl = "";
    String currentHeroLogoUrl = "";
    final Map<String, Bitmap> imageCache = Collections.synchronizedMap(new LinkedHashMap<String, Bitmap>(64, .75f, true){protected boolean removeEldestEntry(Map.Entry<String,Bitmap> e){return size()>80;}});
    final ExecutorService imageExecutor = Executors.newFixedThreadPool(3);
    final Set<String> failedArtworkUrls = Collections.synchronizedSet(new HashSet<String>());
    final Map<String, String[]> ratingCache = Collections.synchronizedMap(new HashMap<String, String[]>());
    ExoPlayer exoPlayer;
    PlayerView activePlayerView;
    int activeZoomMode = 0;
    SelectedMedia selectedMedia;
    FrameLayout activePlayerOverlay;
    TextView activePlayerPlayPause;
    TextView activePlayerTime;
    ProgressBar activePlayerProgress;
    Movie activePlayerMovie;
    final Handler playerOverlayHandler = new Handler(Looper.getMainLooper());
    final Handler playerProgressHandler = new Handler(Looper.getMainLooper());
    Runnable playerOverlayHideRunnable;
    Runnable playerProgressRunnable;
    FrameLayout activePlayerOptionPanel;
    Runnable heroRotationRunnable;
    int heroRotationIndex = 0;

    static class Movie {
        String id = "", type = "movie", title = "Untitled", meta = "", url = "";
        String poster = "", background = "", logo = "", banner = "", overview = "", year = "", tag = "FEATURED", imdbRating = "", tmdbRating = "";
        Movie(String title, String meta, String url) { this.title = title; this.meta = meta; this.url = url; }
    }
    static class SelectedMedia { Movie movie; ArrayList<StreamLink> streams = new ArrayList<>(); SelectedMedia(Movie m){movie=m;} }
    static class StreamLink {
        String name="Stream", title="", description="", quality="", size="", source="Stremio", url="";
        String magnet="", infoHash=""; int fileIdx=-1; long sizeBytes=0; int qualityScore=0;
        boolean external=false, dolbyVision=false, hdr10Plus=false, hdr=false;
        boolean playable(){return url!=null && (url.startsWith("http://")||url.startsWith("https://"));}
        boolean hasResolverPayload(){return (magnet!=null&&!magnet.isEmpty()) || (infoHash!=null&&!infoHash.isEmpty()) || (url!=null && (url.startsWith("magnet:")||url.startsWith("torrent:")||url.endsWith(".torrent")));}
        boolean needsResolver(){ if(url==null)return true; String u=url.toLowerCase(Locale.US); return u.startsWith("magnet:")||u.startsWith("torrent:")||u.endsWith(".torrent")||external; }
    }
    static class HomeRow { String id = "", title = "Catalog"; ArrayList<Movie> items = new ArrayList<>(); HomeRow(String title){this.title=title;} }
    static class Channel { String name, group, url, logo; String tvgId="", number="", source="", streamId=""; String epgNow="", epgNext="", epgLater="", epgDescription="", epgTime=""; Channel(String n,String g,String u,String l){name=n;group=g;url=u;logo=l;} }
    static class Episode {
        String id="", title="Episode", overview="", thumbnail="", airDate="";
        int season=1, episode=1, runtime=0;
        Episode(int s,int e,String t){season=s;episode=e;title=t==null||t.isEmpty()?"Episode "+e:t;}
        String label(){return "S"+season+":E"+episode+"  "+title;}
    }
    static class TrailerSettings { boolean autoPopup=true, muted=false, disabled=false; int delaySeconds=2; }
    final Handler trailerHandler = new Handler(Looper.getMainLooper());
    Runnable pendingTrailerRunnable;
    FrameLayout trailerOverlay;
    VideoView trailerVideo;
    ExoPlayer trailerPlayer;
    PlayerView trailerPlayerView;
    boolean trailerMuted = false;
    ArrayList<String> trailerFallbackUrls = new ArrayList<>();
    int trailerFallbackIndex = 0;
    boolean trailerAudioFallbackInProgress = false;
    boolean livePlayerActive = false;
    // v0.6.8 mixed-density rule: Hero/Home uses 1080p-style UI, every other app area stays 4K when enabled.
    boolean hero1080DensityActive = false;
    Channel lastLiveChannel = null;
    ExoPlayer livePreviewPlayer;
    PlayerView livePreviewPlayerView;
    final Handler livePreviewHandler = new Handler(Looper.getMainLooper());
    Runnable pendingLivePreviewRunnable;
    String currentLivePreviewUrl = "";

    class CardFrame extends FrameLayout {
        final Path clipPath = new Path();
        final RectF rect = new RectF();
        float radius;
        CardFrame(Context context, float r) { super(context); radius = r; setWillNotDraw(false); }
         protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            clipPath.reset(); rect.set(0, 0, w, h);
            clipPath.addRoundRect(rect, radius, radius, Path.Direction.CW); clipPath.close();
        }
         public void draw(Canvas canvas) {
            int save = canvas.save();
            canvas.clipPath(clipPath);
            super.draw(canvas);
            canvas.restoreToCount(save);
        }
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            if (livePlayerActive) {
                AppLogger.mark("LIVE_TV_V081: BACK live player -> guide release_player");
                livePlayerActive = false;
                releaseMainPlayback("back_live_to_guide");
                showLiveTv();
                return true;
            }
            if (nav != null && nav.current() == NavigationController.Screen.LIVE_TV) {
                AppLogger.mark("LIVE_TV_V081: BACK guide -> HOME hero section");
                showHome();
                return true;
            }
        }
        if (activePlayerOverlay != null && event.getAction() == KeyEvent.ACTION_DOWN) {
            if (handlePlayerKey(event.getKeyCode())) return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        nav = new NavigationController();
        player = new PlayerManager(this);
        live = new LiveTvStateMachine();
        guideCache = new GuideCacheOwner(this);
        timeshift = new TimeshiftEngine(this);
        ui = new UiStateStore(this);
        backend = new BackendConfig(this);
        stremio = new StremioAddonRegistry(this);
        root = new FrameLayout(this);
        setContentView(root);
        AppLogger.mark("DC_UI_ROOT_V075: programmatic_single_root_no_xml_no_placeholder target=visible_home_only");
        AppLogger.mark("BOOT " + BuildMarkers.LOG_MARKER + " backend=" + backend.baseUrl());
        try { DisplayMetrics dm=getResources().getDisplayMetrics(); AppLogger.mark("DC_UI_4K: width="+dm.widthPixels+" height="+dm.heightPixels+" density="+dm.density+" enabled="+global4kMode()+" mixedDensity=heroSelectable_default4k_rest4k singleRoot=true visual_pipeline_v077=true"); } catch(Exception ignored) {}
        showHome();
        loadBackendHomeRows();
        try { loadLiveTvSources(); } catch(Exception ignored) {}
    }


    @Override protected void onStop() {
        super.onStop();
        try { releaseLivePreview(); } catch(Exception ignored) {}
        if(livePlayerActive) {
            livePlayerActive=false;
            releaseMainPlayback("activity_stop_live_release");
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        try { if(exoPlayer!=null){exoPlayer.release();exoPlayer=null;} } catch(Exception ignored) {}
        try { imageExecutor.shutdownNow(); } catch(Exception ignored) {}
    }

    void seedFallback() {
        // v0.7.5: legacy/placeholder home content is intentionally disabled.
        // The app starts from one clean root and only renders hero content after real backend rows load.
        movies.clear(); homeRows.clear(); channels.clear();
    }

    int rawDp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    boolean global4kMode(){
        try{
            DisplayMetrics m=getResources().getDisplayMetrics();
            boolean largePanel=m.widthPixels>=3000||m.heightPixels>=1600||m.density>=1.55f;
            return ui!=null && ui.ui4k() && largePanel;
        }catch(Exception e){return false;}
    }
    boolean scoped4kMode(){return global4kMode() && !hero1080DensityActive;}
    float global4kDpFactor(){return scoped4kMode()?0.72f:1f;}
    float global4kSpFactor(){return scoped4kMode()?0.90f:1f;}
    int dp(int v){return rawDp(Math.max(1,Math.round(v*global4kDpFactor())));}
    int sp4k(int v){return Math.max(10,Math.round(v*global4kSpFactor()));}

    // v0.8.3: Live TV density is now a real layout mode, not a late scale hack.
    // 0 = 1080p Auto Fit (default): built from a 1920x1080 safe-area layout and fit to the actual panel.
    // 1 = 4K compact: denser layout for larger panels.
    int liveTvDensityMode(){ return ui==null ? 0 : Math.max(0, Math.min(1, ui.value("liveTvDensityMode",0))); }
    String liveTvDensityName(int v){ String[] n={"1080p Auto Fit","4K compact"}; return n[Math.max(0,Math.min(v,n.length-1))]; }
    boolean live4kDensityMode(){ return liveTvDensityMode()==1; }
    float liveTvFitFactor(){
        try{
            DisplayMetrics m=getResources().getDisplayMetrics();
            float density=m.density<=0?1f:m.density;
            float wDp=(m.widthPixels<=0?1920f:m.widthPixels)/density;
            float hDp=(m.heightPixels<=0?1080f:m.heightPixels)/density;
            if(live4kDensityMode()) return global4kMode()?0.56f:0.68f;
            float fit=Math.min((wDp-18f)/1920f,(hDp-12f)/1080f);
            return Math.max(0.68f, Math.min(0.90f, fit*0.90f));
        }catch(Exception e){ return live4kDensityMode()?0.62f:0.84f; }
    }
    int ldp(int v){return rawDp(Math.max(1,Math.round(v*liveTvFitFactor())));}
    int lsp(int v){
        float f=liveTvFitFactor();
        return Math.max(10,Math.round(v*(live4kDensityMode()?0.82f:Math.max(0.80f,Math.min(0.94f,f+.04f)))));
    }
    TextView ltv(String s,int sz,int style){return tv(s,lsp(sz),style);}
    TextView liveBtn(String s){TextView b=btn(s);b.setTextSize(lsp(16));return b;}
    int livePreviewWidthDp(){
        try{
            DisplayMetrics m=getResources().getDisplayMetrics();
            float density=m.density<=0?1f:m.density;
            int screenDp=Math.max(960, Math.round((m.widthPixels<=0?1920:m.widthPixels)/density));
            int safe=Math.max(280, screenDp-96);
            int target=live4kDensityMode()?440:320;
            return Math.max(live4kDensityMode()?340:280, Math.min(target, safe/3));
        }catch(Exception e){return live4kDensityMode()?420:315;}
    }
    int livePreviewHeightDp(){ return Math.max(158, Math.round(livePreviewWidthDp()*9f/16f)); }
    void clear(){
        try{ if(nav==null || nav.current()!=NavigationController.Screen.LIVE_TV) releaseLivePreview(); }catch(Exception ignored){}
        hero1080DensityActive=false;
        if(playerOverlayHideRunnable!=null)playerOverlayHandler.removeCallbacks(playerOverlayHideRunnable);
        if(playerProgressRunnable!=null)playerProgressHandler.removeCallbacks(playerProgressRunnable);
        activePlayerOverlay=null;activePlayerPlayPause=null;activePlayerProgress=null;activePlayerTime=null;activePlayerView=null;
        if(heroRotationRunnable!=null)heroHandler.removeCallbacks(heroRotationRunnable);
        if(pendingTrailerRunnable!=null)trailerHandler.removeCallbacks(pendingTrailerRunnable);
        dismissTrailerOverlay();
        releaseLivePreview();
        if(!livePlayerActive) releaseMainPlayback("clear_non_player_screen");
        root.removeAllViews();menuItems.clear();rowLists.clear();rowScrolls.clear();rowTitleViews.clear();
        heroBackdropImage=null;heroLogoImage=null;heroBannerImage=null;heroTextPanel=null;heroTitle=null;heroDesc=null;heroMeta=null;heroRatingRow=null;
    }
    GradientDrawable bg(int c,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    GradientDrawable stroke(int c,int s){GradientDrawable g=bg(c,26);g.setStroke(dp(1),s);return g;}
    TextView tv(String x,int sp,int style){TextView t=new TextView(this);t.setText(x);t.setTextColor(Color.WHITE);t.setTextSize(sp4k(sp));t.setTypeface(Typeface.DEFAULT,style);t.setGravity(Gravity.CENTER);return t;}
    Typeface editorTypeface(int index,int style){String[] families={"sans-serif","sans-serif-medium","sans-serif-condensed","sans-serif-light","serif","monospace","casual","cursive","sans-serif-smallcaps","sans-serif-black","sans-serif-thin","sans-serif"};int safe=Math.max(0,Math.min(index,families.length-1));return Typeface.create(families[safe],style);}
    String fontName(int index){String[] names={"Default","Medium","Condensed","Light","Serif","Monospace","Casual","Cursive","Small caps","Black","Thin","Default alt"};return names[Math.max(0,Math.min(index,names.length-1))];}
    String onOff(int v){return v==1?"On":"Off";}
    String placementName(int v){return v==0?"Hidden":v==1?"Inline":v==2?"Left":"Right";}
    String menuCompositionName(int v){return v==0?"Classic":v==1?"Pill":v==2?"Glass":"Pill";}
    String effectProfileName(int v){String[] n={"Custom","Subtle","Cinematic glow","3D pop","Premium glass"};return n[Math.max(0,Math.min(v,n.length-1))];}
    String extraArtworkName(int v){String[] n={"Hidden","Auto best","Banner / landscape","Clearlogo","Poster","Backdrop","Disc / DVD box","3D character art","3D poster","Key art","Fanart alt","Logo stack","Box art","Hero backdrop crop","Minimal none"};return n[Math.max(0,Math.min(v,n.length-1))];}
    String extraArtworkPositionName(int v){String[] n={"Current / manual","Top left","Top right"};return n[Math.max(0,Math.min(v,n.length-1))];}
    String heroTextModeName(int v){String[] n={"Logo only","Text title","Logo + text fallback","Minimal compact","Cinematic large","Bottom-left poster style"};return n[Math.max(0,Math.min(v,n.length-1))];}
    String heroTextStyleName(int v){String[] n={"Clean white","Neon glow","Shadow heavy","Gold cinema","Condensed bold","Soft glass","Minimal small","Poster stack","Wide cinematic","Glass capsule","Ultra compact"};return n[Math.max(0,Math.min(v,n.length-1))];}
    String heroTextScaleName(int v){String[] n={"Tiny","Small","Default","Large","XL"};return n[Math.max(0,Math.min(v,n.length-1))];}
    String heroTextThemeName(int v){String[] n={"Classic left","Compact logo-first","Wide cinematic","Bottom-left poster","Glass card","Minimal metadata"};return n[Math.max(0,Math.min(v,n.length-1))];}
    String heroRotationName(int v){String[] n={"Off","Current row","All rows"};return n[Math.max(0,Math.min(v,n.length-1))];}
    String heroDensityName(int v){String[] n={"1080p style","4K style"};return n[Math.max(0,Math.min(v,n.length-1))];}
    String statusThemeName(int v){String[] n={"Glass pill","Text only","Dark pill","Light pill"};return n[Math.max(0,Math.min(v,n.length-1))];}
    int focusRingColor(int index,int alpha){int i=Math.max(0,Math.min(5,index));int[] c={Color.WHITE,Color.rgb(73,160,255),Color.rgb(0,220,200),Color.rgb(255,210,64),Color.rgb(255,78,120),Color.rgb(180,110,255)};return Color.argb(alpha,Color.red(c[i]),Color.green(c[i]),Color.blue(c[i]));}
    void applyFont(TextView t,int index,int style){if(t!=null)t.setTypeface(editorTypeface(index,style));}

    void backdrop(){
        // v0.6.3: start from a clean black base so no previous/stale hero frame can ghost under the first real artwork.
        root.setBackgroundColor(Color.BLACK);
        heroBackdropImage = new ImageView(this);
        heroBackdropImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        heroBackdropImage.setBackgroundColor(Color.BLACK);
        heroBackdropImage.setImageDrawable(null);
        heroBackdropImage.setAlpha(0f);
        root.addView(heroBackdropImage,new FrameLayout.LayoutParams(-1,-1));
        View tone = new View(this); tone.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.argb(25,20,24,34),Color.argb(110,0,0,0),Color.argb(170,0,0,0)})); root.addView(tone,new FrameLayout.LayoutParams(-1,-1));
        View side = new View(this); side.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.argb(245,0,0,0),Color.argb(160,0,0,0),Color.argb(35,0,0,0)})); root.addView(side,new FrameLayout.LayoutParams(-1,-1));
        View bottom = new View(this); bottom.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,new int[]{Color.argb(250,0,0,0),Color.TRANSPARENT})); root.addView(bottom,new FrameLayout.LayoutParams(-1,dp(400),Gravity.BOTTOM));
    }

    TextView btn(String x){TextView v=tv(x,16,Typeface.BOLD);applyFont(v,ui==null?0:ui.topMenuFontIndex(),Typeface.BOLD);v.setFocusable(true);v.setPadding(dp(18),0,dp(18),0);v.setBackground(bg(Color.argb(0,0,0,0),18));v.setOnFocusChangeListener((a,h)->focus((TextView)a,h));return v;}
    void focus(TextView a,boolean h){a.animate().scaleX(h?1.08f:1f).scaleY(h?1.08f:1f).setDuration(130).start();a.setBackground(h?bg(Color.argb(165,21,57,88),0):bg(Color.argb(0,0,0,0),0));}

    void addMenu(){
        heroMenu=new LinearLayout(this);heroMenu.setGravity(Gravity.CENTER);heroMenu.setPadding(dp(8),0,dp(8),0); if(ui.menuCompositionMode()>0)heroMenu.setBackground(stroke(ui.menuCompositionMode()==2?Color.argb(112,20,28,40):Color.argb(70,10,14,24),Color.argb(80,255,255,255)));
        String ip=ui.iconPlacement();ArrayList<String> labels=new ArrayList<>();
        String searchIcon=ui.topMenuIconStyle()==2?"Search":"⌕";
        String settingsIcon=ui.topMenuIconStyle()==2?"Settings":"⚙";
        if(ip.equals("left")){labels.add(searchIcon);labels.add(settingsIcon);}
        if(ip.equals("inline"))Collections.addAll(labels,"Home","Live TV","Movies","Shows","Settings",searchIcon,settingsIcon); else Collections.addAll(labels,"Home","Live TV","Movies","Shows","Settings");
        if(ip.equals("right")){labels.add(searchIcon);labels.add(settingsIcon);}
        for(String s:labels){
            TextView m=btn(s);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(48));lp.setMargins(dp(5),0,dp(5),0);heroMenu.addView(m,lp);menuItems.add(m);
            m.setOnClickListener(v->{String z=((TextView)v).getText().toString();if(z.equals("Live TV"))showLiveTv();else if(z.equals("Movies")||z.equals("Shows"))showCatalogs(z);else if(z.equals("Settings")||z.equals("⚙"))showSettings();else if(z.equals("⌕")||z.equals("Search"))showSearch();else showHome();});
            m.setOnKeyListener((v,key,event)->{if(event.getAction()!=KeyEvent.ACTION_DOWN)return false;int pos=menuItems.indexOf(v);if(key==KeyEvent.KEYCODE_DPAD_RIGHT){menuItems.get((pos+1)%menuItems.size()).requestFocus();return true;}if(key==KeyEvent.KEYCODE_DPAD_LEFT){menuItems.get((pos-1+menuItems.size())%menuItems.size()).requestFocus();return true;}if(key==KeyEvent.KEYCODE_DPAD_DOWN){focusRowCard(0,0);return true;}return false;});
        }
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(dp(650),dp(58));hp.topMargin=dp(20);hp.leftMargin=dp(ui.topMenuOffsetDp());String pos=ui.menuPosition();hp.gravity=Gravity.TOP|(pos.equals("left")?Gravity.LEFT:pos.equals("right")?Gravity.RIGHT:Gravity.CENTER_HORIZONTAL);root.addView(heroMenu,hp);
    }

    void showHome(){
        clear();
        hero1080DensityActive = (ui.value("heroDensityMode",1)==0);
        nav.go(NavigationController.Screen.HOME);
        AppLogger.mark("DC_UI_ROOT_V075: HOME single_root hero_density="+heroDensityName(ui.value("heroDensityMode",1))+" global4k="+global4kMode());
        backdrop();addMenu();
        heroTextPanel=new View(this);heroTextPanel.setVisibility(View.GONE);root.addView(heroTextPanel,new FrameLayout.LayoutParams(dp(860),dp(280)));
        heroLogoImage=new ImageView(this);heroLogoImage.setScaleType(ImageView.ScaleType.FIT_CENTER);heroLogoImage.setAdjustViewBounds(true);heroLogoImage.setVisibility(View.INVISIBLE);FrameLayout.LayoutParams lpLogo=new FrameLayout.LayoutParams(dp(ui.heroLogoWidthDp()),dp(ui.heroLogoHeightDp()));lpLogo.leftMargin=dp(heroContentLeftDp());lpLogo.topMargin=dp(heroLogoTopBaseDp()+ui.heroLogoTopDp());root.addView(heroLogoImage,lpLogo);
        heroTitle=tv("",42,Typeface.BOLD);applyFont(heroTitle,ui.heroFontIndex(),Typeface.BOLD);heroTitle.setGravity(Gravity.LEFT);heroTitle.setIncludeFontPadding(false);heroTitle.setVisibility(View.INVISIBLE);FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(dp(680),dp(112));tp.leftMargin=dp(heroContentLeftDp());tp.topMargin=dp(heroTitleTopBaseDp());root.addView(heroTitle,tp);
        heroMeta=tv("",17,Typeface.BOLD);applyFont(heroMeta,ui.heroFontIndex(),Typeface.BOLD);heroMeta.setVisibility(View.GONE);heroRatingRow=new LinearLayout(this);heroRatingRow.setOrientation(LinearLayout.HORIZONTAL);heroRatingRow.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);heroRatingRow.setVisibility(View.INVISIBLE);FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(dp(760),dp(42));mp.leftMargin=dp(heroContentLeftDp());mp.topMargin=dp(184+ui.heroTextTopDp());root.addView(heroRatingRow,mp);
        heroDesc=tv("",18,Typeface.BOLD);applyFont(heroDesc,ui.heroFontIndex(),Typeface.BOLD);heroDesc.setGravity(Gravity.LEFT);heroDesc.setVisibility(View.INVISIBLE);FrameLayout.LayoutParams dpv=new FrameLayout.LayoutParams(dp(780),dp(120));dpv.leftMargin=dp(heroContentLeftDp());dpv.topMargin=dp(222+ui.heroTextTopDp());root.addView(heroDesc,dpv);
        heroBannerImage=new ImageView(this);heroBannerImage.setScaleType(ImageView.ScaleType.FIT_CENTER);heroBannerImage.setBackground(bg(Color.argb(0,0,0,0),0));heroBannerImage.setAlpha(ui.extraArtworkOpacityPercent()/100f);FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(ui.extraArtworkWidthDp()),dp(ui.extraArtworkHeightDp()));bp.leftMargin=dp(ui.extraArtworkXdp());bp.topMargin=dp(ui.extraArtworkYdp());root.addView(heroBannerImage,bp);
        addHeroRows(); addStatusHub(); if(!movies.isEmpty())updateHero(movies.get(0)); else AppLogger.mark("DC_UI_ROOT_V075: home_waiting_for_backend_no_placeholder_layer"); startHeroRotation();
    }
    void addStatusHub(){
        if(ui.statusHubEnabled()==0)return;
        LinearLayout hub=new LinearLayout(this);hub.setOrientation(LinearLayout.HORIZONTAL);hub.setGravity(Gravity.CENTER);hub.setPadding(dp(12),0,dp(12),0);
        int theme=ui.statusHubTheme();
        int fill=theme==1?Color.argb(0,0,0,0):theme==2?Color.argb(180,0,0,0):theme==3?Color.argb(170,245,245,245):Color.argb(88,12,18,28);
        int strokeColor=theme==1?Color.argb(0,0,0,0):theme==3?Color.argb(150,255,255,255):Color.argb(90,255,255,255);
        hub.setBackground(theme==1?bg(Color.TRANSPARENT,0):stroke(fill,strokeColor));
        int ts=Math.max(10,ui.statusHubTextSizeSp());
        if(ui.statusHubTimeEnabled()==1){TextView time=tv(currentClockText(),ts,Typeface.BOLD);time.setGravity(Gravity.CENTER);hub.addView(time,new LinearLayout.LayoutParams(dp(92),-1));final Runnable[] ticker=new Runnable[1];ticker[0]=()->{try{time.setText(currentClockText()); if(time.getParent()!=null)heroHandler.postDelayed(ticker[0],30000);}catch(Exception ignored){}};heroHandler.postDelayed(ticker[0],30000);}        
        if(ui.statusHubWeatherEnabled()==1){TextView weather=tv(" •  …°",Math.max(10,ts-2),Typeface.BOLD);weather.setGravity(Gravity.CENTER);weather.setSingleLine(true);hub.addView(weather,new LinearLayout.LayoutParams(dp(96),-1));fetchStatusWeather(weather);}
        if(ui.statusHubNotificationsEnabled()==1){TextView notify=tv(" •  No new favorites",Math.max(10,ts-4),Typeface.BOLD);notify.setGravity(Gravity.CENTER);notify.setSingleLine(true);notify.setTextColor(Color.argb(220,255,255,255));hub.addView(notify,new LinearLayout.LayoutParams(0,-1,1));}
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(dp(ui.statusHubWidthDp()),dp(ui.statusHubHeightDp()),Gravity.RIGHT|Gravity.BOTTOM);hp.rightMargin=dp(ui.statusHubRightDp());hp.bottomMargin=dp(ui.statusHubBottomDp());root.addView(hub,hp);
    }
    String currentClockText(){try{return new java.text.SimpleDateFormat("h:mm a",Locale.US).format(new java.util.Date());}catch(Exception e){return "--:--";}}

    void fetchStatusWeather(TextView target){
        final String location = first(backend.weatherLocation(), "Youngstown, Ohio");
        target.setText(" •  Weather…");
        new Thread(()->{try{
            String geo=httpGet("https://geocoding-api.open-meteo.com/v1/search?count=1&language=en&format=json&name="+URLEncoder.encode(location,"UTF-8"));
            JSONObject go=new JSONObject(geo); JSONArray results=go.optJSONArray("results"); if(results==null||results.length()==0)throw new Exception("location not found: "+location);
            JSONObject place=results.optJSONObject(0); double lat=place.optDouble("latitude"); double lon=place.optDouble("longitude"); String city=place.optString("name", location);
            String fc=httpGet("https://api.open-meteo.com/v1/forecast?latitude="+lat+"&longitude="+lon+"&current=temperature_2m,weather_code,is_day&temperature_unit=fahrenheit&wind_speed_unit=mph&precipitation_unit=inch&timezone=auto");
            JSONObject root=new JSONObject(fc); JSONObject current=root.optJSONObject("current"); double tempVal=Double.NaN;
            if(current!=null)tempVal=current.optDouble("temperature_2m", Double.NaN);
            if(Double.isNaN(tempVal)){
                String fc2=httpGet("https://api.open-meteo.com/v1/forecast?current_weather=true&temperature_unit=fahrenheit&latitude="+lat+"&longitude="+lon);
                JSONObject co=new JSONObject(fc2).optJSONObject("current_weather"); if(co!=null)tempVal=co.optDouble("temperature", Double.NaN);
            }
            if(Double.isNaN(tempVal))throw new Exception("temperature missing");
            int temp=(int)Math.round(tempVal); String shortCity=city.length()>12?city.substring(0,12):city;
            runOnUiThread(()->{ if(target.getParent()!=null) target.setText(" •  "+shortCity+" "+temp+"°"); });
        }catch(Exception e){AppLogger.mark("Weather hub failed: "+e.getMessage()); runOnUiThread(()->{ if(target.getParent()!=null) target.setText(" •  Weather --°"); }); }}).start();
    }

    GradientDrawable cardBg(int a){
        int base=ui.glassCardMode()==1?92:55;
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.argb(base,18,26,36),Color.argb(Math.max(base,70),5,8,14)});
        g.setCornerRadius(dp(ui.cornerRadiusDp()));
        g.setStroke(ui.glassCardMode()==1?dp(1):0,ui.glassCardMode()==1?Color.argb(70,255,255,255):Color.TRANSPARENT);
        return g;
    }
    GradientDrawable focusedCardBg(){
        int glowAlpha=Math.max(0,Math.min(230,50+(ui.glowStrengthPercent()*180/100)));
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.argb(ui.glassCardMode()==1?118:76,25,32,44),Color.argb(ui.glassCardMode()==1?125:90,6,10,18)});
        g.setCornerRadius(dp(ui.cornerRadiusDp()));
        if(ui.focusRingEnabled()==1 && ui.focusRingThicknessDp()>0){
            g.setStroke(dp(Math.max(1,ui.focusRingThicknessDp())),focusRingColor(ui.focusRingColorIndex(),glowAlpha));
        } else {
            g.setStroke(0,Color.TRANSPARENT);
        }
        return g;
    }
    void addHeroRows(){
        rowLists.clear();rowScrolls.clear();rowTitleViews.clear();
        int top=ui.rowTopDp();
        int max=Math.min(6,homeRows.size());
        activeRowIndex=Math.max(0,Math.min(activeRowIndex,Math.max(0,max-1)));
        for(int ri=0;ri<max;ri++)addHeroRow(homeRows.get(ri),top);
        updateActiveRowViewport(false);
    }
    void addHeroRow(HomeRow sourceRow,int topDp){
        TextView rt=null;
        if(ui.rowTitleVisibility()==1){rt=tv((ui.rowTitleIconsEnabled()==1?"▸ ":"")+sourceRow.title,22,Typeface.BOLD);applyFont(rt,ui.contentFontIndex(),Typeface.BOLD);rt.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);FrameLayout.LayoutParams rtp=new FrameLayout.LayoutParams(dp(700),dp(44));rtp.leftMargin=dp(38+ui.rowLeftDp());rtp.topMargin=dp(topDp-45);root.addView(rt,rtp);}        
        final HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);hsv.setClipToPadding(false);hsv.setSmoothScrollingEnabled(true);hsv.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);int sidePad=dp(28+ui.rowLeftDp());hsv.setPadding(sidePad,0,dp(320),0);FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(Math.max(190, ui.cardHeightDp()+78)));hp.topMargin=dp(topDp);root.addView(hsv,hp);
        final LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);hsv.addView(row,new HorizontalScrollView.LayoutParams(-2,-1));
        final int rowIndex=rowLists.size();rowLists.add(row);rowScrolls.add(hsv);rowTitleViews.add(rt);
        int maxCards=Math.min(sourceRow.items.size(), Math.max(12, ui.previewCardCount()*4));
        for(int i=0;i<maxCards;i++){final Movie movie=sourceRow.items.get(i);CardFrame card=new CardFrame(this,dp(ui.cornerRadiusDp()));card.setFocusable(true);card.setPadding(0,0,0,0);card.setBackground(cardBg(215));if(Build.VERSION.SDK_INT>=21)card.setElevation(dp(3));
            ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);img.setBackgroundColor(Color.TRANSPARENT);card.addView(img,new FrameLayout.LayoutParams(-1,-1));String art=rowArtwork(movie);if(!art.isEmpty())loadImage(art,img,false);else img.setImageDrawable(null);
            ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);logo.setAdjustViewBounds(true);logo.setAlpha(.98f);logo.setBackgroundColor(Color.TRANSPARENT);FrameLayout.LayoutParams lpLogoCard=new FrameLayout.LayoutParams(dp(Math.max(120,ui.cardWidthDp()-86)),dp(Math.max(48,ui.cardHeightDp()/2)),Gravity.CENTER);card.addView(logo,lpLogoCard);String cardLogoUrl=cardLogoArtwork(movie);if(isSafeCardLogo(cardLogoUrl)){logo.setVisibility(View.VISIBLE);loadImage(cardLogoUrl,logo,false);}else {logo.setImageDrawable(null);logo.setVisibility(View.GONE);}
            card.setOnKeyListener((v,key,event)->{if(event.getAction()!=KeyEvent.ACTION_DOWN)return false;int pos=Math.max(0,row.indexOfChild(v));if(key==KeyEvent.KEYCODE_DPAD_RIGHT&&pos<row.getChildCount()-1){View next=row.getChildAt(pos+1);next.requestFocus();centerSnap(hsv,next);AppLogger.mark("ROW_NAV right row="+rowIndex+" col="+(pos+1));return true;}if(key==KeyEvent.KEYCODE_DPAD_LEFT&&pos>0){View prev=row.getChildAt(pos-1);prev.requestFocus();centerSnap(hsv,prev);AppLogger.mark("ROW_NAV left row="+rowIndex+" col="+(pos-1));return true;}if(key==KeyEvent.KEYCODE_DPAD_DOWN){focusRowCard(rowIndex+1,pos);return true;}if(key==KeyEvent.KEYCODE_DPAD_UP){focusRowCard(rowIndex-1,pos);return true;}return false;});
            card.setOnFocusChangeListener((v,h)->{
                float scale=h?Math.max(1f,ui.focusedScalePercent()/100f):1f;
                if(h&&ui.focusBouncePercent()>0)scale+=Math.min(.08f,ui.focusBouncePercent()/1000f);
                float lift=h?-dp(10+ui.cardLiftDp()):0;
                v.animate().scaleX(scale).scaleY(scale).translationY(lift).rotationY(h?Math.min(8f,ui.cardTiltPercent()/10f):0f).setDuration(h?190:140).start();
                float dim=1f-(Math.max(0,Math.min(70,ui.dimUnfocusedPercent()))/100f)*.55f;
                v.setAlpha(h?1f:dim);
                if(Build.VERSION.SDK_INT>=21)v.setElevation(h?dp(8+ui.glowStrengthPercent()/6+ui.cardLiftDp()):dp(3));
                v.setBackground(h?focusedCardBg():cardBg(215));
                if(h){activeRowIndex=rowIndex;updateActiveRowViewport(false);scheduleHeroUpdate(movie);v.postDelayed(()->centerSnap(hsv,v),40);}
            });
            card.setOnClickListener(v->showMovieDetails(movie));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(ui.cardWidthDp()),dp(ui.cardHeightDp()));cp.setMargins(0,dp(18),dp(ui.cardSpacingDp()),0);row.addView(card,cp);
        }
        hsv.postDelayed(()->{if(!suppressRowAutoFocus && rowIndex==0 && row.getChildCount()>0){View start=row.getChildAt(0);start.requestFocus();centerSnap(hsv,start);}},140);
    }
    void focusRowCard(int rowIndex,int colIndex){
        AppLogger.mark("ROW_NAV request row="+rowIndex+" col="+colIndex+" rows="+rowLists.size());
        if(rowIndex<0){ if(!menuItems.isEmpty())menuItems.get(0).requestFocus(); return; }
        if(rowIndex>=rowLists.size()){ AppLogger.mark("ROW_NAV ignored: no target row"); return; }
        LinearLayout row=rowLists.get(rowIndex);
        if(row==null||row.getChildCount()==0){ AppLogger.mark("ROW_NAV ignored: empty row "+rowIndex); return; }
        int target=Math.max(0,Math.min(colIndex,row.getChildCount()-1));
        View card=row.getChildAt(target);
        activeRowIndex=rowIndex;
        updateActiveRowViewport(true);
        card.postDelayed(()->{ card.requestFocus(); if(rowIndex<rowScrolls.size())centerSnap(rowScrolls.get(rowIndex),card); AppLogger.mark("ROW_NAV focused row="+rowIndex+" col="+target); },70);
    }
    void updateActiveRowViewport(boolean animate){
        for(int i=0;i<rowScrolls.size();i++){
            boolean active=(i==activeRowIndex);
            HorizontalScrollView hsv=rowScrolls.get(i);
            TextView title=i<rowTitleViews.size()?rowTitleViews.get(i):null;
            hsv.setVisibility(active?View.VISIBLE:View.INVISIBLE);
            hsv.setFocusable(active);
            hsv.setFocusableInTouchMode(active);
            hsv.setEnabled(active);
            hsv.setAlpha(active?1f:0f);
            hsv.setTranslationY(0f);
            if(title!=null){title.setVisibility(active?View.VISIBLE:View.INVISIBLE);title.setAlpha(active?1f:0f);}
        }
    }
    void centerSnap(HorizontalScrollView hsv,View card){int target=card.getLeft()+card.getWidth()/2-getResources().getDisplayMetrics().widthPixels/2;hsv.smoothScrollTo(Math.max(0,target),0);}
    void scheduleHeroUpdate(Movie m){
        if(m==null)return;
        final int seq=++heroUpdateSeq;
        if(pendingHeroRunnable!=null)heroHandler.removeCallbacks(pendingHeroRunnable);
        pendingHeroRunnable=()->{ if(seq==heroUpdateSeq) updateHero(m); };
        heroHandler.postDelayed(pendingHeroRunnable,35);
    }


    TextView metaText(String text,int color,int style){TextView t=tv(text,16,style);t.setGravity(Gravity.CENTER_VERTICAL);t.setTextColor(color);t.setIncludeFontPadding(false);return t;}
    TextView badge(String text,int bgColor,int textColor){TextView t=tv(text,14,Typeface.BOLD);t.setTextColor(textColor);t.setIncludeFontPadding(false);t.setGravity(Gravity.CENTER);t.setPadding(dp(9),0,dp(9),0);t.setBackground(bg(bgColor,7));return t;}
    void addMetaPiece(LinearLayout row,View v,int w,int h,int leftMargin){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(w<0?w:dp(w),dp(h));lp.setMargins(dp(leftMargin),0,0,0);row.addView(v,lp);}
    void buildHeroRatingRow(Movie m){
        if(heroRatingRow==null)return; heroRatingRow.removeAllViews();
        String y=first(m.year,extractYear(m.meta));
        if(!y.isEmpty())addMetaPiece(heroRatingRow,metaText(y,Color.rgb(255,220,56),Typeface.BOLD),-2,30,0);
        addMetaPiece(heroRatingRow,metaText("•",Color.WHITE,Typeface.BOLD),-2,30,12);
        addMetaPiece(heroRatingRow,metaText(first(m.tag,"FEATURED").toUpperCase(Locale.US),Color.WHITE,Typeface.BOLD),-2,30,12);
        String imdb=first(m.imdbRating,extractRating(m.meta,"IMDB"),extractRating(m.meta,"IMDb"));
        if(!imdb.isEmpty()){addMetaPiece(heroRatingRow,badge("IMDb",Color.rgb(245,197,24),Color.BLACK),58,24,20);addMetaPiece(heroRatingRow,metaText(imdb,Color.WHITE,Typeface.NORMAL),-2,30,8);}
        String tmdb=first(m.tmdbRating,extractRating(m.meta,"TMDB"));
        if(!tmdb.isEmpty()){addMetaPiece(heroRatingRow,metaText("|",Color.argb(210,255,255,255),Typeface.NORMAL),-2,30,14);addMetaPiece(heroRatingRow,badge("TMDB",Color.rgb(1,180,228),Color.WHITE),62,24,14);addMetaPiece(heroRatingRow,metaText(tmdb,Color.WHITE,Typeface.NORMAL),-2,30,8);}
    }
    String extractYear(String meta){if(meta==null)return "";java.util.regex.Matcher m=java.util.regex.Pattern.compile("(19|20)\\d{2}").matcher(meta);return m.find()?m.group():"";}
    String extractRating(String meta,String key){if(meta==null)return "";int i=meta.toUpperCase(Locale.US).indexOf(key.toUpperCase(Locale.US));if(i<0)return "";java.util.regex.Matcher m=java.util.regex.Pattern.compile("([0-9](?:\\.[0-9])?)").matcher(meta.substring(i));return m.find()?m.group(1):"";}


    void lockRatings(Movie m){
        if(m==null)return;
        String imdbId=first(m.id,extractImdbId(m.meta));
        String key=first(imdbId,m.title);
        String imdb=first(m.imdbRating,extractRating(m.meta,"IMDB"),extractRating(m.meta,"IMDb"));
        String tmdb=first(m.tmdbRating,extractRating(m.meta,"TMDB"),extractRating(m.meta,"TMDb"));
        String[] cached=ratingCache.get(key);
        if(imdb.isEmpty()&&cached!=null)imdb=cached[0];
        if(tmdb.isEmpty()&&cached!=null)tmdb=cached[1];
        if(!imdb.isEmpty()||!tmdb.isEmpty())ratingCache.put(key,new String[]{imdb,tmdb});
        m.imdbRating=imdb==null?"":imdb;
        m.tmdbRating=tmdb==null?"":tmdb;
        if((m.id==null||m.id.isEmpty())&&!imdbId.isEmpty())m.id=imdbId;
    }

    int heroTitleBaseSize(){
        int scale=ui.value("heroTextScale",2);
        int base=scale==0?26:scale==1?32:scale==3?46:scale==4?54:40;
        int style=ui.value("heroTextStyle",0);
        if(style==4)base+=5;
        if(style==5||style==6||style==10)base-=6;
        int theme=ui.value("heroTextTheme",0);
        if(theme==1||theme==5)base-=4;
        if(theme==2)base+=4;
        return Math.max(22,base);
    }
    int heroTextColorForStyle(){
        int style=ui.value("heroTextStyle",0);
        if(style==1)return Color.rgb(220,255,245);
        if(style==3)return Color.rgb(255,224,120);
        if(style==8)return Color.rgb(235,244,255);
        return Color.WHITE;
    }
    void applyHeroTextStyle(){
        int style=ui.value("heroTextStyle",0);
        int color=heroTextColorForStyle();
        if(heroTitle!=null){
            heroTitle.setTextColor(color);
            heroTitle.setTextSize(heroTitleBaseSize());
            heroTitle.setShadowLayer(style==0?0:style==1?18:style==2?12:style==3?9:style==8?16:6,0,style==2?4:0,style==1?Color.rgb(0,220,255):Color.BLACK);
            if(Build.VERSION.SDK_INT>=21)heroTitle.setLetterSpacing(ui.value("heroLetterSpacing",0)/100f);
            applyFont(heroTitle,ui.heroFontIndex(),Typeface.BOLD);
        }
        if(heroDesc!=null){ heroDesc.setTextColor(Color.argb(style==5?225:235,255,255,255)); heroDesc.setTextSize(Math.max(14,heroTitleBaseSize()/2)); applyFont(heroDesc,ui.heroFontIndex(),Typeface.BOLD); }
        if(heroMeta!=null){ heroMeta.setTextColor(Color.argb(225,255,255,255)); heroMeta.setTextSize(Math.max(13,heroTitleBaseSize()/2-2)); applyFont(heroMeta,ui.heroFontIndex(),Typeface.BOLD); }
    }

    void applyHeroThemeLayout(Movie m){
        int theme=Math.max(0,Math.min(5,ui.value("heroTextTheme",0)));
        int mode=ui.value("heroTextMode",0);
        boolean hasLogo=m!=null && m.logo!=null && !m.logo.isEmpty();
        int left=22+ui.heroTextLeftDp();
        int logoTop=86+ui.heroTextTopDp();
        int titleTop=92+ui.heroTextTopDp();
        int metaTop=184+ui.heroTextTopDp();
        int descTop=222+ui.heroTextTopDp();
        int titleW=680, titleH=112, descW=780, descH=120, logoW=ui.heroLogoWidthDp(), logoH=ui.heroLogoHeightDp();
        boolean showPanel=false;
        if(theme==1){ left=28+ui.heroTextLeftDp(); logoTop=72+ui.heroTextTopDp(); titleTop=168+ui.heroTextTopDp(); metaTop=220+ui.heroTextTopDp(); descTop=252+ui.heroTextTopDp(); logoW=Math.min(logoW,360); logoH=Math.min(logoH,82); titleW=620; titleH=76; descH=96; }
        if(theme==2){ left=64+ui.heroTextLeftDp(); logoTop=88+ui.heroTextTopDp(); titleTop=188+ui.heroTextTopDp(); metaTop=252+ui.heroTextTopDp(); descTop=292+ui.heroTextTopDp(); titleW=900; titleH=92; descW=900; descH=104; }
        if(theme==3||mode==5){ left=34+ui.heroTextLeftDp(); logoTop=254+ui.heroTextTopDp(); titleTop=330+ui.heroTextTopDp(); metaTop=386+ui.heroTextTopDp(); descTop=420+ui.heroTextTopDp(); titleW=760; titleH=84; descW=840; descH=86; }
        if(theme==4){ left=52+ui.heroTextLeftDp(); logoTop=116+ui.heroTextTopDp(); titleTop=206+ui.heroTextTopDp(); metaTop=264+ui.heroTextTopDp(); descTop=300+ui.heroTextTopDp(); titleW=760; descW=780; showPanel=true; }
        if(theme==5){ left=24+ui.heroTextLeftDp(); logoTop=118+ui.heroTextTopDp(); titleTop=206+ui.heroTextTopDp(); metaTop=254+ui.heroTextTopDp(); descTop=286+ui.heroTextTopDp(); titleW=560; titleH=70; descW=640; descH=72; }
        int logoLeft = ui.value("heroLogoAlignWithText",1)==1 ? left : left + ui.heroLogoLeftDp();
        if(heroLogoImage!=null){FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)heroLogoImage.getLayoutParams();lp.leftMargin=dp(logoLeft);lp.topMargin=dp(logoTop+ui.heroLogoTopDp());lp.width=dp(logoW);lp.height=dp(logoH);heroLogoImage.setLayoutParams(lp);heroLogoImage.setAlpha(theme==5?.86f:1f); if(Build.VERSION.SDK_INT>=21)heroLogoImage.setElevation(dp(theme==4?9:4));}
        if(heroTitle!=null){FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)heroTitle.getLayoutParams();lp.leftMargin=dp(left);lp.topMargin=dp(titleTop);lp.width=dp(titleW);lp.height=dp(titleH);heroTitle.setLayoutParams(lp);heroTitle.setGravity(theme==2?Gravity.LEFT|Gravity.CENTER_VERTICAL:Gravity.LEFT|Gravity.TOP);heroTitle.setVisibility((mode==0&&hasLogo)?View.INVISIBLE:View.VISIBLE);}
        if(heroRatingRow!=null){FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)heroRatingRow.getLayoutParams();lp.leftMargin=dp(left);lp.topMargin=dp(metaTop);lp.width=dp(descW);heroRatingRow.setLayoutParams(lp);heroRatingRow.setVisibility(theme==5?View.GONE:View.VISIBLE);}
        if(heroDesc!=null){FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)heroDesc.getLayoutParams();lp.leftMargin=dp(left);lp.topMargin=dp(descTop);lp.width=dp(descW);lp.height=dp(descH);heroDesc.setLayoutParams(lp);heroDesc.setVisibility(theme==5?View.GONE:heroDesc.getVisibility());}
        if(heroTextPanel!=null){FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)heroTextPanel.getLayoutParams();lp.leftMargin=dp(left-20);lp.topMargin=dp(Math.max(70,logoTop-20));lp.width=dp(Math.max(760,descW+54));lp.height=dp(theme==4?260:230);heroTextPanel.setLayoutParams(lp);heroTextPanel.setVisibility(showPanel?View.VISIBLE:View.GONE);heroTextPanel.setBackground(stroke(Color.argb(102,8,14,24),Color.argb(70,255,255,255))); if(Build.VERSION.SDK_INT>=21)heroTextPanel.setElevation(dp(2));}
        AppLogger.mark("HERO_THEME_V080: applied visible layer theme="+theme+" mode="+mode+" textLeft="+left+" logoAlign="+heroLogoAlignName(ui.value("heroLogoAlignWithText",1))+" titleTop="+titleTop+" hasLogo="+hasLogo);
    }
    void applyVisibleHeroTheme(){ if(currentHeroMovie!=null) updateHero(currentHeroMovie); else { applyHeroTextStyle(); applyHeroThemeLayout(null); } }

    void startHeroRotation(){
        if(heroRotationRunnable!=null)heroHandler.removeCallbacks(heroRotationRunnable);
        if(ui.value("heroRotationMode",0)==0)return;
        heroRotationRunnable=()->{
            try{
                ArrayList<Movie> pool=new ArrayList<>();
                if(ui.value("heroRotationMode",0)==1 && activeRowIndex>=0 && activeRowIndex<homeRows.size())pool.addAll(homeRows.get(activeRowIndex).items); else for(HomeRow r:homeRows)pool.addAll(r.items);
                if(!pool.isEmpty()){heroRotationIndex=(heroRotationIndex+1)%pool.size(); updateHero(pool.get(heroRotationIndex));}
                heroHandler.postDelayed(heroRotationRunnable,Math.max(5,ui.value("heroRotationIntervalSec",15))*1000L);
            }catch(Exception ignored){}
        };
        heroHandler.postDelayed(heroRotationRunnable,Math.max(5,ui.value("heroRotationIntervalSec",15))*1000L);
    }

    int heroContentLeftDp(){ return 22 + ui.heroTextLeftDp(); }
    int heroLogoTopBaseDp(){ return 86 + ui.heroTextTopDp(); }
    int heroTitleTopBaseDp(){ return 92 + ui.heroTextTopDp(); }
    void alignHeroLogoWithText(int mode){
        if(heroLogoImage==null)return;
        FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)heroLogoImage.getLayoutParams();
        int contentLeft = (mode==5 ? 34 + ui.heroTextLeftDp() : heroContentLeftDp());
        if(ui.value("heroLogoAlignWithText",1)==0) contentLeft += ui.heroLogoLeftDp();
        // v0.6.3 default alignment: logo shares the exact same left axis as hero title/meta/description.
        // Pro-editor left offset no longer drifts the default logo away from the text stack.
        lp.leftMargin = dp(contentLeft);
        lp.topMargin = dp((mode==5 ? 254 + ui.heroTextTopDp() : heroLogoTopBaseDp()) + ui.heroLogoTopDp());
        lp.width = dp(ui.heroLogoWidthDp());
        lp.height = dp(ui.heroLogoHeightDp());
        heroLogoImage.setLayoutParams(lp);
        AppLogger.mark("HERO_ALIGNMENT_V080: logoLeft="+contentLeft+" titleLeft="+heroContentLeftDp()+" mode="+mode+" align="+heroLogoAlignName(ui.value("heroLogoAlignWithText",1)));
    }
    void clearHeroImageIfChanged(ImageView target, String newUrl, boolean logo){
        if(target==null)return;
        newUrl=abs(newUrl);
        String cur=logo?currentHeroLogoUrl:currentHeroBackdropUrl;
        if(!newUrl.equals(cur)){
            if(logo)currentHeroLogoUrl=newUrl; else currentHeroBackdropUrl=newUrl;
            target.animate().cancel();
            target.setImageDrawable(null);
            target.setAlpha(logo?1f:0f);
            AppLogger.mark("HERO_UNDERLAY_V063: cleared_stale_art logo="+logo+" url="+newUrl);
        }
    }

    void updateHero(Movie m){
        if(m==null)return;
        currentHeroMovie=m;
        lockRatings(m);
        fetchMissingRatingsOnce(m);
        applyHeroTextStyle();
        if(heroTitle!=null){
            int mode=ui.value("heroTextMode",0);
            heroTitle.setText(mode==4?m.title.toUpperCase(Locale.US):m.title.replace(" ",mode==1?" ":"\n"));
            boolean hasLogo=m.logo!=null&&!m.logo.isEmpty();
            heroTitle.setVisibility((mode==0&&hasLogo)?View.INVISIBLE:View.VISIBLE);
            applyHeroThemeLayout(m);
        }
        if(heroMeta!=null)heroMeta.setText((m.meta==null||m.meta.isEmpty()?m.year:m.meta));
        buildHeroRatingRow(m);
        if(heroRatingRow!=null)heroRatingRow.setVisibility(View.VISIBLE);
        if(heroDesc!=null){heroDesc.setVisibility((m.overview==null||m.overview.trim().isEmpty())?View.GONE:View.VISIBLE);heroDesc.setText(m.overview==null?"":m.overview);}
        if(heroBackdropImage!=null){ String bgUrl=first(m.background,m.poster); clearHeroImageIfChanged(heroBackdropImage,bgUrl,false); loadImage(bgUrl,heroBackdropImage,true); }
        if(heroLogoImage!=null){ if(m.logo!=null&&!m.logo.isEmpty()){ heroLogoImage.setVisibility(View.VISIBLE); clearHeroImageIfChanged(heroLogoImage,m.logo,true); loadImage(m.logo,heroLogoImage,true); } else { currentHeroLogoUrl=""; heroLogoImage.setImageDrawable(null); heroLogoImage.setVisibility(View.GONE);} }
        if(heroBannerImage!=null){
            FrameLayout.LayoutParams bp=(FrameLayout.LayoutParams)heroBannerImage.getLayoutParams();
            applyExtraArtworkPosition(bp);
            bp.width=dp(ui.extraArtworkWidthDp()); bp.height=dp(ui.extraArtworkHeightDp());
            heroBannerImage.setLayoutParams(bp);
            String extra=extraArtworkFor(m);
            applyExtraArtworkTilt(heroBannerImage);
            if(ui.extraArtworkEnabled()==0||extra.isEmpty()){heroBannerImage.setImageDrawable(null);heroBannerImage.setAlpha(0f);}
            else {heroBannerImage.setAlpha(ui.extraArtworkOpacityPercent()/100f);loadImage(extra,heroBannerImage,true);}
        }
    }
    String extraArtworkFor(Movie m){
        if(m==null)return "";
        int type=ui.extraArtworkType();
        if(type==0||type==14)return "";
        String logo=isSafeCardLogo(m.logo)?m.logo:"";
        switch(type){
            case 1: return first(m.banner,logo,m.background,m.poster);
            case 2: return first(m.banner,m.background);
            case 3: return logo;
            case 4: return first(m.poster,m.banner);
            case 5: return first(m.background,m.banner);
            case 6: return first(m.banner,m.poster);
            case 7: return first(m.banner,logo);
            case 8: return first(m.poster,m.banner);
            case 9: return first(m.banner,m.background,m.poster);
            case 10:return first(m.background,m.banner);
            case 11:return first(logo,m.banner);
            case 12:return first(m.poster,m.banner);
            case 13:return first(m.background,m.banner);
            default:return first(m.banner,logo,m.background);
        }
    }

    void applyExtraArtworkTilt(ImageView v){
        if(v==null)return;
        boolean enabled=ui.value("extraArtworkTiltEnabled",0)==1;
        int tilt=Math.max(0,Math.min(100,ui.value("extraArtworkTiltPercent",28)));
        if(Build.VERSION.SDK_INT>=21){
            v.setCameraDistance(dp(9000));
            v.setElevation(enabled?dp(10+ui.extraArtworkDepthPercent()/10):dp(2));
        }
        v.setRotationY(enabled?Math.min(18f,tilt/4f):0f);
        v.setRotationX(enabled?-Math.min(8f,tilt/10f):0f);
        v.setTranslationZ(enabled&&Build.VERSION.SDK_INT>=21?dp(ui.extraArtworkDepthPercent()/5):0f);
        AppLogger.mark("HERO_EXTRA_ART_V080: tilt="+(enabled?"on":"off")+" percent="+tilt);
    }

    void applyExtraArtworkPosition(FrameLayout.LayoutParams bp){
        int pos=ui.value("extraArtworkPosition",0);
        bp.gravity=Gravity.LEFT|Gravity.TOP;
        if(pos==1){
            bp.leftMargin=dp(36); bp.topMargin=dp(104);
        }else if(pos==2){
            bp.leftMargin=0; bp.topMargin=dp(104); bp.rightMargin=dp(46); bp.gravity=Gravity.RIGHT|Gravity.TOP;
        }else{
            bp.leftMargin=dp(ui.extraArtworkXdp()); bp.topMargin=dp(ui.extraArtworkYdp()); bp.rightMargin=0;
        }
        AppLogger.mark("HERO_EXTRA_ART_V080: position="+extraArtworkPositionName(pos)+" w="+ui.extraArtworkWidthDp()+" h="+ui.extraArtworkHeightDp());
    }

    String first(String...v){for(String x:v)if(x!=null&&!x.trim().isEmpty())return x.trim();return "";}
    boolean looksPortraitOrLogo(String u){
        if(u==null)return true;
        String x=u.trim().toLowerCase(Locale.US);
        if(x.isEmpty())return true;
        return x.contains("/poster/")||x.contains("poster")||x.contains("portrait")||x.contains("thumbnail")||x.contains("thumb")||x.contains("/logo/")||x.contains("clearlogo")||x.contains("clear_logo")||x.contains("clear-logo");
    }
    boolean isSafeCardLogo(String u){
        if(u==null)return false;
        String x=u.trim().toLowerCase(Locale.US);
        if(x.isEmpty())return false;
        if(x.contains("poster")||x.contains("background")||x.contains("backdrop")||x.contains("thumbnail")||x.contains("thumb")||x.contains("portrait")||x.contains("landscape")||x.contains("banner"))return false;
        return x.contains("/logo/")||x.contains("clearlogo")||x.contains("clear_logo")||x.contains("clear-logo")||x.contains("fanart.tv/fanart/");
    }
    String cardLogoArtwork(Movie m){
        if(m==null)return "";
        if(isSafeCardLogo(m.logo))return m.logo.trim();
        if(m.id!=null && m.id.trim().startsWith("tt"))return "https://images.metahub.space/logo/medium/"+m.id.trim()+"/img";
        return "";
    }
    String rowArtwork(Movie m){
        if(m==null)return "";
        // Best quality row-card order: landscape/banner first, then cinematic backdrop/fanart, then poster only as last-resort.
        if(m.banner!=null&&!m.banner.trim().isEmpty()&&!looksPortraitOrLogo(m.banner))return m.banner.trim();
        if(m.background!=null&&!m.background.trim().isEmpty()&&!looksPortraitOrLogo(m.background))return m.background.trim();
        if(m.poster!=null&&!m.poster.trim().isEmpty())return m.poster.trim();
        return "";
    }

    final Set<String> ratingFetchInFlight = Collections.synchronizedSet(new HashSet<String>());
    void fetchMissingRatingsOnce(Movie m){
        if(m==null)return;
        if(!first(m.imdbRating,m.tmdbRating).isEmpty())return;
        String id=first(m.id,extractImdbId(m.meta));
        if(id.isEmpty()||!id.startsWith("tt")||ratingFetchInFlight.contains(id))return;
        ratingFetchInFlight.add(id);
        new Thread(()->{
            try{
                String txt=httpGet("https://v3-cinemeta.strem.io/meta/movie/"+URLEncoder.encode(id,"UTF-8")+".json");
                JSONObject obj=new JSONObject(txt).optJSONObject("meta");
                if(obj==null)return;
                String imdb=ratingFrom(obj,"imdbRating","imdb_rating","imdbScore","imdb");
                String tmdb=ratingFrom(obj,"tmdbRating","tmdb_rating","tmdbScore","tmdb","vote_average");
                if(!imdb.isEmpty()||!tmdb.isEmpty()){
                    runOnUiThread(()->{
                        if(m.imdbRating.isEmpty())m.imdbRating=imdb;
                        if(m.tmdbRating.isEmpty())m.tmdbRating=tmdb;
                        lockRatings(m);
                        if(heroRatingRow!=null)buildHeroRatingRow(m);
                    });
                }
            }catch(Exception e){AppLogger.mark("Cinemeta rating fill skipped: "+e.getMessage());}
        }).start();
    }

    void showCatalogs(String type){suppressRowAutoFocus=false;clear();nav.go(NavigationController.Screen.VOD);backdrop();addMenu();TextView h=tv(type,38,Typeface.BOLD);h.setGravity(Gravity.LEFT);FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(dp(500),dp(60));hp.leftMargin=dp(55);hp.topMargin=dp(115);root.addView(h,hp);addHeroRows();}

    void showMovieDetails(Movie m){
        suppressRowAutoFocus=false; lockRatings(m); selectedMedia = new SelectedMedia(m);
        clear();backdrop();addMenu();updateHero(m);
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setGravity(Gravity.CENTER);panel.setPadding(dp(90),dp(92),dp(90),dp(36));
        FrameLayout.LayoutParams ppnl=new FrameLayout.LayoutParams(-1,dp(540));ppnl.topMargin=dp(90);root.addView(panel,ppnl);
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setGravity(Gravity.CENTER);info.setPadding(dp(20),0,dp(20),0);panel.addView(info,new LinearLayout.LayoutParams(dp(980),-1));
        ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);String lg=cardLogoArtwork(m);
        if(isSafeCardLogo(lg)){loadImage(lg,logo,false);info.addView(logo,new LinearLayout.LayoutParams(dp(560),dp(128)));}
        else{TextView title=tv(m.title,44,Typeface.BOLD);title.setGravity(Gravity.CENTER);info.addView(title,new LinearLayout.LayoutParams(-1,dp(96)));}
        LinearLayout ratings=new LinearLayout(this);ratings.setGravity(Gravity.CENTER);ratings.setOrientation(LinearLayout.HORIZONTAL);info.addView(ratings,new LinearLayout.LayoutParams(-1,dp(46)));buildRatingRowInto(ratings,m,true);
        TextView desc=tv(first(m.overview,"Select Play to load Stremio addon streams for this title."),20,Typeface.NORMAL);desc.setGravity(Gravity.CENTER);desc.setLineSpacing(dp(3),1.04f);desc.setAlpha(.94f);info.addView(desc,new LinearLayout.LayoutParams(dp(900),dp(150)));
        LinearLayout buttons=new LinearLayout(this);buttons.setGravity(Gravity.CENTER);info.addView(buttons,new LinearLayout.LayoutParams(-1,dp(84)));
        boolean series=isSeries(m);
        TextView play=btn(series?"▶ Episodes":"▶ Play / Select Streams"); TextView trailer=btn("🎬 Trailer"); TextView fav=btn("★ Favorite"); TextView back=btn("Back");
        buttons.addView(play,new LinearLayout.LayoutParams(dp(series?230:330),dp(60)));
        LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(dp(190),dp(60));tlp.setMargins(dp(18),0,0,0);buttons.addView(trailer,tlp);
        LinearLayout.LayoutParams flp=new LinearLayout.LayoutParams(dp(180),dp(60));flp.setMargins(dp(18),0,0,0);buttons.addView(fav,flp);
        LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(dp(150),dp(60));blp.setMargins(dp(18),0,0,0);buttons.addView(back,blp);
        play.setOnClickListener(v->{ if(series) showShowDetails(m); else showStreamList(m); }); trailer.setOnClickListener(v->playTrailerFor(m,true)); fav.setOnClickListener(v->Toast.makeText(this,"Favorite saved locally for "+m.title,Toast.LENGTH_SHORT).show()); back.setOnClickListener(v->showHome());play.requestFocus();
        scheduleTrailerPopup(m);
    }

    boolean isSeries(Movie m){String t=first(m.type,"").toLowerCase(Locale.US);return t.equals("series")||t.equals("show")||t.equals("tv")||t.contains("series");}
    String seriesId(Movie m){return first(m.id,extractImdbId(m.meta));}
    TrailerSettings trailerSettings(){android.content.SharedPreferences p=getSharedPreferences("dc_v040_trailers",MODE_PRIVATE);TrailerSettings ts=new TrailerSettings();ts.autoPopup=p.getBoolean("autoPopup",true);ts.delaySeconds=p.getInt("delaySeconds",2);ts.muted=p.getBoolean("muted",false);ts.disabled=p.getBoolean("disabled",false);return ts;}
    void saveTrailerSetting(String key,Object value){android.content.SharedPreferences.Editor e=getSharedPreferences("dc_v040_trailers",MODE_PRIVATE).edit();if(value instanceof Boolean)e.putBoolean(key,(Boolean)value);else if(value instanceof Integer)e.putInt(key,(Integer)value);e.apply();}
    void cycleTrailerDelay(){TrailerSettings ts=trailerSettings();int n=ts.delaySeconds==0?2:ts.delaySeconds==2?5:ts.delaySeconds==5?10:0;saveTrailerSetting("delaySeconds",n);}
    void scheduleTrailerPopup(Movie m){TrailerSettings ts=trailerSettings();if(m==null||ts.disabled||!ts.autoPopup)return;if(pendingTrailerRunnable!=null)trailerHandler.removeCallbacks(pendingTrailerRunnable);pendingTrailerRunnable=()->playTrailerFor(m,false);trailerHandler.postDelayed(pendingTrailerRunnable,Math.max(0,ts.delaySeconds)*1000L);}
    void playTrailerFor(Movie m, boolean manual){
        TrailerSettings ts=trailerSettings();
        if(m==null)return;
        if(ts.disabled&&!manual)return;
        String id=first(extractImdbId(m.meta),m.id,m.title);
        if(manual)Toast.makeText(this,"Resolving trailer…",Toast.LENGTH_SHORT).show();
        new Thread(()->{
            TrailerResolveResult result=resolveTrailerUrl(id,m);
            runOnUiThread(()->{
                if(result==null||result.url==null||result.url.isEmpty()){
                    Toast.makeText(this,"Trailer not playable yet for "+m.title+" — check v0.4.1 trailer logs",Toast.LENGTH_LONG).show();
                    AppLogger.mark("Trailer v0.4.1 empty result for "+m.title+" id="+id);
                    return;
                }
                showTrailerOverlay(result.urls(),ts.muted,m.title);
            });
        }).start();
    }

    static class TrailerResolveResult {
        String url=""; String source=""; ArrayList<String> allUrls=new ArrayList<>();
        TrailerResolveResult(String u,String s){url=u;source=s;if(u!=null&&!u.isEmpty())allUrls.add(u);}
        TrailerResolveResult(ArrayList<String> urls,String s){source=s;if(urls!=null){for(String u:urls){if(u!=null&&!u.isEmpty()&&!allUrls.contains(u))allUrls.add(u);}}url=allUrls.isEmpty()?"":allUrls.get(0);}
        ArrayList<String> urls(){return allUrls.isEmpty()&&url!=null&&!url.isEmpty()?new ArrayList<>(java.util.Arrays.asList(url)):allUrls;}
    }


    void mergeTrailerUrls(ArrayList<String> dst, ArrayList<String> src){
        if(src==null)return;
        for(String u:src) if(isDirectPlayableTrailer(u) && !dst.contains(u)) dst.add(u);
    }

    ArrayList<String> sortedPlayableTrailerUrls(String txt){
        ArrayList<String> raw=trailerUrlsFromJson(txt);
        ArrayList<String> hls=new ArrayList<>(), mp4=new ArrayList<>(), other=new ArrayList<>();
        for(String u:raw){
            if(!isDirectPlayableTrailer(u))continue;
            String l=u.toLowerCase(Locale.US);
            if(l.contains(".m3u8"))addCandidate(hls,u);
            else if(l.contains(".mp4")||l.contains("googlevideo.com")||l.contains("/videoplayback"))addCandidate(mp4,u);
            else addCandidate(other,u);
        }
        ArrayList<String> out=new ArrayList<>(); mergeTrailerUrls(out,mp4); mergeTrailerUrls(out,other); mergeTrailerUrls(out,hls); return out;
    }

    TrailerResolveResult resolveTrailerUrl(String id, Movie m){
        ArrayList<String> resolvedUrls=new ArrayList<>();
        ArrayList<String> candidates=new ArrayList<>();
        addCandidate(candidates, extractImdbId(m.meta));
        addCandidate(candidates, m.id);
        addCandidate(candidates, id);
        addCandidate(candidates, m.title);
        if(m.year!=null&&!m.year.isEmpty())addCandidate(candidates, m.title+" "+m.year);
        for(String c:candidates){
            try{
                String safe=URLEncoder.encode(c,"UTF-8").replace("+","%20");
                String txt=httpGet(joinUrl(backend.baseUrl(),"/api/trailer/"+safe));
                mergeTrailerUrls(resolvedUrls, sortedPlayableTrailerUrls(txt));
                TrailerResolveResult resolved=resolveTrailerCandidate(bestAnyTrailerUrl(txt),m,"/api/trailer embedded");
                if(resolved!=null&&!resolved.url.isEmpty())mergeTrailerUrls(resolvedUrls,resolved.urls());
                if(resolvedUrls.size()>=4)return new TrailerResolveResult(resolvedUrls,"/api/trailer multi");
            }catch(Exception e){AppLogger.mark("Trailer /api/trailer candidate failed: "+c+" :: "+e.getMessage());}
        }
        ArrayList<JSONObject> payloads=trailerPayloads(id,m);
        for(JSONObject body:payloads){
            try{
                String txt=httpPost(joinUrl(backend.baseUrl(),"/trailers/resolve"),body.toString());
                mergeTrailerUrls(resolvedUrls, sortedPlayableTrailerUrls(txt));
                TrailerResolveResult resolved=resolveTrailerCandidate(bestAnyTrailerUrl(txt),m,"/trailers/resolve embedded");
                if(resolved!=null&&!resolved.url.isEmpty())mergeTrailerUrls(resolvedUrls,resolved.urls());
                if(resolvedUrls.size()>=4)return new TrailerResolveResult(resolvedUrls,"/trailers/resolve multi");
            }catch(Exception e){AppLogger.mark("Trailer resolve payload failed: "+e.getMessage()+" body="+body.toString());}
        }
        for(JSONObject body:payloads){
            try{
                String txt=httpPost(joinUrl(backend.baseUrl(),"/trailers/extract"),body.toString());
                mergeTrailerUrls(resolvedUrls, sortedPlayableTrailerUrls(txt));
                TrailerResolveResult resolved=resolveTrailerCandidate(bestAnyTrailerUrl(txt),m,"/trailers/extract embedded");
                if(resolved!=null&&!resolved.url.isEmpty())mergeTrailerUrls(resolvedUrls,resolved.urls());
                if(resolvedUrls.size()>=4)return new TrailerResolveResult(resolvedUrls,"/trailers/extract multi");
            }catch(Exception e){AppLogger.mark("Trailer extract payload failed: "+e.getMessage()+" body="+body.toString());}
        }
        if(!resolvedUrls.isEmpty())return new TrailerResolveResult(resolvedUrls,"resolved multi-source audio fallback");
        return new TrailerResolveResult("","");
    }

    void addCandidate(ArrayList<String> list,String v){ if(v==null)return; v=v.trim(); if(v.isEmpty())return; if(!list.contains(v))list.add(v); }

    ArrayList<JSONObject> trailerPayloads(String id, Movie m){
        ArrayList<JSONObject> out=new ArrayList<>();
        String imdb=extractImdbId(m.meta);
        String mediaId=first(imdb,m.id,id,m.title);
        try{
            JSONObject o=new JSONObject();
            o.put("id",mediaId); o.put("mediaId",mediaId); o.put("imdbId",imdb); o.put("title",m.title); o.put("name",m.title);
            o.put("year",first(m.year,extractYear(m.meta))); o.put("type",isSeries(m)?"series":"movie"); o.put("mediaType",isSeries(m)?"series":"movie");
            out.add(o);
        }catch(Exception ignored){}
        try{
            JSONObject o=new JSONObject();
            String year=first(m.year,extractYear(m.meta));
            o.put("query",m.title+(year.isEmpty()?"":" "+year)); o.put("title",m.title); o.put("type",isSeries(m)?"tv":"movie"); o.put("imdb",imdb); o.put("imdbId",imdb);
            out.add(o);
        }catch(Exception ignored){}
        return out;
    }

    TrailerResolveResult resolveTrailerCandidate(String candidate, Movie m, String from){
        if(candidate==null||candidate.isEmpty())return null;
        if(isDirectPlayableTrailer(candidate))return new TrailerResolveResult(candidate,from+" direct");
        ArrayList<JSONObject> bodies=new ArrayList<>();
        try{JSONObject o=new JSONObject();o.put("url",candidate);o.put("trailerUrl",candidate);o.put("videoUrl",candidate);o.put("title",m.title);o.put("type",isSeries(m)?"series":"movie");bodies.add(o);}catch(Exception ignored){}
        try{JSONObject o=new JSONObject();o.put("id",first(extractImdbId(m.meta),m.id,m.title));o.put("mediaId",first(extractImdbId(m.meta),m.id,m.title));o.put("sourceUrl",candidate);o.put("title",m.title);bodies.add(o);}catch(Exception ignored){}
        for(JSONObject body:bodies){
            try{
                String txt=httpPost(joinUrl(backend.baseUrl(),"/trailers/resolve"),body.toString());
                String playable=bestPlayableTrailerUrl(txt);
                if(!playable.isEmpty())return new TrailerResolveResult(playable,from+" -> resolve");
            }catch(Exception e){AppLogger.mark("Trailer candidate resolve failed: "+e.getMessage());}
        }
        return null;
    }

    String bestPlayableTrailerUrl(String txt){
        ArrayList<String> urls=sortedPlayableTrailerUrls(txt);
        return urls.isEmpty()?"":urls.get(0);
    }
    String bestAnyTrailerUrl(String txt){
        ArrayList<String> urls=trailerUrlsFromJson(txt);
        return urls.isEmpty()?"":urls.get(0);
    }
    String trailerUrlFromJson(String txt){return bestAnyTrailerUrl(txt);}

    ArrayList<String> trailerUrlsFromJson(String txt){
        ArrayList<String> out=new ArrayList<>();
        if(txt==null||txt.trim().isEmpty())return out;
        String t=txt.trim();
        if(t.startsWith("http://")||t.startsWith("https://")){out.add(t);return out;}
        try{
            Object parsed=t.startsWith("[")?new JSONArray(t):new JSONObject(t);
            collectTrailerUrls(parsed,out);
        }catch(Exception e){
            java.util.regex.Matcher mm=java.util.regex.Pattern.compile("https?://[^\\s\\\"'<>]+",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(t);
            while(mm.find())addCandidate(out,mm.group());
        }
        return out;
    }

    void collectTrailerUrls(Object obj, ArrayList<String> out)throws Exception{
        if(obj==null||obj==JSONObject.NULL)return;
        if(obj instanceof JSONObject){
            JSONObject o=(JSONObject)obj;
            String[] preferred={"streamUrl","playUrl","playableUrl","resolvedUrl","resolved","download","file","mp4","hls","m3u8","url","trailerUrl","videoUrl","embedUrl","youtubeUrl","watchUrl"};
            for(String k:preferred){Object v=o.opt(k); if(v instanceof String)addCandidate(out,(String)v); else if(v instanceof JSONObject||v instanceof JSONArray)collectTrailerUrls(v,out);}
            Iterator<String> it=o.keys();
            while(it.hasNext()){String k=it.next();Object v=o.opt(k); if(v instanceof String){String ss=(String)v;if(ss.startsWith("http://")||ss.startsWith("https://"))addCandidate(out,ss);}else if(v instanceof JSONObject||v instanceof JSONArray)collectTrailerUrls(v,out);}
        }else if(obj instanceof JSONArray){
            JSONArray a=(JSONArray)obj; for(int i=0;i<a.length();i++)collectTrailerUrls(a.opt(i),out);
        }
    }

    boolean isDirectPlayableTrailer(String u){
        if(u==null)return false;
        String l=u.toLowerCase(Locale.US);
        if(!(l.startsWith("http://")||l.startsWith("https://")))return false;
        if(l.contains("youtube.com/watch")||l.contains("youtu.be/")||l.contains("youtube.com/embed")||l.contains("vimeo.com/"))return false;
        return l.contains(".m3u8")||l.contains(".mp4")||l.contains(".webm")||l.contains("googlevideo.com")||l.contains("mime=video")||l.contains("video/")||l.contains("/videoplayback");
    }

    void showTrailerOverlay(ArrayList<String> urls, boolean muted, String title){
        if(urls==null||urls.isEmpty()){Toast.makeText(this,"No playable trailer URL found",Toast.LENGTH_SHORT).show();return;}
        trailerFallbackUrls=new ArrayList<>();
        for(String u:urls) if(isDirectPlayableTrailer(u)&&!trailerFallbackUrls.contains(u)) trailerFallbackUrls.add(u);
        trailerFallbackIndex=0;
        trailerAudioFallbackInProgress=false;
        String url=trailerFallbackUrls.get(0);
        dismissTrailerOverlay();
        trailerMuted=muted;
        AppLogger.mark("DC_TRAILER_AUDIO: candidate_count="+trailerFallbackUrls.size()+" first="+url);
        trailerOverlay=new FrameLayout(this);
        trailerOverlay.setPadding(dp(12),dp(12),dp(12),dp(12));
        trailerOverlay.setBackground(stroke(Color.argb(238,6,9,15),Color.argb(150,255,255,255)));
        FrameLayout.LayoutParams op=new FrameLayout.LayoutParams(dp(520),dp(320),Gravity.RIGHT|Gravity.TOP);
        op.topMargin=dp(132);op.rightMargin=dp(46);root.addView(trailerOverlay,op);
        trailerPlayerView=new PlayerView(this);
        trailerPlayerView.setUseController(false);
        trailerPlayerView.setFocusable(false);
        trailerPlayerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        trailerOverlay.addView(trailerPlayerView,new FrameLayout.LayoutParams(-1,dp(244)));
        LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);controls.setPadding(dp(10),0,dp(8),0);
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-1,dp(62),Gravity.BOTTOM);trailerOverlay.addView(controls,cp);
        TextView label=tv("Trailer Preview",15,Typeface.BOLD);label.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);controls.addView(label,new LinearLayout.LayoutParams(0,-1,1));
        TextView mute=btn(muted?"Unmute":"Mute");TextView close=btn("Close");controls.addView(mute,new LinearLayout.LayoutParams(dp(120),dp(48)));controls.addView(close,new LinearLayout.LayoutParams(dp(110),dp(48)));
        mute.setOnClickListener(v->{trailerMuted=!trailerMuted;mute.setText(trailerMuted?"Unmute":"Mute");applyTrailerAudioState("button_toggle");});
        close.setOnClickListener(v->dismissTrailerOverlay());
        try{
            AppLogger.mark("DC_TRAILER_AUDIO: player_create requested muted="+muted+" url="+url);
            DefaultHttpDataSource.Factory httpFactory=new DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true).setUserAgent("DebridChannelsTrailer/0.4.4");
            DefaultRenderersFactory renderersFactory=new DefaultRenderersFactory(this).setEnableDecoderFallback(true);
            trailerPlayer=new ExoPlayer.Builder(this,renderersFactory).setMediaSourceFactory(new DefaultMediaSourceFactory(httpFactory)).build(); applyPlaybackQualityPreferences(trailerPlayer,"trailer_player");
            AudioAttributes trailerAttrs=new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build();
            trailerPlayer.setAudioAttributes(trailerAttrs,true);
            trailerPlayer.setRepeatMode(Player.REPEAT_MODE_OFF);
            trailerPlayer.setPlayWhenReady(true);
            applyTrailerAudioState("initial_before_attach");
            trailerPlayerView.setPlayer(trailerPlayer); applyFrameRateAndResolutionHints(trailerPlayerView,"trailer_attach");
            trailerPlayer.setMediaItem(MediaItem.fromUri(Uri.parse(url)));
            trailerPlayer.prepare();
            trailerPlayer.play();
            trailerPlayer.addListener(new Player.Listener(){
                @Override public void onPlayerError(PlaybackException error){AppLogger.mark("DC_TRAILER_AUDIO: player_error "+error.getMessage()+" url="+url);Toast.makeText(MainActivity.this,"Trailer player could not play resolved URL",Toast.LENGTH_LONG).show();}
                @Override public void onTracksChanged(Tracks tracks){
                    int audioGroups=0;
                    for(Tracks.Group g:tracks.getGroups()) if(g.getType()==C.TRACK_TYPE_AUDIO) audioGroups++;
                    AppLogger.mark("DC_TRAILER_AUDIO: tracks_changed audioGroups="+audioGroups+" volume="+(trailerPlayer==null?-1f:trailerPlayer.getVolume())+" muted="+trailerMuted);
                    if(audioGroups==0)AppLogger.mark("DC_TRAILER_AUDIO_V063: no_audio_track_detected_keep_current_video=true");
                }
                @Override public void onPlaybackStateChanged(int state){AppLogger.mark("DC_TRAILER_AUDIO: playback_state="+state+" volume="+(trailerPlayer==null?-1f:trailerPlayer.getVolume())+" muted="+trailerMuted);}
            });
            AppLogger.mark("DC_TRAILER_AUDIO: prepared playWhenReady=true volume="+trailerPlayer.getVolume());
        }catch(Exception e){AppLogger.mark("Trailer overlay failed: "+e.getMessage());Toast.makeText(this,"Trailer overlay failed",Toast.LENGTH_SHORT).show();}
        close.requestFocus();
    }


    void tryNextTrailerAudioSource(String reason){
        // v0.6.3: automatic audio-source switching caused black/blank trailer video on some resolved HLS variants.
        // Keep the working video visible; source switching should only return later as a manual debug option.
        AppLogger.mark("DC_TRAILER_AUDIO_V063: auto_fallback_disabled reason="+reason+" keep_current_video=true");
    }

    void applyTrailerAudioState(String reason){
        try{
            if(trailerPlayer==null){AppLogger.mark("DC_TRAILER_AUDIO: apply skipped no_player reason="+reason);return;}
            float volume=trailerMuted?0f:1f;
            trailerPlayer.setVolume(volume);
            trailerPlayer.setDeviceMuted(false);
            AppLogger.mark("DC_TRAILER_AUDIO: apply reason="+reason+" muted="+trailerMuted+" volume="+volume+" deviceMuted=false");
        }catch(Exception e){AppLogger.mark("DC_TRAILER_AUDIO: apply_failed reason="+reason+" error="+e.getMessage());}
    }

    void dismissTrailerOverlay(){
        try{if(trailerVideo!=null){trailerVideo.stopPlayback();trailerVideo=null;}}catch(Exception ignored){}
        try{if(trailerPlayerView!=null)trailerPlayerView.setPlayer(null);}catch(Exception ignored){}
        try{if(trailerPlayer!=null){trailerPlayer.stop();trailerPlayer.release();trailerPlayer=null;}}catch(Exception ignored){}
        trailerPlayerView=null;
        try{if(trailerOverlay!=null&&trailerOverlay.getParent()!=null)((ViewGroup)trailerOverlay.getParent()).removeView(trailerOverlay);}catch(Exception ignored){}
        trailerOverlay=null;
    }

    void showShowDetails(Movie m){suppressRowAutoFocus=false;lockRatings(m);selectedMedia=new SelectedMedia(m);clear();backdrop();addMenu();updateHero(m);LinearLayout p=form("Episodes • "+m.title);TextView top=tv(first(m.overview,"Browse seasons and episodes, then select an episode to load streams."),17,Typeface.NORMAL);top.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);top.setPadding(dp(8),0,dp(8),0);p.addView(top,new LinearLayout.LayoutParams(-1,dp(68)));LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);p.addView(actions,new LinearLayout.LayoutParams(-1,dp(70)));TextView trailer=btn("🎬 Play Trailer");TextView back=btn("Back");actions.addView(trailer,new LinearLayout.LayoutParams(dp(220),dp(56)));LinearLayout.LayoutParams bap=new LinearLayout.LayoutParams(dp(150),dp(56));bap.setMargins(dp(14),0,0,0);actions.addView(back,bap);trailer.setOnClickListener(v->playTrailerFor(m,true));back.setOnClickListener(v->showMovieDetails(m));TextView loading=tv("Loading seasons from backend / Stremio metadata…",18,Typeface.BOLD);loading.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);p.addView(loading,new LinearLayout.LayoutParams(-1,dp(60)));new Thread(()->{ArrayList<Episode> eps=loadEpisodesForShow(m);runOnUiThread(()->renderEpisodes(m,eps));}).start();scheduleTrailerPopup(m);}
    ArrayList<Episode> loadEpisodesForShow(Movie m){ArrayList<Episode> eps=new ArrayList<>();String id=seriesId(m);String safe="";try{safe=URLEncoder.encode(id,"UTF-8").replace("+","%20");}catch(Exception ignored){}String[] paths=new String[]{"/api/show/"+safe,"/api/series/"+safe,"/meta/series/"+safe+".json"};for(String path:paths){try{String txt=httpGet(joinUrl(backend.baseUrl(),path));parseEpisodesFromJson(txt,eps);if(!eps.isEmpty())return eps;}catch(Exception e){AppLogger.mark("Episode endpoint skipped "+path+": "+e.getMessage());}}try{String txt=httpGet("https://v3-cinemeta.strem.io/meta/series/"+safe+".json");parseEpisodesFromJson(txt,eps);if(!eps.isEmpty())return eps;}catch(Exception e){AppLogger.mark("Cinemeta episode metadata skipped: "+e.getMessage());}for(int s=1;s<=3;s++)for(int e=1;e<=8;e++){Episode ep=new Episode(s,e,"Episode "+e);ep.id=id+":"+s+":"+e;ep.overview="Select this episode to resolve stream links using the existing playback pipeline.";eps.add(ep);}return eps;}
    void parseEpisodesFromJson(String txt, ArrayList<Episode> eps)throws Exception{JSONObject root=new JSONObject(txt);JSONObject meta=root.optJSONObject("meta");if(meta==null)meta=root;JSONArray arr=firstArray(meta,"videos","episodes");if(arr==null)arr=firstArray(root,"videos","episodes");if(arr==null)return;for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i);if(o==null)continue;int ss=Math.max(1,o.optInt("season",o.optInt("seasonNumber",1)));int ee=Math.max(1,o.optInt("episode",o.optInt("episodeNumber",i+1)));Episode ep=new Episode(ss,ee,o.optString("title",o.optString("name","Episode "+ee)));ep.id=first(o.optString("id",""),o.optString("imdb_id",""));if(ep.id.isEmpty())ep.id=first(o.optString("streamId",""),seriesIdFromVideo(o));ep.overview=o.optString("overview",o.optString("description",o.optString("summary","")));ep.thumbnail=abs(first(o.optString("thumbnail",""),o.optString("thumb",""),o.optString("poster",""),o.optString("image","")));ep.airDate=o.optString("released",o.optString("airDate",""));ep.runtime=o.optInt("runtime",0);eps.add(ep);}}
    JSONArray firstArray(JSONObject o,String...keys){if(o==null)return null;for(String k:keys){JSONArray a=o.optJSONArray(k);if(a!=null)return a;}return null;}
    String seriesIdFromVideo(JSONObject o){return first(o.optString("id",""),o.optString("streamId",""));}
    void renderEpisodes(Movie show, ArrayList<Episode> eps){clear();backdrop();addMenu();updateHero(show);LinearLayout p=form("Episodes • "+show.title);TreeMap<Integer,ArrayList<Episode>> bySeason=new TreeMap<>();for(Episode e:eps){ArrayList<Episode> list=bySeason.get(e.season);if(list==null){list=new ArrayList<>();bySeason.put(e.season,list);}list.add(e);}if(bySeason.isEmpty()){TextView none=tv("No episodes found.",20,Typeface.BOLD);p.addView(none,new LinearLayout.LayoutParams(-1,dp(70)));none.requestFocus();return;}HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);LinearLayout seasons=new LinearLayout(this);seasons.setOrientation(LinearLayout.HORIZONTAL);hsv.addView(seasons,new HorizontalScrollView.LayoutParams(-2,dp(66)));p.addView(hsv,new LinearLayout.LayoutParams(-1,dp(72)));LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);p.addView(list,new LinearLayout.LayoutParams(-1,-2));final int[] selected={bySeason.firstKey()};Runnable[] draw=new Runnable[1];draw[0]=()->{list.removeAllViews();ArrayList<Episode> current=bySeason.get(selected[0]);TextView head=tv("Season "+selected[0],24,Typeface.BOLD);head.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);list.addView(head,new LinearLayout.LayoutParams(-1,dp(58)));for(Episode ep:current){TextView row=episodeButton(ep);row.setOnClickListener(v->showEpisodeStreams(show,ep));list.addView(row,new LinearLayout.LayoutParams(-1,dp(92)));}if(list.getChildCount()>1)list.getChildAt(1).requestFocus();};for(Integer season:bySeason.keySet()){TextView b=btn("Season "+season);b.setOnClickListener(v->{selected[0]=season;draw[0].run();});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(170),dp(58));lp.setMargins(0,0,dp(12),0);seasons.addView(b,lp);}draw[0].run();}
    TextView episodeButton(Episode ep){String sub=first(ep.overview,ep.airDate,"Episode metadata");if(sub.length()>135)sub=sub.substring(0,132)+"…";TextView b=btn("  ▶  "+ep.label()+"\n     "+sub);b.setTextSize(17);b.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);b.setPadding(dp(18),0,dp(18),0);b.setBackground(stroke(Color.argb(130,12,18,30),Color.argb(70,255,255,255)));return b;}
    void showEpisodeStreams(Movie show, Episode ep){Movie episodeMovie=new Movie(show.title+" • "+ep.label(),show.meta,show.url);episodeMovie.id=first(ep.id,seriesId(show)+":"+ep.season+":"+ep.episode);episodeMovie.type="series";episodeMovie.poster=first(ep.thumbnail,show.poster);episodeMovie.background=first(show.background,episodeMovie.poster);episodeMovie.logo=show.logo;episodeMovie.banner=show.banner;episodeMovie.overview=first(ep.overview,show.overview);showStreamList(episodeMovie);}

    void buildRatingRowInto(LinearLayout row, Movie m, boolean includeTag){
        row.removeAllViews(); String y=first(m.year,extractYear(m.meta));
        if(!y.isEmpty())addMetaPiece(row,metaText(y,Color.rgb(255,220,56),Typeface.BOLD),-2,30,0);
        if(includeTag){addMetaPiece(row,metaText("•",Color.WHITE,Typeface.BOLD),-2,30,12);addMetaPiece(row,metaText(first(m.tag,"FEATURED").toUpperCase(Locale.US),Color.WHITE,Typeface.BOLD),-2,30,12);}
        String imdb=first(m.imdbRating,extractRating(m.meta,"IMDB"),extractRating(m.meta,"IMDb"));
        if(!imdb.isEmpty()){addMetaPiece(row,badge("IMDb",Color.rgb(245,197,24),Color.BLACK),58,24,20);addMetaPiece(row,metaText(imdb,Color.WHITE,Typeface.NORMAL),-2,30,8);}
        String tmdb=first(m.tmdbRating,extractRating(m.meta,"TMDB"));
        if(!tmdb.isEmpty()){addMetaPiece(row,metaText("|",Color.argb(210,255,255,255),Typeface.NORMAL),-2,30,14);addMetaPiece(row,badge("TMDB",Color.rgb(1,180,228),Color.WHITE),62,24,14);addMetaPiece(row,metaText(tmdb,Color.WHITE,Typeface.NORMAL),-2,30,8);}
    }

    void showStreamList(Movie m){
        lockRatings(m); selectedMedia = new SelectedMedia(m); clear();backdrop();addMenu();updateHero(m);
        LinearLayout p=form("Select stream"); TextView sub=tv("Loading Stremio addon links for " + m.title + "…",18,Typeface.NORMAL);sub.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);p.addView(sub,new LinearLayout.LayoutParams(-1,dp(54)));
        new Thread(()->{ArrayList<StreamLink> links=loadStremioStreams(m);runOnUiThread(()->renderStreamList(m,links));}).start();
    }

    void renderStreamList(Movie m, ArrayList<StreamLink> links){
        lockRatings(m); selectedMedia = new SelectedMedia(m); selectedMedia.streams.addAll(links); clear();backdrop();addMenu();updateHero(m);
        LinearLayout p=form("Select stream"); LinearLayout head=new LinearLayout(this);head.setOrientation(LinearLayout.VERTICAL);head.setPadding(0,0,0,dp(8));p.addView(head,new LinearLayout.LayoutParams(-1,dp(112)));
        TextView title=tv(m.title,28,Typeface.BOLD);title.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);head.addView(title,new LinearLayout.LayoutParams(-1,dp(48)));
        LinearLayout ratingLine=new LinearLayout(this);ratingLine.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);head.addView(ratingLine,new LinearLayout.LayoutParams(-1,dp(38)));buildRatingRowInto(ratingLine,m,true);
        if(links.isEmpty()){TextView none=tv("No playable streams found. Make sure the Stremio addon provides stream links, not just catalogs.",20,Typeface.BOLD);none.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);none.setPadding(dp(18),0,dp(18),0);none.setBackground(bg(Color.argb(130,70,24,24),18));p.addView(none,new LinearLayout.LayoutParams(dp(980),dp(86)));none.requestFocus();return;}
        for(StreamLink link:links){TextView row=streamButton(link);row.setOnClickListener(v->showMedia3Player(m,link));p.addView(row,new LinearLayout.LayoutParams(dp(1040),dp(78)));}
        if(p.getChildCount()>2)p.getChildAt(2).requestFocus();
    }

    TextView streamButton(StreamLink l){
        String label="  ▶  "+first(l.name,l.title,"Stream"); if(l.needsResolver())label+="    [Resolver]"; else if(l.external)label+="    [Try Direct]"; if(!l.quality.isEmpty())label+="    ["+l.quality+"]"; if(!l.size.isEmpty())label+="    "+l.size; if(!l.source.isEmpty())label+="    • "+l.source;
        String second=first(l.description,l.url); if(second.length()>120)second=second.substring(0,117)+"…";
        TextView b=btn(label+"\n     "+second);b.setTextSize(17);b.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);b.setPadding(dp(18),0,dp(18),0);b.setBackground(stroke(Color.argb(140,12,18,30),Color.argb(72,255,255,255)));return b;
    }

    ArrayList<StreamLink> loadStremioStreams(Movie m){
        ArrayList<StreamLink> out=new ArrayList<>();
        ArrayList<String> addonUrls=stremio.getManifestUrls();
        if(addonUrls.isEmpty())return out;
        for(String raw:addonUrls){
            String manifest=raw.trim();
            if(manifest.isEmpty()||!manifest.startsWith("http"))continue;
            try{
                String base=manifest;
                int ix=base.indexOf("/manifest.json");
                if(ix>=0)base=base.substring(0,ix);
                while(base.endsWith("/"))base=base.substring(0,base.length()-1);
                String type=first(m.type,"movie").toLowerCase(Locale.US);
                if(type.equals("show")||type.equals("tv"))type="series";
                if(!type.equals("series"))type="movie";
                String id=first(m.id,extractImdbId(m.meta));
                if(id.isEmpty())continue;
                String endpoint=base+"/stream/"+type+"/"+URLEncoder.encode(id,"UTF-8").replace("+","%20")+".json";
                String txt=httpGet(endpoint);
                JSONObject obj=new JSONObject(txt);
                JSONArray arr=obj.optJSONArray("streams");
                if(arr==null)continue;
                for(int i=0;i<arr.length();i++){
                    JSONObject so=arr.optJSONObject(i); if(so==null)continue;
                    JSONObject hints=so.optJSONObject("behaviorHints");
                    String name=first(so.optString("name",""),so.optString("title",""),"Stream");
                    String desc=first(so.optString("description",""),so.optString("title",""),name);
                    String text=(name+" "+desc+" "+so.optString("title","")).trim();
                    String url=so.optString("url","").trim();
                    boolean external=false;
                    String ext=so.optString("externalUrl","").trim();
                    String infoHash=so.optString("infoHash","").trim();
                    if(infoHash.isEmpty() && hints!=null) infoHash=hints.optString("infoHash","").trim();
                    String magnet="";
                    if(ext.startsWith("magnet:")) magnet=ext;
                    else if(hints!=null && hints.optString("magnet","").startsWith("magnet:")) magnet=hints.optString("magnet","");
                    else if(!infoHash.isEmpty()) magnet="magnet:?xt=urn:btih:"+infoHash;
                    if(url.isEmpty()){
                        url=ext;
                        external=!url.isEmpty();
                    }
                    if(url.isEmpty() && !magnet.isEmpty()) url=magnet;
                    if(url.isEmpty() && infoHash.isEmpty() && magnet.isEmpty()) continue;
                    StreamLink sl=new StreamLink();
                    sl.url=url; sl.magnet=magnet; sl.infoHash=infoHash; sl.external=external || looksLikeExternalPage(url);
                    sl.name=name; sl.title=so.optString("title",""); sl.description=desc; sl.source=stremio.addonNameFor(manifest);
                    sl.quality=inferQuality(text+" "+url); sl.size=inferSize(text); sl.sizeBytes=parseSizeBytes(text); sl.qualityScore=scoreQuality(text);
                    sl.dolbyVision=looksDolbyVision(text); sl.hdr10Plus=looksHdr10Plus(text); sl.hdr=sl.dolbyVision||sl.hdr10Plus||looksHdr(text);
                    if(so.has("fileIdx")) sl.fileIdx=so.optInt("fileIdx",-1); else if(hints!=null&&hints.has("fileIdx"))sl.fileIdx=hints.optInt("fileIdx",-1);
                    out.add(sl);
                }
            }catch(Exception e){AppLogger.mark("Stremio stream load failed: "+e.getMessage()+" manifest="+manifest);}
        }
        Collections.sort(out,(a,b)->Integer.compare(b.qualityScore,a.qualityScore));
        return out;
    }

    String extractImdbId(String meta){if(meta==null)return "";java.util.regex.Matcher m=java.util.regex.Pattern.compile("tt\\d+").matcher(meta);return m.find()?m.group():"";}
    String inferQuality(String s){String u=s==null?"":s.toUpperCase(Locale.US);if(u.contains("2160")||u.contains("4K")||u.contains("UHD"))return "4K";if(u.contains("1080"))return "1080p";if(u.contains("720"))return "720p";if(u.contains("HDR10+"))return "HDR10+";if(u.contains("HDR"))return "HDR";return "";}
    String inferSize(String s){if(s==null)return "";java.util.regex.Matcher m=java.util.regex.Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(GB|GIB|MB|MIB)",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(s);return m.find()?m.group(1)+" "+m.group(2).toUpperCase(Locale.US).replace("GIB","GB").replace("MIB","MB"):"";}
    long parseSizeBytes(String text){try{java.util.regex.Matcher m=java.util.regex.Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(GB|GIB|MB|MIB)",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(text==null?"":text);if(!m.find())return 0;double v=Double.parseDouble(m.group(1));String unit=m.group(2).toLowerCase(Locale.US);return (long)(v*(unit.startsWith("g")?1024d*1024d*1024d:1024d*1024d));}catch(Exception e){return 0;}}
    int scoreQuality(String text){String u=text==null?"":text.toLowerCase(Locale.US);int q=(u.contains("2160")||u.contains("4k")||u.contains("uhd"))?400:(u.contains("1080")?300:(u.contains("720")?200:100));if(u.contains("remux"))q+=40;else if(u.contains("bluray")||u.contains("blu-ray"))q+=30;else if(u.contains("web-dl")||u.contains("webdl")||u.contains("webrip"))q+=20;return q;}
    boolean looksDolbyVision(String text){String u=(text==null?"":text).toLowerCase(Locale.US);return u.contains("dolby vision")||u.contains("dovi")||u.contains(" dv ")||u.contains(".dv.")||u.contains("-dv-");}
    boolean looksHdr10Plus(String text){String u=(text==null?"":text).toLowerCase(Locale.US);return u.contains("hdr10+")||u.contains("hdr10plus")||u.contains("hdr 10+");}
    boolean looksHdr(String text){String u=(text==null?"":text).toLowerCase(Locale.US);return u.contains("hdr")||u.contains("hlg")||u.contains("bt2020")||u.contains("bt.2020");}
    boolean isLikelyVideoFile(String path){String u=(path==null?"":path).toLowerCase(Locale.US);return u.contains(".mkv")||u.contains(".mp4")||u.contains(".avi")||u.contains(".ts")||u.contains(".m2ts")||u.contains(".mov")||u.contains(".wmv");}
    String hostLabel(String url){try{return new URL(url).getHost().replace("www.","");}catch(Exception e){return "Stremio";}}
    boolean looksLikeExternalPage(String url){if(url==null||url.isEmpty())return false;String u=url.toLowerCase(Locale.US);if(u.startsWith("magnet:"))return false;if(!(u.startsWith("http://")||u.startsWith("https://")))return true;if(u.contains("youtube.com")||u.contains("youtu.be")||u.contains("imdb.com")||u.contains("stremio.com"))return true;return false;}

    String resolverMode(){ return backend.playbackResolverMode(); }
    ArrayList<String> resolverOrder(){ArrayList<String> order=new ArrayList<>();String mode=resolverMode();if(mode.equals("realdebrid")){order.add("realdebrid");order.add("direct");}else if(mode.equals("torbox")){order.add("torbox");order.add("direct");}else if(mode.equals("auto")){order.add("realdebrid");order.add("torbox");order.add("direct");}else{order.add("direct");order.add("realdebrid");order.add("torbox");}return order;}
    String resolvePlayableUrl(StreamLink link){if(link==null)return "";String url=link.url==null?"":link.url.trim();for(String provider:resolverOrder()){String resolved="";if(provider.equals("direct"))resolved=resolveDirect(link);else if(provider.equals("realdebrid"))resolved=resolveWithRealDebrid(link);else if(provider.equals("torbox"))resolved=resolveWithTorbox(link);if(resolved!=null&&!resolved.isEmpty()){AppLogger.mark("STREAM_RESOLVE provider="+provider+" host="+hostLabel(resolved));return resolved;}}if(url.startsWith("http://")||url.startsWith("https://"))return url;return "";}
    String resolveDirect(StreamLink link){String url=link.url==null?"":link.url.trim();return (url.startsWith("http://")||url.startsWith("https://"))?url:"";}
    String resolveWithRealDebrid(StreamLink link){String api=backend.realDebridApiKey();if(api==null||api.trim().isEmpty())return "";String direct=resolveDirect(link);if(!direct.isEmpty()&&!link.hasResolverPayload())return realDebridUnrestrict(api,direct);if(!direct.isEmpty()&&!direct.startsWith("magnet:")){String u=realDebridUnrestrict(api,direct);if(!u.isEmpty())return u;}String magnet=first(link.magnet,link.infoHash==null||link.infoHash.isEmpty()?"":"magnet:?xt=urn:btih:"+link.infoHash,link.url!=null&&link.url.startsWith("magnet:")?link.url:"");if(magnet.isEmpty())return "";String torrentId=realDebridAddMagnet(api,magnet);if(torrentId.isEmpty())return "";JSONObject before=realDebridTorrentInfo(api,torrentId);String files=chooseRealDebridFiles(before,link.fileIdx);if(!realDebridSelectFiles(api,torrentId,files))return "";for(int attempt=0;attempt<6;attempt++){try{Thread.sleep(attempt==0?1200:2000);}catch(Exception ignored){}JSONObject info=realDebridTorrentInfo(api,torrentId);if(info==null)continue;JSONArray links=info.optJSONArray("links");if(links==null)continue;for(int i=0;i<links.length();i++){String l=links.optString(i,"");if(l.startsWith("http")){String unr=realDebridUnrestrict(api,l);if(!unr.isEmpty())return unr;}}}return "";}
    String chooseRealDebridFiles(JSONObject info,int desired){if(info==null)return "all";JSONArray files=info.optJSONArray("files");if(files==null||files.length()==0)return "all";if(desired>=0&&desired<files.length()){JSONObject f=files.optJSONObject(desired);int id=f==null?0:f.optInt("id",0);if(id>0)return String.valueOf(id);}for(int i=0;i<files.length();i++){JSONObject f=files.optJSONObject(i);if(f!=null&&isLikelyVideoFile(f.optString("path"))){int id=f.optInt("id",0);if(id>0)return String.valueOf(id);}}return "all";}
    String realDebridAddMagnet(String api,String magnet){JSONObject j=httpFormJsonObj("https://api.real-debrid.com/rest/1.0/torrents/addMagnet","POST",mapAuth(api),linkedForm("magnet",magnet));return j==null?"":j.optString("id","");}
    boolean realDebridSelectFiles(String api,String torrentId,String files){HttpURLConnection c=null;try{c=openFormConnection("https://api.real-debrid.com/rest/1.0/torrents/selectFiles/"+torrentId,"POST",mapAuth(api),linkedForm("files",files));int code=c.getResponseCode();return code>=200&&code<300||code==202;}catch(Exception e){AppLogger.mark("RD select files failed: "+e.getMessage());return false;}finally{if(c!=null)c.disconnect();}}
    JSONObject realDebridTorrentInfo(String api,String torrentId){return httpGetJsonObj("https://api.real-debrid.com/rest/1.0/torrents/info/"+torrentId,mapAuth(api));}
    String realDebridUnrestrict(String api,String link){JSONObject j=httpFormJsonObj("https://api.real-debrid.com/rest/1.0/unrestrict/link","POST",mapAuth(api),linkedForm("link",link));if(j==null)return "";return first(j.optString("download",""),j.optString("link",""));}
    String resolveWithTorbox(StreamLink link){String api=backend.torboxApiKey();if(api==null||api.trim().isEmpty())return "";String direct=resolveDirect(link);if(!direct.isEmpty()&&!link.hasResolverPayload())return direct;String magnet=first(link.magnet,link.infoHash==null||link.infoHash.isEmpty()?"":"magnet:?xt=urn:btih:"+link.infoHash,link.url!=null&&link.url.startsWith("magnet:")?link.url:"");if(magnet.isEmpty())return direct;int tid=torboxCreateTorrent(api,magnet);if(tid<=0)return direct;for(int a=0;a<6;a++){try{Thread.sleep(a==0?1200:2000);}catch(Exception ignored){}JSONObject info=torboxTorrentInfo(api,tid);if(info==null)continue;int fileId=chooseTorboxFileId(info,link.fileIdx);String dl=torboxRequestDl(api,tid,fileId);if(!dl.isEmpty())return dl;}return direct;}
    int torboxCreateTorrent(String api,String magnet){JSONObject j=httpFormJsonObj("https://api.torbox.app/v1/api/torrents/createtorrent","POST",mapAuth(api),linkedForm("magnet",magnet,"seed","1","allow_zip","true","as_queued","false"));if(j==null)return 0;JSONObject d=j.optJSONObject("data");return d!=null?Math.max(d.optInt("torrent_id",0),d.optInt("id",0)):Math.max(j.optInt("torrent_id",0),j.optInt("id",0));}
    JSONObject torboxTorrentInfo(String api,int tid){JSONObject j=httpGetJsonObj("https://api.torbox.app/v1/api/torrents/mylist?id="+tid+"&bypass_cache=true",mapAuth(api));if(j==null)return null;Object d=j.opt("data");if(d instanceof JSONObject)return (JSONObject)d;if(d instanceof JSONArray)return ((JSONArray)d).optJSONObject(0);return null;}
    int chooseTorboxFileId(JSONObject info,int desired){JSONArray[] arrays=new JSONArray[]{info.optJSONArray("files"),info.optJSONArray("download_files"),info.optJSONArray("file_list")};for(JSONArray files:arrays){if(files==null)continue;if(desired>=0&&desired<files.length()){JSONObject f=files.optJSONObject(desired);int id=f==null?0:Math.max(f.optInt("id",0),f.optInt("file_id",0));if(id>0)return id;}for(int i=0;i<files.length();i++){JSONObject f=files.optJSONObject(i);if(f!=null&&isLikelyVideoFile(first(f.optString("short_name",""),f.optString("name",""),f.optString("path","")))){int id=Math.max(f.optInt("id",0),f.optInt("file_id",0));if(id>0)return id;}}}return 0;}
    String torboxRequestDl(String api,int tid,int fileId){try{String suffix="token="+URLEncoder.encode(api,"UTF-8")+"&torrent_id="+tid+"&file_id="+fileId+"&zip_link=false&redirect=false";JSONObject j=httpGetJsonObj("https://api.torbox.app/v1/api/torrents/requestdl?"+suffix,new HashMap<String,String>());if(j==null)return "";Object d=j.opt("data");if(d instanceof String)return (String)d;if(d instanceof JSONObject){JSONObject o=(JSONObject)d;return first(o.optString("download",""),o.optString("url",""),o.optString("link",""));}}catch(Exception e){AppLogger.mark("Torbox requestdl failed: "+e.getMessage());}return "";}
    Map<String,String> mapAuth(String api){HashMap<String,String> h=new HashMap<>();h.put("Authorization","Bearer "+api);return h;}
    LinkedHashMap<String,String> linkedForm(String...kv){LinkedHashMap<String,String> m=new LinkedHashMap<>();for(int i=0;i+1<kv.length;i+=2)m.put(kv[i],kv[i+1]);return m;}
    JSONObject httpGetJsonObj(String url,Map<String,String> headers){HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod("GET");c.setConnectTimeout(12000);c.setReadTimeout(20000);c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","ChannelsDebridTV/0.1.9");for(Map.Entry<String,String> e:headers.entrySet())c.setRequestProperty(e.getKey(),e.getValue());String body=readHttpBody(c);if(c.getResponseCode()<200||c.getResponseCode()>=300||body.isEmpty())return null;return new JSONObject(body);}catch(Exception e){AppLogger.mark("HTTP JSON get failed: "+e.getMessage()+" url="+url);return null;}finally{if(c!=null)c.disconnect();}}
    JSONObject httpFormJsonObj(String url,String method,Map<String,String> headers,LinkedHashMap<String,String> form){HttpURLConnection c=null;try{c=openFormConnection(url,method,headers,form);String body=readHttpBody(c);if(c.getResponseCode()<200||c.getResponseCode()>=300||body.isEmpty())return null;return new JSONObject(body);}catch(Exception e){AppLogger.mark("HTTP form failed: "+e.getMessage()+" url="+url);return null;}finally{if(c!=null)c.disconnect();}}
    HttpURLConnection openFormConnection(String url,String method,Map<String,String> headers,LinkedHashMap<String,String> form)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod(method);c.setDoOutput(true);c.setConnectTimeout(12000);c.setReadTimeout(30000);c.setRequestProperty("Accept","application/json");c.setRequestProperty("Content-Type","application/x-www-form-urlencoded");c.setRequestProperty("User-Agent","ChannelsDebridTV/0.1.9");for(Map.Entry<String,String> e:headers.entrySet())c.setRequestProperty(e.getKey(),e.getValue());StringBuilder body=new StringBuilder();for(Map.Entry<String,String> e:form.entrySet()){if(body.length()>0)body.append('&');body.append(URLEncoder.encode(e.getKey(),"UTF-8")).append('=').append(URLEncoder.encode(e.getValue(),"UTF-8"));}try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes("UTF-8"));}return c;}
    String readHttpBody(HttpURLConnection c)throws Exception{InputStream in=(c.getResponseCode()>=200&&c.getResponseCode()<300)?c.getInputStream():c.getErrorStream();if(in==null)return "";try(InputStream stream=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n;while((n=stream.read(buf))>0)out.write(buf,0,n);return out.toString("UTF-8");}}
    String inferMime(String url){String u=url==null?"":url.substring(0, url.indexOf('?')>=0?url.indexOf('?'):url.length()).toLowerCase(Locale.US);if(u.endsWith(".m3u8")||u.contains("m3u8"))return MimeTypes.APPLICATION_M3U8;if(u.endsWith(".mpd"))return MimeTypes.APPLICATION_MPD;if(u.endsWith(".ts")||u.contains("/auto/v"))return MimeTypes.VIDEO_MP2T;if(u.endsWith(".mp4"))return MimeTypes.VIDEO_MP4;return null;}

    void showMedia3Player(Movie m, StreamLink link){
        lockRatings(m);
        if(selectedMedia==null) selectedMedia = new SelectedMedia(m);
        clear();backdrop();addMenu();updateHero(m);
        LinearLayout p=form("Resolving stream");
        TextView msg=tv("Resolving source through Stremio / Real-Debrid / Torbox…",20,Typeface.BOLD);
        msg.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);msg.setPadding(dp(18),0,dp(18),0);
        msg.setBackground(bg(Color.argb(150,12,18,30),18));
        p.addView(msg,new LinearLayout.LayoutParams(dp(1060),dp(78)));msg.requestFocus();
        new Thread(()->{String playUrl=resolvePlayableUrl(link);runOnUiThread(()->{if(playUrl==null||playUrl.isEmpty()){Toast.makeText(this,"This stream needs a resolver or could not be resolved.",Toast.LENGTH_LONG).show();renderPlaybackErrorStreamList(m, link, "RESOLVE_FAILED");return;}startResolvedMedia3Player(m, link, playUrl);});}).start();
    }

    void startResolvedMedia3Player(Movie m, StreamLink link, String playUrl){
        lockRatings(m); clear();
        if(exoPlayer!=null){try{exoPlayer.release();}catch(Exception ignored){} exoPlayer=null;}
        PlayerView pv=new PlayerView(this);pv.setUseController(false);pv.setFocusable(false);pv.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);activePlayerView=pv;activeZoomMode=0;root.addView(pv,new FrameLayout.LayoutParams(-1,-1));
        TextView loading=tv("Loading stream…",22,Typeface.BOLD);loading.setGravity(Gravity.CENTER);loading.setBackgroundColor(Color.argb(110,0,0,0));root.addView(loading,new FrameLayout.LayoutParams(-1,-1));
        try{
            DefaultHttpDataSource.Factory httpFactory=new DefaultHttpDataSource.Factory().setUserAgent("DebridChannelsTV/0.1.9").setAllowCrossProtocolRedirects(true).setConnectTimeoutMs(10000).setReadTimeoutMs(15000);
            DefaultLoadControl loadControl=new DefaultLoadControl.Builder().setBufferDurationsMs(5000,30000,1000,2500).setBackBuffer(0,true).setPrioritizeTimeOverSizeThresholds(true).build();
            DefaultRenderersFactory renderersFactory=new DefaultRenderersFactory(this).setEnableDecoderFallback(true).setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER);
            exoPlayer=new ExoPlayer.Builder(this,renderersFactory).setMediaSourceFactory(new DefaultMediaSourceFactory(httpFactory)).setLoadControl(loadControl).setSeekBackIncrementMs(10000).setSeekForwardIncrementMs(10000).build(); applyPlaybackQualityPreferences(exoPlayer,"vod_player");
            pv.setPlayer(exoPlayer);
            exoPlayer.addListener(new Player.Listener(){
                @Override public void onPlaybackStateChanged(int state){AppLogger.mark("Media3 state="+state+" url="+playUrl);if(state==Player.STATE_READY){loading.setVisibility(View.GONE);}else if(state==Player.STATE_BUFFERING){loading.setText("Buffering stream…");loading.setVisibility(View.VISIBLE);}else if(state==Player.STATE_ENDED){loading.setText("Playback ended");loading.setVisibility(View.VISIBLE);}}
                @Override public void onPlayerError(PlaybackException error){AppLogger.mark("Media3 playback error: "+error.getErrorCodeName()+" "+error.getMessage()+" url="+playUrl);Toast.makeText(MainActivity.this,"Playback failed: "+error.getErrorCodeName(),Toast.LENGTH_LONG).show();try{if(exoPlayer!=null){exoPlayer.release();exoPlayer=null;}}catch(Exception ignored){}renderPlaybackErrorStreamList(m, link, error.getErrorCodeName());}
            });
            MediaItem.Builder item=new MediaItem.Builder().setUri(Uri.parse(playUrl));String mime=inferMime(playUrl);if(mime!=null)item.setMimeType(mime);exoPlayer.setMediaItem(item.build(),true);exoPlayer.prepare();exoPlayer.setPlayWhenReady(true);exoPlayer.play();
        }catch(Exception e){AppLogger.mark("Media3 start failed: "+e.getMessage());Toast.makeText(this,"Playback failed: "+e.getMessage(),Toast.LENGTH_LONG).show();renderPlaybackErrorStreamList(m, link, "START_FAILED");return;}
        buildCinematicPlayerOverlay(m,link);
        startPlayerProgressUpdates();
    }

    void renderPlaybackErrorStreamList(Movie m, StreamLink failed, String code){
        clear();backdrop();addMenu();updateHero(m);
        LinearLayout p=form("Select stream");
        TextView warn=tv("Playback failed: "+code+". Try another stream, or use Real-Debrid/Torbox resolver mode for protected links.",18,Typeface.BOLD);
        warn.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);warn.setPadding(dp(18),0,dp(18),0);warn.setBackground(bg(Color.argb(160,90,28,20),18));
        p.addView(warn,new LinearLayout.LayoutParams(dp(1060),dp(76)));
        ArrayList<StreamLink> links = selectedMedia!=null ? selectedMedia.streams : new ArrayList<>();
        if(links.isEmpty() && failed!=null)links.add(failed);
        for(StreamLink sl:links){TextView row=streamButton(sl);row.setOnClickListener(v->showMedia3Player(m,sl));p.addView(row,new LinearLayout.LayoutParams(dp(1040),dp(78)));}
        if(p.getChildCount()>1)p.getChildAt(1).requestFocus(); else warn.requestFocus();
    }

    void buildCinematicPlayerOverlay(Movie m, StreamLink link){
        FrameLayout overlay=new FrameLayout(this);overlay.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,new int[]{Color.argb(235,0,0,0),Color.argb(110,0,0,0),Color.TRANSPARENT}));root.addView(overlay,new FrameLayout.LayoutParams(-1,-1));
        overlay.setFocusable(true); overlay.setFocusableInTouchMode(true);
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.HORIZONTAL);info.setGravity(Gravity.BOTTOM|Gravity.LEFT);info.setPadding(dp(46),0,dp(46),dp(98));overlay.addView(info,new FrameLayout.LayoutParams(-1,-1));
        CardFrame posterFrame=new CardFrame(this,dp(16));posterFrame.setBackground(cardBg(230));ImageView poster=new ImageView(this);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);posterFrame.addView(poster,new FrameLayout.LayoutParams(-1,-1));String posterUrl=first(m.poster,m.background);if(!posterUrl.isEmpty())loadImage(posterUrl,poster,false);LinearLayout.LayoutParams plp=new LinearLayout.LayoutParams(dp(160),dp(238));plp.setMargins(0,0,dp(26),0);info.addView(posterFrame,plp);
        LinearLayout text=new LinearLayout(this);text.setOrientation(LinearLayout.VERTICAL);text.setGravity(Gravity.BOTTOM|Gravity.LEFT);info.addView(text,new LinearLayout.LayoutParams(0,dp(260),1));
        ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);String lg=cardLogoArtwork(m);if(isSafeCardLogo(lg)){text.addView(logo,new LinearLayout.LayoutParams(dp(430),dp(78)));loadImage(lg,logo,false);}else{TextView title=tv(m.title,34,Typeface.BOLD);title.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);text.addView(title,new LinearLayout.LayoutParams(-1,dp(70)));}
        LinearLayout ratingLine=new LinearLayout(this);ratingLine.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);text.addView(ratingLine,new LinearLayout.LayoutParams(-1,dp(36)));buildRatingRowInto(ratingLine,m,true);
        TextView desc=tv(first(m.overview,link.description),16,Typeface.NORMAL);desc.setGravity(Gravity.LEFT|Gravity.TOP);desc.setAlpha(.9f);text.addView(desc,new LinearLayout.LayoutParams(dp(760),dp(76)));
        LinearLayout progressWrap=new LinearLayout(this);progressWrap.setOrientation(LinearLayout.HORIZONTAL);progressWrap.setGravity(Gravity.CENTER_VERTICAL);text.addView(progressWrap,new LinearLayout.LayoutParams(dp(900),dp(34)));
        activePlayerProgress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);activePlayerProgress.setMax(1000);progressWrap.addView(activePlayerProgress,new LinearLayout.LayoutParams(0,dp(10),1));
        activePlayerTime=tv("0:00 / 0:00",14,Typeface.NORMAL);activePlayerTime.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(dp(150),dp(32));tlp.setMargins(dp(16),0,0,0);progressWrap.addView(activePlayerTime,tlp);
        LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.HORIZONTAL);controls.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);text.addView(controls,new LinearLayout.LayoutParams(-1,dp(62)));
        TextView playPause=btn("Pause");playPause.setOnClickListener(v->{togglePlayerPlayPause();schedulePlayerOverlayHide(overlay);});controls.addView(playPause,new LinearLayout.LayoutParams(dp(118),dp(54)));
        TextView rw=btn("-10");rw.setOnClickListener(v->{seekBy(-10000);schedulePlayerOverlayHide(overlay);});controls.addView(rw,new LinearLayout.LayoutParams(dp(92),dp(54)));
        TextView ff=btn("+10");ff.setOnClickListener(v->{seekBy(10000);schedulePlayerOverlayHide(overlay);});controls.addView(ff,new LinearLayout.LayoutParams(dp(92),dp(54)));
        TextView audio=btn("Audio");audio.setOnClickListener(v->{showAudioTrackPanel();});controls.addView(audio,new LinearLayout.LayoutParams(dp(118),dp(54)));
        TextView sub=btn("Subtitles");sub.setOnClickListener(v->{showSubtitleTrackPanel();});controls.addView(sub,new LinearLayout.LayoutParams(dp(150),dp(54)));
        TextView eps=btn("Episodes");eps.setOnClickListener(v->{showEpisodePanel();});controls.addView(eps,new LinearLayout.LayoutParams(dp(142),dp(54)));
        TextView zoom=btn("Zoom");zoom.setOnClickListener(v->{cycleZoomMode();schedulePlayerOverlayHide(overlay);});controls.addView(zoom,new LinearLayout.LayoutParams(dp(105),dp(54)));
        TextView settings=btn("Settings");settings.setOnClickListener(v->{showPlayerSettingsPanel();});controls.addView(settings,new LinearLayout.LayoutParams(dp(130),dp(54)));
        TextView back=btn("Back");back.setOnClickListener(v->{exitPlayerToDetails();});FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(150),dp(56),Gravity.RIGHT|Gravity.BOTTOM);bp.rightMargin=dp(42);bp.bottomMargin=dp(42);overlay.addView(back,bp);
        activePlayerOverlay = overlay;
        activePlayerPlayPause = playPause;
        activePlayerMovie = m;
        overlay.setOnKeyListener((v,keyCode,event)-> event.getAction()==KeyEvent.ACTION_DOWN && handlePlayerKey(keyCode));
        playPause.requestFocus();
        showPlayerOverlay(overlay);
        schedulePlayerOverlayHide(overlay);
    }

    boolean handlePlayerKey(int keyCode){
        if(activePlayerOverlay==null) return false;
        if(activePlayerOptionPanel!=null && activePlayerOptionPanel.getParent()!=null){
            if(keyCode==KeyEvent.KEYCODE_BACK){closePlayerOptionPanel();return true;}
            schedulePlayerOverlayHide(activePlayerOverlay);
            return false;
        }
        boolean hidden = activePlayerOverlay.getVisibility()!=View.VISIBLE || activePlayerOverlay.getAlpha() < 0.15f;
        if(hidden){
            showPlayerOverlay(activePlayerOverlay);
            if(activePlayerPlayPause!=null) activePlayerPlayPause.requestFocus();
            schedulePlayerOverlayHide(activePlayerOverlay);
            AppLogger.mark("Player overlay restored by key="+keyCode);
            return true;
        }
        showPlayerOverlay(activePlayerOverlay);
        if(keyCode==KeyEvent.KEYCODE_BACK){
            exitPlayerToDetails();
            return true;
        }
        if(keyCode==KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE){
            togglePlayerPlayPause(); schedulePlayerOverlayHide(activePlayerOverlay); return true;
        }
        if(keyCode==KeyEvent.KEYCODE_MEDIA_REWIND){
            seekBy(-10000); schedulePlayerOverlayHide(activePlayerOverlay); return true;
        }
        if(keyCode==KeyEvent.KEYCODE_MEDIA_FAST_FORWARD){
            seekBy(10000); schedulePlayerOverlayHide(activePlayerOverlay); return true;
        }
        // While controls are visible, DPAD arrows and OK are for moving/selecting buttons.
        if(keyCode==KeyEvent.KEYCODE_DPAD_LEFT || keyCode==KeyEvent.KEYCODE_DPAD_RIGHT || keyCode==KeyEvent.KEYCODE_DPAD_UP || keyCode==KeyEvent.KEYCODE_DPAD_DOWN || keyCode==KeyEvent.KEYCODE_DPAD_CENTER || keyCode==KeyEvent.KEYCODE_ENTER){
            schedulePlayerOverlayHide(activePlayerOverlay);
            return false;
        }
        schedulePlayerOverlayHide(activePlayerOverlay);
        return false;
    }


    void closePlayerOptionPanel(){
        try{ if(activePlayerOptionPanel!=null){ root.removeView(activePlayerOptionPanel); } }catch(Exception ignored){}
        activePlayerOptionPanel=null;
    }

    TextView playerOptionButton(String label, View.OnClickListener click){
        TextView b=btn(label);
        b.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);
        b.setPadding(dp(22),0,dp(22),0);
        b.setOnClickListener(v->{ click.onClick(v); closePlayerOptionPanel(); if(activePlayerOverlay!=null){activePlayerOverlay.setVisibility(View.VISIBLE);activePlayerOverlay.setAlpha(1f); schedulePlayerOverlayHide(activePlayerOverlay);} });
        return b;
    }

    void showPlayerOptionPanel(String title, ArrayList<TextView> buttons){
        if(activePlayerOverlay==null)return;
        closePlayerOptionPanel();
        activePlayerOverlay.setVisibility(View.VISIBLE);activePlayerOverlay.setAlpha(1f);
        FrameLayout panel=new FrameLayout(this);panel.setFocusable(false);panel.setBackground(bg(Color.argb(232,8,12,22),28));
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(dp(24),dp(18),dp(24),dp(24));panel.addView(p,new FrameLayout.LayoutParams(-1,-1));
        TextView h=tv(title,22,Typeface.BOLD);h.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);p.addView(h,new LinearLayout.LayoutParams(-1,dp(48)));
        if(buttons.isEmpty())buttons.add(playerOptionButton("No options available",v->{}));
        for(TextView b:buttons){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.setMargins(0,dp(5),0,dp(5));p.addView(b,lp);}
        TextView close=playerOptionButton("Close",v->{});p.addView(close,new LinearLayout.LayoutParams(-1,dp(52)));
        FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(dp(520),dp(Math.min(560,120+buttons.size()*62)),Gravity.RIGHT|Gravity.BOTTOM);fp.rightMargin=dp(44);fp.bottomMargin=dp(128);activePlayerOverlay.addView(panel,fp);activePlayerOptionPanel=panel;
        if(p.getChildCount()>1)p.getChildAt(1).requestFocus(); else close.requestFocus();
        if(playerOverlayHideRunnable!=null)playerOverlayHandler.removeCallbacks(playerOverlayHideRunnable);
    }

    void showAudioTrackPanel(){
        ArrayList<TextView> options=new ArrayList<>();
        options.add(playerOptionButton("Auto / Default audio",v->{try{if(exoPlayer!=null){TrackSelectionParameters p=exoPlayer.getTrackSelectionParameters().buildUpon().clearOverridesOfType(C.TRACK_TYPE_AUDIO).build();exoPlayer.setTrackSelectionParameters(p);Toast.makeText(this,"Audio: Auto",Toast.LENGTH_SHORT).show();}}catch(Exception e){Toast.makeText(this,"Audio change failed",Toast.LENGTH_SHORT).show();}}));
        try{
            if(exoPlayer!=null){Tracks tracks=exoPlayer.getCurrentTracks();int count=0;for(Tracks.Group g:tracks.getGroups()){if(g.getType()!=C.TRACK_TYPE_AUDIO)continue;for(int i=0;i<g.length;i++){final Tracks.Group fg=g;final int fi=i;Format f=g.getTrackFormat(i);String lang=(f.language==null||f.language.isEmpty())?"Unknown":f.language;String label=first(f.label,"");String text="Audio "+(++count)+" • "+lang+(label.isEmpty()?"":" • "+label);options.add(playerOptionButton(text,v->{try{TrackSelectionOverride o=new TrackSelectionOverride(fg.getMediaTrackGroup(),fi);TrackSelectionParameters p=exoPlayer.getTrackSelectionParameters().buildUpon().setOverrideForType(o).setTrackTypeDisabled(C.TRACK_TYPE_AUDIO,false).build();exoPlayer.setTrackSelectionParameters(p);Toast.makeText(this,text,Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Audio track failed",Toast.LENGTH_SHORT).show();}}));}}}
        }catch(Exception e){AppLogger.mark("Audio panel failed: "+e.getMessage());}
        showPlayerOptionPanel("Audio Tracks",options);
    }

    void showSubtitleTrackPanel(){
        ArrayList<TextView> options=new ArrayList<>();
        options.add(playerOptionButton("Subtitles Off",v->{try{if(exoPlayer!=null){TrackSelectionParameters p=exoPlayer.getTrackSelectionParameters().buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT,true).clearOverridesOfType(C.TRACK_TYPE_TEXT).build();exoPlayer.setTrackSelectionParameters(p);Toast.makeText(this,"Subtitles Off",Toast.LENGTH_SHORT).show();}}catch(Exception e){Toast.makeText(this,"Subtitle change failed",Toast.LENGTH_SHORT).show();}}));
        try{
            if(exoPlayer!=null){Tracks tracks=exoPlayer.getCurrentTracks();int count=0;for(Tracks.Group g:tracks.getGroups()){if(g.getType()!=C.TRACK_TYPE_TEXT)continue;for(int i=0;i<g.length;i++){final Tracks.Group fg=g;final int fi=i;Format f=g.getTrackFormat(i);String lang=(f.language==null||f.language.isEmpty())?"Unknown":f.language;String label=first(f.label,"");String text="Subtitle "+(++count)+" • "+lang+(label.isEmpty()?"":" • "+label);options.add(playerOptionButton(text,v->{try{TrackSelectionOverride o=new TrackSelectionOverride(fg.getMediaTrackGroup(),fi);TrackSelectionParameters p=exoPlayer.getTrackSelectionParameters().buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT,false).setOverrideForType(o).build();exoPlayer.setTrackSelectionParameters(p);Toast.makeText(this,text,Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Subtitle track failed",Toast.LENGTH_SHORT).show();}}));}}}
        }catch(Exception e){AppLogger.mark("Subtitle panel failed: "+e.getMessage());}
        showPlayerOptionPanel("Subtitles",options);
    }

    void showEpisodePanel(){
        ArrayList<TextView> options=new ArrayList<>();
        options.add(playerOptionButton("Current: "+(activePlayerMovie==null?"Movie":activePlayerMovie.title),v->{}));
        options.add(playerOptionButton("Episode selector will populate for series metadata",v->{}));
        showPlayerOptionPanel("Episodes",options);
    }

    void showPlayerSettingsPanel(){
        ArrayList<TextView> options=new ArrayList<>();
        options.add(playerOptionButton("Playback speed: 0.75x",v->{if(exoPlayer!=null)exoPlayer.setPlaybackSpeed(.75f);}));
        options.add(playerOptionButton("Playback speed: 1.0x",v->{if(exoPlayer!=null)exoPlayer.setPlaybackSpeed(1f);}));
        options.add(playerOptionButton("Playback speed: 1.25x",v->{if(exoPlayer!=null)exoPlayer.setPlaybackSpeed(1.25f);}));
        options.add(playerOptionButton("Restart from beginning",v->{if(exoPlayer!=null){exoPlayer.seekTo(0);exoPlayer.play();}}));
        showPlayerOptionPanel("Player Settings",options);
    }

    void seekBy(long deltaMs){
        if(exoPlayer==null) return;
        long duration=exoPlayer.getDuration();
        long next=Math.max(0, exoPlayer.getCurrentPosition()+deltaMs);
        if(duration>0) next=Math.min(duration, next);
        exoPlayer.seekTo(next);
        updatePlayerProgress();
    }

    void cycleZoomMode(){
        if(activePlayerView==null) return;
        activeZoomMode=(activeZoomMode+1)%3;
        if(activeZoomMode==0){ activePlayerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT); Toast.makeText(this,"Zoom: Fit",Toast.LENGTH_SHORT).show(); }
        else if(activeZoomMode==1){ activePlayerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_ZOOM); Toast.makeText(this,"Zoom: Fill",Toast.LENGTH_SHORT).show(); }
        else { activePlayerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL); Toast.makeText(this,"Zoom: Stretch",Toast.LENGTH_SHORT).show(); }
        AppLogger.mark("Player zoom mode="+activeZoomMode);
    }

    void exitPlayerToDetails(){
        try{ if(playerOverlayHideRunnable!=null)playerOverlayHandler.removeCallbacks(playerOverlayHideRunnable); }catch(Exception ignored){}
        try{ if(playerProgressRunnable!=null)playerProgressHandler.removeCallbacks(playerProgressRunnable); }catch(Exception ignored){}
        try{ if(exoPlayer!=null){exoPlayer.release();exoPlayer=null;} }catch(Exception ignored){}
        Movie m=activePlayerMovie;
        activePlayerOverlay=null;activePlayerPlayPause=null;activePlayerProgress=null;activePlayerTime=null;activePlayerView=null;
        AppLogger.mark("PLAYER_BACK_TO_DETAILS");
        if(m!=null) showMovieDetails(m); else showHome();
    }

    String fmtTime(long ms){
        if(ms<0) ms=0;
        long total=ms/1000, h=total/3600, min=(total%3600)/60, sec=total%60;
        if(h>0) return String.format(java.util.Locale.US,"%d:%02d:%02d",h,min,sec);
        return String.format(java.util.Locale.US,"%d:%02d",min,sec);
    }

    void updatePlayerProgress(){
        if(exoPlayer==null || activePlayerProgress==null || activePlayerTime==null) return;
        long pos=exoPlayer.getCurrentPosition(); long dur=exoPlayer.getDuration();
        if(dur>0){ activePlayerProgress.setProgress((int)Math.max(0,Math.min(1000,(pos*1000)/dur))); activePlayerTime.setText(fmtTime(pos)+" / "+fmtTime(dur)); }
        else { activePlayerProgress.setProgress(0); activePlayerTime.setText(fmtTime(pos)+" / --:--"); }
    }

    void startPlayerProgressUpdates(){
        if(playerProgressRunnable!=null) playerProgressHandler.removeCallbacks(playerProgressRunnable);
        playerProgressRunnable=()->{ updatePlayerProgress(); if(activePlayerOverlay!=null && exoPlayer!=null) playerProgressHandler.postDelayed(playerProgressRunnable,500); };
        playerProgressHandler.post(playerProgressRunnable);
    }

    void togglePlayerPlayPause(){
        if(exoPlayer==null) return;
        if(exoPlayer.isPlaying()){ exoPlayer.pause(); if(activePlayerPlayPause!=null) activePlayerPlayPause.setText("Play"); }
        else { exoPlayer.play(); if(activePlayerPlayPause!=null) activePlayerPlayPause.setText("Pause"); }
    }

    void showPlayerOverlay(FrameLayout overlay){
        if(overlay==null) return;
        overlay.animate().cancel();
        overlay.setVisibility(View.VISIBLE);
        overlay.setAlpha(1f);
        overlay.setFocusable(true);
        overlay.setFocusableInTouchMode(true);
    }
    void hidePlayerOverlay(FrameLayout overlay){
        if(overlay==null) return;
        overlay.animate().cancel();
        overlay.animate().alpha(0f).setDuration(220).start();
    }
    void schedulePlayerOverlayHide(FrameLayout overlay){
        if(overlay==null) return;
        if(playerOverlayHideRunnable!=null) playerOverlayHandler.removeCallbacks(playerOverlayHideRunnable);
        playerOverlayHideRunnable=()->{
            if(overlay==activePlayerOverlay && exoPlayer!=null && exoPlayer.isPlaying()){
                hidePlayerOverlay(overlay);
                AppLogger.mark("Player overlay auto-hidden");
            }
        };
        playerOverlayHandler.postDelayed(playerOverlayHideRunnable,5000);
    }

    void releaseMainPlayback(String reason){
        try{ if(playerOverlayHideRunnable!=null)playerOverlayHandler.removeCallbacks(playerOverlayHideRunnable); }catch(Exception ignored){}
        try{ if(playerProgressRunnable!=null)playerProgressHandler.removeCallbacks(playerProgressRunnable); }catch(Exception ignored){}
        try{ if(activePlayerView!=null)activePlayerView.setPlayer(null); }catch(Exception ignored){}
        try{ if(exoPlayer!=null){ exoPlayer.stop(); exoPlayer.clearMediaItems(); exoPlayer.release(); exoPlayer=null; AppLogger.mark("LIVE_TV_V081: released_main_playback reason="+reason); } }catch(Exception e){ AppLogger.mark("LIVE_TV_V081: release_main_failed "+e.getMessage()); }
        activePlayerView=null;
    }

    void playChannel(Channel c){ showLivePlayer(c); }
        void showVideo(String title,String url,String overlay){
            clear();backdrop();
            try{ if(exoPlayer!=null){exoPlayer.release();exoPlayer=null;} }catch(Exception ignored){}
            activePlayerView=new PlayerView(this);activePlayerView.setUseController(false);activePlayerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);root.addView(activePlayerView,new FrameLayout.LayoutParams(-1,-1));
            try{
                DefaultHttpDataSource.Factory httpFactory=new DefaultHttpDataSource.Factory().setUserAgent("DebridChannelsTV/0.6.4").setAllowCrossProtocolRedirects(true).setConnectTimeoutMs(12000).setReadTimeoutMs(20000);
                exoPlayer=new ExoPlayer.Builder(this).setMediaSourceFactory(new DefaultMediaSourceFactory(httpFactory)).build(); applyPlaybackQualityPreferences(exoPlayer,"live_tv_player");
                exoPlayer.setMediaItem(MediaItem.fromUri(Uri.parse(url)));
                activePlayerView.setPlayer(exoPlayer); applyFrameRateAndResolutionHints(activePlayerView,"active_player_attach");exoPlayer.prepare();exoPlayer.play();
            }catch(Exception e){Toast.makeText(this,"Playback failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}
            TextView top=tv(title+"\n"+overlay,24,Typeface.BOLD);top.setGravity(Gravity.LEFT|Gravity.TOP);top.setPadding(dp(32),dp(28),0,0);top.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{Color.argb(190,0,0,0),Color.TRANSPARENT}));root.addView(top,new FrameLayout.LayoutParams(-1,dp(160)));
            TextView back=btn("Back");back.setOnClickListener(v->showHome());FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(160),dp(55),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);bp.bottomMargin=dp(45);root.addView(back,bp);back.requestFocus();
        }
        void showLivePlayer(Channel c){
            if(c==null||c.url==null||c.url.trim().isEmpty()){Toast.makeText(this,"No playable stream URL loaded",Toast.LENGTH_SHORT).show();return;}
            releaseLivePreview();
            releaseMainPlayback("start_live_player_replace_previous");
            livePlayerActive=true; lastLiveChannel=c; clear(); nav.go(NavigationController.Screen.LIVE_TV);
            AppLogger.mark("LIVE_TV_V081: play_live channel="+c.name+" group="+c.group+" url="+safeUrlForLog(c.url));
            try{ if(exoPlayer!=null){exoPlayer.release();exoPlayer=null;} }catch(Exception ignored){}
            root.setBackgroundColor(Color.BLACK);
            activePlayerView=new PlayerView(this); activePlayerView.setUseController(false); activePlayerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT); root.addView(activePlayerView,new FrameLayout.LayoutParams(-1,-1));
            try{
                DefaultHttpDataSource.Factory httpFactory=new DefaultHttpDataSource.Factory().setUserAgent("DebridChannelsLiveTV/0.8.0").setAllowCrossProtocolRedirects(true).setConnectTimeoutMs(15000).setReadTimeoutMs(30000);
                DefaultLoadControl lc=new DefaultLoadControl.Builder().setBufferDurationsMs(2500,18000,750,1500).build();
                exoPlayer=new ExoPlayer.Builder(this).setMediaSourceFactory(new DefaultMediaSourceFactory(httpFactory)).setLoadControl(lc).build(); applyPlaybackQualityPreferences(exoPlayer,"live_tv_player");
                exoPlayer.setAudioAttributes(new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),true);
                exoPlayer.setVolume(1f); activePlayerView.setPlayer(exoPlayer); applyFrameRateAndResolutionHints(activePlayerView,"active_player_attach");
                String liveUrl=c.url.trim();
                MediaItem.Builder liveItem=new MediaItem.Builder().setUri(Uri.parse(liveUrl));
                String liveMime=inferLiveMime(liveUrl);
                if(liveMime!=null)liveItem.setMimeType(liveMime);
                AppLogger.mark("LIVE_TV_V081: media_item mime="+(liveMime==null?"auto":liveMime)+" url="+safeUrlForLog(liveUrl));
                exoPlayer.setMediaSource(createLiveMediaSource(liveUrl)); exoPlayer.prepare(); exoPlayer.play();
                exoPlayer.addListener(new Player.Listener(){@Override public void onPlayerError(PlaybackException error){AppLogger.mark("LIVE_TV_V081: player_error code="+error.errorCode+" msg="+error.getMessage());Toast.makeText(MainActivity.this,"Live TV playback error: "+error.getMessage(),Toast.LENGTH_LONG).show();}});
            }catch(Exception e){Toast.makeText(this,"Live TV playback failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}
            TextView top=tv(c.name+"  -  "+(c.group==null?"Live TV":c.group)+"\nPress BACK to return to guide",22,Typeface.BOLD);top.setGravity(Gravity.LEFT|Gravity.TOP);top.setPadding(dp(32),dp(26),0,0);top.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{Color.argb(185,0,0,0),Color.TRANSPARENT}));root.addView(top,new FrameLayout.LayoutParams(-1,dp(150)));
        }
        String safeUrlForLog(String u){try{if(u==null)return"";Uri x=Uri.parse(u);String h=x.getHost();return (h==null?"stream":h)+" path="+x.getPath();}catch(Exception e){return"stream";}}

        String inferLiveMime(String url){
            if(url==null)return null;
            String u=url.toLowerCase(Locale.US);
            if(u.contains(".m3u8")||u.contains("format=m3u8"))return MimeTypes.APPLICATION_M3U8;
            if(u.contains(".mpd"))return MimeTypes.APPLICATION_MPD;
            if(u.contains(".ism")||u.contains("manifest"))return MimeTypes.APPLICATION_SS;
            if(u.contains(".mp4"))return MimeTypes.VIDEO_MP4;
            if(u.contains(".ts")||u.contains("mpegts")||u.contains("stream.mpg"))return MimeTypes.VIDEO_MP2T;
            return null;
        }
        MediaSource createLiveMediaSource(String liveUrl){
            DefaultHttpDataSource.Factory httpFactory=new DefaultHttpDataSource.Factory().setUserAgent("DebridChannelsLiveTV/0.8.0").setAllowCrossProtocolRedirects(true).setConnectTimeoutMs(15000).setReadTimeoutMs(30000);
            String u=liveUrl==null?"":liveUrl.toLowerCase(Locale.US);
            MediaItem item=MediaItem.fromUri(Uri.parse(liveUrl));
            if(u.contains(".m3u8")||u.contains("format=m3u8"))return new HlsMediaSource.Factory(httpFactory).createMediaSource(item);
            if(u.contains(".mpd"))return new DashMediaSource.Factory(httpFactory).createMediaSource(item);
            return new ProgressiveMediaSource.Factory(httpFactory).createMediaSource(item);
        }
        void releaseLivePreview(){
            if(pendingLivePreviewRunnable!=null)livePreviewHandler.removeCallbacks(pendingLivePreviewRunnable);
            pendingLivePreviewRunnable=null; currentLivePreviewUrl="";
            try{ if(livePreviewPlayerView!=null) livePreviewPlayerView.setPlayer(null); }catch(Exception ignored){}
            try{ if(livePreviewPlayer!=null){livePreviewPlayer.stop(); livePreviewPlayer.clearMediaItems(); livePreviewPlayer.release();livePreviewPlayer=null;} }catch(Exception ignored){}
            livePreviewPlayerView=null;
        }
        void scheduleLivePreview(Channel c, ImageView fallback){
            if(pendingLivePreviewRunnable!=null)livePreviewHandler.removeCallbacks(pendingLivePreviewRunnable);
            pendingLivePreviewRunnable=()->startLivePreview(c,fallback);
            livePreviewHandler.postDelayed(pendingLivePreviewRunnable,350);
        }
        void startLivePreview(Channel c, ImageView fallback){
            if(livePreviewPlayerView==null||c==null||c.url==null||c.url.trim().isEmpty())return;
            String u=c.url.trim();
            if(u.equals(currentLivePreviewUrl)&&livePreviewPlayer!=null)return;
            currentLivePreviewUrl=u;
            try{
                if(livePreviewPlayer!=null){livePreviewPlayer.release();livePreviewPlayer=null;}
                if(fallback!=null)fallback.setAlpha(1f);
                DefaultLoadControl lc=new DefaultLoadControl.Builder().setBufferDurationsMs(1200,8000,350,700).build();
                livePreviewPlayer=new ExoPlayer.Builder(this).setMediaSourceFactory(new DefaultMediaSourceFactory(new DefaultHttpDataSource.Factory().setUserAgent("DebridChannelsLiveTV/0.8.0").setAllowCrossProtocolRedirects(true).setConnectTimeoutMs(12000).setReadTimeoutMs(22000))).setLoadControl(lc).build(); applyPlaybackQualityPreferences(livePreviewPlayer,"live_preview_muted");
                livePreviewPlayer.setAudioAttributes(new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),false);
                livePreviewPlayer.setVolume(0f);
                livePreviewPlayerView.setPlayer(livePreviewPlayer); applyFrameRateAndResolutionHints(livePreviewPlayerView,"live_preview_attach");
                livePreviewPlayer.setMediaSource(createLiveMediaSource(u));
                livePreviewPlayer.prepare();
                livePreviewPlayer.play();
                livePreviewPlayer.addListener(new Player.Listener(){
                    @Override public void onPlaybackStateChanged(int state){ if(state==Player.STATE_READY&&fallback!=null)fallback.setAlpha(0f); }
                    @Override public void onPlayerError(PlaybackException error){ if(fallback!=null)fallback.setAlpha(1f); AppLogger.mark("LIVE_TV_V086: preview_error "+error.getMessage()); }
                });
                AppLogger.mark("LIVE_TV_V086: preview_start channel="+c.name+" url="+safeUrlForLog(u));
            }catch(Exception e){ if(fallback!=null)fallback.setAlpha(1f); AppLogger.mark("LIVE_TV_V086: preview_failed "+e.getMessage()); }
        }
    void showLiveTv(){
        suppressRowAutoFocus=false;
        clear();
        nav.go(NavigationController.Screen.LIVE_TV);
        AppLogger.mark("LIVE_TV_V086: sources_guide_player channels="+channels.size()+" liveDensity="+liveTvDensityName(liveTvDensityMode())+" fit="+liveTvFitFactor()+" live4k="+live4kDensityMode()+" display="+getResources().getDisplayMetrics().widthPixels+"x"+getResources().getDisplayMetrics().heightPixels+" density="+getResources().getDisplayMetrics().density);

        ImageView heroBg=new ImageView(this);
        heroBg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        heroBg.setBackgroundColor(Color.rgb(3,3,4));
        root.addView(heroBg,new FrameLayout.LayoutParams(-1,-1));
        View scrim=new View(this);
        scrim.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.argb(252,0,0,0),Color.argb(236,5,5,7),Color.argb(198,9,9,12),Color.argb(238,0,0,0)}));
        root.addView(scrim,new FrameLayout.LayoutParams(-1,-1));
        View bottomFade=new View(this);
        bottomFade.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,new int[]{Color.argb(255,0,0,0),Color.argb(220,0,0,0),Color.TRANSPARENT}));
        root.addView(bottomFade,new FrameLayout.LayoutParams(-1,ldp(420),Gravity.BOTTOM));

        // Keep the app shell menu visible, but make the guide layout itself match the old Google-TV-style Live TV activity.
        addMenu();

        final ArrayList<View> catViews=new ArrayList<>();
        final ArrayList<View> guideViews=new ArrayList<>();
        final String[] activeGroup=new String[]{"All Channels"};
        final Channel[] activeChannel=new Channel[]{channels.isEmpty()?new Channel("Live TV source not loaded","All Channels","",""):channels.get(0)};
        final int[] focusedRow=new int[]{0};

        // v0.8.3 real 1080p layout: these numbers are layout dimensions before the ldp() fit pass.
        // 1080p Auto Fit is intentionally narrower/shorter than the 4K compact shell so it cannot crop.
        final boolean live1080Mode=!live4kDensityMode();
        final int liveTheme=Math.max(0,Math.min(5,ui.value("liveTvThemeMode",0)));
        final boolean showGuideRedLine=ui.value("liveTvGuideRedLine",1)==1;
        final boolean showTimelineLabels=ui.value("liveTvTimelineLabels",1)==1;
        final boolean showChannelLogos=ui.value("liveTvChannelLogos",1)==1;
        final boolean showPreviewWindow=ui.value("liveTvPreviewWindow",1)==1;
        final int liveTvVisibleRows=Math.max(3,Math.min(7,ui.value("liveTvVisibleRows",5)));
        final LiveTvLayoutConfig tvLayout=LiveTvLayoutConfig.preset(liveTheme, live4kDensityMode(), liveTvVisibleRows);
        AppLogger.mark("LIVE_TV_V090_ENGINE: applied theme="+tvLayout.name+" id="+tvLayout.id+" density="+liveTvDensityName(liveTvDensityMode())+" rows="+tvLayout.visibleRows+" redLine="+showGuideRedLine+" timeline="+showTimelineLabels+" preview="+showPreviewWindow+" logos="+showChannelLogos+" main="+tvLayout.mainLeft+","+tvLayout.mainTop+","+tvLayout.mainWidth+","+tvLayout.mainHeight+" previewW="+tvLayout.previewWidth);
        final int catLeft=tvLayout.catLeft;
        final int catTop=tvLayout.catTop;
        final int catWidth=tvLayout.catWidth;
        final int catHeight=tvLayout.catHeight;
        final int mainLeft=tvLayout.mainLeft;
        final int mainTop=tvLayout.mainTop;
        final int mainWidth=tvLayout.mainWidth;
        final int mainHeight=tvLayout.mainHeight;
        final int fullLeft=tvLayout.fullLeft;
        final int fullTop=tvLayout.fullTop;
        final int fullWidth=tvLayout.fullWidth;
        final int fullHeight=tvLayout.fullHeight;
        final int rowLogoW=tvLayout.rowLogoWidth;
        final int nowCellW=tvLayout.nowCellWidth;
        final int nextCellW=tvLayout.nextCellWidth;
        final int laterCellW=tvLayout.laterCellWidth;
        final int farCellW=tvLayout.farCellWidth;
        final int rowH=tvLayout.rowHeight;
        final int rowCellH=tvLayout.rowCellHeight;

        LinearLayout categoryPanel=new LinearLayout(this);
        categoryPanel.setOrientation(LinearLayout.VERTICAL);
        categoryPanel.setPadding(ldp(4),0,ldp(16),0);
        FrameLayout.LayoutParams cpLp=new FrameLayout.LayoutParams(ldp(catWidth),ldp(catHeight));
        cpLp.leftMargin=ldp(catLeft); cpLp.topMargin=ldp(catTop); root.addView(categoryPanel,cpLp);

        LinearLayout mainPanel=new LinearLayout(this);
        mainPanel.setOrientation(LinearLayout.VERTICAL);
        final FrameLayout.LayoutParams mpLp=new FrameLayout.LayoutParams(ldp(mainWidth),ldp(mainHeight));
        mpLp.leftMargin=ldp(mainLeft); mpLp.topMargin=ldp(mainTop); root.addView(mainPanel,mpLp);

        LinearLayout header=new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        mainPanel.addView(header,new LinearLayout.LayoutParams(-1,ldp(tvLayout.headerHeight)));

        LinearLayout info=new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(ldp(10),ldp(2),ldp(12),0);
        header.addView(info,new LinearLayout.LayoutParams(0,-1,1));

        FrameLayout logoTile=new FrameLayout(this);
        logoTile.setBackground(bg(Color.argb(110,22,24,31),12));
        TextView logoText=ltv("TV",18,Typeface.BOLD); logoText.setGravity(Gravity.CENTER);
        ImageView logoImg=new ImageView(this); logoImg.setScaleType(ImageView.ScaleType.FIT_CENTER); logoImg.setPadding(ldp(5),ldp(5),ldp(5),ldp(5));
        logoTile.addView(logoImg,new FrameLayout.LayoutParams(-1,-1));
        logoTile.addView(logoText,new FrameLayout.LayoutParams(-1,-1));
        info.addView(logoTile,new LinearLayout.LayoutParams(ldp(tvLayout.logoTileW),ldp(tvLayout.logoTileH)));

        TextView title=ltv("Live TV",tvLayout.titleSp,Typeface.NORMAL); title.setSingleLine(true); title.setEllipsize(android.text.TextUtils.TruncateAt.END); title.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        info.addView(title,new LinearLayout.LayoutParams(-1,ldp(78)));
        LinearLayout metaRow=new LinearLayout(this); metaRow.setOrientation(LinearLayout.HORIZONTAL); metaRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView nowTimeLabel=ltv("Today",tvLayout.metaSp,Typeface.BOLD); nowTimeLabel.setSingleLine(true); metaRow.addView(nowTimeLabel,new LinearLayout.LayoutParams(-2,ldp(36)));
        TextView groupLabel=ltv("All Channels",tvLayout.metaSp,Typeface.BOLD); groupLabel.setSingleLine(true); groupLabel.setPadding(ldp(20),0,0,0); metaRow.addView(groupLabel,new LinearLayout.LayoutParams(-2,ldp(36)));
        info.addView(metaRow,new LinearLayout.LayoutParams(-1,ldp(40)));
        TextView desc=ltv("Browse your synced live channels in a cable-style guide.",tvLayout.descSp,Typeface.NORMAL); desc.setTextColor(Color.argb(205,255,255,255)); desc.setMaxLines(2); desc.setEllipsize(android.text.TextUtils.TruncateAt.END);
        info.addView(desc,new LinearLayout.LayoutParams(-1,ldp(54)));

        FrameLayout preview=new FrameLayout(this); preview.setBackground(bg(Color.argb(85,18,20,27),18)); preview.setPadding(ldp(tvLayout.previewPadding),ldp(tvLayout.previewPadding),ldp(tvLayout.previewPadding),ldp(tvLayout.previewPadding));
        livePreviewPlayerView=new PlayerView(this); livePreviewPlayerView.setUseController(false); livePreviewPlayerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT); preview.addView(livePreviewPlayerView,new FrameLayout.LayoutParams(-1,-1));
        // v0.8.6: preview is no longer part of the header row. It is anchored to the root safe area
        // so it cannot be clipped/cropped by Live TV density, guide width, or header overflow.
        DisplayMetrics previewMetrics=getResources().getDisplayMetrics();
        // v0.8.7: preview is locked inside the top-right header zone. It shrinks before it can overlap the guide grid.
        int previewWpx=showPreviewWindow?Math.min(rawDp(tvLayout.previewWidth), Math.max(rawDp(live1080Mode?240:280), previewMetrics.widthPixels-rawDp(96))):1;
        int previewHpx=showPreviewWindow?Math.round(previewWpx*9f/16f):1;
        FrameLayout.LayoutParams prevLp=new FrameLayout.LayoutParams(previewWpx,previewHpx,Gravity.RIGHT|Gravity.TOP);
        prevLp.rightMargin=rawDp(tvLayout.previewRight);
        prevLp.topMargin=rawDp(tvLayout.previewTop);
        root.addView(preview,prevLp);
        preview.setVisibility(showPreviewWindow?View.VISIBLE:View.GONE);
        preview.bringToFront();
        AppLogger.mark("LIVE_TV_V086: preview_root_bounds xRightMargin="+prevLp.rightMargin+" y="+prevLp.topMargin+" widthPx="+previewWpx+" heightPx="+previewHpx+" screen="+previewMetrics.widthPixels+"x"+previewMetrics.heightPixels+" mode="+liveTvDensityName(liveTvDensityMode())+" fit="+liveTvFitFactor());
        ImageView previewImg=new ImageView(this); previewImg.setScaleType(ImageView.ScaleType.FIT_CENTER); previewImg.setAdjustViewBounds(true); previewImg.setPadding(ldp(8),ldp(8),ldp(8),ldp(8)); preview.addView(previewImg,new FrameLayout.LayoutParams(-1,-1));
        TextView previewHint=ltv("LIVE",11,Typeface.BOLD); previewHint.setGravity(Gravity.CENTER); previewHint.setBackground(bg(Color.rgb(170,22,26),2));
        FrameLayout.LayoutParams liveLp=new FrameLayout.LayoutParams(ldp(52),ldp(20),Gravity.LEFT|Gravity.TOP); liveLp.leftMargin=ldp(12); liveLp.topMargin=ldp(10); preview.addView(previewHint,liveLp);

        LinearLayout timeRow=new LinearLayout(this); timeRow.setOrientation(LinearLayout.HORIZONTAL); timeRow.setPadding(ldp(tvLayout.timelineLeftPadding),0,0,0); timeRow.setGravity(Gravity.CENTER_VERTICAL);
        mainPanel.addView(timeRow,new LinearLayout.LayoutParams(-1,ldp(tvLayout.timelineHeight)));
        String nowText=new java.text.SimpleDateFormat("h:mm a",Locale.US).format(new Date());
        String[] ticks=new String[]{"ON NOW",nowText,"+30 MIN","+60 MIN","+90 MIN","+120 MIN"};
        int[] tickW=tvLayout.tickWidths;
        for(int i=0;i<ticks.length;i++){TextView t=ltv(showTimelineLabels?ticks[i]:"",12,Typeface.BOLD);t.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);t.setTextColor(i==1?Color.rgb(255,68,91):Color.argb(175,255,255,255));timeRow.addView(t,new LinearLayout.LayoutParams(ldp(tickW[i]),ldp(34)));}
        timeRow.setVisibility(showTimelineLabels?View.VISIBLE:View.INVISIBLE);

        FrameLayout guideFrame=new FrameLayout(this);
        mainPanel.addView(guideFrame,new LinearLayout.LayoutParams(-1,0,1));
        HorizontalScrollView hsv=new HorizontalScrollView(this); hsv.setHorizontalScrollBarEnabled(false); hsv.setClipToPadding(false);
        LinearLayout wide=new LinearLayout(this); wide.setOrientation(LinearLayout.VERTICAL); hsv.addView(wide,new HorizontalScrollView.LayoutParams(ldp(tvLayout.wideWidth),-2));
        // v0.8.7: bottom-anchor the guide viewport so the rows sit at the bottom of the screen and grow upward like a cable guide.
        final int visibleGuideRows=tvLayout.visibleRows;
        final int guideViewportH=(rowH*visibleGuideRows)+(live1080Mode?16:20);
        FrameLayout.LayoutParams hsvLp=new FrameLayout.LayoutParams(-1,ldp(guideViewportH),Gravity.BOTTOM);
        guideFrame.addView(hsv,hsvLp);
        FrameLayout rowsFrame=new FrameLayout(this); wide.addView(rowsFrame,new LinearLayout.LayoutParams(-1,ldp(guideViewportH)));
        View redLine=new View(this); redLine.setBackgroundColor(Color.rgb(255,64,88)); FrameLayout.LayoutParams redLp=new FrameLayout.LayoutParams(ldp(2),ldp(guideViewportH)); redLp.leftMargin=ldp(tvLayout.redLineX); redLp.topMargin=0; rowsFrame.addView(redLine,redLp); redLine.setVisibility(showGuideRedLine?View.VISIBLE:View.GONE);
        TextView redDot=ltv("•",28,Typeface.BOLD); redDot.setTextColor(Color.rgb(255,64,88)); FrameLayout.LayoutParams dotLp=new FrameLayout.LayoutParams(ldp(28),ldp(28)); dotLp.leftMargin=ldp(Math.max(0,tvLayout.redLineX-13)); dotLp.topMargin=ldp(-18); rowsFrame.addView(redDot,dotLp); redDot.setVisibility(showGuideRedLine?View.VISIBLE:View.GONE);
        ScrollView sv=new ScrollView(this); sv.setVerticalScrollBarEnabled(false); sv.setClipToPadding(false); LinearLayout rows=new LinearLayout(this); rows.setOrientation(LinearLayout.VERTICAL); rows.setPadding(0,0,0,ldp(12)); sv.addView(rows,new ScrollView.LayoutParams(-1,-2)); rowsFrame.addView(sv,new FrameLayout.LayoutParams(-1,-1));

        TextView refresh=liveBtn("Force Refresh Guide"); refresh.setTextSize(15); refresh.setGravity(Gravity.CENTER); refresh.setBackground(bg(Color.argb(220,39,47,70),26));
        refresh.setOnClickListener(v->{ loadLiveTvSources(); Toast.makeText(this,"Refreshing Live TV guide",Toast.LENGTH_SHORT).show(); });
        FrameLayout.LayoutParams rfLp=new FrameLayout.LayoutParams(ldp(tvLayout.refreshWidth),ldp(tvLayout.refreshHeight),Gravity.LEFT|Gravity.BOTTOM); rfLp.leftMargin=ldp(catLeft); rfLp.bottomMargin=ldp(tvLayout.refreshBottom); root.addView(refresh,rfLp);

        ArrayList<String> groups=new ArrayList<>(); groups.add("All Channels"); groups.add("Favorites");
        for(Channel ch:channels){String g=(ch.group==null||ch.group.trim().isEmpty())?"Other":ch.group.trim(); if(!groups.contains(g))groups.add(g);} 
        if(groups.size()<=2 && channels.isEmpty()) Collections.addAll(groups,"Google TV","Popular","Movies","News & opinion","Hit TV shows","Entertainment","Crime","Reality");

        final Runnable[] updateInfo=new Runnable[1];
        final Runnable[] repaintGuide=new Runnable[1];
        final boolean[] fullGuideMode=new boolean[]{false};
        final Runnable[] enterFullGuide=new Runnable[1];
        final Runnable[] exitFullGuide=new Runnable[1];
        enterFullGuide[0]=()->{
            if(fullGuideMode[0])return;
            fullGuideMode[0]=true;
            categoryPanel.setVisibility(View.GONE);
            refresh.setVisibility(View.GONE);
            mpLp.leftMargin=ldp(fullLeft);
            mpLp.topMargin=ldp(fullTop);
            mpLp.width=ldp(fullWidth);
            mpLp.height=ldp(fullHeight);
            mainPanel.setLayoutParams(mpLp);
            mainPanel.requestLayout();
            AppLogger.mark("LIVE_TV_V086: entered_full_guide_view");
        };
        exitFullGuide[0]=()->{
            if(!fullGuideMode[0])return;
            fullGuideMode[0]=false;
            categoryPanel.setVisibility(View.VISIBLE);
            refresh.setVisibility(View.VISIBLE);
            mpLp.leftMargin=ldp(mainLeft);
            mpLp.topMargin=ldp(mainTop);
            mpLp.width=ldp(mainWidth);
            mpLp.height=ldp(mainHeight);
            mainPanel.setLayoutParams(mpLp);
            mainPanel.requestLayout();
            AppLogger.mark("LIVE_TV_V086: exited_full_guide_view");
        };
        updateInfo[0]=()->{
            Channel c=activeChannel[0];
            String g=(c==null||c.group==null||c.group.trim().isEmpty())?activeGroup[0]:c.group.trim();
            String n=(c==null||c.name==null||c.name.trim().isEmpty())?"Live TV":c.name.trim();
            String programTitle=(c!=null&&c.epgNow!=null&&!c.epgNow.trim().isEmpty())?c.epgNow:n;
            title.setText(programTitle); groupLabel.setText(g); String time=(c!=null&&c.epgTime!=null&&!c.epgTime.trim().isEmpty())?c.epgTime:"On Now"; nowTimeLabel.setText(c!=null&&c.url!=null&&!c.url.trim().isEmpty()?"Today, "+time:"Today, Source needed");
            desc.setText(c!=null&&c.url!=null&&!c.url.trim().isEmpty()?((c.epgDescription!=null&&!c.epgDescription.trim().isEmpty())?c.epgDescription:("Channel: "+n+". Press OK to play. Press LEFT for categories. Press UP for the top menu.")):"Live TV source is not loaded. Add or verify the M3U, Channels DVR, HDHomeRun, or IPTV URL in Settings, then refresh the guide.");
            scheduleLivePreview(c, previewImg);
            String initials=shortChannelLabel(n,0); logoText.setText(initials); logoText.setVisibility(View.VISIBLE); logoImg.setVisibility(View.GONE);
            if(c!=null&&c.logo!=null&&!c.logo.trim().isEmpty()){
                try{
                    // v0.6.5: keep logos in the logo/preview containers only.
                    // Do NOT paint channel logos into the guide background; it caused ghosting and scroll slowdown.
                    loadImage(c.logo,logoImg,false);
                    loadImage(c.logo,previewImg,false);
                    heroBg.setImageDrawable(null);
                    heroBg.setAlpha(0f);
                    logoImg.setVisibility(View.VISIBLE);
                    logoText.setVisibility(View.GONE);
                }catch(Exception ignored){}
            }
            else{previewImg.setImageDrawable(null); heroBg.setImageDrawable(null); heroBg.setAlpha(0f);}
        };

        repaintGuide[0]=()->{
            rows.removeAllViews(); guideViews.clear();
            ArrayList<Channel> filtered=new ArrayList<>();
            for(int i=0;i<channels.size();i++){Channel c=channels.get(i);String g=(c.group==null||c.group.trim().isEmpty())?"Other":c.group.trim(); if(activeGroup[0].equals("All Channels")||activeGroup[0].equals(g)||(activeGroup[0].equals("Favorites")&&i<12))filtered.add(c);} 
            if(filtered.isEmpty()) filtered.add(new Channel("Live TV source not loaded",activeGroup[0],"", ""));
            activeChannel[0]=filtered.get(0); focusedRow[0]=0; updateInfo[0].run();
            for(int i=0;i<Math.min(filtered.size(),120);i++){
                final Channel ch=filtered.get(i); final int rowIndex=i;
                LinearLayout line=new LinearLayout(this); line.setOrientation(LinearLayout.HORIZONTAL); line.setGravity(Gravity.CENTER_VERTICAL); line.setPadding(0,ldp(3),0,ldp(3)); line.setFocusable(true); line.setFocusableInTouchMode(true);
                TextView tile=ltv(shortChannelLabel(ch.name,i),17,Typeface.BOLD); tile.setGravity(Gravity.CENTER); tile.setSingleLine(true); tile.setBackground(bg(tvLayout.guideCellColor,tvLayout.radius));
                if(showChannelLogos && ch.logo!=null&&!ch.logo.trim().isEmpty()){ ImageView im=new ImageView(this); im.setScaleType(ImageView.ScaleType.FIT_CENTER); im.setBackground(bg(tvLayout.guideCellColor,tvLayout.radius)); loadImage(ch.logo,im,false); LinearLayout.LayoutParams ilp=new LinearLayout.LayoutParams(ldp(rowLogoW),ldp(rowCellH)); ilp.setMargins(0,0,ldp(10),0); line.addView(im,ilp); }
                else{ LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(ldp(rowLogoW),ldp(rowCellH)); tlp.setMargins(0,0,ldp(10),0); line.addView(tile,tlp); }
                String n=(ch.name==null||ch.name.trim().isEmpty())?"Live TV":ch.name.trim();
                TextView now=ltv((ch.epgNow!=null&&!ch.epgNow.trim().isEmpty())?ch.epgNow:n,17,Typeface.BOLD); now.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); now.setSingleLine(true); now.setEllipsize(android.text.TextUtils.TruncateAt.END); now.setPadding(ldp(24),0,ldp(20),0); now.setBackground(bg(tvLayout.guideCellColor,tvLayout.radius)); LinearLayout.LayoutParams nlp=new LinearLayout.LayoutParams(ldp(nowCellW),ldp(rowCellH)); nlp.setMargins(0,0,ldp(10),0); line.addView(now,nlp);
                TextView next=ltv(ch.url==null||ch.url.trim().isEmpty()?"Source missing":((ch.epgNext!=null&&!ch.epgNext.trim().isEmpty())?ch.epgNext:"No guide data"),17,Typeface.BOLD); next.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); next.setSingleLine(true); next.setEllipsize(android.text.TextUtils.TruncateAt.END); next.setPadding(ldp(24),0,ldp(20),0); next.setBackground(bg(tvLayout.guideCellAltColor,tvLayout.radius)); LinearLayout.LayoutParams xlp=new LinearLayout.LayoutParams(ldp(nextCellW),ldp(rowCellH)); xlp.setMargins(0,0,ldp(10),0); line.addView(next,xlp);
                TextView later=ltv(ch.url==null||ch.url.trim().isEmpty()?"":((ch.epgLater!=null&&!ch.epgLater.trim().isEmpty())?ch.epgLater:""),17,Typeface.BOLD); later.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); later.setSingleLine(true); later.setPadding(ldp(24),0,ldp(20),0); later.setBackground(bg(tvLayout.guideCellAltColor,tvLayout.radius)); LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(ldp(laterCellW),ldp(rowCellH)); alp.setMargins(0,0,ldp(10),0); line.addView(later,alp);
                TextView far=ltv("",17,Typeface.BOLD); far.setBackground(bg(tvLayout.guideCellAltColor,tvLayout.radius)); line.addView(far,new LinearLayout.LayoutParams(ldp(farCellW),ldp(rowCellH)));
                line.setOnFocusChangeListener((v,has)->{ if(has){focusedRow[0]=rowIndex; activeChannel[0]=ch; updateInfo[0].run(); line.setBackground(bg(Color.argb(40,255,255,255),14)); now.setBackground(bg(tvLayout.guideFocusBgColor,tvLayout.radius)); now.setTextColor(tvLayout.guideFocusTextColor); line.animate().scaleX(1.006f).scaleY(1.006f).setDuration(90).start();} else {line.setBackgroundColor(Color.TRANSPARENT); now.setBackground(bg(tvLayout.guideCellColor,tvLayout.radius)); now.setTextColor(Color.WHITE); line.animate().scaleX(1f).scaleY(1f).setDuration(90).start();} });
                line.setOnClickListener(v->{ if(ch.url!=null&&!ch.url.trim().isEmpty())playChannel(ch); else Toast.makeText(this,"No playable stream URL loaded for "+ch.name,Toast.LENGTH_SHORT).show(); });
                line.setOnKeyListener((v,key,event)->{ if(event.getAction()!=KeyEvent.ACTION_DOWN)return false; int pos=guideViews.indexOf(v); if(key==KeyEvent.KEYCODE_DPAD_UP){ if(pos<=0){ if(!menuItems.isEmpty())menuItems.get(Math.min(1,menuItems.size()-1)).requestFocus(); } else guideViews.get(pos-1).requestFocus(); return true;} if(key==KeyEvent.KEYCODE_DPAD_DOWN){ if(pos<guideViews.size()-1)guideViews.get(pos+1).requestFocus(); return true;} if(key==KeyEvent.KEYCODE_DPAD_LEFT){ exitFullGuide[0].run(); if(!catViews.isEmpty())catViews.get(Math.min(catViews.size()-1,0)).requestFocus(); return true;} if(key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_ENTER){v.performClick();return true;} return false; });
                rows.addView(line,new LinearLayout.LayoutParams(-1,ldp(rowH))); guideViews.add(line);
            }
        };

        TextView head=ltv("YOUR CHANNELS",12,Typeface.BOLD); head.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); head.setTextColor(Color.argb(165,255,255,255)); head.setPadding(ldp(14),0,0,0); categoryPanel.addView(head,new LinearLayout.LayoutParams(-1,ldp(36)));
        for(int i=0;i<groups.size();i++){
            final String g=groups.get(i);
            if(i==2){TextView free=ltv("FREE CHANNELS FROM APPS",12,Typeface.BOLD);free.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);free.setTextColor(Color.argb(155,255,255,255));free.setPadding(ldp(14),0,0,0);LinearLayout.LayoutParams fl=new LinearLayout.LayoutParams(-1,ldp(44));fl.setMargins(0,ldp(6),0,0);categoryPanel.addView(free,fl);}
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setFocusable(true);row.setFocusableInTouchMode(true);row.setPadding(ldp(10),0,ldp(10),0);row.setBackground(bg(Color.TRANSPARENT,24));
            TextView icon=ltv(categoryIcon(g),20,Typeface.BOLD);icon.setGravity(Gravity.CENTER);icon.setBackground(bg(Color.argb(145,29,31,38),28));row.addView(icon,new LinearLayout.LayoutParams(ldp(tvLayout.categoryIconSize),ldp(tvLayout.categoryIconSize)));
            LinearLayout col=new LinearLayout(this);col.setOrientation(LinearLayout.VERTICAL);col.setGravity(Gravity.CENTER_VERTICAL);col.setPadding(ldp(18),0,0,0);TextView name=ltv(g,tvLayout.categoryTextSp,Typeface.BOLD);name.setSingleLine(true);name.setEllipsize(android.text.TextUtils.TruncateAt.END);col.addView(name,new LinearLayout.LayoutParams(-1,ldp(30)));TextView cnt=ltv(countGroup(g)+" channels",tvLayout.categorySubTextSp,Typeface.NORMAL);cnt.setTextColor(Color.argb(165,255,255,255));col.addView(cnt,new LinearLayout.LayoutParams(-1,ldp(26)));row.addView(col,new LinearLayout.LayoutParams(0,ldp(Math.max(48,tvLayout.categoryRowHeight-12)),1));
            row.setOnFocusChangeListener((v,has)->{row.setBackground(bg(has?tvLayout.categoryFocusBgColor:Color.TRANSPARENT,28));icon.setBackground(bg(has?Color.argb(95,210,213,220):Color.argb(145,29,31,38),28));icon.setTextColor(has?tvLayout.categoryFocusTextColor:Color.WHITE);name.setTextColor(has?tvLayout.categoryFocusTextColor:Color.WHITE);cnt.setTextColor(has?Color.argb(185,24,25,29):Color.argb(165,255,255,255));if(has){activeGroup[0]=g;repaintGuide[0].run();}});
            row.setOnClickListener(v->{activeGroup[0]=g;repaintGuide[0].run();if(!guideViews.isEmpty())guideViews.get(0).requestFocus();});
            row.setOnKeyListener((v,key,event)->{if(event.getAction()!=KeyEvent.ACTION_DOWN)return false;int pos=catViews.indexOf(v);if(key==KeyEvent.KEYCODE_DPAD_RIGHT){activeGroup[0]=g;repaintGuide[0].run();enterFullGuide[0].run();if(!guideViews.isEmpty())guideViews.get(0).requestFocus();return true;}if(key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_ENTER){activeGroup[0]=g;repaintGuide[0].run();if(!guideViews.isEmpty())guideViews.get(0).requestFocus();return true;}if(key==KeyEvent.KEYCODE_DPAD_DOWN){if(pos<catViews.size()-1)catViews.get(pos+1).requestFocus();return true;}if(key==KeyEvent.KEYCODE_DPAD_UP){if(pos>0)catViews.get(pos-1).requestFocus();else if(!menuItems.isEmpty())menuItems.get(Math.min(1,menuItems.size()-1)).requestFocus();return true;}return false;});
            LinearLayout.LayoutParams rlp2=new LinearLayout.LayoutParams(-1,ldp(tvLayout.categoryRowHeight));rlp2.setMargins(0,ldp(2),0,ldp(2));categoryPanel.addView(row,rlp2);catViews.add(row);
        }

        for(View menuView: menuItems){ menuView.setOnKeyListener((v,key,event)->{ if(event.getAction()!=KeyEvent.ACTION_DOWN)return false; int pos=menuItems.indexOf(v); if(key==KeyEvent.KEYCODE_DPAD_RIGHT){ menuItems.get((pos+1)%menuItems.size()).requestFocus(); return true;} if(key==KeyEvent.KEYCODE_DPAD_LEFT){ menuItems.get((pos-1+menuItems.size())%menuItems.size()).requestFocus(); return true;} if(key==KeyEvent.KEYCODE_DPAD_DOWN){ exitFullGuide[0].run(); if(!catViews.isEmpty())catViews.get(0).requestFocus(); return true;} if(key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_ENTER){ v.performClick(); return true;} return false; }); }
        repaintGuide[0].run(); updateInfo[0].run(); if(!catViews.isEmpty())catViews.get(0).requestFocus();
    }

    String shortChannelLabel(String name,int fallback){
        if(name==null||name.trim().isEmpty())return String.valueOf(100+fallback);
        String[] parts=name.trim().split("\\s+"); StringBuilder sb=new StringBuilder();
        for(String part:parts){ if(part.length()>0 && sb.length()<3) sb.append(Character.toUpperCase(part.charAt(0))); }
        return sb.length()==0?String.valueOf(100+fallback):sb.toString();
    }
    String categoryIcon(String g){String x=g==null?"":g.toLowerCase(Locale.US);if(x.contains("fav"))return "★";if(x.contains("movie"))return "▣";if(x.contains("news"))return "▤";if(x.contains("sport"))return "●";if(x.contains("kid"))return "☻";if(x.contains("music"))return "♫";if(x.contains("crime"))return "◆";return "▣";}
    int countGroup(String g){if(g==null)return channels.size();if(g.equals("All Channels"))return channels.size();int n=0;for(Channel c:channels){String cg=(c.group==null||c.group.trim().isEmpty())?"Other":c.group.trim();if(g.equals(cg)||(g.equals("Favorites")&&n<7))n++;}return n;}


    String shortHost(String url){
        try{ if(url==null||url.trim().isEmpty())return "Not configured"; Uri u=Uri.parse(url); String h=u.getHost(); return h==null?url:h+(u.getPort()>0?":"+u.getPort():""); }catch(Exception e){return "Configured";}
    }

    LinearLayout form(String title){
        ScrollView sv=new ScrollView(this);sv.setFillViewport(false);sv.setFocusable(false);sv.setFocusableInTouchMode(false);sv.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);sv.setSmoothScrollingEnabled(true);sv.setClipToPadding(false);sv.setPadding(0,0,0,ldp(120));editorScroll=sv;
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(ldp(72),ldp(100),ldp(72),ldp(110));
        sv.addView(p,new ScrollView.LayoutParams(-1,-2));root.addView(sv,new FrameLayout.LayoutParams(-1,-1));
        TextView h=ltv(title,34,Typeface.BOLD);h.setGravity(Gravity.LEFT);p.addView(h,new LinearLayout.LayoutParams(-1,ldp(70)));return p;
    }
    LinearLayout overlayForm(String title){
        View dim=new View(this);dim.setBackgroundColor(Color.argb(132,0,0,0));root.addView(dim,new FrameLayout.LayoutParams(-1,-1));
        ScrollView sv=new ScrollView(this);
        editorScroll=sv;
        sv.setFillViewport(false);
        sv.setFocusable(false);
        sv.setFocusableInTouchMode(false);
        sv.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        sv.setSmoothScrollingEnabled(true);
        sv.setClipToPadding(false);
        sv.setPadding(0,0,0,ldp(80));
        sv.setBackground(bg(Color.argb(232,9,13,22),28));
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(ldp(28),ldp(24),ldp(28),ldp(140));sv.addView(p,new ScrollView.LayoutParams(-1,-2));
        FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(ldp(870),-1,Gravity.RIGHT|Gravity.TOP);sp.setMargins(0,ldp(78),ldp(22),ldp(30));root.addView(sv,sp);
        TextView h=ltv(title,30,Typeface.BOLD);h.setGravity(Gravity.LEFT);p.addView(h,new LinearLayout.LayoutParams(-1,ldp(62)));return p;
    }
    void settingButton(LinearLayout p,String text,View.OnClickListener l){
        TextView b=ltv(text,17,Typeface.BOLD);applyFont(b,ui==null?0:ui.contentFontIndex(),Typeface.BOLD);
        b.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);b.setSingleLine(true);b.setFocusable(true);b.setFocusableInTouchMode(true);b.setPadding(ldp(28),0,ldp(28),0);b.setTextColor(Color.WHITE);
        b.setBackground(stroke(Color.argb(88,18,27,42),Color.argb(46,255,255,255)));b.setOnClickListener(l);
        b.setOnFocusChangeListener((v,has)->{b.setBackground(has?stroke(Color.argb(205,20,72,120),Color.argb(230,73,160,255)):stroke(Color.argb(88,18,27,42),Color.argb(46,255,255,255)));b.animate().scaleX(has?1.012f:1f).scaleY(has?1.012f:1f).setDuration(110).start();if(has)ensureEditorVisible(v);});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,ldp(68));lp.setMargins(0,ldp(6),0,ldp(10));p.addView(b,lp);
    }
    void ensureEditorVisible(View v){ if(editorScroll==null||v==null)return; editorScroll.postDelayed(()->{try{Rect r=new Rect();v.getDrawingRect(r);editorScroll.offsetDescendantRectToMyCoords(v,r);int pad=ldp(90);int top=r.top-pad;int bottom=r.bottom+pad;int sy=editorScroll.getScrollY();int sh=editorScroll.getHeight();if(top<sy)editorScroll.smoothScrollTo(0,Math.max(0,top));else if(bottom>sy+sh)editorScroll.smoothScrollTo(0,bottom-sh);}catch(Exception ignored){}},40); }
    String maskKey(String key){ if(key==null||key.trim().isEmpty())return "Not set"; String k=key.trim(); return k.length()<=6?"••••••":k.substring(0,3)+"••••"+k.substring(k.length()-3); }
    void cycleResolverMode(){ String m=backend.playbackResolverMode(); backend.savePlaybackResolverMode(m.equals("direct")?"auto":m.equals("auto")?"realdebrid":m.equals("realdebrid")?"torbox":"direct"); }
    void showSettings(){suppressRowAutoFocus=false;clear();nav.go(NavigationController.Screen.SETTINGS);backdrop();addMenu();LinearLayout p=form("Settings");TrailerSettings ts=trailerSettings();settingButton(p,"Pro Layout Editor",v->showLayoutEditor());settingButton(p,"Stremio Addon Manager: "+stremio.getManifestUrls().size()+" addons",v->showStremioAddonManager());settingButton(p,"Weather Location: "+backend.weatherLocation(),v->editTextScreen("Weather location",backend.weatherLocation(),x->{backend.saveWeatherLocation(x);showSettings();}));settingButton(p,"Playback Resolver Mode: "+backend.playbackResolverMode(),v->{cycleResolverMode();showSettings();});settingButton(p,"Real-Debrid API Key: "+maskKey(backend.realDebridApiKey()),v->editTextScreen("Real-Debrid API Key",backend.realDebridApiKey(),x->backend.saveRealDebridApiKey(x)));settingButton(p,"Torbox API Key: "+maskKey(backend.torboxApiKey()),v->editTextScreen("Torbox API Key",backend.torboxApiKey(),x->backend.saveTorboxApiKey(x)));settingButton(p,"Backend Base URL: "+backend.baseUrl(),v->editTextScreen("Backend Base URL",backend.baseUrl(),x->{backend.saveBaseUrl(x);loadBackendHomeRows();}));settingButton(p,"Live TV Guide Source: "+liveGuideSourceLabel(),v->{cycleLiveGuideSourceMode();showSettings();});settingButton(p,"XMLTV Guide URL: "+shortHost(backend.xmltvGuideUrl()),v->editTextScreen("XMLTV Guide URL",backend.xmltvGuideUrl(),x->{backend.saveXmltvGuideUrl(x);loadLiveTvSources();}));settingButton(p,"Live TV: Reload all sources",v->{loadLiveTvSources();Toast.makeText(this,"Reloading Live TV sources",Toast.LENGTH_SHORT).show();});settingButton(p,"Live TV: Clear guide cache",v->{clearGuideCache();Toast.makeText(this,"Guide cache cleared",Toast.LENGTH_SHORT).show();});settingButton(p,"M3U URL: "+shortHost(backend.m3uUrl()),v->editTextScreen("Live TV M3U URL",backend.m3uUrl(),x->{backend.saveM3uUrl(x);loadLiveTvSources();}));settingButton(p,"Channels DVR URL: "+shortHost(backend.channelsDvrUrl()),v->editTextScreen("Channels DVR Base URL",backend.channelsDvrUrl(),x->{backend.saveChannelsDvrUrl(x);loadLiveTvSources();}));settingButton(p,"Xtream Host: "+shortHost(backend.xtreamHost()),v->editTextScreen("Xtream Codes Host URL",backend.xtreamHost(),x->{backend.saveXtreamHost(x);loadLiveTvSources();}));settingButton(p,"Xtream Username: "+maskKey(backend.xtreamUsername()),v->editTextScreen("Xtream Username",backend.xtreamUsername(),x->{backend.saveXtreamUsername(x);loadLiveTvSources();}));settingButton(p,"Xtream Password: "+maskKey(backend.xtreamPassword()),v->editTextScreen("Xtream Password",backend.xtreamPassword(),x->{backend.saveXtreamPassword(x);loadLiveTvSources();}));settingButton(p,"Trailer Auto Popup: "+(ts.autoPopup?"ON":"OFF"),v->{saveTrailerSetting("autoPopup",!trailerSettings().autoPopup);showSettings();});settingButton(p,"Trailer Popup Delay: "+ts.delaySeconds+"s",v->{cycleTrailerDelay();showSettings();});settingButton(p,"Trailer Audio Starts Muted: "+(ts.muted?"ON":"OFF"),v->{saveTrailerSetting("muted",!trailerSettings().muted);showSettings();});settingButton(p,"Disable Trailers Completely: "+(ts.disabled?"ON":"OFF"),v->{saveTrailerSetting("disabled",!trailerSettings().disabled);showSettings();});settingButton(p,"Refresh Backend Catalog Rows",v->{loadBackendHomeRows();Toast.makeText(this,"Refreshing backend rows",Toast.LENGTH_SHORT).show();});settingButton(p,"4K UI: "+(ui.ui4k()?"Enabled":"Disabled"),v->{ui.save4k(!ui.ui4k());showSettings();});settingButton(p,"Hero UI Density: "+heroDensityName(ui.value("heroDensityMode",1)),v->{ui.saveValue("heroDensityMode",ui.value("heroDensityMode",1)==1?0:1);showSettings();});settingButton(p,"Live TV UI Density: "+liveTvDensityName(ui.value("liveTvDensityMode",0)),v->{ui.saveValue("liveTvDensityMode",(ui.value("liveTvDensityMode",0)+1)%2);showSettings();});
        settingButton(p,"Live TV Theme: "+liveTvThemeName(ui.value("liveTvThemeMode",0)),v->{ui.saveValue("liveTvThemeMode",(ui.value("liveTvThemeMode",0)+1)%6);showSettings();});
        settingButton(p,"Live TV red timeline: "+onOffName(ui.value("liveTvGuideRedLine",1)),v->{ui.saveValue("liveTvGuideRedLine",ui.value("liveTvGuideRedLine",1)==1?0:1);showSettings();});
        settingButton(p,"Live TV timeline labels: "+onOffName(ui.value("liveTvTimelineLabels",1)),v->{ui.saveValue("liveTvTimelineLabels",ui.value("liveTvTimelineLabels",1)==1?0:1);showSettings();});
        settingButton(p,"Live TV channel logos: "+onOffName(ui.value("liveTvChannelLogos",1)),v->{ui.saveValue("liveTvChannelLogos",ui.value("liveTvChannelLogos",1)==1?0:1);showSettings();});
        settingButton(p,"Live TV preview window: "+onOffName(ui.value("liveTvPreviewWindow",1)),v->{ui.saveValue("liveTvPreviewWindow",ui.value("liveTvPreviewWindow",1)==1?0:1);showSettings();});
        settingButton(p,"Live TV visible rows: "+ui.value("liveTvVisibleRows",5),v->{int r=ui.value("liveTvVisibleRows",5)+1;if(r>7)r=3;ui.saveValue("liveTvVisibleRows",r);showSettings();});
        settingButton(p,"Image Quality Mode: "+imageQualityModeName(ui.value("imageQualityMode",0)),v->{ui.saveValue("imageQualityMode",(ui.value("imageQualityMode",0)+1)%4);Toast.makeText(this,"Image quality: "+imageQualityModeName(ui.value("imageQualityMode",0)),Toast.LENGTH_SHORT).show();showSettings();});
        settingButton(p,"Extra artwork position: "+extraArtworkPositionName(ui.value("extraArtworkPosition",0)),v->{ui.saveValue("extraArtworkPosition",(ui.value("extraArtworkPosition",0)+1)%3);showSettings();});settingButton(p,"About / Build: "+BuildMarkers.VERSION,v->Toast.makeText(this,BuildMarkers.LOG_MARKER,Toast.LENGTH_SHORT).show());if(p.getChildCount()>1)p.getChildAt(1).requestFocus();}

    String liveTvThemeName(int mode){
        switch(Math.max(0,Math.min(5,mode))){
            case 1: return "TiviMate style";
            case 2: return "iMPlayer style";
            case 3: return "Arvio style";
            case 4: return "Minimal compact";
            case 5: return "Custom editable";
            default: return "Google Free TV style";
        }
    }
    String onOffName(int v){ return v==1?"ON":"OFF"; }

    String imageQualityModeName(int mode){
        switch(mode){
            case 1: return "Pro Quality";
            case 2: return "Advanced Quality";
            case 3: return "Ultra / Old App";
            default: return "Balanced";
        }
    }
    String heroLogoAlignName(int mode){
        return mode==0 ? "Manual offset" : "Align with hero text";
    }
    String liveGuideSourceLabel(){String m=backend.liveGuideSourceMode(); if("channelsdvr".equals(m))return "Channels DVR"; if("xtream".equals(m))return "Xtream Codes"; if("xmltv".equals(m))return "XMLTV Manual"; return "Auto";}
    void cycleLiveGuideSourceMode(){String m=backend.liveGuideSourceMode(); String n="auto"; if("auto".equals(m))n="channelsdvr"; else if("channelsdvr".equals(m))n="xtream"; else if("xtream".equals(m))n="xmltv"; else n="auto"; backend.saveLiveGuideSourceMode(n); loadLiveTvSources(); Toast.makeText(this,"Guide source: "+liveGuideSourceLabel(),Toast.LENGTH_SHORT).show();}

    void showStremioAddonManager(){
        suppressRowAutoFocus=false;clear();backdrop();addMenu();LinearLayout p=form("Stremio Addon Manager");
        TextView info=tv("Unlimited addon support: paste one manifest URL per line, or comma/space separated. Names and icons are fetched automatically from manifest.json.",16,Typeface.BOLD);
        info.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);info.setPadding(dp(12),0,dp(12),0);p.addView(info,new LinearLayout.LayoutParams(-1,dp(72)));
        settingButton(p,"Add / Edit Manifest URLs",v->editTextScreen("Stremio addon manifest URLs",stremio.getJsonLinks(),x->{stremio.saveJsonLinks(x);new Thread(()->{int ok=stremio.refreshAll();runOnUiThread(()->{Toast.makeText(this,"Refreshed "+ok+" addon manifests",Toast.LENGTH_SHORT).show();showStremioAddonManager();});}).start();}));
        settingButton(p,"Refresh Addon Names + Icons",v->{Toast.makeText(this,"Refreshing Stremio manifests…",Toast.LENGTH_SHORT).show();new Thread(()->{int ok=stremio.refreshAll();runOnUiThread(()->{Toast.makeText(this,"Refreshed "+ok+" addon manifests",Toast.LENGTH_SHORT).show();showStremioAddonManager();});}).start();});
        settingButton(p,"Back to Settings",v->showSettings());
        ArrayList<StremioAddonRegistry.AddonManifest> addons=stremio.getAddons();
        if(addons.isEmpty()){TextView none=tv("No addons yet. Add unlimited Stremio manifest.json URLs to enable catalogs and stream links.",18,Typeface.BOLD);none.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);none.setPadding(dp(18),0,dp(18),0);none.setBackground(bg(Color.argb(110,40,45,58),18));p.addView(none,new LinearLayout.LayoutParams(-1,dp(86)));}
        for(StremioAddonRegistry.AddonManifest a:addons){
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(12),dp(8),dp(12),dp(8));row.setFocusable(true);row.setFocusableInTouchMode(true);row.setBackground(stroke(Color.argb(88,18,27,42),Color.argb(46,255,255,255)));
            ImageView icon=new ImageView(this);icon.setScaleType(ImageView.ScaleType.FIT_CENTER);row.addView(icon,new LinearLayout.LayoutParams(dp(56),dp(56)));if(a.iconUrl!=null&&!a.iconUrl.isEmpty())loadImage(a.iconUrl,icon,false);
            TextView label=tv(a.name+((a.version==null||a.version.isEmpty())?"":"  •  v"+a.version)+"\n"+a.manifestUrl,15,Typeface.BOLD);label.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);label.setPadding(dp(16),0,0,0);row.addView(label,new LinearLayout.LayoutParams(0,dp(74),1));
            row.setOnFocusChangeListener((v,has)->{row.setBackground(has?stroke(Color.argb(205,20,72,120),Color.argb(230,73,160,255)):stroke(Color.argb(88,18,27,42),Color.argb(46,255,255,255)));if(has)ensureEditorVisible(v);});
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(86));lp.setMargins(0,dp(6),0,dp(8));p.addView(row,lp);
        }
        if(p.getChildCount()>1)p.getChildAt(1).requestFocus();
    }
    interface SaveText{void save(String s);} void editTextScreen(String title,String current,SaveText save){clear();backdrop();addMenu();LinearLayout p=form(title);EditText e=new EditText(this);e.setText(current);e.setSingleLine(false);e.setMinLines(3);e.setTextColor(Color.WHITE);e.setHintTextColor(Color.GRAY);e.setTextSize(18);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);e.setBackground(stroke(Color.argb(120,20,25,35),Color.argb(100,255,255,255)));p.addView(e,new LinearLayout.LayoutParams(-1,dp(160)));TextView done=btn("Save");done.setOnClickListener(v->{save.save(e.getText().toString());showSettings();});p.addView(done,new LinearLayout.LayoutParams(dp(180),dp(60)));e.requestFocus();}

    void editorHeader(LinearLayout p,String text){TextView h=tv(text.toUpperCase(Locale.US),13,Typeface.BOLD);h.setTextColor(Color.argb(210,150,205,255));h.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);h.setPadding(dp(8),dp(10),0,0);p.addView(h,new LinearLayout.LayoutParams(-1,dp(42)));}

    void showLayoutEditor(){
        suppressRowAutoFocus=true;
        showHome();
        nav.go(NavigationController.Screen.LAYOUT_EDITOR);
        LinearLayout p=overlayForm("Pro Layout Editor • Live Preview");
        settingButton(p,"✅ Live preview is ON — changes apply behind this panel",v->Toast.makeText(this,"Use arrows/OK. View Home closes editor.",Toast.LENGTH_SHORT).show());
        settingButton(p,"Save layout",v->{ui.saveLayoutSnapshot();Toast.makeText(this,"Layout saved",Toast.LENGTH_SHORT).show();});
        settingButton(p,"Reset all layout settings",v->{ui.resetLayoutDefaults();Toast.makeText(this,"Layout reset",Toast.LENGTH_SHORT).show();showLayoutEditor();});
        settingButton(p,"Reset card size only",v->{ui.resetCardSizeDefaults();Toast.makeText(this,"Card size reset",Toast.LENGTH_SHORT).show();showLayoutEditor();});
        settingButton(p,"View Home",v->{ui.saveLayoutSnapshot();suppressRowAutoFocus=false;showHome();});

        editorHeader(p,"Menu + Navigation");
        settingButton(p,"Menu position: "+ui.menuPosition(),v->{cycleMenuPosition();showLayoutEditor();});
        settingButton(p,"Search / Settings icons: "+ui.iconPlacement(),v->{cycleIconPlacement();showLayoutEditor();});
        settingButton(p,"Menu style: "+menuCompositionName(ui.menuCompositionMode()),v->{ui.saveValue("menuCompositionMode",(ui.menuCompositionMode()+1)%3);showLayoutEditor();});
        settingButton(p,"Search icon placement: "+placementName(ui.searchItemPlacement()),v->{ui.saveValue("searchItemPlacement",(ui.searchItemPlacement()+1)%4);showLayoutEditor();});
        settingButton(p,"Settings icon placement: "+placementName(ui.settingsItemPlacement()),v->{ui.saveValue("settingsItemPlacement",(ui.settingsItemPlacement()+1)%4);showLayoutEditor();});
        addSlider(p,"Top menu left / right","topMenuOffsetDp",-220,220,ui.topMenuOffsetDp());

        editorHeader(p,"Rows + Cards");
        settingButton(p,"Row title text: "+(ui.rowTitles()?"Shown":"Hidden"),v->{boolean next=!ui.rowTitles();ui.saveRowTitles(next);ui.saveValue("rowTitleVisibility",next?1:0);showLayoutEditor();});
        settingButton(p,"Row title icons: "+onOff(ui.rowTitleIconsEnabled()),v->{ui.saveValue("rowTitleIconsEnabled",ui.rowTitleIconsEnabled()==1?0:1);showLayoutEditor();});
        addSlider(p,"Preview cards","previewCardCount",1,8,ui.previewCardCount());
        addSlider(p,"Row vertical position","rowTopDp",300,620,ui.rowTopDp());
        addSlider(p,"Row left / right","rowLeftDp",0,120,ui.rowLeftDp());
        addSlider(p,"Card width","cardWidthDp",190,420,ui.cardWidthDp());
        addSlider(p,"Card height","cardHeightDp",110,260,ui.cardHeightDp());
        addSlider(p,"Card spacing","cardSpacingDp",0,40,ui.cardSpacingDp());
        addSlider(p,"Rounded corners","cornerRadiusDp",8,44,ui.cornerRadiusDp());
        addSlider(p,"Dim unfocused cards","dimUnfocusedPercent",0,70,ui.dimUnfocusedPercent());

        editorHeader(p,"Focus Effects");
        settingButton(p,"Effect profile: "+effectProfileName(ui.effectProfileIndex()),v->{ui.saveValue("effectProfileIndex",(ui.effectProfileIndex()+1)%5);showLayoutEditor();});
        addSlider(p,"Focused card scale","focusedScalePercent",100,120,ui.focusedScalePercent());
        addSlider(p,"Glow strength","glowStrengthPercent",0,100,ui.glowStrengthPercent());
        addSlider(p,"Pulse effect","pulseStrengthPercent",0,100,ui.pulseStrengthPercent());
        addSlider(p,"Focus ring on/off","focusRingEnabled",0,1,ui.focusRingEnabled());
        addSlider(p,"Focus ring thickness","focusRingThicknessDp",0,8,ui.focusRingThicknessDp());
        addSlider(p,"Focus ring color","focusRingColorIndex",0,5,ui.focusRingColorIndex());
        addSlider(p,"3D tilt effect","cardTiltPercent",0,100,ui.cardTiltPercent());
        addSlider(p,"Card lift","cardLiftDp",0,24,ui.cardLiftDp());
        addSlider(p,"Focus bounce","focusBouncePercent",0,100,ui.focusBouncePercent());
        settingButton(p,"Glass card mode: "+onOff(ui.glassCardMode()),v->{ui.saveValue("glassCardMode",ui.glassCardMode()==1?0:1);showLayoutEditor();});
        settingButton(p,"Hover info overlay: "+onOff(ui.hoverInfoOverlay()),v->{ui.saveValue("hoverInfoOverlay",ui.hoverInfoOverlay()==1?0:1);showLayoutEditor();});

        editorHeader(p,"Hero Text + Fonts");
        settingButton(p,"Top menu font: "+fontName(ui.topMenuFontIndex()),v->{ui.saveValue("topMenuFontIndex",(ui.topMenuFontIndex()+1)%12);showLayoutEditor();});
        settingButton(p,"Hero font: "+fontName(ui.heroFontIndex()),v->{ui.saveValue("heroFontIndex",(ui.heroFontIndex()+1)%12);applyVisibleHeroTheme();showLayoutEditor();});
        settingButton(p,"Content/card font: "+fontName(ui.contentFontIndex()),v->{ui.saveValue("contentFontIndex",(ui.contentFontIndex()+1)%12);showLayoutEditor();});
        settingButton(p,"Hero text mode: "+heroTextModeName(ui.value("heroTextMode",0)),v->{ui.saveValue("heroTextMode",(ui.value("heroTextMode",0)+1)%6);applyVisibleHeroTheme();showLayoutEditor();});
        settingButton(p,"Hero text style: "+heroTextStyleName(ui.value("heroTextStyle",0)),v->{ui.saveValue("heroTextStyle",(ui.value("heroTextStyle",0)+1)%11);applyVisibleHeroTheme();showLayoutEditor();});
        settingButton(p,"Hero text size: "+heroTextScaleName(ui.value("heroTextScale",2)),v->{ui.saveValue("heroTextScale",(ui.value("heroTextScale",2)+1)%5);applyVisibleHeroTheme();showLayoutEditor();});
        settingButton(p,"Hero text theme/layout: "+heroTextThemeName(ui.value("heroTextTheme",0)),v->{ui.saveValue("heroTextTheme",(ui.value("heroTextTheme",0)+1)%6);applyVisibleHeroTheme();showLayoutEditor();});
        addSlider(p,"Hero letter spacing","heroLetterSpacing",-8,18,ui.value("heroLetterSpacing",0));
        settingButton(p,"Dynamic hero rotation: "+heroRotationName(ui.value("heroRotationMode",0)),v->{ui.saveValue("heroRotationMode",(ui.value("heroRotationMode",0)+1)%3);showLayoutEditor();});
        addSlider(p,"Hero rotation interval sec","heroRotationIntervalSec",5,30,ui.value("heroRotationIntervalSec",15));
        addSlider(p,"Hero text left / right","heroTextLeftDp",-80,220,ui.heroTextLeftDp());
        addSlider(p,"Hero text up / down","heroTextTopDp",-80,180,ui.heroTextTopDp());
        addSlider(p,"Background dim on focus","backgroundDimOnFocusPercent",0,45,ui.backgroundDimOnFocusPercent());
        addSlider(p,"Bottom safe space","bottomSafeDp",24,160,ui.bottomSafeDp());
        settingButton(p,"4K UI: "+(ui.ui4k()?"Enabled":"Disabled"),v->{ui.save4k(!ui.ui4k());showLayoutEditor();});
        settingButton(p,"Hero UI Density: "+heroDensityName(ui.value("heroDensityMode",1)),v->{ui.saveValue("heroDensityMode",ui.value("heroDensityMode",1)==1?0:1);showLayoutEditor();});

        editorHeader(p,"Hero Logo Position");
        settingButton(p,"Hero logo alignment: "+heroLogoAlignName(ui.value("heroLogoAlignWithText",1)),v->{ui.saveValue("heroLogoAlignWithText",ui.value("heroLogoAlignWithText",1)==1?0:1);applyVisibleHeroTheme();showLayoutEditor();});
        addSlider(p,"Hero logo left / right","heroLogoLeftDp",-260,420,ui.heroLogoLeftDp());
        addSlider(p,"Hero logo up / down","heroLogoTopDp",-180,260,ui.heroLogoTopDp());
        addSlider(p,"Hero logo width","heroLogoWidthDp",180,720,ui.heroLogoWidthDp());
        addSlider(p,"Hero logo height","heroLogoHeightDp",50,240,ui.heroLogoHeightDp());

        editorHeader(p,"Status Hub");
        settingButton(p,"Status Hub: "+onOff(ui.statusHubEnabled()),v->{ui.saveValue("statusHubEnabled",ui.statusHubEnabled()==1?0:1);showLayoutEditor();});
        settingButton(p,"Status time: "+onOff(ui.statusHubTimeEnabled()),v->{ui.saveValue("statusHubTimeEnabled",ui.statusHubTimeEnabled()==1?0:1);showLayoutEditor();});
        settingButton(p,"Status weather: "+onOff(ui.statusHubWeatherEnabled()),v->{ui.saveValue("statusHubWeatherEnabled",ui.statusHubWeatherEnabled()==1?0:1);showLayoutEditor();});
        settingButton(p,"Favorite notifications: "+onOff(ui.statusHubNotificationsEnabled()),v->{ui.saveValue("statusHubNotificationsEnabled",ui.statusHubNotificationsEnabled()==1?0:1);showLayoutEditor();});
        settingButton(p,"Status theme: "+statusThemeName(ui.statusHubTheme()),v->{ui.saveValue("statusHubTheme",(ui.statusHubTheme()+1)%4);showLayoutEditor();});
        addSlider(p,"Status width","statusHubWidthDp",120,560,ui.statusHubWidthDp());
        addSlider(p,"Status height","statusHubHeightDp",30,90,ui.statusHubHeightDp());
        addSlider(p,"Status move left / right","statusHubRightDp",0,900,ui.statusHubRightDp());
        addSlider(p,"Status move up / down","statusHubBottomDp",0,500,ui.statusHubBottomDp());
        addSlider(p,"Status text size","statusHubTextSizeSp",10,30,ui.statusHubTextSizeSp());

        editorHeader(p,"Image Quality");
        settingButton(p,"Image quality mode: "+imageQualityModeName(ui.value("imageQualityMode",0)),v->{ui.saveValue("imageQualityMode",(ui.value("imageQualityMode",0)+1)%4);applyVisibleHeroTheme();showLayoutEditor();});
        TextView iqWarn=tv("Balanced is safest. Pro/Advanced/Ultra use more memory for sharper 4K logos, row art and extra artwork.",13,Typeface.NORMAL);iqWarn.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);p.addView(iqWarn,new LinearLayout.LayoutParams(-1,dp(54)));

        editorHeader(p,"Extra Artwork Slot");
        settingButton(p,"Extra artwork slot: "+onOff(ui.extraArtworkEnabled()),v->{ui.saveValue("extraArtworkEnabled",ui.extraArtworkEnabled()==1?0:1);showLayoutEditor();});
        settingButton(p,"Extra artwork type: "+extraArtworkName(ui.extraArtworkType()),v->{ui.saveValue("extraArtworkType",(ui.extraArtworkType()+1)%15);showLayoutEditor();});
        settingButton(p,"Extra artwork position: "+extraArtworkPositionName(ui.value("extraArtworkPosition",0)),v->{ui.saveValue("extraArtworkPosition",(ui.value("extraArtworkPosition",0)+1)%3);applyVisibleHeroTheme();showLayoutEditor();});
        addSlider(p,"Extra artwork X","extraArtworkXdp",0,1200,ui.extraArtworkXdp());
        addSlider(p,"Extra artwork Y","extraArtworkYdp",0,620,ui.extraArtworkYdp());
        addSlider(p,"Extra artwork width","extraArtworkWidthDp",80,620,ui.extraArtworkWidthDp());
        addSlider(p,"Extra artwork height","extraArtworkHeightDp",60,420,ui.extraArtworkHeightDp());
        addSlider(p,"Extra artwork opacity","extraArtworkOpacityPercent",0,100,ui.extraArtworkOpacityPercent());
        addSlider(p,"Extra artwork depth / 3D pop","extraArtworkDepthPercent",0,100,ui.extraArtworkDepthPercent());
        settingButton(p,"Extra artwork 3D tilt effect: "+extraArtworkTiltName(ui.value("extraArtworkTiltEnabled",0)),v->{ui.saveValue("extraArtworkTiltEnabled",ui.value("extraArtworkTiltEnabled",0)==1?0:1);applyVisibleHeroTheme();showLayoutEditor();});
        addSlider(p,"Extra artwork tilt strength","extraArtworkTiltPercent",0,100,ui.value("extraArtworkTiltPercent",28));
        settingButton(p,"Reset extra artwork slot",v->{ui.saveValue("extraArtworkEnabled",1);ui.saveValue("extraArtworkType",1);ui.saveValue("extraArtworkXdp",760);ui.saveValue("extraArtworkYdp",120);ui.saveValue("extraArtworkWidthDp",240);ui.saveValue("extraArtworkHeightDp",160);ui.saveValue("extraArtworkOpacityPercent",95);ui.saveValue("extraArtworkTiltEnabled",0);ui.saveValue("extraArtworkTiltPercent",28);applyVisibleHeroTheme();showLayoutEditor();});
        if(p.getChildCount()>1)p.getChildAt(1).requestFocus();
    }
    void cycleMenuPosition(){String m=ui.menuPosition();ui.saveMenuPosition(m.equals("left")?"center":m.equals("center")?"right":"left");}
    void cycleIconPlacement(){String m=ui.iconPlacement();ui.saveIconPlacement(m.equals("right")?"inline":m.equals("inline")?"left":m.equals("left")?"hidden":"right");}
    void addSlider(LinearLayout parent,String label,String key,int min,int max,int current){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setFocusable(true);
        box.setFocusableInTouchMode(true);
        box.setPadding(dp(16),dp(6),dp(16),dp(8));
        box.setBackground(stroke(Color.argb(54,20,25,35),Color.argb(45,255,255,255)));
        TextView title=tv(label+": "+current,15,Typeface.BOLD);
        title.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        TextView hint=tv("◀ / ▶ adjust    OK save preview",11,Typeface.NORMAL);
        hint.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        hint.setTextColor(Color.argb(185,255,255,255));
        ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        bar.setMax(max-min);
        bar.setProgress(Math.max(0,Math.min(max-min,current-min)));
        box.addView(title,new LinearLayout.LayoutParams(-1,dp(30)));
        box.addView(bar,new LinearLayout.LayoutParams(-1,dp(22)));
        box.addView(hint,new LinearLayout.LayoutParams(-1,dp(24)));
        final int[] val=new int[]{Math.max(min,Math.min(max,current))};
        Runnable apply=()->{ title.setText(label+": "+val[0]); bar.setProgress(val[0]-min); ui.saveValue(key,val[0]); if(key!=null && key.startsWith("hero")) applyVisibleHeroTheme(); };
        box.setOnFocusChangeListener((v,has)->{ box.animate().scaleX(has?1.018f:1f).scaleY(has?1.018f:1f).setDuration(100).start(); box.setBackground(has?stroke(Color.argb(120,18,72,126),Color.argb(210,64,160,255)):stroke(Color.argb(54,20,25,35),Color.argb(45,255,255,255))); if(has)ensureEditorVisible(box); });
        box.setOnKeyListener((v,k,e)->{ if(e.getAction()!=KeyEvent.ACTION_DOWN)return false; int step=(max-min)>500?25:(max-min)>120?10:1; if(k==KeyEvent.KEYCODE_DPAD_LEFT){val[0]=Math.max(min,val[0]-step);apply.run();return true;} if(k==KeyEvent.KEYCODE_DPAD_RIGHT){val[0]=Math.min(max,val[0]+step);apply.run();return true;} if(k==KeyEvent.KEYCODE_DPAD_CENTER||k==KeyEvent.KEYCODE_ENTER){ui.saveLayoutSnapshot();Toast.makeText(this,label+" saved",Toast.LENGTH_SHORT).show();return true;} return false; });
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(94));lp.setMargins(0,dp(5),0,dp(10));parent.addView(box,lp);
    }

    void showSearch(){suppressRowAutoFocus=false;clear();backdrop();addMenu();LinearLayout p=form("Search");EditText e=new EditText(this);e.setHint("Search movies, shows, channels");e.setTextColor(Color.WHITE);e.setHintTextColor(Color.GRAY);e.setTextSize(22);e.setSingleLine(true);e.setBackground(stroke(Color.argb(110,20,25,35),Color.argb(100,255,255,255)));p.addView(e,new LinearLayout.LayoutParams(-1,dp(70)));e.requestFocus();}

    void loadLiveTvSources(){
        new Thread(()->{
            ArrayList<Channel> merged=new ArrayList<>();
            int m3uCount=0,dvrCount=0,xtreamCount=0;
            String guideMode=backend.liveGuideSourceMode();
            boolean useM3u="auto".equals(guideMode)||"xmltv".equals(guideMode);
            boolean useDvr="auto".equals(guideMode)||"channelsdvr".equals(guideMode)||"xmltv".equals(guideMode);
            boolean useXtream="auto".equals(guideMode)||"xtream".equals(guideMode)||"xmltv".equals(guideMode);
            try{ String m=backend.m3uUrl(); if(useM3u&&m!=null&&!m.trim().isEmpty()){ ArrayList<Channel> a=fetchM3uChannels(m.trim(),"M3U"); m3uCount=a.size(); merged.addAll(a); } }catch(Exception e){AppLogger.mark("LIVE_TV_V081: m3u failed "+e.getMessage());}
            try{ String d=backend.channelsDvrUrl(); if(useDvr&&d!=null&&!d.trim().isEmpty()){ ArrayList<Channel> a=fetchChannelsDvrChannels(d.trim()); dvrCount=a.size(); merged.addAll(a); } }catch(Exception e){AppLogger.mark("LIVE_TV_V081: channels_dvr failed "+e.getMessage());}
            try{ if(useXtream){ ArrayList<Channel> a=fetchXtreamChannels(); xtreamCount=a.size(); merged.addAll(a); } }catch(Exception e){AppLogger.mark("LIVE_TV_V081: xtream failed "+e.getMessage());}
            LinkedHashMap<String,Channel> dedup=new LinkedHashMap<>();
            for(Channel c:merged){ if(c==null||c.url==null||c.url.trim().isEmpty())continue; String key=(c.name+"|"+c.url).toLowerCase(Locale.US); if(!dedup.containsKey(key))dedup.put(key,c); }
            ArrayList<Channel> finalList=new ArrayList<>(dedup.values());
            int cachedMatches=applyGuideCache(finalList,guideMode);
            AppLogger.mark("LIVE_TV_V081: scale_verify after_channel_merge total="+finalList.size()+" cached_matches="+cachedMatches+" mode="+guideMode);
            try{
                String manual=backend.xmltvGuideUrl();
                if(manual!=null&&!manual.trim().isEmpty() && ("auto".equals(guideMode)||"xmltv".equals(guideMode))){
                    applyXmltvGuide(finalList,manual.trim(),"Manual XMLTV");
                    AppLogger.mark("LIVE_TV_V081: manual_xmltv_applied mode="+guideMode+" channels="+finalList.size());
                }
            }catch(Exception e){AppLogger.mark("LIVE_TV_V081: manual_xmltv_failed "+e.getMessage());}
            applyBasicGuidePlaceholders(finalList);
            int hydratedCount=countHydratedGuideRows(finalList);
            writeGuideCache(finalList,guideMode);
            AppLogger.mark("LIVE_TV_V081: guide_hydration channels="+finalList.size()+" hydrated="+hydratedCount+" m3u="+m3uCount+" dvr="+dvrCount+" xtream="+xtreamCount+" mode="+guideMode);
            int fm=m3uCount,fd=dvrCount,fx=xtreamCount,total=finalList.size(); String gm=guideMode;
            runOnUiThread(()->{ channels.clear(); channels.addAll(finalList); AppLogger.mark("LIVE_TV_V081: loaded sources mode="+gm+" m3u="+fm+" dvr="+fd+" xtream="+fx+" total="+total); if(total>0)Toast.makeText(this,"Loaded "+total+" Live TV channels",Toast.LENGTH_LONG).show(); try{if(nav!=null&&nav.current()==NavigationController.Screen.LIVE_TV&&!livePlayerActive)showLiveTv();}catch(Exception ignored){} });
        }).start();
    }

    ArrayList<Channel> fetchChannelsDvrChannels(String base)throws Exception{
        ArrayList<Channel> out=new ArrayList<>();
        String b=trimSlash(base);
        // Channels DVR exposes a generated M3U for all tuners at /devices/ANY/channels.m3u.
        String[] candidates=new String[]{b+"/devices/ANY/channels.m3u", b+"/devices/ANY/channels.m3u?format=ts", b+"/devices/ANY/channels"};
        for(String u:candidates){
            try{
                if(u.endsWith("/channels")){
                    JSONArray arr=httpGetJsonArray(u,new HashMap<>());
                    if(arr!=null){
                        for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i); if(o==null)continue; String num=o.optString("Number",o.optString("GuideNumber",String.valueOf(i+1))); String name=o.optString("Name",o.optString("GuideName","Channel "+num)); String logo=o.optString("Image",o.optString("Logo","")); String group=o.optString("Group","Channels DVR"); String stream=b+"/devices/ANY/channels/"+URLEncoder.encode(num,"UTF-8")+"/stream.mpg?format=ts&codec=copy"; Channel ch=new Channel(name,group,stream,logo); ch.number=num; ch.tvgId=o.optString("ID",o.optString("GuideName",name)); ch.source="Channels DVR"; out.add(ch);}
                    }
                } else out.addAll(fetchM3uChannels(u,"Channels DVR"));
                if(!out.isEmpty()){ try{applyChannelsDvrXmltvGuide(out,b);}catch(Exception ge){AppLogger.mark("LIVE_TV_V081: Channels DVR XMLTV guide failed "+ge.getMessage());applyBasicGuidePlaceholders(out);} return out;}
            }catch(Exception e){AppLogger.mark("LIVE_TV_V081: Channels DVR candidate failed "+u+" :: "+e.getMessage());}
        }
        return out;
    }

    ArrayList<Channel> fetchXtreamChannels()throws Exception{
        ArrayList<Channel> out=new ArrayList<>();
        String host=backend.xtreamHost(), user=backend.xtreamUsername(), pass=backend.xtreamPassword();
        if(host==null||host.trim().isEmpty()||user==null||user.trim().isEmpty()||pass==null||pass.trim().isEmpty())return out;
        String h=trimSlash(host.trim());
        String auth="username="+URLEncoder.encode(user.trim(),"UTF-8")+"&password="+URLEncoder.encode(pass.trim(),"UTF-8");
        HashMap<String,String> cats=new HashMap<>();
        try{JSONArray ca=httpGetJsonArray(h+"/player_api.php?"+auth+"&action=get_live_categories",new HashMap<>()); if(ca!=null)for(int i=0;i<ca.length();i++){JSONObject o=ca.optJSONObject(i); if(o!=null)cats.put(o.optString("category_id"),o.optString("category_name","Xtream"));}}catch(Exception ignored){}
        JSONArray streams=httpGetJsonArray(h+"/player_api.php?"+auth+"&action=get_live_streams",new HashMap<>());
        if(streams==null)return out;
        for(int i=0;i<streams.length();i++){
            JSONObject o=streams.optJSONObject(i); if(o==null)continue;
            String id=o.optString("stream_id",""); if(id.isEmpty())continue;
            String name=o.optString("name","Xtream Channel"); String logo=o.optString("stream_icon",""); String cat=o.optString("category_id",""); String group=cats.containsKey(cat)?cats.get(cat):"Xtream";
            String ext=o.optString("container_extension","ts"); if(ext==null||ext.trim().isEmpty())ext="ts";
            String url=h+"/live/"+URLEncoder.encode(user.trim(),"UTF-8")+"/"+URLEncoder.encode(pass.trim(),"UTF-8")+"/"+id+"."+ext;
            Channel ch=new Channel(name,group,url,logo); ch.streamId=id; ch.tvgId=o.optString("epg_channel_id",o.optString("tvg_id",name)); ch.source="Xtream"; out.add(ch);
        }
        try{applyXtreamShortEpg(out,h,auth,120);}catch(Exception e){AppLogger.mark("LIVE_TV_V081: Xtream EPG failed "+e.getMessage());applyBasicGuidePlaceholders(out);}
        return out;
    }

    ArrayList<Channel> fetchM3uChannels(String url,String sourceLabel)throws Exception{
        ArrayList<Channel> out=new ArrayList<>();
        URLConnection cn=new URL(url).openConnection(); cn.setConnectTimeout(12000); cn.setReadTimeout(30000); cn.setRequestProperty("User-Agent","DebridChannelsLiveTV/0.8.0");
        BufferedReader br=new BufferedReader(new InputStreamReader(cn.getInputStream()));
        String line,name="Channel",group=sourceLabel==null?"Other":sourceLabel,logo="",tvgId="",chno="",xmltvUrl="";
        while((line=br.readLine())!=null){
            line=line.trim();
            if(line.startsWith("#EXTM3U")){String x=grab(line,"url-tvg=\""); if(x==null||x.isEmpty())x=grab(line,"x-tvg-url=\""); if(x==null||x.isEmpty())x=grab(line,"tvg-url=\""); if(x!=null&&!x.isEmpty())xmltvUrl=resolveRelativeUrl(url,x);}
            else if(line.startsWith("#EXTINF")){int ix=line.lastIndexOf(',');name=ix>=0?line.substring(ix+1).trim():"Channel";String gt=grab(line,"group-title=\"");group=(gt==null||gt.trim().isEmpty())?(sourceLabel==null?"Other":sourceLabel):gt;logo=grab(line,"tvg-logo=\"");tvgId=grab(line,"tvg-id=\"");if(tvgId==null||tvgId.isEmpty())tvgId=grab(line,"tvg-name=\"");chno=grab(line,"tvg-chno=\"");if(chno==null||chno.isEmpty())chno=grab(line,"channel-number=\"");}
            else if(line.startsWith("http://")||line.startsWith("https://")){Channel ch=new Channel(name,group,line,logo); ch.tvgId=tvgId; ch.number=chno; ch.source=sourceLabel==null?"M3U":sourceLabel; out.add(ch);}
        }
        try{br.close();}catch(Exception ignored){}
        if(!xmltvUrl.isEmpty()){try{applyXmltvGuide(out,xmltvUrl,"M3U XMLTV");}catch(Exception e){AppLogger.mark("LIVE_TV_V081: M3U XMLTV failed "+e.getMessage());}}
        applyBasicGuidePlaceholders(out);
        return out;
    }

    void applyChannelsDvrXmltvGuide(ArrayList<Channel> out,String base)throws Exception{
        String b=trimSlash(base);
        // v0.7.9: memory-safe guide windows for huge 2500+ channel DVR libraries. Never request 14 days by default.
        String[] urls=new String[]{b+"/devices/ANY/guide/xmltv?duration=21600", b+"/devices/ANY/guide/xmltv?duration=43200", b+"/devices/ANY/guide/xmltv?duration=86400"};
        Exception last=null;
        for(String u:urls){try{applyXmltvGuide(out,u,"Channels DVR XMLTV"); applyBasicGuidePlaceholders(out); return;}catch(Exception e){last=e; AppLogger.mark("LIVE_TV_V081: xmltv_candidate_failed "+safeUrlForLog(u)+" :: "+e.getMessage());}}
        if(last!=null)throw last;
    }
    void applyXtreamShortEpg(ArrayList<Channel> out,String host,String auth,int limit){
        if(out==null||out.isEmpty())return; int max=Math.min(limit,out.size());
        for(int i=0;i<max;i++){Channel ch=out.get(i); if(ch.streamId==null||ch.streamId.isEmpty())continue; try{
            JSONObject o=httpGetJsonObject(host+"/player_api.php?"+auth+"&action=get_short_epg&stream_id="+URLEncoder.encode(ch.streamId,"UTF-8"),new HashMap<>());
            JSONArray epg=o==null?null:o.optJSONArray("epg_listings"); if(epg==null&&o!=null)epg=o.optJSONArray("epg");
            if(epg!=null&&epg.length()>0){JSONObject now=epg.optJSONObject(0), next=epg.length()>1?epg.optJSONObject(1):null, later=epg.length()>2?epg.optJSONObject(2):null; ch.epgNow=decodeXtreamTitle(now); ch.epgNext=decodeXtreamTitle(next); ch.epgLater=decodeXtreamTitle(later); if(now!=null)ch.epgDescription=decodeBase64Maybe(now.optString("description",now.optString("plot","")));}
        }catch(Exception ignored){}}
        applyBasicGuidePlaceholders(out);
    }
    String decodeXtreamTitle(JSONObject o){ if(o==null)return""; return decodeBase64Maybe(o.optString("title",o.optString("name",""))); }
    String decodeBase64Maybe(String v){ if(v==null)return""; String x=v.trim(); if(x.isEmpty())return""; try{ if(x.matches("^[A-Za-z0-9+/=]{8,}$")){ byte[] b=android.util.Base64.decode(x,android.util.Base64.DEFAULT); String d=new String(b,"UTF-8").trim(); if(!d.isEmpty()&&d.length()<400)return d; } }catch(Exception ignored){} return x; }
    void applyXmltvGuide(ArrayList<Channel> out,String xmlUrl,String label)throws Exception{
        if(out==null||out.isEmpty()||xmlUrl==null||xmlUrl.trim().isEmpty())return;
        HashMap<String,Channel> map=new HashMap<>();
        for(Channel c:out){for(String k:channelKeys(c)) if(k!=null&&!k.isEmpty()&&!map.containsKey(k))map.put(k,c);}
        long now=System.currentTimeMillis();
        int matched=0, programmes=0, channelAliases=0;
        int maxProgrammes=Math.max(3500, Math.min(65000, out.size()*32));
        HttpURLConnection conn=null; InputStream input=null;
        try{
            conn=(HttpURLConnection)new URL(xmlUrl).openConnection();
            conn.setConnectTimeout(12000); conn.setReadTimeout(75000);
            conn.setRequestProperty("Accept","application/xml,text/xml,text/plain,*/*");
            conn.setRequestProperty("Accept-Encoding","identity");
            conn.setRequestProperty("User-Agent","DebridChannelsLiveTV/0.8.0");
            input=conn.getInputStream();
            XmlPullParser parser=Xml.newPullParser();
            parser.setInput(new BufferedInputStream(input,32768), null);
            String currentChannelId=""; ArrayList<String> displayNames=new ArrayList<>();
            String progChannel="", progStart="", progStop="", progTitle="", progDesc=""; boolean inProgramme=false;
            int event=parser.getEventType();
            while(event!=XmlPullParser.END_DOCUMENT){
                if(event==XmlPullParser.START_TAG){
                    String tag=parser.getName();
                    if("channel".equalsIgnoreCase(tag)){currentChannelId=parser.getAttributeValue(null,"id"); displayNames.clear();}
                    else if("display-name".equalsIgnoreCase(tag) && currentChannelId!=null && !currentChannelId.isEmpty()){try{String name=parser.nextText(); if(name!=null&&!name.trim().isEmpty())displayNames.add(htmlUnescape(name.trim()));}catch(Exception ignored){}}
                    else if("programme".equalsIgnoreCase(tag)){inProgramme=true; progChannel=parser.getAttributeValue(null,"channel"); progStart=parser.getAttributeValue(null,"start"); progStop=parser.getAttributeValue(null,"stop"); progTitle=""; progDesc="";}
                    else if(inProgramme && "title".equalsIgnoreCase(tag)){try{progTitle=htmlUnescape(parser.nextText());}catch(Exception ignored){}}
                    else if(inProgramme && "desc".equalsIgnoreCase(tag)){try{progDesc=htmlUnescape(parser.nextText());}catch(Exception ignored){}}
                }else if(event==XmlPullParser.END_TAG){
                    String tag=parser.getName();
                    if("channel".equalsIgnoreCase(tag)){
                        Channel matchedChannel=null;
                        for(String n:displayNames){matchedChannel=map.get(normKey(n)); if(matchedChannel!=null)break;}
                        if(matchedChannel==null){for(String n:displayNames){String nk=normKey(n); if(nk.isEmpty())continue; for(String k:new ArrayList<String>(map.keySet())){ if(k.equals(nk)||k.contains(nk)||nk.contains(k)){matchedChannel=map.get(k);break;} } if(matchedChannel!=null)break;}}
                        if(matchedChannel!=null && currentChannelId!=null && !currentChannelId.isEmpty()){map.put(normKey(currentChannelId),matchedChannel);channelAliases++;}
                        currentChannelId=""; displayNames.clear();
                    }else if("programme".equalsIgnoreCase(tag)){
                        programmes++;
                        if(applyXmltvProgrammeParsed(progChannel,progStart,progStop,progTitle,progDesc,map,now))matched++;
                        inProgramme=false;
                        if(programmes>=maxProgrammes || guideLooksHydrated(out))break;
                    }
                }
                event=parser.next();
            }
        }finally{try{if(input!=null)input.close();}catch(Exception ignored){} if(conn!=null)conn.disconnect();}
        AppLogger.mark("LIVE_TV_V081: applied_xmltv_pull label="+label+" aliases="+channelAliases+" programmes="+programmes+" matched="+matched+" url="+safeUrlForLog(xmlUrl));
    }

    boolean applyXmltvProgrammeParsed(String chId,String startAttr,String stopAttr,String title,String desc,HashMap<String,Channel> map,long now){
        try{
            if(chId==null||chId.isEmpty()||title==null||title.trim().isEmpty())return false;
            Channel c=map.get(normKey(chId)); if(c==null)return false;
            title=htmlUnescape(title.trim()); desc=htmlUnescape(desc==null?"":desc.trim());
            long start=parseXmltvTime(startAttr), stop=parseXmltvTime(stopAttr);
            if(start>0&&stop>0){
                if(now>=start&&now<stop){c.epgNow=title; c.epgDescription=desc; c.epgTime=fmtClock(start)+" - "+fmtClock(stop); return true;}
                if(start>=now){
                    if(c.epgNext==null||c.epgNext.isEmpty()||"No guide data".equals(c.epgNext)){c.epgNext=title; return true;}
                    if(c.epgLater==null||c.epgLater.isEmpty()){c.epgLater=title; return true;}
                }
            }else{
                if(c.epgNow==null||c.epgNow.isEmpty()){c.epgNow=title;c.epgDescription=desc;return true;}
                if(c.epgNext==null||c.epgNext.isEmpty()||"No guide data".equals(c.epgNext)){c.epgNext=title;return true;}
                if(c.epgLater==null||c.epgLater.isEmpty()){c.epgLater=title;return true;}
            }
        }catch(Throwable ignored){}
        return false;
    }

    boolean applyXmltvChannelAliasBlock(String block,HashMap<String,Channel> map){
        try{
            int close=block.indexOf('>'); if(close<0)return false;
            String attrs=block.substring(0,close+1);
            String body=block.substring(close+1);
            String id=xmlAttr(attrs,"id"); if(id.isEmpty())return false;
            Channel matched=null;
            ArrayList<String> names=new ArrayList<>();
            java.util.regex.Matcher m=java.util.regex.Pattern.compile("<display-name[^>]*>(.*?)</display-name>",java.util.regex.Pattern.DOTALL|java.util.regex.Pattern.CASE_INSENSITIVE).matcher(body);
            while(m.find()) names.add(htmlUnescape(m.group(1).replaceAll("<[^>]+>"," ").trim()));
            for(String n:names){ matched=map.get(normKey(n)); if(matched!=null)break; }
            if(matched==null){
                for(String n:names){String nk=normKey(n); if(nk.isEmpty())continue; for(String k:new ArrayList<String>(map.keySet())){ if(k.equals(nk)||k.contains(nk)||nk.contains(k)){matched=map.get(k);break;} } if(matched!=null)break;}
            }
            if(matched!=null){map.put(normKey(id),matched);return true;}
        }catch(Throwable ignored){}
        return false;
    }

    boolean applyXmltvProgrammeBlock(String programme,HashMap<String,Channel> map,long now){
        try{
            int close=programme.indexOf('>'); if(close<0)return false;
            String attrs=programme.substring(0,close+1);
            String body=programme.substring(close+1);
            String chId=xmlAttr(attrs,"channel"); if(chId.isEmpty())return false;
            Channel c=map.get(normKey(chId)); if(c==null)return false;
            String title=xmlTag(body,"title"); if(title.isEmpty())return false;
            String desc=xmlTag(body,"desc");
            long start=parseXmltvTime(xmlAttr(attrs,"start")), stop=parseXmltvTime(xmlAttr(attrs,"stop"));
            if(start>0&&stop>0){
                if(now>=start&&now<stop){c.epgNow=title; c.epgDescription=desc; c.epgTime=fmtClock(start)+" - "+fmtClock(stop); return true;}
                if(start>=now){
                    if(c.epgNext==null||c.epgNext.isEmpty()){c.epgNext=title; return true;}
                    if(c.epgLater==null||c.epgLater.isEmpty()){c.epgLater=title; return true;}
                }
            }else{
                if(c.epgNow==null||c.epgNow.isEmpty()){c.epgNow=title;c.epgDescription=desc;return true;}
                if(c.epgNext==null||c.epgNext.isEmpty()){c.epgNext=title;return true;}
                if(c.epgLater==null||c.epgLater.isEmpty()){c.epgLater=title;return true;}
            }
        }catch(Throwable ignored){}
        return false;
    }

    boolean guideLooksHydrated(ArrayList<Channel> out){
        if(out==null||out.isEmpty())return true;
        int checked=0, hydrated=0;
        int limit=Math.min(out.size(),160);
        for(Channel c:out){
            if(c==null)continue; checked++;
            if((c.epgNow!=null&&!c.epgNow.isEmpty())&&(c.epgNext!=null&&!c.epgNext.isEmpty()))hydrated++;
            if(checked>=limit)break;
        }
        return checked>0 && hydrated>=Math.max(10,checked*7/10);
    }
    ArrayList<String> channelKeys(Channel c){ArrayList<String> keys=new ArrayList<>(); if(c==null)return keys; String[] vals=new String[]{c.tvgId,c.number,c.name,c.name==null?"":c.name.replace(" HD",""),c.name==null?"":c.name.replace("-HD","")}; for(String v:vals){String k=normKey(v); if(!k.isEmpty()&&!keys.contains(k))keys.add(k);} return keys;}
    String normKey(String v){if(v==null)return"";return v.toLowerCase(Locale.US).replaceAll("&amp;","&").replaceAll("[^a-z0-9]+","");}
    String xmlAttr(String attrs,String key){try{java.util.regex.Matcher m=java.util.regex.Pattern.compile(key+"=\\\"([^\\\"]*)\\\"",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(attrs);return m.find()?htmlUnescape(m.group(1)):"";}catch(Exception e){return"";}}
    String xmlTag(String body,String tag){try{java.util.regex.Matcher m=java.util.regex.Pattern.compile("<"+tag+"[^>]*>(.*?)</"+tag+">",java.util.regex.Pattern.DOTALL|java.util.regex.Pattern.CASE_INSENSITIVE).matcher(body);return m.find()?htmlUnescape(m.group(1).replaceAll("<[^>]+>"," ").trim()):"";}catch(Exception e){return"";}}
    String htmlUnescape(String s){if(s==null)return"";return s.replace("&amp;","&").replace("&quot;","\"").replace("&apos;","'").replace("&lt;","<").replace("&gt;",">").trim();}
    long parseXmltvTime(String s){if(s==null||s.trim().isEmpty())return 0;String x=s.trim();String[] fmts=new String[]{"yyyyMMddHHmmss Z","yyyyMMddHHmmssZ","yyyyMMddHHmmss"};for(String f:fmts){try{return new java.text.SimpleDateFormat(f,Locale.US).parse(x).getTime();}catch(Exception ignored){}}return 0;}
    String fmtClock(long t){try{return new java.text.SimpleDateFormat("h:mm a",Locale.US).format(new java.util.Date(t));}catch(Exception e){return"";}}
    String resolveRelativeUrl(String base,String ref){try{if(ref.startsWith("http://")||ref.startsWith("https://"))return ref;return new URL(new URL(base),ref).toString();}catch(Exception e){return ref;}}
    String httpGetText(String url)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(45000);c.setRequestProperty("Accept","application/xml,text/xml,text/plain,*/*");c.setRequestProperty("User-Agent","DebridChannelsLiveTV/0.8.0");try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);return out.toString("UTF-8");}}
    JSONObject httpGetJsonObject(String url,Map<String,String> headers){HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod("GET");c.setConnectTimeout(9000);c.setReadTimeout(18000);c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","DebridChannelsLiveTV/0.8.0");for(Map.Entry<String,String> e:headers.entrySet())c.setRequestProperty(e.getKey(),e.getValue());String body=readHttpBody(c);if(c.getResponseCode()<200||c.getResponseCode()>=300||body.isEmpty())return null;return new JSONObject(body);}catch(Exception e){AppLogger.mark("HTTP JSON object get failed: "+e.getMessage()+" url="+url);return null;}finally{if(c!=null)c.disconnect();}}

    int countHydratedGuideRows(ArrayList<Channel> out){
        if(out==null)return 0; int n=0;
        for(Channel c:out){ if(c!=null && c.epgNow!=null && !c.epgNow.trim().isEmpty() && c.epgNext!=null && !c.epgNext.trim().isEmpty() && !"No guide data".equals(c.epgNext)) n++; }
        return n;
    }
    File guideCacheFile(String mode){ String m=(mode==null||mode.trim().isEmpty()?"auto":mode.trim().toLowerCase(Locale.US)).replaceAll("[^a-z0-9_-]","_"); File dir=guideCache!=null?guideCache.dir():new File(getFilesDir(),"guide-cache-v5"); if(!dir.exists())dir.mkdirs(); return new File(dir,"guide_"+m+".json"); }
    int applyGuideCache(ArrayList<Channel> out,String mode){ if(out==null||out.isEmpty())return 0; File f=guideCacheFile(mode); if(!f.exists()||f.length()<8)return 0; try{ String txt=readSmallFile(f,2*1024*1024); JSONObject root=new JSONObject(txt); long saved=root.optLong("savedAt",0L); if(saved>0 && System.currentTimeMillis()-saved>6L*60L*60L*1000L){AppLogger.mark("LIVE_TV_V081: guide_cache_stale file="+f.getName());return 0;} JSONObject rows=root.optJSONObject("rows"); if(rows==null)return 0; int hits=0; for(Channel c:out){ if(c==null)continue; JSONObject o=null; for(String k:channelKeys(c)){ if(rows.has(k)){o=rows.optJSONObject(k);break;} } if(o==null)continue; c.epgNow=o.optString("now",c.epgNow); c.epgNext=o.optString("next",c.epgNext); c.epgLater=o.optString("later",c.epgLater); c.epgDescription=o.optString("desc",c.epgDescription); c.epgTime=o.optString("time",c.epgTime); hits++; } AppLogger.mark("LIVE_TV_V081: guide_cache_apply file="+f.getName()+" hits="+hits+" channels="+out.size()); return hits; }catch(Exception e){AppLogger.mark("LIVE_TV_V081: guide_cache_apply_failed "+e.getMessage());return 0;} }
    void writeGuideCache(ArrayList<Channel> out,String mode){ if(out==null||out.isEmpty())return; try{ JSONObject root=new JSONObject(); root.put("savedAt",System.currentTimeMillis()); root.put("mode",mode==null?"auto":mode); JSONObject rows=new JSONObject(); int saved=0; for(Channel c:out){ if(c==null)continue; boolean has=(c.epgNow!=null&&!c.epgNow.trim().isEmpty()) || (c.epgNext!=null&&!c.epgNext.trim().isEmpty()&&!"No guide data".equals(c.epgNext)); if(!has)continue; JSONObject o=new JSONObject(); o.put("now",c.epgNow==null?"":c.epgNow); o.put("next",c.epgNext==null?"":c.epgNext); o.put("later",c.epgLater==null?"":c.epgLater); o.put("desc",c.epgDescription==null?"":c.epgDescription); o.put("time",c.epgTime==null?"":c.epgTime); for(String k:channelKeys(c)){ if(!k.isEmpty()) rows.put(k,o); } saved++; if(saved>=5000)break; } root.put("rows",rows); File f=guideCacheFile(mode); writeSmallFile(f,root.toString()); AppLogger.mark("LIVE_TV_V081: guide_cache_write file="+f.getName()+" rows="+saved+" bytes="+f.length()); }catch(Exception e){AppLogger.mark("LIVE_TV_V081: guide_cache_write_failed "+e.getMessage());} }
    void clearGuideCache(){ try{ File dir=guideCache!=null?guideCache.dir():new File(getFilesDir(),"guide-cache-v5"); File[] files=dir.listFiles(); if(files!=null)for(File f:files)if(f!=null&&f.getName().startsWith("guide_"))f.delete(); AppLogger.mark("LIVE_TV_V081: guide_cache_cleared"); }catch(Exception e){AppLogger.mark("LIVE_TV_V081: guide_cache_clear_failed "+e.getMessage());} }
    String readSmallFile(File f,int maxBytes)throws Exception{ ByteArrayOutputStream out=new ByteArrayOutputStream(); try(InputStream in=new FileInputStream(f)){byte[] buf=new byte[8192];int n,total=0;while((n=in.read(buf))>0){total+=n;if(total>maxBytes)throw new IOException("cache too large");out.write(buf,0,n);}} return out.toString("UTF-8"); }
    void writeSmallFile(File f,String txt)throws Exception{ File tmp=new File(f.getParentFile(),f.getName()+".tmp"); try(OutputStream out=new FileOutputStream(tmp)){out.write(txt.getBytes("UTF-8"));} if(!tmp.renameTo(f)){try(OutputStream out=new FileOutputStream(f)){out.write(txt.getBytes("UTF-8"));} tmp.delete();} }
    void applyBasicGuidePlaceholders(ArrayList<Channel> out){ if(out==null)return; for(Channel c:out){ if(c.epgNow==null||c.epgNow.isEmpty())c.epgNow=c.name; if(c.epgNext==null||c.epgNext.isEmpty()||"Guide data loading".equals(c.epgNext))c.epgNext="No guide data"; if(c.epgLater==null||c.epgLater.isEmpty())c.epgLater=""; }}

    JSONArray httpGetJsonArray(String url,Map<String,String> headers){HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod("GET");c.setConnectTimeout(12000);c.setReadTimeout(30000);c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","DebridChannelsLiveTV/0.8.0");for(Map.Entry<String,String> e:headers.entrySet())c.setRequestProperty(e.getKey(),e.getValue());String body=readHttpBody(c);if(c.getResponseCode()<200||c.getResponseCode()>=300||body.isEmpty())return null;return new JSONArray(body);}catch(Exception e){AppLogger.mark("HTTP JSON array get failed: "+e.getMessage()+" url="+url);return null;}finally{if(c!=null)c.disconnect();}}
    String trimSlash(String v){if(v==null)return"";String x=v.trim();while(x.endsWith("/"))x=x.substring(0,x.length()-1);return x;}

    void loadM3u(String url){new Thread(()->{try{ArrayList<Channel> out=new ArrayList<>();BufferedReader br=new BufferedReader(new InputStreamReader(new URL(url).openStream()));String line,name="Channel",group="Other",logo="";while((line=br.readLine())!=null){if(line.startsWith("#EXTINF")){int ix=line.lastIndexOf(',');name=ix>=0?line.substring(ix+1).trim():"Channel";group=grab(line,"group-title=\"");logo=grab(line,"tvg-logo=\"");}else if(line.startsWith("http")){out.add(new Channel(name,group,line.trim(),logo));}}if(!out.isEmpty())runOnUiThread(()->{channels.clear();channels.addAll(out);Toast.makeText(this,"Loaded "+out.size()+" channels",Toast.LENGTH_LONG).show();try{if(nav!=null&&nav.current()==NavigationController.Screen.LIVE_TV)showLiveTv();}catch(Exception ignored){}});}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"M3U load failed: "+e.getMessage(),Toast.LENGTH_LONG).show());}}).start();}
    String grab(String line,String key){int s=line.indexOf(key);if(s<0)return "";s+=key.length();int e=line.indexOf('"',s);return e>s?line.substring(s,e):"";}

    void loadBackendHomeRowsLegacy(){new Thread(()->{try{String txt=httpGet(joinUrl(backend.baseUrl(),"/api/home"));JSONObject rootObj=new JSONObject(txt);JSONArray rails=rootObj.optJSONArray("rails");if(rails==null||rails.length()==0)return;ArrayList<HomeRow> loaded=new ArrayList<>();ArrayList<Movie> flat=new ArrayList<>();for(int r=0;r<rails.length();r++){JSONObject ro=rails.optJSONObject(r);if(ro==null)continue;HomeRow row=new HomeRow(ro.optString("title",ro.optString("name","Catalog")));row.id=ro.optString("slug",ro.optString("id",""));JSONArray items=ro.optJSONArray("items");if(items==null)continue;for(int i=0;i<items.length();i++){JSONObject it=items.optJSONObject(i);if(it==null)continue;Movie m=new Movie(it.optString("title",it.optString("name","Untitled")),metaFrom(it,ro),"");m.id=it.optString("id",it.optString("externalId",it.optString("imdbId","")));m.type=it.optString("type",it.optString("streamLookupType","movie"));m.poster=abs(it.optString("poster",it.optString("posterUrl","")));m.background=abs(it.optString("background",it.optString("backdrop",it.optString("backdropUrl",m.poster))));m.logo=abs(it.optString("logo",it.optString("clearlogo",it.optString("logoUrl",""))));m.banner=abs(it.optString("banner",it.optString("thumb",m.logo)));m.overview=it.optString("overview",it.optString("description",""));m.year=it.optString("year","");row.items.add(m);flat.add(m);}if(!row.items.isEmpty())loaded.add(row);}if(!loaded.isEmpty())runOnUiThread(()->{homeRows.clear();homeRows.addAll(loaded);movies.clear();movies.addAll(flat);showHome();Toast.makeText(this,"Loaded backend artwork rows: "+flat.size(),Toast.LENGTH_SHORT).show();});}catch(Exception e){AppLogger.mark("Backend home load failed: "+e.getMessage());}}).start();}
    void loadBackendHomeRows(){new Thread(()->{try{if(!loadBackendHomeRowsFresh()){try{httpPost(joinUrl(backend.baseUrl(),"/api/refresh"),"{}");}catch(Exception re){AppLogger.mark("Backend refresh failed: "+re.getMessage());}loadBackendHomeRowsFresh();}}catch(Exception e){AppLogger.mark("Backend artwork load failed: "+e.getMessage());runOnUiThread(()->Toast.makeText(this,"Backend artwork load failed: "+e.getMessage(),Toast.LENGTH_LONG).show());}}).start();}
    boolean loadBackendHomeRowsFresh()throws Exception{String txt=httpGet(joinUrl(backend.baseUrl(),"/api/home"));JSONObject rootObj=new JSONObject(txt);JSONArray rails=rootObj.optJSONArray("rails");if(rails==null||rails.length()==0)return false;ArrayList<HomeRow> loaded=new ArrayList<>();ArrayList<Movie> flat=new ArrayList<>();for(int r=0;r<rails.length();r++){JSONObject ro=rails.optJSONObject(r);if(ro==null)continue;HomeRow row=new HomeRow(ro.optString("title",ro.optString("name","Catalog")));row.id=ro.optString("slug",ro.optString("id",""));JSONArray items=ro.optJSONArray("items");if(items==null)continue;for(int i=0;i<items.length();i++){JSONObject it=items.optJSONObject(i);if(it==null)continue;Movie m=new Movie(it.optString("title",it.optString("name","Untitled")),metaFrom(it,ro),"");m.id=it.optString("id",it.optString("externalId",it.optString("imdbId",it.optString("imdb_id",""))));m.type=it.optString("type",it.optString("streamLookupType","movie"));m.poster=artUrl(it,"poster","posterUrl","poster_url","thumbnail","thumb","image");m.background=artUrl(it,"background","backdrop","backdropUrl","backgroundUrl","fanart","fanartUrl");if(m.background.isEmpty())m.background=m.poster;m.logo=artUrl(it,"logo","clearlogo","clearLogo","clear_logo","clearlogoUrl","logoUrl");m.banner=artUrl(it,"banner","landscape","landscapeUrl","landscape_url","card","cardUrl","card_url","horizontal","horizontalUrl");m.overview=it.optString("overview",it.optString("description",it.optString("summary","")));m.year=it.optString("year","");m.tag=it.optString("tag",it.optString("label",ro.optString("title","FEATURED")));m.imdbRating=ratingFrom(it,"imdbRating","imdb_rating","imdbScore","imdb","imdb_vote_average");m.tmdbRating=ratingFrom(it,"tmdbRating","tmdb_rating","tmdbScore","tmdb","vote_average");row.items.add(m);flat.add(m);}if(!row.items.isEmpty())loaded.add(row);}if(loaded.isEmpty())return false;runOnUiThread(()->{homeRows.clear();homeRows.addAll(loaded);movies.clear();movies.addAll(flat);showHome();Toast.makeText(this,"Loaded backend artwork rows: "+flat.size(),Toast.LENGTH_SHORT).show();});return true;}
    String ratingFrom(JSONObject it,String...keys){for(String k:keys){String v=it.optString(k,"");if(v!=null&&!v.trim().isEmpty()&&!v.equals("0")&&!v.equals("0.0"))return normalizeRating(v);}JSONObject ratings=it.optJSONObject("ratings");if(ratings!=null){for(String k:keys){String v=ratings.optString(k,"");if(v!=null&&!v.trim().isEmpty()&&!v.equals("0")&&!v.equals("0.0"))return normalizeRating(v);}}return "";}
    String normalizeRating(String v){try{String cleaned=v.replaceAll("[^0-9.]","");double d=Double.parseDouble(cleaned);if(d>10)d=d/10.0;return String.format(Locale.US,"%.1f",d);}catch(Exception e){return v.replaceAll("[^0-9.]","");}}
    String artUrl(JSONObject it,String... keys){for(String k:keys){String v=it.optString(k,"");if(v!=null&&!v.trim().isEmpty())return abs(v);}JSONObject art=it.optJSONObject("artwork");if(art!=null){for(String k:keys){String v=art.optString(k,"");if(v!=null&&!v.trim().isEmpty())return abs(v);}}JSONObject images=it.optJSONObject("images");if(images!=null){for(String k:keys){String v=images.optString(k,"");if(v!=null&&!v.trim().isEmpty())return abs(v);}}return "";}
    String httpPost(String u,String body)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(45000);c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Accept","application/json");try(OutputStream os=c.getOutputStream()){os.write(body.getBytes("UTF-8"));}try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);return out.toString("UTF-8");}}

    String metaFrom(JSONObject it,JSONObject ro){String y=it.optString("year","");String source=it.optString("source",ro.optString("source","Stremio Catalog"));return (y.isEmpty()?source:(y+" • "+source));}
    String joinUrl(String base,String path){if(base==null||base.trim().isEmpty())base="http://192.168.100.55:8181";base=base.trim();while(base.endsWith("/"))base=base.substring(0,base.length()-1);return base+path;}
    String abs(String u){if(u==null)return "";u=u.trim();if(u.isEmpty())return "";if(u.startsWith("http://")||u.startsWith("https://"))return u;if(u.startsWith("/"))return joinUrl(backend.baseUrl(),u);return u;}
    String httpGet(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);c.setRequestProperty("Accept","application/json");try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);return out.toString("UTF-8");}}
    void loadImage(String url,ImageView target,boolean cinematic){
        url=abs(url);
        if(target==null)return;
        if(url.isEmpty()){target.setImageDrawable(null);return;}
        final String fu=url;
        target.setTag(fu);
        Bitmap cached=imageCache.get(fu);
        if(cached!=null){target.setImageBitmap(cached);target.setAlpha(1f);return;}
        if(failedArtworkUrls.contains(fu))return;
        imageExecutor.execute(()->{
            try{
                HttpURLConnection c=(HttpURLConnection)new URL(fu).openConnection();
                c.setConnectTimeout(4500);
                c.setReadTimeout(9500);
                c.setRequestProperty("User-Agent","DebridChannelsAndroidTV/0.7.8-ImageQualityModes");
                c.setInstanceFollowRedirects(true);
                int code=c.getResponseCode();
                if(code<200||code>=300){failedArtworkUrls.add(fu);AppLogger.mark("Artwork HTTP "+code+" url="+fu);return;}
                int qualityMode=Math.max(0,Math.min(3,ui.value("imageQualityMode",0)));
                int maxBytes;
                if(qualityMode==3) maxBytes = cinematic ? (52*1024*1024) : (28*1024*1024);
                else if(qualityMode==2) maxBytes = cinematic ? (36*1024*1024) : (18*1024*1024);
                else if(qualityMode==1) maxBytes = cinematic ? (26*1024*1024) : (12*1024*1024);
                else maxBytes = cinematic ? (18*1024*1024) : (8*1024*1024);
                ByteArrayOutputStream out=new ByteArrayOutputStream(Math.min(Math.max(4096,c.getContentLength()),1024*1024));
                InputStream in=new BufferedInputStream(c.getInputStream(),32768);
                byte[] buf=new byte[32768]; int n,total=0;
                while((n=in.read(buf))>0){ total+=n; if(total>maxBytes){failedArtworkUrls.add(fu); AppLogger.mark("ARTWORK_QUALITY_V080: skipped oversized bytes="+total+" url="+fu); try{in.close();}catch(Exception ignored){} return;} out.write(buf,0,n); }
                try{in.close();}catch(Exception ignored){}
                byte[] data=out.toByteArray();
                BitmapFactory.Options bounds=new BitmapFactory.Options(); bounds.inJustDecodeBounds=true; BitmapFactory.decodeByteArray(data,0,data.length,bounds);
                int maxW=1280, maxH=720;
                if(qualityMode==0){
                    if(target==heroBackdropImage){maxW=3840;maxH=2160;}
                    else if(target==heroLogoImage||target==heroBannerImage){maxW=2560;maxH=1440;}
                    else if(cinematic){maxW=1920;maxH=1080;}
                } else if(qualityMode==1){
                    if(target==heroBackdropImage){maxW=3840;maxH=2160;}
                    else if(target==heroLogoImage||target==heroBannerImage){maxW=3200;maxH=1800;}
                    else {maxW=1920;maxH=1080;}
                } else if(qualityMode==2){
                    if(target==heroBackdropImage){maxW=4096;maxH=2304;}
                    else if(target==heroLogoImage||target==heroBannerImage){maxW=3840;maxH=2160;}
                    else {maxW=2560;maxH=1440;}
                } else {
                    // Ultra / old-app full-source mode: keep source resolution whenever memory allows.
                    maxW=8192; maxH=8192;
                }
                int sample=1;
                while(bounds.outWidth/sample>maxW || bounds.outHeight/sample>maxH) sample*=2;
                BitmapFactory.Options opts=new BitmapFactory.Options();
                opts.inPreferredConfig=Bitmap.Config.ARGB_8888;
                opts.inDither=true;
                opts.inScaled=false;
                opts.inSampleSize=Math.max(1,sample);
                Bitmap bm=BitmapFactory.decodeByteArray(data,0,data.length,opts);
                if(bm!=null){
                    imageCache.put(fu,bm);
                    runOnUiThread(()->{
                        if(!fu.equals(String.valueOf(target.getTag())))return;
                        if(cinematic){
                            target.animate().cancel();
                            target.setImageBitmap(bm);
                            target.setAlpha(0f);
                            target.animate().alpha(1f).setDuration(180).start();
                            AppLogger.mark("ARTWORK_QUALITY_V080: mode="+imageQualityModeName(qualityMode)+" cinematic="+cinematic+" src="+bounds.outWidth+"x"+bounds.outHeight+" decoded="+bm.getWidth()+"x"+bm.getHeight()+" url="+fu);
                        } else {
                            target.setImageBitmap(bm);
                            target.setAlpha(1f);
                            AppLogger.mark("ARTWORK_QUALITY_V080: mode="+imageQualityModeName(qualityMode)+" row/logo src="+bounds.outWidth+"x"+bounds.outHeight+" decoded="+bm.getWidth()+"x"+bm.getHeight()+" url="+fu);
                        }
                    });
                } else failedArtworkUrls.add(fu);
            }catch(Throwable e){failedArtworkUrls.add(fu);AppLogger.mark("Artwork load failed: "+e.getClass().getSimpleName()+": "+e.getMessage()+" url="+fu);}
        });
    }

    void applyPlaybackQualityPreferences(ExoPlayer player, String reason){
        if(player==null)return;
        try{
            player.setTrackSelectionParameters(
                player.getTrackSelectionParameters().buildUpon()
                    .setMaxVideoSize(Integer.MAX_VALUE,Integer.MAX_VALUE)
                    .setForceHighestSupportedBitrate(true)
                    .build()
            );
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true);
            AppLogger.mark("PLAYBACK_UPGRADE_V080: highest_quality_tracks audio_focus reason="+reason);
        }catch(Throwable t){AppLogger.mark("PLAYBACK_UPGRADE_V080: preference_failed "+t.getMessage());}
    }

    void applyFrameRateAndResolutionHints(PlayerView view, String reason){
        try{
            if(view!=null)view.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
            getWindow().getDecorView().post(()->AppLogger.mark("PLAYBACK_UPGRADE_V080: frame_rate_resolution_hooks_ready reason="+reason+" display="+getResources().getDisplayMetrics().widthPixels+"x"+getResources().getDisplayMetrics().heightPixels));
        }catch(Throwable ignored){}
    }



    String extraArtworkTiltName(int enabled){
        return enabled==1 ? "Enabled" : "Disabled";
    }

    String enabledDisabledName(int enabled){
        return enabled==1 ? "Enabled" : "Disabled";
    }

}
