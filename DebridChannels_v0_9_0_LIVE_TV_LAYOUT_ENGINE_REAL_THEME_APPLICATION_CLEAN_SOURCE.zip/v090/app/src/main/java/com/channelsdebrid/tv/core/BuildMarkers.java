package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.9.0 Live TV Layout Engine + Real Theme Application";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.9.0_livetv_layout_engine_real_theme_application_clean_base";
}
