package com.channelsdebrid.tv.settings

import android.content.Context

class SettingsRepository(context: Context) {
    private val prefs = context.getSharedPreferences("channels_debrid_settings", Context.MODE_PRIVATE)

    fun loadTmdb() = TmdbSettings(
        apiKey = prefs.getString("tmdb_api_key", SettingsScaffold.defaultTmdb.apiKey).orEmpty(),
        region = prefs.getString("tmdb_region", SettingsScaffold.defaultTmdb.region).orEmpty(),
        language = prefs.getString("tmdb_language", SettingsScaffold.defaultTmdb.language).orEmpty()
    )

    fun saveTmdb(value: TmdbSettings) {
        prefs.edit()
            .putString("tmdb_api_key", value.apiKey)
            .putString("tmdb_region", value.region)
            .putString("tmdb_language", value.language)
            .apply()
    }

    fun loadCatalogs() = CatalogSettings(
        trendingMoviesEnabled = prefs.getBoolean("catalog_trending_movies", true),
        popularMoviesEnabled = prefs.getBoolean("catalog_popular_movies", true),
        trendingShowsEnabled = prefs.getBoolean("catalog_trending_shows", true),
        popularShowsEnabled = prefs.getBoolean("catalog_popular_shows", true),
        platformRowsEnabled = prefs.getBoolean("catalog_platform_rows", true),
        stremioCatalogRowsEnabled = prefs.getBoolean("catalog_stremio_rows", true)
    )

    fun saveCatalogs(value: CatalogSettings) {
        prefs.edit()
            .putBoolean("catalog_trending_movies", value.trendingMoviesEnabled)
            .putBoolean("catalog_popular_movies", value.popularMoviesEnabled)
            .putBoolean("catalog_trending_shows", value.trendingShowsEnabled)
            .putBoolean("catalog_popular_shows", value.popularShowsEnabled)
            .putBoolean("catalog_platform_rows", value.platformRowsEnabled)
            .putBoolean("catalog_stremio_rows", value.stremioCatalogRowsEnabled)
            .apply()
    }

    fun loadPrimaryAddon(): StremioAddonSettings {
        val defaultAddon = SettingsScaffold.defaultAddons.first()
        return StremioAddonSettings(
            id = prefs.getString("stremio_id", defaultAddon.id).orEmpty(),
            name = prefs.getString("stremio_name", defaultAddon.name).orEmpty(),
            manifestUrl = prefs.getString("stremio_manifest", defaultAddon.manifestUrl).orEmpty(),
            enabled = prefs.getBoolean("stremio_enabled", defaultAddon.enabled)
        )
    }

    fun savePrimaryAddon(value: StremioAddonSettings) {
        prefs.edit()
            .putString("stremio_id", value.id)
            .putString("stremio_name", value.name)
            .putString("stremio_manifest", value.manifestUrl)
            .putBoolean("stremio_enabled", value.enabled)
            .apply()
    }

    fun loadChannelsDvr() = ChannelsDvrSettings(
        autoDetect = prefs.getBoolean("dvr_auto_detect", true),
        baseUrl = prefs.getString("dvr_base_url", "").orEmpty(),
        username = prefs.getString("dvr_username", "").orEmpty(),
        password = prefs.getString("dvr_password", "").orEmpty()
    )

    fun saveChannelsDvr(value: ChannelsDvrSettings) {
        prefs.edit()
            .putBoolean("dvr_auto_detect", value.autoDetect)
            .putString("dvr_base_url", value.baseUrl)
            .putString("dvr_username", value.username)
            .putString("dvr_password", value.password)
            .apply()
    }

    fun loadXtream() = XtreamSettings(
        server = prefs.getString("xtream_server", "").orEmpty(),
        username = prefs.getString("xtream_username", "").orEmpty(),
        password = prefs.getString("xtream_password", "").orEmpty(),
        enabled = prefs.getBoolean("xtream_enabled", false)
    )

    fun saveXtream(value: XtreamSettings) {
        prefs.edit()
            .putString("xtream_server", value.server)
            .putString("xtream_username", value.username)
            .putString("xtream_password", value.password)
            .putBoolean("xtream_enabled", value.enabled)
            .apply()
    }

    fun loadStorage() = StorageSettings(
        preferredTarget = prefs.getString("storage_preferred", SettingsScaffold.defaultStorage.preferredTarget).orEmpty(),
        usbPath = prefs.getString("storage_usb_path", "").orEmpty(),
        nasPath = prefs.getString("storage_nas_path", "").orEmpty(),
        timeshiftMinutes = prefs.getInt("storage_timeshift_minutes", SettingsScaffold.defaultStorage.timeshiftMinutes),
        movieCacheEnabled = prefs.getBoolean("storage_movie_cache_enabled", SettingsScaffold.defaultStorage.movieCacheEnabled)
    )

    fun saveStorage(value: StorageSettings) {
        prefs.edit()
            .putString("storage_preferred", value.preferredTarget)
            .putString("storage_usb_path", value.usbPath)
            .putString("storage_nas_path", value.nasPath)
            .putInt("storage_timeshift_minutes", value.timeshiftMinutes)
            .putBoolean("storage_movie_cache_enabled", value.movieCacheEnabled)
            .apply()
    }

    fun loadTrailers() = TrailerSettings(
        enabled = prefs.getBoolean("trailers_enabled", true),
        autoplayOnFocus = prefs.getBoolean("trailers_autoplay_focus", false),
        autoplayDelayMs = prefs.getLong("trailers_delay_ms", 1500L),
        popupMode = prefs.getString("trailers_popup_mode", "center_modal").orEmpty()
    )

    fun saveTrailers(value: TrailerSettings) {
        prefs.edit()
            .putBoolean("trailers_enabled", value.enabled)
            .putBoolean("trailers_autoplay_focus", value.autoplayOnFocus)
            .putLong("trailers_delay_ms", value.autoplayDelayMs)
            .putString("trailers_popup_mode", value.popupMode)
            .apply()
    }

    fun loadPlayback() = PlaybackSettings(
        frameRateMatching = prefs.getBoolean("playback_frame_rate_matching", true),
        preferExternalStorageForCache = prefs.getBoolean("playback_prefer_external", true),
        timeshiftEnabled = prefs.getBoolean("playback_timeshift_enabled", true),
        autoPlayBestStream = prefs.getBoolean("playback_auto_best", true),
        fileSizeLimitGb = prefs.getInt("playback_file_limit_gb", 40)
    )

    fun savePlayback(value: PlaybackSettings) {
        prefs.edit()
            .putBoolean("playback_frame_rate_matching", value.frameRateMatching)
            .putBoolean("playback_prefer_external", value.preferExternalStorageForCache)
            .putBoolean("playback_timeshift_enabled", value.timeshiftEnabled)
            .putBoolean("playback_auto_best", value.autoPlayBestStream)
            .putInt("playback_file_limit_gb", value.fileSizeLimitGb)
            .apply()
    }
}
