package com.channelsdebrid.tv

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.channelsdebrid.tv.databinding.ActivitySettingsBinding
import com.channelsdebrid.tv.settings.CatalogSettings
import com.channelsdebrid.tv.settings.ChannelsDvrSettings
import com.channelsdebrid.tv.settings.PlaybackSettings
import com.channelsdebrid.tv.settings.SettingsRepository
import com.channelsdebrid.tv.settings.StorageSettings
import com.channelsdebrid.tv.settings.StremioAddonSettings
import com.channelsdebrid.tv.settings.TmdbSettings
import com.channelsdebrid.tv.settings.TrailerSettings
import com.channelsdebrid.tv.settings.XtreamSettings

class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding
    private lateinit var repository: SettingsRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = SettingsRepository(this)

        val storageTargets = listOf("internal", "usb", "nas")
        binding.storageTargetInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, storageTargets))
        binding.trailerModeInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("center_modal", "fullscreen")))

        loadAll()
        binding.backButton.setOnClickListener { finish() }
        binding.cancelButton.setOnClickListener { finish() }
        binding.saveButton.setOnClickListener {
            saveAll()
            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun loadAll() {
        val tmdb = repository.loadTmdb()
        binding.tmdbApiKeyInput.setText(tmdb.apiKey)
        binding.tmdbRegionInput.setText(tmdb.region)
        binding.tmdbLanguageInput.setText(tmdb.language)

        val catalogs = repository.loadCatalogs()
        binding.catalogTrendingMoviesSwitch.isChecked = catalogs.trendingMoviesEnabled
        binding.catalogPopularMoviesSwitch.isChecked = catalogs.popularMoviesEnabled
        binding.catalogTrendingShowsSwitch.isChecked = catalogs.trendingShowsEnabled
        binding.catalogPopularShowsSwitch.isChecked = catalogs.popularShowsEnabled
        binding.catalogPlatformSwitch.isChecked = catalogs.platformRowsEnabled
        binding.catalogStremioSwitch.isChecked = catalogs.stremioCatalogRowsEnabled

        val addon = repository.loadPrimaryAddon()
        binding.stremioEnabledSwitch.isChecked = addon.enabled
        binding.stremioNameInput.setText(addon.name)
        binding.stremioManifestInput.setText(addon.manifestUrl)

        val dvr = repository.loadChannelsDvr()
        binding.channelsAutoDetectSwitch.isChecked = dvr.autoDetect
        binding.channelsBaseUrlInput.setText(dvr.baseUrl)
        binding.channelsUsernameInput.setText(dvr.username)
        binding.channelsPasswordInput.setText(dvr.password)

        val xtream = repository.loadXtream()
        binding.xtreamEnabledSwitch.isChecked = xtream.enabled
        binding.xtreamServerInput.setText(xtream.server)
        binding.xtreamUsernameInput.setText(xtream.username)
        binding.xtreamPasswordInput.setText(xtream.password)

        val storage = repository.loadStorage()
        binding.storageTargetInput.setText(storage.preferredTarget, false)
        binding.storageUsbInput.setText(storage.usbPath)
        binding.storageNasInput.setText(storage.nasPath)
        binding.timeshiftMinutesInput.setText(storage.timeshiftMinutes.toString())
        binding.movieCacheSwitch.isChecked = storage.movieCacheEnabled

        val trailers = repository.loadTrailers()
        binding.trailerEnabledSwitch.isChecked = trailers.enabled
        binding.trailerAutoplaySwitch.isChecked = trailers.autoplayOnFocus
        binding.trailerDelayInput.setText(trailers.autoplayDelayMs.toString())
        binding.trailerModeInput.setText(trailers.popupMode, false)

        val playback = repository.loadPlayback()
        binding.frameRateSwitch.isChecked = playback.frameRateMatching
        binding.autoPlayBestSwitch.isChecked = playback.autoPlayBestStream
        binding.preferExternalSwitch.isChecked = playback.preferExternalStorageForCache
        binding.timeshiftEnabledSwitch.isChecked = playback.timeshiftEnabled
        binding.fileSizeLimitInput.setText(playback.fileSizeLimitGb.toString())
    }

    private fun saveAll() {
        repository.saveTmdb(
            TmdbSettings(
                apiKey = binding.tmdbApiKeyInput.text.toString().trim(),
                region = binding.tmdbRegionInput.text.toString().trim().ifEmpty { "US" },
                language = binding.tmdbLanguageInput.text.toString().trim().ifEmpty { "en-US" }
            )
        )

        repository.saveCatalogs(
            CatalogSettings(
                trendingMoviesEnabled = binding.catalogTrendingMoviesSwitch.isChecked,
                popularMoviesEnabled = binding.catalogPopularMoviesSwitch.isChecked,
                trendingShowsEnabled = binding.catalogTrendingShowsSwitch.isChecked,
                popularShowsEnabled = binding.catalogPopularShowsSwitch.isChecked,
                platformRowsEnabled = binding.catalogPlatformSwitch.isChecked,
                stremioCatalogRowsEnabled = binding.catalogStremioSwitch.isChecked
            )
        )

        repository.savePrimaryAddon(
            StremioAddonSettings(
                id = "primary",
                name = binding.stremioNameInput.text.toString().trim().ifEmpty { "Primary Addon" },
                manifestUrl = binding.stremioManifestInput.text.toString().trim(),
                enabled = binding.stremioEnabledSwitch.isChecked
            )
        )

        repository.saveChannelsDvr(
            ChannelsDvrSettings(
                autoDetect = binding.channelsAutoDetectSwitch.isChecked,
                baseUrl = binding.channelsBaseUrlInput.text.toString().trim(),
                username = binding.channelsUsernameInput.text.toString().trim(),
                password = binding.channelsPasswordInput.text.toString().trim()
            )
        )

        repository.saveXtream(
            XtreamSettings(
                server = binding.xtreamServerInput.text.toString().trim(),
                username = binding.xtreamUsernameInput.text.toString().trim(),
                password = binding.xtreamPasswordInput.text.toString().trim(),
                enabled = binding.xtreamEnabledSwitch.isChecked
            )
        )

        repository.saveStorage(
            StorageSettings(
                preferredTarget = binding.storageTargetInput.text.toString().trim().ifEmpty { "internal" },
                usbPath = binding.storageUsbInput.text.toString().trim(),
                nasPath = binding.storageNasInput.text.toString().trim(),
                timeshiftMinutes = binding.timeshiftMinutesInput.text.toString().toIntOrNull() ?: 90,
                movieCacheEnabled = binding.movieCacheSwitch.isChecked
            )
        )

        repository.saveTrailers(
            TrailerSettings(
                enabled = binding.trailerEnabledSwitch.isChecked,
                autoplayOnFocus = binding.trailerAutoplaySwitch.isChecked,
                autoplayDelayMs = binding.trailerDelayInput.text.toString().toLongOrNull() ?: 1500L,
                popupMode = binding.trailerModeInput.text.toString().trim().ifEmpty { "center_modal" }
            )
        )

        repository.savePlayback(
            PlaybackSettings(
                frameRateMatching = binding.frameRateSwitch.isChecked,
                preferExternalStorageForCache = binding.preferExternalSwitch.isChecked,
                timeshiftEnabled = binding.timeshiftEnabledSwitch.isChecked,
                autoPlayBestStream = binding.autoPlayBestSwitch.isChecked,
                fileSizeLimitGb = binding.fileSizeLimitInput.text.toString().toIntOrNull() ?: 40
            )
        )
    }
}
