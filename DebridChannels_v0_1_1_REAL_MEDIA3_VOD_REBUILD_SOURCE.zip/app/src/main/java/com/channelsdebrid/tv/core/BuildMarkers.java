package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.1.1 REAL MEDIA3 VOD";
    public static final String LOG_MARKER = "DC_V0_1_1_REAL_MEDIA3_VOD_ACTIVE";
    private BuildMarkers() {}
}
