# Debrid Channels Android TV — v0.1.1 Real Media3 VOD

Clean rewrite/consolidation from the stable v0.0.1 visual baseline.

Version: 0.1.1
Marker: DC_V0_1_1_REAL_MEDIA3_VOD_ACTIVE

Core VOD flow:
Home -> Media Info -> Styled Stream List -> Select Stream -> Media3 ExoPlayer + cinematic overlay.
