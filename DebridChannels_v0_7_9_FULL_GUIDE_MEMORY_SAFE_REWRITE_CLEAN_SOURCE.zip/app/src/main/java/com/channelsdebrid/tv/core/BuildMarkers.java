package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.7.9 Full Guide Memory-Safe Rewrite";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.7.9_full_guide_memory_safe_rewrite_clean_base";
}
