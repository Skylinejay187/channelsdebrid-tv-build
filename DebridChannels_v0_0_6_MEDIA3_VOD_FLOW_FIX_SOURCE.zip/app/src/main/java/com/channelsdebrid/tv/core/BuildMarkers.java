package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.0.6 MEDIA3 VOD FLOW FIX";
    public static final String LOG_MARKER = "DC_V0_0_6_MEDIA3_VOD_FLOW_FIX_ACTIVE";
    private BuildMarkers() {}
}
