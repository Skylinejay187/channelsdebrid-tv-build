# Debrid Channels v0.0.1 Stable Base — Card Clip + Center Logo Fix

Clean rewrite/consolidation from the v0.0.1 stable source path.

Preserved:
- Working single active row navigation
- Hero artwork/logo/rating badges
- Pro Layout Editor
- Backend artwork loader
- Centered row-card logos

Fixed:
- Card artwork is clipped to rounded card bounds.
- Square/white card edge from padded image layers removed.
- Row-card logo overlay remains centered and only uses safe logo/clearlogo artwork.

Markers:
- UI: DC_V0_0_1_STABLE_BASE
- Logcat: DC_V0_0_1_ACTIVE
