# Rewrite Build Audit - v0.0.6
Base used: v0.0.1 stable Card Clip + Logo Fix line.
Broken paths avoided: v7.x and broken v0.0.5 runtime behavior were not used as the source base.
Rewritten: VOD flow, Media3 playback entry, rating persistence, version/log markers.
Preserved: row scrolling, card-logo visuals, Pro Layout Editor, backend default URL.
