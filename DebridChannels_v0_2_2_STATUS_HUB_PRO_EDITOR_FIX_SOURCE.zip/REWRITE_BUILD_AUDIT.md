# Rewrite Build Audit — v0.2.2 Status Hub + Pro Editor Fix

Base used: v0.2.1 Pro Editor Live Preview clean line.

Rule followed: clean consolidation/rewrite from latest known-good line; no broken v7.x code carried forward.

Fixes in this build:
- Fixed compile error caused by missing `extraArtworkFor(Movie)` method.
- Replaced visible debug build marker on Home with a Status Hub area.
- Build marker remains available in Settings/About and logcat only.
- Status Hub currently shows time and a placeholder favorite notification slot.
- Extra Artwork Slot now maps Pro Editor type selections to real artwork sources.
- Version and logcat markers updated to v0.2.2.

Marker: `DC_V0_2_2_STATUS_HUB_PRO_EDITOR_FIX_ACTIVE`
