package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.2.2 STATUS HUB + PRO EDITOR FIX";
    public static final String LOG_MARKER = "DC_V0_2_2_STATUS_HUB_PRO_EDITOR_FIX_ACTIVE";
    private BuildMarkers() {}
}
