package com.channelsdebrid.tv

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.channelsdebrid.tv.settings.HomeLayoutSettings
import com.channelsdebrid.tv.settings.SettingsRepository

class HomeLayoutEditorActivity : AppCompatActivity() {
    private lateinit var repository: SettingsRepository
    private lateinit var previewHero: FrameLayout
    private lateinit var previewRows: LinearLayout
    private lateinit var previewMenu: TextView
    private lateinit var previewHeroText: LinearLayout
    private var config = HomeLayoutSettings()

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repository = SettingsRepository(this)
        config = repository.loadHomeLayout()
        buildUi()
        renderPreview()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFF05070D.toInt())
            setPadding(dp(18), dp(14), dp(18), dp(14))
            clipChildren = false
            clipToPadding = false
        }

        val preview = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF182036.toInt(), 0xFF061018.toInt())
            )
            clipChildren = false
            clipToPadding = false
        }

        previewHero = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(430), Gravity.TOP)
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xEE000000.toInt(), 0x66159BFF, 0x33101040)
            )
        }

        previewMenu = TextView(this).apply {
            text = "Resume Watching     Smart Home     Live TV     Movies"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            textSize = 15f
            background = rounded(0x99000000.toInt(), 24, 0x55FFFFFF, 1)
        }

        previewHeroText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(76), 0, 0)
        }
        previewHeroText.addView(TextView(this).apply {
            text = "PROJECT\nHAIL MARY"
            setTextColor(Color.WHITE)
            textSize = 34f
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        })
        previewHeroText.addView(TextView(this).apply {
            text = "2026  •  FEATURED   IMDb 8.2   TMDB 7.9"
            setTextColor(0xFFFFD54A.toInt())
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
        })
        previewHeroText.addView(TextView(this).apply {
            text = "Live preview shows 4 full cards + partial 5th. Save or View from buttons."
            setTextColor(Color.WHITE)
            textSize = 14f
            maxLines = 2
        })

        previewRows = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipToPadding = false
            clipChildren = false
        }

        preview.addView(previewHero)
        preview.addView(previewMenu)
        preview.addView(previewHeroText)
        preview.addView(previewRows)

        val sidePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(dp(330), ViewGroup.LayoutParams.MATCH_PARENT)
        }
        sidePanel.addView(TextView(this).apply {
            text = "Home Layout Editor"
            setTextColor(Color.WHITE)
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
        })
        sidePanel.addView(TextView(this).apply {
            text = "Tune the real 4-card row with DPAD. Buttons stay visible."
            setTextColor(0xFFA9B2C8.toInt())
            textSize = 12f
        })

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(12))
        }
        addSlider(controls, "Row vertical position", 300, 620, config.rowTopDp) { config = config.copy(rowTopDp = it) }
        addSlider(controls, "Row left / right", 0, 120, config.rowLeftDp) { config = config.copy(rowLeftDp = it) }
        addSlider(controls, "Card width", 190, 420, config.cardWidthDp) { config = config.copy(cardWidthDp = it) }
        addSlider(controls, "Card height", 110, 260, config.cardHeightDp) { config = config.copy(cardHeightDp = it) }
        addSlider(controls, "Card spacing", 0, 40, config.cardSpacingDp) { config = config.copy(cardSpacingDp = it) }
        addSlider(controls, "Focused card scale", 100, 118, config.focusedScalePercent) { config = config.copy(focusedScalePercent = it) }
        addSlider(controls, "Hero text left / right", -80, 220, config.heroTextLeftDp) { config = config.copy(heroTextLeftDp = it) }
        addSlider(controls, "Hero text up / down", -80, 180, config.heroTextTopDp) { config = config.copy(heroTextTopDp = it) }
        addSlider(controls, "Top menu left / right", -220, 220, config.topMenuOffsetDp) { config = config.copy(topMenuOffsetDp = it) }
        addSlider(controls, "Bottom safe space", 24, 160, config.bottomSafeDp) { config = config.copy(bottomSafeDp = it) }

        val scroll = ScrollView(this).apply {
            isFillViewport = false
            clipToPadding = false
        }
        scroll.addView(controls, ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        sidePanel.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = rounded(0xDD05070D.toInt(), 16, 0x22FFFFFF, 1)
        }
        buttons.addView(Button(this).apply {
            text = "Reset"
            setOnClickListener {
                repository.resetHomeLayout()
                config = repository.loadHomeLayout()
                Toast.makeText(this@HomeLayoutEditorActivity, "Layout reset", Toast.LENGTH_SHORT).show()
                recreate()
            }
        })
        buttons.addView(Button(this).apply {
            text = "Save"
            requestFocus()
            setOnClickListener {
                repository.saveHomeLayout(config)
                Toast.makeText(this@HomeLayoutEditorActivity, "Home layout saved", Toast.LENGTH_SHORT).show()
            }
        })
        buttons.addView(Button(this).apply {
            text = "View"
            setOnClickListener {
                repository.saveHomeLayout(config)
                startActivity(Intent(this@HomeLayoutEditorActivity, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
            }
        })
        sidePanel.addView(buttons, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(62)))

        root.addView(preview)
        root.addView(sidePanel)
        setContentView(root)
    }

    private fun addSlider(parent: LinearLayout, label: String, min: Int, max: Int, current: Int, onChange: (Int) -> Unit) {
        val title = TextView(this).apply {
            text = "$label: $current"
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(0, dp(9), 0, 0)
        }
        val sliderMax = max - min
        val bar = SeekBar(this).apply {
            isFocusable = true
            this.max = sliderMax
            progress = (current - min).coerceIn(0, sliderMax)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = min + progress
                    title.text = "$label: $value"
                    onChange(value)
                    renderPreview()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        parent.addView(title)
        parent.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(30)))
    }

    private fun renderPreview() {
        if (!::previewHero.isInitialized) return
        previewHero.layoutParams = (previewHero.layoutParams as FrameLayout.LayoutParams).apply { height = dp(config.rowTopDp) }
        previewRows.removeAllViews()
        previewRows.translationX = dp(config.rowLeftDp).toFloat()
        previewRows.translationY = dp(config.rowTopDp).toFloat()
        previewMenu.layoutParams = FrameLayout.LayoutParams(dp(560), dp(42), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(12) }
        previewMenu.translationX = dp(config.topMenuOffsetDp).toFloat()
        previewHeroText.translationX = dp(config.heroTextLeftDp).toFloat()
        previewHeroText.translationY = dp(config.heroTextTopDp).toFloat()
        previewRows.addView(TextView(this).apply {
            text = "Trending in Movies"
            setTextColor(Color.WHITE)
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
        })
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            clipToPadding = false
        }
        repeat(6) { index ->
            val card = FrameLayout(this).apply {
                background = rounded(
                    if (index == 0) 0xFF0E2230.toInt() else 0xFF151820.toInt(),
                    18,
                    if (index == 0) 0xFF5EE6FF.toInt() else 0x66FFFFFF,
                    if (index == 0) 2 else 1
                )
                scaleX = if (index == 0) config.focusedScalePercent / 100f else 1f
                scaleY = scaleX
            }
            card.addView(TextView(this).apply {
                text = if (index == 0) "FOCUSED" else "CARD ${index + 1}"
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setTypeface(typeface, Typeface.BOLD)
                textSize = 20f
            }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            row.addView(card, LinearLayout.LayoutParams(dp(config.cardWidthDp), dp(config.cardHeightDp)).apply {
                rightMargin = dp(config.cardSpacingDp)
            })
        }
        previewRows.addView(row)
    }

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int, strokeDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(dp(strokeDp).coerceAtLeast(1), strokeColor)
    }
}
