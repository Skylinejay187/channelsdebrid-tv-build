# DC v5.7 Pro Layout Editor Complete

Base used: DebridChannels_v5_6_FULL_CORE_COMPLETION / v5.1 clean-core lineage.
Reference only: v2.1.3 Pro Layout Menu Art Livefix Full.

What was recreated as new code:
- Pro Layout Editor settings list from v2.1.3 capability set.
- Persistent UI state store for all editor controls.
- Live preview panel for hero, row title, cards, artwork/menu metadata.
- Reset and View Home actions.

No legacy HomeLayoutEditorActivity.kt or SettingsRepository code was copied into this build.

## v5.8 Pro Editor Reset/Save/View
- Base remained the v5 clean-core line.
- Added explicit Pro Layout Editor Reset, Save, and View Home controls.
- Save records a layout snapshot timestamp; slider/toggle values still persist immediately through UiStateStore.
- View Home saves snapshot before returning to the home preview.
- Default backend URL set to http://192.168.100.55:8181.
- v2.1.3 remains visual/settings reference only; no legacy source files copied.
- Marker: DC_V5_8_PRO_EDITOR_RESET_SAVE_VIEW

## v5.9 Card Size Defaults + Pro Editor Resize
- Default row/card icon size is locked to 286dp width × 160dp height.
- Pro Layout Editor can resize smaller and larger from the default using the Card width and Card height controls.
- Card size reset helper added for returning width/height to 286×160 defaults without legacy code.
- Marker: DC_V5_9_CARD_SIZE_CONTROLS

## v6.0 Row Snap Carousel Engine
- Added one-card-per-click horizontal snap carousel behavior from the v5.1 clean-core line.
- RIGHT/LEFT now requests the next/previous card focus and smooth-centers it in the row.
- Uses Pro Layout Editor card width, height, spacing, row offset, and focused-scale settings.
- Marker: DC_V6_0_ROW_SNAP_CAROUSEL_ENGINE
