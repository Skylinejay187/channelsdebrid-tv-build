package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v6.0 ROW_SNAP_CAROUSEL_ENGINE";
    public static final String LOG_MARKER = "DC_V6_0_ROW_SNAP_CAROUSEL_ENGINE";
    private BuildMarkers() {}
}
