package com.channelsdebrid.tv

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.channelsdebrid.tv.live.LiveSourceResolver
import com.channelsdebrid.tv.playback.PlayerActivity
import com.channelsdebrid.tv.settings.SettingsRepository
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class LiveTvActivity : AppCompatActivity() {

    private lateinit var settingsRepository: SettingsRepository
    private lateinit var backButton: TextView
    private lateinit var clockView: TextView
    private lateinit var infoLogo: TextView
    private lateinit var infoChannel: TextView
    private lateinit var infoGroup: TextView
    private lateinit var nowTime: TextView
    private lateinit var nowTitle: TextView
    private lateinit var descriptionView: TextView
    private lateinit var nextLine: TextView
    private lateinit var laterLine: TextView
    private lateinit var progressBar: View
    private lateinit var timelineRow: LinearLayout
    private lateinit var channelList: LinearLayout
    private lateinit var previewImage: ImageView

    private val executor = Executors.newSingleThreadExecutor()
    private var currentChannels: List<GuideEntry> = emptyList()
    private var selectedIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_live_tv)
        settingsRepository = SettingsRepository(this)

        backButton = findViewById(R.id.liveTvBackButton)
        clockView = findViewById(R.id.liveTvClock)
        infoLogo = findViewById(R.id.liveTvInfoLogo)
        infoChannel = findViewById(R.id.liveTvInfoChannel)
        infoGroup = findViewById(R.id.liveTvInfoGroup)
        nowTime = findViewById(R.id.liveTvNowTime)
        nowTitle = findViewById(R.id.liveTvNowTitle)
        descriptionView = findViewById(R.id.liveTvDescription)
        nextLine = findViewById(R.id.liveTvNextLine)
        laterLine = findViewById(R.id.liveTvLaterLine)
        progressBar = findViewById(R.id.liveTvProgressBar)
        timelineRow = findViewById(R.id.liveTvTimeline)
        channelList = findViewById(R.id.liveTvChannelList)
        previewImage = findViewById(R.id.liveTvPreviewImage)

        backButton.setOnClickListener { finish() }
        updateClock()
        buildTimeline()
        loadChannels()
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    private fun updateClock() {
        val formatter = SimpleDateFormat("h:mm a", Locale.US)
        clockView.text = formatter.format(Date())
    }

    private fun loadChannels() {
        infoChannel.text = "Loading Live TV"
        infoGroup.text = "Unified Live TV"
        descriptionView.text = "Bringing in Channels DVR and IPTV channels for the ARVIO-style black glass guide."
        channelList.removeAllViews()

        val dvr = settingsRepository.loadChannelsDvr()
        val xtream = settingsRepository.loadXtream()

        executor.execute {
            val allChannels = mutableListOf<LiveSourceResolver.ChannelItem>()
            var dvrDeviceId = dvr.deviceId

            if (dvr.baseUrl.isNotBlank()) {
                val dvrResult = LiveSourceResolver.loadDvrChannels(dvr.baseUrl, dvr.deviceId)
                allChannels += dvrResult.channels
                if (!dvrResult.deviceId.isNullOrBlank() && dvrResult.deviceId != dvr.deviceId) {
                    dvrDeviceId = dvrResult.deviceId
                    settingsRepository.saveChannelsDvr(dvr.copy(deviceId = dvrDeviceId))
                }
            }

            if (xtream.enabled && xtream.server.isNotBlank() && xtream.username.isNotBlank() && xtream.password.isNotBlank()) {
                val (xtreamChannels, _) = LiveSourceResolver.loadXtreamChannels(
                    xtream.server,
                    xtream.username,
                    xtream.password
                )
                allChannels += xtreamChannels
            }

            val entries = allChannels
                .distinctBy { it.source + "|" + it.name + "|" + it.url }
                .mapIndexed { index, item -> buildGuideEntry(item, index) }
                .take(160)

            runOnUiThread {
                currentChannels = entries
                channelList.removeAllViews()
                if (entries.isEmpty()) {
                    infoChannel.text = "No channels found"
                    infoGroup.text = "Add Channels DVR or IPTV in Settings"
                    descriptionView.text = "Once a source is configured, channels will appear here in the unified guide."
                    Toast.makeText(this, "No source configured. Add Channels DVR or Xtream in Settings.", Toast.LENGTH_LONG).show()
                } else {
                    entries.forEachIndexed { index, entry ->
                        channelList.addView(makeGuideRow(index, entry))
                    }
                    selectedIndex = 0
                    updateSelection(0, requestFocus = true)
                    infoGroup.text = "${entries.size} channels • ${if (dvrDeviceId.isNotBlank()) "DVR $dvrDeviceId + IPTV" else "Unified Live TV"}"
                }
            }
        }
    }

    private fun buildTimeline() {
        timelineRow.removeAllViews()
        val labels = mutableListOf<String>()
        val cal = Calendar.getInstance().apply {
            set(Calendar.MINUTE, if (get(Calendar.MINUTE) < 30) 30 else 0)
            if (get(Calendar.MINUTE) >= 30) add(Calendar.HOUR_OF_DAY, 1)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val formatter = SimpleDateFormat("h:mm a", Locale.US)
        repeat(7) {
            labels += formatter.format(cal.time)
            cal.add(Calendar.MINUTE, 30)
        }
        addSpacer(timelineRow, 220)
        labels.forEach {
            timelineRow.addView(TextView(this).apply {
                text = it
                setTextColor(0xFFA9B1BD.toInt())
                textSize = 14f
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(170), ViewGroup.LayoutParams.WRAP_CONTENT)
            })
        }
    }

    private fun makeGuideRow(index: Int, entry: GuideEntry): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = getDrawable(R.drawable.guide_row_bg)
            isFocusable = true
            isFocusableInTouchMode = true
            isClickable = true
            setPadding(dp(12), dp(10), dp(12), dp(10))
            val lp = LinearLayout.LayoutParams(dp(1210), ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(12)
            layoutParams = lp
            setOnFocusChangeListener { v, hasFocus ->
                if (hasFocus) updateSelection(index)
                styleRow(v as LinearLayout, hasFocus)
            }
            setOnClickListener { openPlayer(index) }
        }

        val logoBox = TextView(this).apply {
            text = entry.logoText
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 18f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            background = getDrawable(R.drawable.guide_logo_tile)
            layoutParams = LinearLayout.LayoutParams(dp(54), dp(54))
        }

        val channelColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val lp = LinearLayout.LayoutParams(dp(150), ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginStart = dp(12)
            lp.marginEnd = dp(16)
            layoutParams = lp
        }

        val name = TextView(this).apply {
            text = entry.item.name
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 18f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val source = TextView(this).apply {
            text = if (entry.item.source.contains("DVR", ignoreCase = true)) "LIVE • DVR" else "LIVE • IPTV"
            setTextColor(0xFF19E3A8.toInt())
            textSize = 12f
        }
        channelColumn.addView(name)
        channelColumn.addView(source)

        row.addView(logoBox)
        row.addView(channelColumn)

        entry.programs.forEachIndexed { programIndex, program ->
            row.addView(makeProgramCard(entry, program, programIndex == 0))
        }
        row.tag = index
        return row
    }

    private fun makeProgramCard(entry: GuideEntry, program: ProgramBlock, isNow: Boolean): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            background = getDrawable(if (isNow) R.drawable.guide_program_card_selected else R.drawable.guide_program_card)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            val lp = LinearLayout.LayoutParams(dp(program.widthDp), dp(74))
            lp.marginEnd = dp(4)
            layoutParams = lp
        }
        val time = TextView(this).apply {
            text = program.startLabel
            setTextColor(0xFFF1F5FA.toInt())
            textSize = 14f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val title = TextView(this).apply {
            text = program.title
            setTextColor(if (isNow) 0xFFFFFFFF.toInt() else 0xFFC6CCD7.toInt())
            textSize = 15f
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        card.addView(time)
        card.addView(title)

        if (isNow) {
            card.addView(View(this).apply {
                setBackgroundColor(0xFF19E3A8.toInt())
                layoutParams = LinearLayout.LayoutParams((program.widthDp * resources.displayMetrics.density * 0.72f).roundToInt(), dp(3)).apply {
                    topMargin = dp(8)
                }
            })
        }
        return card
    }

    private fun updateSelection(index: Int, requestFocus: Boolean = false) {
        if (currentChannels.isEmpty()) return
        selectedIndex = index.coerceIn(0, currentChannels.lastIndex)
        val selected = currentChannels[selectedIndex]
        val channelPrograms = selected.programs

        infoLogo.text = selected.logoText
        infoChannel.text = selected.item.name
        infoGroup.text = if (selected.item.source.contains("DVR", ignoreCase = true)) "Favorites • Channels DVR" else "Favorites • IPTV"
        nowTime.text = "${channelPrograms[0].startLabel} - ${channelPrograms[0].endLabel}"
        nowTitle.text = channelPrograms[0].title
        descriptionView.text = selected.description
        nextLine.text = "NEXT   ${channelPrograms[1].startLabel}  ${channelPrograms[1].title}"
        laterLine.text = "LATER  ${channelPrograms[2].startLabel}  ${channelPrograms[2].title}"
        progressBar.layoutParams = progressBar.layoutParams.apply {
            width = dp((220 + (selectedIndex % 5) * 24).coerceAtMost(340))
        }
        progressBar.requestLayout()
        previewImage.setImageResource(selected.previewRes)

        for (i in 0 until channelList.childCount) {
            val child = channelList.getChildAt(i) as? LinearLayout ?: continue
            val isSelected = i == selectedIndex
            styleRow(child, isSelected)
        }

        if (requestFocus) {
            channelList.getChildAt(selectedIndex)?.requestFocus()
        }
    }

    private fun styleRow(row: LinearLayout, selected: Boolean) {
        row.background = getDrawable(if (selected) R.drawable.guide_row_selected else R.drawable.guide_row_bg)
        row.scaleX = if (selected) 1.01f else 1f
        row.scaleY = if (selected) 1.01f else 1f
        row.alpha = if (selected) 1f else 0.88f
    }

    private fun openPlayer(index: Int) {
        val entry = currentChannels.getOrNull(index) ?: return
        startActivity(
            Intent(this, PlayerActivity::class.java)
                .putExtra(PlayerActivity.EXTRA_STREAM_URL, entry.item.url)
                .putExtra(PlayerActivity.EXTRA_TITLE, entry.item.name)
                .putExtra(PlayerActivity.EXTRA_SOURCE_LABEL, entry.item.source)
                .putExtra(PlayerActivity.EXTRA_DEBUG_LABEL, entry.item.debug)
                .putExtra(PlayerActivity.EXTRA_CHANNEL_INDEX, index)
                .putExtra(PlayerActivity.EXTRA_CHANNELS_JSON, serializeChannels(currentChannels.map { it.item }))
        )
    }

    private fun serializeChannels(channels: List<LiveSourceResolver.ChannelItem>): String {
        val arr = JSONArray()
        channels.forEach { channel ->
            arr.put(
                JSONObject()
                    .put("name", channel.name)
                    .put("url", channel.url)
                    .put("source", channel.source)
                    .put("debug", channel.debug)
            )
        }
        return arr.toString()
    }

    private fun buildGuideEntry(item: LiveSourceResolver.ChannelItem, index: Int): GuideEntry {
        val seed = item.name.uppercase(Locale.US)
        val descriptor = when {
            seed.contains("CNN") || seed.contains("FOX") || seed.contains("MSNBC") || seed.contains("CSPAN") -> "Live news, breaking updates, and current coverage."
            seed.contains("AMC") || seed.contains("TNT") || seed.contains("LIFETIME") || seed.contains("TRU") -> "Movie and event blocks with polished premium-channel presentation."
            seed.contains("ESPN") || seed.contains("FS") || seed.contains("NFL") || seed.contains("NBA") -> "Live sports and studio coverage with upcoming game windows."
            else -> "Unified live guide with current, next, and later programming in the ARVIO black glass layout."
        }
        val programs = syntheticProgramsFor(item.name, index)
        val logoText = item.name
            .replace("Channels DVR", "")
            .trim()
            .split(" ", "-", "_")
            .filter { it.isNotBlank() }
            .take(2)
            .joinToString("") { it.take(1).uppercase(Locale.US) }
            .ifBlank { "TV" }
            .take(4)
        val previewPool = listOf(
            R.drawable.bg_wonka,
            R.drawable.bg_dune,
            R.drawable.bg_fallout,
            R.drawable.bg_shogun,
            R.drawable.bg_civilwar,
            R.drawable.bg_halo,
            R.drawable.bg_batman,
            R.drawable.bg_mayor
        )
        return GuideEntry(item, logoText, descriptor, programs, previewPool[index % previewPool.size])
    }

    private fun syntheticProgramsFor(channelName: String, index: Int): List<ProgramBlock> {
        val titlePool = when {
            channelName.contains("TRU", ignoreCase = true) -> listOf("Hoosiers (1986)", "NHL on TNT Face Off", "NHL Hockey")
            channelName.contains("AMC", ignoreCase = true) -> listOf("The Martian (2015)", "National Treasure (2004)", "Movie Bonus Round")
            channelName.contains("LIFETIME", ignoreCase = true) -> listOf("Toni Braxton's Breathe Again", "Mary J. Blige Presents Be Happy", "The Beach House Murders")
            channelName.contains("CNN", ignoreCase = true) -> listOf("CNN News Central", "Inside Politics", "The Lead With Jake Tapper")
            channelName.contains("CSPAN", ignoreCase = true) -> listOf("Washington Journal", "Public Affairs Event", "Floor Debate Replay")
            channelName.contains("A&E", ignoreCase = true) || channelName.contains("AETV", ignoreCase = true) -> listOf("Live PD: Police Patrol", "Live PD: Police Patrol", "Live PD: Police Patrol")
            channelName.contains("HLN", ignoreCase = true) -> listOf("Morning Express", "Weekend Express", "Forensic Files")
            else -> listOf("${channelName} Live", "${channelName} Spotlight", "${channelName} After Hours")
        }
        val times = listOf(
            Triple("12:00 PM", "2:00 PM", 170),
            Triple("2:00 PM", "3:00 PM", 210),
            Triple("3:00 PM", "4:30 PM", 240)
        )
        return titlePool.mapIndexed { i, title ->
            ProgramBlock(title, times[i].first, times[i].second, times[i].third + ((index + i) % 3) * 18)
        }
    }

    private fun addSpacer(parent: LinearLayout, widthDp: Int) {
        parent.addView(SpaceView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(widthDp), 1)
        })
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    data class GuideEntry(
        val item: LiveSourceResolver.ChannelItem,
        val logoText: String,
        val description: String,
        val programs: List<ProgramBlock>,
        val previewRes: Int
    )

    data class ProgramBlock(
        val title: String,
        val startLabel: String,
        val endLabel: String,
        val widthDp: Int
    )

    private class SpaceView(context: android.content.Context) : View(context)
}
