# Debrid Channels v6.3

Clean-core Android TV source.

Build marker: `DC_V6_3_STABLE_INTERACTIVE_HERO_EDITOR_RESTORE`

Default backend: `http://192.168.100.55:8181`

Highlights:
- Stable interactive Pro Layout Editor overlay
- Scrollable Settings / editor controls
- Card rows remain snap-scrollable
- Focused card drives cinematic hero background/logo/banner
- Backend `/api/home` artwork row loading preserved
