package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v6.6 BACKEND_POSTER_ARTWORK_LOADER";
    public static final String LOG_MARKER = "DC_V6_6_BACKEND_POSTER_ARTWORK_LOADER";
    private BuildMarkers() {}
}
