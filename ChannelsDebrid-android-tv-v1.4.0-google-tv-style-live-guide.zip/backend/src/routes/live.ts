import { Router } from "express"
import fs from "node:fs/promises"
import path from "node:path"

interface LiveSource {
  id: string
  userId: string
  type: "m3u" | "xtream" | "channels_dvr" | "hdhomerun"
  name: string
  url: string
  username?: string
  password?: string
  updatedAt: string
}

const DATA_DIR = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(process.cwd(), "backend", "data")
const SOURCES_PATH = path.join(DATA_DIR, "live-sources.json")

async function loadSources(): Promise<LiveSource[]> {
  try {
    const raw = await fs.readFile(SOURCES_PATH, "utf8")
    return JSON.parse(raw) as LiveSource[]
  } catch {
    return []
  }
}

async function saveSources(sources: LiveSource[]): Promise<void> {
  await fs.mkdir(DATA_DIR, { recursive: true })
  await fs.writeFile(SOURCES_PATH, JSON.stringify(sources, null, 2), "utf8")
}

export function liveRouter() {
  const router = Router()

  router.get("/live/sources", async (req, res, next) => {
    try {
      const userId = String(req.query.user_id ?? req.query.userId ?? "demo")
      const sources = (await loadSources()).filter(s => s.userId === userId)
      res.json({ ok: true, sources })
    } catch (err) {
      next(err)
    }
  })

  router.post("/live/sources/connect", async (req, res, next) => {
    try {
      const body = req.body ?? {}
      const userId = String(body.userId ?? body.user_id ?? "demo").trim() || "demo"
      let type = String(body.type ?? "").trim().toLowerCase() as LiveSource["type"]
      const url = String(body.url ?? body.sourceUrl ?? body.m3uUrl ?? body.server ?? body.baseUrl ?? "").trim()
      const name = String(body.name ?? (type ? type.toUpperCase() : "Live Source")).trim() || (type ? type.toUpperCase() : "Live Source")
      if (type === "iptv") type = "m3u" as LiveSource["type"]
      if (type === "hdhr" || type === "hd_home_run") type = "hdhomerun" as LiveSource["type"]
      if (type === "xtream_codes" || type === "xc" || type === "stream_codes") type = "xtream" as LiveSource["type"]
      if (type === "playlist" || type === "m3u8") type = "m3u" as LiveSource["type"]
      if (!["m3u", "xtream", "channels_dvr", "hdhomerun"].includes(type)) {
        res.status(400).json({ ok: false, error: "Unsupported live source type" })
        return
      }
      if (!url) {
        res.status(400).json({ ok: false, error: "Live source URL missing", received: Object.keys(body) })
        return
      }
      const sources = await loadSources()
      const stableKey = `${type}:${url}:${body.username ? String(body.username) : ""}`
      const id = `${userId}_${type}_${Buffer.from(stableKey).toString("base64url").slice(0, 24)}`
      const nextSource: LiveSource = {
        id,
        userId,
        type,
        name,
        url,
        username: body.username ? String(body.username) : undefined,
        password: body.password ? String(body.password) : undefined,
        updatedAt: new Date().toISOString(),
      }
      const withoutOld = sources.filter(s => s.id !== id)
      withoutOld.push(nextSource)
      await saveSources(withoutOld)
      res.json({ ok: true, source: { ...nextSource, password: nextSource.password ? "***" : undefined } })
    } catch (err) {
      next(err)
    }
  })

  router.post("/live/sources/remove", async (req, res, next) => {
    try {
      const userId = String(req.body?.userId ?? req.body?.user_id ?? "demo")
      const id = String(req.body?.id ?? "")
      const before = await loadSources()
      const after = before.filter(s => !(s.userId === userId && s.id === id))
      await saveSources(after)
      res.json({ ok: true, removed: before.length - after.length, sources: after.filter(s => s.userId === userId) })
    } catch (err) {
      next(err)
    }
  })



  router.get("/live/bootstrap", async (req, res, next) => {
    try {
      const userId = String(req.query.user_id ?? req.query.userId ?? "demo")
      const sources = (await loadSources()).filter(s => s.userId === userId)
      res.json({
        ok: true,
        userId,
        cached: true,
        refreshedAt: new Date().toISOString(),
        sources: sources.map(s => ({ id: s.id, type: s.type, name: s.name, url: s.url, username: s.username, updatedAt: s.updatedAt })),
        categories: [],
        channels: [],
        nowPlaying: {},
        nextPrograms: {}
      })
    } catch (err) {
      next(err)
    }
  })

  router.post("/live/refresh", async (req, res) => {
    const userId = String(req.body?.userId ?? req.body?.user_id ?? "demo")
    const sources = (await loadSources()).filter(s => s.userId === userId)
    res.json({ ok: true, userId, sourceCount: sources.length, sources: sources.map(s => ({ id: s.id, type: s.type, name: s.name, url: s.url, updatedAt: s.updatedAt })), refreshedAt: new Date().toISOString() })
  })

  return router
}
