package com.channelsdebrid.tv.live

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

object LiveSourceResolver {

    data class HttpResult(
        val body: String?,
        val error: String?
    )

    data class ChannelItem(
        val name: String,
        val url: String,
        val source: String,
        val debug: String = "",
        val groups: List<String> = emptyList(),
        val number: String = "",
        val iconUrl: String = ""
    )

    data class DvrResult(
        val channels: List<ChannelItem>,
        val message: String,
        val deviceId: String? = null
    )

    data class HdHomeRunDevice(
        val deviceId: String,
        val friendlyName: String,
        val baseUrl: String,
        val lineupUrl: String
    )

    data class HdHomeRunResult(
        val channels: List<ChannelItem>,
        val message: String,
        val devices: List<HdHomeRunDevice> = emptyList()
    )

    fun loadHdHomeRunChannels(): HdHomeRunResult {
        val devices = discoverHdHomeRunDevices()
        if (devices.isEmpty()) {
            return HdHomeRunResult(emptyList(), "HDHomeRun scan found no tuners.")
        }
        val channels = mutableListOf<ChannelItem>()
        val successful = mutableListOf<HdHomeRunDevice>()
        for (device in devices) {
            val lineup = getJson(device.lineupUrl)
            val parsed = parseHdHomeRunLineup(device, lineup.body.orEmpty())
            if (parsed.isNotEmpty()) {
                successful += device
                channels += parsed
            }
        }
        val deduped = channels.distinctBy { it.source + "|" + it.number + "|" + it.name + "|" + it.url }
        return if (deduped.isNotEmpty()) {
            val label = if (successful.size == 1) successful.first().friendlyName else "${successful.size} tuners"
            HdHomeRunResult(deduped, "HDHomeRun connected • ${deduped.size} channels found ($label)", successful)
        } else {
            HdHomeRunResult(emptyList(), "HDHomeRun tuner found, but no channels were returned.", devices)
        }
    }

    private fun discoverHdHomeRunDevices(): List<HdHomeRunDevice> {
        val devices = linkedMapOf<String, HdHomeRunDevice>()
        fun addFromJson(json: String) {
            try {
                val arr = if (json.trim().startsWith("[")) JSONArray(json) else JSONArray().put(JSONObject(json))
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val deviceId = obj.optString("DeviceID").ifBlank { obj.optString("DeviceId") }.ifBlank { obj.optString("deviceId") }.trim()
                    val friendly = obj.optString("FriendlyName").ifBlank { obj.optString("Name") }.ifBlank { "HDHomeRun ${deviceId.ifBlank { i.toString() }}" }
                    val discoverUrl = obj.optString("DiscoverURL").trim().trimEnd('/')
                    val lineupUrl = obj.optString("LineupURL").ifBlank { if (discoverUrl.isNotBlank()) "$discoverUrl/lineup.json" else "" }.trim()
                    val base = discoverUrl.ifBlank { lineupUrl.substringBefore("/lineup", "").trimEnd('/') }
                    if (lineupUrl.isBlank() || base.isBlank()) continue
                    val key = deviceId.ifBlank { base }
                    devices[key] = HdHomeRunDevice(key, friendly, base, lineupUrl)
                }
            } catch (_: Exception) {
            }
        }

        listOf("http://api.hdhomerun.com/discover", "http://hdhomerun.local/discover.json").forEach { url ->
            getJson(url).body?.let { addFromJson(it) }
        }
        return devices.values.toList()
    }

    private fun parseHdHomeRunLineup(device: HdHomeRunDevice, json: String): List<ChannelItem> {
        if (json.isBlank()) return emptyList()
        val out = mutableListOf<ChannelItem>()
        try {
            val arr = if (json.trim().startsWith("[")) JSONArray(json) else JSONObject(json).optJSONArray("Guide") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                if (obj.optBoolean("DRM", false)) continue
                val number = obj.optString("GuideNumber").ifBlank { obj.optString("Channel") }.trim()
                val name = obj.optString("GuideName").ifBlank { obj.optString("Name") }.ifBlank { "HDHomeRun ${number.ifBlank { i.toString() }}" }.trim()
                val url = obj.optString("URL").ifBlank {
                    if (number.isNotBlank()) "${device.baseUrl}/auto/v$number" else ""
                }.trim()
                if (url.isBlank()) continue
                val groups = mutableListOf("HDHomeRun")
                val lower = name.lowercase(Locale.US)
                when {
                    "sport" in lower || "espn" in lower -> groups += "Sports"
                    "news" in lower || "cnn" in lower || "fox" in lower || "msnbc" in lower -> groups += "News"
                    "kids" in lower || "disney" in lower || "nick" in lower -> groups += "Kids"
                    "movie" in lower || "hbo" in lower || "starz" in lower || "showtime" in lower -> groups += "Movies"
                }
                val icon = obj.optString("ImageURL").ifBlank { obj.optString("LogoURL") }.trim()
                out += ChannelItem(
                    name = name,
                    url = url,
                    source = "HDHomeRun",
                    debug = "device=${device.deviceId} • ch=$number • native tuner",
                    groups = groups.distinct(),
                    number = number,
                    iconUrl = icon
                )
            }
        } catch (_: Exception) {
        }
        return out
    }


    fun discoverChannelsDvrBaseUrl(): String? {
        val candidates = linkedSetOf<String>()
        candidates += "http://channels.local:8089"
        candidates += "http://channels-dvr.local:8089"
        candidates += "http://192.168.1.50:8089"
        candidates += "http://192.168.100.55:8089"
        localSubnetPrefixes().forEach { prefix ->
            listOf(1, 2, 10, 20, 50, 55, 80, 89, 100, 101, 150, 200, 254).forEach { host ->
                candidates += "http://$prefix.$host:8089"
            }
        }
        return candidates.firstOrNull { base -> isChannelsDvrServer(base) }
    }

    private fun isChannelsDvrServer(baseUrl: String): Boolean {
        val base = baseUrl.trim().trimEnd('/')
        val probes = listOf("$base/dvr/lineups", "$base/devices", "$base/status")
        return probes.any { url ->
            val body = getJson(url, connectTimeoutMs = 500, readTimeoutMs = 700).body.orEmpty()
            body.contains("Channels", ignoreCase = true) ||
                body.contains("Device", ignoreCase = true) ||
                body.contains("lineup", ignoreCase = true) ||
                body.trim().startsWith("[")
        }
    }

    private fun localSubnetPrefixes(): List<String> {
        val prefixes = linkedSetOf<String>()
        return try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (address is Inet4Address && !address.isLoopbackAddress) {
                        val parts = address.hostAddress.split('.')
                        if (parts.size == 4) prefixes += parts.take(3).joinToString(".")
                    }
                }
            }
            prefixes.toList()
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun loadDvrChannels(baseUrl: String, preferredDeviceId: String = ""): DvrResult {
        val base = baseUrl.trim().trimEnd('/').ifBlank { discoverChannelsDvrBaseUrl().orEmpty() }
        if (base.isBlank()) return DvrResult(emptyList(), "Channels DVR auto-detect found no server. Manual IP is still available in Settings.")

        val m3uProbe = getText("$base/devices/ANY/channels.m3u?format=ts&codec=copy")
        if (m3uProbe.body != null) {
            val parsed = parseDvrM3u(base, m3uProbe.body)
            if (parsed.isNotEmpty()) {
                return DvrResult(parsed, "Channels DVR connected • ${parsed.size} channels found (M3U export)", preferredDeviceId.ifBlank { "ANY" })
            }
        }

        val candidates = linkedSetOf<String>()
        if (preferredDeviceId.isNotBlank()) candidates += preferredDeviceId

        val deviceProbe = getJson("$base/devices")
        if (deviceProbe.body != null) {
            candidates.addAll(parseDeviceNames(deviceProbe.body))
        }
        if (!candidates.contains("ANY")) candidates += "ANY"

        val combined = mutableListOf<ChannelItem>()
        val successfulDevices = mutableListOf<String>()

        for (device in candidates) {
            val encodedDevice = encodeURIComponent(device)
            val probe = getJson("$base/devices/$encodedDevice/channels")
            if (probe.error != null) continue
            val parsed = parseDvrChannels(base, device, probe.body ?: "")
            if (parsed.isNotEmpty()) {
                combined += parsed
                successfulDevices += device
            }
        }

        val deduped = combined.distinctBy { it.name + "|" + it.url }
        if (deduped.isNotEmpty()) {
            val label = when {
                successfulDevices.isEmpty() -> "Channels DVR"
                successfulDevices.size == 1 -> successfulDevices.first()
                else -> "${successfulDevices.size} devices"
            }
            val savedDevice = successfulDevices.firstOrNull { !it.equals("ANY", ignoreCase = true) } ?: preferredDeviceId
            return DvrResult(deduped, "Channels DVR connected • ${deduped.size} channels found ($label)", savedDevice)
        }

        val errorText = m3uProbe.error ?: deviceProbe.error
        return when {
            errorText != null -> DvrResult(emptyList(), "Channels DVR failed: $errorText")
            preferredDeviceId.isNotBlank() -> DvrResult(emptyList(), "Channels DVR connected, but no channels were returned for saved device '$preferredDeviceId'.")
            else -> DvrResult(emptyList(), "Channels DVR connected, but no channels were returned.")
        }
    }

    fun loadXtreamChannels(server: String, user: String, pass: String): Pair<List<ChannelItem>, String> {
        val base = server.trim().trimEnd('/')
        if (base.isBlank() || user.isBlank() || pass.isBlank()) {
            return emptyList<ChannelItem>() to "Xtream is missing server or credentials."
        }
        val probe = getJson("$base/player_api.php?username=$user&password=$pass&action=get_live_streams")
        if (probe.error != null) {
            return emptyList<ChannelItem>() to "Xtream failed: ${probe.error}"
        }
        val json = probe.body ?: return emptyList<ChannelItem>() to "Xtream returned no data."
        val arr = try {
            JSONArray(json)
        } catch (_: Exception) {
            return emptyList<ChannelItem>() to "Xtream returned invalid JSON."
        }
        val items = mutableListOf<ChannelItem>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val id = obj.optString("stream_id")
            if (id.isBlank()) continue
            val ext = obj.optString("container_extension").ifBlank { "m3u8" }
            val name = obj.optString("name").ifBlank { "Channel $id" }
            val category = obj.optString("category_name").trim()
            val channelNum = obj.optString("num").trim()
            val url = "$base/live/$user/$pass/$id.$ext"
            val iconUrl = obj.optString("stream_icon").trim()
            items += ChannelItem(
                name = name,
                url = url,
                source = "Xtream/IPTV",
                debug = "streamId=$id • ext=$ext",
                groups = listOfNotNull(category.takeIf { it.isNotBlank() }, "IPTV"),
                number = channelNum,
                iconUrl = iconUrl
            )
        }
        return if (items.isEmpty()) {
            emptyList<ChannelItem>() to "Xtream connected, but no channels were returned."
        } else {
            items to "Xtream connected • ${items.size} channels found"
        }
    }

    fun loadM3uChannels(m3uUrl: String): Pair<List<ChannelItem>, String> {
        val normalized = m3uUrl.trim()
        if (normalized.isBlank()) return emptyList<ChannelItem>() to "M3U URL missing."
        val probe = getText(normalized)
        if (probe.error != null) return emptyList<ChannelItem>() to "M3U failed: ${probe.error}"
        val body = probe.body ?: return emptyList<ChannelItem>() to "M3U returned no data."
        val lines = body.lines()
        val items = mutableListOf<ChannelItem>()
        var currentMeta = ""
        for (rawLine in lines) {
            val line = rawLine.trim()
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> currentMeta = line
                line.isBlank() || line.startsWith("#") -> Unit
                currentMeta.isNotBlank() -> {
                    val name = currentMeta.substringAfter(',').trim().ifBlank { "IPTV Channel ${items.size + 1}" }
                    val group = Regex("""group-title="([^"]+)""", RegexOption.IGNORE_CASE).find(currentMeta)?.groupValues?.getOrNull(1).orEmpty()
                    val number = Regex("""tvg-chno="([^"]+)""", RegexOption.IGNORE_CASE).find(currentMeta)?.groupValues?.getOrNull(1).orEmpty()
                    val iconUrl = Regex("""tvg-logo="([^"]+)""", RegexOption.IGNORE_CASE).find(currentMeta)?.groupValues?.getOrNull(1).orEmpty()
                    val debug = buildString {
                        append("m3u")
                        if (group.isNotBlank()) append(" • group=").append(group)
                        if (number.isNotBlank()) append(" • ch=").append(number)
                    }
                    items += ChannelItem(
                        name = name,
                        url = line,
                        source = "M3U/IPTV",
                        debug = debug,
                        groups = listOfNotNull(group.takeIf { it.isNotBlank() }, "IPTV"),
                        number = number,
                        iconUrl = iconUrl
                    )
                    currentMeta = ""
                }
            }
        }
        return if (items.isEmpty()) emptyList<ChannelItem>() to "M3U connected, but no channels were returned."
        else items to "M3U connected • ${items.size} channels found"
    }

    fun resolveDvrPlayback(baseUrl: String, preferredDeviceId: String = ""): ChannelItem? {
        return loadDvrChannels(baseUrl, preferredDeviceId).channels.firstOrNull()
    }

    private fun loadDvrLineupMap(base: String): Map<String, Set<String>> {
        val result = linkedMapOf<String, MutableSet<String>>()
        val probe = getJson("$base/dvr/lineups")
        val body = probe.body ?: return emptyMap()
        try {
            if (body.trim().startsWith("[")) {
                val arr = JSONArray(body)
                for (i in 0 until arr.length()) collectLineupObject(arr.optJSONObject(i), result)
            } else {
                val root = JSONObject(body)
                val arr = root.optJSONArray("lineups") ?: root.optJSONArray("Lineups") ?: root.optJSONArray("items")
                if (arr != null) {
                    for (i in 0 until arr.length()) collectLineupObject(arr.optJSONObject(i), result)
                } else {
                    collectLineupObject(root, result)
                }
            }
        } catch (_: Exception) {
        }
        return result
    }

    private fun collectLineupObject(obj: JSONObject?, result: MutableMap<String, MutableSet<String>>) {
        if (obj == null) return
        val lineupName = sequenceOf("name", "Name", "title", "Title", "group", "Group")
            .map { obj.optString(it).trim() }
            .firstOrNull { it.isNotBlank() }
            ?: return
        val members = result.getOrPut(lineupName) { linkedSetOf() }
        fun collectAny(value: Any?) {
            when (value) {
                is JSONArray -> for (i in 0 until value.length()) collectAny(value.opt(i))
                is JSONObject -> {
                    listOf("GuideNumber", "guideNumber", "Number", "number", "id", "ID", "GuideName", "guideName", "Name", "name").forEach { key ->
                        val token = value.optString(key).trim()
                        if (token.isNotBlank()) members += token.lowercase(Locale.US)
                    }
                    value.keys().forEach { key ->
                        if (key.equals("name", true) || key.equals("title", true)) return@forEach
                        collectAny(value.opt(key))
                    }
                }
                is String -> {
                    val cleaned = value.trim()
                    if (cleaned.isNotBlank() && !cleaned.startsWith("http")) members += cleaned.lowercase(Locale.US)
                }
                is Number -> members += value.toString().lowercase(Locale.US)
            }
        }
        listOf("channels", "Channels", "channelNumbers", "stations", "members", "items").forEach { key -> collectAny(obj.opt(key)) }
    }

    private fun parseDeviceNames(json: String): List<String> {
        val names = linkedSetOf<String>()
        fun addName(raw: String?) {
            val value = raw?.trim().orEmpty()
            if (value.isNotBlank()) names += value
        }
        fun addFromObject(obj: JSONObject?) {
            if (obj == null) return
            addName(obj.optString("Name"))
            addName(obj.optString("name"))
            addName(obj.optString("FriendlyName"))
            addName(obj.optString("friendlyName"))
            addName(obj.optString("DeviceID"))
            addName(obj.optString("deviceId"))
            addName(obj.optString("ID"))
            addName(obj.optString("id"))
        }
        try {
            if (json.trim().startsWith("[")) {
                val arr = JSONArray(json)
                for (i in 0 until arr.length()) {
                    when (val item = arr.opt(i)) {
                        is JSONObject -> addFromObject(item)
                        is String -> addName(item)
                    }
                }
            } else {
                val root = JSONObject(json)
                val arr = root.optJSONArray("devices")
                    ?: root.optJSONArray("Devices")
                    ?: root.optJSONArray("results")
                    ?: root.optJSONArray("Results")
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        when (val item = arr.opt(i)) {
                            is JSONObject -> addFromObject(item)
                            is String -> addName(item)
                        }
                    }
                }
                addFromObject(root)
            }
        } catch (_: Exception) {
        }
        return names.filterNot { it.equals("ANY", ignoreCase = true) }
    }

    private fun parseDvrChannels(base: String, device: String, json: String): List<ChannelItem> {
        val out = mutableListOf<ChannelItem>()
        try {
            val arr = if (json.trim().startsWith("[")) {
                JSONArray(json)
            } else {
                val root = JSONObject(json)
                root.optJSONArray("channels") ?: root.optJSONArray("Channels") ?: JSONArray()
            }

            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue

                val guideNumber = obj.optString("GuideNumber")
                    .ifBlank { obj.optString("Number") }
                    .ifBlank { obj.optString("number") }

                val id = obj.optString("id")
                    .ifBlank { obj.optString("ID") }
                    .ifBlank { guideNumber }

                val name = obj.optString("GuideName")
                    .ifBlank { obj.optString("Name") }
                    .ifBlank { obj.optString("name") }
                    .ifBlank { obj.optString("channel") }
                    .ifBlank { "Channel ${if (guideNumber.isNotBlank()) guideNumber else id}" }

                val playbackKey = guideNumber.ifBlank { id }
                if (playbackKey.isBlank()) continue

                val encodedDevice = encodeURIComponent(device)
                val encodedChannel = encodeURIComponent(playbackKey)
                val url = "$base/devices/$encodedDevice/channels/$encodedChannel/stream.mpg?format=ts&codec=copy"

                val groups = mutableListOf<String>()
                val lowerName = name.lowercase(Locale.US)
                when {
                    "sport" in lowerName || "espn" in lowerName || "fox sports" in lowerName -> groups += "Sports"
                    "news" in lowerName || "cnn" in lowerName || "fox" in lowerName || "msnbc" in lowerName || "cspan" in lowerName -> groups += "News"
                    "kid" in lowerName || "cartoon" in lowerName || "disney" in lowerName || "nick" in lowerName -> groups += "Kids"
                    "movie" in lowerName || "cinemax" in lowerName || "hbo" in lowerName || "starz" in lowerName || "showtime" in lowerName -> groups += "Movies"
                }
                groups += "Channels DVR"

                val iconUrl = sequenceOf(
                    obj.optString("ImageURL").trim(),
                    obj.optString("Image").trim(),
                    obj.optString("imageUrl").trim(),
                    obj.optString("LogoURL").trim(),
                    obj.optString("logoUrl").trim(),
                    obj.optString("logo").trim()
                ).firstOrNull { it.isNotBlank() }.orEmpty()
                val debug = buildString {
                    append("device=")
                    append(device)
                    if (guideNumber.isNotBlank()) append(" • guide=").append(guideNumber)
                    if (id.isNotBlank()) append(" • id=").append(id)
                    append(" • playKey=")
                    append(playbackKey)
                    if (groups.isNotEmpty()) append(" • groups=").append(groups.joinToString("/"))
                }
                out += ChannelItem(name, url, "Channels DVR", debug, groups.distinct(), guideNumber, iconUrl)
            }
        } catch (_: Exception) {
        }
        return out
    }


    private fun parseDvrM3u(base: String, body: String): List<ChannelItem> {
        val items = mutableListOf<ChannelItem>()
        var currentMeta = ""
        body.lineSequence().forEach { raw ->
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> currentMeta = line
                line.isBlank() || line.startsWith("#") -> Unit
                currentMeta.isNotBlank() -> {
                    val name = currentMeta.substringAfter(',', missingDelimiterValue = "").trim().ifBlank { "DVR Channel ${items.size + 1}" }
                    val group = Regex("""group-title="([^"]+)""", RegexOption.IGNORE_CASE).find(currentMeta)?.groupValues?.getOrNull(1).orEmpty()
                    val tvgName = Regex("""tvg-name="([^"]+)""", RegexOption.IGNORE_CASE).find(currentMeta)?.groupValues?.getOrNull(1).orEmpty()
                    val chno = Regex("""tvg-chno="([^"]+)""", RegexOption.IGNORE_CASE).find(currentMeta)?.groupValues?.getOrNull(1).orEmpty()
                    val iconUrl = Regex("""tvg-logo="([^"]+)""", RegexOption.IGNORE_CASE).find(currentMeta)?.groupValues?.getOrNull(1).orEmpty()
                    val groups = mutableListOf<String>()
                    if (group.isNotBlank()) groups += group
                    val debug = buildString {
                        append("m3u")
                        if (tvgName.isNotBlank()) append(" • tvg=").append(tvgName)
                        if (group.isNotBlank()) append(" • group=").append(group)
                        if (chno.isNotBlank()) append(" • ch=").append(chno)
                    }
                    items += ChannelItem(
                        name = if (tvgName.isNotBlank()) tvgName else name,
                        url = line,
                        source = "Channels DVR",
                        debug = debug,
                        groups = (groups + "Channels DVR").distinct(),
                        number = chno,
                        iconUrl = iconUrl
                    )
                    currentMeta = ""
                }
            }
        }
        return items.distinctBy { it.name + "|" + it.url }
    }

    private fun getJson(url: String, connectTimeoutMs: Int = 6000, readTimeoutMs: Int = 6000): HttpResult {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = connectTimeoutMs
        connection.readTimeout = readTimeoutMs
        connection.instanceFollowRedirects = true
        connection.requestMethod = "GET"
        return try {
            connection.connect()
            val code = connection.responseCode
            if (code !in 200..299) {
                HttpResult(null, "HTTP $code")
            } else {
                val body = BufferedReader(InputStreamReader(connection.inputStream)).use { it.readText() }
                HttpResult(body, null)
            }
        } catch (e: Exception) {
            HttpResult(null, e.javaClass.simpleName + (e.message?.let { ": $it" } ?: ""))
        } finally {
            connection.disconnect()
        }
    }

    private fun getText(url: String): HttpResult {
        return getJson(url)
    }

    private fun encodeURIComponent(value: String): String = URLEncoder.encode(value, "UTF-8")
}
