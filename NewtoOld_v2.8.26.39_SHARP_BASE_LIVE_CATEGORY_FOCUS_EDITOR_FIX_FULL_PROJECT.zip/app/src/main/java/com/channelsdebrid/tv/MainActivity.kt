package com.channelsdebrid.tv

import com.channelsdebrid.tv.net.BackendEndpoint
import android.content.Intent
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.channelsdebrid.tv.data.BackendHomeLoader
import com.channelsdebrid.tv.data.BackendlessArtworkProvider
import com.channelsdebrid.tv.data.StremioLiveLoader
import com.channelsdebrid.tv.data.UnifiedCatalogRepository
import com.channelsdebrid.tv.config.UIConfigManager
import com.channelsdebrid.tv.playback.MediaDetailsActivity
import com.channelsdebrid.tv.settings.HomeLayoutSettings
import com.channelsdebrid.tv.settings.SettingsRepository
import com.channelsdebrid.tv.settings.homeLayoutFontName
import com.channelsdebrid.tv.settings.homeLayoutTypeface
import com.channelsdebrid.tv.settings.homeLayoutRingColor
import java.io.File
import java.util.concurrent.Executors
import org.json.JSONArray
import org.json.JSONObject

/**
 * NewtoOld v2.1 hard home rebuild.
 *
 * This file intentionally does not use the previous ScrollView + per-row binding system.
 * Rows are owned by one vertical RecyclerView and one explicit FocusGraph so DPAD DOWN/UP
 * cannot be stolen by legacy scroll recovery code.
 */
class MainActivity : AppCompatActivity() {
    private companion object {
        private const val BACKEND_BASE_URL = "http://192.168.100.55:8181"
        private const val TAG = "DebridChannels"
    }

    private lateinit var repository: SettingsRepository
    private var config = HomeLayoutSettings()
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val backendLoader = BackendHomeLoader()
    private val artworkProvider by lazy { BackendlessArtworkProvider(this) }
    private val stremioLoader = StremioLiveLoader()

    private lateinit var root: FrameLayout
    private lateinit var heroBackdrop: ImageView
    private lateinit var heroPosterDepthLayer: ImageView
    private lateinit var heroCutoutGlowLayer: ImageView
    private var heroBackdropTarget: CustomTarget<Drawable>? = null
    private var heroPosterDepthLayerTarget: CustomTarget<Drawable>? = null
    private lateinit var heroScrim: View
    private lateinit var heroBottomFade: View
    private lateinit var heroLighting: View
    private lateinit var heroText: LinearLayout
    private lateinit var heroTitle: TextView
    private lateinit var heroMeta: TextView
    private lateinit var heroGenrePills: LinearLayout
    private lateinit var heroRatings: LinearLayout
    private lateinit var imdbBadge: TextView
    private lateinit var tmdbBadge: TextView
    private lateinit var heroDesc: TextView
    private lateinit var heroLogo: ImageView
    private lateinit var heroExtraArt: ImageView
    private lateinit var topMenu: LinearLayout
    private lateinit var sideMenu: LinearLayout
    private lateinit var rowsRecycler: RecyclerView
    private lateinit var stableRowsScroll: ScrollView
    private lateinit var stableRowsColumn: LinearLayout
    private lateinit var statusPill: TextView

    private val rowRecyclerByIndex = LinkedHashMap<Int, RecyclerView>()
    private val stableRowByIndex = LinkedHashMap<Int, LinearLayout>()
    private val stableScrollerByIndex = LinkedHashMap<Int, HorizontalScrollView>()
    private val stableCardByKey = LinkedHashMap<String, FrameLayout>()
    private var currentRows: List<HomeRow> = emptyList()
    private var lastFocusedRow = 0
    private var lastFocusedColumn = 0
    private var holdLastCardHighlightForMenu = false
    private var lastHeroBackdropKey: String = ""
    private var lastHeroLogoKey: String = ""
    private var lastHeroExtraKey: String = ""
    private var lastHeroIdentityKey: String = ""
    private var pendingHeroItem: TitleCard? = null
    private val heroUpdateRunnable = Runnable {
        pendingHeroItem?.let { applyHeroNow(it) }
        pendingHeroItem = null
    }

    data class TitleCard(
        val title: String,
        val meta: String,
        val desc: String,
        val backgroundRes: Int,
        val posterUrl: String? = null,
        val backdropUrl: String? = null,
        val logoUrl: String? = null,
        val heroForegroundCutoutUrl: String? = null,
        val heroBackdropAssetUrl: String? = null,
        val heroPaletteUrl: String? = null,
        val heroMaskQualityUrl: String? = null,
        val mediaType: String = "movie",
        val externalId: String? = null,
        val year: Int = 0,
        val source: String = "Local"
    )

    data class HomeRow(val title: String, val items: List<TitleCard>)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.channelsdebrid.tv.config.UiModeApplier.apply(this)
        com.channelsdebrid.tv.settings.UiPresetManager.applyBundledDefaultPresetIfNeeded(this)
        repository = SettingsRepository(this)
        config = repository.loadHomeLayout()
        applyNativeUiConfig()
        Log.i(TAG, "DC_BUILD_MARKER: NewtoOld_v2.8.26.39_SHARP_BASE_LIVE_CATEGORY_FOCUS_EDITOR_FIX_FULL_PROJECT")
        Log.i(TAG, "HERO_FOREGROUND_PRIORITY: enabled=true rollbackPref=hero_foreground_priority_enabled layers=rows_under_hero_content menu_top")
        Log.i(TAG, "HERO_FOREGROUND_PRIORITY_ROLLBACK: set pref hero_foreground_priority_enabled=false to restore classic layering")
        Log.i(TAG, "HERO_METADATA_BIND_RESTORE: success=true logo_meta_genre_in_identity=true cache_untouched=true")
        Log.i(TAG, "FOCUSED_CARD_LOGO_LAYER: restored=true row_logo_renderer_original=true")
        Log.i(TAG, "GENRE_BIND_PIPELINE: restored=true focused_card_pill=true")
        Log.i(TAG, "PERSISTENT_ARTWORK_CATALOG_CACHE: enabled=true diskRows=true glideWarm=true staleWhileRefresh=true")
        Log.i(TAG, "SMART_STARTUP_CACHE_STRATEGY: cached_home_instant=true hero_first=true visibleWindowItems=24 backgroundRefresh=true preloadEverything=false")
        Log.i(TAG, "INSTANT_HOME_PIPELINE: enabled=true endpoints=/api/home/instant,/api/home/hero cachedSnapshotFirst=true backendReadyRows=true normalizedArtworkUrls=true")
        Log.i(TAG, "BACKEND_TRAILER_CACHE_ENGINE: enabled=true scope=hero_rows mode=metadata_thumbnail_video_cache backendCdnPreferred=true lazyQueue=true")
        Log.i(TAG, "BACKEND_IMAGE_CDN_CACHE_ENGINE: enabled=true hero4K=true rowsPersistent=true appRequestsBackendProxy=true")
        Log.i(TAG, "HERO_4K_ARTWORK_FORCE: enabled=true target=3840x2160 uiMayRemain1080p=true quality=ARGB_8888")
        Log.i(TAG, "PERFORMANCE_RENDER_REWRITE: lazy_card_image_decode=true focus_window_prefetch=true no_all_card_decode_on_start=true smart_startup_cache=true")
        Log.i(TAG, "CACHE_RENDER_AUDIT: hero_cache_untouched=true row_disk_cache_untouched=true glide_disk_cache_untouched=true startup_visible_window_only=true")
        Log.i(TAG, "HERO_CUTOUT_ASSET_PIPELINE_CONTROL: enabled=true depthPercent=${config.heroPosterDepthPercent} singleHeroImage=true oldBackdropRenderer=false globalGlow=false backendFields=hero_backdrop,hero_foreground_cutout,hero_palette,hero_mask_quality opacityFix=true")
        Log.i(TAG, "LIVE_TV_BOOT_ISOLATION: enabled=true no_m3u_xmltv_parse_on_home=true gracenote_restored_in_live_tv=true")
        val activeProfile = ProfileManager.activeProfile(this)
        Log.i(TAG, "PROFILE_SYSTEM_ACTIVE: id=${activeProfile.id} kids=${activeProfile.kidsMode}")
        Log.i(TAG, "QR_SYSTEM_READY: setupActivity=true presetPairing=true")
        Log.i(TAG, "BRAND_PURGE_AUDIT: legacyBrandReferences=0 visibleText=DebridChannels")
        Log.i(TAG, "DIM_UNFOCUSED_CARDS_EDITOR_FIX: runtimeAlphaWired=true sliderPercent=${config.dimUnfocusedPercent}")
        Log.i(TAG, "PRO_EDITOR_FULL_WIRING_AUDIT: extraArtworkVisible=${config.extraArtworkVisible} rowText=${config.rowTextVisible} focusRing=${config.focusRingEnabled} cardLogo=${config.cardLogoVisible} heroLogo=${config.heroLogoVisible} backdropStyle=${config.heroBackdropStyle}")
        Log.i(TAG, "MENU_HOLD_LAST_CARD_HIGHLIGHT: enabled=true topRowToMenu=true")
        Log.i(TAG, "ROW_ENGINE: V37_BASE_BACKEND_CUTOUT_ASSET_PIPELINE_OPACITY_FIX")
        Log.i(TAG, "FOCUS_EFFECTS_RESTORED: scale_ring_lift_active")
        Log.i(TAG, "FOCUS_GLOW_CONTROL: editor_slider_active strength_spread")
        Log.i(TAG, "STREMIO_LOGO_RESOLUTION: multi_key_meta_detail_metahub_fallback_active")
        Log.i(TAG, "HERO_BACKDROP_QUALITY: oldBackdropRenderer=false primaryCutoutARGB8888=true override=3840x2160 backendCutoutPreferred=true fallbackBackdropSafe=true globalGlow=false opacityFix=true")
        Log.i(TAG, "ROW_ENGINE: OLD_NEWTOOLD_ROW_RENDERERS_DELETED_DONOR_ROW_CARD_PATH_ACTIVE")
        Log.i(TAG, "FOCUS_GRAPH: V14_INSTANT_HOME_PREFETCH_STICKY_DIM")
        Log.i(TAG, "CLEAN_CORE_AUDIT: old_row_stack_deleted lazy_image_decode_sticky_dim cache_off_direct_player_preserved instant_home_pipeline_4k_hero ui_preset_picker_view_apply")
        Log.i(TAG, "PLAYER_FINAL_HARDENING: adaptive_buffering safe_watchdog silent_rebuffer decoder_memory network_aware audio_route_debounce session_stability_mode")
        Log.i(TAG, "TOP_MENU_ENGINE: FULL_THEME_CHOOSER_ACTIVE noGlassOption=true")
        Log.i(TAG, "DEBRID_STATUS: NOT_PRESENT runtimeHome=false")
        Log.i(TAG, "BACKENDLESS_ARTWORK_PROVIDER: ACTIVE mode=${config.artworkSourceMode}")
        buildUi()
        applyMenuTheme()
        val cachedRows = loadPersistentArtworkRowsCache()
        if (cachedRows.isNotEmpty()) {
            Log.i(TAG, "PERSISTENT_HOME_CACHE_HIT: rows=${cachedRows.size} staleWhileRefresh=true")
            setRows(cachedRows)
            warmCachedRowImages(cachedRows, limit = 24)
        } else {
            Log.i(TAG, "PERSISTENT_HOME_CACHE_MISS: using_local_fallback=true")
            setRows(defaultRows())
        }
        requestBackendInstantHomeRows("startup")
        loadArtworkRows()
        scheduleBackendTrailerCacheForRows(if (cachedRows.isNotEmpty()) cachedRows else defaultRows(), "startup_visible_rows")
        warmMoviesShowsInBackground()
    }


    private fun warmMoviesShowsInBackground() {
        io.execute {
            runCatching {
                val catalogRepo = UnifiedCatalogRepository(this)
                val preloadItems = catalogRepo.prewarmDiscoverySections(listOf("movies", "shows"), 42)
                preloadItems.forEach { item ->
                    listOf(item.posterUrl, item.backdropUrl, item.logoUrl)
                        .filter { it.isNotBlank() }
                        .take(3)
                        .forEach { url ->
                            runCatching {
                                Glide.with(applicationContext)
                                    .downloadOnly()
                                    .load(BackendEndpoint.imageProxyUrl(url))
                                    .submit()
                            }
                        }
                }
                val preloadCards = preloadItems.mapIndexed { index, item ->
                    TitleCard(
                        title = item.title,
                        meta = item.meta,
                        desc = item.overview,
                        backgroundRes = fallbackDrawable(index),
                        posterUrl = item.posterUrl.ifBlank { null },
                        backdropUrl = item.backdropUrl.ifBlank { null },
                        logoUrl = item.logoUrl.ifBlank { null },
                        mediaType = item.type.ifBlank { "movie" },
                        externalId = item.externalId.ifBlank { null },
                        year = extractYearFromMeta(item.meta),
                        source = "UnifiedCatalog"
                    )
                }
                requestBackendArtworkCache(preloadCards.take(72), "movies_shows_background")
                requestBackendTrailerCache(preloadCards.take(42), "movies_shows_background")
                runCatching { java.net.URL(BackendEndpoint.route("/api/prewarm")).openConnection().apply { connectTimeout = 1200; readTimeout = 1600 }.getInputStream().close() }
                Log.i(TAG, "MOVIES_SHOWS_PREWARM: cached_items=${preloadItems.size} domain=${BackendEndpoint.baseUrl()} backendTrailerCache=queued backendImageCdnCache=queued")
            }.onFailure { Log.w(TAG, "MOVIES_SHOWS_PREWARM_FAIL: ${it.message}") }
        }
    }

    private fun scheduleBackendTrailerCacheForRows(rows: List<HomeRow>, reason: String) {
        val visibleWindowItems = rows.flatMap { it.items.take(12) }.take(48)
        if (visibleWindowItems.isEmpty()) return
        io.execute {
            requestBackendArtworkCache(visibleWindowItems, reason)
            requestBackendTrailerCache(visibleWindowItems, reason)
        }
    }

    private fun requestBackendArtworkCache(items: List<TitleCard>, reason: String) {
        if (items.isEmpty()) return
        runCatching {
            val payload = JSONObject().apply {
                put("reason", reason)
                put("forceHero4K", true)
                put("cdnPersist", true)
                put("items", JSONArray().apply {
                    items.forEach { item ->
                        put(JSONObject().apply {
                            put("title", item.title)
                            put("type", item.mediaType)
                            put("externalId", item.externalId ?: "")
                            put("poster", item.posterUrl ?: "")
                            put("backdrop", item.backdropUrl ?: "")
                            put("logo", item.logoUrl ?: "")
                            put("year", item.year)
                        })
                    }
                })
            }
            postJsonToBackend("/api/artwork/cache", payload, 2500, 3500)
            Log.i(TAG, "BACKEND_IMAGE_CDN_CACHE_QUEUE: reason=$reason items=${items.size} hero4K=true rows=true")
        }.onFailure { Log.w(TAG, "BACKEND_IMAGE_CDN_CACHE_QUEUE_FAIL: reason=$reason ${it.message}") }
    }

    private fun requestBackendTrailerCache(items: List<TitleCard>, reason: String) {
        if (items.isEmpty()) return
        runCatching {
            val payload = JSONObject().apply {
                put("reason", reason)
                put("prefer4k", true)
                put("cacheVideo", true)
                put("cacheThumbnails", true)
                put("serveFromBackend", true)
                put("scope", "hero_rows_visible_window")
                put("items", JSONArray().apply {
                    items.forEach { item ->
                        put(JSONObject().apply {
                            put("title", item.title)
                            put("year", item.year)
                            put("type", item.mediaType.ifBlank { "movie" })
                            put("externalId", item.externalId ?: "")
                        })
                    }
                })
            }
            postJsonToBackend("/api/trailers/cache", payload, 2500, 5000)
            // Backward-compatible endpoint used by current backend builds. It can ignore unknown fields.
            postJsonToBackend("/trailers/prewarm", payload, 2500, 5000)
            Log.i(TAG, "BACKEND_TRAILER_CACHE_QUEUE: reason=$reason items=${items.size} cacheVideo=true prefer4K=true")
        }.onFailure { Log.w(TAG, "BACKEND_TRAILER_CACHE_QUEUE_FAIL: reason=$reason ${it.message}") }
    }

    private fun postJsonToBackend(path: String, payload: JSONObject, connectMs: Int, readMs: Int) {
        val connection = (java.net.URL(BackendEndpoint.route(path)).openConnection() as java.net.HttpURLConnection).apply {
            connectTimeout = connectMs
            readTimeout = readMs
            requestMethod = "POST"
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
        }
        try {
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            (if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream)?.close()
        } finally {
            connection.disconnect()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra("force_reload_layout", false)) {
            reloadHomeLayoutFromEditor()
        }
    }

    override fun onResume() {
        super.onResume()
        if (::repository.isInitialized) {
            val latest = repository.loadHomeLayout()
            if (latest != config) {
                config = latest
                reloadHomeLayoutFromEditor()
            }
        }
    }

    private fun reloadHomeLayoutFromEditor() {
        config = repository.loadHomeLayout()
        applyNativeUiConfig()
        buildUi()
        applyMenuTheme()
        val cachedRows = loadPersistentArtworkRowsCache()
        if (cachedRows.isNotEmpty()) {
            Log.i(TAG, "PERSISTENT_HOME_CACHE_HIT: rows=${cachedRows.size} staleWhileRefresh=true")
            setRows(cachedRows)
            warmCachedRowImages(cachedRows, limit = 24)
        } else {
            Log.i(TAG, "PERSISTENT_HOME_CACHE_MISS: using_local_fallback=true")
            setRows(defaultRows())
        }
        requestBackendInstantHomeRows("startup")
        requestBackendInstantHomeRows("layout_reload")
        loadArtworkRows()
        scheduleBackendTrailerCacheForRows(if (cachedRows.isNotEmpty()) cachedRows else defaultRows(), "startup_visible_rows")
        warmMoviesShowsInBackground()
        Log.i(TAG, "HOME_LAYOUT_RELOAD_FROM_EDITOR: applied_immediately=true build=NewtoOld_v2.8.26.14_ROW_CARD_LOGO_POSITION_HERO_GENRE_PILL")
    }


    private fun applyNativeUiConfig() {
        UIConfigManager.uiRenderMode = when (config.nativeUiResolutionMode.coerceIn(0, 2)) {
            1 -> UIConfigManager.UiRenderMode.NATIVE_1080P
            2 -> UIConfigManager.UiRenderMode.NATIVE_4K
            else -> UIConfigManager.UiRenderMode.AUTO
        }
        UIConfigManager.heroMenuPosition = heroMenuPosition()
        UIConfigManager.heroLightingEnabled = config.heroLightingEnabled == 1
        UIConfigManager.heroLightingIntensity = config.heroLightingIntensityPercent.coerceIn(0, 45) / 100f
        UIConfigManager.hdHomeRunAutoScanEnabled = repository.loadChannelsDvr().hdHomeRunAutoScan
        Log.i(TAG, "NATIVE_4K_UI_MODE: new_app_style active=${UIConfigManager.isNative4KActive(this)} mode=${UIConfigManager.uiRenderMode}")
        Log.i(TAG, "HERO_MENU_POSITION: ${UIConfigManager.heroMenuPosition}")
        Log.i(TAG, "HERO_LIGHTING: enabled=${UIConfigManager.heroLightingEnabled} intensity=${UIConfigManager.heroLightingIntensity}")
        Log.i(TAG, "HDHOMERUN_AUTO_SCAN_SETTING: ${UIConfigManager.hdHomeRunAutoScanEnabled}")
        Log.i(TAG, "HERO_BADGE_SYSTEM: imdb=${config.imdbBadgeVisible} tmdb=${config.tmdbBadgeVisible} ratings=${config.ratingNumbersVisible} theme=${config.heroBadgeTheme} position=${config.heroBadgePosition}")
        Log.i(TAG, "ROW_FOCUS_REWRITE: stableMode=${config.stableRowFocusMode}")
    }
    override fun onDestroy() {
        heroBackdropTarget?.let { runCatching { Glide.with(this).clear(it) } }
        super.onDestroy()
        io.shutdownNow()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun heroPosterDepthZ(): Float {
        val percent = config.heroPosterDepthPercent.coerceIn(0, 100)
        val rowZ = 24f
        // v2.8.26.35: cutout visibility/depth +30 total and real composite pop above rows while staying below metadata/logo layers.
        val posterDp = rowZ + 6f + (percent / 100f) * 22f
        return dp(posterDp.toInt()).toFloat()
    }


    private fun heroForegroundPriorityEnabled(): Boolean {
        return getSharedPreferences("layout", MODE_PRIVATE)
            .getBoolean("hero_foreground_priority_enabled", true)
    }

    private fun applyHeroForegroundPriorityLayers() {
        val enabled = heroForegroundPriorityEnabled()
        if (enabled) {
            // v2.8.26.36: restore ghost-row readability. The prior composite-pop build
            // placed a full-screen hero plane above rows, which hid them on real devices.
            // Keep glow/cutout behind the row ghost layer, but close enough in Z to read
            // as depth. Metadata/logo/menu remain above both.
            val primaryHeroZ = dp(40).toFloat()
            val rowsZ = dp(52).toFloat()
            val depth = config.heroPosterDepthPercent.coerceIn(0, 100)
            // v2.8.26.31 OPTION 3 TEST: the synced foreground/cutout hero becomes the
            // primary hero art plane. The original full-screen backdrop is kept only as
            // a very dim ambient color source so there is no double-head/double-poster conflict.
            // v2.8.26.39 opacity fix: do not boost the whole image into a flat poster sheet.
            // A true backend cutout can be fully visible because transparent pixels do the masking;
            // fallback backdrops stay softer so they do not wash out ghost rows or cut off the right side.
            val usingBackendCutout = lastHeroBackdropKey.startsWith("cutout:")
            val cutoutAlpha = if (usingBackendCutout) 0.98f else (0.70f + (depth / 100f) * 0.10f).coerceIn(0.70f, 0.80f)
            val popScale = if (usingBackendCutout) (1.018f + (depth / 100f) * 0.030f) else 1.0f
            heroPosterDepthLayer.elevation = primaryHeroZ
            heroPosterDepthLayer.translationZ = primaryHeroZ
            heroPosterDepthLayer.alpha = cutoutAlpha
            heroPosterDepthLayer.scaleX = popScale
            heroPosterDepthLayer.scaleY = popScale
            heroPosterDepthLayer.translationY = -dp((3 + depth / 28).coerceIn(3, 7)).toFloat()
            heroPosterDepthLayer.visibility = View.VISIBLE
            applyHeroCutoutGlow(depth, primaryHeroZ)
            heroText.elevation = dp(92).toFloat()
            heroText.translationZ = dp(92).toFloat()
            heroLogo.elevation = dp(96).toFloat()
            heroLogo.translationZ = dp(96).toFloat()
            heroExtraArt.elevation = dp(88).toFloat()
            heroExtraArt.translationZ = dp(88).toFloat()
            topMenu.elevation = dp(90).toFloat()
            topMenu.translationZ = dp(90).toFloat()
            sideMenu.elevation = dp(90).toFloat()
            sideMenu.translationZ = dp(90).toFloat()
            rowsRecycler.elevation = rowsZ
            rowsRecycler.translationZ = rowsZ
            stableRowsScroll.elevation = rowsZ
            stableRowsScroll.translationZ = rowsZ
            applyHeroPosterCutoutParams()
        } else {
            heroText.elevation = 0f
            heroText.translationZ = 0f
            heroLogo.elevation = dp(20).toFloat()
            heroLogo.translationZ = dp(20).toFloat()
            heroExtraArt.elevation = 0f
            heroExtraArt.translationZ = 0f
            heroPosterDepthLayer.elevation = 0f
            heroPosterDepthLayer.translationZ = 0f
            heroPosterDepthLayer.alpha = 0f
            heroPosterDepthLayer.visibility = View.INVISIBLE
            if (::heroCutoutGlowLayer.isInitialized) {
                heroCutoutGlowLayer.alpha = 0f
                heroCutoutGlowLayer.visibility = View.INVISIBLE
            }
            topMenu.elevation = 0f
            topMenu.translationZ = 0f
            sideMenu.elevation = 0f
            sideMenu.translationZ = 0f
        }
        Log.i(TAG, "HERO_CUTOUT_ASSET_PIPELINE_APPLY: enabled=$enabled depthPercent=${config.heroPosterDepthPercent} cutoutZ=${heroPosterDepthLayer.translationZ} cutoutAlpha=${heroPosterDepthLayer.alpha} glowAlpha=${if (::heroCutoutGlowLayer.isInitialized) heroCutoutGlowLayer.alpha else 0f} rowsZ=${stableRowsScroll.translationZ} oldBackdropRenderer=false darkBalance=true backendCutoutPreferred=true fallbackOpacitySafe=true globalGlow=false rowsRestored=true")
        Log.i(TAG, "HERO_FOREGROUND_PRIORITY_APPLY: enabled=$enabled heroTextZ=${heroText.translationZ} heroLogoZ=${heroLogo.translationZ} heroExtraArtZ=${heroExtraArt.translationZ} menuZ=${topMenu.translationZ} rowsZ=${stableRowsScroll.translationZ} ghostRowsPreserved=true")
    }

    private fun applyHeroCutoutGlow(depth: Int, primaryHeroZ: Float) {
        // v2.8.26.37: remove the full-plane warm glow/bloom.
        // The previous glow used the whole hero drawable, so titles with wide
        // environmental artwork looked like a glowing flat poster sheet.
        if (!::heroCutoutGlowLayer.isInitialized) return
        heroCutoutGlowLayer.setImageDrawable(null)
        heroCutoutGlowLayer.clearColorFilter()
        heroCutoutGlowLayer.alpha = 0f
        heroCutoutGlowLayer.visibility = View.GONE
        heroCutoutGlowLayer.elevation = 0f
        heroCutoutGlowLayer.translationZ = 0f
    }

    private fun applyHeroCutoutGlowParams() {
        if (!::heroCutoutGlowLayer.isInitialized) return
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        heroCutoutGlowLayer.layoutParams = FrameLayout.LayoutParams(screenW, screenH, Gravity.TOP or Gravity.START)
        heroCutoutGlowLayer.clipToOutline = false
        heroCutoutGlowLayer.invalidate()
    }

    private fun applyHeroPosterCutoutParams() {
        if (!::heroPosterDepthLayer.isInitialized) return
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        // Option 3 primary hero mode: use the synced foreground/cutout hero as the main
        // cinematic plane. It spans the screen like a hero backdrop, while rows remain
        // above it and the old backdrop is dimmed to ambient color only.
        val lp = FrameLayout.LayoutParams(screenW, screenH, Gravity.TOP or Gravity.START).apply {
            leftMargin = 0
            topMargin = 0
        }
        heroPosterDepthLayer.layoutParams = lp
        heroPosterDepthLayer.clipToOutline = false
        heroPosterDepthLayer.invalidate()
    }

    private fun buildUi() {
        root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            clipChildren = false
            clipToPadding = false
        }
        heroBackdrop = ImageView(this).apply {
            // v2.8.26.32: retained only as an unused compatibility field; not added to root.
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0f
            visibility = View.GONE
        }
        heroPosterDepthLayer = ImageView(this).apply {
            // Primary cutout hero plane: the only active hero artwork image.
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0f
            visibility = View.INVISIBLE
            adjustViewBounds = false
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
        }
        heroCutoutGlowLayer = ImageView(this).apply {
            // v2.8.26.37: compatibility placeholder only; global glow render path disabled.
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0f
            visibility = View.INVISIBLE
            adjustViewBounds = false
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
        }
        heroScrim = View(this).apply {
            background = cinematicHeroScrim()
        }
        heroBottomFade = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x00000000, 0x66000000, 0xEE000000.toInt())
            )
        }
        heroLighting = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x00000000, 0x1800AEEF, 0x33000000)
            )
            alpha = (config.heroLightingIntensityPercent.coerceIn(0, 45) / 100f)
            visibility = if (config.heroLightingEnabled == 1) View.VISIBLE else View.GONE
        }
        heroText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(34 + config.heroTextLeftDp), dp(118 + config.heroTextTopDp), dp(34), 0)
            clipChildren = false
        }
        heroTitle = TextView(this).apply {
            textSize = 48f * (config.heroTextSizePercent.coerceIn(60, 160) / 100f)
            setTextColor(Color.WHITE)
            setShadowLayer(dp(5).toFloat(), 0f, dp(2).toFloat(), 0xCC000000.toInt())
            typeface = homeLayoutTypeface(config.heroFontIndex)
            maxLines = 2
        }
        heroMeta = TextView(this).apply {
            textSize = 19f * (config.heroTextSizePercent.coerceIn(60, 160) / 100f)
            setTextColor(0xFFFFFFFF.toInt())
            setShadowLayer(dp(4).toFloat(), 0f, dp(2).toFloat(), 0xCC000000.toInt())
            typeface = homeLayoutTypeface(config.heroFontIndex)
            setPadding(0, dp(12), 0, 0)
        }
        heroGenrePills = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, 0)
            clipChildren = false
        }
        heroRatings = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        imdbBadge = ratingBadge("IMDb", 0xFFFFC400.toInt(), 0xFF101010.toInt())
        tmdbBadge = ratingBadge("TMDB", 0xFF01B4E4.toInt(), 0xFFFFFFFF.toInt())

        heroDesc = TextView(this).apply {
            textSize = 24f * (config.heroTextSizePercent.coerceIn(60, 160) / 100f)
            setTextColor(Color.WHITE)
            setShadowLayer(dp(5).toFloat(), 0f, dp(2).toFloat(), 0xD9000000.toInt())
            typeface = homeLayoutTypeface(config.heroFontIndex)
            maxLines = 3
            setPadding(0, dp(14), dp(380), 0)
        }
        heroText.addView(heroTitle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        heroText.addView(heroMeta, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        heroText.addView(heroGenrePills, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)))
        heroText.addView(heroRatings, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)))
        heroText.addView(heroDesc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        heroLogo = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            visibility = View.INVISIBLE
            elevation = dp(20).toFloat()
        }

        heroExtraArt = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            elevation = 0f
            visibility = View.INVISIBLE
        }

        topMenu = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            clipChildren = false
            clipToPadding = false
            translationX = dp(config.topMenuOffsetDp).toFloat()
        }
        buildTopMenuItems()
        sideMenu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(10), dp(34), dp(10), dp(28))
            clipChildren = false
            clipToPadding = false
            background = rounded(0x66000000, 28, 0x22FFFFFF, 1)
            visibility = if (useLeftSidebar()) View.VISIBLE else View.GONE
        }
        buildSideMenuItems()
        topMenu.visibility = if (useLeftSidebar()) View.GONE else View.VISIBLE

        // v2.8.16.1: donor new-app row/card renderer path.
        // Only the active row is attached; all cards in that active row remain available horizontally.
        rowsRecycler = RecyclerView(this).apply {
            id = View.generateViewId()
            layoutManager = LinearLayoutManager(this@MainActivity, RecyclerView.VERTICAL, false)
            itemAnimator = null
            overScrollMode = View.OVER_SCROLL_NEVER
            clipChildren = false
            clipToPadding = false
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
            setHasFixedSize(true)
            isFocusable = false
            visibility = View.GONE
            recycledViewPool.setMaxRecycledViews(0, 8)
        }

        stableRowsColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            setPadding(0, 0, 0, dp(80))
        }
        stableRowsScroll = ScrollView(this).apply {
            id = View.generateViewId()
            isFillViewport = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipChildren = false
            clipToPadding = false
            isFocusable = false
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
            elevation = dp(24).toFloat()
            addView(stableRowsColumn, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        statusPill = TextView(this).apply {
            text = "10:17 PM   •   No new favorites"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = rounded(0x66000000, 24, 0x55FFFFFF, 1)
        }

        // v2.8.26.32: do not attach the old full-screen hero backdrop.
        root.addView(heroScrim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(heroBottomFade, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(360), Gravity.BOTTOM))
        root.addView(heroLighting, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(topMenu, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(58), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(UIConfigManager.menuTopMarginDp(this@MainActivity, heroMenuPosition())) })
        root.addView(sideMenu, FrameLayout.LayoutParams(dp(74), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.START or Gravity.CENTER_VERTICAL).apply { leftMargin = dp(18) })
        // v2.8.26.37: global glow layer removed. Only the primary cutout hero plane is attached; ghost rows stay visible.
        root.addView(heroPosterDepthLayer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        applyHeroPosterCutoutParams()
        root.addView(rowsRecycler, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply {
            topMargin = dp(config.rowTopDp.coerceIn(360, 620))
            leftMargin = dp((if (useLeftSidebar()) 92 else 0) + config.rowLeftDp.coerceIn(0, 120))
            bottomMargin = dp(config.bottomSafeDp.coerceIn(24, 160))
        })
        root.addView(stableRowsScroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply {
            topMargin = dp(config.rowTopDp.coerceIn(360, 620))
            leftMargin = dp((if (useLeftSidebar()) 92 else 0) + config.rowLeftDp.coerceIn(0, 120))
            bottomMargin = dp(config.bottomSafeDp.coerceIn(24, 160))
        })
        root.addView(heroExtraArt, extraArtHeroParams())
        root.addView(heroText, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(430), Gravity.TOP or Gravity.START))
        root.addView(heroLogo, heroLogoParams())
        topMenu.bringToFront()
        sideMenu.bringToFront()
        // Keep rows in front of the full-screen cutout plane; bring only metadata layers forward.
        heroExtraArt.bringToFront()
        heroText.bringToFront()
        heroLogo.bringToFront()
        topMenu.bringToFront()
        sideMenu.bringToFront()
        stableRowsScroll.visibility = View.VISIBLE
        if (config.statusHubVisible == 1) {
            root.addView(statusPill, FrameLayout.LayoutParams(dp(490), dp(58), Gravity.BOTTOM or Gravity.END).apply {
                rightMargin = dp(26)
                bottomMargin = dp(26)
            })
        }
        Log.i(TAG, "STATUS_HUB_VISIBLE_APPLY: ${config.statusHubVisible == 1}")
        applyHeroForegroundPriorityLayers()
        setContentView(root)
    }


    private fun ratingBadge(label: String, bgColor: Int, fgColor: Int): TextView = TextView(this).apply {
        text = label
        textSize = if (label == "IMDb") 12f else 11f
        setTextColor(fgColor)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = rounded(bgColor, if (label == "IMDb") 5 else 12, 0x33FFFFFF, 1)
        setPadding(dp(8), 0, dp(8), 0)
    }

    private fun heroMenuPosition(): UIConfigManager.HeroMenuPosition = when (config.heroMenuVerticalPosition.coerceIn(0, 3)) {
        0 -> UIConfigManager.HeroMenuPosition.TOP
        2 -> UIConfigManager.HeroMenuPosition.LOWER
        3 -> UIConfigManager.HeroMenuPosition.TOP_EDGE
        else -> UIConfigManager.HeroMenuPosition.CENTER
    }

    private data class RatingValues(val imdb: String, val tmdb: String)

    private fun bindHeroRatingBadges(item: TitleCard) {
        val values = extractHeroRatings(item)
        heroRatings.removeAllViews()
        if (config.imdbBadgeVisible == 1) addRatingBadge("IMDb", values.imdb, true, 0xFFF5C518.toInt(), 0xFF111111.toInt())
        if (config.tmdbBadgeVisible == 1) addRatingBadge("TMDB", values.tmdb, false, 0xFF01B4E4.toInt(), 0xFFFFFFFF.toInt())
        heroRatings.visibility = if (heroRatings.childCount > 0) View.VISIBLE else View.GONE
        placeRatingBadges()
        Log.i(TAG, "HERO_BADGE_THEME_APPLY: imdb=${values.imdb.ifBlank { "badge-only" }} tmdb=${values.tmdb.ifBlank { "badge-only" }} theme=${config.heroBadgeTheme} numbers=${config.ratingNumbersVisible} rawMeta=${item.meta}")
    }

    private fun placeRatingBadges() {
        if (heroRatings.parent === heroText) heroText.removeView(heroRatings)
        val index = when (config.heroBadgePosition.coerceIn(0, 3)) {
            1 -> 3 // keep ratings after the hero genre pill lane
            2 -> 1
            3 -> heroText.childCount
            else -> 3
        }.coerceIn(0, heroText.childCount)
        heroText.addView(heroRatings, index, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)))
    }

    private fun extractHeroRatings(item: TitleCard): RatingValues {
        val raw = listOf(item.meta, item.source, item.desc).joinToString("  •  ")
        val imdb = extractRating(raw, listOf("IMDb", "IMDB", "imdbRating", "imdb_rating"))
        val tmdb = extractRating(raw, listOf("TMDB", "tmdbRating", "tmdb_rating", "vote_average", "voteAverage", "vote average"))
            .ifBlank { extractTmdbFallback(raw) }
        return RatingValues(imdb, tmdb)
    }

    private fun extractRating(raw: String, labels: List<String>): String {
        labels.forEach { label ->
            val rx = Regex("(?:^|[\\s•|,;])" + Regex.escape(label) + "\\s*(?:rating|score)?\\s*[:★⭐=/|-]?\\s*([0-9]+(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE)
            val found = rx.find(raw)?.groupValues?.getOrNull(1)
            if (!found.isNullOrBlank()) return normalizeRating(found)
        }
        return ""
    }

    private fun extractTmdbFallback(raw: String): String {
        val patterns = listOf(
            Regex("TMDB[^0-9]{0,18}([0-9]+(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE),
            Regex("vote[_ ]?average[^0-9]{0,18}([0-9]+(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE),
            Regex("tmdbRating[^0-9]{0,18}([0-9]+(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE)
        )
        patterns.forEach { rx ->
            val found = rx.find(raw)?.groupValues?.getOrNull(1)
            if (!found.isNullOrBlank()) return normalizeRating(found)
        }
        return ""
    }

    private fun normalizeRating(value: String): String {
        val n = value.toDoubleOrNull() ?: return value.trim()
        return java.lang.String.format(java.util.Locale.US, "%.1f", n.coerceIn(0.0, 10.0))
    }

    private fun addRatingBadge(label: String, value: String, imdb: Boolean, brandColor: Int, brandTextColor: Int) {
        val theme = config.heroBadgeTheme.coerceIn(0, 14)
        val showNumber = config.ratingNumbersVisible == 1 && value.isNotBlank()
        val badge = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            clipToPadding = false
            clipChildren = false
            elevation = dp(10).toFloat()
            background = badgeContainerBackground(theme, imdb, brandColor)
            setPadding(dp(3), dp(2), dp(8), dp(2))
        }
        val labelView = TextView(this).apply {
            text = when (theme) {
                7 -> if (imdb) "IMDb" else "TMDb"
                10 -> if (imdb) "IMDB" else "TMDB"
                11 -> if (imdb) "imdb" else "tmdb"
                else -> label.uppercase()
            }
            gravity = Gravity.CENTER
            includeFontPadding = false
            typeface = when (theme) {
                3, 9, 12 -> Typeface.create("sans-serif-condensed", Typeface.BOLD)
                4, 13 -> Typeface.create("serif", Typeface.BOLD)
                5, 14 -> Typeface.create("monospace", Typeface.BOLD)
                else -> Typeface.DEFAULT_BOLD
            }
            textSize = when (theme) { 3 -> 13f; 6 -> 16f; 10 -> 12f; 12 -> 15f; else -> 14f }
            setTextColor(if (theme in listOf(2,4,5,9,13)) Color.WHITE else brandTextColor)
            setPadding(dp(if (theme in listOf(6,12) ) 13 else 10), 0, dp(if (theme in listOf(6,12)) 13 else 10), 0)
            background = badgeLabelBackground(theme, brandColor, imdb)
        }
        val valueView = TextView(this).apply {
            text = value
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
            typeface = when (theme) {
                4, 13 -> Typeface.create("serif", Typeface.BOLD)
                5, 14 -> Typeface.create("monospace", Typeface.BOLD)
                7, 11 -> Typeface.create("sans-serif-light", Typeface.NORMAL)
                else -> homeLayoutTypeface(config.heroFontIndex)
            }
            textSize = when (theme) { 3 -> 17f; 6 -> 20f; 12 -> 19f; else -> 18f }
            setTextColor(when (theme) {
                0, 6, 10 -> Color.WHITE
                1 -> 0xFFE7EAEE.toInt()
                2 -> brandColor
                3 -> 0xFFF8FAFF.toInt()
                4 -> 0xFFFFF4C2.toInt()
                5 -> 0xFF9FFFE6.toInt()
                else -> 0xFFEFF4FA.toInt()
            })
            setPadding(dp(9), 0, dp(2), 0)
        }
        val labelHeight = when (theme) { 6, 12 -> 32; 10 -> 25; else -> 28 }
        badge.addView(labelView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(labelHeight)))
        if (showNumber) badge.addView(valueView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)))
        val outerHeight = when (theme) { 6, 12 -> 42; else -> 38 }
        heroRatings.addView(badge, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(outerHeight)).apply { rightMargin = dp(12) })
    }

    private fun badgeLabelBackground(theme: Int, brandColor: Int, imdb: Boolean): GradientDrawable = when (theme.coerceIn(0, 14)) {
        1 -> rounded(brandColor, 7, 0x55FFFFFF, 1)
        2 -> rounded(0x22000000, 10, brandColor, 2)
        3 -> rounded(brandColor, 2, 0x22FFFFFF, 1)
        4 -> rounded(0xAA111111.toInt(), 4, brandColor, 2)
        5 -> rounded(0x66000000, 4, brandColor, 2)
        6 -> rounded(brandColor, if (imdb) 6 else 10, 0x66FFFFFF, 1)
        7 -> rounded(brandColor, if (imdb) 4 else 8, 0x33FFFFFF, 1)
        8 -> rounded(0xAA05070B.toInt(), 14, brandColor, 2)
        9 -> rounded(0x33111111, 0, brandColor, 2)
        10 -> rounded(brandColor, 3, 0x33FFFFFF, 1)
        11 -> rounded(brandColor, 14, 0x33FFFFFF, 1)
        12 -> rounded(brandColor, 8, 0x66FFFFFF, 1)
        13 -> rounded(0x99101824.toInt(), 8, brandColor, 2)
        14 -> rounded(0xFF05070D.toInt(), 4, brandColor, 2)
        else -> rounded(brandColor, if (imdb) 5 else 8, 0x22FFFFFF, 1)
    }

    private fun badgeContainerBackground(theme: Int, imdb: Boolean, brandColor: Int): GradientDrawable = when (theme.coerceIn(0, 14)) {
        0 -> rounded(0x00000000, 0, Color.TRANSPARENT, 0)
        1 -> rounded(0xAA05070B.toInt(), 18, 0x22FFFFFF, 1)
        2 -> rounded(0x6605070B.toInt(), 18, brandColor, 1)
        3 -> rounded(0x33000000, 2, Color.TRANSPARENT, 0)
        4 -> rounded(0xCC05070B.toInt(), 12, 0x33FFFFFF, 1)
        5 -> rounded(0x99000203.toInt(), 6, brandColor, 1)
        6 -> rounded(0xCC05070B.toInt(), 12, 0x33FFFFFF, 1)
        7 -> rounded(Color.TRANSPARENT, 0, Color.TRANSPARENT, 0)
        8 -> rounded(Color.TRANSPARENT, 0, Color.TRANSPARENT, 0)
        9 -> rounded(0x44000000, 0, brandColor, 1)
        10 -> rounded(0x77000000, 9, Color.TRANSPARENT, 0)
        11 -> rounded(0x8805070B.toInt(), 18, 0x22FFFFFF, 1)
        12 -> rounded(0xDD05070B.toInt(), 14, 0x33FFFFFF, 1)
        13 -> rounded(0xAA101824.toInt(), 14, 0x33FFFFFF, 1)
        14 -> rounded(0xAA000000.toInt(), 6, brandColor, 1)
        else -> rounded(0x9905070B.toInt(), 8, 0x33FFFFFF, 1)
    }

    private fun useLeftSidebar(): Boolean = config.navigationMenuMode == 1

    private fun cinematicHeroScrim(): GradientDrawable {
        // v2.8.21.9: smarter half-fade. The left readability zone stays black, but the
        // center/right hero artwork is no longer crushed by the old heavy overlay. This is
        // specifically for backdrops where the face/subject sits near the left-middle.
        return if (config.heroBackdropStyle == 1) {
            GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(
                    0xFF000000.toInt(),
                    0xF6000000.toInt(),
                    0xD9000000.toInt(),
                    0x99000000.toInt(),
                    0x50000000,
                    0x18000000,
                    0x00000000
                )
            )
        } else {
            GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xF2000000.toInt(), 0xAA000000.toInt(), 0x22000000))
        }
    }

    private fun buildTopMenuItems() {
        topMenu.removeAllViews()
        val labels = menuLabelsForStyle(config.topMenuIconStyle)
        labels.forEachIndexed { index, item ->
            val tab = TextView(this).apply {
                id = View.generateViewId()
                text = item.first
                tag = item.second
                textSize = if (config.topMenuIconStyle == 2) 25f else 18f
                setTextColor(Color.WHITE)
                typeface = homeLayoutTypeface(config.topMenuFontIndex)
                gravity = Gravity.CENTER
                isFocusable = true
                isClickable = true
                setPadding(dp(18), 0, dp(18), 0)
                background = menuItemBg(false)
                setOnFocusChangeListener { v, hasFocus ->
                    v.background = menuItemBg(hasFocus)
                    (v as? TextView)?.paint?.isUnderlineText = hasFocus
                    (v as? TextView)?.setShadowLayer(if (hasFocus) dp(10).toFloat() else 0f, 0f, 0f, if (hasFocus) 0xCCBFEFFF.toInt() else Color.TRANSPARENT)
                    animateMenuFocus(v, hasFocus)
                }
                setOnClickListener { holdLastCardHighlightForMenu = false; refreshLastCardVisualIfVisible(); handleMenuAction(item.second) }
                setOnKeyListener { _, keyCode, event ->
                    if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                    when (keyCode) {
                        KeyEvent.KEYCODE_DPAD_DOWN -> {
                            focusCard(0, lastFocusedColumn.coerceAtLeast(0))
                            true
                        }
                        KeyEvent.KEYCODE_DPAD_LEFT -> {
                            topMenu.getChildAt((index - 1).coerceAtLeast(0))?.requestFocus(); true
                        }
                        KeyEvent.KEYCODE_DPAD_RIGHT -> {
                            topMenu.getChildAt((index + 1).coerceAtMost(topMenu.childCount - 1))?.requestFocus(); true
                        }
                        else -> false
                    }
                }
            }
            topMenu.addView(tab, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT).apply {
                leftMargin = dp(4)
                rightMargin = dp(4)
            })
        }
    }

    private fun buildSideMenuItems() {
        sideMenu.removeAllViews()
        val labels = listOf("⌂" to "home", "▶" to "live", "▣" to "movies", "▤" to "shows", "⌕" to "search", "⚙" to "settings")
        labels.forEachIndexed { index, item ->
            val tab = TextView(this).apply {
                id = View.generateViewId()
                text = item.first
                tag = item.second
                textSize = 26f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                isFocusable = true
                isClickable = true
                setPadding(0, dp(10), 0, dp(10))
                background = menuItemBg(false)
                setOnFocusChangeListener { v, hasFocus ->
                    v.background = menuItemBg(hasFocus)
                    animateMenuFocus(v, hasFocus)
                }
                setOnClickListener { holdLastCardHighlightForMenu = false; refreshLastCardVisualIfVisible(); handleMenuAction(item.second) }
                setOnKeyListener { _, keyCode, event ->
                    if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                    when (keyCode) {
                        KeyEvent.KEYCODE_DPAD_RIGHT -> { focusCard(lastFocusedRow.coerceAtLeast(0), lastFocusedColumn.coerceAtLeast(0)); true }
                        KeyEvent.KEYCODE_DPAD_UP -> { sideMenu.getChildAt((index - 1).coerceAtLeast(0))?.requestFocus(); true }
                        KeyEvent.KEYCODE_DPAD_DOWN -> { sideMenu.getChildAt((index + 1).coerceAtMost(sideMenu.childCount - 1))?.requestFocus(); true }
                        else -> false
                    }
                }
            }
            sideMenu.addView(tab, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)).apply { bottomMargin = dp(6) })
        }
    }

    private fun menuLabelsForStyle(style: Int): List<Pair<String, String>> = when (style.coerceIn(0, 5)) {
        1 -> listOf("◆ Home" to "home", "▶ Live TV" to "live", "▣ Movies" to "movies", "▤ Shows" to "shows", "⚙ Settings" to "settings", "⌕" to "search")
        2 -> listOf("⌂" to "home", "▶" to "live", "▣" to "movies", "▤" to "shows", "⚙" to "settings", "⌕" to "search")
        3 -> listOf("HOME" to "home", "LIVE" to "live", "MOVIES" to "movies", "SHOWS" to "shows", "SETTINGS" to "settings", "SEARCH" to "search")
        4 -> listOf("Home" to "home", "Live TV" to "live", "Movies" to "movies", "Shows" to "shows", "Settings" to "settings", "Search" to "search")
        5 -> listOf("⌂ Home" to "home", "◉ Live" to "live", "▰ Movies" to "movies", "▱ Shows" to "shows", "⚙ Settings" to "settings", "⌕ Search" to "search")
        else -> listOf("Home" to "home", "Live TV" to "live", "Movies" to "movies", "Shows" to "shows", "Settings" to "settings", "⌕" to "search")
    }

    private fun applyMenuTheme() {
        val theme = config.topMenuThemeStyle.coerceIn(0, 7)
        val bg: GradientDrawable? = when (theme) {
            0 -> null // true no-glass/no-pill mode
            1 -> rounded(0x00000000, 0, 0x00000000, 0) // flat transparent
            2 -> rounded(0x66000000, 24, 0x33FFFFFF, 1)
            3 -> rounded(0xCC06080F.toInt(), 18, 0xFFFFD84A.toInt(), 1)
            4 -> rounded(0xAA061A2A.toInt(), 34, 0x774DFFB8, 1)
            5 -> rounded(0xE60A0A10.toInt(), 8, 0x88FFFFFF.toInt(), 1)
            6 -> rounded(0x99111A2A.toInt(), 26, 0xFF76E4FF.toInt(), 1)
            else -> rounded(0xDD050507.toInt(), 30, 0x88B46CFF.toInt(), 2)
        }
        topMenu.background = bg
        topMenu.elevation = if (theme == 0 || theme == 1) 0f else dp(12).toFloat()
        topMenu.setPadding(if (theme <= 1) 0 else dp(12), 0, if (theme <= 1) 0 else dp(12), 0)
        Log.i(TAG, "TOP_MENU_THEME_VISIBLE_APPLY: theme=$theme noGlass=${theme == 0 || theme == 1}")
    }

    private fun menuItemBg(focused: Boolean): GradientDrawable {
        val theme = config.topMenuThemeStyle.coerceIn(0, 7)
        if (!focused) return rounded(Color.TRANSPARENT, 18, Color.TRANSPARENT, 0)
        return when (theme) {
            0, 1 -> rounded(Color.TRANSPARENT, 0, Color.TRANSPARENT, 0)
            3 -> rounded(0x11FFFFFF, 14, 0x88BFEFFF.toInt(), 1)
            4 -> rounded(0x224DFFB8, 22, 0xFF4DFFB8.toInt(), 2)
            6 -> rounded(0x2276E4FF, 22, 0xFF76E4FF.toInt(), 2)
            else -> rounded(0x22FFFFFF, 18, 0x99FFFFFF.toInt(), 1)
        }
    }

    private fun animateMenuFocus(view: View, focused: Boolean) {
        view.animate().cancel()
        val style = config.topMenuAnimationStyle.coerceIn(0, 4)
        if (!focused) {
            view.animate().scaleX(1f).scaleY(1f).translationY(0f).alpha(1f).setDuration(100).start()
            return
        }
        when (style) {
            0 -> view.scaleX = 1.06f
            1 -> view.animate().scaleX(1.08f).scaleY(1.08f).translationY(-dp(2).toFloat()).setDuration(120).start()
            2 -> view.animate().scaleX(1.16f).scaleY(1.16f).translationY(-dp(4).toFloat()).setDuration(90).withEndAction {
                view.animate().scaleX(1.09f).scaleY(1.09f).setDuration(110).start()
            }.start()
            3 -> view.animate().alpha(0.72f).setDuration(70).withEndAction { view.animate().alpha(1f).scaleX(1.1f).scaleY(1.1f).setDuration(120).start() }.start()
            else -> view.animate().scaleX(1.05f).scaleY(1.05f).translationY(dp(3).toFloat()).setDuration(110).start()
        }
    }

    private fun handleMenuAction(action: String) {
        when (action) {
            "live" -> startActivity(Intent(this, LiveTvActivity::class.java))
            "settings" -> startActivity(Intent(this, SettingsActivity::class.java))
            "search" -> startActivity(Intent(this, SearchActivity::class.java))
            "movies" -> startActivity(Intent(this, BrowseSectionActivity::class.java).putExtra("section", "movies"))
            "shows" -> startActivity(Intent(this, BrowseSectionActivity::class.java).putExtra("section", "shows"))
            else -> focusCard(0, 0)
        }
    }

    private fun setRows(rows: List<HomeRow>) {
        currentRows = rows.filter { it.items.isNotEmpty() }
        rowRecyclerByIndex.clear()
        stableRowByIndex.clear()
        stableScrollerByIndex.clear()
        stableCardByKey.clear()
        rowsRecycler.adapter = null
        rowsRecycler.visibility = View.GONE
        stableRowsScroll.visibility = View.VISIBLE
        lastFocusedRow = lastFocusedRow.coerceIn(0, currentRows.lastIndex.coerceAtLeast(0))
        lastFocusedColumn = 0
        renderNewAppViewportRows()
        currentRows.firstOrNull()?.items?.firstOrNull()?.let { applyHeroNow(it) }
        scheduleBackendTrailerCacheForRows(currentRows, "rows_render_visible_window")
        stableRowsScroll.postDelayed({ focusCard(lastFocusedRow, lastFocusedColumn) }, 90)
        Log.i(TAG, "ROW_ENGINE_V9_RENDER: rows=${currentRows.size} activeRowOnly=false itemLimit=none donorNewAppCards=true backendTrailerCache=queued")
    }

    private fun renderStableRows() {
        renderNewAppViewportRows()
    }

    private fun renderNewAppViewportRows() {
        if (currentRows.isEmpty()) return
        stableRowsColumn.removeAllViews()
        stableRowByIndex.clear()
        stableScrollerByIndex.clear()
        stableCardByKey.clear()

        val safeRow = lastFocusedRow.coerceIn(0, currentRows.lastIndex)
        val safeCol = lastFocusedColumn.coerceIn(0, currentRows[safeRow].items.lastIndex)
        lastFocusedRow = safeRow
        lastFocusedColumn = safeCol

        currentRows.forEachIndexed { rowIndex, rowData ->
            val title = TextView(this).apply {
                visibility = if (config.rowTextVisible == 1) View.VISIBLE else View.GONE
                text = rowData.title
                textSize = 21f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(8), 0, 0, dp(8))
            }
            stableRowsColumn.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, if (config.rowTextVisible == 1) dp(34) else 0))

            val lane = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                clipChildren = false
                clipToPadding = false
                setPadding(dp(8), dp(6), dp(320), dp(18))
            }
            val scroller = HorizontalScrollView(this).apply {
                overScrollMode = View.OVER_SCROLL_NEVER
                isHorizontalScrollBarEnabled = false
                isFocusable = false
                clipChildren = false
                clipToPadding = false
                descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
                addView(lane, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }
            rowData.items.forEachIndexed { column, item ->
                val card = createNewAppViewportCard(rowIndex, column, item)
                lane.addView(card)
                stableCardByKey["$rowIndex:$column"] = card
            }
            stableRowByIndex[rowIndex] = lane
            stableScrollerByIndex[rowIndex] = scroller
            stableRowsColumn.addView(scroller, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(config.cardHeightDp.coerceIn(110, 260) + 58)))
        }
        applyDimStateToAllVisibleCards()
        Log.i(TAG, "ROW_ENGINE_V12_LAZY_IMAGE_BIND: rows=${currentRows.size} dimUnfocused=${config.dimUnfocusedPercent} cacheInstant=true lazyDecode=true")
    }

    private fun shouldPrimeCardArtwork(rowIndex: Int, column: Int): Boolean {
        if (rowIndex <= 1 && column <= 8) return true
        return kotlin.math.abs(rowIndex - lastFocusedRow) <= 1 && kotlin.math.abs(column - lastFocusedColumn) <= 5
    }

    private fun loadCardArtworkForKey(rowIndex: Int, column: Int) {
        val row = currentRows.getOrNull(rowIndex) ?: return
        val item = row.items.getOrNull(column) ?: return
        val card = stableCardByKey["$rowIndex:$column"] ?: return
        val art = card.getTag(R.id.tag_card_artwork_view) as? ImageView ?: return
        loadImage(art, item.backdropUrl ?: item.posterUrl, item.backgroundRes)
    }

    private fun prefetchNeighborArtwork(rowIndex: Int, column: Int) {
        for (r in (rowIndex - 1)..(rowIndex + 1)) {
            for (c in (column - 4)..(column + 6)) {
                if (r >= 0 && r < currentRows.size && c >= 0 && c < currentRows[r].items.size) {
                    loadCardArtworkForKey(r, c)
                }
            }
        }
    }

    private fun createNewAppViewportCard(rowIndex: Int, column: Int, item: TitleCard): FrameLayout {
        val w = dp(config.cardWidthDp.coerceIn(190, 420))
        val h = dp(config.cardHeightDp.coerceIn(110, 260))
        val frame = FrameLayout(this).apply {
            id = View.generateViewId()
            layoutParams = LinearLayout.LayoutParams(w, h).apply { rightMargin = dp(config.cardSpacingDp.coerceIn(0, 40)) }
            isFocusable = true
            isClickable = true
            clipToOutline = true
            outlineProvider = roundOutline(config.cornerRadiusDp)
            background = rounded(if (config.glassCardMode == 1) 0xAA121A26.toInt() else 0xFF0B0F18.toInt(), config.cornerRadiusDp, 0x22FFFFFF, 1)
        }
        val art = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(0xFF05070D.toInt()) }
        val logoGlow = View(this).apply { visibility = View.INVISIBLE; background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0xAA000000.toInt(), 0x00000000)) }
        val logo = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_START; adjustViewBounds = false; visibility = View.INVISIBLE; alpha = 0.98f }
        val focusOverlay = View(this).apply {
            visibility = View.INVISIBLE
            alpha = 0f
            background = rounded(Color.TRANSPARENT, config.cornerRadiusDp, homeLayoutRingColor(config.focusRingColorIndex), config.focusRingThicknessDp.coerceIn(2, 8))
            elevation = dp(30).toFloat()
        }
        val label = TextView(this).apply {
            gravity = Gravity.CENTER
            text = ""
            textSize = 13f
            setTextColor(0xFFE9F4FF.toInt())
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(10), dp(4), dp(10), dp(4))
            maxLines = 1
            visibility = View.INVISIBLE
            alpha = 0f
            background = rounded(0x990B1320.toInt(), 18, 0x66FFFFFF, 1)
        }
        frame.addView(art, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.addView(logoGlow, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp((config.cardHeightDp * 0.50f).toInt()), Gravity.BOTTOM))
        frame.addView(logo, FrameLayout.LayoutParams(dp((config.cardWidthDp * 0.68f).toInt()), dp((config.cardHeightDp * 0.28f).toInt()), Gravity.BOTTOM or Gravity.START).apply { leftMargin = dp(config.cardLogoInsetLeftDp); bottomMargin = dp(config.cardLogoInsetBottomDp) })
        frame.addView(label, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(30), Gravity.BOTTOM or Gravity.START).apply { leftMargin = dp(10); bottomMargin = dp(10) })
        frame.addView(focusOverlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.setTag(R.id.tag_card_focus_overlay, focusOverlay)
        frame.setTag(R.id.tag_card_artwork_view, art)

        if (shouldPrimeCardArtwork(rowIndex, column)) {
            loadImage(art, item.backdropUrl ?: item.posterUrl, item.backgroundRes)
        } else {
            art.setImageResource(item.backgroundRes)
        }
        resetRowLogoState(frame, logoGlow, logo, label, item.title)
        frame.setOnClickListener { launchDetails(item) }
        frame.setOnFocusChangeListener { v, focused ->
            if (focused) {
                lastFocusedRow = rowIndex
                lastFocusedColumn = column
                loadImage(art, item.backdropUrl ?: item.posterUrl, item.backgroundRes)
                prefetchNeighborArtwork(rowIndex, column)
                updateHero(item)
                stableScrollerByIndex[rowIndex]?.smoothScrollTo((v.left - dp(32)).coerceAtLeast(0), 0)
                scheduleFocusedRowLogoLoad(frame, item, logoGlow, logo, label)
                prefetchNeighborLogos(rowIndex, column)
            } else if (shouldHoldLastCardHighlight(rowIndex, column)) {
                scheduleFocusedRowLogoLoad(frame, item, logoGlow, logo, label)
            } else {
                resetRowLogoState(frame, logoGlow, logo, label, item.title)
            }
            applyCardFocus(v, focused || shouldHoldLastCardHighlight(rowIndex, column))
        }
        frame.setOnKeyListener { _, keyCode, event ->
            if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_UP -> { if (rowIndex == 0) focusTopMenu() else focusCard(rowIndex - 1, 0); true }
                KeyEvent.KEYCODE_DPAD_DOWN -> { focusCard((rowIndex + 1).coerceAtMost(currentRows.lastIndex), 0); true }
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    if (column > 0) {
                        focusCard(rowIndex, column - 1)
                        true
                    } else if (useLeftSidebar()) {
                        focusTopMenu(); true
                    } else {
                        false
                    }
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    if (column < currentRows[rowIndex].items.lastIndex) {
                        focusCard(rowIndex, column + 1)
                        true
                    } else {
                        false
                    }
                }
                else -> false
            }
        }
        return frame
    }


    private fun requestBackendInstantHomeRows(reason: String) {
        io.execute {
            runCatching {
                fetchBackendHeroSnapshot(reason)
                val rows = fetchBackendInstantRows()
                if (rows.isNotEmpty()) {
                    main.post {
                        if (!isFinishing && !isDestroyed) {
                            Log.i(TAG, "INSTANT_HOME_PIPELINE_APPLY: reason=$reason rows=${rows.size} source=backend_ready_to_render")
                            setRows(rows)
                            savePersistentArtworkRowsCache(rows)
                            warmCachedRowImages(rows, limit = 24)
                            scheduleBackendTrailerCacheForRows(rows, "instant_home_$reason")
                        }
                    }
                } else {
                    Log.i(TAG, "INSTANT_HOME_PIPELINE_SKIP: reason=$reason rows=0 using_cached_or_direct_rows")
                }
            }.onFailure { Log.w(TAG, "INSTANT_HOME_PIPELINE_FAIL: reason=$reason ${it.message}") }
        }
    }

    private fun fetchBackendHeroSnapshot(reason: String) {
        runCatching {
            val text = fetchBackendText("/api/home/hero", 900, 1200).ifBlank { fetchBackendText("/home/hero", 900, 1200) }
            if (text.isBlank()) return@runCatching
            val obj = JSONObject(text)
            val itemObj = obj.optJSONObject("item") ?: obj.optJSONObject("hero") ?: obj
            val title = itemObj.optString("title")
            if (title.isNotBlank()) {
                val hero = parseInstantItem(itemObj, 0)
                main.post {
                    if (!isFinishing && !isDestroyed) {
                        Log.i(TAG, "HERO_FIRST_PIPELINE_APPLY: reason=$reason title=${hero.title} force4K=true")
                        applyHeroNow(hero)
                        listOf(hero.heroForegroundCutoutUrl, hero.heroBackdropAssetUrl, hero.backdropUrl, hero.logoUrl).filter { !it.isNullOrBlank() }.forEach { url ->
                            io.execute { runCatching { Glide.with(applicationContext).downloadOnly().load(BackendEndpoint.imageProxyUrl(url!!)).submit(3840, 2160) } }
                        }
                    }
                }
            }
        }.onFailure { Log.i(TAG, "HERO_FIRST_PIPELINE_SKIP: reason=$reason ${it.message}") }
    }

    private fun fetchBackendInstantRows(): List<HomeRow> {
        val jsonText = fetchBackendText("/api/home/instant", 1200, 1800).ifBlank {
            fetchBackendText("/home/instant", 1200, 1800)
        }
        if (jsonText.isBlank()) return emptyList()
        val root = JSONObject(jsonText)
        val rowsJson = root.optJSONArray("rows") ?: root.optJSONArray("data") ?: JSONArray()
        val rows = mutableListOf<HomeRow>()
        for (i in 0 until rowsJson.length()) {
            val rowObj = rowsJson.optJSONObject(i) ?: continue
            val itemsJson = rowObj.optJSONArray("items") ?: rowObj.optJSONArray("videos") ?: JSONArray()
            val items = mutableListOf<TitleCard>()
            for (j in 0 until itemsJson.length()) {
                val itemObj = itemsJson.optJSONObject(j) ?: continue
                items += parseInstantItem(itemObj, j)
            }
            if (items.isNotEmpty()) rows += HomeRow(rowObj.optString("title", rowObj.optString("name", "Home")), items)
        }
        Log.i(TAG, "INSTANT_HOME_PIPELINE_FETCH: rows=${rows.size} endpoint=backend_ready_to_render normalizedArtwork=true")
        return rows
    }

    private fun parseInstantItem(obj: JSONObject, index: Int): TitleCard {
        val title = obj.optString("title", obj.optString("name", "Untitled"))
        val year = obj.optInt("year", 0)
        val genre = obj.optString("genre", obj.optString("genres", ""))
        val source = obj.optString("source", "BackendInstant")
        val meta = obj.optString("meta").ifBlank {
            listOfNotNull(year.takeIf { it > 0 }?.toString(), genre.takeIf { it.isNotBlank() }, source.takeIf { it.isNotBlank() }).joinToString("  •  ")
        }
        return TitleCard(
            title = title,
            meta = meta,
            desc = obj.optString("overview", obj.optString("desc", obj.optString("description", ""))),
            backgroundRes = fallbackDrawable(index),
            posterUrl = firstNonBlank(obj, "poster4k", "posterUrl", "poster", "image"),
            backdropUrl = firstNonBlank(obj, "backdrop4k", "hero4k", "backdropUrl", "backdrop", "background"),
            logoUrl = firstNonBlank(obj, "logoUrl", "logo", "clearLogo"),
            heroForegroundCutoutUrl = firstNonBlank(obj, "hero_foreground_cutout", "heroForegroundCutout", "heroForegroundCutoutUrl", "foregroundCutout", "foregroundCutoutUrl"),
            heroBackdropAssetUrl = firstNonBlank(obj, "hero_backdrop", "heroBackdrop", "heroBackdropUrl", "backdrop4k", "hero4k"),
            heroPaletteUrl = firstNonBlank(obj, "hero_palette", "heroPalette", "heroPaletteUrl", "paletteUrl"),
            heroMaskQualityUrl = firstNonBlank(obj, "hero_mask_quality", "heroMaskQuality", "heroMaskQualityUrl", "maskQualityUrl"),
            mediaType = obj.optString("type", obj.optString("mediaType", "movie")),
            externalId = obj.optString("externalId", obj.optString("id", title)),
            year = year,
            source = source.ifBlank { "BackendInstant" }
        )
    }

    private fun firstNonBlank(obj: JSONObject, vararg keys: String): String? {
        keys.forEach { key -> obj.optString(key).takeIf { it.isNotBlank() }?.let { return it } }
        return null
    }

    private fun fetchBackendText(path: String, connectMs: Int, readMs: Int): String {
        val connection = (java.net.URL(BackendEndpoint.route(path)).openConnection() as java.net.HttpURLConnection).apply {
            connectTimeout = connectMs
            readTimeout = readMs
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
        }
        return try {
            if (connection.responseCode in 200..299) connection.inputStream.bufferedReader().use { it.readText() } else ""
        } finally {
            connection.disconnect()
        }
    }

    private fun loadArtworkRows() {
        val mode = config.artworkSourceMode.coerceIn(0, 3)
        Log.i(TAG, "ARTWORK_SOURCE_MODE: ${artworkModeName(mode)}")
        io.execute {
            val directRows = if (mode in 0..2) {
                runCatching { artworkProvider.loadDirectRows(96) }.getOrDefault(emptyList())
            } else emptyList()

            val backendRows = emptyList<com.channelsdebrid.tv.data.BackendHomeLoader.BackendRow>()

            val mappedDirect = directRows.map { row ->
                HomeRow(row.title, row.items.mapIndexed { index, item ->
                    TitleCard(
                        title = item.title,
                        meta = item.meta.ifBlank { item.source },
                        desc = item.overview.ifBlank { "Direct metadata artwork item." },
                        backgroundRes = fallbackDrawable(index),
                        posterUrl = item.posterUrl,
                        backdropUrl = item.backdropUrl ?: item.posterUrl,
                        logoUrl = item.logoUrl,
                        mediaType = item.type.ifBlank { "movie" },
                        externalId = item.externalId.ifBlank { item.title },
                        source = item.source.ifBlank { "Direct" }
                    )
                })
            }

            val mappedBackend = backendRows.map { row ->
                HomeRow(row.title, row.items.mapIndexed { index, item ->
                    TitleCard(
                        title = item.title,
                        meta = listOfNotNull(item.year.takeIf { it > 0 }?.toString(), item.genre.takeIf { it.isNotBlank() }, item.source.takeIf { it.isNotBlank() }).joinToString("  •  "),
                        desc = item.overview.ifBlank { "Backend catalog item" },
                        backgroundRes = fallbackDrawable(index),
                        posterUrl = item.poster,
                        backdropUrl = item.backdrop ?: item.poster,
                        logoUrl = item.logo,
                        mediaType = item.type.ifBlank { "movie" },
                        externalId = item.imdbId ?: item.id,
                        year = item.year,
                        source = item.source.ifBlank { "Backend" }
                    )
                })
            }

            val stremioRows = if (repository.loadCatalogs().stremioCatalogRowsEnabled) {
                repository.loadStremioAddons()
                    .filter { it.enabled && it.manifestUrl.isNotBlank() }
                    .flatMap { addon ->
                        runCatching { stremioLoader.loadRows(addon.name.ifBlank { "Stremio" }, addon.manifestUrl, 96) }
                            .getOrDefault(emptyList())
                            .map { row ->
                                HomeRow("${addon.name.ifBlank { "Stremio" }} • ${row.title}", row.items.mapIndexed { index, item ->
                                    TitleCard(
                                        title = item.title,
                                        meta = item.meta.ifBlank { addon.name },
                                        desc = item.desc.ifBlank { "Stremio catalog item." },
                                        backgroundRes = fallbackDrawable(index),
                                        posterUrl = item.posterUrl,
                                        backdropUrl = item.backdropUrl ?: item.posterUrl,
                                        logoUrl = item.logoUrl,
                                        mediaType = item.mediaType ?: "movie",
                                        externalId = item.externalId ?: item.title,
                                        source = addon.name.ifBlank { "Stremio" }
                                    )
                                })
                            }
                    }
            } else emptyList()
            val finalRows = when (mode) {
                0 -> mappedDirect + stremioRows
                1 -> mappedDirect + stremioRows
                2 -> mappedDirect + stremioRows
                else -> stremioRows
            }

            main.post {
                if (!isFinishing && !isDestroyed && finalRows.isNotEmpty()) {
                    Log.i(TAG, "ARTWORK_ROWS_APPLIED_INCREMENTAL: mode=${artworkModeName(mode)} rows=${finalRows.size} backendRequired=false memorySafe=true persisted=true")
                    setRows(finalRows)
                    savePersistentArtworkRowsCache(finalRows)
                    warmCachedRowImages(finalRows, limit = 30)
                } else {
                    Log.i(TAG, "ARTWORK_ROWS_APPLIED: mode=${artworkModeName(mode)} rows=0 fallback=local")
                }
            }
        }
    }


    private fun persistentArtworkRowsCacheFile(): File = File(cacheDir, "persistent_home_artwork_rows_v2.json")

    private fun loadPersistentArtworkRowsCache(): List<HomeRow> {
        return runCatching {
            val file = persistentArtworkRowsCacheFile()
            if (!file.exists() || file.length() <= 16L) return emptyList()
            val root = JSONObject(file.readText())
            val savedAt = root.optLong("savedAt", 0L)
            val maxAgeMs = 7L * 24L * 60L * 60L * 1000L
            if (savedAt > 0L && System.currentTimeMillis() - savedAt > maxAgeMs) {
                Log.i(TAG, "PERSISTENT_HOME_CACHE_STALE: ageMs=${System.currentTimeMillis() - savedAt} usingWhileRefresh=true")
            }
            val rowsJson = root.optJSONArray("rows") ?: JSONArray()
            val rows = mutableListOf<HomeRow>()
            for (i in 0 until rowsJson.length()) {
                val rowObj = rowsJson.optJSONObject(i) ?: continue
                val itemsJson = rowObj.optJSONArray("items") ?: JSONArray()
                val items = mutableListOf<TitleCard>()
                for (j in 0 until itemsJson.length()) {
                    val itemObj = itemsJson.optJSONObject(j) ?: continue
                    items += TitleCard(
                        title = itemObj.optString("title"),
                        meta = itemObj.optString("meta"),
                        desc = itemObj.optString("desc"),
                        backgroundRes = fallbackDrawable(j),
                        posterUrl = itemObj.optString("posterUrl").ifBlank { null },
                        backdropUrl = itemObj.optString("backdropUrl").ifBlank { null },
                        logoUrl = itemObj.optString("logoUrl").ifBlank { null },
                        mediaType = itemObj.optString("mediaType", "movie"),
                        externalId = itemObj.optString("externalId").ifBlank { itemObj.optString("title") },
                        year = itemObj.optInt("year", 0),
                        source = itemObj.optString("source", "Cache")
                    )
                }
                if (items.isNotEmpty()) rows += HomeRow(rowObj.optString("title", "Cached"), items)
            }
            rows
        }.onFailure { Log.w(TAG, "PERSISTENT_HOME_CACHE_READ_FAIL: ${it.message}") }.getOrDefault(emptyList())
    }

    private fun savePersistentArtworkRowsCache(rows: List<HomeRow>) {
        io.execute {
            runCatching {
                val rowsJson = JSONArray()
                rows.take(12).forEach { row ->
                    val rowObj = JSONObject()
                    rowObj.put("title", row.title)
                    val itemsJson = JSONArray()
                    row.items.take(120).forEach { item ->
                        val itemObj = JSONObject()
                        itemObj.put("title", item.title)
                        itemObj.put("meta", item.meta)
                        itemObj.put("desc", item.desc)
                        itemObj.put("posterUrl", item.posterUrl ?: "")
                        itemObj.put("backdropUrl", item.backdropUrl ?: "")
                        itemObj.put("logoUrl", item.logoUrl ?: "")
                        itemObj.put("mediaType", item.mediaType)
                        itemObj.put("externalId", item.externalId ?: "")
                        itemObj.put("year", item.year)
                        itemObj.put("source", item.source)
                        itemsJson.put(itemObj)
                    }
                    rowObj.put("items", itemsJson)
                    rowsJson.put(rowObj)
                }
                val root = JSONObject()
                root.put("version", 2)
                root.put("savedAt", System.currentTimeMillis())
                root.put("rows", rowsJson)
                persistentArtworkRowsCacheFile().writeText(root.toString())
                Log.i(TAG, "PERSISTENT_HOME_CACHE_SAVE: rows=${rows.size} file=${persistentArtworkRowsCacheFile().length()} bytes")
            }.onFailure { Log.w(TAG, "PERSISTENT_HOME_CACHE_SAVE_FAIL: ${it.message}") }
        }
    }

    private fun warmCachedRowImages(rows: List<HomeRow>, limit: Int) {
        io.execute {
            runCatching {
                var count = 0
                rows.asSequence().flatMap { it.items.asSequence() }.take(limit).forEach { item ->
                    listOf(item.posterUrl, item.backdropUrl, item.logoUrl)
                        .filter { !it.isNullOrBlank() }
                        .forEach { url ->
                            runCatching {
                                Glide.with(applicationContext)
                                    .downloadOnly()
                                    .load(BackendEndpoint.imageProxyUrl(url!!))
                                    .submit()
                                count++
                            }
                        }
                }
                Log.i(TAG, "PERSISTENT_IMAGE_CACHE_WARM: requested=$count rows=${rows.size} diskStrategy=glide_default_plus_rows visibleWindowOnly=true heroFirst=true")
            }.onFailure { Log.w(TAG, "PERSISTENT_IMAGE_CACHE_WARM_FAIL: ${it.message}") }
        }
    }

    private fun artworkModeName(mode: Int): String = when (mode.coerceIn(0, 3)) {
        0 -> "Direct metadata"
        1 -> "Direct metadata + local cache"
        2 -> "Direct metadata"
        else -> "Offline/local fallback"
    }

    private inner class HomeRowsAdapter(private val rows: List<HomeRow>) : RecyclerView.Adapter<HomeRowsAdapter.RowHolder>() {
        init { setHasStableIds(true) }
        override fun getItemId(position: Int): Long = rows[position].title.hashCode().toLong()
        inner class RowHolder(val box: LinearLayout, val title: TextView, val row: RecyclerView) : RecyclerView.ViewHolder(box)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowHolder {
            val box = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                clipChildren = false
                clipToPadding = false
                setPadding(0, 0, 0, dp(16))
            }
            val title = TextView(parent.context).apply {
                setTextColor(Color.WHITE)
                textSize = 21f
                typeface = Typeface.DEFAULT_BOLD
                setPadding(0, 0, 0, dp(8))
            }
            val row = RecyclerView(parent.context).apply {
                layoutManager = LinearLayoutManager(parent.context, RecyclerView.HORIZONTAL, false)
                itemAnimator = null
                overScrollMode = View.OVER_SCROLL_NEVER
                clipChildren = false
                clipToPadding = false
                descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
                setHasFixedSize(true)
                isFocusable = false
            }
            box.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, if (config.rowTextVisible == 1) dp(34) else 0))
            box.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(config.cardHeightDp.coerceIn(110, 260) + 38)))
            return RowHolder(box, title, row)
        }
        override fun getItemCount(): Int = rows.size
        override fun onBindViewHolder(holder: RowHolder, position: Int) {
            val rowData = rows[position]
            holder.title.visibility = if (config.rowTextVisible == 1) View.VISIBLE else View.GONE
            holder.title.text = rowData.title
            holder.row.adapter = CardAdapter(position, rowData.items)
            rowRecyclerByIndex[position] = holder.row
            Log.i(TAG, "ROW_ENGINE_BIND_ROW: index=$position title=${rowData.title} oldAdapter=false")
        }
    }

    private inner class CardAdapter(private val rowIndex: Int, private val items: List<TitleCard>) : RecyclerView.Adapter<CardAdapter.CardHolder>() {
        init { setHasStableIds(true) }
        override fun getItemId(position: Int): Long = (items[position].externalId ?: items[position].title).hashCode().toLong()
        inner class CardHolder(
            val frame: FrameLayout,
            val art: ImageView,
            val logoGlow: View,
            val logo: ImageView,
            val label: TextView,
            val focusOverlay: View
        ) : RecyclerView.ViewHolder(frame)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardHolder {
            val w = dp(config.cardWidthDp.coerceIn(190, 420))
            val h = dp(config.cardHeightDp.coerceIn(110, 260))
            val frame = FrameLayout(parent.context).apply {
                id = View.generateViewId()
                layoutParams = RecyclerView.LayoutParams(w, h).apply { rightMargin = dp(config.cardSpacingDp.coerceIn(0, 40)) }
                isFocusable = true
                isClickable = true
                clipToOutline = true
                outlineProvider = roundOutline(config.cornerRadiusDp)
                background = rounded(if (config.glassCardMode == 1) 0xAA121A26.toInt() else 0xFF0B0F18.toInt(), config.cornerRadiusDp, 0x22FFFFFF, 1)
            }
            val art = ImageView(parent.context).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(0xFF05070D.toInt())
            }
            val logoGlow = View(parent.context).apply {
                visibility = View.INVISIBLE
                background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0xAA000000.toInt(), 0x00000000))
            }
            val logo = ImageView(parent.context).apply {
                scaleType = ImageView.ScaleType.FIT_START
                adjustViewBounds = false
                visibility = View.INVISIBLE
                alpha = 0.98f
                setLayerType(View.LAYER_TYPE_HARDWARE, null)
            }
            val focusOverlay = View(parent.context).apply {
                visibility = View.INVISIBLE
                alpha = 0f
                background = rounded(Color.TRANSPARENT, config.cornerRadiusDp, homeLayoutRingColor(config.focusRingColorIndex), config.focusRingThicknessDp.coerceIn(2, 8))
                elevation = dp(30).toFloat()
            }
            val label = TextView(parent.context).apply {
                gravity = Gravity.CENTER
                textSize = 13f
                setTextColor(0xFFE9F4FF.toInt())
                typeface = homeLayoutTypeface(config.contentFontIndex)
                setPadding(dp(10), dp(4), dp(10), dp(4))
                background = rounded(0x990B1320.toInt(), 18, 0x66FFFFFF, 1)
                visibility = View.INVISIBLE
                alpha = 0f
                maxLines = 1
            }
            frame.addView(art, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            frame.addView(logoGlow, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp((config.cardHeightDp * 0.50f).toInt()), Gravity.BOTTOM))
            frame.addView(logo, FrameLayout.LayoutParams(dp((config.cardWidthDp * 0.68f).toInt()), dp((config.cardHeightDp * 0.28f).toInt()), Gravity.BOTTOM or Gravity.START).apply { leftMargin = dp(config.cardLogoInsetLeftDp); bottomMargin = dp(config.cardLogoInsetBottomDp) })
            frame.addView(label, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(30), Gravity.BOTTOM or Gravity.START).apply { leftMargin = dp(10); bottomMargin = dp(10) })
            frame.addView(focusOverlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            frame.setTag(R.id.tag_card_focus_overlay, focusOverlay)
        frame.setTag(R.id.tag_card_artwork_view, art)
            return CardHolder(frame, art, logoGlow, logo, label, focusOverlay)
        }
        override fun getItemCount(): Int = items.size
        override fun onBindViewHolder(holder: CardHolder, position: Int) {
            val item = items[position]
            holder.label.text = ""
            loadImage(holder.art, item.backdropUrl ?: item.posterUrl, item.backgroundRes)
            resetRowLogoState(holder.frame, holder.logoGlow, holder.logo, holder.label, item.title)
            // Per-card logging removed for memory-safe recycled rows.
            applyCardFocus(holder.frame, holder.frame.hasFocus())
            holder.frame.setOnClickListener { launchDetails(item) }
            holder.frame.setOnFocusChangeListener { v, focused ->
                if (focused) {
                    lastFocusedRow = rowIndex
                    lastFocusedColumn = position
                    updateHero(item)
                    scheduleFocusedRowLogoLoad(holder.frame, item, holder.logoGlow, holder.logo, holder.label)
                    prefetchNeighborLogos(rowIndex, position)
                } else if (shouldHoldLastCardHighlight(rowIndex, position)) {
                    scheduleFocusedRowLogoLoad(holder.frame, item, holder.logoGlow, holder.logo, holder.label)
                } else {
                    resetRowLogoState(holder.frame, holder.logoGlow, holder.logo, holder.label, item.title)
                }
                applyCardFocus(v, focused || shouldHoldLastCardHighlight(rowIndex, position))
            }
            holder.frame.setOnKeyListener { _, keyCode, event ->
                if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP -> { if (rowIndex == 0) focusTopMenu() else focusCard(rowIndex - 1, 0); true }
                    KeyEvent.KEYCODE_DPAD_DOWN -> { focusCard((rowIndex + 1).coerceAtMost(currentRows.lastIndex), 0); true }
                    else -> false
                }
            }
        }
    }

    private fun focusTopMenu() {
        holdLastCardHighlightForMenu = true
        refreshLastCardVisualIfVisible()
        if (useLeftSidebar()) sideMenu.getChildAt(0)?.requestFocus() else topMenu.getChildAt(0)?.requestFocus()
    }

    private fun shouldHoldLastCardHighlight(rowIndex: Int, column: Int): Boolean {
        return holdLastCardHighlightForMenu && rowIndex == lastFocusedRow && column == lastFocusedColumn
    }

    private fun refreshLastCardVisualIfVisible() {
        val key = "${lastFocusedRow}:${lastFocusedColumn}"
        val card = stableCardByKey[key] ?: return
        applyCardFocus(card, holdLastCardHighlightForMenu)
    }

    private fun focusCard(rowIndex: Int, column: Int) {
        holdLastCardHighlightForMenu = false
        if (currentRows.isEmpty()) return
        val safeRow = rowIndex.coerceIn(0, currentRows.lastIndex)
        val safeCol = column.coerceIn(0, currentRows[safeRow].items.lastIndex)
        val viewportKey = "$safeRow:$safeCol"
        lastFocusedRow = safeRow
        lastFocusedColumn = safeCol
        Log.i(TAG, "FOCUS_GRAPH_V9_MOVE: row=$safeRow col=$safeCol activeRowOnly=false")
        stableRowsScroll.post {
            if (!stableCardByKey.containsKey(viewportKey)) {
                renderNewAppViewportRows()
            }
            val target = stableCardByKey[viewportKey]
            if (target == null) {
                stableRowsScroll.postDelayed({ focusCard(safeRow, safeCol) }, 32)
                return@post
            }
            val rowTop = stableScrollerByIndex[safeRow]?.top ?: 0
            stableRowsScroll.smoothScrollTo(0, (rowTop - dp(18)).coerceAtLeast(0))
            target.requestFocus()
        }
    }

    private fun bindHeroGenrePills(item: TitleCard) {
        heroGenrePills.removeAllViews()
        val genres = focusedCardGenrePill(item)
            .split('•')
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .take(3)
        heroGenrePills.visibility = if (genres.isEmpty()) View.GONE else View.VISIBLE
        genres.forEach { genre ->
            val pill = TextView(this).apply {
                text = genre
                textSize = 14f * (config.heroTextSizePercent.coerceIn(60, 160) / 100f)
                setTextColor(0xFFEAF7FF.toInt())
                typeface = homeLayoutTypeface(config.heroFontIndex)
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(4), dp(14), dp(4))
                background = rounded(0xAA0B1320.toInt(), 18, 0x66FFFFFF, 1)
                includeFontPadding = false
            }
            heroGenrePills.addView(pill, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(28)).apply { rightMargin = dp(8) })
        }
        Log.i(TAG, "HERO_GENRE_PILL_THEME_APPLY: count=${genres.size} rowCardGenreRemoved=true")
    }

    private fun formatHeroRatings(item: TitleCard): String {
        val raw = item.meta.ifBlank { "Featured • ${item.source}" }
        fun findRating(label: String): String {
            val rx = Regex(label + "\\s*[:★⭐]?\\s*([0-9]+(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE)
            return rx.find(raw)?.groupValues?.getOrNull(1).orEmpty()
        }
        val imdb = findRating("IMDb")
        val tmdb = findRating("TMDB").ifBlank {
            Regex("★\\s*([0-9]+(?:\\.[0-9]+)?)").find(raw)?.groupValues?.getOrNull(1).orEmpty()
        }
        val cleanParts = raw.split("•").map { it.trim() }
            .filter { it.isNotBlank() && !it.contains("IMDb", true) && !it.contains("TMDB", true) && !it.startsWith("★") }
        val ratingParts = mutableListOf<String>()
        if (imdb.isNotBlank()) ratingParts += "IMDb ★ $imdb"
        if (tmdb.isNotBlank()) ratingParts += "TMDB ★ $tmdb"
        if (ratingParts.isEmpty()) return raw
        return (cleanParts + ratingParts).joinToString("   •   ")
    }


    private fun formatHeroMetaWithoutRatings(item: TitleCard): String {
        val raw = item.meta.ifBlank { "Featured • ${item.source}" }
        val genreTokens = focusedCardGenrePill(item)
            .split('•')
            .map { it.trim().lowercase() }
            .filter { it.isNotBlank() }
            .toSet()
        val cleaned = raw.split("•")
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .filterNot { part -> part.contains("IMDb", true) || part.contains("TMDB", true) || part.startsWith("★") }
            .filterNot { part -> genreTokens.contains(part.lowercase()) }
            .filterNot { part -> part.equals("Action", true) || part.equals("Comedy", true) || part.equals("Drama", true) || part.equals("Horror", true) || part.equals("Thriller", true) || part.equals("Adventure", true) || part.equals("Family", true) || part.equals("Sci-Fi", true) || part.equals("Science Fiction", true) || part.equals("Crime", true) || part.equals("Fantasy", true) || part.equals("Romance", true) || part.equals("Animation", true) || part.equals("Documentary", true) }
            .toMutableList()
        if (cleaned.none { it.matches(Regex("\\d{4}")) } && item.year > 0) cleaned.add(0, item.year.toString())
        val typeLabel = when (item.mediaType.lowercase()) {
            "series", "show", "tv" -> "TV Show"
            else -> "Movie"
        }
        if (cleaned.none { it.equals(typeLabel, true) }) cleaned.add(typeLabel)
        val sourceLabel = item.source.takeIf { it.isNotBlank() && !it.equals("Local", true) }
        if (sourceLabel != null && cleaned.none { it.equals(sourceLabel, true) }) cleaned.add(sourceLabel)
        return cleaned.take(4).joinToString("   •   ").ifBlank { typeLabel }
    }
    private fun heroBindIdentity(item: TitleCard): String {
        // Include logo/meta/description so stale persistent-cache rows cannot block later
        // fresh rows from restoring logo artwork, genre text, IMDb/TMDB badges, and extra art.
        return listOf(
            item.externalId,
            item.title,
            item.backdropUrl,
            item.posterUrl,
            item.logoUrl,
            item.meta,
            item.desc,
            item.source
        ).joinToString("|")
    }

    private fun updateHero(item: TitleCard) {
        val identity = heroBindIdentity(item)
        if (identity == lastHeroIdentityKey) return
        pendingHeroItem = item
        main.removeCallbacks(heroUpdateRunnable)
        // V3 row rewrite rule: never rebind hero while DPAD movement is still settling.
        // This prevents the visible row/card jump caused by image/logo layout work racing focus.
        main.postDelayed(heroUpdateRunnable, 220L)
    }

    private fun applyHeroNow(item: TitleCard) {
        val identity = heroBindIdentity(item)
        if (identity == lastHeroIdentityKey) return
        lastHeroIdentityKey = identity
        heroText.animate().cancel()
        heroTitle.text = item.title.uppercase()
        heroMeta.text = formatHeroMetaWithoutRatings(item)
        bindHeroGenrePills(item)
        bindHeroRatingBadges(item)
        heroDesc.text = item.desc.ifBlank { "Select to open details." }
        heroScrim.background = cinematicHeroScrim()
        Log.i(TAG, "HERO_HALF_POSTER_FADE_APPLY: enabled=${config.heroBackdropStyle == 1} style=${config.heroBackdropStyle} leftBlack=true rightPosterVisible=true")
        // v2.8.21.6: half-poster fade must never force a portrait poster into a full-screen crop.
        // Prefer the true landscape backdrop for the hero layer; poster artwork remains available
        // to the extra-art/logo layer so logos/art do not disappear when fade mode is enabled.
        // v2.8.26.39: prefer real backend-generated transparent foreground cutout when present.
        // If no cutout asset exists yet, fall back to the v37-safe backdrop path without
        // cropping/cutting the right side or applying fake full-poster opacity pop.
        val heroImageUrl = item.heroForegroundCutoutUrl ?: item.heroBackdropAssetUrl ?: item.backdropUrl ?: item.posterUrl
        val hasRealCutoutAsset = !item.heroForegroundCutoutUrl.isNullOrBlank()
        val backdropKey = (if (hasRealCutoutAsset) "cutout:" else "fallback:") + (heroImageUrl ?: "${item.backgroundRes}")
        Log.i(TAG, "HERO_ASSET_PIPELINE_SELECT: realCutout=$hasRealCutoutAsset foreground=${!item.heroForegroundCutoutUrl.isNullOrBlank()} backdropAsset=${!item.heroBackdropAssetUrl.isNullOrBlank()} palette=${!item.heroPaletteUrl.isNullOrBlank()} maskQuality=${!item.heroMaskQualityUrl.isNullOrBlank()}")
        if (backdropKey != lastHeroBackdropKey) {
            lastHeroBackdropKey = backdropKey
            loadHeroBackdropImage(heroPosterDepthLayer, heroImageUrl, item.backgroundRes)
        } else {
            syncHeroPosterCutoutFromPrimaryLayer()
        }
        applyHeroQualityMode()
        applyHeroLogo(item)
        applyHeroExtraArt(item)
        applyHeroForegroundPriorityLayers()
        Log.i(TAG, "HERO_BIND_RESTORE_APPLY: logo=${!item.logoUrl.isNullOrBlank()} meta=${item.meta.isNotBlank()} genre=${focusedCardGenrePill(item).isNotBlank()} cacheUntouched=true")
    }

    private fun syncHeroPosterCutoutFromPrimaryLayer() {
        if (heroPosterDepthLayer.drawable == null) {
            heroPosterDepthLayer.visibility = View.INVISIBLE
            heroPosterDepthLayer.alpha = 0f
            return
        }
        heroPosterDepthLayer.scaleType = ImageView.ScaleType.CENTER_CROP
        heroPosterDepthLayer.adjustViewBounds = false
        applyHeroPosterCutoutParams()
        applyHeroForegroundPriorityLayers()
        Log.i(TAG, "HERO_CUTOUT_PRIMARY_SYNC: source=primaryHeroLayer singleHeroImage=true oldBackdropRenderer=false secondLoad=false")
    }


    private fun applyHeroPosterDepthLayerMatrix() {
        if (!::heroPosterDepthLayer.isInitialized) return
        // v2.8.26.29 compile fix: keep the cutout depth function inside MainActivity scope.
        // This intentionally does not load a second image; it only reapplies the bounded
        // cutout layout/transform to the existing synced hero backdrop drawable.
        applyHeroPosterCutoutParams()
        if (heroPosterDepthLayer.drawable != null && heroForegroundPriorityEnabled()) {
            val depth = config.heroPosterDepthPercent.coerceIn(0, 100)
            val posterZ = heroPosterDepthZ()
            val usingBackendCutout = lastHeroBackdropKey.startsWith("cutout:")
            val cutoutAlpha = if (usingBackendCutout) 0.98f else (0.70f + (depth / 100f) * 0.10f).coerceIn(0.70f, 0.80f)
            val popScale = if (usingBackendCutout) (1.018f + (depth / 100f) * 0.030f) else 1.0f
            heroPosterDepthLayer.elevation = posterZ
            heroPosterDepthLayer.translationZ = posterZ
            heroPosterDepthLayer.alpha = cutoutAlpha
            heroPosterDepthLayer.scaleX = popScale
            heroPosterDepthLayer.scaleY = popScale
            heroPosterDepthLayer.translationY = -dp((3 + depth / 28).coerceIn(3, 7)).toFloat()
            heroPosterDepthLayer.visibility = View.VISIBLE
            applyHeroCutoutGlow(depth, posterZ - dp(1).toFloat())
        }
        Log.i(TAG, "HERO_CUTOUT_ASSET_MATRIX_APPLY: primaryHeroPlane=true singleHeroImage=true oldBackdropRenderer=false secondLoad=false darkBalance=true backendCutoutPreferred=true fallbackOpacitySafe=true globalGlow=false rowsRestored=true depthPercent=${config.heroPosterDepthPercent}")
    }

    private fun applyHeroQualityMode() {
        // v2.8.26.32: old full-screen heroBackdrop renderer is not part of the render tree.
        // The single 4K hero image is rendered by heroPosterDepthLayer only.
        heroPosterDepthLayer.scaleType = ImageView.ScaleType.CENTER_CROP
        heroPosterDepthLayer.adjustViewBounds = false
        applyHeroPosterDepthLayerMatrix()
        Log.i(TAG, "HERO_QUALITY_MODE_APPLY: primaryCutoutOnly=true oldBackdropRenderer=false singleHeroImage=true uiResolution=${if (config.uiResolutionMode == 1) "4K" else "1080p"} decodeTarget=3840x2160 darkBalance=true globalGlow=false")
    }

    private fun applyHeroBackdropSmartMatrix(target: ImageView) {
        if (config.heroBackdropStyle != 1) return
        val drawable = target.drawable ?: return
        val viewW = target.width.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels
        val viewH = target.height.takeIf { it > 0 } ?: resources.displayMetrics.heightPixels
        val drawableW = drawable.intrinsicWidth.takeIf { it > 0 } ?: viewW
        val drawableH = drawable.intrinsicHeight.takeIf { it > 0 } ?: viewH

        // v2.8.26.10: strict full-art fit lock.
        // Requirement: hero artwork must remain 4K quality but NEVER stretch, zoom, or crop.
        // Use a CENTER_INSIDE-style matrix so the full poster/backdrop is visible inside the hero surface.
        // Existing left fade/ghost rows remain untouched; this only changes the bitmap fit matrix.
        val fitScale = minOf(viewW.toFloat() / drawableW.toFloat(), viewH.toFloat() / drawableH.toFloat())
        val scale = fitScale.coerceAtLeast(0.01f)
        val drawnW = drawableW * scale
        val drawnH = drawableH * scale
        val dx = (viewW - drawnW) / 2f
        val dy = (viewH - drawnH) / 2f
        val matrix = Matrix().apply {
            setScale(scale, scale)
            postTranslate(dx, dy)
        }
        target.scaleType = ImageView.ScaleType.MATRIX
        target.imageMatrix = matrix
        target.invalidate()
        Log.i(TAG, "HERO_FULL_POSTER_FIT_LOCK_APPLY: mode=center_inside_full_art_no_crop_no_stretch view=${viewW}x$viewH drawable=${drawableW}x$drawableH scale=$scale dx=$dx dy=$dy hero4K=true")
    }


    private fun heroLogoParams(): FrameLayout.LayoutParams {
        return FrameLayout.LayoutParams(dp(config.heroLogoWidthDp), dp(config.heroLogoHeightDp), Gravity.TOP or Gravity.START).apply {
            // Logo is intentionally anchored slightly farther left than the metadata block.
            // This keeps it clear of the genre/meta pill lane and matches the reference layout.
            leftMargin = dp((22 + config.heroTextLeftDp).coerceAtLeast(8))
            topMargin = dp(78 + config.heroTextTopDp)
        }
    }

    private fun updateHeroTextAnchorForLogo(logoVisible: Boolean) {
        val logoTop = 78 + config.heroTextTopDp
        val logoHeight = config.heroLogoHeightDp.coerceIn(64, 280)
        val normalTop = 118 + config.heroTextTopDp
        val safeTop = if (logoVisible) (logoTop + logoHeight + 16) else normalTop
        heroText.setPadding(dp(34 + config.heroTextLeftDp), dp(safeTop), dp(34), 0)
        Log.i(TAG, "HERO_LOGO_SAFE_ANCHOR: visible=$logoVisible logoLeft=${(22 + config.heroTextLeftDp).coerceAtLeast(8)} textTop=$safeTop noOverlap=true")
    }

    private fun applyHeroLogo(item: TitleCard) {
        if (heroLogo.parent == null) root.addView(heroLogo, heroLogoParams())
        heroLogo.layoutParams = heroLogoParams()
        val displayLogoUrl = resolveDisplayLogoUrl(item)
        if (config.heroLogoVisible != 1 || displayLogoUrl.isNullOrBlank()) {
            heroLogo.animate().cancel()
            heroLogo.visibility = View.INVISIBLE
            heroLogo.alpha = 0f
            heroTitle.visibility = View.VISIBLE
            updateHeroTextAnchorForLogo(false)
            lastHeroLogoKey = ""
            Log.i(TAG, "HERO_LOGO_ARTWORK_APPLY: hidden fallbackTitle=true")
            return
        }
        if (displayLogoUrl != lastHeroLogoKey) {
            lastHeroLogoKey = displayLogoUrl
            Glide.with(this).load(upgradeArtworkUrl(displayLogoUrl))
                .apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).diskCacheStrategy(DiskCacheStrategy.ALL).dontTransform())
                .into(heroLogo)
        }
        heroTitle.visibility = View.GONE
        updateHeroTextAnchorForLogo(true)
        heroLogo.animate().cancel()
        heroLogo.visibility = View.VISIBLE
        heroLogo.alpha = 0f
        heroLogo.translationY = dp(16).toFloat()
        heroLogo.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(260)
            .start()
        Log.i(TAG, "HERO_LOGO_ARTWORK_APPLY: visible cached=${displayLogoUrl == lastHeroLogoKey} fallback=${item.logoUrl.isNullOrBlank()} anchorSafe=true")
    }

    private fun applyHeroExtraArt(item: TitleCard) {
        if (config.extraArtworkVisible != 1) {
            heroExtraArt.animate().cancel()
            heroExtraArt.visibility = View.GONE
            heroExtraArt.alpha = 0f
            lastHeroExtraKey = ""
            Log.i(TAG, "HERO_EXTRA_ART_LAYER_APPLY: enabled=false source=pro_editor")
            return
        }
        // v2.8.21.6: do NOT hide extra artwork/logos in half-fade mode. The prior fix
        // made the fade visible by deleting this layer, but that also removed user-enabled
        // extra logo/art options. Keep the layer and control ordering/alpha instead.
        if (heroExtraArt.parent == null) root.addView(heroExtraArt, extraArtHeroParams())
        heroExtraArt.layoutParams = extraArtHeroParams()
        // Keep the poster as a raised visual object over ghost rows without hiding the rows behind it.
        heroPosterDepthLayer.bringToFront()
        heroExtraArt.bringToFront()
        heroText.bringToFront()
        heroLogo.bringToFront()
        topMenu.bringToFront()
        sideMenu.bringToFront()
        val sourceMode = config.extraArtworkSourceMode.coerceIn(0, 4)
        val url = when (sourceMode) {
            1 -> item.logoUrl ?: item.posterUrl ?: item.backdropUrl
            2 -> item.backdropUrl ?: item.posterUrl ?: item.logoUrl
            3 -> item.posterUrl ?: item.logoUrl ?: item.backdropUrl
            4 -> item.logoUrl ?: item.backdropUrl ?: item.posterUrl
            else -> item.posterUrl ?: item.logoUrl ?: item.backdropUrl
        }
        val imageKey = url ?: "fallback:${item.backgroundRes}"
        if (imageKey != lastHeroExtraKey) {
            lastHeroExtraKey = imageKey
            if (url.isNullOrBlank()) {
                heroExtraArt.setImageDrawable(ContextCompat.getDrawable(this, item.backgroundRes))
            } else {
                Glide.with(this).load(upgradeArtworkUrl(url))
                    .override(com.bumptech.glide.request.target.Target.SIZE_ORIGINAL)
                    .apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).diskCacheStrategy(DiskCacheStrategy.ALL))
                    .into(heroExtraArt)
            }
        }
        heroExtraArt.visibility = View.VISIBLE
        applyExtraArtworkTilt()
        Log.i(TAG, "HERO_EXTRA_ART_LAYER_APPLY: placement=${config.extraArtworkPlacement} sourceMode=$sourceMode tiltEnabled=${config.extraArtwork3dEnabled} depth=${config.extraArtworkDepthPercent} cached=${imageKey == lastHeroExtraKey} trueDepthOverGhostRows=true heroPosterZ=${heroExtraArt.translationZ} rowsStillVisible=true")
    }

    private fun applyExtraArtworkTilt() {
        val depth = config.extraArtworkDepthPercent.coerceIn(0, 100)
        heroExtraArt.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        heroExtraArt.post {
            val density = resources.displayMetrics.density
            heroExtraArt.cameraDistance = density * 36000f
            heroExtraArt.pivotX = heroExtraArt.width / 2f
            heroExtraArt.pivotY = heroExtraArt.height / 2f
            if (config.extraArtwork3dEnabled == 1) {
                val normalized = depth / 100f
                heroExtraArt.rotationY = 0f
                heroExtraArt.rotationX = -(1.0f + normalized * 5.0f)
                heroExtraArt.rotation = 0f
                heroExtraArt.translationX = 0f
                heroExtraArt.translationY = 0f
                heroExtraArt.translationZ = heroPosterDepthZ()
                heroExtraArt.scaleX = 1.0f
                heroExtraArt.scaleY = 1.0f
                heroExtraArt.alpha = 1f
            } else {
                heroExtraArt.rotationY = 0f
                heroExtraArt.rotationX = 0f
                heroExtraArt.rotation = 0f
                heroExtraArt.translationX = 0f
                heroExtraArt.translationY = 0f
                heroExtraArt.translationZ = heroPosterDepthZ()
                heroExtraArt.scaleX = 1f
                heroExtraArt.scaleY = 1f
                heroExtraArt.alpha = 1f
            }
            heroExtraArt.invalidate()
        }
    }

    private fun extraArtHeroParams(): FrameLayout.LayoutParams {
        val w = dp(config.extraArtworkWidthDp)
        val h = dp(config.extraArtworkHeightDp)
        val placement = config.extraArtworkPlacement.coerceIn(0, 3)
        val gravity = when (placement) {
            1 -> Gravity.TOP or Gravity.START
            2 -> Gravity.TOP or Gravity.END
            3 -> Gravity.CENTER
            else -> Gravity.TOP or Gravity.END
        }
        return FrameLayout.LayoutParams(w, h, gravity).apply {
            topMargin = if (placement == 3) dp(config.extraArtworkOffsetYDp) else dp(150 + config.extraArtworkOffsetYDp)
            leftMargin = dp(52 + config.extraArtworkOffsetXDp)
            rightMargin = dp(86 - config.extraArtworkOffsetXDp)
        }
    }

    private fun launchDetails(item: TitleCard) {
        startActivity(Intent(this, MediaDetailsActivity::class.java).apply {
            putExtra(MediaDetailsActivity.EXTRA_TITLE, item.title)
            putExtra(MediaDetailsActivity.EXTRA_META_LINE, item.meta)
            putExtra(MediaDetailsActivity.EXTRA_DESC, item.desc)
            putExtra(MediaDetailsActivity.EXTRA_MEDIA_TYPE, item.mediaType)
            putExtra(MediaDetailsActivity.EXTRA_EXTERNAL_ID, item.externalId ?: item.title)
            putExtra(MediaDetailsActivity.EXTRA_POSTER_URL, item.posterUrl ?: "")
            putExtra(MediaDetailsActivity.EXTRA_BACKDROP_URL, item.backdropUrl ?: item.posterUrl ?: "")
            putExtra(MediaDetailsActivity.EXTRA_LOGO_URL, item.logoUrl ?: "")
        })
    }


    private fun resetRowLogoState(frame: View, logoGlow: View, logo: ImageView, label: TextView, title: String) {
        (frame.getTag(R.id.tag_logo_focus_runnable) as? Runnable)?.let { frame.removeCallbacks(it) }
        frame.setTag(R.id.tag_logo_focus_runnable, null)
        // True lazy logo/title mode: unfocused row cards are artwork-only.
        logo.animate().cancel()
        logoGlow.animate().cancel()
        label.animate().cancel()
        logo.visibility = View.INVISIBLE
        logo.alpha = 0f
        logo.scaleX = 0.90f
        logo.scaleY = 0.90f
        logo.translationX = 0f
        logo.translationY = dp(18).toFloat()
        logoGlow.visibility = View.INVISIBLE
        logoGlow.alpha = 0f
        label.visibility = View.INVISIBLE
        label.alpha = 0f
        label.translationY = dp(22).toFloat()
        label.gravity = Gravity.CENTER
        label.textSize = 13f
        label.typeface = Typeface.DEFAULT_BOLD
        label.background = rounded(0x990B1320.toInt(), 18, 0x66FFFFFF, 1)
    }

    private fun scheduleFocusedRowLogoLoad(frame: View, item: TitleCard, logoGlow: View, logo: ImageView, label: TextView) {
        if (config.cardLogoVisible != 1) return
        val displayLogoUrl = resolveDisplayLogoUrl(item)?.takeIf { it.isNotBlank() }
        val upgradedUrl = displayLogoUrl?.let { upgradeArtworkUrl(it) }
        val runnable = Runnable {
            if (!frame.hasFocus()) return@Runnable
            logoGlow.visibility = View.VISIBLE
            logoGlow.alpha = 0f
            // v2.8.26.14: row-card genre pill removed. The title/logo artwork now occupies
            // the lower metadata lane with a half-inch visual inset from the left edge.
            label.text = ""
            label.visibility = View.INVISIBLE
            label.alpha = 0f
            label.scaleX = 1f
            label.scaleY = 1f
            label.translationY = 0f
            if (upgradedUrl != null) {
                logo.visibility = View.VISIBLE
                logo.alpha = 0f
                logo.scaleX = 0.88f
                logo.scaleY = 0.88f
                logo.translationY = dp(18).toFloat()
                val previous = logo.getTag(R.id.tag_logo_focus_url) as? String
                if (previous != upgradedUrl || logo.drawable == null) {
                    logo.setTag(R.id.tag_logo_focus_url, upgradedUrl)
                    Glide.with(this@MainActivity).load(upgradedUrl)
                        .override(dp((config.cardWidthDp * 0.68f).toInt()), dp((config.cardHeightDp * 0.28f).toInt()))
                        .apply(RequestOptions()
                            .format(DecodeFormat.PREFER_RGB_565)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .dontTransform())
                        .into(logo)
                }
                logo.animate()
                    .alpha(0.98f)
                    .scaleX(1f)
                    .scaleY(1f)
                    .translationX(0f)
                    .translationY(0f)
                    .setDuration(220)
                    .start()
            }
            logoGlow.animate().alpha(1f).setDuration(150).start()
            Log.i(TAG, "ROW_CARD_LOGO_LEFT_MATH_FIX: rowGenreRemoved=true logoLowerLane=true gravity=bottom_start scaleType=FIT_START trueLeftInsetDp=${config.cardLogoInsetLeftDp} bottomInsetDp=${config.cardLogoInsetBottomDp} noRightOrigin=true title=${item.title.take(42)}")
        }
        frame.setTag(R.id.tag_logo_focus_runnable, runnable)
        frame.postDelayed(runnable, 150L)
    }


    private fun focusedCardGenrePill(item: TitleCard): String {
        // Focus card overlay: logo/title is handled by artwork; this pill shows only themed genre text.
        // Keep unfocused cards text-free for performance and a cleaner Stremize-style row.
        val tokens = item.meta
            .split('•')
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .filterNot { it.matches(Regex("\\d{4}")) }
            .filterNot { it.contains("IMDb", ignoreCase = true) }
            .filterNot { it.contains("TMDb", ignoreCase = true) }
            .filterNot { it.contains("GB", ignoreCase = true) }
            .filterNot { it.equals("4K", ignoreCase = true) || it.equals("HD", ignoreCase = true) || it.equals("DV", ignoreCase = true) }
        return tokens.take(2).joinToString(" • ")
    }

    private fun focusedCardLabel(item: TitleCard): String {
        val genreLine = item.meta
            .split('•')
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.matches(Regex("\\d{4}")) && !it.contains("IMDb", ignoreCase = true) && !it.contains("GB", ignoreCase = true) }
            .joinToString(" • ")
        return if (genreLine.isBlank()) item.title else "${item.title}\n$genreLine"
    }

    private fun prefetchNeighborLogos(rowIndex: Int, column: Int) {
        // Low-pressure cache warm for immediate neighbors only, after focus settles.
        // This keeps fast DPAD movement smooth without loading every row logo at bind time.
        if (config.cardLogoVisible != 1 || currentRows.isEmpty()) return
        val row = currentRows.getOrNull(rowIndex) ?: return
        listOf(column - 1, column + 1).forEach { idx ->
            val neighbor = row.items.getOrNull(idx) ?: return@forEach
            val url = resolveDisplayLogoUrl(neighbor)?.takeIf { it.isNotBlank() } ?: return@forEach
            main.postDelayed({
                if (lastFocusedRow == rowIndex && kotlin.math.abs(lastFocusedColumn - idx) <= 1) {
                    Glide.with(this@MainActivity)
                        .downloadOnly()
                        .load(upgradeArtworkUrl(url))
                        .submit(dp((config.cardWidthDp * 0.55f).toInt()), dp((config.cardHeightDp * 0.36f).toInt()))
                }
            }, 260L)
        }
    }

    private fun cardUnfocusedAlpha(): Float {
        return ((100 - config.dimUnfocusedPercent.coerceIn(0, 70)).coerceIn(30, 100) / 100f)
    }

    private fun applyDimStateToAllVisibleCards() {
        stableCardByKey.forEach { (key, card) ->
            val focusedOrHeld = key == "${lastFocusedRow}:${lastFocusedColumn}" && (card.hasFocus() || holdLastCardHighlightForMenu)
            card.animate().cancel()
            card.alpha = if (focusedOrHeld) 1f else cardUnfocusedAlpha()
        }
        Log.i(TAG, "DIM_UNFOCUSED_CARDS_STICKY_APPLY: cards=${stableCardByKey.size} alpha=${cardUnfocusedAlpha()} rows=${stableRowByIndex.size}")
    }

    private fun applyCardFocus(view: View, focused: Boolean) {
        view.animate().cancel()
        val configuredScale = config.focusedScalePercent.coerceIn(100, 120) / 100f
        // v2.8.16.2: restore donor/new-app style card focus without changing row layout.
        // The card visually grows above neighboring cards using translationZ/elevation; layout size is unchanged.
        val bounceBoost = if (focused) (config.focusBouncePercent.coerceIn(0, 100) / 1000f) else 0f
        val scale = if (focused) (configuredScale.coerceAtLeast(1.08f) + bounceBoost).coerceAtMost(1.24f) else 1f
        val lift = if (focused) dp(config.cardLiftDp.coerceIn(0, 28).coerceAtLeast(10)).toFloat() else 0f
        val glowAlpha = ((config.glowStrengthPercent.coerceIn(0, 100) / 100f) * 255).toInt().coerceIn(0, 255)
        val baseRing = homeLayoutRingColor(config.focusRingColorIndex)
        val ringColor = if (focused && config.focusRingEnabled == 1) (baseRing and 0x00FFFFFF) or (glowAlpha shl 24) else Color.TRANSPARENT
        val spreadExtra = if (focused) (config.focusGlowSpreadPercent.coerceIn(0, 100) / 25) else 0
        val ringWidth = if (focused && config.focusRingEnabled == 1) (config.focusRingThicknessDp.coerceIn(2, 8) + spreadExtra).coerceIn(2, 12) else 0
        view.background = rounded(
            if (focused) 0x00182235 else if (config.glassCardMode == 1) 0xAA121A26.toInt() else 0xFF0B0F18.toInt(),
            config.cornerRadiusDp,
            if (focused) Color.TRANSPARENT else 0x22FFFFFF,
            if (focused) 0 else 1
        )
        (view.getTag(R.id.tag_card_focus_overlay) as? View)?.let { overlay ->
            overlay.background = rounded(Color.TRANSPARENT, config.cornerRadiusDp, ringColor, ringWidth)
            overlay.visibility = if (focused && config.focusRingEnabled == 1) View.VISIBLE else View.INVISIBLE
            overlay.animate().cancel()
            overlay.alpha = if (focused && config.focusRingEnabled == 1) 1f else 0f
            overlay.translationZ = dp(96).toFloat()
            overlay.elevation = dp(96).toFloat()
            overlay.bringToFront()
        }
        val glowElevation = if (focused) dp(6 + (config.focusGlowSpreadPercent.coerceIn(0, 100) * 0.22f).toInt()).toFloat() else dp(2).toFloat()
        view.elevation = glowElevation
        val targetAlpha = if (focused) 1f else cardUnfocusedAlpha()
        view.alpha = targetAlpha
        view.animate()
            .alpha(targetAlpha)
            .scaleX(scale)
            .scaleY(scale)
            .translationZ(lift)
            .setDuration(if (focused) 135 else 105)
            .withEndAction { applyDimStateToAllVisibleCards() }
            .start()
    }

    private fun loadHeroBackdropImage(target: ImageView, url: String?, fallbackRes: Int) {
        val applyFitmentAfterLoad = {
            target.post { applyHeroQualityMode() }
        }
        if (url.isNullOrBlank()) {
            target.setImageResource(fallbackRes)
            applyFitmentAfterLoad()
            target.post { syncHeroPosterCutoutFromPrimaryLayer() }
        } else {
            // Hero artwork is always requested/decode-cached at 4K quality even when the UI
            // composition stays 1080p for smooth Android TV performance. Use a CustomTarget so
            // the fit matrix is applied AFTER the real decoded drawable is attached, not while
            // the placeholder is still on screen.
            val width = 3840
            val height = 2160
            heroBackdropTarget?.let { Glide.with(this).clear(it) }
            heroBackdropTarget = object : CustomTarget<Drawable>(width, height) {
                override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable>?) {
                    target.setImageDrawable(resource)
                    applyFitmentAfterLoad()
                    target.post { syncHeroPosterCutoutFromPrimaryLayer() }
                    Log.i(TAG, "HERO_4K_PRIMARY_CUTOUT_RESOURCE_READY: decodedTarget=${width}x$height urlCached=true oldBackdropRenderer=false singleHeroImage=true backendCutoutPreferred=true fallbackOpacitySafe=true globalGlow=false rowsRestored=true")
                }

                override fun onLoadCleared(placeholder: Drawable?) {
                    if (placeholder != null) target.setImageDrawable(placeholder)
                }

                override fun onLoadFailed(errorDrawable: Drawable?) {
                    target.setImageDrawable(errorDrawable ?: ContextCompat.getDrawable(this@MainActivity, fallbackRes))
                    applyFitmentAfterLoad()
                    target.post { syncHeroPosterCutoutFromPrimaryLayer() }
                }
            }
            Glide.with(this).load(upgradeArtworkUrl(url))
                .placeholder(fallbackRes)
                .error(fallbackRes)
                .override(width, height)
                .apply(RequestOptions()
                    .format(DecodeFormat.PREFER_ARGB_8888)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .dontAnimate()
                    .dontTransform())
                .into(heroBackdropTarget!!)
        }
    }

    private fun loadImage(target: ImageView, url: String?, fallbackRes: Int) {
        if (url.isNullOrBlank()) {
            target.setImageResource(fallbackRes)
        } else {
            Glide.with(this).load(upgradeArtworkUrl(url))
                .placeholder(fallbackRes)
                .error(fallbackRes)
                .override(dp(config.cardWidthDp.coerceIn(190, 420)), dp(config.cardHeightDp.coerceIn(110, 260)))
                .apply(RequestOptions()
                    .format(DecodeFormat.PREFER_RGB_565)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .dontAnimate()
                    .dontTransform())
                .into(target)
        }
    }


    private fun resolveDisplayLogoUrl(item: TitleCard): String? {
        val direct = item.logoUrl?.trim().orEmpty()
        if (direct.isNotBlank()) return direct
        val id = item.externalId?.trim().orEmpty()
        if (id.startsWith("tt") && id.length >= 5) {
            val type = if (item.mediaType.equals("series", true)) "series" else "movie"
            val metahub = "https://images.metahub.space/logo/large/$id/img"
            Log.i(TAG, "ROW_HERO_LOGO_FALLBACK: title=${item.title.take(40)} type=$type imdb=$id source=${item.source}")
            return metahub
        }
        return null
    }

    private fun upgradeArtworkUrl(url: String): String = BackendEndpoint.imageProxyUrl(url)

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int, strokeDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(dp(strokeDp).coerceAtLeast(0), strokeColor)
    }

    private fun roundOutline(radiusDp: Int): ViewOutlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, dp(radiusDp).toFloat())
        }
    }

    private fun fallbackDrawable(index: Int): Int = when (index % 9) {
        0 -> R.drawable.bg_shogun
        1 -> R.drawable.bg_batman
        2 -> R.drawable.bg_fallout
        3 -> R.drawable.bg_dune
        4 -> R.drawable.bg_halo
        5 -> R.drawable.bg_wonka
        6 -> R.drawable.bg_mayor
        7 -> R.drawable.bg_civilwar
        else -> R.drawable.bg_avatar
    }

    private fun extractYearFromMeta(meta: String): Int {
        val match = Regex("""\b(19\d{2}|20\d{2})\b""").find(meta)
        return match?.value?.toIntOrNull() ?: 0
    }

    private fun defaultRows(): List<HomeRow> {
        val base = listOf(
            TitleCard("The Housemaid", "2025  •  Popular   IMDb 6.8", "A young woman enters a mansion of secrets, manipulation, and escalating psychological games.", R.drawable.bg_shogun, mediaType = "movie", externalId = "the-housemaid"),
            TitleCard("Michael", "2025  •  Music Drama", "A cinematic music-story spotlight with large landscape artwork.", R.drawable.bg_batman, mediaType = "movie", externalId = "michael"),
            TitleCard("Send Help", "2025  •  Thriller", "A bold poster-driven hero example for the rebuilt row engine.", R.drawable.bg_fallout, mediaType = "movie", externalId = "send-help"),
            TitleCard("Dune", "2024  •  Sci-Fi", "Expansive cinema artwork with clean DPAD navigation.", R.drawable.bg_dune, mediaType = "movie", externalId = "dune"),
            TitleCard("Halo", "Series  •  Action", "A series card using the same rebuilt card renderer.", R.drawable.bg_halo, mediaType = "series", externalId = "halo"),
            TitleCard("Wonka", "Movie  •  Family", "A bright colorful fallback card.", R.drawable.bg_wonka, mediaType = "movie", externalId = "wonka")
        )
        return listOf(
            HomeRow("Featured", base),
            HomeRow("Popular Movies", base.shuffled()),
            HomeRow("Popular Shows", base.reversed()),
            HomeRow("Recently Added", base.drop(1) + base.take(1)),
            HomeRow("Because You Watched", base.drop(2) + base.take(2))
        )
    }
}
