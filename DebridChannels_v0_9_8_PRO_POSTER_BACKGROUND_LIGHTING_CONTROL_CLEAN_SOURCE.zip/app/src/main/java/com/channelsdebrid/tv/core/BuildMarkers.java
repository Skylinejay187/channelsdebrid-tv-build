package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.9.6 Advanced Live TV Layout Editor";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.9.6_advanced_live_tv_layout_editor_clean_consolidation";
}
