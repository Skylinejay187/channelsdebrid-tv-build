package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v5.1 FULL FUNCTIONAL REWIRE";
    public static final String LOG_MARKER = "DC_V5_1_FULL_FUNCTIONAL_REWIRE";
    private BuildMarkers() {}
}
