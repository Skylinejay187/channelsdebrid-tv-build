package com.channelsdebrid.tv.backend;
import android.content.Context;import android.content.SharedPreferences;
public final class BackendConfig {
    private final SharedPreferences p;
    public BackendConfig(Context c){ p=c.getSharedPreferences("dc_v5_backend",Context.MODE_PRIVATE); }
    public String baseUrl(){ return p.getString("baseUrl", "http://192.168.1.50:8089"); }
    public String m3uUrl(){ return p.getString("m3uUrl", ""); }
    public String catalogUrl(){ return p.getString("catalogUrl", ""); }
    public String channelsDvrUrl(){ return p.getString("channelsDvrUrl", "http://192.168.1.50:8089"); }
    public void saveBaseUrl(String url){ p.edit().putString("baseUrl", clean(url)).apply(); }
    public void saveM3uUrl(String url){ p.edit().putString("m3uUrl", clean(url)).apply(); }
    public void saveCatalogUrl(String url){ p.edit().putString("catalogUrl", clean(url)).apply(); }
    public void saveChannelsDvrUrl(String url){ p.edit().putString("channelsDvrUrl", clean(url)).apply(); }
    private String clean(String s){ return s==null?"":s.trim(); }
}
