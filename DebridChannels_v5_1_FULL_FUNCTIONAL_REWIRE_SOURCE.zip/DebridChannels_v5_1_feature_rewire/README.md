# Debrid Channels v5.1 FULL FUNCTIONAL REWIRE

Clean v5 architecture, no old stacked patch code.

Functional wiring included:
- Settings surfaces are real and persistent.
- Pro Layout Editor saves menu position, icon placement, row title toggle, hero artwork position/size.
- Stremio addon JSON links are saved and used for manifest/catalog/stream loading.
- Backend/catalog URL loading supports Stremio-style `metas`, `items`, or `data` JSON arrays.
- Live TV M3U loading parses EXTINF names, groups, logos, and stream URLs.
- Channels DVR base URL tries `/devices/ANY/channels.m3u`.
- VOD link selection calls configured Stremio `/stream/{type}/{id}.json` endpoints.
- One Activity, one NavigationController, one PlayerManager, one LiveTvStateMachine, one GuideCacheOwner, one TimeshiftEngine, one UiStateStore.

Logcat marker: `DC_V5_1_FULL_FUNCTIONAL_REWIRE`
UI marker: `v5.1 FULL FUNCTIONAL REWIRE`
