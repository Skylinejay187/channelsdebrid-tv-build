package com.channelsdebrid.tv.settings

import android.content.Context
import com.channelsdebrid.tv.settings.HomeLayoutDefaults
import com.channelsdebrid.tv.settings.sanitized

class SettingsRepository(context: Context) {
    private val prefs = context.getSharedPreferences("channels_debrid_settings", Context.MODE_PRIVATE)

    fun loadHomeLayout(): HomeLayoutSettings = HomeLayoutSettings(
        rowTopDp = prefs.getInt("home_layout_row_top_dp", HomeLayoutDefaults.ROW_TOP_DP),
        rowLeftDp = prefs.getInt("home_layout_row_left_dp", HomeLayoutDefaults.ROW_LEFT_DP),
        cardWidthDp = prefs.getInt("home_layout_card_width_dp", HomeLayoutDefaults.CARD_WIDTH_DP),
        cardHeightDp = prefs.getInt("home_layout_card_height_dp", HomeLayoutDefaults.CARD_HEIGHT_DP),
        cardSpacingDp = prefs.getInt("home_layout_card_spacing_dp", HomeLayoutDefaults.CARD_SPACING_DP),
        focusedScalePercent = prefs.getInt("home_layout_focused_scale_percent", HomeLayoutDefaults.FOCUSED_SCALE_PERCENT),
        heroTextLeftDp = prefs.getInt("home_layout_hero_text_left_dp", HomeLayoutDefaults.HERO_TEXT_LEFT_DP),
        heroTextTopDp = prefs.getInt("home_layout_hero_text_top_dp", HomeLayoutDefaults.HERO_TEXT_TOP_DP),
        topMenuOffsetDp = prefs.getInt("home_layout_top_menu_offset_dp", HomeLayoutDefaults.TOP_MENU_OFFSET_DP),
        bottomSafeDp = prefs.getInt("home_layout_bottom_safe_dp", HomeLayoutDefaults.BOTTOM_SAFE_DP),
        previewCardCount = prefs.getInt("home_layout_preview_card_count", HomeLayoutDefaults.PREVIEW_CARD_COUNT),
        glowStrengthPercent = prefs.getInt("home_layout_glow_strength_percent", HomeLayoutDefaults.GLOW_STRENGTH_PERCENT),
        pulseStrengthPercent = prefs.getInt("home_layout_pulse_strength_percent", HomeLayoutDefaults.PULSE_STRENGTH_PERCENT),
        focusRingEnabled = prefs.getInt("home_layout_focus_ring_enabled", HomeLayoutDefaults.FOCUS_RING_ENABLED),
        focusRingThicknessDp = prefs.getInt("home_layout_focus_ring_thickness_dp", HomeLayoutDefaults.FOCUS_RING_THICKNESS_DP),
        focusRingColorIndex = prefs.getInt("home_layout_focus_ring_color_index", HomeLayoutDefaults.FOCUS_RING_COLOR_INDEX),
        cardTiltPercent = prefs.getInt("home_layout_card_tilt_percent", HomeLayoutDefaults.CARD_TILT_PERCENT),
        cardLiftDp = prefs.getInt("home_layout_card_lift_dp", HomeLayoutDefaults.CARD_LIFT_DP),
        cornerRadiusDp = prefs.getInt("home_layout_corner_radius_dp", HomeLayoutDefaults.CORNER_RADIUS_DP),
        dimUnfocusedPercent = prefs.getInt("home_layout_dim_unfocused_percent", HomeLayoutDefaults.DIM_UNFOCUSED_PERCENT),
        topMenuIconStyle = prefs.getInt("home_layout_top_menu_icon_style", HomeLayoutDefaults.TOP_MENU_ICON_STYLE),
        topMenuFontIndex = prefs.getInt("home_layout_top_menu_font_index", HomeLayoutDefaults.TOP_MENU_FONT_INDEX),
        heroFontIndex = prefs.getInt("home_layout_hero_font_index", HomeLayoutDefaults.HERO_FONT_INDEX),
        contentFontIndex = prefs.getInt("home_layout_content_font_index", HomeLayoutDefaults.CONTENT_FONT_INDEX),
        rowTitleIconsEnabled = prefs.getInt("home_layout_row_title_icons_enabled", HomeLayoutDefaults.ROW_TITLE_ICONS_ENABLED),
        rowTextVisible = prefs.getInt("home_layout_row_text_visible", HomeLayoutDefaults.ROW_TEXT_VISIBLE),
        extraArtwork3dEnabled = prefs.getInt("home_layout_extra_artwork_3d_enabled", HomeLayoutDefaults.EXTRA_ARTWORK_3D_ENABLED),
        extraArtworkDepthPercent = prefs.getInt("home_layout_extra_artwork_depth_percent", HomeLayoutDefaults.EXTRA_ARTWORK_DEPTH_PERCENT),
        focusBouncePercent = prefs.getInt("home_layout_focus_bounce_percent", HomeLayoutDefaults.FOCUS_BOUNCE_PERCENT),
        glassCardMode = prefs.getInt("home_layout_glass_card_mode", HomeLayoutDefaults.GLASS_CARD_MODE),
        hoverInfoOverlay = prefs.getInt("home_layout_hover_info_overlay", HomeLayoutDefaults.HOVER_INFO_OVERLAY),
        backgroundDimOnFocusPercent = prefs.getInt("home_layout_background_dim_on_focus_percent", HomeLayoutDefaults.BACKGROUND_DIM_ON_FOCUS_PERCENT),
        effectProfileIndex = prefs.getInt("home_layout_effect_profile_index", HomeLayoutDefaults.EFFECT_PROFILE_INDEX)
    ).sanitized()

    fun saveHomeLayout(value: HomeLayoutSettings) {
        val safe = value.sanitized()
        prefs.edit()
            .putInt("home_layout_row_top_dp", safe.rowTopDp)
            .putInt("home_layout_row_left_dp", safe.rowLeftDp)
            .putInt("home_layout_card_width_dp", safe.cardWidthDp)
            .putInt("home_layout_card_height_dp", safe.cardHeightDp)
            .putInt("home_layout_card_spacing_dp", safe.cardSpacingDp)
            .putInt("home_layout_focused_scale_percent", safe.focusedScalePercent)
            .putInt("home_layout_hero_text_left_dp", safe.heroTextLeftDp)
            .putInt("home_layout_hero_text_top_dp", safe.heroTextTopDp)
            .putInt("home_layout_top_menu_offset_dp", safe.topMenuOffsetDp)
            .putInt("home_layout_bottom_safe_dp", safe.bottomSafeDp)
            .putInt("home_layout_preview_card_count", safe.previewCardCount)
            .putInt("home_layout_glow_strength_percent", safe.glowStrengthPercent)
            .putInt("home_layout_pulse_strength_percent", safe.pulseStrengthPercent)
            .putInt("home_layout_focus_ring_enabled", safe.focusRingEnabled)
            .putInt("home_layout_focus_ring_thickness_dp", safe.focusRingThicknessDp)
            .putInt("home_layout_focus_ring_color_index", safe.focusRingColorIndex)
            .putInt("home_layout_card_tilt_percent", safe.cardTiltPercent)
            .putInt("home_layout_card_lift_dp", safe.cardLiftDp)
            .putInt("home_layout_corner_radius_dp", safe.cornerRadiusDp)
            .putInt("home_layout_dim_unfocused_percent", safe.dimUnfocusedPercent)
            .putInt("home_layout_top_menu_icon_style", safe.topMenuIconStyle)
            .putInt("home_layout_top_menu_font_index", safe.topMenuFontIndex)
            .putInt("home_layout_hero_font_index", safe.heroFontIndex)
            .putInt("home_layout_content_font_index", safe.contentFontIndex)
            .putInt("home_layout_row_title_icons_enabled", safe.rowTitleIconsEnabled)
            .putInt("home_layout_row_text_visible", safe.rowTextVisible)
            .putInt("home_layout_extra_artwork_3d_enabled", safe.extraArtwork3dEnabled)
            .putInt("home_layout_extra_artwork_depth_percent", safe.extraArtworkDepthPercent)
            .putInt("home_layout_focus_bounce_percent", safe.focusBouncePercent)
            .putInt("home_layout_glass_card_mode", safe.glassCardMode)
            .putInt("home_layout_hover_info_overlay", safe.hoverInfoOverlay)
            .putInt("home_layout_background_dim_on_focus_percent", safe.backgroundDimOnFocusPercent)
            .putInt("home_layout_effect_profile_index", safe.effectProfileIndex)
            .apply()
    }

    fun resetHomeLayout() {
        prefs.edit()
            .remove("home_layout_row_top_dp")
            .remove("home_layout_row_left_dp")
            .remove("home_layout_card_width_dp")
            .remove("home_layout_card_height_dp")
            .remove("home_layout_card_spacing_dp")
            .remove("home_layout_focused_scale_percent")
            .remove("home_layout_hero_text_left_dp")
            .remove("home_layout_hero_text_top_dp")
            .remove("home_layout_top_menu_offset_dp")
            .remove("home_layout_bottom_safe_dp")
            .remove("home_layout_preview_card_count")
            .remove("home_layout_glow_strength_percent")
            .remove("home_layout_pulse_strength_percent")
            .remove("home_layout_focus_ring_enabled")
            .remove("home_layout_focus_ring_thickness_dp")
            .remove("home_layout_focus_ring_color_index")
            .remove("home_layout_card_tilt_percent")
            .remove("home_layout_card_lift_dp")
            .remove("home_layout_corner_radius_dp")
            .remove("home_layout_dim_unfocused_percent")
            .remove("home_layout_top_menu_icon_style")
            .remove("home_layout_top_menu_font_index")
            .remove("home_layout_hero_font_index")
            .remove("home_layout_row_title_icons_enabled")
            .remove("home_layout_row_text_visible")
            .remove("home_layout_extra_artwork_3d_enabled")
            .remove("home_layout_extra_artwork_depth_percent")
            .apply()
    }

    fun loadTmdb() = TmdbSettings(
        apiKey = prefs.getString("tmdb_api_key", SettingsScaffold.defaultTmdb.apiKey).orEmpty(),
        region = prefs.getString("tmdb_region", SettingsScaffold.defaultTmdb.region).orEmpty(),
        language = prefs.getString("tmdb_language", SettingsScaffold.defaultTmdb.language).orEmpty()
    )

    fun saveTmdb(value: TmdbSettings) {
        prefs.edit()
            .putString("tmdb_api_key", value.apiKey)
            .putString("tmdb_region", value.region)
            .putString("tmdb_language", value.language)
            .apply()
    }

    fun loadCatalogs() = CatalogSettings(
        trendingMoviesEnabled = prefs.getBoolean("catalog_trending_movies", true),
        popularMoviesEnabled = prefs.getBoolean("catalog_popular_movies", true),
        trendingShowsEnabled = prefs.getBoolean("catalog_trending_shows", true),
        popularShowsEnabled = prefs.getBoolean("catalog_popular_shows", true),
        platformRowsEnabled = prefs.getBoolean("catalog_platform_rows", true),
        stremioCatalogRowsEnabled = prefs.getBoolean("catalog_stremio_rows", true)
    )

    fun saveCatalogs(value: CatalogSettings) {
        prefs.edit()
            .putBoolean("catalog_trending_movies", value.trendingMoviesEnabled)
            .putBoolean("catalog_popular_movies", value.popularMoviesEnabled)
            .putBoolean("catalog_trending_shows", value.trendingShowsEnabled)
            .putBoolean("catalog_popular_shows", value.popularShowsEnabled)
            .putBoolean("catalog_platform_rows", value.platformRowsEnabled)
            .putBoolean("catalog_stremio_rows", value.stremioCatalogRowsEnabled)
            .apply()
    }

    fun loadPrimaryAddon(): StremioAddonSettings {
        return loadStremioAddons().firstOrNull() ?: StremioAddonSettings(
            id = "",
            name = "",
            manifestUrl = "",
            enabled = false
        )
    }

    fun loadStremioAddons(): List<StremioAddonSettings> {
        val defaultAddon = SettingsScaffold.defaultAddons.firstOrNull()
        val enabled = prefs.getBoolean("stremio_enabled", defaultAddon?.enabled ?: true)
        val rawNames = prefs.getString("stremio_names_multiline", "").orEmpty().trim()
        val rawManifests = prefs.getString("stremio_manifests_multiline", "").orEmpty().trim()

        val manifestLines = rawManifests
            .lineSequence()
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .toList()

        val nameLines = rawNames
            .lineSequence()
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .toList()

        if (manifestLines.isNotEmpty()) {
            return manifestLines.mapIndexed { index, manifestUrl ->
                val explicitName = nameLines.getOrNull(index).orEmpty()
                val inferredName = manifestUrl
                    .substringBefore('?')
                    .substringAfter("//", manifestUrl)
                    .substringBefore('/')
                    .substringBefore(':')
                    .replace("-", " ")
                    .replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
                StremioAddonSettings(
                    id = "addon_${index + 1}",
                    name = explicitName.ifBlank { inferredName.ifBlank { "Addon ${index + 1}" } },
                    manifestUrl = manifestUrl,
                    enabled = enabled
                )
            }
        }

        val legacy = StremioAddonSettings(
            id = prefs.getString("stremio_id", defaultAddon?.id ?: "").orEmpty(),
            name = prefs.getString("stremio_name", defaultAddon?.name ?: "").orEmpty(),
            manifestUrl = prefs.getString("stremio_manifest", defaultAddon?.manifestUrl ?: "").orEmpty(),
            enabled = enabled
        )

        val candidates = mutableListOf<StremioAddonSettings>()
        if (legacy.manifestUrl.isNotBlank()) {
            candidates.add(legacy)
        }
        SettingsScaffold.defaultAddons.forEach { addon ->
            val addonManifest = addon.manifestUrl.trim()
            if (addonManifest.isNotBlank() && candidates.none { it.manifestUrl.equals(addonManifest, ignoreCase = true) }) {
                candidates.add(addon.copy(manifestUrl = addonManifest, enabled = enabled))
            }
        }
        return candidates.distinctBy { it.manifestUrl.trim().lowercase() }
    }

    fun savePrimaryAddon(value: StremioAddonSettings) {
        saveStremioAddons(listOf(value))
    }

    fun saveStremioAddons(values: List<StremioAddonSettings>) {
        val cleaned = values
            .map { it.copy(name = it.name.trim(), manifestUrl = it.manifestUrl.trim()) }
            .filter { it.manifestUrl.isNotBlank() }
        val primary = cleaned.firstOrNull() ?: SettingsScaffold.defaultAddons.firstOrNull() ?: StremioAddonSettings(
            id = "",
            name = "",
            manifestUrl = "",
            enabled = false
        )
        prefs.edit()
            .putString("stremio_id", primary.id)
            .putString("stremio_name", primary.name)
            .putString("stremio_manifest", primary.manifestUrl)
            .putBoolean("stremio_enabled", values.firstOrNull()?.enabled ?: primary.enabled)
            .putString("stremio_names_multiline", cleaned.joinToString("\n") { it.name })
            .putString("stremio_manifests_multiline", cleaned.joinToString("\n") { it.manifestUrl })
            .apply()
    }


    fun loadDebrid() = DebridSettings(
        realDebridEnabled = prefs.getBoolean("debrid_rd_enabled", SettingsScaffold.defaultDebrid.realDebridEnabled),
        realDebridApiKey = prefs.getString("debrid_rd_api_key", SettingsScaffold.defaultDebrid.realDebridApiKey).orEmpty(),
        torBoxEnabled = prefs.getBoolean("debrid_torbox_enabled", SettingsScaffold.defaultDebrid.torBoxEnabled),
        torBoxApiKey = prefs.getString("debrid_torbox_api_key", SettingsScaffold.defaultDebrid.torBoxApiKey).orEmpty(),
        preferredProvider = prefs.getString("debrid_preferred_provider", SettingsScaffold.defaultDebrid.preferredProvider).orEmpty(),
        autoFallback = prefs.getBoolean("debrid_auto_fallback", SettingsScaffold.defaultDebrid.autoFallback)
    )

    fun saveDebrid(value: DebridSettings) {
        prefs.edit()
            .putBoolean("debrid_rd_enabled", value.realDebridEnabled)
            .putString("debrid_rd_api_key", value.realDebridApiKey)
            .putBoolean("debrid_torbox_enabled", value.torBoxEnabled)
            .putString("debrid_torbox_api_key", value.torBoxApiKey)
            .putString("debrid_preferred_provider", value.preferredProvider)
            .putBoolean("debrid_auto_fallback", value.autoFallback)
            .apply()
    }

    fun loadChannelsDvr() = ChannelsDvrSettings(
        autoDetect = false,
        baseUrl = prefs.getString("dvr_base_url", "").orEmpty(),
        deviceId = prefs.getString("dvr_device_id", "").orEmpty()
    )

    fun saveChannelsDvr(value: ChannelsDvrSettings) {
        prefs.edit()
            .putBoolean("dvr_auto_detect", false)
            .putString("dvr_base_url", value.baseUrl)
            .remove("dvr_username")
            .remove("dvr_password")
            .putString("dvr_device_id", value.deviceId)
            .apply()
    }

    fun loadXtream() = XtreamSettings(
        server = prefs.getString("xtream_server", "").orEmpty(),
        username = prefs.getString("xtream_username", "").orEmpty(),
        password = prefs.getString("xtream_password", "").orEmpty(),
        m3uUrl = prefs.getString("xtream_m3u_url", "").orEmpty(),
        enabled = prefs.getBoolean("xtream_enabled", false)
    )

    fun saveXtream(value: XtreamSettings) {
        prefs.edit()
            .putString("xtream_server", value.server)
            .putString("xtream_username", value.username)
            .putString("xtream_password", value.password)
            .putString("xtream_m3u_url", value.m3uUrl)
            .putBoolean("xtream_enabled", value.enabled)
            .apply()
    }

    fun loadStorage() = StorageSettings(
        preferredTarget = prefs.getString("storage_preferred", SettingsScaffold.defaultStorage.preferredTarget).orEmpty(),
        usbPath = prefs.getString("storage_usb_path", "").orEmpty(),
        nasPath = prefs.getString("storage_nas_path", "").orEmpty(),
        nasHost = prefs.getString("storage_nas_host", "").orEmpty(),
        nasShare = prefs.getString("storage_nas_share", "").orEmpty(),
        nasUsername = prefs.getString("storage_nas_username", "").orEmpty(),
        nasPassword = prefs.getString("storage_nas_password", "").orEmpty(),
        timeshiftMinutes = prefs.getInt("storage_timeshift_minutes", SettingsScaffold.defaultStorage.timeshiftMinutes),
        movieCacheEnabled = prefs.getBoolean("storage_movie_cache_enabled", SettingsScaffold.defaultStorage.movieCacheEnabled)
    )

    fun saveStorage(value: StorageSettings) {
        prefs.edit()
            .putString("storage_preferred", value.preferredTarget)
            .putString("storage_usb_path", value.usbPath)
            .putString("storage_nas_path", value.nasPath)
            .putString("storage_nas_host", value.nasHost)
            .putString("storage_nas_share", value.nasShare)
            .putString("storage_nas_username", value.nasUsername)
            .putString("storage_nas_password", value.nasPassword)
            .putInt("storage_timeshift_minutes", value.timeshiftMinutes)
            .putBoolean("storage_movie_cache_enabled", value.movieCacheEnabled)
            .apply()
    }

    fun loadTrailers() = TrailerSettings(
        enabled = prefs.getBoolean("trailers_enabled", true),
        autoplayOnFocus = prefs.getBoolean("trailers_autoplay_focus", true),
        autoplayDelayMs = prefs.getLong("trailers_delay_ms", 5000L),
        backgroundAutoplayEnabled = prefs.getBoolean("trailers_background_enabled", true),
        backgroundAutoplayDelayMs = prefs.getLong("trailers_background_delay_ms", 5000L),
        popupMode = prefs.getString("trailers_popup_mode", "popup").orEmpty().let { if (it == "center_modal") "fullscreen" else it },
        playbackLocation = prefs.getString("trailers_playback_location", "both").orEmpty().ifBlank { "both" },
        youtubeApiKey = "",
        prefer4k = prefs.getBoolean("trailers_prefer_4k", true)
    )

    fun saveTrailers(value: TrailerSettings) {
        prefs.edit()
            .putBoolean("trailers_enabled", value.enabled)
            .putBoolean("trailers_autoplay_focus", value.autoplayOnFocus)
            .putLong("trailers_delay_ms", value.autoplayDelayMs)
            .putBoolean("trailers_background_enabled", value.backgroundAutoplayEnabled)
            .putLong("trailers_background_delay_ms", value.backgroundAutoplayDelayMs)
            .putString("trailers_popup_mode", value.popupMode)
            .putString("trailers_playback_location", value.playbackLocation)
            .remove("trailers_youtube_api_key")
            .putBoolean("trailers_prefer_4k", value.prefer4k)
            .apply()
    }

    fun loadPlayback() = PlaybackSettings(
        frameRateMatching = prefs.getBoolean("playback_frame_rate_matching", true),
        preferExternalStorageForCache = prefs.getBoolean("playback_prefer_external", true),
        timeshiftEnabled = prefs.getBoolean("playback_timeshift_enabled", true),
        autoPlayBestStream = prefs.getBoolean("playback_auto_best", true),
        fileSizeLimitGb = prefs.getInt("playback_file_limit_gb", 40),
        ultraHdGuideUiEnabled = prefs.getBoolean("playback_4k_ui_enabled", true),
        liveStatusChecksEnabled = prefs.getBoolean("playback_status_checks_enabled", true)
    )

    fun savePlayback(value: PlaybackSettings) {
        prefs.edit()
            .putBoolean("playback_frame_rate_matching", value.frameRateMatching)
            .putBoolean("playback_prefer_external", value.preferExternalStorageForCache)
            .putBoolean("playback_timeshift_enabled", value.timeshiftEnabled)
            .putBoolean("playback_auto_best", value.autoPlayBestStream)
            .putInt("playback_file_limit_gb", value.fileSizeLimitGb)
            .putBoolean("playback_4k_ui_enabled", value.ultraHdGuideUiEnabled)
            .putBoolean("playback_status_checks_enabled", value.liveStatusChecksEnabled)
            .apply()
    }


    fun loadLiveBackend() = LiveBackendSettings(
        baseUrl = prefs.getString("live_backend_base_url", "http://192.168.100.55:8181").orEmpty(),
        userId = prefs.getString("live_backend_user_id", "demo").orEmpty(),
        autoSyncSources = prefs.getBoolean("live_backend_auto_sync", true),
        epgRefreshEveryHours = prefs.getInt("live_backend_epg_refresh_hours", 12).let { if (it <= 6) 6 else if (it <= 12) 12 else 24 },
        xmltvGuideUrl = prefs.getString("live_backend_xmltv_guide_url", "").orEmpty()
    )

    fun saveLiveBackend(value: LiveBackendSettings) {
        prefs.edit()
            .putString("live_backend_base_url", value.baseUrl)
            .putString("live_backend_user_id", value.userId)
            .putBoolean("live_backend_auto_sync", value.autoSyncSources)
            .putInt("live_backend_epg_refresh_hours", value.epgRefreshEveryHours)
            .putString("live_backend_xmltv_guide_url", value.xmltvGuideUrl)
            .apply()
    }

}
