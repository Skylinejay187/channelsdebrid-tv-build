package com.channelsdebrid.tv.playback

import com.channelsdebrid.tv.net.BackendEndpoint
import android.content.Intent
import android.os.Bundle
import android.graphics.Typeface
import android.util.TypedValue
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.channelsdebrid.tv.R
import com.channelsdebrid.tv.TvSafeAreaHelper
import com.channelsdebrid.tv.settings.SettingsRepository
import java.util.concurrent.Executors

class SourceSelectionActivity : AppCompatActivity() {
    private lateinit var settingsRepository: SettingsRepository
    private val resolver = StreamingPipelineResolver()
    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var container: LinearLayout
    private lateinit var loading: ProgressBar
    private lateinit var status: TextView
    private lateinit var backgroundView: ImageView
    private lateinit var metaView: TextView
    private var options: List<StreamingPipelineResolver.StreamOption> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_source_selection)
        TvSafeAreaHelper.applyIfTv(this, ((findViewById(android.R.id.content) as? ViewGroup)?.getChildAt(0) as? ViewGroup)?.getChildAt(2), "source_selection", TvSafeAreaHelper.InsetsDp(36, 30, 36, 50))
        settingsRepository = SettingsRepository(this)
        container = findViewById(R.id.sourceList)
        loading = findViewById(R.id.sourceLoading)
        status = findViewById(R.id.sourceStatus)
        backgroundView = findViewById(R.id.sourceBackdrop)
        metaView = findViewById(R.id.sourceMeta)
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val backdropUrl = intent.getStringExtra(EXTRA_ARTWORK_URL).orEmpty()
        findViewById<TextView>(R.id.sourceTitle).text = title
        metaView.text = intent.getStringExtra(EXTRA_META_LINE).orEmpty()
        if (backdropUrl.isNotBlank()) {
            com.bumptech.glide.Glide.with(this)
                .load(upgradeArtworkUrl(backdropUrl))
                .override(com.bumptech.glide.request.target.Target.SIZE_ORIGINAL)
                .diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.ALL)
                .centerCrop()
                .into(backgroundView)
        }
        loadSources()
    }

    private fun loadSources() {
        loading.visibility = View.VISIBLE
        status.text = "Loading sources…"
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val externalId = intent.getStringExtra(EXTRA_EXTERNAL_ID).orEmpty()
        val mediaType = intent.getStringExtra(EXTRA_MEDIA_TYPE).orEmpty()
        val addons = settingsRepository.loadStremioAddons()
        val playback = settingsRepository.loadPlayback()
        executor.execute {
            val loaded = resolver.listCandidates(title, externalId, mediaType, addons, playback)
            handler.post {
                loading.visibility = View.GONE
                val scored = loaded.sortedWith(compareByDescending<StreamingPipelineResolver.StreamOption> { option ->
                    val key = PlayerReliabilitySystem.sourceKey(option.debug, option.sourceLabel)
                    val penalty = PlayerReliabilitySystem.storedPenalty(this, key)
                    PlayerReliabilitySystem.scoreSource(option.sourceLabel, option.displayTitle, option.debug, penalty).score
                }.thenBy { it.index })
                options = scored
                android.util.Log.i("DebridChannels", "SOURCE_RELIABILITY_SCORING_APPLIED: count=${scored.size} profile=${PlayerReliabilitySystem.deviceProfile().name}")
                if (scored.isEmpty()) {
                    status.text = "No sources found"
                    return@post
                }
                status.text = "Select a source"
                renderOptions()
            }
        }
    }

    private fun renderOptions() {
        container.removeAllViews()
        val grouped = options.groupBy { normalizeProviderName(it.addonName.ifBlank { it.sourceLabel }) }
            .toSortedMap(compareBy<String> { providerSortRank(it) }.thenBy { it.lowercase() })
        var firstRow: View? = null

        grouped.forEach { (provider, providerOptions) ->
            addSectionHeader(provider)
            providerOptions.forEach { option ->
                val row = addSourceRow(option)
                if (firstRow == null) firstRow = row
            }
        }

        if (options.size > 1) {
            addSectionHeader("All Sources")
            options.forEach { option ->
                val row = addSourceRow(option)
                if (firstRow == null) firstRow = row
            }
        }

        firstRow?.post { firstRow?.requestFocus() }
        android.util.Log.i("DebridChannels", "SOURCE_SELECTION_GROUPED_BY_ADDON: providers=${grouped.keys.joinToString()} all=${options.size}")
    }

    private fun addSectionHeader(title: String) {
        val density = resources.displayMetrics.density
        val header = TextView(this).apply {
            text = title
            setTextColor(0xFFF4EFE8.toInt())
            setTypeface(typeface, Typeface.BOLD)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            letterSpacing = 0.04f
            isFocusable = false
        }
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = (18 * density).toInt()
            bottomMargin = (8 * density).toInt()
        }
        container.addView(header, params)
    }

    private fun addSourceRow(option: StreamingPipelineResolver.StreamOption): View {
        val row = layoutInflater.inflate(R.layout.item_source_option, container, false) as LinearLayout
        val sourceKey = PlayerReliabilitySystem.sourceKey(option.debug, option.sourceLabel)
        val health = PlayerReliabilitySystem.scoreSource(
            option.sourceLabel,
            option.displayTitle,
            option.debug,
            PlayerReliabilitySystem.storedPenalty(this, sourceKey)
        )
        row.findViewById<TextView>(R.id.sourcePrimary).text = "${health.tier} ${health.score}/100 • ${sourcePrimaryLine(option)}"
        row.findViewById<TextView>(R.id.sourceSecondary).text = sourceSecondaryLine(option)
        row.findViewById<TextView>(R.id.sourceExtra).text = sourceExtraLine(option) + "
Reliability: ${health.reasons.joinToString(" • ").ifBlank { "clean history" }}"
        android.util.Log.i("DebridChannels", "SOURCE_HEALTH_ROW: index=${option.index} score=${health.score} tier=${health.tier} label=${option.sourceLabel.take(48)} reasons=${health.reasons.joinToString("|")}")
        row.isFocusable = true
        row.isFocusableInTouchMode = true
        row.setOnClickListener { selectSource(option.index) }
        row.setOnFocusChangeListener { _, hasFocus ->
            row.scaleX = if (hasFocus) 1.025f else 1f
            row.scaleY = if (hasFocus) 1.025f else 1f
            if (hasFocus) {
                status.text = "Press OK to play ${option.qualityLabel.ifBlank { option.displayTitle }}"
            }
        }
        row.setOnKeyListener { v, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN && (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER || keyCode == KeyEvent.KEYCODE_BUTTON_A)) {
                v.performClick()
                true
            } else false
        }
        container.addView(row)
        return row
    }

    private fun normalizeProviderName(raw: String): String {
        val clean = raw.replace(Regex("\\s+"), " ").trim()
        val lower = clean.lowercase()
        return when {
            lower.contains("mediafusion") || lower.contains("media fusion") -> "MediaFusion"
            lower.contains("torbox") || lower.contains("tor box") -> "Torbox"
            lower.contains("cinemeta") -> "Cinemeta"
            clean.isNotBlank() -> clean
            else -> "Other"
        }
    }

    private fun providerSortRank(provider: String): Int {
        return when (provider.lowercase()) {
            "mediafusion" -> 0
            "torbox" -> 1
            "cinemeta" -> 98
            "other" -> 99
            else -> 20
        }
    }

    private fun sourcePrimaryLine(option: StreamingPipelineResolver.StreamOption): String {
        val videoFlags = mutableListOf<String>()
        if (option.qualityLabel.isNotBlank()) videoFlags += option.qualityLabel
        if (option.isDolbyVision) videoFlags += "Dolby Vision"
        val title = option.displayTitle.replace(Regex("\\s+"), " ").trim()
        return (videoFlags + listOf(title)).filter { it.isNotBlank() }.joinToString(" • ")
    }

    private fun sourceSecondaryLine(option: StreamingPipelineResolver.StreamOption): String {
        val raw = option.displayTitle.lowercase()
        val parts = mutableListOf<String>()
        if (option.sizeLabel.isNotBlank()) parts += option.sizeLabel
        if (raw.contains("bluray") || raw.contains("blu-ray")) parts += "BluRay"
        if (raw.contains("web-dl") || raw.contains("webdl")) parts += "WEB-DL"
        if (raw.contains("webrip")) parts += "WEBRip"
        if (raw.contains("hevc") || raw.contains("h265") || raw.contains("x265")) parts += "HEVC"
        if (raw.contains("h264") || raw.contains("x264") || raw.contains("avc")) parts += "H.264"
        if (raw.contains("hdr10+")) parts += "HDR10+"
        else if (raw.contains("hdr")) parts += "HDR"
        if (raw.contains("dolby digital plus") || raw.contains("dd+") || raw.contains("eac3")) parts += "Dolby Digital Plus"
        if (raw.contains("5.1")) parts += "5.1"
        if (raw.contains("7.1")) parts += "7.1"
        return parts.distinct().joinToString(" • ").ifBlank { option.sourceLabel }
    }

    private fun sourceExtraLine(option: StreamingPipelineResolver.StreamOption): String {
        val cleanTitle = option.displayTitle.replace(Regex("\\s+"), " ").replace("|", " • ").trim()
        return listOf("Source: ${option.sourceLabel}", cleanTitle).filter { it.isNotBlank() }.joinToString("\n")
    }

    private fun upgradeArtworkUrl(url: String): String {
        return BackendEndpoint.imageProxyUrl(url)
    }

    private fun selectSource(index: Int) {
        loading.visibility = View.VISIBLE
        status.text = "Resolving source…"
        android.util.Log.i("DebridChannels", "SOURCE_SELECTION_RESOLVE: selectedIndex=$index fallbackEnabled=true")
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val externalId = intent.getStringExtra(EXTRA_EXTERNAL_ID).orEmpty()
        val mediaType = intent.getStringExtra(EXTRA_MEDIA_TYPE).orEmpty()
        val addons = settingsRepository.loadStremioAddons()
        val debrid = settingsRepository.loadDebrid()
        val playback = settingsRepository.loadPlayback()
        executor.execute {
            val resolved = resolver.resolveAtIndexWithFallback(title, externalId, mediaType, addons, debrid, playback, index)
            handler.post {
                loading.visibility = View.GONE
                if (resolved == null) {
                    status.text = "Unable to resolve source"
                    Toast.makeText(this, "Unable to resolve source", Toast.LENGTH_LONG).show()
                    return@post
                }
                val option = options.firstOrNull { it.index == index } ?: options.getOrNull(index)
                val sourceKey = PlayerReliabilitySystem.sourceKey(resolved.url, resolved.sourceLabel)
                val health = PlayerReliabilitySystem.scoreSource(
                    resolved.sourceLabel,
                    option?.displayTitle.orEmpty(),
                    resolved.url,
                    PlayerReliabilitySystem.storedPenalty(this, sourceKey)
                )
                android.util.Log.i("DebridChannels", "SOURCE_HEALTH_SELECTED: key=$sourceKey score=${health.score} tier=${health.tier} selectedIndex=$index resolvedLabel=${resolved.sourceLabel.take(48)}")
                startActivity(Intent(this, PlayerActivity::class.java).apply {
                    putExtra(PlayerActivity.EXTRA_STREAM_URL, resolved.url)
                    putExtra(PlayerActivity.EXTRA_TITLE, title)
                    putExtra(PlayerActivity.EXTRA_MEDIA_TYPE, mediaType)
                    putExtra(PlayerActivity.EXTRA_EXTERNAL_ID, externalId)
                    putExtra(PlayerActivity.EXTRA_SOURCE_LABEL, resolved.sourceLabel)
                    putExtra(PlayerActivity.EXTRA_DEBUG_LABEL, resolved.debugLabel + "
Reliability: ${health.tier} ${health.score}/100 ${health.reasons.joinToString(" • ")}")
                    putExtra("source_health_key", sourceKey)
                    putExtra("source_health_score", health.score)
                    putExtra("source_health_tier", health.tier)
                    putExtra(PlayerActivity.EXTRA_ARTWORK_URL, intent.getStringExtra(EXTRA_ARTWORK_URL).orEmpty())
                    putExtra(PlayerActivity.EXTRA_LOGO_URL, intent.getStringExtra(EXTRA_LOGO_URL).orEmpty())
                    putExtra(PlayerActivity.EXTRA_POSTER_URL, intent.getStringExtra(EXTRA_POSTER_URL).orEmpty())
                    putExtra("meta_line", listOf(option?.qualityLabel.orEmpty(), if (option?.isDolbyVision == true) "Dolby Vision" else "", option?.sizeLabel.orEmpty()).filter { it.isNotBlank() }.joinToString(" • "))
                    putExtra("media_meta_line", intent.getStringExtra(EXTRA_META_LINE).orEmpty())
                    putExtra("overview", intent.getStringExtra(EXTRA_DESC).orEmpty())
                    putExtra("vod_mode", true)
                })
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_MEDIA_TYPE = "media_type"
        const val EXTRA_EXTERNAL_ID = "external_id"
        const val EXTRA_ARTWORK_URL = "artwork_url"
        const val EXTRA_BACKDROP_URL = "backdrop_url"
        const val EXTRA_LOGO_URL = "logo_url"
        const val EXTRA_POSTER_URL = "poster_url"
        const val EXTRA_META_LINE = "meta_line"
        const val EXTRA_DESC = "desc"
        const val EXTRA_ITEM_META = "item_meta"
        const val EXTRA_SERIES_EXTERNAL_ID = "series_external_id"
        const val EXTRA_SERIES_TITLE = "series_title"
    }
}
