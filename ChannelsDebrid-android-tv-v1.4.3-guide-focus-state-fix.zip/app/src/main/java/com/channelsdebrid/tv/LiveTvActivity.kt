package com.channelsdebrid.tv

import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.ui.PlayerView
import com.bumptech.glide.Glide
import com.channelsdebrid.tv.live.LiveSourceResolver
import com.channelsdebrid.tv.data.LiveGuideProgramResolver
import com.channelsdebrid.tv.playback.PlayerActivity
import com.channelsdebrid.tv.settings.SettingsRepository
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class LiveTvActivity : AppCompatActivity() {

    private lateinit var settingsRepository: SettingsRepository
    private lateinit var clockView: TextView
    private lateinit var infoLogo: TextView
    private lateinit var infoChannel: TextView
    private lateinit var infoGroup: TextView
    private lateinit var nowTime: TextView
    private lateinit var nowTitle: TextView
    private lateinit var descriptionView: TextView
    private lateinit var nextLine: TextView
    private lateinit var laterLine: TextView
    private lateinit var progressBar: View
    private lateinit var timelineRow: LinearLayout
    private lateinit var channelList: LinearLayout
    private lateinit var previewImage: ImageView
    private lateinit var heroBackground: ImageView
    private lateinit var previewFrame: FrameLayout
    private lateinit var previewPlayerView: PlayerView
    private lateinit var previewHint: TextView
    private lateinit var guideHeaderRow: LinearLayout
    private lateinit var categoryRail: LinearLayout
    private lateinit var categoryPanel: LinearLayout
    private lateinit var mainPanel: LinearLayout
    private lateinit var horizontalScroll: HorizontalScrollView
    private lateinit var verticalScroll: ScrollView
    private lateinit var loadingOverlay: View
    private lateinit var contentRoot: View
    private lateinit var loadingTitle: TextView
    private lateinit var loadingSubtitle: TextView
    private lateinit var channelStats: TextView
    private lateinit var statusTitle: TextView
    private lateinit var statusSources: TextView

    private val executor = Executors.newSingleThreadExecutor()
    private val guideProgramResolver = LiveGuideProgramResolver()
    private val categoryCache = linkedMapOf<String, List<GuideEntry>>()
    private lateinit var topSpacer: SpaceView
    private lateinit var bottomSpacer: SpaceView
    private var renderWindowStart = 0
    private var renderWindowEnd = -1
    private val renderWindowSize = 20
    private val renderWindowBuffer = 6
    private val rowHeightEstimateDp = 58
    private var currentChannels: List<GuideEntry> = emptyList()
    private var filteredChannels: List<GuideEntry> = emptyList()
    private var categories: List<CategoryFilter> = emptyList()
    private var categoryViews: List<View> = emptyList()
    private var selectedIndex = 0
    private var selectedCategoryIndex = 0
    private var activeZone = FocusZone.CATEGORY
    private var isGuideExpanded = false
    private var previewArmedIndex = -1
    private var previewPlayer: ExoPlayer? = null
    private var previewUrl: String = ""
    private val previewHandler = Handler(Looper.getMainLooper())
    private var previewRunnable: Runnable? = null
    private var is4kUiEnabled = true
    private var liveStatusChecksEnabled = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_live_tv)
        settingsRepository = SettingsRepository(this)

        clockView = findViewById(R.id.liveTvClock)
        infoLogo = findViewById(R.id.liveTvInfoLogo)
        infoChannel = findViewById(R.id.liveTvInfoChannel)
        infoGroup = findViewById(R.id.liveTvInfoGroup)
        nowTime = findViewById(R.id.liveTvNowTime)
        nowTitle = findViewById(R.id.liveTvNowTitle)
        descriptionView = findViewById(R.id.liveTvDescription)
        nextLine = findViewById(R.id.liveTvNextLine)
        laterLine = findViewById(R.id.liveTvLaterLine)
        progressBar = findViewById(R.id.liveTvProgressBar)
        timelineRow = findViewById(R.id.liveTvTimeline)
        channelList = findViewById(R.id.liveTvChannelList)
        previewImage = findViewById(R.id.liveTvPreviewImage)
        heroBackground = findViewById(R.id.liveTvHeroBackground)
        previewFrame = findViewById(R.id.liveTvPreviewFrame)
        previewPlayerView = findViewById(R.id.liveTvPreviewPlayer)
        previewHint = findViewById(R.id.liveTvPreviewHint)
        guideHeaderRow = findViewById(R.id.liveTvGuideHeaderRow)
        categoryRail = findViewById(R.id.liveTvCategoryRail)
        categoryPanel = findViewById(R.id.liveTvCategoryPanel)
        mainPanel = findViewById(R.id.liveTvMainPanel)
        horizontalScroll = findViewById(R.id.liveTvHorizontalScroll)
        verticalScroll = findViewById(R.id.liveTvVerticalScroll)
        loadingOverlay = findViewById(R.id.liveTvLoadingOverlay)
        contentRoot = findViewById(R.id.liveTvContentRoot)
        loadingTitle = findViewById(R.id.liveTvLoadingTitle)
        loadingSubtitle = findViewById(R.id.liveTvLoadingSubtitle)
        channelStats = findViewById(R.id.liveTvChannelStats)
        statusTitle = findViewById(R.id.liveTvStatusTitle)
        statusSources = findViewById(R.id.liveTvStatusSources)
        topSpacer = SpaceView(this)
        bottomSpacer = SpaceView(this)

        previewFrame.setOnClickListener {
            if (filteredChannels.isNotEmpty() && activeZone == FocusZone.GUIDE) {
                openPlayer(selectedIndex)
            }
        }

        val playbackSettings = settingsRepository.loadPlayback()
        is4kUiEnabled = playbackSettings.ultraHdGuideUiEnabled
        liveStatusChecksEnabled = playbackSettings.liveStatusChecksEnabled

        updateClock()
        buildTimeline()
        initializePreviewPlayer()
        val hadWarmCache = renderCachedChannelsIfAvailable()
        if (!hadWarmCache) {
            showLoading(true, "Loading channels", "Pulling guide data and lineup details…")
            channelStats.text = "Scanning channel lineup…"
        } else {
            channelStats.text = "Using instant cached lineup • refreshing in background…"
        }
        statusTitle.text = "Live TV connected"
        statusSources.text = "● Checking Channels DVR   •   ● Checking HDHomeRun   •   ● Checking IPTV"
        loadChannels(showFullLoading = !hadWarmCache)
    }

    override fun onStop() {
        super.onStop()
        previewHandler.removeCallbacksAndMessages(null)
        previewPlayer?.playWhenReady = false
    }

    override fun onDestroy() {
        super.onDestroy()
        previewHandler.removeCallbacksAndMessages(null)
        executor.shutdownNow()
        previewPlayerView.player = null
        previewPlayer?.release()
        previewPlayer = null
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        if (filteredChannels.isEmpty() && categories.isEmpty()) return super.dispatchKeyEvent(event)

        return when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> {
                when (activeZone) {
                    FocusZone.CATEGORY -> moveCategory(-1)
                    FocusZone.GUIDE -> moveSelection(-1)
                }
                applyZoneState()
                true
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                when (activeZone) {
                    FocusZone.CATEGORY -> moveCategory(1)
                    FocusZone.GUIDE -> moveSelection(1)
                }
                applyZoneState()
                true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                when (activeZone) {
                    FocusZone.GUIDE -> {
                        activeZone = FocusZone.CATEGORY
                        isGuideExpanded = false
                        applyZoneState()
                        true
                    }
                    FocusZone.CATEGORY -> super.dispatchKeyEvent(event)
                }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                when (activeZone) {
                    FocusZone.CATEGORY -> {
                        activeZone = FocusZone.GUIDE
                        isGuideExpanded = true
                        applyZoneState()
                        true
                    }
                    FocusZone.GUIDE -> {
                        if (previewArmedIndex == selectedIndex && previewPlayer?.playWhenReady == true) {
                            openPlayer(selectedIndex)
                        } else {
                            armPreviewForSelection(selectedIndex)
                            Toast.makeText(this, "Preview started • press OK again for full screen", Toast.LENGTH_SHORT).show()
                        }
                        true
                    }
                }
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                when (activeZone) {
                    FocusZone.CATEGORY -> {
                        applyCategorySelection(selectedCategoryIndex)
                        activeZone = FocusZone.GUIDE
                        isGuideExpanded = true
                        applyZoneState()
                        true
                    }
                    FocusZone.GUIDE -> {
                        if (previewArmedIndex == selectedIndex && previewPlayer?.playWhenReady == true) {
                            openPlayer(selectedIndex)
                        } else {
                            armPreviewForSelection(selectedIndex)
                            Toast.makeText(this, "Preview started • press OK again for full screen", Toast.LENGTH_SHORT).show()
                        }
                        true
                    }
                }
            }
            KeyEvent.KEYCODE_BACK -> {
                when (activeZone) {
                    FocusZone.GUIDE -> {
                        activeZone = FocusZone.CATEGORY
                        isGuideExpanded = false
                        applyZoneState()
                        true
                    }
                    FocusZone.CATEGORY -> super.dispatchKeyEvent(event)
                }
            }
            else -> super.dispatchKeyEvent(event)
        }
    }

    private fun initializePreviewPlayer() {
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("ChannelsDebridTV/1.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(7000)
            .setReadTimeoutMs(10000)
        previewPlayer = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(httpFactory))
            .build().also {
                previewPlayerView.player = it
                it.volume = 1f
                it.repeatMode = androidx.media3.common.Player.REPEAT_MODE_ALL
                it.playWhenReady = false
            }
    }

    private fun updateClock() {
        val formatter = SimpleDateFormat("HH:mm", Locale.US)
        clockView.text = formatter.format(Date())
    }

    private fun loadChannels(showFullLoading: Boolean = true) {
        if (showFullLoading) {
            infoChannel.text = ""
            infoGroup.text = ""
            descriptionView.text = ""
            channelList.removeAllViews()
            categoryRail.removeAllViews()
            showLoading(true, "Loading channels", "Pulling guide data and lineup details…")
        }

        val dvr = settingsRepository.loadChannelsDvr()
        val xtream = settingsRepository.loadXtream()

        executor.execute {
            val allChannels = mutableListOf<LiveSourceResolver.ChannelItem>()
            var dvrDeviceId = dvr.deviceId
            var dvrResultMessage = "Channels DVR not configured"
            var xtreamResultMessage = if (xtream.enabled) "IPTV not configured" else "IPTV disabled"
            var hdhrResultMessage = "HDHomeRun scan pending"
            var dvrCount = 0
            var hdhrCount = 0
            var xtreamCount = 0

            if (dvr.autoDetect || dvr.baseUrl.isNotBlank()) {
                val dvrResult = LiveSourceResolver.loadDvrChannels(dvr.baseUrl, dvr.deviceId)
                dvrResultMessage = dvrResult.message
                dvrCount = dvrResult.channels.size
                allChannels += dvrResult.channels
                if (!dvrResult.deviceId.isNullOrBlank() && dvrResult.deviceId != dvr.deviceId) {
                    dvrDeviceId = dvrResult.deviceId
                    settingsRepository.saveChannelsDvr(dvr.copy(deviceId = dvrDeviceId))
                }
            }

            val hdhrResult = LiveSourceResolver.loadHdHomeRunChannels()
            hdhrResultMessage = hdhrResult.message
            hdhrCount = hdhrResult.channels.size
            allChannels += hdhrResult.channels

            if (xtream.enabled) {
                val (xtreamChannels, xtreamMessage) = when {
                    xtream.m3uUrl.isNotBlank() -> LiveSourceResolver.loadM3uChannels(xtream.m3uUrl)
                    xtream.server.isNotBlank() && xtream.username.isNotBlank() && xtream.password.isNotBlank() -> LiveSourceResolver.loadXtreamChannels(
                        xtream.server,
                        xtream.username,
                        xtream.password
                    )
                    else -> emptyList<LiveSourceResolver.ChannelItem>() to "IPTV not configured"
                }
                xtreamResultMessage = xtreamMessage
                xtreamCount = xtreamChannels.size
                allChannels += xtreamChannels
            }

            val dedupedItems = allChannels
                .distinctBy { it.source + "|" + it.name + "|" + it.url }
                .sortedWith(compareBy<LiveSourceResolver.ChannelItem>({ sourcePriority(it.source) }, { extractChannelSortNumber(it) }, { it.name.lowercase(Locale.US) }))
            saveLiveTvCache(dedupedItems)
            val entries = dedupedItems.mapIndexed { index, item -> buildGuideEntry(item, index) }

            runOnUiThread {
                currentChannels = entries
                categoryCache.clear()
                categories = buildCategories(entries)
                selectedCategoryIndex = 0
                buildCategoryRail()
                showLoading(false)
                val dvrConnected = dvrCount > 0
                val xtreamConnected = xtreamCount > 0
                val hdhrConnected = hdhrCount > 0
                val dvrBadge = if (dvrConnected) "🟢 DVR ${dvrCount}" else "⚪ DVR 0"
                val hdhrBadge = if (hdhrConnected) "🟢 HDHR ${hdhrCount}" else "⚪ HDHR 0"
                val xtreamBadge = if (xtreamConnected) "🟢 IPTV ${xtreamCount}" else if (xtream.enabled) "⚪ IPTV 0" else "⚪ IPTV off"
                statusTitle.text = if (entries.isNotEmpty()) "Live TV connected" else "Waiting for channels"
                statusSources.text = "$dvrBadge   •   $hdhrBadge   •   $xtreamBadge"
                if (entries.isEmpty()) {
                    channelStats.text = "No channels loaded yet"
                    infoChannel.text = "No channels found"
                    infoGroup.text = "Add Channels DVR or IPTV in Settings"
                    Toast.makeText(this, "No source configured. Add Channels DVR or IPTV in Settings.", Toast.LENGTH_LONG).show()
                } else {
                    applyCategorySelection(0)
                    channelStats.text = "Showing ${filteredChannels.size} of ${entries.size} channels"
                    infoGroup.text = "${entries.size} channels • ${if (dvrDeviceId.isNotBlank()) "DVR $dvrDeviceId + IPTV" else "Unified Live TV"}"
                }
            }
        }
    }


    private fun renderCachedChannelsIfAvailable(): Boolean {
        val raw = getSharedPreferences("live_tv_cache", MODE_PRIVATE).getString("channels_json", "").orEmpty()
        if (raw.isBlank()) return false
        return runCatching {
            val arr = JSONArray(raw)
            val items = mutableListOf<LiveSourceResolver.ChannelItem>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val groupsArr = obj.optJSONArray("groups") ?: JSONArray()
                val groups = mutableListOf<String>()
                for (g in 0 until groupsArr.length()) groups += groupsArr.optString(g)
                val name = obj.optString("name")
                val url = obj.optString("url")
                if (name.isBlank() || url.isBlank()) continue
                items += LiveSourceResolver.ChannelItem(
                    name = name,
                    url = url,
                    source = obj.optString("source"),
                    debug = obj.optString("debug"),
                    groups = groups,
                    number = obj.optString("number"),
                    iconUrl = obj.optString("iconUrl")
                )
            }
            if (items.isEmpty()) return false
            val entries = items.mapIndexed { index, item -> buildGuideEntry(item, index) }
            currentChannels = entries
            categoryCache.clear()
            categories = buildCategories(entries)
            selectedCategoryIndex = 0
            buildCategoryRail()
            showLoading(false)
            applyCategorySelection(0)
            statusTitle.text = "Live TV ready"
            statusSources.text = "⚡ Instant cache • refreshing sources in background"
            channelStats.text = "Showing ${filteredChannels.size} of ${entries.size} cached channels"
            true
        }.getOrDefault(false)
    }

    private fun saveLiveTvCache(items: List<LiveSourceResolver.ChannelItem>) {
        val arr = JSONArray()
        items.take(5000).forEach { channel ->
            val groups = JSONArray()
            channel.groups.forEach { groups.put(it) }
            arr.put(JSONObject()
                .put("name", channel.name)
                .put("url", channel.url)
                .put("source", channel.source)
                .put("debug", channel.debug)
                .put("groups", groups)
                .put("number", channel.number)
                .put("iconUrl", channel.iconUrl)
            )
        }
        getSharedPreferences("live_tv_cache", MODE_PRIVATE).edit()
            .putString("channels_json", arr.toString())
            .putLong("updated_at", System.currentTimeMillis())
            .apply()
    }


    private fun showLoading(visible: Boolean, title: String = "Loading channels", subtitle: String = "Pulling guide data and lineup details…") {
        loadingOverlay.visibility = if (visible) View.VISIBLE else View.GONE
        contentRoot.visibility = if (visible) View.GONE else View.VISIBLE
        loadingTitle.text = title
        loadingSubtitle.text = subtitle
    }

    private fun buildCategories(entries: List<GuideEntry>): List<CategoryFilter> {
        val defs = mutableListOf<CategoryFilter>()
        defs += CategoryFilter("All Channels") { true }
        val explicitGroups = entries
            .flatMap { it.item.groups }
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.equals("Channels DVR", true) }
            .distinct()
            .sortedBy { it.lowercase(Locale.US) }
        explicitGroups.forEach { groupName ->
            defs += CategoryFilter(groupName) { entry -> entry.item.groups.any { it.equals(groupName, true) } }
        }
        defs += CategoryFilter("Favorites") { it.tags.contains("favorites") }
        defs += CategoryFilter("DVR") { it.item.source.contains("DVR", true) }
        defs += CategoryFilter("HDHomeRun") { it.item.source.contains("HDHomeRun", true) }
        defs += CategoryFilter("IPTV") { it.item.source.contains("IPTV", true) || it.item.source.contains("Xtream", true) }
        return defs
            .distinctBy { it.name.lowercase(Locale.US) }
            .filter { filter -> entries.any(filter.matcher) }
    }

    private fun buildCategoryRail() {
        categoryRail.removeAllViews()
        categoryViews = categories.mapIndexed { index, category ->
            val count = currentChannels.count(category.matcher)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = getDrawable(R.drawable.guide_category_idle)
                setPadding(dp(14), dp(9), dp(14), dp(9))
                isClickable = true
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58))
                lp.bottomMargin = dp(8)
                layoutParams = lp
                setOnClickListener {
                    selectedCategoryIndex = index
                    applyCategorySelection(index)
                    activeZone = FocusZone.CATEGORY
                    applyZoneState()
                }
            }
            val icon = TextView(this).apply {
                tag = "icon"
                text = categoryIcon(category.name)
                gravity = Gravity.CENTER
                textSize = 15f
                setTypeface(typeface, Typeface.BOLD)
                background = getDrawable(R.drawable.guide_category_icon_idle)
                setTextColor(0xFFFFFFFF.toInt())
                layoutParams = LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginEnd = dp(14) }
            }
            val labels = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            }
            labels.addView(TextView(this).apply {
                tag = "title"
                text = category.name
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 15f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setTypeface(typeface, Typeface.BOLD)
            })
            labels.addView(TextView(this).apply {
                tag = "count"
                text = "$count channels"
                setTextColor(0xFF9BA3AF.toInt())
                textSize = 11f
                maxLines = 1
            })
            row.addView(icon)
            row.addView(labels)
            categoryRail.addView(row)
            row
        }
        styleCategories()
    }

    private fun categoryIcon(name: String): String {
        val n = name.lowercase(Locale.US)
        return when {
            n.contains("favorite") -> "★"
            n.contains("popular") -> "●"
            n.contains("movie") || n.contains("film") -> "▰"
            n.contains("news") -> "▤"
            n.contains("sport") -> "◉"
            n.contains("kid") || n.contains("family") -> "☺"
            n.contains("music") -> "♪"
            n.contains("local") -> "⌂"
            n.contains("hit") || n.contains("tv") -> "▭"
            n.contains("entertain") -> "✦"
            n.contains("crime") -> "✪"
            n.contains("reality") -> "♣"
            n.contains("dvr") -> "D"
            n.contains("hdhome") -> "H"
            n.contains("iptv") -> "I"
            else -> "□"
        }
    }

    private fun applyCategorySelection(index: Int) {
        if (categories.isEmpty()) return
        selectedCategoryIndex = index.coerceIn(0, categories.lastIndex)
        val category = categories[selectedCategoryIndex]
        filteredChannels = categoryCache.getOrPut(category.name) {
            currentChannels.filter(category.matcher).ifEmpty { currentChannels }
        }
        selectedIndex = selectedIndex.coerceIn(0, filteredChannels.lastIndex.coerceAtLeast(0))
        previewArmedIndex = -1
        rebuildGuideWindow(force = true)
        updateSelection(selectedIndex, restartPreview = false)
        channelStats.text = "Showing ${filteredChannels.size} of ${currentChannels.size} channels"
        styleCategories()
        if (filteredChannels.isEmpty()) {
            activeZone = FocusZone.CATEGORY
        }
        applyZoneState()
    }

    private fun desiredWindowStart(targetIndex: Int): Int {
        if (filteredChannels.isEmpty()) return 0
        val maxStart = (filteredChannels.size - renderWindowSize).coerceAtLeast(0)
        return (targetIndex - renderWindowBuffer).coerceIn(0, maxStart)
    }

    private fun rebuildGuideWindow(force: Boolean = false) {
        if (filteredChannels.isEmpty()) {
            channelList.removeAllViews()
            renderWindowStart = 0
            renderWindowEnd = -1
            return
        }
        val desiredStart = desiredWindowStart(selectedIndex)
        val desiredEnd = (desiredStart + renderWindowSize - 1).coerceAtMost(filteredChannels.lastIndex)
        if (!force && desiredStart == renderWindowStart && desiredEnd == renderWindowEnd) return
        renderWindowStart = desiredStart
        renderWindowEnd = desiredEnd

        channelList.removeAllViews()
        topSpacer.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(renderWindowStart * rowHeightEstimateDp)
        )
        bottomSpacer.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(((filteredChannels.size - renderWindowEnd - 1).coerceAtLeast(0)) * rowHeightEstimateDp)
        )
        channelList.addView(topSpacer)
        for (rowIndex in renderWindowStart..renderWindowEnd) {
            channelList.addView(makeGuideRow(rowIndex, filteredChannels[rowIndex]))
        }
        channelList.addView(bottomSpacer)
    }

    private fun styleCategories() {
        categoryViews.forEachIndexed { index, view ->
            val selected = index == selectedCategoryIndex
            val active = activeZone == FocusZone.CATEGORY && selected
            view.background = getDrawable(if (selected) R.drawable.guide_category_selected else R.drawable.guide_category_idle)
            view.alpha = if (selected) 1f else 0.82f
            val row = view as? LinearLayout
            val icon = findTaggedText(row, "icon")
            val title = findTaggedText(row, "title")
            val count = findTaggedText(row, "count")
            icon?.background = getDrawable(if (selected) R.drawable.guide_category_icon_selected else R.drawable.guide_category_icon_idle)
            icon?.setTextColor(if (selected) 0xFF111111.toInt() else 0xFFFFFFFF.toInt())
            title?.setTextColor(if (selected) 0xFF202124.toInt() else 0xFFFFFFFF.toInt())
            count?.setTextColor(if (selected) 0xFF5F6368.toInt() else 0xFF9BA3AF.toInt())
        }
    }

    private fun findTaggedText(root: View?, tagValue: String): TextView? {
        if (root is TextView && root.tag == tagValue) return root
        if (root is ViewGroup) {
            for (i in 0 until root.childCount) {
                val result = findTaggedText(root.getChildAt(i), tagValue)
                if (result != null) return result
            }
        }
        return null
    }

    private fun buildTimeline() {
        timelineRow.removeAllViews()
        val cal = Calendar.getInstance().apply {
            set(Calendar.MINUTE, if (get(Calendar.MINUTE) < 30) 0 else 30)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val formatter = SimpleDateFormat("h:mm a", Locale.US)
        addSpacer(timelineRow, 98)
        timelineRow.addView(TextView(this).apply {
            text = "ON NOW"
            setTextColor(0xFFC2C7D0.toInt())
            textSize = 10f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        repeat(5) { idx ->
            val label = if (idx == 0) SimpleDateFormat("h:mm a", Locale.US).format(Date()) else formatter.format(cal.time)
            timelineRow.addView(TextView(this).apply {
                text = label
                setTextColor(if (idx == 0) 0xFFFF4457.toInt() else 0xFFA9B1BD.toInt())
                textSize = 11f
                gravity = Gravity.CENTER
                setTypeface(typeface, if (idx == 0) Typeface.BOLD else Typeface.NORMAL)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            cal.add(Calendar.MINUTE, 30)
        }
    }

    private fun makeGuideRow(index: Int, entry: GuideEntry): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = getDrawable(R.drawable.guide_row_bg)
            isClickable = true
            setPadding(dp(8), dp(6), dp(8), dp(6))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(8)
            layoutParams = lp
            setOnClickListener {
                selectedIndex = index
                updateSelection(index, restartPreview = true)
                activeZone = FocusZone.GUIDE
                applyZoneState()
            }
        }

        val logoContainer = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(72), dp(48))
            background = getDrawable(R.drawable.guide_logo_tile)
        }

        val logoImage = ImageView(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

        val logoBox = TextView(this).apply {
            text = entry.logoText
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 15f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        if (entry.item.iconUrl.isNotBlank()) {
            logoContainer.addView(logoImage)
            Glide.with(this)
                .load(entry.item.iconUrl)
                .into(logoImage)
        } else {
            logoContainer.addView(logoBox)
        }

        val star = TextView(this).apply {
            text = if (entry.tags.contains("favorites")) "★" else ""
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 11f
            gravity = Gravity.BOTTOM or Gravity.END
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        logoContainer.addView(star)
        val logoLp = logoContainer.layoutParams as LinearLayout.LayoutParams
        logoLp.marginEnd = dp(8)
        logoContainer.layoutParams = logoLp
        row.addView(logoContainer)

        entry.programs.forEachIndexed { programIndex, program ->
            row.addView(makeProgramCard(program, programIndex == 0))
        }
        row.tag = index
        return row
    }

    private fun buildSourceLabel(entry: GuideEntry): String {
        val base = when {
            entry.item.source.contains("HDHomeRun", ignoreCase = true) -> "LIVE • HDHR"
            entry.item.source.contains("DVR", ignoreCase = true) -> "LIVE • DVR"
            else -> "LIVE • IPTV"
        }
        val group = entry.item.groups.firstOrNull { !it.equals("IPTV", true) && !it.equals("Channels DVR", true) && !it.equals("HDHomeRun", true) }
        val withGroup = if (group.isNullOrBlank()) base else "$base • $group"
        return if (entry.tags.contains("hd")) "$withGroup • HD" else withGroup
    }

    private fun makeProgramCard(program: ProgramBlock, isNow: Boolean): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = getDrawable(R.drawable.guide_program_card)
            tag = if (isNow) "program_now" else "program_later"
            setPadding(dp(0), dp(0), dp(10), dp(0))
            val lp = LinearLayout.LayoutParams(0, dp(54), program.widthDp.coerceAtLeast(110).toFloat())
            lp.marginEnd = dp(4)
            layoutParams = lp
        }
        if (isNow) {
            card.addView(View(this).apply {
                background = getDrawable(R.drawable.guide_now_line)
                layoutParams = LinearLayout.LayoutParams(dp(2), ViewGroup.LayoutParams.MATCH_PARENT).apply {
                    rightMargin = dp(12)
                }
            })
        } else {
            card.addView(SpaceView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(2), ViewGroup.LayoutParams.MATCH_PARENT).apply {
                    rightMargin = dp(12)
                }
            })
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        val time = TextView(this).apply {
            text = program.startLabel
            setTextColor(0xFFB9C0C9.toInt())
            textSize = 10f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val title = TextView(this).apply {
            text = program.title
            setTextColor(0xFFE7EAEE.toInt())
            textSize = 13f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        content.addView(time)
        content.addView(title)
        card.addView(content)
        return card
    }

    private fun moveSelection(delta: Int) {
        if (filteredChannels.isEmpty()) return
        selectedIndex = (selectedIndex + delta).coerceIn(0, filteredChannels.lastIndex)
        rebuildGuideWindow(force = false)
        updateSelection(selectedIndex, restartPreview = false)
    }

    private fun moveCategory(delta: Int) {
        if (categories.isEmpty()) return
        selectedCategoryIndex = (selectedCategoryIndex + delta).coerceIn(0, categories.lastIndex)
        applyCategorySelection(selectedCategoryIndex)
        activeZone = FocusZone.CATEGORY
        applyZoneState()
    }

    private fun updateSelection(index: Int, restartPreview: Boolean) {
        if (filteredChannels.isEmpty()) return
        selectedIndex = index.coerceIn(0, filteredChannels.lastIndex)
        val selected = filteredChannels[selectedIndex]
        val channelPrograms = selected.programs

        infoLogo.text = selected.logoText
        infoChannel.text = selected.item.name
        val categoryName = categories.getOrNull(selectedCategoryIndex)?.name ?: "All Channels"
        infoGroup.text = categoryName
        nowTime.text = "Today, ${channelPrograms[0].startLabel} - ${channelPrograms[0].endLabel}"
        nowTitle.text = channelPrograms[0].title
        if (selected.item.iconUrl.isNotBlank()) {
            Glide.with(this).load(selected.item.iconUrl).centerCrop().into(heroBackground)
            Glide.with(this).load(selected.item.iconUrl).centerCrop().into(previewImage)
        } else {
            heroBackground.setImageResource(selected.previewRes)
            previewImage.setImageResource(selected.previewRes)
        }
        if (previewArmedIndex != selectedIndex) {
            previewPlayer?.playWhenReady = false
            previewFrame.visibility = View.GONE
            previewImage.alpha = 0.30f
            previewHint.visibility = View.VISIBLE
            previewHint.text = "Press OK to preview • OK again for full screen"
        }

        for (i in 0 until channelList.childCount) {
            val child = channelList.getChildAt(i) as? LinearLayout ?: continue
            val rowTag = child.tag as? Int ?: continue
            val isSelected = rowTag == selectedIndex
            styleRow(child, isSelected, activeZone == FocusZone.GUIDE && isSelected)
        }
        scrollToSelection(selectedIndex)
    }

    private fun armPreviewForSelection(index: Int) {
        val entry = filteredChannels.getOrNull(index) ?: return
        previewArmedIndex = index
        previewFrame.visibility = View.VISIBLE
        schedulePreview(entry.item.url, force = true)
    }

    private fun schedulePreview(url: String, force: Boolean = false) {
        if (url.isBlank()) return
        previewRunnable?.let { previewHandler.removeCallbacks(it) }
        val targetUrl = url
        previewRunnable = Runnable {
            playPreviewNow(targetUrl, force)
        }
        previewHandler.postDelayed(previewRunnable!!, if (force) 80L else 420L)
    }

    private fun playPreviewNow(url: String, force: Boolean = false) {
        if (url.isBlank()) return
        if (!force && url == previewUrl) return
        previewUrl = url
        previewImage.alpha = 0.25f
        val mediaItemBuilder = MediaItem.Builder().setUri(Uri.parse(url))
        if (looksLikeTsStream(url)) {
            mediaItemBuilder.setMimeType(MimeTypes.VIDEO_MP2T)
        }
        try {
            previewPlayer?.apply {
                stop()
                clearMediaItems()
                setMediaItem(mediaItemBuilder.build())
                prepare()
                playWhenReady = force && activeZone == FocusZone.GUIDE && previewArmedIndex == selectedIndex
                previewHint.visibility = View.GONE
            }
        } catch (_: Exception) {
            previewImage.alpha = 1f
        }
    }

    private fun applyZoneState() {
        styleCategories()
        for (i in 0 until channelList.childCount) {
            val child = channelList.getChildAt(i) as? LinearLayout ?: continue
            val rowTag = child.tag as? Int ?: continue
            val isSelected = rowTag == selectedIndex
            styleRow(child, isSelected, activeZone == FocusZone.GUIDE && isSelected)
        }
        val guideVisible = true
        isGuideExpanded = activeZone == FocusZone.GUIDE
        if (guideVisible) rebuildGuideWindow(force = false)
        guideHeaderRow.visibility = View.VISIBLE
        timelineRow.visibility = View.VISIBLE
        horizontalScroll.visibility = View.VISIBLE
        previewFrame.foreground = null
        if (previewArmedIndex == selectedIndex && previewPlayer?.playWhenReady == true) {
            previewFrame.visibility = View.VISIBLE
            previewHint.visibility = View.GONE
        } else {
            previewFrame.visibility = View.GONE
            previewHint.visibility = View.VISIBLE
            previewHint.text = "Press OK to preview • OK again for full screen"
        }
        categoryRail.alpha = 1f
        updateGuideExpansionState()
        previewPlayer?.playWhenReady = activeZone == FocusZone.GUIDE && previewArmedIndex == selectedIndex
    }

    private fun updateGuideExpansionState() {
        categoryPanel.visibility = if (isGuideExpanded) View.GONE else View.VISIBLE
        val layoutParams = mainPanel.layoutParams as LinearLayout.LayoutParams
        layoutParams.marginStart = if (isGuideExpanded) 0 else dp(16)
        mainPanel.layoutParams = layoutParams
        guideHeaderRow.alpha = 1f
        timelineRow.alpha = 1f
        horizontalScroll.alpha = 1f
    }

    private fun scrollToSelection(index: Int) {
        verticalScroll.post {
            val target = (dp(index * rowHeightEstimateDp) - dp(64)).coerceAtLeast(0)
            verticalScroll.scrollTo(0, target)
        }
    }

    private fun styleRow(row: LinearLayout, selected: Boolean, active: Boolean) {
        row.background = getDrawable(R.drawable.guide_row_bg)
        row.isSelected = false
        row.isActivated = false
        row.scaleX = 1f
        row.scaleY = 1f
        row.alpha = when {
            active -> 1f
            selected -> 0.97f
            else -> 0.90f
        }

        for (i in 1 until row.childCount) {
            val child = row.getChildAt(i) as? LinearLayout ?: continue
            styleProgramCard(child, focused = active && i == 1)
        }
    }

    private fun styleProgramCard(card: LinearLayout, focused: Boolean) {
        card.background = getDrawable(if (focused) R.drawable.guide_program_card_selected else R.drawable.guide_program_card)
        card.isSelected = false
        card.isActivated = false
        setProgramTextColor(card, if (focused) 0xFF202124.toInt() else 0xFFE7EAEE.toInt())
    }

    private fun setProgramTextColor(view: View, color: Int) {
        if (view is TextView) {
            view.setTextColor(color)
            return
        }
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                setProgramTextColor(view.getChildAt(i), color)
            }
        }
    }

    private fun openPlayer(index: Int) {
        val entry = filteredChannels.getOrNull(index) ?: return
        if (entry.item.url.isBlank()) {
            Toast.makeText(this, "This channel has no playable stream yet.", Toast.LENGTH_SHORT).show()
            return
        }
        previewHandler.removeCallbacksAndMessages(null)
        previewPlayer?.playWhenReady = false

        val windowStart = (index - 40).coerceAtLeast(0)
        val windowEnd = (index + 40).coerceAtMost(filteredChannels.lastIndex)
        val playbackWindow = filteredChannels.subList(windowStart, windowEnd + 1)
        val playbackIndex = (index - windowStart).coerceAtLeast(0)

        startActivity(
            Intent(this, PlayerActivity::class.java)
                .putExtra(PlayerActivity.EXTRA_STREAM_URL, entry.item.url)
                .putExtra(PlayerActivity.EXTRA_TITLE, entry.item.name)
                .putExtra(PlayerActivity.EXTRA_SOURCE_LABEL, entry.item.source)
                .putExtra(PlayerActivity.EXTRA_DEBUG_LABEL, entry.item.debug)
                .putExtra(PlayerActivity.EXTRA_CHANNEL_INDEX, playbackIndex)
                .putExtra(PlayerActivity.EXTRA_CHANNELS_JSON, serializeChannels(playbackWindow.map { it.item }))
        )
    }

    private fun serializeChannels(channels: List<LiveSourceResolver.ChannelItem>): String {
        val arr = JSONArray()
        channels.forEach { channel ->
            arr.put(
                JSONObject()
                    .put("name", channel.name)
                    .put("url", channel.url)
                    .put("source", channel.source)
                    .put("debug", channel.debug)
                    .put("iconUrl", channel.iconUrl)
            )
        }
        return arr.toString()
    }

    private fun buildGuideEntry(item: LiveSourceResolver.ChannelItem, index: Int): GuideEntry {
        val seed = item.name.uppercase(Locale.US)
        val tags = mutableSetOf<String>()
        when {
            seed.contains("CNN") || seed.contains("FOX") || seed.contains("MSNBC") || seed.contains("CSPAN") || seed.contains("HLN") -> tags += "news"
            seed.contains("ESPN") || seed.contains("FS") || seed.contains("NFL") || seed.contains("NBA") || seed.contains("GOLF") || seed.contains("CBS") -> tags += "sports"
            seed.contains("AMC") || seed.contains("TNT") || seed.contains("LIFETIME") || seed.contains("TRU") || seed.contains("HBO") || seed.contains("STARZ") -> tags += "movies"
            seed.contains("DISNEY") || seed.contains("NICK") || seed.contains("CARTOON") -> tags += "kids"
            else -> tags += "general"
        }
        if (tags.any { it == "news" || it == "sports" || it == "movies" } || index % 7 == 0) tags += "favorites"
        if (seed.contains("HD")) tags += "hd"
        when {
            item.source.contains("HDHomeRun", true) -> tags += "hdhr"
            item.source.contains("DVR", true) -> tags += "dvr"
            else -> tags += "iptv"
        }
        item.groups.forEach { group ->
            val normalized = group.lowercase(Locale.US)
            when {
                normalized.contains("news") -> tags += "news"
                normalized.contains("sport") -> tags += "sports"
                normalized.contains("movie") || normalized.contains("film") -> tags += "movies"
                normalized.contains("kids") || normalized.contains("family") -> tags += "kids"
            }
        }

        val descriptor = when {
            tags.contains("news") -> "Live news, breaking updates, and current coverage in the unified ARVIO-style guide."
            tags.contains("movies") -> "Movie and event blocks with polished premium-channel presentation."
            tags.contains("sports") -> "Live sports and studio coverage with upcoming game windows."
            tags.contains("kids") -> "Family and kids programming with lighter schedule blocks."
            else -> "Current episode and upcoming schedule blocks shown in the live guide with full now/next/later details."
        }
        val resolvedPrograms = guideProgramResolver.programsFor(item.name, item.number, tvgIdFrom(item))
        val programs = if (resolvedPrograms.isNotEmpty()) {
            resolvedPrograms.map { ProgramBlock(it.title, it.start, it.end, it.widthDp) }
        } else {
            noInformationPrograms()
        }
        val logoText = item.name
            .replace("Channels DVR", "")
            .trim()
            .split(" ", "-", "_")
            .filter { it.isNotBlank() }
            .take(2)
            .joinToString("") { it.take(1).uppercase(Locale.US) }
            .ifBlank { "TV" }
            .take(4)
        val previewPool = listOf(
            R.drawable.bg_wonka,
            R.drawable.bg_dune,
            R.drawable.bg_fallout,
            R.drawable.bg_shogun,
            R.drawable.bg_civilwar,
            R.drawable.bg_halo,
            R.drawable.bg_batman,
            R.drawable.bg_mayor
        )
        return GuideEntry(item, logoText, descriptor, programs, previewPool[index % previewPool.size], tags)
    }

    private fun tvgIdFrom(item: LiveSourceResolver.ChannelItem): String {
        val candidates = listOf(item.debug, item.groups.joinToString(" "), item.name)
        val regexes = listOf(Regex("tvg-id=\"([^\"]+)\""), Regex("tvgId=([^ •]+)"), Regex("guide=([^ •]+)"))
        for (text in candidates) {
            for (regex in regexes) regex.find(text)?.groupValues?.getOrNull(1)?.let { return it }
        }
        return ""
    }

    private fun noInformationPrograms(): List<ProgramBlock> = listOf(
        ProgramBlock("No information", "Now", "Next", 170),
        ProgramBlock("No information", "Next", "Later", 170),
        ProgramBlock("No information", "Later", "", 170)
    )

    private fun syntheticProgramsFor(channelName: String, index: Int): List<ProgramBlock> {
        val titlePool = when {
            channelName.contains("TRU", ignoreCase = true) -> listOf("Hoosiers (1986)", "NHL on TNT Face Off", "NHL Hockey", "Postgame Live", "Inside the Arena")
            channelName.contains("AMC", ignoreCase = true) -> listOf("The Martian (2015)", "National Treasure (2004)", "Movie Bonus Round", "Late Night Rewind", "Behind the Scenes")
            channelName.contains("LIFETIME", ignoreCase = true) -> listOf("Toni Braxton's Breathe Again", "Mary J. Blige Presents Be Happy", "The Beach House Murders", "Movie Extra", "Tonight on Lifetime")
            channelName.contains("CNN", ignoreCase = true) -> listOf("CNN News Central", "Inside Politics", "The Lead With Jake Tapper", "The Situation Room", "Newsnight")
            channelName.contains("CSPAN", ignoreCase = true) -> listOf("Washington Journal", "Public Affairs Event", "Floor Debate Replay", "Committee Hearing", "Capitol Review")
            channelName.contains("A&E", ignoreCase = true) || channelName.contains("AETV", ignoreCase = true) -> listOf("Live PD: Police Patrol", "Live PD: Police Patrol", "Court Cam", "Booked: First Day In", "Nightwatch")
            channelName.contains("HLN", ignoreCase = true) -> listOf("Morning Express", "Weekend Express", "Forensic Files", "Weekend Express", "Forensic Files II")
            else -> listOf("${channelName} Live", "${channelName} Spotlight", "${channelName} After Hours", "${channelName} Tonight", "${channelName} Encore")
        }
        val cal = Calendar.getInstance().apply {
            set(Calendar.MINUTE, if (get(Calendar.MINUTE) < 30) 0 else 30)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val formatter = SimpleDateFormat("h:mm a", Locale.US)
        val durations = listOf(60, 30, 30, 60, 30)
        val widths = listOf(170, 120, 120, 170, 120)
        val blocks = mutableListOf<ProgramBlock>()
        for (i in titlePool.indices) {
            val start = cal.time
            cal.add(Calendar.MINUTE, durations[i])
            val end = cal.time
            blocks += ProgramBlock(
                titlePool[i],
                formatter.format(start),
                formatter.format(end),
                widths[i] + ((index + i) % 2) * 10
            )
        }
        return blocks
    }


    private fun sourcePriority(source: String): Int {
        return when {
            source.contains("HDHomeRun", true) -> 0
            source.contains("DVR", true) -> 1
            else -> 2
        }
    }

    private fun extractChannelSortNumber(item: LiveSourceResolver.ChannelItem): Int {
        val debugMatch = Regex("""(?:guide|playKey|number|ch)=([0-9]+(?:\.[0-9]+)?)""").find(item.debug)
        val textMatch = item.number.takeIf { it.isNotBlank() }
            ?: debugMatch?.groupValues?.getOrNull(1)
            ?: Regex("""\b([0-9]{1,4}(?:\.[0-9]+)?)\b""").find(item.name)?.groupValues?.getOrNull(1)
        return textMatch?.toDoubleOrNull()?.times(10)?.toInt() ?: Int.MAX_VALUE
    }

    private fun addSpacer(parent: LinearLayout, widthDp: Int) {
        parent.addView(SpaceView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(widthDp), 1)
        })
    }

    private fun looksLikeTsStream(url: String): Boolean {
        val lower = url.lowercase(Locale.US)
        return lower.contains("format=ts") || lower.contains("/auto/v") || lower.contains("hdhomerun") || lower.endsWith(".ts") || lower.endsWith(".mpg")
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    data class GuideEntry(
        val item: LiveSourceResolver.ChannelItem,
        val logoText: String,
        val description: String,
        val programs: List<ProgramBlock>,
        val previewRes: Int,
        val tags: Set<String>
    )

    data class ProgramBlock(
        val title: String,
        val startLabel: String,
        val endLabel: String,
        val widthDp: Int
    )

    data class CategoryFilter(
        val name: String,
        val matcher: (GuideEntry) -> Boolean
    )

    enum class FocusZone { CATEGORY, GUIDE }

    private class SpaceView(context: android.content.Context) : View(context)
}
