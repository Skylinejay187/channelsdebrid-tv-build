package com.channelsdebrid.tv.data

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class LiveGuideProgramResolver(private val backendBaseUrl: String = "http://192.168.100.55:8181") {
    data class Program(val title: String, val start: String, val end: String, val widthDp: Int)

    fun programsFor(channelName: String, channelNumber: String, tvgId: String = ""): List<Program> {
        val encodedName = URLEncoder.encode(channelName, "UTF-8")
        val encodedNumber = URLEncoder.encode(channelNumber, "UTF-8")
        val encodedTvg = URLEncoder.encode(tvgId, "UTF-8")
        val urls = listOf(
            "$backendBaseUrl/api/live/guide?name=$encodedName&number=$encodedNumber&tvgId=$encodedTvg",
            "$backendBaseUrl/api/guide?name=$encodedName&number=$encodedNumber&tvgId=$encodedTvg",
            "$backendBaseUrl/live/guide?name=$encodedName&number=$encodedNumber&tvgId=$encodedTvg"
        )
        for (url in urls) {
            val parsed = fetch(url)
            if (parsed.isNotEmpty()) return parsed
        }
        return emptyList()
    }

    private fun fetch(url: String): List<Program> = try {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 1500
            readTimeout = 2200
            requestMethod = "GET"
        }
        if (conn.responseCode !in 200..299) return emptyList()
        parse(conn.inputStream.bufferedReader().use { it.readText() })
    } catch (_: Exception) { emptyList() }

    private fun parse(body: String): List<Program> {
        if (body.isBlank()) return emptyList()
        val root = if (body.trim().startsWith("[")) JSONObject().put("programs", JSONArray(body)) else JSONObject(body)
        val arr = root.optJSONArray("programs") ?: root.optJSONArray("guide") ?: root.optJSONArray("items") ?: return emptyList()
        val out = mutableListOf<Program>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val title = obj.optString("title").ifBlank { obj.optString("name") }.ifBlank { obj.optString("program") }
            if (title.isBlank()) continue
            val start = obj.optString("startLabel").ifBlank { obj.optString("start") }.takeLast(8).ifBlank { "Now" }
            val end = obj.optString("endLabel").ifBlank { obj.optString("end") }.takeLast(8).ifBlank { "Next" }
            val minutes = obj.optInt("durationMinutes", obj.optInt("duration", 30)).coerceIn(15, 180)
            out += Program(title, start, end, ((minutes / 30f) * 120).toInt().coerceIn(90, 360))
        }
        return out.take(8)
    }
}
