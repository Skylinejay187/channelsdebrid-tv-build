package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.2 ANR ARTWORK SAFE";
    public static final String LOG_MARKER = "DC_V0_2_ACTIVE";
    private BuildMarkers() {}
}
