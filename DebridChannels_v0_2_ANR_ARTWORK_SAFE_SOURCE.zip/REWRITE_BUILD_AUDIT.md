# Rewrite Build Audit — v0.2 ANR ARTWORK SAFE

Base used: `DebridChannels_v6_9_EXACT_HERO_RATING_BADGES_SOURCE.zip` / v0.1 stable baseline.

Rule enforced: clean rewrite/consolidation from the known-good base. Broken v7.1 code was not carried forward.

Fixes in this build:
- versionCode updated to `2`.
- versionName updated to `0.2`.
- visible marker updated to `DC_V0_2_ANR_ARTWORK_SAFE`.
- logcat marker updated to `DC_V0_2_ACTIVE`.
- artwork loading moved to a bounded 3-thread executor to avoid launching dozens/hundreds of image threads.
- artwork network timeouts reduced so dead Metahub/CDN images cannot stall the app.
- failed artwork URLs are remembered during the session to avoid repeated hammering.
- stale ImageView loads are ignored using per-target URL tags.
- row cards are capped per row for stability while preserving home row browsing.
- focus row requests now log `FOCUS_ROW` entries for UP/DOWN debug verification.

Preserved from v0.1/v6.9:
- hero artwork layout.
- logo-only cards.
- IMDb/TMDB hero badges.
- Pro Layout Editor current behavior.
- backend default URL: `http://192.168.100.55:8181`.
- top menu focus wrap.

Not carried forward:
- v7.1 frozen row/editor code.
- stale 6.6 markers.
- unbounded image-thread behavior.
