package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.6.3 TRAILER VIDEO RESTORE + HERO ALIGNMENT + HQ ARTWORK";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.6.3_trailer_video_restore_hero_alignment_hq_artwork_clean_base";
    private BuildMarkers() {}
}
