package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.6.8 Mixed Density Hero 1080p + Rest 4K";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.6.8_mixed_density_hero_1080_rest_4k_clean_base";
    private BuildMarkers() {}
}
