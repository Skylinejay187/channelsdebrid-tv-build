
package com.channelsdebrid.tv

import android.animation.Animator
import android.animation.AnimatorSet
import android.content.Intent
import android.graphics.Outline
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.KeyEvent
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.RequestBuilder
import com.bumptech.glide.RequestManager
import com.channelsdebrid.tv.databinding.ActivityMainBinding
import com.channelsdebrid.tv.settings.SettingsRepository
import com.channelsdebrid.tv.settings.HomeLayoutSettings
import com.channelsdebrid.tv.data.TmdbLiveLoader
import com.channelsdebrid.tv.data.StremioLiveLoader
import com.channelsdebrid.tv.data.SourceProbe
import com.channelsdebrid.tv.data.BackendHomeLoader
import com.channelsdebrid.tv.BuildConfig
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors
import java.util.concurrent.ConcurrentHashMap
import org.json.JSONObject
import org.json.JSONArray
import android.widget.Toast
import android.graphics.Color
import com.channelsdebrid.tv.playback.PlayerActivity
import com.channelsdebrid.tv.playback.PlaybackResolver
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView
import com.channelsdebrid.tv.LiveTvActivity


private class HeroBadgeSpan(
    private val backgroundColor: Int,
    private val textColor: Int,
    private val horizontalPaddingDp: Float,
    private val cornerRadiusDp: Float
) : android.text.style.ReplacementSpan() {
    private fun Float.dp(paint: android.graphics.Paint): Float = this * android.content.res.Resources.getSystem().displayMetrics.density

    override fun getSize(
        paint: android.graphics.Paint,
        text: CharSequence,
        start: Int,
        end: Int,
        fm: android.graphics.Paint.FontMetricsInt?
    ): Int {
        val padding = horizontalPaddingDp.dp(paint)
        return (paint.measureText(text, start, end) + padding * 2f).toInt()
    }

    override fun draw(
        canvas: android.graphics.Canvas,
        text: CharSequence,
        start: Int,
        end: Int,
        x: Float,
        top: Int,
        y: Int,
        bottom: Int,
        paint: android.graphics.Paint
    ) {
        val originalColor = paint.color
        val originalTypeface = paint.typeface
        val padding = horizontalPaddingDp.dp(paint)
        val radius = cornerRadiusDp.dp(paint)
        val width = paint.measureText(text, start, end) + padding * 2f
        val textHeight = paint.descent() - paint.ascent()
        val badgeTop = y + paint.ascent() - 2f.dp(paint)
        val badgeBottom = badgeTop + textHeight + 4f.dp(paint)
        val rect = android.graphics.RectF(x, badgeTop, x + width, badgeBottom)

        paint.color = backgroundColor
        paint.style = android.graphics.Paint.Style.FILL
        canvas.drawRoundRect(rect, radius, radius, paint)

        paint.color = textColor
        paint.typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        canvas.drawText(text, start, end, x + padding, y.toFloat(), paint)

        paint.color = originalColor
        paint.typeface = originalTypeface
        paint.style = android.graphics.Paint.Style.FILL
    }
}

class MainActivity : AppCompatActivity() {

    private companion object {
        private const val BACKEND_BASE_URL = "http://192.168.100.55:8181"
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var settingsRepository: SettingsRepository
    private val tmdbLiveLoader = TmdbLiveLoader()
    private val stremioLiveLoader = StremioLiveLoader()
    private val sourceProbe = SourceProbe()
    private val backendHomeLoader = BackendHomeLoader()
    private val playbackResolver = PlaybackResolver()
    private var homeLayoutSettings = HomeLayoutSettings(430, 6, 286, 160, 12, 105, 0, 0, 0, 72)
    private val liveExecutor = Executors.newSingleThreadExecutor()
    private val heroLogoExecutor = Executors.newSingleThreadExecutor()
    private val inFlightHeroBackdropRequests = java.util.Collections.newSetFromMap(java.util.concurrent.ConcurrentHashMap<String, Boolean>())
    private val inFlightHeroLogoRequests = java.util.Collections.newSetFromMap(java.util.concurrent.ConcurrentHashMap<String, Boolean>())
    private var tmdbRequestVersion = 0
    private var stremioRequestVersion = 0
    private var backendRequestVersion = 0
    private var startupFocusLocked = true
    @Volatile private var pendingHeroLogoRequestKey: String? = null
    private val resolvedHeroLogoCache = ConcurrentHashMap<String, String>()
    private val resolvedHeroBackdropCache = ConcurrentHashMap<String, String>()
    private val loadedCardArtworkRequests = ConcurrentHashMap<Int, String>()
    private val loadedCardLogoRequests = ConcurrentHashMap<Int, String>()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var pendingHeroCommitRunnable: Runnable? = null
    private var committedHeroRequestKey: String? = null
    private var pendingRevealRunnable: Runnable? = null
    private var pendingRowSettleRunnable: Runnable? = null
    private var pendingNavigationIdleRunnable: Runnable? = null
    private var pendingBottomHudHideRunnable: Runnable? = null
    private var bottomHudDismissedForSession = false
    private var lastFocusedCardId: Int = View.NO_ID
    private var lastTopMenuFocusId: Int = View.NO_ID
    private var activeRowSection: RowSection? = null
    private var rowSettleInProgress = false
    private var navigationInFlight = false
    private var motionIdleDeadlineMs: Long = 0L
    private var pendingLiveRowsRunnable: Runnable? = null
    private var pendingLiveStremioRunnable: Runnable? = null
    private var pendingHeroAutoRotateRunnable: Runnable? = null
    private var heroAutoRotatePool: List<TitleCard> = emptyList()
    private var heroAutoRotateIndex: Int = 0
    private var lastHeroInteractionMs: Long = 0L
    private var liveRowsAppliedOnce = false
    private var initialWindowFocusHandled = false
    private var lastDirectionalKeyCode: Int = KeyEvent.KEYCODE_UNKNOWN
    private var lastDirectionalKeyAtMs: Long = 0L
    private var trailerOverlay: FrameLayout? = null
    private var trailerPlayerView: PlayerView? = null
    private var trailerPreviewPlayerView: PlayerView? = null
    private var trailerPreviewPrompt: TextView? = null
    private var trailerPreviewHost: FrameLayout? = null
    private var trailerPreviewItemKey: String? = null
    private var trailerPlayer: ExoPlayer? = null
    private var pendingTrailerRunnable: Runnable? = null
    private var focusedTrailerItem: TitleCard? = null
    private var trailerVisible = false
    private var trailerRequestVersion = 0
    private val resolvedTrailerStreams = ConcurrentHashMap<String, TrailerStream>()

    private enum class RowSection {
        FIRST,
        SECOND,
        THIRD,
        FOURTH,
        FIFTH,
        SIXTH,
        SEVENTH
    }

    private data class RowSlot(
        val section: RowSection,
        val titleView: TextView,
        val subtitleView: TextView,
        val container: ViewGroup,
        val recyclerView: RecyclerView
    )

    private class CardHolder(
        val frame: FrameLayout,
        val artwork: ImageView,
        val logo: ImageView,
        val dimmer: View,
    ) : RecyclerView.ViewHolder(frame)

    private inner class RowAdapter(
        private val rowSlot: RowSlot,
        private val items: List<TitleCard>
    ) : RecyclerView.Adapter<CardHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardHolder {
            return makeCleanCardHolder(parent)
        }

        override fun onBindViewHolder(holder: CardHolder, position: Int) {
            bindCleanCard(holder, items[position], rowSlot.recyclerView, binding.contentScroll, position)
        }

        override fun getItemCount(): Int = items.size

        override fun onViewRecycled(holder: CardHolder) {
            holder.frame.animate().cancel()
            holder.frame.scaleX = 1f
            holder.frame.scaleY = 1f
            holder.frame.translationZ = 0f
            super.onViewRecycled(holder)
        }

        fun itemsForPreload(): List<TitleCard> = items
    }

    private data class HomeRowSpec(
        val title: String,
        val subtitle: String,
        val section: RowSection,
        val items: List<TitleCard>
    )

    data class TitleCard(
        val title: String,
        val meta: String,
        val desc: String,
        val badge: String,
        val brand: String,
        val footer: String,
        val progress: Float,
        val backgroundRes: Int,
        val posterUrl: String? = null,
        val backdropUrl: String? = null,
        val logoUrl: String? = null,
        val mediaType: String? = null,
        val tmdbId: Int = 0,
        val sourceKey: String? = null,
        val externalId: String? = null
    )

    private val heroTitles = listOf(
        TitleCard("SHŌGUN", "S1 E7: A Stick of Time  •  43 min left", "A premium lean-back presentation for your media center, with live TV, trending shows, smart recommendations, and instant playback.", "⚑  Instant Playback Ready", "FX", "43 min left", 0.58f, R.drawable.bg_shogun),
        TitleCard("THE BATMAN", "2h 56m  •  IMAX", "A darker detective spotlight with premium backdrop changes and clean TV-safe row alignment.", "⚑  Direct Play Ready", "PLEX", "IMAX", 0.42f, R.drawable.bg_batman),
        TitleCard("FALLOUT", "49 min left  •  Prime", "Post-apocalyptic action with large-format hero art and poster rows that stay locked in place.", "⚑  Synced to Library", "prime", "49 min left", 0.51f, R.drawable.bg_fallout),
        TitleCard("DUNE", "2h 35m  •  Max", "Expansive cinema-style focus treatment with large typography and backdrop-driven navigation.", "⚑  HDR Available", "max", "Featured", 0.46f, R.drawable.bg_dune),
        TitleCard("HALO", "Series  •  Prime", "Sci-fi recommendations rendered in the same composition language as your reference shot.", "⚑  Resume Synced", "prime", "Series", 0.33f, R.drawable.bg_halo),
        TitleCard("WONKA", "Movie  •  Max", "Bright contrast title art for spotlight and recently-added rows without breaking the layout grid.", "⚑  Trailer Ready", "max", "Movie", 0.37f, R.drawable.bg_wonka),
        TitleCard("MAYOR OF KINGSTOWN", "Series  •  Paramount+", "Grounded drama hero state with full-screen poster changes as focus moves across rows.", "⚑  Watched on Device", "P+", "Series", 0.28f, R.drawable.bg_mayor),
        TitleCard("CIVIL WAR", "Movie  •  109 min", "Poster rows line up under the hero so the screen still feels premium and intentional.", "⚑  Cache Eligible", "A24", "109 min", 0.22f, R.drawable.bg_civilwar),
        TitleCard("AVATAR", "Movie  •  Disney+", "High-contrast blockbuster art for the lower row examples and future trailer pop-up placement.", "⚑  Dolby Vision", "D+", "Featured", 0.48f, R.drawable.bg_avatar)
    )

    private fun rowSlots(): List<RowSlot> = listOf(
        RowSlot(RowSection.FIRST, binding.rowOneTitle, binding.rowOneSubtitle, binding.rowOneScroll, binding.rowOne),
        RowSlot(RowSection.SECOND, binding.rowTwoTitle, binding.rowTwoSubtitle, binding.rowTwoScroll, binding.rowTwo),
        RowSlot(RowSection.THIRD, binding.rowThreeTitle, binding.rowThreeSubtitle, binding.rowThreeScroll, binding.rowThree),
        RowSlot(RowSection.FOURTH, binding.rowFourTitle, binding.rowFourSubtitle, binding.rowFourScroll, binding.rowFour),
        RowSlot(RowSection.FIFTH, binding.rowFiveTitle, binding.rowFiveSubtitle, binding.rowFiveScroll, binding.rowFive),
        RowSlot(RowSection.SIXTH, binding.rowSixTitle, binding.rowSixSubtitle, binding.rowSixScroll, binding.rowSix),
        RowSlot(RowSection.SEVENTH, binding.rowSevenTitle, binding.rowSevenSubtitle, binding.rowSevenScroll, binding.rowSeven)
    )

    private fun rowFirstCard(rowSlot: RowSlot?): View? = rowSlot?.recyclerView?.layoutManager?.findViewByPosition(0)

    private fun firstVisibleRowSlot(): RowSlot? = rowSlots().firstOrNull { it.container.visibility == View.VISIBLE && (it.recyclerView.adapter?.itemCount ?: 0) > 0 }

    private fun lastVisibleRowSlot(): RowSlot? = rowSlots().lastOrNull { it.container.visibility == View.VISIBLE && (it.recyclerView.adapter?.itemCount ?: 0) > 0 }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun applyHomeRowBottomPositioning() {
        homeLayoutSettings = settingsRepository.loadHomeLayout()
        val cfg = homeLayoutSettings
        binding.root.post {
            val screenHeight = resources.displayMetrics.heightPixels
            val targetHeroHeight = dp(cfg.rowTopDp).coerceIn(dp(280), (screenHeight - dp(120)).coerceAtLeast(dp(280)))

            binding.heroHost.layoutParams = binding.heroHost.layoutParams.apply { height = targetHeroHeight }
            binding.heroContent.translationX = dp(cfg.heroTextLeftDp).toFloat()
            binding.heroContent.translationY = dp(cfg.heroTextTopDp).toFloat()
            binding.topNav.translationX = dp(cfg.topMenuOffsetDp).toFloat()
            binding.contentScroll.setPadding(
                dp(cfg.rowLeftDp),
                binding.contentScroll.paddingTop,
                binding.contentScroll.paddingRight,
                dp(cfg.bottomSafeDp.coerceIn(24, 160))
            )
            val rowHeight = dp((cfg.cardHeightDp + 62).coerceIn(170, 340))
            listOf(binding.rowOneScroll, binding.rowTwoScroll, binding.rowThreeScroll, binding.rowFourScroll, binding.rowFiveScroll, binding.rowSixScroll, binding.rowSevenScroll).forEach { row ->
                row.layoutParams = row.layoutParams.apply { height = rowHeight }
                row.setPadding(row.paddingLeft, dp(16), row.paddingRight, dp(14))
            }
        }
    }

    private fun isDescendantOf(view: View, parent: ViewGroup): Boolean {
        var current: View? = view
        while (current != null) {
            if (current == parent) return true
            current = current.parent as? View
        }
        return false
    }

    private fun isCurrentFocusOnContentCard(): Boolean {
        val focused = currentFocus ?: return false
        return rowSlots().any { isDescendantOf(focused, it.recyclerView) }
    }

    private fun cancelDynamicHeroRotation() {
        pendingHeroAutoRotateRunnable?.let(mainHandler::removeCallbacks)
        pendingHeroAutoRotateRunnable = null
    }

    private fun updateDynamicHeroPool(items: List<TitleCard>) {
        val unique = items.filter { it.title.isNotBlank() }
            .distinctBy { "${it.mediaType}:${it.tmdbId}:${it.externalId}:${it.title}" }
        if (unique.isEmpty()) return
        val daySeed = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())
        heroAutoRotatePool = unique.sortedBy { kotlin.math.abs((it.title + it.mediaType + daySeed).hashCode()) }.take(40)
        heroAutoRotateIndex = 0
        scheduleDynamicHeroRotation(12000L)
    }

    private fun scheduleDynamicHeroRotation(delayMs: Long = 12000L) {
        cancelDynamicHeroRotation()
        if (heroAutoRotatePool.isEmpty() || isFinishing || isDestroyed) return
        pendingHeroAutoRotateRunnable = Runnable {
            if (isCurrentFocusOnContentCard() || navigationInFlight || isMotionBusy()) {
                scheduleDynamicHeroRotation(5000L)
                return@Runnable
            }
            if (System.currentTimeMillis() - lastHeroInteractionMs < 6500L) {
                scheduleDynamicHeroRotation(6500L)
                return@Runnable
            }
            val item = heroAutoRotatePool[heroAutoRotateIndex % heroAutoRotatePool.size]
            heroAutoRotateIndex = (heroAutoRotateIndex + 1) % heroAutoRotatePool.size
            commitHero(item)
            scheduleDynamicHeroRotation(14000L)
        }.also { mainHandler.postDelayed(it, delayMs) }
    }

    private fun markHeroInteraction() {
        lastHeroInteractionMs = System.currentTimeMillis()
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        applyHomeRowBottomPositioning()
        settingsRepository = SettingsRepository(this)
        installTrailerPlayerOverlay()
        binding.contentScroll.clipToPadding = false
        binding.contentScroll.clipChildren = false
        rowSlots().forEach {
            it.container.clipToPadding = false
            it.container.clipChildren = false
            it.recyclerView.clipToPadding = false
            it.recyclerView.clipChildren = false
            it.recyclerView.itemAnimator = null
            it.recyclerView.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
            it.recyclerView.setHasFixedSize(true)
            it.recyclerView.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        }

        commitHero(heroTitles[3])
        applySettingsToHome()
        lockRowsForStartup()
        wireTopControls()
        wireRowNavigation()
        showBottomHudTemporarily()
        binding.contentScroll.post {
            binding.contentScroll.scrollTo(0, 0)
            binding.contentScroll.postDelayed({
                unlockRowsAfterStartup()
                binding.contentScroll.scrollTo(0, 0)
                requestInitialRowFocus()
            }, 90)
            binding.contentScroll.postDelayed({
                binding.contentScroll.scrollTo(0, 0)
                requestInitialRowFocus()
            }, 220)
            binding.contentScroll.postDelayed({
                binding.contentScroll.scrollTo(0, 0)
                requestInitialRowFocus()
            }, 520)
        }
    }

    override fun onPause() {
        super.onPause()
        cancelTrailerAutoplay()
        stopTrailerPreview(null)
        closeTrailerOverlay()
        cancelDynamicHeroRotation()
    }

    override fun onDestroy() {
        super.onDestroy()
        pendingHeroCommitRunnable?.let(mainHandler::removeCallbacks)
        pendingRevealRunnable?.let(mainHandler::removeCallbacks)
        pendingRowSettleRunnable?.let(mainHandler::removeCallbacks)
        pendingNavigationIdleRunnable?.let(mainHandler::removeCallbacks)
        pendingBottomHudHideRunnable?.let(mainHandler::removeCallbacks)
        pendingLiveRowsRunnable?.let(mainHandler::removeCallbacks)
        pendingLiveStremioRunnable?.let(mainHandler::removeCallbacks)
        pendingHeroAutoRotateRunnable?.let(mainHandler::removeCallbacks)
        cancelTrailerAutoplay()
        releaseTrailerPlayer()
        liveExecutor.shutdownNow()
        heroLogoExecutor.shutdownNow()
    }

    override fun onResume() {
        super.onResume()
        if (!liveRowsAppliedOnce) {
            applySettingsToHome()
        } else {
            wireRowNavigation()
        }
        scheduleDynamicHeroRotation(10000L)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || initialWindowFocusHandled) return
        initialWindowFocusHandled = true
        binding.contentScroll.post {
            unlockRowsAfterStartup()
            binding.contentScroll.scrollTo(0, 0)
            requestInitialRowFocus()
        }
        binding.contentScroll.postDelayed({
            if (!isFinishing && !isDestroyed) {
                binding.contentScroll.scrollTo(0, 0)
                requestInitialRowFocus()
            }
        }, 180L)
    }

    private fun applySettingsToHome() {
        val catalogs = settingsRepository.loadCatalogs()
        val tmdb = settingsRepository.loadTmdb()
        val stremioAddons = settingsRepository.loadStremioAddons()
        val debrid = settingsRepository.loadDebrid()
        val dvr = settingsRepository.loadChannelsDvr()
        val xtream = settingsRepository.loadXtream()
        val trailers = settingsRepository.loadTrailers()
        val playback = settingsRepository.loadPlayback()
        val storage = settingsRepository.loadStorage()
        val sourceSummary = buildInitialSourceSummary(stremioAddons.count { it.enabled }, dvr, xtream, debrid)

        val sectionOrder = RowSection.values().toList()
        val rowSpecs = mutableListOf<HomeRowSpec>()
        fun addRow(title: String, subtitle: String, itemOffset: Int) {
            if (rowSpecs.size >= sectionOrder.size) return
            rowSpecs += HomeRowSpec(
                title = title,
                subtitle = subtitle,
                section = sectionOrder[rowSpecs.size],
                items = List(24) { index -> heroTitles[(index + itemOffset) % heroTitles.size] }
            )
        }

        if (catalogs.trendingMoviesEnabled) addRow("Popular Movies", "Backend catalog • cached artwork", 3)
        if (catalogs.popularMoviesEnabled) addRow("Popular Shows", "Backend catalog • cached artwork", 5)
        if (catalogs.trendingShowsEnabled) addRow("Featured Movies", "Backend catalog • cached artwork", 6)
        if (catalogs.popularShowsEnabled) addRow("Featured Series", "Backend catalog • cached artwork", 1)
        if (catalogs.platformRowsEnabled) addRow("Streaming Catalogs", "Backend merged sources", 2)
        addRow("Catalog Picks", "Backend • primary artwork source", 7)
        if (catalogs.stremioCatalogRowsEnabled) {
            stremioAddons.take(2).forEachIndexed { index, addon ->
                val addonName = addon.name.ifBlank { if (index == 0) "Cinemeta" else "Stremio" }
                addRow(
                    "$addonName Catalog",
                    if (addon.enabled) "Manifest ready • custom rows" else "Manifest configured • currently disabled",
                    4 + index
                )
            }
        }
        while (rowSpecs.size < sectionOrder.size) {
            addRow("Featured Picks ${rowSpecs.size + 1}", "Fallback catalog • browse ready", rowSpecs.size + 2)
        }

        rowSlots().forEachIndexed { index, slot ->
            bindRowSpec(rowSpecs.getOrNull(index), slot.titleView, slot.subtitleView, slot.container, slot.recyclerView)
        }
        updateDynamicHeroPool(rowSpecs.flatMap { it.items })

        binding.infoChip.text = buildInfoChipText(trailers.enabled, playback.autoPlayBestStream, storage.movieCacheEnabled, sourceSummary)
        binding.statusBadge.visibility = View.GONE
        binding.statusBadge.text = ""
        binding.heroMeta.text = "Backend catalog • ${if (trailers.enabled) "Trailers On" else "Trailers Off"}"
        val cachedBackendRows = backendHomeLoader.loadCachedRows(this, BACKEND_BASE_URL)
        if (cachedBackendRows.isNotEmpty()) {
            applyBackendRows(cachedBackendRows, keepFocus = true)
        }

        binding.weatherPill.text = buildWeatherPill(playback.frameRateMatching)
        wireRowNavigation()
        binding.contentScroll.post {
            snapToRow(RowSection.FIRST, smooth = false)
        }
        scheduleLiveCatalogRefresh(catalogs, tmdb, stremioAddons)
        scheduleBackendHomeRefresh()
    }

    private fun scheduleBackendHomeRefresh() {
        if (BACKEND_BASE_URL.isBlank()) return
        val requestVersion = ++backendRequestVersion
        liveExecutor.execute {
            val rows = runCatching { backendHomeLoader.loadRows(this, BACKEND_BASE_URL) }.getOrDefault(emptyList())
            if (rows.isEmpty()) return@execute
            runOnUiThread {
                if (isFinishing || isDestroyed || requestVersion != backendRequestVersion) return@runOnUiThread
                applyBackendRows(rows)
            }
        }
    }


    private fun prewarmBackendTrailers(rows: List<BackendHomeLoader.BackendRow>) {
        if (BACKEND_BASE_URL.isBlank() || !settingsRepository.loadTrailers().enabled) return
        val items = rows.flatMap { it.items }.take(24)
        if (items.isEmpty()) return
        liveExecutor.execute {
            runCatching {
                val payloadItems = JSONArray()
                items.forEach { item ->
                    payloadItems.put(JSONObject().apply {
                        put("title", item.title)
                        if (item.year > 0) put("year", item.year)
                    })
                }
                val payload = JSONObject().apply {
                    put("prefer4k", settingsRepository.loadTrailers().prefer4k)
                    put("items", payloadItems)
                }.toString()
                val url = URL("${BACKEND_BASE_URL.trimEnd('/')}/trailers/prewarm")
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 2500
                    readTimeout = 3500
                    requestMethod = "POST"
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Accept", "application/json")
                }
                connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                connection.inputStream.close()
                connection.disconnect()
            }
        }
    }

    private fun applyBackendRows(rows: List<BackendHomeLoader.BackendRow>, keepFocus: Boolean = false) {
        val slots = rowSlots()
        if (rows.isEmpty()) return
        liveRowsAppliedOnce = true
        slots.forEachIndexed { index, slot ->
            val row = rows.getOrNull(index)
            if (row == null) {
                bindLiveRow(null, slot.section, slot.titleView, slot.subtitleView, slot.container, slot.recyclerView)
            } else {
                titleFromBackendRow(row, slot)
            }
        }
        val firstItem = rows.firstOrNull()?.items?.firstOrNull()
        if (firstItem != null) {
            val card = mapBackendItemToTitleCard(firstItem, 0)
            commitHero(card)
            binding.heroMeta.text = "Backend catalog • ${rows.size} row${if (rows.size == 1) "" else "s"} loaded"
        }
        scheduleInitialArtworkPreload(rows)
        updateDynamicHeroPool(rows.flatMap { it.items }.mapIndexed { index, item -> mapBackendItemToTitleCard(item, index) })
        prewarmBackendTrailers(rows)
        binding.infoChip.text = buildInfoChipText(
            trailersEnabled = settingsRepository.loadTrailers().enabled,
            autoBest = settingsRepository.loadPlayback().autoPlayBestStream,
            movieCacheEnabled = settingsRepository.loadStorage().movieCacheEnabled,
            sourceSummary = "Backend Ready  •  $BACKEND_BASE_URL"
        )
        wireRowNavigation()
        if (!keepFocus) {
            binding.contentScroll.post {
                unlockRowsAfterStartup()
                requestInitialRowFocus()
            }
        }
    }

    private fun titleFromBackendRow(row: BackendHomeLoader.BackendRow, slot: RowSlot) {
        slot.titleView.visibility = View.VISIBLE
        slot.subtitleView.visibility = View.VISIBLE
        slot.container.visibility = View.VISIBLE
        slot.titleView.text = row.title
        slot.subtitleView.text = "Backend catalog • ${row.items.size} items"
        val mapped = row.items.mapIndexed { index, item -> mapBackendItemToTitleCard(item, index) }
        slot.recyclerView.adapter = RowAdapter(slot, mapped)
        slot.recyclerView.scrollToPosition(0)
    }

    private fun mapBackendItemToTitleCard(item: BackendHomeLoader.BackendItem, index: Int): TitleCard {
        val meta = buildString {
            if (item.year > 0) append(item.year)
            if (item.genre.isNotBlank()) {
                if (isNotEmpty()) append("  •  ")
                append(item.genre)
            }
        }.ifBlank { item.type.replaceFirstChar { it.uppercase() } }
        return TitleCard(
            title = item.title,
            meta = meta,
            desc = item.overview.ifBlank { "Backend catalog item" },
            badge = "⚑  Backend Ready",
            brand = item.source.ifBlank { "Backend" },
            footer = if (item.genre.isNotBlank()) item.genre else item.type.replaceFirstChar { it.uppercase() },
            progress = (0.18f + (index % 5) * 0.12f).coerceAtMost(0.86f),
            backgroundRes = heroTitles[index % heroTitles.size].backgroundRes,
            posterUrl = item.poster ?: item.backdrop,
            backdropUrl = item.backdrop ?: item.poster,
            logoUrl = item.logo,
            mediaType = item.type,
            tmdbId = 0,
            sourceKey = "backend",
            externalId = item.imdbId ?: item.id
        )
    }



    private fun bindRowSpec(
        spec: HomeRowSpec?,
        titleView: TextView,
        subtitleView: TextView,
        container: ViewGroup,
        recyclerView: RecyclerView
    ) {
        if (spec == null) {
            titleView.visibility = View.GONE
            subtitleView.visibility = View.GONE
            container.visibility = View.GONE
            recyclerView.adapter = null
            return
        }
        titleView.visibility = View.VISIBLE
        subtitleView.visibility = View.VISIBLE
        container.visibility = View.VISIBLE
        titleView.text = spec.title
        subtitleView.text = spec.subtitle
        val slot = rowSlots().first { it.recyclerView.id == recyclerView.id }
        recyclerView.adapter = RowAdapter(slot, spec.items)
        recyclerView.scrollToPosition(0)
    }

    private fun buildInfoChipText(
        trailersEnabled: Boolean,
        autoBest: Boolean,
        movieCacheEnabled: Boolean,
        sourceSummary: String? = null
    ): String {
        val parts = mutableListOf<String>()
        parts += if (trailersEnabled) "Trailers On" else "Trailers Off"
        parts += if (autoBest) "Auto Best Stream" else "Manual Source Select"
        parts += if (movieCacheEnabled) "Movie Cache Ready" else "Cache Limited"
        sourceSummary?.takeIf { it.isNotBlank() }?.let { parts += it }
        return parts.joinToString("  •  ")
    }

    private fun buildStatusBadgeText(
        rdEnabled: Boolean,
        torBoxEnabled: Boolean,
        timeshiftEnabled: Boolean
    ): String {
        return when {
            rdEnabled -> "⚑  Real-Debrid Ready"
            torBoxEnabled -> "⚑  TorBox Ready"
            timeshiftEnabled -> "⚑  Timeshift Ready"
            else -> "⚑  Instant Playback Ready"
        }
    }

    private fun buildWeatherPill(frameRateMatchingEnabled: Boolean): String {
        return if (frameRateMatchingEnabled) {
            "1:33  •  Frame Match On"
        } else {
            "1:33  •  Frame Match Off"
        }
    }

    private fun buildInitialSourceSummary(
        enabledAddonCount: Int,
        dvr: com.channelsdebrid.tv.settings.ChannelsDvrSettings,
        xtream: com.channelsdebrid.tv.settings.XtreamSettings,
        debrid: com.channelsdebrid.tv.settings.DebridSettings
    ): String {
        val parts = mutableListOf<String>()
        if (enabledAddonCount > 0) {
            parts += if (enabledAddonCount == 1) "1 Catalog Source" else "$enabledAddonCount Catalog Sources"
        }
        if (debrid.realDebridEnabled) parts += "Real-Debrid Armed"
        if (debrid.torBoxEnabled) parts += "TorBox Armed"
        if (dvr.autoDetect || dvr.baseUrl.isNotBlank()) parts += "Channels DVR Ready"
        if (xtream.enabled) parts += "Xtream Ready"
        return parts.take(2).joinToString("  •  ")
    }



    private fun scheduleLiveCatalogRefresh(
        catalogs: com.channelsdebrid.tv.settings.CatalogSettings,
        tmdb: com.channelsdebrid.tv.settings.TmdbSettings,
        stremioAddons: List<com.channelsdebrid.tv.settings.StremioAddonSettings>
    ) {
        pendingLiveRowsRunnable?.let(mainHandler::removeCallbacks)
        pendingLiveStremioRunnable?.let(mainHandler::removeCallbacks)
        if (BACKEND_BASE_URL.isNotBlank()) return
        pendingLiveStremioRunnable = Runnable {
            maybeLoadLiveStremioRows(catalogs, stremioAddons)
        }.also { mainHandler.postDelayed(it, if (liveRowsAppliedOnce) 180L else 320L) }
        pendingLiveRowsRunnable = Runnable {
            maybeLoadLiveTmdbRows(catalogs, tmdb)
        }.also { mainHandler.postDelayed(it, if (liveRowsAppliedOnce) 1200L else 2200L) }
    }

    private fun maybeLoadLiveTmdbRows(catalogs: com.channelsdebrid.tv.settings.CatalogSettings, tmdb: com.channelsdebrid.tv.settings.TmdbSettings) {
        if (liveRowsAppliedOnce || tmdb.apiKey.isBlank()) return

        val enabledKeys = mutableListOf<String>().apply {
            if (catalogs.trendingMoviesEnabled) add("trending_movies")
            if (catalogs.popularMoviesEnabled) add("popular_movies")
            if (catalogs.trendingShowsEnabled) add("trending_shows")
            if (catalogs.popularShowsEnabled) add("popular_shows")
            if (catalogs.platformRowsEnabled) add("platform_rows")
            add("top_rated_movies")
        }.take(6)

        if (enabledKeys.isEmpty()) return
        val requestVersion = ++tmdbRequestVersion

        liveExecutor.execute {
            val rows = runCatching {
                tmdbLiveLoader.loadRows(
                    apiKey = tmdb.apiKey,
                    region = tmdb.region.ifBlank { "US" },
                    language = tmdb.language.ifBlank { "en-US" },
                    enabledKeys = enabledKeys,
                    fanartApiKey = BuildConfig.FANART_API_KEY,
                    fanartClientKey = BuildConfig.FANART_CLIENT_KEY,
                    limit = 12
                )
            }.getOrDefault(emptyList())

            if (rows.isEmpty()) return@execute
            runOnUiThread {
                if (isFinishing || requestVersion != tmdbRequestVersion) return@runOnUiThread
                applyLiveRows(rows)
            }
        }
    }

    private fun applyLiveRows(rows: List<TmdbLiveLoader.LiveRow>) {
        val slots = rowSlots()
        if (rows.isEmpty()) return
        liveRowsAppliedOnce = true

        val firstChunk = rows.take(2)
        slots.forEachIndexed { index, slot ->
            bindLiveRow(firstChunk.getOrNull(index), slot.section, slot.titleView, slot.subtitleView, slot.container, slot.recyclerView)
        }
        prefetchHeroAssets(firstChunk.flatMap { it.items }.take(4).mapIndexed { index, item -> mapLiveItemToTitleCard(item, index) })
        wireRowNavigation()

        if (lastFocusedCardId == View.NO_ID) {
            firstChunk.firstOrNull()?.items?.firstOrNull()?.let { commitHero(mapLiveItemToTitleCard(it, 0)) }
        }
        if (startupFocusLocked || currentFocus == null || isTopMenuView(currentFocus)) {
            binding.contentScroll.post {
                unlockRowsAfterStartup()
                requestInitialRowFocus()
            }
            binding.contentScroll.postDelayed({
                if (!isFinishing && !isDestroyed) requestInitialRowFocus()
            }, 140L)
        }

        val remaining = rows.drop(2)
        if (remaining.isEmpty()) {
            binding.contentScroll.post { snapToRow(RowSection.FIRST, smooth = false) }
            return
        }

        mainHandler.postDelayed({
            if (isFinishing || isDestroyed) return@postDelayed
            slots.forEachIndexed { index, slot ->
                bindLiveRow(rows.getOrNull(index), slot.section, slot.titleView, slot.subtitleView, slot.container, slot.recyclerView)
            }
            val heroPool = rows.flatMap { it.items }.mapIndexed { index, item -> mapLiveItemToTitleCard(item, index) }
            updateDynamicHeroPool(heroPool)
            prefetchHeroAssets(heroPool.take(10))
            wireRowNavigation()
        }, 180L)
    }

    private fun bindLiveRow(
        row: TmdbLiveLoader.LiveRow?,
        section: RowSection,
        titleView: TextView,
        subtitleView: TextView,
        container: ViewGroup,
        recyclerView: RecyclerView
    ) {
        if (row == null) {
            titleView.visibility = View.GONE
            subtitleView.visibility = View.GONE
            container.visibility = View.GONE
            recyclerView.adapter = null
            return
        }
        titleView.visibility = View.VISIBLE
        subtitleView.visibility = View.VISIBLE
        container.visibility = View.VISIBLE
        titleView.text = row.title
        subtitleView.text = row.subtitle
        val mappedItems = row.items.mapIndexed { index, item -> mapLiveItemToTitleCard(item, index) }
        val slot = rowSlots().first { it.section == section }
        recyclerView.adapter = RowAdapter(slot, mappedItems)
        recyclerView.scrollToPosition(0)
        prefetchHeroAssets(mappedItems.take(2))
        prefetchCardArtwork(mappedItems)
    }

    private fun mapLiveItemToTitleCard(item: TmdbLiveLoader.LiveCatalogItem, index: Int): TitleCard {
        val fallback = heroTitles[index % heroTitles.size]
        return TitleCard(
            title = item.title,
            meta = item.meta,
            desc = item.desc,
            badge = item.badge,
            brand = item.brand,
            footer = item.footer,
            progress = item.progress.coerceIn(0.12f, 0.94f),
            backgroundRes = fallback.backgroundRes,
            posterUrl = item.posterUrl,
            backdropUrl = item.backdropUrl,
            logoUrl = item.logoUrl,
            mediaType = item.mediaType,
            tmdbId = item.tmdbId,
            sourceKey = "tmdb",
            externalId = item.externalId
        )
    }
    private fun maybeLoadLiveStremioRows(
        catalogs: com.channelsdebrid.tv.settings.CatalogSettings,
        stremioAddons: List<com.channelsdebrid.tv.settings.StremioAddonSettings>
    ) {
        if (!catalogs.stremioCatalogRowsEnabled) return
        val enabledAddons = stremioAddons.filter { it.enabled && it.manifestUrl.isNotBlank() }
        if (enabledAddons.isEmpty()) return
        val requestVersion = ++stremioRequestVersion
        liveExecutor.execute {
            val rowLimit = rowSlots().size
            val rows = buildList {
                enabledAddons.forEach { addon ->
                    val loaded = runCatching {
                        stremioLiveLoader.loadRows(addon.name.ifBlank { "Stremio" }, addon.manifestUrl, 12)
                    }.getOrDefault(emptyList())
                    addAll(loaded)
                    if (size >= rowLimit) return@forEach
                }
            }.take(rowLimit)
            if (rows.isEmpty()) return@execute
            runOnUiThread {
                if (isFinishing || requestVersion != stremioRequestVersion) return@runOnUiThread
                applyStremioRows(rows)
            }
        }
    }

    private fun applyStremioRows(rows: List<com.channelsdebrid.tv.data.StremioLiveLoader.LiveRow>) {
        val slots = rowSlots()
        if (rows.isEmpty()) return
        liveRowsAppliedOnce = true

        val firstChunk = rows.take(2)
        slots.forEachIndexed { index, slot ->
            bindStremioRowInto(slot.titleView, slot.subtitleView, slot.container, slot.recyclerView, firstChunk.getOrNull(index))
        }
        prefetchHeroAssets(firstChunk.flatMap { it.items }.take(4).mapIndexed { index, item -> mapStremioItemToTitleCard(item, index) })
        wireRowNavigation()

        if (lastFocusedCardId == View.NO_ID) {
            firstChunk.firstOrNull()?.items?.firstOrNull()?.let { commitHero(mapStremioItemToTitleCard(it, 0)) }
        }
        if (startupFocusLocked || currentFocus == null || isTopMenuView(currentFocus)) {
            binding.contentScroll.post {
                unlockRowsAfterStartup()
                requestInitialRowFocus()
            }
            binding.contentScroll.postDelayed({
                if (!isFinishing && !isDestroyed) requestInitialRowFocus()
            }, 140L)
        }

        val remaining = rows.drop(2)
        if (remaining.isEmpty()) {
            binding.contentScroll.post { snapToRow(RowSection.FIRST, smooth = false) }
            return
        }

        mainHandler.postDelayed({
            if (isFinishing || isDestroyed) return@postDelayed
            slots.forEachIndexed { index, slot ->
                bindStremioRowInto(slot.titleView, slot.subtitleView, slot.container, slot.recyclerView, rows.getOrNull(index))
            }
            val heroPool = rows.flatMap { it.items }.mapIndexed { index, item -> mapStremioItemToTitleCard(item, index) }
            updateDynamicHeroPool(heroPool)
            prefetchHeroAssets(heroPool.take(10))
            wireRowNavigation()
        }, 180L)
    }

    private fun bindStremioRowInto(
        titleView: TextView,
        subtitleView: TextView,
        container: ViewGroup,
        recyclerView: RecyclerView,
        row: com.channelsdebrid.tv.data.StremioLiveLoader.LiveRow?
    ) {
        if (row == null) {
            titleView.visibility = View.GONE
            subtitleView.visibility = View.GONE
            container.visibility = View.GONE
            recyclerView.adapter = null
            return
        }
        titleView.visibility = View.VISIBLE
        subtitleView.visibility = View.VISIBLE
        container.visibility = View.VISIBLE
        titleView.text = row.title
        subtitleView.text = row.subtitle
        val mappedItems = row.items.mapIndexed { index, item -> mapStremioItemToTitleCard(item, index) }
        val slot = rowSlots().first { it.recyclerView.id == recyclerView.id }
        recyclerView.adapter = RowAdapter(slot, mappedItems)
        recyclerView.scrollToPosition(0)
        prefetchCardArtwork(mappedItems)
    }

    private fun mapStremioItemToTitleCard(item: com.channelsdebrid.tv.data.StremioLiveLoader.LiveCatalogItem, index: Int): TitleCard {
        val fallback = heroTitles[index % heroTitles.size]
        return TitleCard(
            title = item.title,
            meta = item.meta,
            desc = item.desc,
            badge = item.badge,
            brand = item.brand,
            footer = item.footer,
            progress = item.progress.coerceIn(0.12f, 0.92f),
            backgroundRes = fallback.backgroundRes,
            posterUrl = item.posterUrl,
            backdropUrl = item.backdropUrl,
            logoUrl = item.logoUrl,
            mediaType = item.mediaType,
            tmdbId = 0,
            sourceKey = "stremio",
            externalId = item.externalId
        )
    }

    private fun probeSourceStatuses(
        stremio: com.channelsdebrid.tv.settings.StremioAddonSettings,
        dvr: com.channelsdebrid.tv.settings.ChannelsDvrSettings,
        xtream: com.channelsdebrid.tv.settings.XtreamSettings,
        debrid: com.channelsdebrid.tv.settings.DebridSettings,
        trailers: com.channelsdebrid.tv.settings.TrailerSettings,
        playback: com.channelsdebrid.tv.settings.PlaybackSettings,
        storage: com.channelsdebrid.tv.settings.StorageSettings
    ) {
        liveExecutor.execute {
            val parts = mutableListOf<String>()
            settingsRepository.loadStremioAddons()
                .filter { it.enabled && it.manifestUrl.isNotBlank() }
                .take(3)
                .forEach { addon ->
                    sourceProbe.probeStremio(addon.manifestUrl)?.let { parts += it }
                }
            sourceProbe.probeChannelsDvr(dvr.autoDetect, dvr.baseUrl)?.let { parts += it }
            if (xtream.enabled) {
                sourceProbe.probeXtream(xtream.server, xtream.username, xtream.password, xtream.m3uUrl)?.let { parts += it }
            }
            val summary = parts.take(2).joinToString("  •  ")
            if (summary.isBlank()) return@execute
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                binding.infoChip.text = buildInfoChipText(trailers.enabled, playback.autoPlayBestStream, storage.movieCacheEnabled, summary)
                binding.statusBadge.visibility = View.GONE
            }
        }
    }

    private fun lockRowsForStartup() {
        startupFocusLocked = true
        rowSlots().forEach { blockRowFocus(it.recyclerView) }
    }

    private fun unlockRowsAfterStartup() {
        startupFocusLocked = false
        rowSlots().forEach { allowRowFocus(it.recyclerView) }
    }

    private fun blockRowFocus(row: RecyclerView) {
        row.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        row.isFocusable = false
        row.isFocusableInTouchMode = false
        for (i in 0 until row.childCount) {
            row.getChildAt(i).apply {
                isFocusable = false
                isFocusableInTouchMode = false
            }
        }
    }

    private fun allowRowFocus(row: RecyclerView) {
        row.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        row.isFocusable = true
        row.isFocusableInTouchMode = true
        for (i in 0 until row.childCount) {
            row.getChildAt(i).apply {
                isFocusable = true
                isFocusableInTouchMode = true
            }
        }
    }

    private fun markNavigationBusy(durationMs: Long = 170L) {
        navigationInFlight = true
        motionIdleDeadlineMs = android.os.SystemClock.uptimeMillis() + durationMs
        pendingNavigationIdleRunnable?.let(mainHandler::removeCallbacks)
        pendingNavigationIdleRunnable = Runnable {
            if (android.os.SystemClock.uptimeMillis() >= motionIdleDeadlineMs) {
                navigationInFlight = false
            } else {
                pendingNavigationIdleRunnable = this.pendingNavigationIdleRunnable
            }
        }.also { mainHandler.postDelayed(it, durationMs) }
    }

    private fun isMotionBusy(): Boolean {
        val now = android.os.SystemClock.uptimeMillis()
        val verticalBusy = kotlin.math.abs(binding.contentScroll.scrollY - (binding.contentScroll.getTag(R.id.tag_last_stable_scroll_y) as? Int ?: binding.contentScroll.scrollY)) > 2
        if (!verticalBusy) {
            binding.contentScroll.setTag(R.id.tag_last_stable_scroll_y, binding.contentScroll.scrollY)
        }
        return rowSettleInProgress || navigationInFlight || now < motionIdleDeadlineMs || binding.contentScroll.isPressed || verticalBusy
    }

        private fun openLiveTv() {
        startActivity(Intent(this, LiveTvActivity::class.java))
    }

private fun wireTopControls() {
        val focusables = listOf(
            binding.menuButton,
            binding.homeButton,
            binding.navResume,
            binding.navSmart,
            binding.navLive,
            binding.navMovies
        )
        if (lastTopMenuFocusId == View.NO_ID) {
            lastTopMenuFocusId = binding.menuButton.id
        }
        binding.navLive.isClickable = true
        binding.navLive.isFocusable = true
        binding.navLive.setOnClickListener { openLiveTv() }
        binding.navLive.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_UP &&
                (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER)
            ) {
                openLiveTv()
                true
            } else {
                false
            }
        }
        binding.menuButton.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.menuButton.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_UP &&
                (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER)
            ) {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            } else {
                false
            }
        }

        binding.homeButton.setOnClickListener {
            binding.contentScroll.smoothScrollTo(0, 0)
            binding.navSmart.requestFocus()
        }

        focusables.forEach { v ->
            v.setOnFocusChangeListener { view, hasFocus ->
                if (hasFocus) {
                    lastTopMenuFocusId = view.id
                }
                view.animate().cancel()
                view.animate()
                    .scaleX(if (hasFocus) 1.05f else 1f)
                    .scaleY(if (hasFocus) 1.05f else 1f)
                    .alpha(if (hasFocus) 1f else 0.96f)
                    .setDuration(150)
                    .start()
            }
        }
    }


    private fun preferredTopMenuFocusId(): Int {
        val candidateIds = listOf(
            binding.menuButton.id,
            binding.homeButton.id,
            binding.navResume.id,
            binding.navSmart.id,
            binding.navLive.id,
            binding.navMovies.id
        )
        return if (candidateIds.contains(lastTopMenuFocusId)) lastTopMenuFocusId else binding.menuButton.id
    }

    private fun isTopMenuView(view: View?): Boolean {
        val id = view?.id ?: return false
        return id == binding.menuButton.id ||
            id == binding.homeButton.id ||
            id == binding.navResume.id ||
            id == binding.navSmart.id ||
            id == binding.navLive.id ||
            id == binding.navMovies.id
    }

    private fun centerRowOnPosition(recyclerView: RecyclerView, position: Int, requestFocus: Boolean = false) {
        val lm = recyclerView.layoutManager as? LinearLayoutManager ?: return
        recyclerView.post {
            val roughOffset = ((recyclerView.width - recyclerView.paddingLeft - recyclerView.paddingRight) / 2f).toInt()
            lm.scrollToPositionWithOffset(position, roughOffset)
            recyclerView.post {
                val child = lm.findViewByPosition(position)
                if (child != null) {
                    val exactOffset = ((recyclerView.width - recyclerView.paddingLeft - recyclerView.paddingRight - child.width) / 2f).toInt()
                    lm.scrollToPositionWithOffset(position, exactOffset)
                    if (requestFocus) {
                        child.isFocusable = true
                        child.isFocusableInTouchMode = true
                        child.requestFocus()
                    }
                }
            }
        }
    }

    private fun requestInitialRowFocus() {
        val firstRow = firstVisibleRowSlot() ?: return
        binding.contentScroll.scrollTo(0, 0)
        activeRowSection = firstRow.section
        centerRowOnPosition(firstRow.recyclerView, 0, requestFocus = true)
        firstRow.recyclerView.post {
            val firstCard = rowFirstCard(firstRow) ?: return@post
            lastFocusedCardId = firstCard.id
        }
    }

    private fun showBottomHudTemporarily() {
        if (bottomHudDismissedForSession) return
        pendingBottomHudHideRunnable?.let(mainHandler::removeCallbacks)
        binding.weatherPill.animate().cancel()
        binding.weatherPill.alpha = 0f
        binding.weatherPill.visibility = View.GONE
        val hud = binding.infoChip
        if (hud.visibility != View.VISIBLE) {
            hud.alpha = 0f
            hud.visibility = View.VISIBLE
        }
        hud.animate().cancel()
        hud.animate().alpha(1f).setDuration(160L).start()
        pendingBottomHudHideRunnable = Runnable {
            hideBottomHud(permanentForSession = true)
        }.also { mainHandler.postDelayed(it, 8000L) }
    }

    private fun hideBottomHud(permanentForSession: Boolean = false) {
        if (permanentForSession) {
            bottomHudDismissedForSession = true
        }
        listOf(binding.weatherPill, binding.infoChip).forEach { hud ->
            hud.animate().cancel()
            hud.animate()
                .alpha(0f)
                .setDuration(180L)
                .withEndAction {
                    hud.visibility = View.GONE
                }
                .start()
        }
    }

    private fun shouldConsumeDirectionalRepeat(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode !in setOf(
                KeyEvent.KEYCODE_DPAD_LEFT,
                KeyEvent.KEYCODE_DPAD_RIGHT,
                KeyEvent.KEYCODE_DPAD_UP,
                KeyEvent.KEYCODE_DPAD_DOWN
            )
        ) return false
        if (event.action != KeyEvent.ACTION_DOWN) return false
        if (event.repeatCount > 0) return true
        val now = android.os.SystemClock.uptimeMillis()
        val tooSoon = keyCode == lastDirectionalKeyCode && (now - lastDirectionalKeyAtMs) < 110L
        if (tooSoon || rowSettleInProgress || navigationInFlight) return true
        lastDirectionalKeyCode = keyCode
        lastDirectionalKeyAtMs = now
        markNavigationBusy(if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) 110L else 140L)
        return false
    }

    private fun wireRowNavigation() {
        val visibleRows = rowSlots().filter { it.container.visibility == View.VISIBLE && (it.recyclerView.adapter?.itemCount ?: 0) > 0 }
        if (visibleRows.isEmpty()) {
            return
        }

        val firstRowFirstCardId = rowFirstCard(visibleRows.first())?.id ?: View.NO_ID
        binding.homeButton.nextFocusDownId = firstRowFirstCardId
        binding.navResume.nextFocusDownId = firstRowFirstCardId
        binding.navSmart.nextFocusDownId = firstRowFirstCardId
        binding.navLive.nextFocusDownId = firstRowFirstCardId
        binding.navMovies.nextFocusDownId = firstRowFirstCardId

        binding.menuButton.nextFocusRightId = binding.homeButton.id
        binding.homeButton.nextFocusLeftId = binding.menuButton.id
        binding.homeButton.nextFocusRightId = binding.navResume.id
        binding.navResume.nextFocusLeftId = binding.homeButton.id
        binding.navResume.nextFocusRightId = binding.navSmart.id
        binding.navSmart.nextFocusLeftId = binding.navResume.id
        binding.navSmart.nextFocusRightId = binding.navLive.id
        binding.navLive.nextFocusLeftId = binding.navSmart.id
        binding.navLive.nextFocusRightId = binding.navMovies.id
        binding.navMovies.nextFocusLeftId = binding.navLive.id
        binding.navMovies.nextFocusRightId = binding.navMovies.id

        visibleRows.forEachIndexed { rowIndex, current ->
            val prev = visibleRows.getOrNull(rowIndex - 1)
            val next = visibleRows.getOrNull(rowIndex + 1)
            val childCount = current.recyclerView.childCount
            for (childIndex in 0 until childCount) {
                val card = current.recyclerView.getChildAt(childIndex) ?: continue
                card.nextFocusUpId = rowFirstCard(prev)?.id ?: preferredTopMenuFocusId()
                card.nextFocusDownId = rowFirstCard(next)?.id ?: card.id
                card.setOnKeyListener { _, keyCode, event ->
                    if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                    if (shouldConsumeDirectionalRepeat(keyCode, event)) return@setOnKeyListener true
                    when (keyCode) {
                        KeyEvent.KEYCODE_DPAD_UP -> {
                            if (prev != null) {
                                moveFocusToRowStart(prev)
                            } else {
                                moveFocusToTopMenu()
                            }
                            true
                        }
                        KeyEvent.KEYCODE_DPAD_DOWN -> {
                            if (next != null) {
                                moveFocusToRowStart(next)
                                true
                            } else {
                                true
                            }
                        }
                        else -> false
                    }
                }
            }
        }
    }

    private fun moveFocusToTopMenu() {
        val targetId = preferredTopMenuFocusId()
        val targetView = findViewById<View>(targetId) ?: binding.navSmart
        rowSettleInProgress = false
        pendingRowSettleRunnable?.let(mainHandler::removeCallbacks)
        activeRowSection = null
        lastTopMenuFocusId = targetView.id
        markNavigationBusy(120L)
        binding.contentScroll.post {
            binding.contentScroll.scrollTo(0, 0)
            targetView.requestFocus()
        }
    }

    private fun moveFocusToRowStart(targetRow: RowSlot?) {
        if (targetRow == null) return
        rowSettleInProgress = true
        pendingRowSettleRunnable?.let(mainHandler::removeCallbacks)
        activeRowSection = targetRow.section
        snapToRow(targetRow.section, smooth = false)
        markNavigationBusy(180L)
        centerRowOnPosition(targetRow.recyclerView, 0, requestFocus = true)
        targetRow.recyclerView.post {
            val targetCard = rowFirstCard(targetRow) ?: run { rowSettleInProgress = false; return@post }
            lastFocusedCardId = targetCard.id
            pendingRowSettleRunnable?.let(mainHandler::removeCallbacks)
            pendingRowSettleRunnable = Runnable {
                rowSettleInProgress = false
            }.also { mainHandler.postDelayed(it, 140L) }
        }
    }

    private fun populateRows() {
        applySettingsToHome()
    }

    private fun makeCleanCardHolder(parent: ViewGroup): CardHolder {
        val density = resources.displayMetrics.density
        val cfg = homeLayoutSettings
        val widthPx = (cfg.cardWidthDp.coerceIn(190, 420) * density).toInt()
        val heightPx = (cfg.cardHeightDp.coerceIn(110, 260) * density).toInt()
        val radius = 28f * density
        val frame = FrameLayout(this).apply {
            id = View.generateViewId()
            layoutParams = RecyclerView.LayoutParams(widthPx, heightPx).apply {
                rightMargin = (homeLayoutSettings.cardSpacingDp.coerceIn(0, 40) * density).toInt()
            }
            isFocusable = true
            isClickable = true
            clipToOutline = true
            clipChildren = false
            clipToPadding = false
            foreground = cardChromeDrawable(false)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = radius
                setColor(0xFF0B0F18.toInt())
            }
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, radius)
                }
            }
            cameraDistance = 12000f
            // Keep the card visually raised through scale/chrome only; Android elevation created the unwanted dark under-shadow.
            elevation = 0f
            translationZ = 0f
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                outlineAmbientShadowColor = 0x00000000
                outlineSpotShadowColor = 0x00000000
            }
        }
        val artwork = ImageView(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            // Landscape card artwork should fill the full card with no black side bars.
            // We bind backdrop-first art below so center-crop stays readable and not over-zoomed.
            scaleType = ImageView.ScaleType.CENTER_CROP
            adjustViewBounds = false
            setBackgroundColor(0xFF05070D.toInt())
            alpha = 1f
        }
        val dimmer = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = radius
                orientation = GradientDrawable.Orientation.TOP_BOTTOM
                colors = intArrayOf(0x22000000, 0x66000000)
            }
            alpha = 0.22f
        }
        val logo = ImageView(this).apply {
            layoutParams = FrameLayout.LayoutParams((widthPx * 0.70f).toInt(), (heightPx * 0.34f).toInt(), Gravity.CENTER)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            visibility = View.GONE
            alpha = 0f
            elevation = 8f * density
        }
        frame.addView(artwork)
        frame.addView(dimmer)
        frame.addView(logo)
        return CardHolder(frame, artwork, logo, dimmer)
    }

    private fun cardChromeDrawable(focused: Boolean): Drawable {
        val density = resources.displayMetrics.density
        val radius = 28f * density
        fun stroke(widthDp: Float, color: Int): GradientDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius
            setColor(Color.TRANSPARENT)
            setStroke((widthDp * density).toInt().coerceAtLeast(1), color)
        }
        val outerGlow = stroke(if (focused) 2.1f else 0.8f, if (focused) 0xAA19C8FF.toInt() else 0x44FFFFFF)
        val hairline = stroke(if (focused) 0.8f else 0.55f, if (focused) 0xFF8BEAFF.toInt() else 0x66B7C0C8)
        val topSheen = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x22FFFFFF, 0x00000000)).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius
            setStroke(1, if (focused) 0x553DE5FF else 0x22FFFFFF)
        }
        return LayerDrawable(arrayOf(outerGlow, hairline, topSheen)).apply {
            setLayerInset(1, (1.2f * density).toInt(), (1.2f * density).toInt(), (1.2f * density).toInt(), (1.2f * density).toInt())
            setLayerInset(2, (1.5f * density).toInt(), (1.5f * density).toInt(), (1.5f * density).toInt(), (1.5f * density).toInt())
        }
    }

    private fun applyFocusedCardScale(holder: CardHolder) {
        holder.frame.animate().cancel()
        holder.frame.animate()
            .scaleX(homeLayoutSettings.focusedScalePercent.coerceIn(100, 118) / 100f)
            .scaleY(homeLayoutSettings.focusedScalePercent.coerceIn(100, 118) / 100f)
            .setDuration(120L)
            .start()
    }

    private fun resetFocusedCardScale(holder: CardHolder) {
        holder.frame.animate().cancel()
        holder.frame.animate()
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(100L)
            .start()
    }

    private fun bindCleanCard(holder: CardHolder, item: TitleCard, recyclerView: RecyclerView, verticalScroll: ScrollView, index: Int) {
        val frame = holder.frame
        val artwork = holder.artwork
        val logo = holder.logo
        val dimmer = holder.dimmer
        // Cards are landscape. Prefer HD backdrop/wide artwork so the card stays filled without black bars.
        // Poster remains a fallback for items that do not provide landscape artwork.
        val artUrl = preferredHeroBackdropUrl(item)?.takeIf { it.isNotBlank() } ?: preferredHeroPosterUrl(item)?.takeIf { it.isNotBlank() }
        val logoUrl = preferredHeroLogoUrl(item, resolvedHeroLogoCache[heroRequestKey(item)])
        val bindKey = "${item.sourceKey}:${item.mediaType}:${item.tmdbId}:${item.externalId}:${item.title}:$artUrl:$logoUrl"
        frame.tag = bindKey
        frame.setOnClickListener { launchPlaybackFor(item) }
        loadCleanCardArtwork(artwork, item, artUrl, bindKey)
        loadCleanCenteredLogo(logo, item, logoUrl, bindKey)
        frame.setOnFocusChangeListener { view, hasFocus ->
            pendingRevealRunnable?.let(mainHandler::removeCallbacks)
            if (hasFocus) {
                markNavigationBusy()
                markHeroInteraction()
                cancelDynamicHeroRotation()
            } else {
                markHeroInteraction()
                scheduleDynamicHeroRotation(9000L)
            }
            view.animate().cancel()
            logo.animate().cancel()
            dimmer.animate().cancel()
            val section = rowSlots().firstOrNull { it.recyclerView.id == recyclerView.id }?.section
            val verticalRowChange = hasFocus && section != null && activeRowSection != null && activeRowSection != section
            if (hasFocus && section != null) activeRowSection = section
            if (hasFocus) {
                applyFocusedCardScale(holder)
            } else {
                resetFocusedCardScale(holder)
            }
            view.rotationX = 0f
            view.rotationY = 0f
            view.foreground = cardChromeDrawable(hasFocus)
            // No platform elevation shadow under the cards. Depth is handled by scale + thin chrome.
            view.translationZ = 0f
            view.elevation = 0f
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                view.outlineAmbientShadowColor = 0x00000000
                view.outlineSpotShadowColor = 0x00000000
            }
            dimmer.animate().alpha(if (hasFocus) 0.10f else 0.24f).setDuration(120L).start()
            artwork.animate()
                .translationX(0f)
                .translationY(0f)
                .setDuration(120L)
                .start()
            logo.visibility = if (logoUrl != null) View.VISIBLE else View.GONE
            logo.animate()
                .alpha(if (hasFocus && logoUrl != null) 1f else if (logoUrl != null) 0.92f else 0f)
                .translationX(0f)
                .translationY(0f)
                .setDuration(120L)
                .start()
            artwork.setLayerType(if (hasFocus) View.LAYER_TYPE_HARDWARE else View.LAYER_TYPE_NONE, null)
            logo.setLayerType(if (hasFocus) View.LAYER_TYPE_HARDWARE else View.LAYER_TYPE_NONE, null)
            if (hasFocus) {
                lastFocusedCardId = view.id
                previewHeroForFocus(item)
                scheduleHeroCommit(item, if (startupFocusLocked) 150L else if (verticalRowChange) 210L else 110L)
                if (!startupFocusLocked) {
                    pendingRevealRunnable = Runnable {
                        if (view.isFocused && lastFocusedCardId == view.id) revealFocusedCard(recyclerView, verticalScroll, view, index, verticalRowChange)
                    }.also { mainHandler.postDelayed(it, if (verticalRowChange) 190L else 130L) }
                }
            }
        }
    }

    private fun loadCleanCardArtwork(imageView: ImageView, item: TitleCard, url: String?, bindKey: String) {
        val viewKey = System.identityHashCode(imageView)
        val requestKey = "clean-art:$bindKey"
        if (loadedCardArtworkRequests[viewKey] == requestKey) return
        loadedCardArtworkRequests[viewKey] = requestKey
        imageView.animate().cancel()
        imageView.tag = requestKey
        imageView.scaleType = ImageView.ScaleType.CENTER_CROP
        imageView.setBackgroundColor(0xFF05070D.toInt())
        if (imageView.drawable == null) imageView.setImageResource(item.backgroundRes)
        if (url.isNullOrBlank()) return
        val options = RequestOptions()
            .format(DecodeFormat.PREFER_ARGB_8888)
            .disallowHardwareConfig()
            .centerCrop()
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .skipMemoryCache(false)
            .override(1280, 720)
        imageRequest(Glide.with(this), url)
            ?.apply(options)
            ?.thumbnail(0.18f)
            ?.dontAnimate()
            ?.into(imageView)
    }

    private fun loadCleanCenteredLogo(imageView: ImageView, item: TitleCard, url: String?, bindKey: String) {
        val viewKey = System.identityHashCode(imageView)
        val requestKey = "clean-logo:$bindKey"
        if (loadedCardLogoRequests[viewKey] == requestKey) return
        loadedCardLogoRequests[viewKey] = requestKey
        imageView.animate().cancel()
        imageView.tag = requestKey
        imageView.scaleType = ImageView.ScaleType.FIT_CENTER
        if (url.isNullOrBlank()) {
            Glide.with(this).clear(imageView)
            imageView.visibility = View.GONE
            imageView.alpha = 0f
            return
        }
        imageView.visibility = View.VISIBLE
        imageView.alpha = 0.92f
        val options = RequestOptions()
            .format(DecodeFormat.PREFER_ARGB_8888)
            .disallowHardwareConfig()
            .fitCenter()
            .dontTransform()
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .skipMemoryCache(false)
            .override(620, 230)
        imageRequest(Glide.with(this), url)
            ?.apply(options)
            ?.thumbnail(0.25f)
            ?.dontAnimate()
            ?.into(imageView)
        maybeResolveCardLogoAsync(item, imageView, highQuality = false)
    }

    private fun makeCard(item: TitleCard, recyclerView: RecyclerView, verticalScroll: ScrollView, index: Int, widthDp: Int, heightDp: Int): View {
        val density = resources.displayMetrics.density
        val widthPx = (widthDp * density).toInt()
        val heightPx = (heightDp * density).toInt()
        val marginEnd = (16 * density).toInt()
        val pad = (14 * density).toInt()
        val pillRadius = 34f * density

        val frame = FrameLayout(this).apply {
            id = View.generateViewId()
            layoutParams = RecyclerView.LayoutParams(widthPx, heightPx).apply { rightMargin = marginEnd }
            isFocusable = true
            isClickable = true
            foreground = null
            background = (ContextCompat.getDrawable(this@MainActivity, item.backgroundRes)?.mutate() as? GradientDrawable)?.apply {
                cornerRadius = pillRadius
            } ?: ContextCompat.getDrawable(this@MainActivity, item.backgroundRes)
            clipToOutline = true
            clipChildren = false
            clipToPadding = false
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, pillRadius)
                }
            }
        }

        val posterBackdropImage = ImageView(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.94f
            setBackgroundColor(0xFF0B0F18.toInt())
        }
        loadCardBackdropLayerInto(posterBackdropImage, item, highQuality = false)

        val posterImage = ImageView(this).apply {
            layoutParams = FrameLayout.LayoutParams(1, 1, Gravity.CENTER)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            alpha = 0f
            visibility = View.GONE
        }

        val overlay = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            background = (ContextCompat.getDrawable(this@MainActivity, R.drawable.card_overlay)?.mutate() as? GradientDrawable)?.apply {
                cornerRadius = pillRadius
            } ?: ContextCompat.getDrawable(this@MainActivity, R.drawable.card_overlay)
            alpha = 0.40f
        }

        val focusBloom = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            background = null
            alpha = 0f
        }

        val cardLogo = ImageView(this).apply {
            layoutParams = FrameLayout.LayoutParams((widthPx * 0.66f).toInt(), (heightPx * 0.28f).toInt(), Gravity.CENTER)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            alpha = 0f
            visibility = View.GONE
            elevation = 12f * resources.displayMetrics.density
        }
        bindCardLogo(cardLogo, item, highQuality = false)
        val shouldPreferLogoOnCard = preferredHeroLogoUrl(item, null) != null || resolveHeroLogoRes(item.title) != 0

        val bottomWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
            setPadding(pad, 0, pad, pad)
            alpha = 0f
            visibility = View.GONE
        }

        val title = TextView(this).apply {
            text = item.title
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 22f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 2
            setShadowLayer(10f * density, 0f, 3f * density, 0xCC000000.toInt())
        }

        val meta = TextView(this).apply {
            text = item.meta
            setTextColor(0xFFF0E6D7.toInt())
            textSize = 12.8f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 1
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = (4 * density).toInt()
            }
        }

        val footer = TextView(this).apply {
            text = item.desc
            setTextColor(0xFFF5EFE6.toInt())
            textSize = 11.6f
            maxLines = 4
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setLineSpacing(0f, 1.08f)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = (6 * density).toInt()
            }
        }

        bottomWrap.addView(title)
        bottomWrap.addView(meta)
        bottomWrap.addView(footer)

        frame.addView(posterBackdropImage)
        frame.addView(focusBloom)
        frame.addView(overlay)
        frame.addView(cardLogo)
        frame.addView(bottomWrap)

        frame.cameraDistance = 12000f
        frame.elevation = 0f
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
            frame.outlineAmbientShadowColor = 0x00000000
            frame.outlineSpotShadowColor = 0x00000000
        }

        frame.setOnFocusChangeListener { view, hasFocus ->
            pendingRevealRunnable?.let(mainHandler::removeCallbacks)
            if (hasFocus) markNavigationBusy()
            view.animate().cancel()
            cardLogo.animate().cancel()
            bottomWrap.animate().cancel()
            overlay.animate().cancel()
            focusBloom.animate().cancel()
            val section = rowSlots().firstOrNull { it.recyclerView.id == recyclerView.id }?.section
            val verticalRowChange = hasFocus && section != null && activeRowSection != null && activeRowSection != section
            if (hasFocus && section != null) {
                activeRowSection = section
            }
            view.alpha = if (hasFocus) 1f else 0.992f
            view.translationZ = 0f
            view.scaleX = if (hasFocus) 1.022f else 1f
            view.scaleY = if (hasFocus) 1.022f else 1f
            overlay.animate().alpha(if (hasFocus) 0.14f else 0.30f).setDuration(140L).start()
            bottomWrap.alpha = 0f
            bottomWrap.visibility = View.GONE
            focusBloom.alpha = 0f
            cardLogo.visibility = if (shouldPreferLogoOnCard) View.VISIBLE else View.GONE
            cardLogo.alpha = if (shouldPreferLogoOnCard) 1f else 0f
            title.alpha = 0f
            frame.foreground = null
            glowAnimator(view, focusBloom, hasFocus)
            posterBackdropImage.setLayerType(if (hasFocus) View.LAYER_TYPE_HARDWARE else View.LAYER_TYPE_NONE, null)
            posterImage.setLayerType(if (hasFocus) View.LAYER_TYPE_HARDWARE else View.LAYER_TYPE_NONE, null)
            cardLogo.setLayerType(if (hasFocus) View.LAYER_TYPE_HARDWARE else View.LAYER_TYPE_NONE, null)
            if (hasFocus) {
                lastFocusedCardId = view.id
                if (section != null && section == lastVisibleRowSlot()?.section) {
                    // bottom-right settings button removed; keep focus within content
                }
                previewHeroForFocus(item)
                scheduleHeroCommit(item, if (startupFocusLocked) 150L else if (verticalRowChange) 210L else 110L)
                if (!startupFocusLocked) {
                    pendingRevealRunnable = Runnable {
                        if (view.isFocused && lastFocusedCardId == view.id) {
                            revealFocusedCard(recyclerView, verticalScroll, view, index, verticalRowChange)
                        }
                    }.also { mainHandler.postDelayed(it, if (verticalRowChange) 190L else 130L) }
                }
            }
        }
        frame.setOnClickListener { launchPlaybackFor(item) }
        return frame
    }



    private fun installTrailerPlayerOverlay() {
        val root = binding.root as? FrameLayout ?: return
        val density = resources.displayMetrics.density
        val overlay = FrameLayout(this).apply {
            visibility = View.GONE
            alpha = 0f
            isFocusable = true
            isClickable = true
            setBackgroundColor(0x99000000.toInt())
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        }
        val modal = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 24f * density
                setColor(0xF1121720.toInt())
                setStroke((1.2f * density).toInt().coerceAtLeast(1), 0x55FFFFFF)
            }
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, 24f * density)
                }
            }
            layoutParams = FrameLayout.LayoutParams((720 * density).toInt(), (405 * density).toInt(), Gravity.CENTER)
        }
        val playerView = PlayerView(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            setBackgroundColor(Color.BLACK)
            useController = false
            isFocusable = false
        }
        val loadingText = TextView(this).apply {
            text = "Loading trailer…"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        }
        val close = TextView(this).apply {
            text = "✕"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            isFocusable = true
            isClickable = true
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 18f * density
                setColor(0xAA000000.toInt())
            }
            setOnClickListener { closeTrailerOverlay() }
            layoutParams = FrameLayout.LayoutParams((42 * density).toInt(), (42 * density).toInt(), Gravity.TOP or Gravity.RIGHT).apply {
                topMargin = (10 * density).toInt()
                rightMargin = (10 * density).toInt()
            }
        }
        modal.addView(playerView)
        modal.addView(loadingText)
        modal.addView(close)
        overlay.addView(modal)
        overlay.setOnClickListener { }
        root.addView(overlay)
        trailerOverlay = overlay
        trailerPlayerView = playerView
        playerView.tag = loadingText
    }

    private fun scheduleTrailerAutoplay(item: TitleCard, focusedView: View) {
        // Home/card trailer previews are intentionally disabled.
        // Trailers now play only from MediaDetailsActivity to avoid card preview glitches.
        cancelTrailerAutoplay()
        focusedTrailerItem = null
    }

    private fun cancelTrailerAutoplay() {
        pendingTrailerRunnable?.let(mainHandler::removeCallbacks)
        pendingTrailerRunnable = null
    }


    private fun showFocusedCardTrailerPreview(item: TitleCard, focusedView: View) {
        val host = focusedView as? FrameLayout ?: return
        if (trailerVisible || !host.isFocused) return
        val settings = settingsRepository.loadTrailers()
        val requestId = ++trailerRequestVersion
        val cacheKey = trailerCacheKey(item)

        fun attachPreview(stream: TrailerStream?) {
            if (requestId != trailerRequestVersion || isFinishing || isDestroyed || !host.isFocused || focusedTrailerItem?.title != item.title) return
            if (stream?.playbackUrl.isNullOrBlank()) return
            stopTrailerPreview(null)
            trailerPreviewHost = host
            trailerPreviewItemKey = cacheKey
            val density = resources.displayMetrics.density
            val preview = PlayerView(this).apply {
                layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
                setBackgroundColor(Color.BLACK)
                useController = false
                isFocusable = false
                alpha = 0f
            }
            val prompt = TextView(this).apply {
                text = "Press OK to expand trailer"
                textSize = 14f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding((12 * density).toInt(), (6 * density).toInt(), (12 * density).toInt(), (6 * density).toInt())
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 16f * density
                    setColor(0xAA000000.toInt())
                    setStroke((1f * density).toInt().coerceAtLeast(1), 0x44FFFFFF)
                }
                layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                    bottomMargin = (12 * density).toInt()
                }
            }
            trailerPreviewPlayerView = preview
            trailerPreviewPrompt = prompt
            host.addView(preview)
            host.addView(prompt)
            preview.animate().alpha(1f).setDuration(220L).start()
            startTrailerStream(stream!!, preview)
        }

        resolvedTrailerStreams[cacheKey]?.let { cachedStream ->
            attachPreview(cachedStream)
            return
        }

        liveExecutor.execute {
            val stream = resolveBackendTrailerStream(item, settings.prefer4k)
            if (stream != null && stream.playbackUrl.isNotBlank()) resolvedTrailerStreams[cacheKey] = stream
            mainHandler.post { attachPreview(stream) }
        }
    }

    private fun stopTrailerPreview(item: TitleCard?) {
        if (item != null && trailerPreviewItemKey != trailerCacheKey(item)) return
        trailerPreviewPrompt?.let { prompt -> (prompt.parent as? ViewGroup)?.removeView(prompt) }
        trailerPreviewPlayerView?.let { preview ->
            preview.player = null
            (preview.parent as? ViewGroup)?.removeView(preview)
        }
        trailerPreviewPrompt = null
        trailerPreviewPlayerView = null
        trailerPreviewHost = null
        trailerPreviewItemKey = null
        if (!trailerVisible) releaseTrailerPlayer()
    }

    private fun showInAppTrailer(item: TitleCard) {
        val overlay = trailerOverlay ?: return
        val playerView = trailerPlayerView ?: return
        if (trailerVisible) return
        val settings = settingsRepository.loadTrailers()
        val requestId = ++trailerRequestVersion
        val cacheKey = trailerCacheKey(item)

        fun openTrailer(stream: TrailerStream?) {
            if (requestId != trailerRequestVersion || isFinishing || isDestroyed || focusedTrailerItem?.title != item.title) return
            if (stream?.playbackUrl.isNullOrBlank()) {
                Toast.makeText(this, "Trailer stream unavailable", Toast.LENGTH_SHORT).show()
                return
            }
            stopTrailerPreview(item)
            trailerVisible = true
            overlay.visibility = View.VISIBLE
            overlay.animate().cancel()
            overlay.alpha = 0f
            overlay.animate().alpha(1f).setDuration(180L).start()
            overlay.requestFocus()
            (playerView.tag as? TextView)?.visibility = View.VISIBLE
            startTrailerStream(stream!!, playerView)
        }

        resolvedTrailerStreams[cacheKey]?.let { cachedStream ->
            openTrailer(cachedStream)
            return
        }

        liveExecutor.execute {
            val stream = resolveBackendTrailerStream(item, settings.prefer4k)
            if (stream != null && stream.playbackUrl.isNotBlank()) resolvedTrailerStreams[cacheKey] = stream
            mainHandler.post { openTrailer(stream) }
        }
    }

    private fun startTrailerStream(stream: TrailerStream, playerView: PlayerView) {
        releaseTrailerPlayer()
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Android TV; ChannelsDebrid)")
            .setAllowCrossProtocolRedirects(true)
        val mediaSourceFactory = DefaultMediaSourceFactory(this).setDataSourceFactory(httpFactory)
        val trackSelector = DefaultTrackSelector(this).apply {
            setParameters(
                buildUponParameters()
                    .setMaxVideoSize(3840, 2160)
                    .setMinVideoSize(1920, 1080)
                    .setForceHighestSupportedBitrate(true)
            )
        }
        val exoPlayer = ExoPlayer.Builder(this)
            .setMediaSourceFactory(mediaSourceFactory)
            .setTrackSelector(trackSelector)
            .build()
        trailerPlayer = exoPlayer
        playerView.player = exoPlayer
        val mediaItemBuilder = MediaItem.Builder().setUri(stream.playbackUrl)
        if (stream.mimeType.contains("dash", ignoreCase = true) || stream.playbackUrl.contains(".mpd", ignoreCase = true)) {
            mediaItemBuilder.setMimeType(MimeTypes.APPLICATION_MPD)
        } else if (stream.mimeType.contains("hls", ignoreCase = true) || stream.playbackUrl.contains(".m3u8", ignoreCase = true)) {
            mediaItemBuilder.setMimeType(MimeTypes.APPLICATION_M3U8)
        }
        exoPlayer.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) (playerView.tag as? TextView)?.visibility = View.GONE
                if (playbackState == Player.STATE_ENDED) closeTrailerOverlay()
            }

            override fun onPlayerError(error: PlaybackException) {
                (playerView.tag as? TextView)?.visibility = View.VISIBLE
                (playerView.tag as? TextView)?.text = "Trailer playback failed"
                Toast.makeText(this@MainActivity, "Trailer playback failed", Toast.LENGTH_SHORT).show()
            }
        })
        exoPlayer.setMediaItem(mediaItemBuilder.build())
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
    }

    private fun releaseTrailerPlayer() {
        trailerPlayerView?.player = null
        trailerPreviewPlayerView?.player = null
        trailerPlayer?.release()
        trailerPlayer = null
    }

    private fun resolveBackendTrailerStream(item: TitleCard, prefer4k: Boolean): TrailerStream? {
        return runCatching {
            val title = URLEncoder.encode(item.title, "UTF-8")
            val year = Regex("(19|20)\\d{2}").find(item.meta)?.value.orEmpty()
            val url = URL(
                "$BACKEND_BASE_URL/trailers/resolve" +
                    "?title=$title" +
                    "&year=${URLEncoder.encode(year, "UTF-8")}" +
                    "&prefer4k=$prefer4k"
            )
            val connection = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 12000
                readTimeout = 25000
                requestMethod = "GET"
                setRequestProperty("Accept", "application/json")
            }
            connection.inputStream.bufferedReader().use { reader ->
                val json = JSONObject(reader.readText())
                if (!json.optBoolean("ok", false)) return null
                val trailer = json.optJSONObject("trailer") ?: return null
                TrailerStream(
                    playbackUrl = trailer.optString("playbackUrl"),
                    mimeType = trailer.optString("mimeType"),
                    videoId = trailer.optString("videoId"),
                    quality = trailer.optString("quality")
                )
            }
        }.getOrNull()
    }

    private fun closeTrailerOverlay() {
        trailerRequestVersion++
        cancelTrailerAutoplay()
        trailerVisible = false
        releaseTrailerPlayer()
        trailerOverlay?.animate()?.cancel()
        trailerOverlay?.animate()?.alpha(0f)?.setDuration(140L)?.withEndAction {
            trailerOverlay?.visibility = View.GONE
        }?.start()
    }

    private fun trailerCacheKey(item: TitleCard): String = listOf(item.title, item.meta)
        .joinToString("|")
        .lowercase()

    private fun trailerSearchQuery(item: TitleCard): String = listOf(
        item.title,
        item.meta.takeIf { it.matches(Regex(".*\\d{4}.*")) } ?: "",
        "official trailer 4k"
    ).filter { it.isNotBlank() }.joinToString(" ")

    private data class TrailerStream(
        val playbackUrl: String,
        val mimeType: String,
        val videoId: String,
        val quality: String
    )

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (trailerVisible && event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> {
                    closeTrailerOverlay()
                    return true
                }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }


    private fun launchPlaybackFor(item: TitleCard) {
        cancelTrailerAutoplay()
        stopTrailerPreview(null)
        closeTrailerOverlay()

        if (!item.externalId.isNullOrBlank()) {
            startActivity(Intent(this, com.channelsdebrid.tv.playback.MediaDetailsActivity::class.java).apply {
                putExtra(com.channelsdebrid.tv.playback.MediaDetailsActivity.EXTRA_TITLE, item.title)
                putExtra(com.channelsdebrid.tv.playback.MediaDetailsActivity.EXTRA_META_LINE, item.meta)
                putExtra(com.channelsdebrid.tv.playback.MediaDetailsActivity.EXTRA_DESC, item.desc)
                putExtra(com.channelsdebrid.tv.playback.MediaDetailsActivity.EXTRA_MEDIA_TYPE, item.mediaType ?: "movie")
                putExtra(com.channelsdebrid.tv.playback.MediaDetailsActivity.EXTRA_EXTERNAL_ID, item.externalId)
                putExtra(com.channelsdebrid.tv.playback.MediaDetailsActivity.EXTRA_POSTER_URL, item.posterUrl ?: "")
                putExtra(com.channelsdebrid.tv.playback.MediaDetailsActivity.EXTRA_BACKDROP_URL, item.backdropUrl ?: item.posterUrl ?: "")
                putExtra(com.channelsdebrid.tv.playback.MediaDetailsActivity.EXTRA_LOGO_URL, item.logoUrl ?: "")
            })
            return
        }
        val dvr = settingsRepository.loadChannelsDvr()
        val xtream = settingsRepository.loadXtream()
        binding.statusBadge.visibility = View.GONE
        liveExecutor.execute {
            val target = playbackResolver.resolveLiveTestTarget(item.title, dvr, xtream)
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (target == null) {
                    Toast.makeText(this, "Configure Channels DVR or Xtream/IPTV in Settings to test playback.", Toast.LENGTH_LONG).show()
                } else {
                    startActivity(Intent(this, PlayerActivity::class.java).apply {
                        putExtra(PlayerActivity.EXTRA_STREAM_URL, target.url)
                        putExtra(PlayerActivity.EXTRA_TITLE, target.title)
                        putExtra(PlayerActivity.EXTRA_DEBUG_LABEL, target.debugLabel)
                        putExtra(PlayerActivity.EXTRA_SOURCE_LABEL, target.sourceLabel)
                        putExtra(PlayerActivity.EXTRA_ARTWORK_URL, item.backdropUrl ?: item.posterUrl ?: "")
                        putExtra(PlayerActivity.EXTRA_LOGO_URL, item.logoUrl ?: "")
                        putExtra(PlayerActivity.EXTRA_POSTER_URL, item.posterUrl ?: "")
                        putExtra(PlayerActivity.EXTRA_META_LINE, item.meta)
                        putExtra(PlayerActivity.EXTRA_MEDIA_META_LINE, item.meta)
                        putExtra(PlayerActivity.EXTRA_OVERVIEW, item.desc)
                        putExtra("vod_mode", true)
                    })
                }
            }
        }
    }

    private fun revealFocusedCard(recyclerView: RecyclerView, verticalScroll: ScrollView, view: View, index: Int, verticalRowChange: Boolean = false) {
        val section = rowSlots().firstOrNull { it.recyclerView.id == recyclerView.id }?.section
        val performHorizontalReveal = Runnable {
            val lm = recyclerView.layoutManager as? LinearLayoutManager ?: return@Runnable
            if (verticalRowChange || index <= 0) {
                val targetPos = 0
                val offset = ((recyclerView.width - recyclerView.paddingLeft - recyclerView.paddingRight - view.width) / 2f).toInt()
                lm.scrollToPositionWithOffset(targetPos, offset)
            } else {
                recyclerView.smoothScrollToPosition(index)
            }
        }
        recyclerView.postOnAnimation {
            if (section != null) {
                if (verticalRowChange) {
                    rowSettleInProgress = true
                    pendingRowSettleRunnable?.let(mainHandler::removeCallbacks)
                    markNavigationBusy(220L)
                    snapToRow(section, smooth = false)
                    pendingRowSettleRunnable = Runnable {
                        if (view.isFocused && lastFocusedCardId == view.id) {
                            centerRowOnPosition(recyclerView, 0, requestFocus = true)
                        }
                        rowSettleInProgress = false
                    }.also { mainHandler.postDelayed(it, 90L) }
                } else {
                    performHorizontalReveal.run()
                    markNavigationBusy(160L)
                    snapToRow(section, smooth = false)
                }
            } else {
                verticalScroll.scrollTo(0, view.top)
                performHorizontalReveal.run()
            }
        }
    }

    private fun snapToRow(section: RowSection, smooth: Boolean) {
        val density = resources.displayMetrics.density
        val slot = rowSlots().firstOrNull { it.section == section } ?: return
        val rowTop = slot.titleView.top
        val target = if (section == RowSection.FIRST) 0 else (rowTop - (22f * density).toInt()).coerceAtLeast(0)
        binding.contentScroll.post {
            if (smooth) binding.contentScroll.smoothScrollTo(0, target)
            else binding.contentScroll.scrollTo(0, target)
        }
    }

    private fun glowAnimator(view: View, bloomView: View, hasFocus: Boolean) {
        (view.getTag(R.id.tag_pulse_animator) as? Animator)?.cancel()
        view.setTag(R.id.tag_pulse_animator, null)
        view.animate().cancel()
        bloomView.animate().cancel()
        bloomView.alpha = 0f
        val d = resources.displayMetrics.density
        view.alpha = 1f
        if (!hasFocus) {
            view.scaleX = 1f
            view.scaleY = 1f
            view.translationY = 0f
            view.translationZ = 0f
            view.elevation = 0f
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                view.outlineAmbientShadowColor = 0x00000000
                view.outlineSpotShadowColor = 0x00000000
            }
            return
        }
        // Focus style without bottom platform shadow.
        view.scaleX = 1.035f
        view.scaleY = 1.035f
        view.translationY = 0f
        view.translationZ = 0f
        view.elevation = 0f
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
            view.outlineAmbientShadowColor = 0x00000000
            view.outlineSpotShadowColor = 0x00000000
        }
    }

    private fun makeFocusGlowDrawable(radius: Float): Drawable {
        val d = resources.displayMetrics.density
        val softOuter = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius + (8f * d)
            setColor(0x00000000)
            setStroke((10f * d).toInt().coerceAtLeast(8), 0x55FF9F2E)
        }
        val orangeRing = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius + (4f * d)
            setColor(0x00000000)
            setStroke((5f * d).toInt().coerceAtLeast(4), 0xFFFFB253.toInt())
        }
        val brightInner = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius + (1f * d)
            setColor(0x00000000)
            setStroke((2f * d).toInt().coerceAtLeast(2), 0xFFFFE1A6.toInt())
        }
        return LayerDrawable(arrayOf(softOuter, orangeRing, brightInner))
    }

    private fun makeFocusRing(radius: Float): Drawable = makeFocusGlowDrawable(radius)

    private fun animateHeroContentEntrance() {
        val targets = listOf(binding.heroTitleArtwork, binding.heroTitle, binding.heroMeta, binding.heroDesc)
        targets.forEach { view ->
            view.animate().cancel()
            view.alpha = 1f
            view.translationY = 0f
        }
    }

    private fun previewHeroForFocus(item: TitleCard) {
        loadHeroBackdrop(item)
        applyHeroTitleVisual(item)
        applyHeroMetadataVisual(item)
        binding.heroDesc.text = item.desc
        binding.statusBadge.visibility = View.GONE
    }

    private fun applyHeroMetadataVisual(item: TitleCard) {
        val firstPart = item.meta.substringBefore("•").trim()
        val year = firstPart.takeIf { it.matches(Regex("\\d{4}")) } ?: firstPart.takeIf { it.isNotBlank() } ?: "Featured"
        val featured = item.meta.substringAfter("•", "FEATURED").trim().uppercase().takeIf { it.isNotBlank() } ?: "FEATURED"
        val ratingSeed = kotlin.math.abs(item.title.hashCode())
        val imdb = String.format(java.util.Locale.US, "%.1f", 7.1 + ((ratingSeed % 18) / 10.0))
        val tmdb = String.format(java.util.Locale.US, "%.1f", 7.0 + (((ratingSeed / 7) % 19) / 10.0))

        val text = "$year  •  $featured   IMDb  $imdb   |   TMDB  $tmdb"
        val span = android.text.SpannableString(text)

        fun mark(part: String, vararg styles: Any) {
            val startIndex = text.indexOf(part)
            if (startIndex >= 0) styles.forEach { style ->
                span.setSpan(style, startIndex, startIndex + part.length, android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }

        mark(year,
            android.text.style.ForegroundColorSpan(0xFFFFD33D.toInt()),
            android.text.style.StyleSpan(android.graphics.Typeface.BOLD)
        )
        mark(featured, android.text.style.StyleSpan(android.graphics.Typeface.BOLD))
        mark("IMDb", HeroBadgeSpan(0xFFF5C518.toInt(), 0xFF0B0B0B.toInt(), 6f, 8f))
        mark("TMDB", HeroBadgeSpan(0xFF032541.toInt(), 0xFF21D6B2.toInt(), 6f, 8f))
        mark(imdb, android.text.style.StyleSpan(android.graphics.Typeface.BOLD))
        mark(tmdb, android.text.style.StyleSpan(android.graphics.Typeface.BOLD))

        binding.heroMeta.text = span
    }

    private fun applyHeroTitleVisual(item: TitleCard) {
        val requestKey = heroRequestKey(item)
        pendingHeroLogoRequestKey = requestKey
        val cachedResolvedLogo = resolvedHeroLogoCache[requestKey]
        val logoUrl = preferredHeroLogoUrl(item, cachedResolvedLogo)
        val logoRes = resolveHeroLogoRes(item.title)
        binding.heroTitleArtwork.animate().cancel()
        binding.heroTitle.animate().cancel()
        Glide.with(this).clear(binding.heroTitleArtwork)
        binding.heroTitleArtwork.setImageDrawable(null)
        when {
            logoUrl != null -> {
                binding.heroTitleArtwork.visibility = View.VISIBLE
                binding.heroTitle.visibility = View.GONE
                imageRequest(Glide.with(this), logoUrl)
                    ?.apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).dontTransform())
                    ?.diskCacheStrategy(DiskCacheStrategy.ALL)
                    ?.override(1400, 560)
                    ?.dontAnimate()
                    ?.into(binding.heroTitleArtwork)
            }
            logoRes != 0 -> {
                binding.heroTitleArtwork.visibility = View.VISIBLE
                binding.heroTitleArtwork.setImageResource(logoRes)
                binding.heroTitle.visibility = View.GONE
            }
            else -> {
                binding.heroTitleArtwork.visibility = View.GONE
                binding.heroTitle.visibility = View.VISIBLE
                binding.heroTitle.text = item.title
            }
        }
    }

    private fun loadHeroBackdrop(item: TitleCard) {
        loadBackdropInto(
            imageView = binding.heroBackdrop,
            item = item,
            fallbackRes = item.backgroundRes
        )
    }

    private fun scheduleHeroCommit(item: TitleCard, delayMs: Long = 140L) {
        val requestKey = heroRequestKey(item)
        if (requestKey == committedHeroRequestKey) return
        pendingHeroCommitRunnable?.let(mainHandler::removeCallbacks)
        pendingHeroCommitRunnable = Runnable {
            if (isMotionBusy()) {
                scheduleHeroCommit(item, 160L)
            } else {
                commitHero(item)
            }
        }.also { mainHandler.postDelayed(it, delayMs) }
    }

    private fun commitHero(item: TitleCard) {
        if (isMotionBusy()) {
            scheduleHeroCommit(item, 180L)
            return
        }
        pendingHeroCommitRunnable?.let(mainHandler::removeCallbacks)
        pendingHeroCommitRunnable = null
        committedHeroRequestKey = heroRequestKey(item)
        preloadArtworkBundle(item)
        loadHeroBackdrop(item)
        binding.heroMeta.animate().cancel()
        binding.heroDesc.animate().cancel()
        binding.statusBadge.animate().cancel()
        applyHeroTitleVisual(item)
        maybeResolveHeroBackdropAsync(item)
        maybeResolveHeroLogoAsync(item)
        applyHeroMetadataVisual(item)
        binding.heroDesc.text = item.desc
        binding.statusBadge.visibility = View.GONE
        animateHeroContentEntrance()
    }

    private fun maybeResolveHeroLogoAsync(item: TitleCard) {
        val requestKey = heroRequestKey(item)
        val tmdb = settingsRepository.loadTmdb()
        resolvedHeroLogoCache[requestKey]?.takeIf { it.isNotBlank() }?.let { resolved ->
            if (pendingHeroLogoRequestKey == requestKey) {
                binding.heroTitleArtwork.visibility = View.VISIBLE
                binding.heroTitle.visibility = View.GONE
                Glide.with(this).clear(binding.heroTitleArtwork)
                binding.heroTitleArtwork.setImageDrawable(null)
                imageRequest(Glide.with(this), resolved)
                    ?.apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).dontTransform())
                    ?.diskCacheStrategy(DiskCacheStrategy.ALL)
                    ?.override(1600, 640)
                    ?.dontAnimate()
                    ?.into(binding.heroTitleArtwork)
            }
            return
        }
        val imdbId = item.externalId?.takeIf { it.startsWith("tt") }
        val canResolveTmdbItem = item.sourceKey == "tmdb" && item.tmdbId > 0 && !item.mediaType.isNullOrBlank() && tmdb.apiKey.isNotBlank()
        val canResolveImdbItem = !imdbId.isNullOrBlank() && tmdb.apiKey.isNotBlank()
        if (!canResolveTmdbItem && !canResolveImdbItem) return
        if (!inFlightHeroLogoRequests.add(requestKey)) return
        heroLogoExecutor.execute {
            try {
                val resolved = if (canResolveTmdbItem) {
                    runCatching {
                        tmdbLiveLoader.resolveLogoForItem(
                            apiKey = tmdb.apiKey,
                            type = item.mediaType!!,
                            tmdbId = item.tmdbId,
                            language = tmdb.language.ifBlank { "en-US" },
                            fanartApiKey = BuildConfig.FANART_API_KEY,
                            fanartClientKey = BuildConfig.FANART_CLIENT_KEY
                        )
                    }.getOrNull()
                } else {
                    runCatching {
                        tmdbLiveLoader.resolveHeroArtForExternalId(
                            apiKey = tmdb.apiKey,
                            externalId = imdbId!!,
                            language = tmdb.language.ifBlank { "en-US" },
                            fanartApiKey = BuildConfig.FANART_API_KEY,
                            fanartClientKey = BuildConfig.FANART_CLIENT_KEY
                        )?.logoUrl
                    }.getOrNull()
                }
                if (resolved.isNullOrBlank()) return@execute
                resolvedHeroLogoCache[requestKey] = resolved
                runOnUiThread {
                    if (isFinishing || pendingHeroLogoRequestKey != requestKey) return@runOnUiThread
                    binding.heroTitleArtwork.visibility = View.VISIBLE
                    binding.heroTitle.visibility = View.GONE
                    Glide.with(this).clear(binding.heroTitleArtwork)
                    binding.heroTitleArtwork.setImageDrawable(null)
                    imageRequest(Glide.with(this), resolved)
                        ?.apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).dontTransform())
                        ?.diskCacheStrategy(DiskCacheStrategy.ALL)
                        ?.override(1600, 640)
                        ?.dontAnimate()
                        ?.into(binding.heroTitleArtwork)
                }
            } finally {
                inFlightHeroLogoRequests.remove(requestKey)
            }
        }
    }

    private fun maybeResolveHeroBackdropAsync(item: TitleCard) {
        val tmdb = settingsRepository.loadTmdb()
        val imdbId = item.externalId?.takeIf { it.startsWith("tt") } ?: return
        if (tmdb.apiKey.isBlank()) return
        val requestKey = heroRequestKey(item)
        if (resolvedHeroBackdropCache[requestKey].isNullOrBlank().not()) {
            if (committedHeroRequestKey == requestKey || pendingHeroLogoRequestKey == requestKey) {
                loadHeroBackdrop(item)
            }
            return
        }
        if (!inFlightHeroBackdropRequests.add(requestKey)) return
        heroLogoExecutor.execute {
            try {
                val resolved = runCatching {
                    tmdbLiveLoader.resolveHeroArtForExternalId(
                        apiKey = tmdb.apiKey,
                        externalId = imdbId,
                        language = tmdb.language.ifBlank { "en-US" },
                        fanartApiKey = BuildConfig.FANART_API_KEY,
                        fanartClientKey = BuildConfig.FANART_CLIENT_KEY
                    )
                }.getOrNull() ?: return@execute
                resolved.backdropUrl?.takeIf { it.isNotBlank() }?.let { resolvedHeroBackdropCache[requestKey] = it }
                resolved.logoUrl?.takeIf { it.isNotBlank() }?.let { resolvedHeroLogoCache[requestKey] = it }
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    val activeRequestKey = committedHeroRequestKey
                    if (activeRequestKey != requestKey && pendingHeroLogoRequestKey != requestKey) return@runOnUiThread
                    loadHeroBackdrop(item)
                    applyHeroTitleVisual(item)
                }
            } finally {
                inFlightHeroBackdropRequests.remove(requestKey)
            }
        }
    }

    private fun heroRequestKey(item: TitleCard): String = "${item.sourceKey}:${item.mediaType}:${item.tmdbId}:${item.externalId}:${item.title}"

    private fun prefetchHeroAssets(items: List<TitleCard>) {
        if (items.isEmpty()) return
        items.take(6).forEach { item ->
            preloadArtworkBundle(item)
        }
    }

    private fun resolveHeroLogoRes(title: String): Int {
        val normalized = buildString {
            title.toLowerCase(java.util.Locale.ROOT).forEach { ch ->
                when {
                    ch.isLetterOrDigit() -> append(ch)
                    ch == ' ' || ch == '-' || ch == '–' || ch == '—' || ch == ':' || ch == '/' -> append('_')
                }
            }
        }.replace(Regex("_+"), "_").trim('_')
        if (normalized.isBlank()) return 0
        return resources.getIdentifier("logo_${normalized}", "drawable", packageName)
    }


    private fun bindCardLogo(imageView: ImageView, item: TitleCard, highQuality: Boolean) {
        val requestKey = heroRequestKey(item)
        val logoUrl = preferredHeroLogoUrl(item, resolvedHeroLogoCache[requestKey])
        val cacheKey = requestKey + ":" + highQuality + ":" + (logoUrl ?: "none")
        val viewKey = System.identityHashCode(imageView)
        if (loadedCardLogoRequests[viewKey] == cacheKey) return
        loadedCardLogoRequests[viewKey] = cacheKey

        imageView.tag = requestKey
        imageView.scaleType = ImageView.ScaleType.FIT_CENTER

        if (logoUrl != null) {
            imageView.visibility = View.VISIBLE
            imageRequest(Glide.with(this), logoUrl)
                ?.apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).disallowHardwareConfig().dontTransform())
                ?.diskCacheStrategy(DiskCacheStrategy.ALL)
                ?.skipMemoryCache(false)
                ?.override(if (highQuality) 900 else 680, if (highQuality) 340 else 260)
                ?.dontAnimate()
                ?.into(imageView)
        } else {
            imageView.visibility = View.GONE
        }
    }

    private fun backendImageProxyCandidates(url: String?): List<String> {
        val normalized = url?.trim()?.takeIf { it.isNotBlank() } ?: return emptyList()
        return listOf(normalized)
    }

    private fun imageRequest(requestManager: RequestManager, url: String?): RequestBuilder<Drawable>? {
        val candidates = backendImageProxyCandidates(url)
        if (candidates.isEmpty()) return null
        var request: RequestBuilder<Drawable>? = null
        for (candidate in candidates.asReversed()) {
            request = if (request == null) requestManager.load(candidate) else requestManager.load(candidate).error(request)
        }
        return request
    }

    private fun preloadImageUrl(url: String?, width: Int, height: Int) {
        val requestManager = Glide.with(this)
        imageRequest(requestManager, url)
            ?.diskCacheStrategy(DiskCacheStrategy.ALL)
            ?.skipMemoryCache(false)
            ?.preload(width, height)
    }

    private fun preloadArtworkBundle(item: TitleCard) {
        preloadImageUrl(preferredHeroBackdropUrl(item), 1920, 1080)
        preloadImageUrl(preferredHeroPosterUrl(item), 560, 840)
        preloadImageUrl(preferredHeroLogoUrl(item, resolvedHeroLogoCache[heroRequestKey(item)]), 900, 340)
        preloadImageUrl(item.backdropUrl, 1280, 720)
        preloadImageUrl(item.posterUrl, 520, 780)
        preloadImageUrl(item.logoUrl, 680, 260)
    }

    private fun maybeResolveCardLogoAsync(item: TitleCard, imageView: ImageView, highQuality: Boolean) {
        val tmdb = settingsRepository.loadTmdb()
        if (item.sourceKey != "tmdb" || item.tmdbId <= 0 || item.mediaType.isNullOrBlank() || tmdb.apiKey.isBlank()) return
        val requestKey = heroRequestKey(item)
        resolvedHeroLogoCache[requestKey]?.takeIf { it.isNotBlank() }?.let { resolved ->
            if (isMotionBusy()) return
            imageView.visibility = View.VISIBLE
            imageRequest(Glide.with(this), resolved)
                ?.apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).disallowHardwareConfig().dontTransform())
                ?.diskCacheStrategy(DiskCacheStrategy.ALL)
                ?.override(if (highQuality) 900 else 680, if (highQuality) 340 else 260)
                ?.dontAnimate()
                ?.into(imageView)
            return
        }
        val expectedTag = imageView.tag?.toString()
        liveExecutor.execute {
            val resolved = runCatching {
                tmdbLiveLoader.resolveLogoForItem(
                    apiKey = tmdb.apiKey,
                    type = item.mediaType,
                    tmdbId = item.tmdbId,
                    language = tmdb.language.ifBlank { "en-US" },
                    fanartApiKey = BuildConfig.FANART_API_KEY,
                    fanartClientKey = BuildConfig.FANART_CLIENT_KEY
                )
            }.getOrNull() ?: return@execute
            resolvedHeroLogoCache[requestKey] = resolved
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (imageView.tag?.toString() != expectedTag) return@runOnUiThread
                imageView.visibility = View.VISIBLE
                imageRequest(Glide.with(this), resolved)
                    ?.apply(RequestOptions().format(DecodeFormat.PREFER_ARGB_8888).disallowHardwareConfig().dontTransform())
                    ?.diskCacheStrategy(DiskCacheStrategy.ALL)
                    ?.override(if (highQuality) 900 else 680, if (highQuality) 340 else 260)
                    ?.dontAnimate()
                    ?.into(imageView)
            }
        }
    }

    private fun prefetchCardArtwork(items: List<TitleCard>, limit: Int = 12) {
        // Controlled preload only. Preloading every poster/logo/backdrop at once overloaded TV devices.
        items.take(limit).forEach { item ->
            preloadImageUrl(preferredHeroPosterUrl(item), 520, 780)
            preloadImageUrl(preferredHeroLogoUrl(item, resolvedHeroLogoCache[heroRequestKey(item)]), 520, 200)
        }
    }

    private fun scheduleInitialArtworkPreload(rows: List<BackendHomeLoader.BackendRow>) {
        mainHandler.postDelayed({
            rows.take(3).forEachIndexed { rowIndex, row ->
                val mapped = row.items.mapIndexed { index, item -> mapBackendItemToTitleCard(item, index) }
                prefetchCardArtwork(mapped, limit = if (rowIndex == 0) 14 else 8)
            }
        }, 350L)
    }

    private fun preloadAllVisibleHomeArtwork() {
        val firstAdapter = firstVisibleRowSlot()?.recyclerView?.adapter as? RowAdapter
        firstAdapter?.itemsForPreload()?.let { prefetchCardArtwork(it, limit = 12) }
    }

    private fun loadCardBackdropLayerInto(imageView: ImageView, item: TitleCard, highQuality: Boolean) {
        val posterUrl = preferredHeroPosterUrl(item)?.takeIf { it.isNotBlank() }
        val wideUrl = preferredHeroBackdropUrl(item)?.takeIf { it.isNotBlank() && it != posterUrl }
        val backgroundUrl = posterUrl ?: wideUrl
        val fallbackUrl = if (backgroundUrl == posterUrl) wideUrl else posterUrl
        val requestTag = "bg:${item.sourceKey}:${item.mediaType}:${item.tmdbId}:${item.title}:$highQuality:$backgroundUrl:$fallbackUrl"
        val viewKey = System.identityHashCode(imageView)
        if (loadedCardArtworkRequests[viewKey] == requestTag) return
        loadedCardArtworkRequests[viewKey] = requestTag

        imageView.animate().cancel()
        imageView.tag = requestTag
        imageView.scaleType = ImageView.ScaleType.CENTER_CROP
        imageView.alpha = 0.96f
        if (imageView.drawable == null) imageView.setImageResource(item.backgroundRes)

        if (backgroundUrl == null) return

        val reqWidth = if (highQuality) 1280 else 900
        val reqHeight = if (highQuality) 720 else 520
        val baseOptions = RequestOptions()
            .format(DecodeFormat.PREFER_ARGB_8888)
            .disallowHardwareConfig()
            .override(reqWidth, reqHeight)
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .skipMemoryCache(false)
            .centerCrop()

        val requestManager = Glide.with(this)
        val fallbackRequest = fallbackUrl?.let {
            imageRequest(requestManager, it)
                ?.apply(baseOptions)
                ?.transition(DrawableTransitionOptions.withCrossFade(140))
        }

        imageRequest(requestManager, backgroundUrl)
            ?.apply(baseOptions)
            ?.thumbnail(imageRequest(requestManager, backgroundUrl)?.apply(baseOptions.override(180, 104)))
            ?.transition(DrawableTransitionOptions.withCrossFade(140))
            ?.error(fallbackRequest ?: requestManager.load(item.backgroundRes).apply(baseOptions))
            ?.into(imageView)
    }

    private fun loadCardPosterLayerInto(imageView: ImageView, item: TitleCard, highQuality: Boolean) {
        val posterUrl = preferredHeroPosterUrl(item)?.takeIf { it.isNotBlank() }
        val fallbackWideUrl = preferredHeroBackdropUrl(item)?.takeIf { it.isNotBlank() && it != posterUrl }
        val targetUrl = posterUrl ?: fallbackWideUrl
        val usePosterLayer = targetUrl != null
        val requestTag = "poster:${item.sourceKey}:${item.mediaType}:${item.tmdbId}:${item.title}:$highQuality:$posterUrl:$fallbackWideUrl"
        val viewKey = System.identityHashCode(imageView)
        if (loadedCardArtworkRequests[viewKey] == requestTag) return
        loadedCardArtworkRequests[viewKey] = requestTag

        Glide.with(this).clear(imageView)
        imageView.animate().cancel()
        imageView.tag = requestTag
        imageView.setImageDrawable(null)
        imageView.visibility = if (usePosterLayer) View.VISIBLE else View.GONE
        imageView.alpha = if (usePosterLayer) 1f else 0f
        imageView.scaleType = if (posterUrl != null) ImageView.ScaleType.FIT_CENTER else ImageView.ScaleType.CENTER_CROP

        if (!usePosterLayer) return

        val reqWidth = if (highQuality) 720 else 420
        val reqHeight = if (highQuality) 1080 else 620
        val baseOptions = RequestOptions()
            .format(DecodeFormat.PREFER_ARGB_8888)
            .disallowHardwareConfig()
            .override(reqWidth, reqHeight)
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .skipMemoryCache(false)
            .apply { if (posterUrl != null) fitCenter() else centerCrop() }

        val requestManager = Glide.with(this)
        val thumb = imageRequest(requestManager, targetUrl)?.apply(baseOptions.override(140, 210))
        imageRequest(requestManager, targetUrl)
            ?.apply(baseOptions)
            ?.thumbnail(thumb)
            ?.transition(DrawableTransitionOptions.withCrossFade(120))
            ?.error(imageRequest(requestManager, fallbackWideUrl)?.apply(baseOptions)
                ?: requestManager.load(android.R.color.transparent).apply(baseOptions))
            ?.into(imageView)
    }

    private fun loadBackdropInto(
        imageView: ImageView,
        item: TitleCard,
        fallbackRes: Int
    ) {
        val backdrop = preferredHeroBackdropUrl(item)
        val poster = preferredHeroPosterUrl(item)
        val targetUrl = backdrop ?: poster
        val requestTag = "hero:${targetUrl ?: fallbackRes}:${itemHash(backdrop, poster)}"
        imageView.tag = requestTag
        Glide.with(this).clear(imageView)
        imageView.animate().cancel()
        imageView.setImageDrawable(null)
        imageView.setBackgroundColor(0xFF06080F.toInt())
        imageView.scaleType = ImageView.ScaleType.CENTER_CROP
        if (targetUrl.isNullOrBlank()) {
            imageView.setImageDrawable(safeDrawable(fallbackRes))
            return
        }
        val requestManager = Glide.with(this)
        val requestOptions = RequestOptions()
            .format(DecodeFormat.PREFER_ARGB_8888)
            .disallowHardwareConfig()
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .skipMemoryCache(false)

        val fullSizeOptions = requestOptions.centerCrop().override(3840, 2160)
        val largeFallbackOptions = requestOptions.centerCrop().override(2560, 1440)
        val thumb = imageRequest(requestManager, targetUrl)?.apply(
            requestOptions.override(1920, 1080).centerCrop()
        )
        val largeFallback = imageRequest(requestManager, targetUrl)
            ?.apply(largeFallbackOptions)
            ?.thumbnail(thumb)

        imageRequest(requestManager, targetUrl)
            ?.apply(fullSizeOptions)
            ?.thumbnail(thumb)
            ?.transition(DrawableTransitionOptions.withCrossFade(180))
            ?.placeholder(fallbackRes)
            ?.error(largeFallback)
            ?.into(imageView)
    }

    private fun preferredHeroBackdropUrl(item: TitleCard): String? {
        val requestKey = heroRequestKey(item)
        val cached = normalizeHeroBackdropUrl(resolvedHeroBackdropCache[requestKey])
        if (!cached.isNullOrBlank()) return cached
        val directBackdrop = normalizeHeroBackdropUrl(item.backdropUrl)
        if (!directBackdrop.isNullOrBlank()) return directBackdrop
        val derivedBackdrop = normalizeHeroBackdropUrl(metahubBackdropUrlFor(item.externalId))
        if (!derivedBackdrop.isNullOrBlank()) return derivedBackdrop
        return preferredHeroPosterUrl(item)
    }

    private fun preferredHeroPosterUrl(item: TitleCard): String? {
        val directPoster = normalizeHeroPosterUrl(item.posterUrl)
        if (!directPoster.isNullOrBlank()) return directPoster
        return normalizeHeroPosterUrl(metahubPosterUrlFor(item.externalId))
    }

    private fun preferredHeroLogoUrl(item: TitleCard, cachedLogo: String? = null): String? {
        cachedLogo?.takeIf { it.isNotBlank() }?.let { return it }
        val directLogo = item.logoUrl
            ?.takeIf { it.isNotBlank() }
            ?.takeIf { logo ->
                logo != item.posterUrl && logo != item.backdropUrl &&
                    !logo.contains("/poster/", ignoreCase = true) &&
                    !logo.contains("/background/", ignoreCase = true)
            }
        return directLogo ?: metahubLogoUrlFor(item.externalId)
    }

    private fun metahubBackdropUrlFor(externalId: String?): String? =
        externalId?.takeIf { it.startsWith("tt") }?.let { "https://images.metahub.space/background/large/$it/img" }

    private fun metahubPosterUrlFor(externalId: String?): String? =
        externalId?.takeIf { it.startsWith("tt") }?.let { "https://images.metahub.space/poster/large/$it/img" }

    private fun metahubLogoUrlFor(externalId: String?): String? =
        externalId?.takeIf { it.startsWith("tt") }?.let { "https://images.metahub.space/logo/large/$it/img" }

    private fun normalizeHeroBackdropUrl(url: String?): String? =
        url?.takeIf { it.isNotBlank() }
            ?.replace("/background/small/", "/background/large/")
            ?.replace("/background/medium/", "/background/large/")
            ?.replace("/poster/small/", "/background/large/")
            ?.replace("/poster/medium/", "/background/large/")
            ?.replace("/w300/", "/original/")
            ?.replace("/w500/", "/original/")
            ?.replace("/w780/", "/original/")
            ?.replace("/w1280/", "/original/")

    private fun normalizeHeroPosterUrl(url: String?): String? =
        url?.takeIf { it.isNotBlank() }
            ?.replace("/poster/small/", "/poster/large/")
            ?.replace("/poster/medium/", "/poster/large/")
            ?.replace("/w300/", "/original/")
            ?.replace("/w500/", "/original/")
            ?.replace("/w780/", "/original/")

    private fun itemHash(backdrop: String?, poster: String?): String = listOfNotNull(backdrop, poster).joinToString("|")

    private fun safeDrawable(resId: Int): Drawable? = ContextCompat.getDrawable(this, resId)
}
