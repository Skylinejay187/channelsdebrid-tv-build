package com.channelsdebrid.tv.settings

data class TmdbSettings(
    val apiKey: String = "",
    val region: String = "US",
    val language: String = "en-US"
)

data class CatalogSettings(
    val trendingMoviesEnabled: Boolean = true,
    val popularMoviesEnabled: Boolean = true,
    val trendingShowsEnabled: Boolean = true,
    val popularShowsEnabled: Boolean = true,
    val platformRowsEnabled: Boolean = true,
    val stremioCatalogRowsEnabled: Boolean = true
)

data class StremioAddonSettings(
    val id: String,
    val name: String,
    val manifestUrl: String,
    val enabled: Boolean = true
) {
    val url: String get() = manifestUrl
}

data class DebridSettings(
    val realDebridEnabled: Boolean = false,
    val realDebridApiKey: String = "",
    val torBoxEnabled: Boolean = false,
    val torBoxApiKey: String = "",
    val preferredProvider: String = "realdebrid",
    val autoFallback: Boolean = true
)

data class ChannelsDvrSettings(
    val autoDetect: Boolean = true,
    val baseUrl: String = "",
    val deviceId: String = ""
)

data class XtreamSettings(
    val server: String = "",
    val username: String = "",
    val password: String = "",
    val m3uUrl: String = "",
    val enabled: Boolean = false
)

data class StorageTarget(
    val id: String,
    val type: String,
    val label: String,
    val path: String,
    val allowTimeshift: Boolean,
    val allowVodCache: Boolean,
    val priority: Int
)

data class StorageSettings(
    val preferredTarget: String = "internal",
    val usbPath: String = "",
    val nasPath: String = "",
    val timeshiftMinutes: Int = 90,
    val movieCacheEnabled: Boolean = true
)

data class TrailerSettings(
    val enabled: Boolean = true,
    val autoplayOnFocus: Boolean = false,
    val autoplayDelayMs: Long = 5000,
    val backgroundAutoplayEnabled: Boolean = true,
    val backgroundAutoplayDelayMs: Long = 3000,
    val popupMode: String = "fullscreen",
    val youtubeApiKey: String = "",
    val prefer4k: Boolean = false
)

data class PlaybackSettings(
    val frameRateMatching: Boolean = true,
    val preferExternalStorageForCache: Boolean = true,
    val timeshiftEnabled: Boolean = true,
    val autoPlayBestStream: Boolean = true,
    val fileSizeLimitGb: Int = 40,
    val ultraHdGuideUiEnabled: Boolean = true,
    val liveStatusChecksEnabled: Boolean = true
)


data class LiveBackendSettings(
    val baseUrl: String = "http://192.168.100.55:8181",
    val userId: String = "demo",
    val autoSyncSources: Boolean = true
)


/**
 * Single source of truth for the home-screen layout engine.
 *
 * Every field has a safe default so new layout options never break older callers.
 * These defaults intentionally target the Arvio-style 4 full cards + partial 5th card look.
 */
data class HomeLayoutSettings(
    val rowTopDp: Int = HomeLayoutDefaults.ROW_TOP_DP,
    val rowLeftDp: Int = HomeLayoutDefaults.ROW_LEFT_DP,
    val cardWidthDp: Int = HomeLayoutDefaults.CARD_WIDTH_DP,
    val cardHeightDp: Int = HomeLayoutDefaults.CARD_HEIGHT_DP,
    val cardSpacingDp: Int = HomeLayoutDefaults.CARD_SPACING_DP,
    val focusedScalePercent: Int = HomeLayoutDefaults.FOCUSED_SCALE_PERCENT,
    val heroTextLeftDp: Int = HomeLayoutDefaults.HERO_TEXT_LEFT_DP,
    val heroTextTopDp: Int = HomeLayoutDefaults.HERO_TEXT_TOP_DP,
    val topMenuOffsetDp: Int = HomeLayoutDefaults.TOP_MENU_OFFSET_DP,
    val bottomSafeDp: Int = HomeLayoutDefaults.BOTTOM_SAFE_DP,
    val previewCardCount: Int = HomeLayoutDefaults.PREVIEW_CARD_COUNT
)

object HomeLayoutDefaults {
    const val ROW_TOP_DP = 430
    const val ROW_LEFT_DP = 6
    const val CARD_WIDTH_DP = 286
    const val CARD_HEIGHT_DP = 160
    const val CARD_SPACING_DP = 12
    const val FOCUSED_SCALE_PERCENT = 105
    const val HERO_TEXT_LEFT_DP = 0
    const val HERO_TEXT_TOP_DP = 0
    const val TOP_MENU_OFFSET_DP = 0
    const val BOTTOM_SAFE_DP = 72
    const val PREVIEW_CARD_COUNT = 4
}

fun HomeLayoutSettings.sanitized(): HomeLayoutSettings = copy(
    rowTopDp = rowTopDp.coerceIn(260, 660),
    rowLeftDp = rowLeftDp.coerceIn(0, 180),
    cardWidthDp = cardWidthDp.coerceIn(180, 460),
    cardHeightDp = cardHeightDp.coerceIn(100, 300),
    cardSpacingDp = cardSpacingDp.coerceIn(0, 60),
    focusedScalePercent = focusedScalePercent.coerceIn(100, 120),
    heroTextLeftDp = heroTextLeftDp.coerceIn(-120, 260),
    heroTextTopDp = heroTextTopDp.coerceIn(-120, 220),
    topMenuOffsetDp = topMenuOffsetDp.coerceIn(-260, 260),
    bottomSafeDp = bottomSafeDp.coerceIn(24, 180),
    previewCardCount = previewCardCount.coerceIn(1, 8)
)
