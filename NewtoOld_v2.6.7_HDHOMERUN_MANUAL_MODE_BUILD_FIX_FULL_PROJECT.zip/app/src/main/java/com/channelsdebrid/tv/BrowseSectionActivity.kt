package com.channelsdebrid.tv

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.channelsdebrid.tv.data.UnifiedCatalogRepository
import com.channelsdebrid.tv.playback.MediaDetailsActivity
import com.channelsdebrid.tv.playback.PlayerActivity
import java.util.concurrent.Executors

class BrowseSectionActivity : AppCompatActivity() {
    private lateinit var repo: UnifiedCatalogRepository
    private lateinit var rows: LinearLayout
    private lateinit var heroTitle: TextView
    private lateinit var heroMeta: TextView
    private lateinit var heroBg: ImageView
    private var section = "movies"
    private val executor = Executors.newSingleThreadExecutor()
    private var loadVersion = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = UnifiedCatalogRepository(this)
        section = intent.getStringExtra(EXTRA_SECTION) ?: "movies"
        setContentView(buildLayout())
        renderSection()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildLayout(): View {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(3, 5, 9)) }
        heroBg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; alpha = 0.45f }
        root.addView(heroBg, FrameLayout.LayoutParams(-1, dp(360)))
        val shade = View(this).apply { background = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x66000000, 0xFF030509.toInt())) }
        root.addView(shade, FrameLayout.LayoutParams(-1, dp(390)))
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(54), dp(38), dp(54), 0) }
        heroTitle = TextView(this).apply { textSize = 42f; setTextColor(Color.WHITE); typeface = android.graphics.Typeface.DEFAULT_BOLD }
        heroMeta = TextView(this).apply { textSize = 16f; setTextColor(0xFFD7CCBF.toInt()); setPadding(0, dp(6), 0, dp(28)) }
        content.addView(heroTitle)
        content.addView(heroMeta)
        val scroll = ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER }
        rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(rows)
        content.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(content)
        return root
    }

    private fun renderSection() {
        val title = if (section == "shows") "TV Shows" else "Movies"
        heroTitle.text = title
        heroMeta.text = if (section == "shows") "Popular shows, trending series, and addon catalog rows" else "Popular movies, trending films, and addon catalog rows"
        val version = ++loadVersion
        rows.removeAllViews()
        rows.addView(TextView(this).apply {
            text = "Loading ${title.lowercase()} catalogs…"
            textSize = 18f
            setTextColor(0xCCFFFFFF.toInt())
            setPadding(0, dp(18), 0, dp(18))
        })
        executor.execute {
            val base = repo.section(section)
            runOnUiThread {
                if (version != loadVersion || isFinishing || isDestroyed) return@runOnUiThread
                rows.removeAllViews()
                val rowNames = if (section == "shows") listOf("Popular Shows", "Trending Series", "Recently Added Shows", "Featured Episodes") else listOf("Popular Movies", "Trending Movies", "Recently Added Movies", "Featured Films")
                rowNames.forEachIndexed { idx, rowName -> addRow(rowName, base.drop(idx).ifEmpty { base }) }
                base.firstOrNull()?.let { updateHero(it) }
            }
        }
    }

    private fun addRow(title: String, items: List<UnifiedCatalogRepository.MediaItem>) {
        rows.addView(TextView(this).apply { text = title; textSize = 23f; setTextColor(Color.WHITE); typeface = android.graphics.Typeface.DEFAULT_BOLD; setPadding(0, dp(10), 0, dp(10)) })
        val scroller = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val lane = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        items.take(28).forEach { lane.addView(card(it)) }
        scroller.addView(lane)
        rows.addView(scroller, LinearLayout.LayoutParams(-1, dp(188)).apply { bottomMargin = dp(12) })
    }

    private fun card(item: UnifiedCatalogRepository.MediaItem): View {
        val frame = FrameLayout(this).apply {
            isFocusable = true; isClickable = true
            background = rounded(0xFF111827.toInt(), 0, dp(18), 0)
            layoutParams = LinearLayout.LayoutParams(dp(250), dp(150)).apply { rightMargin = dp(14) }
        }
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(0xFF0B0F18.toInt()) }
        frame.addView(img, FrameLayout.LayoutParams(-1, -1))
        val label = TextView(this).apply { text = item.title; textSize = 17f; setTextColor(Color.WHITE); typeface = android.graphics.Typeface.DEFAULT_BOLD; gravity = Gravity.BOTTOM; setPadding(dp(14), 0, dp(14), dp(12)); maxLines = 2 }
        frame.addView(label, FrameLayout.LayoutParams(-1, -1))
        val art = item.backdropUrl.ifBlank { item.posterUrl }
        if (art.isNotBlank()) Glide.with(this).load(art).centerCrop().into(img)
        frame.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) updateHero(item)
            v.background = if (hasFocus) rounded(0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), dp(18), dp(2)) else rounded(0xFF111827.toInt(), 0, dp(18), 0)
            v.animate().scaleX(if (hasFocus) 1.025f else 1f).scaleY(if (hasFocus) 1.025f else 1f).setDuration(120).start()
        }
        frame.setOnClickListener { openItem(item) }
        return frame
    }

    private fun updateHero(item: UnifiedCatalogRepository.MediaItem) {
        heroTitle.text = item.title
        heroMeta.text = listOf(if (item.type == "series") "TV Show" else "Movie", item.meta).filter { it.isNotBlank() }.joinToString("  •  ")
        val art = item.backdropUrl.ifBlank { item.posterUrl }
        if (art.isNotBlank()) Glide.with(this).load(art).centerCrop().into(heroBg)
    }

    private fun openItem(item: UnifiedCatalogRepository.MediaItem) {
        if (item.type == "live" && item.streamUrl.isNotBlank()) {
            startActivity(Intent(this, PlayerActivity::class.java).apply { putExtra(PlayerActivity.EXTRA_STREAM_URL, item.streamUrl); putExtra(PlayerActivity.EXTRA_TITLE, item.title); putExtra(PlayerActivity.EXTRA_SOURCE_LABEL, item.meta) })
            return
        }
        startActivity(Intent(this, MediaDetailsActivity::class.java).apply {
            putExtra(MediaDetailsActivity.EXTRA_TITLE, item.title)
            putExtra(MediaDetailsActivity.EXTRA_META_LINE, item.meta)
            putExtra(MediaDetailsActivity.EXTRA_DESC, item.overview)
            putExtra(MediaDetailsActivity.EXTRA_MEDIA_TYPE, if (item.type == "series") "series" else "movie")
            putExtra(MediaDetailsActivity.EXTRA_EXTERNAL_ID, item.externalId)
            putExtra(MediaDetailsActivity.EXTRA_POSTER_URL, item.posterUrl)
            putExtra(MediaDetailsActivity.EXTRA_BACKDROP_URL, item.backdropUrl)
            putExtra(MediaDetailsActivity.EXTRA_LOGO_URL, item.logoUrl)
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int, strokeWidth: Int) = android.graphics.drawable.GradientDrawable().apply { shape = android.graphics.drawable.GradientDrawable.RECTANGLE; setColor(fill); cornerRadius = radius.toFloat(); if (strokeWidth > 0) setStroke(strokeWidth, stroke) }

    companion object { const val EXTRA_SECTION = "section" }
}
