package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.5.2 LIVE TV EXACT REFERENCE TOP MENU BACK FIX";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.5.2_live_tv_exact_reference_top_menu_back_home_clean_base";
    private BuildMarkers() {}
}
