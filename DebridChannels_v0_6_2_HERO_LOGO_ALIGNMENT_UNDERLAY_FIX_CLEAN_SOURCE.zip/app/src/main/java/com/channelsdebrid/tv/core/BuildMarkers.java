package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.6.2 HERO LOGO ALIGNMENT + STARTUP UNDERLAY FIX";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.6.2_hero_logo_alignment_startup_underlay_clean_base";
    private BuildMarkers() {}
}
