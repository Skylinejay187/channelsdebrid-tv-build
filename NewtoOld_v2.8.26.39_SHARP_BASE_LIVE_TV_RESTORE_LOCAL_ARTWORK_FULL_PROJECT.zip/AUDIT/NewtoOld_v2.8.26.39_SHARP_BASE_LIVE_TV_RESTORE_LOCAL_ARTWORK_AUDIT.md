# NewtoOld v2.8.26.39 SHARP BASE LIVE TV RESTORE LOCAL ARTWORK AUDIT

- Base: uploaded v2.8.26.39 sharp-image renderer.
- Reverted forced migration of `live_backend_base_url` to local LAN.
- Restored uploaded DebridChannels_Full_Preset.json live backend value so Live TV guide/source behavior is not touched.
- Kept app artwork/runtime backend routing in BackendEndpoint.kt pointed at `http://192.168.100.55:8181` for poster/artwork backend testing.
- Added compatibility restore: if the previous force-local build changed Live TV backend to local, this build restores the original preset Live TV backend value.
- Preserves Live TV, row focus/scrolling, Pro Layout Editor, sharp v2.8.26.39 renderer, backend compatibility, visible build marker discipline.
