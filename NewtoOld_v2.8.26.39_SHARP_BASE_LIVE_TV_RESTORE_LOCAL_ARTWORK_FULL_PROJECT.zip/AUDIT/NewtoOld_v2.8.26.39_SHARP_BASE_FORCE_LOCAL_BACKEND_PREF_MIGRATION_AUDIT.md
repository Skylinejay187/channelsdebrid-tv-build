# NewtoOld v2.8.26.39 Sharp Base - Force Local Backend Preference Migration

- Base preserved: v2.8.26.39 sharp-image renderer.
- Preserved Live TV, Pro Layout Editor, row focus/scrolling, backend compatibility, and user full preset.
- Fixed persisted old backend URL issue: app now sanitizes saved `live_backend_base_url` on load.
- Any stale `skylinejay187.duckdns.org` or `api.skylinejay187.it.com` saved value is migrated to `http://192.168.100.55:8181`.
- Bundled `DebridChannels_Full_Preset.json` now uses the local backend URL.
- Updated visible/build markers to `NewtoOld_v2.8.26.39_SHARP_BASE_FORCE_LOCAL_BACKEND_PREF_MIGRATION`.
