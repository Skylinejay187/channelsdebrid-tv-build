# NewtoOld_v2.8.26.39_SHARP_BASE_FORCE_LOCAL_BACKEND_PREF_MIGRATION Audit

Base used: NewtoOld_v2.8.26.39 V37 sharp-image rollback source uploaded by user.

Preserved:
- old app v2.8.26.39 sharp hero/artwork base
- row scrolling/focus behavior
- Live TV
- Pro Layout Editor
- backend compatibility
- VOD/player systems

Applied:
- Bundled DebridChannels_Full_Preset.json default.
- Included original uploaded preset as DebridChannels_Full_Preset_ORIGINAL_UPLOADED.json.
- Corrected runtime backend default to local LAN host http://192.168.100.55:8181.
- Kept Cloudflare/public endpoint out of active local routing.
- Hardened SharedPreferences getLong-compatible trailer delay reads.
- Updated visible BuildConfig/logcat/build audit markers.

Future rule:
Build future app updates forward from this v2.8.26.39 sharp base unless the user explicitly requests another app base.
