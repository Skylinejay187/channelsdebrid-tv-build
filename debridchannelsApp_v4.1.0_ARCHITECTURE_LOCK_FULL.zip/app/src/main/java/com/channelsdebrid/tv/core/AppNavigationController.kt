package com.channelsdebrid.tv.core

import android.app.Activity
import android.content.Intent
import android.os.SystemClock

class AppNavigationController(private val activity: Activity) {
    private var lastLaunchAtMs = 0L
    private var lastFinishAtMs = 0L
    private var lastTarget = ""
    private var finishingLocked = false

    fun launch(intent: Intent, target: String, finishCurrent: Boolean = false, minIntervalMs: Long = 650L): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (target == lastTarget && now - lastLaunchAtMs < minIntervalMs) {
            BuildMarkers.trace("NavigationController", "blocked duplicate target=$target")
            return false
        }
        if (finishCurrent && finishingLocked) {
            BuildMarkers.trace("NavigationController", "blocked launch because finish locked target=$target")
            return false
        }
        lastTarget = target
        lastLaunchAtMs = now
        BuildMarkers.trace("NavigationController", "launch target=$target finish=$finishCurrent")
        activity.startActivity(intent)
        activity.overridePendingTransition(0, 0)
        if (finishCurrent) finishOnly("launch-$target")
        return true
    }

    fun finishOnly(reason: String): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (finishingLocked || activity.isFinishing || now - lastFinishAtMs < 900L) {
            BuildMarkers.trace("NavigationController", "blocked duplicate finish reason=$reason")
            return false
        }
        finishingLocked = true
        lastFinishAtMs = now
        BuildMarkers.trace("NavigationController", "finish reason=$reason")
        activity.finish()
        return true
    }
}
