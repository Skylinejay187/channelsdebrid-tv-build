package com.channelsdebrid.tv.core

import android.util.Log
import com.channelsdebrid.tv.BuildConfig

object BuildMarkers {
    const val BUILD_MARKER = "V4_1_ARCHITECTURE_LOCK_START"
    const val ARCHITECTURE_MARKER = "architecture_lock_single_navigation_guarded_player_livetv_guide_timeshift_pro_layout"

    fun log(component: String) {
        Log.i("DebridChannels", "$BUILD_MARKER component=$component build=${BuildConfig.VERSION_NAME} code=${BuildConfig.VERSION_CODE} arch=$ARCHITECTURE_MARKER")
    }

    fun trace(component: String, message: String) {
        Log.i("DebridChannels", "$BUILD_MARKER component=$component $message")
    }
}
