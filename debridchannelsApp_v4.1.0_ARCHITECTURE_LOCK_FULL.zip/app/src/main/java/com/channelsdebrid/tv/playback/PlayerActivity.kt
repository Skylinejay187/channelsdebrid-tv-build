package com.channelsdebrid.tv.playback

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.channelsdebrid.tv.BuildConfig
import com.channelsdebrid.tv.R
import com.channelsdebrid.tv.core.BuildMarkers
import com.channelsdebrid.tv.core.TimeshiftOwner
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

class PlayerActivity : AppCompatActivity() {
    private lateinit var playerView: PlayerView
    private lateinit var backdrop: ImageView
    private lateinit var topOverlay: View
    private lateinit var titleArtwork: ImageView
    private lateinit var titleView: TextView
    private lateinit var metaText: TextView
    private lateinit var statusView: TextView
    private lateinit var channelBadge: TextView
    private lateinit var channelLogo: ImageView
    private lateinit var clock: TextView
    private lateinit var nowTime: TextView
    private lateinit var nextText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var liveTopInfo: View
    private lateinit var nowRow: View
    private lateinit var vodTimeRow: View
    private lateinit var vodControls: LinearLayout
    private lateinit var currentTime: TextView
    private lateinit var duration: TextView
    private lateinit var vodInfoHero: View
    private lateinit var vodPoster: ImageView
    private lateinit var vodTitle: TextView
    private lateinit var vodMetaLine: TextView
    private lateinit var vodRating: TextView
    private lateinit var vodDescription: TextView
    private lateinit var vodBadgeRow: LinearLayout
    private lateinit var guideOverlay: View
    private lateinit var guideMode: TextView
    private lateinit var guideClock: TextView
    private lateinit var guideTitle: TextView
    private lateinit var guideMeta: TextView
    private lateinit var guideHint: TextView
    private lateinit var guideInfoLogo: TextView
    private lateinit var guideList: LinearLayout
    private lateinit var guideScroller: HorizontalScrollView

    private var rewindButton: TextView? = null
    private var playPauseButton: TextView? = null
    private var forwardButton: TextView? = null
    private var audioButton: TextView? = null
    private var subtitlesButton: TextView? = null
    private var episodesButton: TextView? = null
    private var zoomButton: TextView? = null
    private var settingsButton: TextView? = null

    private val overlayHandler = Handler(Looper.getMainLooper())
    private lateinit var playerOwner: UnifiedPlayerManager
    private lateinit var timeshiftOwner: TimeshiftOwner
    private var player: ExoPlayer? = null
    private var released = false
    private var finishRequested = false
    private var isVod = false
    private var channels: List<GuideChannel> = emptyList()
    private var currentIndex = 0
    private var selectedIndex = 0
    private var streamUrl = ""
    private var title = "Playback"
    private var sourceLabel = ""

    private val progressRunnable = object : Runnable {
        override fun run() {
            updateProgress()
            overlayHandler.postDelayed(this, 1000L)
        }
    }
    private val hideOverlayRunnable = Runnable {
        if (!guideOverlay.isVisible) topOverlay.visibility = View.GONE
    }
    private val hideGuideRunnable = Runnable { hideGuideOverlay() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        BuildMarkers.log("PlayerActivity")
        Log.i("DebridChannels", "PlayerActivity rewriteLabel=${BuildConfig.VERSION_NAME}")
        supportActionBar?.hide()
        setContentView(R.layout.activity_player)
        bindViews()

        playerOwner = UnifiedPlayerManager(this, "fullscreen")
        timeshiftOwner = TimeshiftOwner(this)

        streamUrl = intent.getStringExtra(EXTRA_STREAM_URL).orEmpty()
        title = intent.getStringExtra(EXTRA_TITLE).orEmpty().ifBlank { "Playback" }
        sourceLabel = intent.getStringExtra(EXTRA_SOURCE_LABEL).orEmpty()
        isVod = intent.getBooleanExtra(EXTRA_VOD_MODE, false)
        channels = decodeChannels(intent.getStringExtra(EXTRA_CHANNELS_JSON))
        currentIndex = intent.getIntExtra(EXTRA_CHANNEL_INDEX, 0).coerceIn(0, max(0, channels.size - 1))
        selectedIndex = currentIndex

        bindModeUi()
        bindMetadata()
        wireControls()
        renderGuideOverlay()

        if (streamUrl.isBlank()) {
            Toast.makeText(this, "No stream URL available", Toast.LENGTH_LONG).show()
            finishCleanly()
            return
        }
        startPlayback(streamUrl)
    }

    private fun bindViews() {
        playerView = findViewById(R.id.playerView)
        backdrop = findViewById(R.id.playerBackdrop)
        topOverlay = findViewById(R.id.playerTopOverlay)
        titleArtwork = findViewById(R.id.playerTitleArtwork)
        titleView = findViewById(R.id.playerTitle)
        metaText = findViewById(R.id.playerMetaText)
        statusView = findViewById(R.id.playerStatus)
        channelBadge = findViewById(R.id.playerChannelBadge)
        channelLogo = findViewById(R.id.playerChannelLogo)
        clock = findViewById(R.id.playerClock)
        nowTime = findViewById(R.id.playerNowTime)
        nextText = findViewById(R.id.playerNext)
        progress = findViewById(R.id.playerProgress)
        liveTopInfo = findViewById(R.id.playerLiveTopInfo)
        nowRow = findViewById(R.id.playerNowRow)
        vodTimeRow = findViewById(R.id.playerVodTimeRow)
        vodControls = findViewById(R.id.playerVodControls)
        currentTime = findViewById(R.id.playerCurrentTime)
        duration = findViewById(R.id.playerDuration)
        vodInfoHero = findViewById(R.id.playerVodInfoHero)
        vodPoster = findViewById(R.id.playerVodPoster)
        vodTitle = findViewById(R.id.playerVodTitle)
        vodMetaLine = findViewById(R.id.playerVodMetaLine)
        vodRating = findViewById(R.id.playerVodRating)
        vodDescription = findViewById(R.id.playerVodDescription)
        vodBadgeRow = findViewById(R.id.playerVodBadgeRow)
        guideOverlay = findViewById(R.id.guideOverlay)
        guideMode = findViewById(R.id.guideMode)
        guideClock = findViewById(R.id.guideClock)
        guideTitle = findViewById(R.id.guideTitle)
        guideMeta = findViewById(R.id.guideMeta)
        guideHint = findViewById(R.id.guideHint)
        guideInfoLogo = findViewById(R.id.guideInfoLogo)
        guideList = findViewById(R.id.guideChannelList)
        guideScroller = findViewById(R.id.guideScroller)
        rewindButton = findText("playerRewindButton")
        playPauseButton = findText("playerPlayPauseButton")
        forwardButton = findText("playerForwardButton")
        audioButton = findText("playerAudioButton")
        subtitlesButton = findText("playerSubtitlesButton")
        episodesButton = findText("playerEpisodesButton")
        zoomButton = findText("playerZoomButton")
        settingsButton = findText("playerSettingsButton")
        playerView.useController = false
        playerView.controllerAutoShow = false
        guideOverlay.visibility = View.GONE
        topOverlay.visibility = View.VISIBLE
    }

    private fun findText(name: String): TextView? {
        val id = resources.getIdentifier(name, "id", packageName)
        return if (id == 0) null else findViewById(id)
    }

    private fun bindModeUi() {
        liveTopInfo.visibility = if (isVod) View.GONE else View.VISIBLE
        nowRow.visibility = if (isVod) View.GONE else View.VISIBLE
        nextText.visibility = if (isVod) View.GONE else View.VISIBLE
        vodInfoHero.visibility = if (isVod) View.VISIBLE else View.GONE
        vodControls.visibility = View.VISIBLE
        vodTimeRow.visibility = View.VISIBLE
        titleView.visibility = if (isVod) View.GONE else View.VISIBLE
        metaText.visibility = if (isVod) View.GONE else View.VISIBLE
        audioButton?.visibility = if (isVod) View.VISIBLE else View.GONE
        subtitlesButton?.visibility = if (isVod) View.VISIBLE else View.GONE
        episodesButton?.visibility = if (isVod) View.VISIBLE else View.GONE
        zoomButton?.visibility = if (isVod) View.VISIBLE else View.GONE
        settingsButton?.text = if (isVod) "Settings" else "Timeshift"
        rewindButton?.text = if (isVod) "-10" else "-30"
        forwardButton?.text = if (isVod) "+10" else "+30"
        playPauseButton?.text = "Pause"
        progress.progress = 0
    }

    private fun bindMetadata() {
        val logoUrl = intent.getStringExtra(EXTRA_LOGO_URL).orEmpty()
        val posterUrl = intent.getStringExtra(EXTRA_POSTER_URL).orEmpty()
        val artworkUrl = intent.getStringExtra(EXTRA_ARTWORK_URL).orEmpty()
        val meta = intent.getStringExtra(EXTRA_META_LINE).orEmpty().ifBlank { sourceLabel }
        val mediaMeta = intent.getStringExtra(EXTRA_MEDIA_META_LINE).orEmpty()
        val overview = intent.getStringExtra(EXTRA_OVERVIEW).orEmpty()
        clock.text = timeNow()
        titleView.text = title
        metaText.text = meta
        statusView.text = sourceLabel
        channelBadge.text = channels.getOrNull(currentIndex)?.number?.ifBlank { title.take(8).uppercase(Locale.US) } ?: title.take(8).uppercase(Locale.US)
        nowTime.text = channels.getOrNull(currentIndex)?.nowTime?.ifBlank { "LIVE" } ?: "LIVE"
        nextText.text = "Next: ${channels.getOrNull(currentIndex)?.nextTitle?.ifBlank { "Live programming" } ?: "Live programming"}"
        if (artworkUrl.isNotBlank()) Glide.with(this).load(artworkUrl).diskCacheStrategy(DiskCacheStrategy.AUTOMATIC).centerCrop().into(backdrop)
        val icon = logoUrl.ifBlank { channels.getOrNull(currentIndex)?.iconUrl.orEmpty() }
        if (icon.isNotBlank()) {
            channelLogo.visibility = View.VISIBLE
            Glide.with(this).load(icon).diskCacheStrategy(DiskCacheStrategy.AUTOMATIC).fitCenter().into(channelLogo)
            Glide.with(this).load(icon).diskCacheStrategy(DiskCacheStrategy.AUTOMATIC).fitCenter().into(titleArtwork)
            titleArtwork.visibility = if (isVod) View.VISIBLE else View.GONE
        } else {
            channelLogo.visibility = View.GONE
            titleArtwork.visibility = View.GONE
        }
        if (isVod) {
            vodTitle.text = title
            vodMetaLine.text = listOf(mediaMeta, meta).filter { it.isNotBlank() }.distinct().joinToString(" • ").ifBlank { "Movie / Show" }
            vodRating.text = ratingFrom(vodMetaLine.text.toString())
            vodDescription.text = overview.ifBlank { "Press OK for controls. Subtitles, audio, episodes, zoom, and source settings are available from the control bar." }
            if (posterUrl.isNotBlank()) Glide.with(this).load(posterUrl).diskCacheStrategy(DiskCacheStrategy.AUTOMATIC).centerCrop().into(vodPoster)
            buildBadges(vodMetaLine.text.toString())
        }
    }

    private fun wireControls() {
        rewindButton?.setOnClickListener { seekBack() }
        forwardButton?.setOnClickListener { seekForward() }
        playPauseButton?.setOnClickListener { togglePlayPause() }
        settingsButton?.setOnClickListener { showToast(if (isVod) "Playback settings" else timeshiftOwner.label()) }
        audioButton?.setOnClickListener { showToast("Audio track options") }
        subtitlesButton?.setOnClickListener { showToast("Subtitle options") }
        episodesButton?.setOnClickListener { showToast("Episodes") }
        zoomButton?.setOnClickListener { showToast("Zoom mode") }
    }

    private fun startPlayback(url: String) {
        released = false
        if (!isVod) timeshiftOwner.start(title, url)
        val mode = if (isVod) UnifiedPlayerManager.Mode.VOD else UnifiedPlayerManager.Mode.LIVE
        player = playerOwner.play(playerView, url, mode, muted = false, playWhenReady = true)
        player?.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_READY -> {
                        statusView.text = if (isVod) "Ready" else timeshiftOwner.label()
                        scheduleOverlayHide()
                    }
                    Player.STATE_BUFFERING -> statusView.text = "Buffering"
                    Player.STATE_ENDED -> if (!isVod) seekLiveEdge()
                }
            }
        })
        overlayHandler.post(progressRunnable)
        scheduleOverlayHide()
    }

    private fun seekLiveEdge() {
        val p = player ?: return
        runCatching { p.seekToDefaultPosition() }
        p.playWhenReady = true
        currentTime.text = "LIVE"
        duration.text = timeshiftOwner.label()
    }

    private fun seekBack() {
        val p = player ?: return
        if (isVod) {
            p.seekTo((p.currentPosition - 10_000L).coerceAtLeast(0L))
        } else if (!timeshiftOwner.seekBack(p, 30_000L)) {
            showToast(timeshiftOwner.label())
        }
        showOverlay()
    }

    private fun seekForward() {
        val p = player ?: return
        if (isVod) {
            val dur = if (p.duration > 0) p.duration else Long.MAX_VALUE
            p.seekTo((p.currentPosition + 10_000L).coerceAtMost(dur))
        } else if (!timeshiftOwner.seekForward(p, 30_000L)) {
            seekLiveEdge()
            showToast("Returned to live")
        }
        showOverlay()
    }

    private fun togglePlayPause() {
        val p = player ?: return
        if (p.isPlaying) {
            p.pause()
            playPauseButton?.text = "Play"
        } else {
            p.play()
            playPauseButton?.text = "Pause"
        }
        showOverlay()
    }

    private fun updateProgress() {
        clock.text = timeNow()
        guideClock.text = timeNow()
        val p = player ?: return
        if (isVod) {
            val dur = p.duration.takeIf { it > 0 } ?: 0L
            val pos = p.currentPosition.coerceAtLeast(0L)
            currentTime.text = formatDuration(pos)
            duration.text = if (dur > 0) formatDuration(dur) else "--:--"
            progress.progress = if (dur > 0) ((pos * 100L) / dur).toInt().coerceIn(0, 100) else 0
        } else {
            currentTime.text = "LIVE"
            duration.text = timeshiftOwner.label()
            progress.progress = 100
        }
    }

    private fun renderGuideOverlay() {
        guideList.removeAllViews()
        if (channels.isEmpty()) return
        channels.forEachIndexed { index, channel ->
            val row = TextView(this)
            row.text = listOf(channel.number, channel.name, channel.nowTitle).filter { it.isNotBlank() }.joinToString("  •  ")
            row.textSize = 18f
            row.maxLines = 1
            row.ellipsize = TextUtils.TruncateAt.END
            row.gravity = android.view.Gravity.CENTER_VERTICAL
            row.setPadding(dp(14), 0, dp(14), 0)
            row.setOnClickListener { selectedIndex = index; switchChannel(index) }
            guideList.addView(row, LinearLayout.LayoutParams(dp(540), dp(54)))
        }
        updateGuideSelection()
    }

    private fun updateGuideSelection() {
        for (i in 0 until guideList.childCount) {
            val row = guideList.getChildAt(i) as TextView
            val active = i == selectedIndex
            row.setTextColor(if (active) 0xFFFFFFFF.toInt() else 0xCCFFFFFF.toInt())
            row.setBackgroundResource(if (active) R.drawable.guide_row_selected else R.drawable.guide_row_bg)
        }
        channels.getOrNull(selectedIndex)?.let { ch ->
            guideTitle.text = ch.name
            guideMeta.text = listOf(ch.source, ch.nowTitle).filter { it.isNotBlank() }.joinToString(" • ")
            guideInfoLogo.text = ch.number.ifBlank { ch.name.take(3).uppercase(Locale.US) }
        }
        guideScroller.smoothScrollTo((selectedIndex - 1).coerceAtLeast(0) * dp(540), 0)
    }

    private fun showGuideOverlay() {
        if (channels.isEmpty() || isVod) return
        selectedIndex = currentIndex
        updateGuideSelection()
        guideOverlay.visibility = View.VISIBLE
        guideMode.text = "Live Guide"
        guideHint.text = "Left/Right channels • OK switch • Back closes guide"
        topOverlay.visibility = View.VISIBLE
        overlayHandler.removeCallbacks(hideGuideRunnable)
        overlayHandler.postDelayed(hideGuideRunnable, 7000L)
    }

    private fun hideGuideOverlay() {
        guideOverlay.visibility = View.GONE
        scheduleOverlayHide()
    }

    private fun switchChannel(index: Int) {
        val ch = channels.getOrNull(index) ?: return
        if (ch.url.isBlank()) return
        currentIndex = index
        selectedIndex = index
        title = ch.name
        sourceLabel = ch.source
        streamUrl = ch.url
        bindMetadata()
        updateGuideSelection()
        timeshiftOwner.stop("switch-channel")
        playerOwner.release("switch-channel")
        startPlayback(ch.url)
        hideGuideOverlay()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                if (guideOverlay.isVisible) switchChannel(selectedIndex) else showOverlay()
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (guideOverlay.isVisible) { selectedIndex = (selectedIndex - 1).coerceAtLeast(0); updateGuideSelection() } else seekBack()
                return true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (guideOverlay.isVisible) { selectedIndex = (selectedIndex + 1).coerceAtMost((channels.size - 1).coerceAtLeast(0)); updateGuideSelection() } else seekForward()
                return true
            }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (!isVod) showGuideOverlay() else showOverlay()
                return true
            }
            KeyEvent.KEYCODE_BACK -> {
                if (guideOverlay.isVisible) { hideGuideOverlay(); return true }
                finishCleanly(); return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun showOverlay() {
        topOverlay.visibility = View.VISIBLE
        scheduleOverlayHide()
    }

    private fun scheduleOverlayHide() {
        overlayHandler.removeCallbacks(hideOverlayRunnable)
        overlayHandler.postDelayed(hideOverlayRunnable, 5000L)
    }

    private fun buildBadges(meta: String) {
        vodBadgeRow.removeAllViews()
        meta.split("•").map { it.trim() }.filter { it.isNotBlank() }.take(5).forEach { badge ->
            val tv = TextView(this)
            tv.text = badge
            tv.setTextColor(0xFFFFFFFF.toInt())
            tv.textSize = 13f
            tv.setPadding(dp(12), dp(5), dp(12), dp(5))
            tv.setBackgroundResource(R.drawable.chip_bg)
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 0, dp(8), 0)
            vodBadgeRow.addView(tv, lp)
        }
    }

    private fun decodeChannels(raw: String?): List<GuideChannel> {
        if (raw.isNullOrBlank()) return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            List(arr.length()) { i ->
                val obj = arr.optJSONObject(i)
                GuideChannel(
                    name = obj?.optString("name").orEmpty(),
                    url = obj?.optString("url").orEmpty(),
                    source = obj?.optString("source").orEmpty(),
                    debug = obj?.optString("debug").orEmpty(),
                    number = obj?.optString("number").orEmpty(),
                    iconUrl = obj?.optString("iconUrl").orEmpty(),
                    group = obj?.optString("group").orEmpty(),
                    nowTitle = obj?.optString("nowTitle").orEmpty(),
                    nowTime = obj?.optString("nowTime").orEmpty(),
                    nextTitle = obj?.optString("nextTitle").orEmpty()
                )
            }
        }.getOrElse { emptyList() }
    }

    private fun ratingFrom(meta: String): String {
        val rating = Regex("(\\d(?:\\.\\d)?)").find(meta)?.value ?: "7.0"
        return "★★★★☆  $rating"
    }

    private fun formatDuration(ms: Long): String {
        val total = (ms / 1000L).coerceAtLeast(0L)
        val h = total / 3600L
        val m = (total % 3600L) / 60L
        val s = total % 60L
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
    }

    private fun timeNow(): String = SimpleDateFormat("h:mm a", Locale.US).format(Date())
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()
    private fun showToast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    @Deprecated("Back dispatch compatibility")
    override fun onBackPressed() { finishCleanly() }

    override fun onPause() {
        player?.playWhenReady = false
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (!released) player?.playWhenReady = true
    }

    override fun onStop() {
        releaseEverything("stop")
        super.onStop()
    }

    override fun onDestroy() {
        releaseEverything("destroy")
        super.onDestroy()
    }

    private fun finishCleanly() {
        if (finishRequested || isFinishing) return
        finishRequested = true
        setResult(RESULT_OK)
        finish()
    }

    private fun releaseEverything(reason: String) {
        if (released) return
        released = true
        overlayHandler.removeCallbacksAndMessages(null)
        timeshiftOwner.stop(reason)
        playerOwner.release(reason)
        player = null
        Log.i("DebridChannels", "PlayerActivity released reason=$reason")
    }

    data class GuideChannel(
        val name: String,
        val url: String,
        val source: String,
        val debug: String = "",
        val number: String = "",
        val iconUrl: String = "",
        val group: String = "",
        val nowTitle: String = "",
        val nowTime: String = "",
        val nextTitle: String = ""
    )

    companion object {
        const val EXTRA_STREAM_URL = "stream_url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_MEDIA_TYPE = "media_type"
        const val EXTRA_EXTERNAL_ID = "external_id"
        const val EXTRA_SOURCE_LABEL = "source_label"
        const val EXTRA_ARTWORK_URL = "artwork_url"
        const val EXTRA_LOGO_URL = "logo_url"
        const val EXTRA_POSTER_URL = "poster_url"
        const val EXTRA_META_LINE = "meta_line"
        const val EXTRA_MEDIA_META_LINE = "media_meta_line"
        const val EXTRA_OVERVIEW = "overview"
        const val EXTRA_DEBUG_LABEL = "debug_label"
        const val EXTRA_CHANNELS_JSON = "channels_json"
        const val EXTRA_CHANNEL_INDEX = "channel_index"
        const val EXTRA_VOD_MODE = "vod_mode"
    }
}
