# Debrid Channels v4.1.0 Architecture Lock

This build is an enforcement pass on the v4 fresh rebuild.

## Build marker
- `V4_1_ARCHITECTURE_LOCK_START`

## Version
- versionName: `4.1.0-architecture-lock`
- versionCode: `101`

## Enforcement changes
- MainActivity internal navigation now routes through `AppNavigationController` instead of direct `startActivity()` calls.
- `AppNavigationController` now has duplicate launch and duplicate finish guards.
- PlayerActivity now guards `finishCleanly()` so back/DPAD repeat cannot request multiple finishes.
- UnifiedPlayerManager user agent updated to v4.1 architecture lock marker.
- Existing guide look, VOD player artwork/ratings/poster UI, and backend/API contract preserved.
