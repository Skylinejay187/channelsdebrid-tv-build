package com.channelsdebrid.tv

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val density = resources.displayMetrics.density
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        }
        val glow = View(this).apply {
            layoutParams = FrameLayout.LayoutParams((420 * density).toInt(), (420 * density).toInt(), Gravity.CENTER)
            alpha = 0f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x3325A7FF)
            }
        }
        val logo = ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            alpha = 0f
            scaleX = 0.86f
            scaleY = 0.86f
            layoutParams = FrameLayout.LayoutParams((132 * density).toInt(), (132 * density).toInt(), Gravity.CENTER).apply {
                bottomMargin = (40 * density).toInt()
            }
        }
        val title = TextView(this).apply {
            text = getString(R.string.app_name)
            setTextColor(Color.WHITE)
            textSize = 28f
            letterSpacing = 0.08f
            gravity = Gravity.CENTER
            alpha = 0f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER).apply {
                topMargin = (170 * density).toInt()
            }
        }
        root.addView(glow)
        root.addView(logo)
        root.addView(title)
        setContentView(root)

        AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(glow, View.ALPHA, 0f, 1f),
                ObjectAnimator.ofFloat(glow, View.SCALE_X, 0.65f, 1.2f),
                ObjectAnimator.ofFloat(glow, View.SCALE_Y, 0.65f, 1.2f),
                ObjectAnimator.ofFloat(logo, View.ALPHA, 0f, 1f),
                ObjectAnimator.ofFloat(logo, View.SCALE_X, 0.86f, 1f),
                ObjectAnimator.ofFloat(logo, View.SCALE_Y, 0.86f, 1f),
                ObjectAnimator.ofFloat(title, View.ALPHA, 0f, 1f)
            )
            duration = 900L
            start()
        }
        handler.postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 1650L)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
