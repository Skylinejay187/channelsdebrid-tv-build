#!/usr/bin/env python3
"""Stage the complete unmodified F143 production Swift source into a Skip Fuse app.
No source filtering, extraction, shims, or fabricated compilation success.
"""
import argparse, hashlib, json, pathlib, shutil, sys
p=argparse.ArgumentParser()
p.add_argument('--checkpoint-root',type=pathlib.Path,required=True)
p.add_argument('--skip-project',type=pathlib.Path,required=True)
p.add_argument('--diagnostics',type=pathlib.Path,required=True)
a=p.parse_args()
root=a.checkpoint_root/'reference/apple-original/Sources'
assert root.is_dir(), f'Missing original production sources: {root}'
manifest=json.loads((a.checkpoint_root/'reference/apple-original-manifest.json').read_text())
for rel,sha in manifest['files'].items():
    f=a.checkpoint_root/rel
    if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest()!=sha:
        sys.exit(f'Integrity failure: {rel}')
source_files=sorted(root.rglob('*.swift'))
if len(source_files)<100:sys.exit(f'Expected complete production source; found {len(source_files)}')
project_sources=a.skip_project/'Sources'
modules=[x for x in project_sources.iterdir() if x.is_dir() and x.name == 'SignalF143Fuse']
if len(modules)!=1:
    sys.exit(f'Expected one Skip Fuse source module; found {modules}')
dst=modules[0]
# Do not overwrite Skip-generated entry or templates; original entry is preserved as-is.
# Compiling all originals intentionally exposes duplicate entry points, missing imports,
# and tvOS-only dependencies as genuine blockers for the next repair phase.
for f in source_files:
    relative=f.relative_to(root)
    out=dst/'F143Original'/relative
    out.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(f,out)
report={'source_files_staged':len(source_files),'source_bytes':sum(x.stat().st_size for x in source_files),'original_app_entry':str(dst/'F143Original/DebridChannelsTVOSApp.swift'),'skip_module':str(dst),'full_original_source_unmodified':True,'build_status':'NOT_RUN'}
a.diagnostics.mkdir(parents=True,exist_ok=True)
(a.diagnostics/'full-source-stage.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
