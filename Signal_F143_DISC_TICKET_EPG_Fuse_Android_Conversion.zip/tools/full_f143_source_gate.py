#!/usr/bin/env python3
"""Fail-closed F143 production Swift inventory and full-source staging gate.
Does NOT claim compilation or automatically replace Apple frameworks.
"""
import argparse, pathlib, re, json, collections, shutil, hashlib
p=argparse.ArgumentParser();p.add_argument('--root',default='reference/apple-original/Sources');p.add_argument('--output',default='full-f143-gate');a=p.parse_args()
root=pathlib.Path(a.root);out=pathlib.Path(a.output)
if not root.is_dir():raise SystemExit('Missing F143 original Sources directory')
files=sorted(root.rglob('*.swift'))
if len(files)<100:raise SystemExit(f'Incomplete original production source: {len(files)} Swift files')
out.mkdir(parents=True,exist_ok=True)
records=[];imports=collections.Counter();blocked=[]
unsupported={'UIKit','AVKit','AVFoundation','TVServices','QuartzCore','CoreVideo','CoreImage','ImageIO','MediaPlayer','UserNotifications','Security','Darwin','Network','Kingfisher'}
for f in files:
 s=f.read_text(errors='replace'); im=sorted(set(re.findall(r'(?m)^\s*import\s+([A-Za-z_][A-Za-z_0-9]*)',s)))
 imports.update(im); conflicts=sorted(set(im)&unsupported)
 rec={'file':str(f.relative_to(root)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'imports':im,'apple_or_external_dependencies':conflicts,'entrypoint_candidate':'@main' in s or 'struct DebridChannelsTVOSApp' in s}
 records.append(rec)
 if conflicts:blocked.append(rec)
report={'source_files':len(files),'source_bytes':sum(r['bytes'] for r in records),'imports':dict(imports.most_common()),'files':records,'files_requiring_platform_adapter':len(blocked),'note':'Dependency inventory only; NOT a successful Skip compile or app conversion'}
(out/'source-inventory.json').write_text(json.dumps(report,indent=2))
(out/'README.txt').write_text(f"F143 original production source files: {len(files)}\nFiles importing Apple/external platform APIs: {len(blocked)}\nNo source silently omitted. This is a full-source intake gate, not an APK.\n")
print(json.dumps({'source_files':len(files),'platform_dependency_files':len(blocked),'largest_files':sorted([(r['file'],r['bytes']) for r in records],key=lambda x:-x[1])[:8]},indent=2))
