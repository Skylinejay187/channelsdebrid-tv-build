# Full F143 Swift source intake gate

This checkpoint replaces two-file-only scope with an inventory of every Swift file in the original production `Sources` directory. The source itself is retained unchanged. Run `python3 tools/full_f143_source_gate.py --root reference/apple-original/Sources --output full-f143-gate` to reproduce. The output lists every source hash, imports, and platform-only dependencies.

**This is not a complete conversion or a successful build.** The original tvOS entry point is a multi-megabyte SwiftUI source importing AVFoundation, UIKit, and TVServices. A native Android compilation must first supply compatible platform adapters or refactor conditional imports. No existing Android APK or visual layout is changed by this gate.
