F143 original production source files: 125
Files importing Apple/external platform APIs: 30
No source silently omitted. This is a full-source intake gate, not an APK.
