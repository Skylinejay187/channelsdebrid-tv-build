# Checkpoint 52 — F143 Skip Lite runtime integration

## Changes
- Preserves all Checkpoint 51 app and Apple master Swift sources.
- Adds `SkipGeneratedUnityPolicy.kt` based on the actual Skip Lite export `UnitySurfaceSystem.kt` (SHA256 a671489bdb709a9935f41e77de40495632bd7f7697893d710382212ae279355b).
- Maps Skip-generated internal AppTab names to the existing Android public AppTab enum, removes imported Skip/Foundation runtime interface dependencies, and retains exact generated rules including sports background residency distinction.
- Changes the existing `UnitySurfacePolicy` public API to delegate runtime decisions to this adapter. Existing `DebridChannelsApp` reads that public API, so Live TV visibility and Back policy are now executed through the adapted Skip-generated policy.
- Preserves both original generated Kotlin sources under reference/skip-generated for auditing.
- Adds regression test for all eight cases.

## Not yet integrated
- The Fuse output `SignalPlayerFuse-debug.aar` has no callable public Swift/Kotlin bridge. Do not copy it into the Android application without fixing that bridge and dependency closure.
- SwiftUI catalog visuals and 3D artwork have not yet been converted.
- There is no validated replacement for Android APK build in this checkpoint.
- This checkpoint integrates F143 converted **policy logic** only, not an entire Skip Hybrid app.

## Verification
- Kotlin JVM compilation of AppModels.kt, SkipGeneratedUnityPolicy.kt and UnitySurfacePolicy.kt should be run locally.
- GitHub Android APK must still build and be tested on-device; NOT verified here.

## Slogan
“Our app is Unity, not separate screens.”
