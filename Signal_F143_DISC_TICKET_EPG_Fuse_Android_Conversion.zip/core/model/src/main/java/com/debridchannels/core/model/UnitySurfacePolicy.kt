package com.debridchannels.core.model

/** Public Android API backed by the F143 policy translated by Skip Lite. */
object UnitySurfacePolicy {
    enum class Role { LIVE_ROOT, CATALOG_BRANCH, SPORTS_BRANCH, DEDICATED_SURFACE }
    data class RuntimePolicy(
        val stateResident: Boolean,
        val pixelsResidentWhenCovered: Boolean,
        val backgroundWorkWhenCovered: Boolean,
        val ownsGlobalTopNavigation: Boolean
    )
    fun role(tab: AppTab): Role = Role.valueOf(SkipGeneratedUnityPolicy.role(tab).name)
    fun runtimePolicy(tab: AppTab): RuntimePolicy = SkipGeneratedUnityPolicy.runtimePolicy(tab).let {
        RuntimePolicy(it.stateResident, it.pixelsResidentWhenCovered, it.backgroundWorkWhenCovered, it.ownsGlobalTopNavigation)
    }
    fun keepsLiveTVRootMounted(tab: AppTab) = SkipGeneratedUnityPolicy.keepsLiveTVRootMounted(tab)
    fun shouldCompositeLiveTVRoot(tab: AppTab) = SkipGeneratedUnityPolicy.shouldCompositeLiveTVRoot(tab)
    fun catalogBranchActive(tab: AppTab) = SkipGeneratedUnityPolicy.catalogBranchActive(tab)
    fun quickPanelBranchActive(tab: AppTab) = SkipGeneratedUnityPolicy.quickPanelBranchActive(tab)
    fun backDestination(tab: AppTab) = SkipGeneratedUnityPolicy.backDestination(tab)
}
