package com.debridchannels.core.model

/**
 * F143 Skip Lite Unity policy adapter.
 * Rules taken directly from generated-kotlin/UnitySurfaceSystem.kt produced by Skip.
 * Source SHA-256: a671489bdb709a9935f41e77de40495632bd7f7697893d710382212ae279355b
 *
 * Skip emitted internal symbols and Skip/Foundation runtime interfaces. This Android
 * adapter maps the original eight AppTab cases to the existing public AppTab enum,
 * removes the unused foreign runtime interfaces, and retains the generated branches.
 * It is NOT a conversion of the SwiftUI views or an integration of the Fuse library.
 */
internal object SkipGeneratedUnityPolicy {
    enum class Role { LIVE_ROOT, CATALOG_BRANCH, SPORTS_BRANCH, DEDICATED_SURFACE }
    data class RuntimePolicy(
        val stateResident: Boolean,
        val pixelsResidentWhenCovered: Boolean,
        val backgroundWorkWhenCovered: Boolean,
        val ownsGlobalTopNavigation: Boolean
    )

    fun role(tab: AppTab): Role = when (tab) {
        AppTab.LIVE_TV -> Role.LIVE_ROOT
        AppTab.HOME, AppTab.MOVIES, AppTab.SHOWS -> Role.CATALOG_BRANCH
        AppTab.SPORTS -> Role.SPORTS_BRANCH
        AppTab.FAVORITES, AppTab.MEMBERSHIP, AppTab.SETTINGS -> Role.DEDICATED_SURFACE
    }

    fun runtimePolicy(tab: AppTab): RuntimePolicy = when (tab) {
        AppTab.LIVE_TV -> RuntimePolicy(true, true, false, true)
        AppTab.HOME, AppTab.MOVIES, AppTab.SHOWS -> RuntimePolicy(true, true, false, true)
        AppTab.SPORTS, AppTab.FAVORITES, AppTab.MEMBERSHIP, AppTab.SETTINGS -> RuntimePolicy(true, false, false, true)
    }

    fun keepsLiveTVRootMounted(tab: AppTab): Boolean = runtimePolicy(tab).stateResident
    fun shouldCompositeLiveTVRoot(tab: AppTab): Boolean = when (role(tab)) {
        Role.LIVE_ROOT, Role.CATALOG_BRANCH, Role.SPORTS_BRANCH -> true
        Role.DEDICATED_SURFACE -> false
    }
    fun catalogBranchActive(tab: AppTab): Boolean = role(tab) == Role.CATALOG_BRANCH
    fun quickPanelBranchActive(tab: AppTab): Boolean = when (role(tab)) {
        Role.CATALOG_BRANCH, Role.SPORTS_BRANCH -> true
        Role.LIVE_ROOT, Role.DEDICATED_SURFACE -> false
    }
    fun backDestination(tab: AppTab): AppTab = when (role(tab)) {
        Role.CATALOG_BRANCH, Role.SPORTS_BRANCH -> AppTab.LIVE_TV
        Role.LIVE_ROOT, Role.DEDICATED_SURFACE -> tab
    }
}
