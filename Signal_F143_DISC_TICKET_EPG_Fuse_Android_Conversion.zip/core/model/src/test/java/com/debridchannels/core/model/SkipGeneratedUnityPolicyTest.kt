package com.debridchannels.core.model

import org.junit.Assert.*
import org.junit.Test

/** These assertions cover the original F143 rules rather than comparing two aliases. */
class SkipGeneratedUnityPolicyTest {
    @Test fun generatedRulesForEveryOriginalTab() {
        val live = setOf(AppTab.LIVE_TV, AppTab.HOME, AppTab.MOVIES, AppTab.SHOWS)
        val composited = live + AppTab.SPORTS
        val quickPanel = setOf(AppTab.HOME, AppTab.MOVIES, AppTab.SHOWS, AppTab.SPORTS)
        for (tab in AppTab.entries) {
            val p = SkipGeneratedUnityPolicy.runtimePolicy(tab)
            assertTrue(p.stateResident)
            assertEquals(tab in live, p.pixelsResidentWhenCovered)
            assertFalse(p.backgroundWorkWhenCovered)
            assertTrue(p.ownsGlobalTopNavigation)
            assertEquals(tab in composited, SkipGeneratedUnityPolicy.shouldCompositeLiveTVRoot(tab))
            assertEquals(tab in quickPanel, SkipGeneratedUnityPolicy.quickPanelBranchActive(tab))
            assertEquals(tab in setOf(AppTab.HOME, AppTab.MOVIES, AppTab.SHOWS), SkipGeneratedUnityPolicy.catalogBranchActive(tab))
            assertEquals(if (tab in quickPanel) AppTab.LIVE_TV else tab, SkipGeneratedUnityPolicy.backDestination(tab))
        }
    }
}
