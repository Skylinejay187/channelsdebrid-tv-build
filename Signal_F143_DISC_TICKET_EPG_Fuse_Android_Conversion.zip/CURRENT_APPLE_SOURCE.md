# Signal Apple TV source baseline

Source ZIP: `Signal_F143_1252_DISC_TICKET_GEOMETRY_EPG_SOURCE_RECOVERY.zip`
SHA-256: `c9be4c522f40cb6725fe185f62099bbd56c3cce5990a2aaf0a261d6f55fe78f7`
Original production Swift files: 126
Changed files from previous F143 intake: 12

Original source is staged without rewriting. GitHub workflow patches temporary copies for Skip compatibility, then compiles and exports if possible. This package does not contain an APK.
