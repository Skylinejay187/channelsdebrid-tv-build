import Foundation
import UIKit
import Combine
import Network
import Darwin
import os.signpost

/// Bounded diagnostic telemetry: fixed event identifiers and numeric measurements only.
/// Never record URLs, title names, request headers, credentials, or provider payloads.
@MainActor
final class SignalDiagnosticCenter: ObservableObject {
    static let shared = SignalDiagnosticCenter()
    struct Event: Codable {
        let at: Date
        let area: String
        let action: String
        let state: String
        let value: Double?
        // Allowlisted numeric interpretation; never provider or viewing identifiers.
        let metric: String?
    }
    @Published private(set) var recording = false
    @Published private(set) var eventCount = 0
    @Published private(set) var exportAddress = ""
    @Published private(set) var exportStatus = "No export session"
    private var events: [Event] = []
    private let maxEvents = 2400
    private var listener: NWListener?
    private var token = ""
    private var exportDeadline: Date = .distantPast
    private var exportData = Data()
    private var exportGeneration = UUID()
    private var expirationTimer: DispatchSourceTimer?
    private var monitoringTokens: [NSObjectProtocol] = []
    private var performanceText = "Not recorded"
    private var lastBufferSampleAt: TimeInterval = 0
    private var lastTimeSampleAt: TimeInterval = 0
    private var currentPlayhead: Double = 0
    private var currentDuration: Double = 0
    private var lastFrontier: Double = -1
    private var lastFrontierAdvanceAt: TimeInterval = 0
    private var lastStallAlertAt: TimeInterval = 0
    private var buffering = false
    private var resourceSampler: Task<Void, Never>?
    private static let performanceLog = OSLog(subsystem: "Signal", category: "Diagnostics")
    private let metrics: Set<String> = ["buffer_frontier_seconds", "playhead_seconds", "duration_seconds", "ahead_seconds", "coverage_percent", "forward_segment_target", "buffer_stall_seconds", "free_disk_bytes", "thermal_level", "low_power_mode", "memory_warning_count", "true_cached_bytes_available", "elapsed_seconds"]


    private let areas: Set<String> = ["playback", "cache", "preview", "artwork", "guide", "trakt", "usenet", "sports", "api", "app", "performance", "selftest"]
    private let actions: Set<String> = ["start", "stop", "success", "failure", "timeout", "retry", "stall", "buffer", "progress", "handoff", "refresh", "request", "response", "cancel", "loaded", "empty", "selfcheck", "snapshot"]
    private let states: Set<String> = ["ok", "error", "waiting", "active", "idle", "cached", "missing", "off", "on", "unknown"]

    func start() {
        stopExport()
        events.removeAll(keepingCapacity: true)
        eventCount = 0
        recording = true
        currentPlayhead = 0; currentDuration = 0; lastFrontier = -1
        lastFrontierAdvanceAt = ProcessInfo.processInfo.systemUptime
        lastStallAlertAt = 0
        attachAetherObservers()
        sampleResources()
        resourceSampler = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 15_000_000_000)
                guard !Task.isCancelled, let self, self.recording else { break }
                self.sampleResources()
                self.checkForCacheStall()
            }
        }
        mark("app", "start", "active")
    }
    func stop() {
        mark("app", "stop", "idle")
        recording = false
        resourceSampler?.cancel(); resourceSampler = nil
        for token in monitoringTokens { NotificationCenter.default.removeObserver(token) }
        monitoringTokens.removeAll()
    }

    func attachPerformanceReport(_ report: String) {
        // Performance trace has no viewing identifiers, URLs or credentials by design.
        performanceText = String(report.prefix(100_000))
    }

    private func attachAetherObservers() {
        for token in monitoringTokens { NotificationCenter.default.removeObserver(token) }
        monitoringTokens.removeAll()
        lastBufferSampleAt = 0
        lastTimeSampleAt = 0
        let center = NotificationCenter.default
        monitoringTokens.append(center.addObserver(forName: Notification.Name("DebridChannels.Aether.buffer"), object: nil, queue: nil) { [weak self] notification in
            let value = (notification.userInfo?["buffered"] as? NSNumber)?.doubleValue
            let duration = (notification.userInfo?["duration"] as? NSNumber)?.doubleValue
            Task { @MainActor [weak self] in
                guard let self, self.recording, let value, value.isFinite else { return }
                let now = ProcessInfo.processInfo.systemUptime
                if value > self.lastFrontier + 0.25 {
                    self.lastFrontierAdvanceAt = now
                    self.lastFrontier = value
                }
                if let duration, duration.isFinite, duration > 0 { self.currentDuration = duration }
                guard now - self.lastBufferSampleAt >= 2 else { return }
                self.lastBufferSampleAt = now
                self.metric("cache", "buffer_frontier_seconds", value)
                self.metric("cache", "ahead_seconds", max(0, value - self.currentPlayhead))
                if self.currentDuration > 0 {
                    self.metric("cache", "coverage_percent", min(100, max(0, 100 * value / self.currentDuration)))
                }
                self.checkForCacheStall()
            }
        })
        monitoringTokens.append(center.addObserver(forName: Notification.Name("DebridChannels.Aether.time"), object: nil, queue: nil) { [weak self] notification in
            let position = (notification.userInfo?["current"] as? NSNumber)?.doubleValue
            let duration = (notification.userInfo?["duration"] as? NSNumber)?.doubleValue
            Task { @MainActor [weak self] in
                guard let self, self.recording else { return }
                if let position, position.isFinite { self.currentPlayhead = max(0, position) }
                if let duration, duration.isFinite, duration > 0 { self.currentDuration = duration }
                let now = ProcessInfo.processInfo.systemUptime
                guard now - self.lastTimeSampleAt >= 5 else { return }
                self.lastTimeSampleAt = now
                self.metric("playback", "playhead_seconds", self.currentPlayhead)
                if self.currentDuration > 0 { self.metric("playback", "duration_seconds", self.currentDuration) }
            }
        })
        monitoringTokens.append(center.addObserver(forName: Notification.Name("Signal.Aether.ForwardCacheTarget"), object: nil, queue: nil) { [weak self] notification in
            let segments = (notification.userInfo?["segments"] as? NSNumber)?.doubleValue
            Task { @MainActor [weak self] in
                guard let self, let segments else { return }
                self.currentPlayhead = 0; self.currentDuration = 0
                self.lastFrontier = -1
                self.lastFrontierAdvanceAt = ProcessInfo.processInfo.systemUptime
                self.metric("cache", "forward_segment_target", segments)
            }
        })
        monitoringTokens.append(center.addObserver(forName: Notification.Name("DebridChannels.Aether.buffering"), object: nil, queue: nil) { [weak self] notification in
            let buffering = notification.userInfo?["isBuffering"] as? Bool ?? false
            Task { @MainActor [weak self] in self?.buffering = buffering; self?.mark("playback", "buffer", buffering ? "waiting" : "ok") }
        })
        monitoringTokens.append(center.addObserver(forName: Notification.Name("DebridChannels.Aether.failure"), object: nil, queue: nil) { [weak self] _ in
            Task { @MainActor [weak self] in self?.mark("playback", "failure", "error") }
        })
        monitoringTokens.append(center.addObserver(forName: UIApplication.didReceiveMemoryWarningNotification, object: nil, queue: nil) { [weak self] _ in
            Task { @MainActor [weak self] in
                self?.metric("performance", "memory_warning_count", 1, state: "error")
                os_signpost(.event, log: Self.performanceLog, name: "SignalMemoryWarning")
            }
        })
        for (notificationName, area, action, state) in [
            ("DebridChannels.Aether.firstFrame", "playback", "success", "ok"),
            ("DebridChannels.Aether.ended", "playback", "stop", "idle"),
            ("DebridChannels.Aether.liveReset", "playback", "retry", "waiting"),
            ("DebridChannels.TrailerExclusivePlaybackDidBegin", "preview", "start", "active"),
            ("DebridChannels.TrailerExclusivePlaybackDidEnd", "preview", "stop", "idle"),
            ("SignalProtectedHomeRouteRevoked", "api", "failure", "error"),
        ] {
            monitoringTokens.append(center.addObserver(forName: Notification.Name(notificationName), object: nil, queue: nil) { [weak self] _ in
                Task { @MainActor [weak self] in self?.mark(area, action, state) }
            })
        }
    }

    func metric(_ area: String, _ key: String, _ value: Double, state: String = "ok") {
        guard metrics.contains(key) else { return }
        mark(area, "snapshot", state, value: value, metric: key)
    }

    private func checkForCacheStall() {
        let now = ProcessInfo.processInfo.systemUptime
        guard recording, lastFrontier >= 0, currentDuration > 0,
              lastFrontier < currentDuration - 15,
              !buffering, currentPlayhead < currentDuration - 15 else { return }
        let stalledFor = now - lastFrontierAdvanceAt
        guard stalledFor >= 30, now - lastStallAlertAt >= 30 else { return }
        lastStallAlertAt = now
        metric("cache", "buffer_stall_seconds", stalledFor, state: "waiting")
        os_signpost(.event, log: Self.performanceLog, name: "SignalCacheFrontierStall")
    }

    private func sampleResources() {
        guard recording else { return }
        let path = URL(fileURLWithPath: NSHomeDirectory())
        let free = (try? path.resourceValues(forKeys: [.volumeAvailableCapacityKey]).volumeAvailableCapacity) ?? -1
        if free >= 0 { metric("cache", "free_disk_bytes", Double(free)) }
        metric("performance", "thermal_level", Double(ProcessInfo.processInfo.thermalState.rawValue))
        metric("performance", "low_power_mode", ProcessInfo.processInfo.isLowPowerModeEnabled ? 1 : 0)
    }

    func mark(_ area: String, _ action: String, _ state: String, value: Double? = nil, metric: String? = nil) {
        guard recording, areas.contains(area), actions.contains(action), states.contains(state) else { return }
        let safeValue = value.flatMap { $0.isFinite ? min(1.0e12, max(-1.0e12, $0)) : nil }
        events.append(Event(at: Date(), area: area, action: action, state: state, value: safeValue, metric: metric))
        if events.count > maxEvents { events.removeFirst(events.count - maxEvents) }
        eventCount = events.count
    }

    func selfCheck() {
        let defaults = UserDefaults.standard
        for key in ["tmdbApiKey", "fanartTvApiKey", "omdbApiKey", "tvdbToken"] {
            // Never retain raw values or expose whether a particular key's bytes match.
            mark("api", "selfcheck", (defaults.string(forKey: key) ?? "").isEmpty ? "missing" : "ok")
        }
        let free = (try? URL(fileURLWithPath: NSHomeDirectory()).resourceValues(forKeys: [.volumeAvailableCapacityKey]).volumeAvailableCapacity) ?? -1
        mark("cache", "selfcheck", free >= 0 ? "ok" : "unknown", value: free >= 0 ? Double(free) : nil)
        mark("app", "selfcheck", "ok")
        // Do not infer stored bytes from buffered seconds or a segment-window count.
        mark("cache", "selfcheck", "unknown")
    }

    func report() -> String {
        let groups = Dictionary(grouping: events, by: { $0.area })
        return (["Signal diagnostic session", "Recording: \(recording ? "On" : "Off")", "Events: \(events.count)", "Collection is opt-in, bounded and excludes viewing titles, URLs and credentials."] + groups.keys.sorted().map { "\($0): \(groups[$0]?.count ?? 0) events" }).joined(separator: "\n")
    }

    private func makeArchive() -> Data? {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        let summary: [String: String] = [
            "schema": "signal-diagnostics-v2",
            "aether_cache_bytes_available": "false",
            "measurement_note": "buffer frontier is temporal coverage; no actual cache bytes reported",
            "app_version": Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "unknown",
            "build": Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "unknown",
            "recording": recording ? "on" : "off",
            "event_count": String(events.count),
            "privacy": "Allowlisted categories, action, state and numeric values only. No source titles, URLs, tokens or account identifiers."
        ]
        guard let timeline = try? encoder.encode(events), let metadata = try? encoder.encode(summary) else { return nil }
        let performanceSummary = """
        Timeline values are engine-reported buffer coverage in SECONDS, not verified disk bytes.
        forward_segment_target is a requested Aether window, NOT a byte quota.
        This engine boundary does not expose true_cached_bytes; no storage-completion
        claim can be made from a coverage_percent value. free_disk_bytes is device
        free capacity, NOT the amount cached. Missing metrics are unavailable.
        Performance trace comes from the existing frame pacing HUD.
        No viewing titles, URLs, or credentials are exported.

        """
        return SignalDiagnosticZip.make(files: [
            ("manifest.json", metadata),
            ("session_timeline.json", timeline),
            ("performance_trace.txt", Data(performanceText.utf8)),
            ("diagnostics_summary.json", (try? encoder.encode(makeSummary())) ?? Data("{}".utf8)),
            ("README.txt", Data(performanceSummary.utf8))
        ])
    }

    private func makeSummary() -> [String: Double] {
        let numerical = events.compactMap { event -> (String, Double)? in
            guard let metric = event.metric, let value = event.value else { return nil }
            return (metric, value)
        }
        var summary: [String: Double] = [:]
        for (metric, value) in numerical { summary[metric + "_latest"] = value }
        summary["event_count"] = Double(events.count)
        summary["cache_stall_events"] = Double(events.filter { $0.metric == "buffer_stall_seconds" }.count)
        summary["memory_warning_events"] = Double(events.filter { $0.metric == "memory_warning_count" }.count)
        return summary
    }

    /// Explicit local-network share. A fresh unpredictable URL expires after ten minutes.
    /// No automated uploads or third-party analytics are performed.
    func startExport() {
        stopExport()
        guard let archive = makeArchive(), archive.count <= 4_000_000 else {
            exportStatus = "Report creation failed or exceeded 4 MB."
            return
        }
        exportData = archive
        let generation = UUID()
        exportGeneration = generation
        token = UUID().uuidString.replacingOccurrences(of: "-", with: "") + UUID().uuidString.replacingOccurrences(of: "-", with: "")
        exportDeadline = Date().addingTimeInterval(600)
        do {
            let ip = localAddress()
            guard ip != "127.0.0.1" else {
                exportStatus = "No trusted LAN interface detected. Connect Apple TV to Wi-Fi or Ethernet."
                return
            }
            let parameters = NWParameters.tcp
            parameters.includePeerToPeer = false
            parameters.requiredLocalEndpoint = .hostPort(host: NWEndpoint.Host(ip), port: .any)
            let next = try NWListener(using: parameters)
            next.stateUpdateHandler = { [weak self] state in
                Task { @MainActor [weak self] in
                    guard let self, self.exportGeneration == generation else { return }
                    if case .ready = state, let port = self.listener?.port {
                        self.exportAddress = "http://\(self.localAddress()):\(port.rawValue)/\(self.token)"
                        self.exportStatus = "Available on the same trusted LAN for 10 minutes."
                    } else if case .failed = state {
                        self.stopExport()
                        self.exportStatus = "Local download server failed to start."
                    }
                }
            }
            next.newConnectionHandler = { [weak self] connection in
                Task { @MainActor [weak self] in
                    guard let self, self.exportGeneration == generation else { connection.cancel(); return }
                    self.serve(connection)
                }
            }
            listener = next
            next.start(queue: .main)
            let timer = DispatchSource.makeTimerSource(queue: .main)
            timer.schedule(deadline: .now() + 600)
            timer.setEventHandler { [weak self] in
                Task { @MainActor [weak self] in
                    guard let self, self.exportGeneration == generation else { return }
                    self.stopExport()
                    self.exportStatus = "Diagnostic download expired. Start a new export to share again."
                }
            }
            expirationTimer = timer
            timer.resume()
            exportStatus = "Starting local report download…"
        } catch { exportStatus = "Local report export is unavailable." }
    }

    func stopExport() {
        exportGeneration = UUID()
        expirationTimer?.setEventHandler {}
        expirationTimer?.cancel()
        expirationTimer = nil
        listener?.cancel()
        listener = nil
        exportData = Data()
        token = ""
        exportAddress = ""
        exportDeadline = .distantPast
        exportStatus = "No export session"
    }

    private func localAddress() -> String {
        var result = "127.0.0.1"
        var addresses: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&addresses) == 0, let first = addresses else { return result }
        defer { freeifaddrs(addresses) }
        var cursor: UnsafeMutablePointer<ifaddrs>? = first
        while let node = cursor {
            let iface = node.pointee
            if let addr = iface.ifa_addr, addr.pointee.sa_family == UInt8(AF_INET) {
                let name = String(cString: iface.ifa_name)
                if name == "en0" || name == "en1" {
                    var address = addr.pointee
                    var buffer = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                    if getnameinfo(&address, socklen_t(addr.pointee.sa_len), &buffer, socklen_t(buffer.count), nil, 0, NI_NUMERICHOST) == 0 {
                        result = String(cString: buffer)
                        break
                    }
                }
            }
            cursor = iface.ifa_next
        }
        return result
    }

    private func serve(_ connection: NWConnection) {
        guard Date() < exportDeadline, exportData.count > 0 else { connection.cancel(); return }
        connection.start(queue: .main)
        connection.receive(minimumIncompleteLength: 1, maximumLength: 2048) { [weak self] data, _, _, error in
            Task { @MainActor [weak self] in
                guard let self, self.exportData.count > 0, Date() < self.exportDeadline,
                      error == nil, let data, let request = String(data: data, encoding: .utf8) else { connection.cancel(); return }
                let firstLine = request.components(separatedBy: "\r\n").first ?? ""
                let permitted = firstLine == "GET /\(self.token) HTTP/1.1" || firstLine == "GET /\(self.token) HTTP/1.0"
                let body = permitted ? self.exportData : Data("Not found".utf8)
                let status = permitted ? "200 OK" : "404 Not Found"
                let header = "HTTP/1.1 \(status)\r\nContent-Type: \(permitted ? "application/zip" : "text/plain")\r\nContent-Disposition: attachment; filename=Signal_Diagnostics.zip\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nConnection: close\r\nContent-Length: \(body.count)\r\n\r\n"
                connection.send(content: Data(header.utf8) + body, completion: .contentProcessed { _ in connection.cancel() })
                if permitted { self.stopExport() } // Single successful download only.
            }
        }
    }
}

/// Small stored-only ZIP writer. No third-party library, compression process or credentials.
private enum SignalDiagnosticZip {
    private static func append16(_ v: UInt16, to data: inout Data) { var x = v.littleEndian; withUnsafeBytes(of: &x) { data.append(contentsOf: $0) } }
    private static func append32(_ v: UInt32, to data: inout Data) { var x = v.littleEndian; withUnsafeBytes(of: &x) { data.append(contentsOf: $0) } }
    private static func checksum(_ data: Data) -> UInt32 {
        var crc: UInt32 = 0xffffffff
        for byte in data {
            crc ^= UInt32(byte)
            for _ in 0..<8 { crc = (crc >> 1) ^ ((crc & 1) != 0 ? 0xedb88320 : 0) }
        }
        return ~crc
    }
    static func make(files: [(String, Data)]) -> Data {
        var archive = Data(); var directory = Data()
        for (name, bytes) in files {
            let filename = Data(name.utf8)
            let crc = checksum(bytes)
            let offset = UInt32(archive.count)
            append32(0x04034b50, to: &archive); append16(20, to: &archive); append16(0, to: &archive)
            append16(0, to: &archive); append16(0, to: &archive); append16(0, to: &archive)
            append32(crc, to: &archive); append32(UInt32(bytes.count), to: &archive); append32(UInt32(bytes.count), to: &archive)
            append16(UInt16(filename.count), to: &archive); append16(0, to: &archive)
            archive.append(filename); archive.append(bytes)
            append32(0x02014b50, to: &directory); append16(20, to: &directory); append16(20, to: &directory)
            append16(0, to: &directory); append16(0, to: &directory); append16(0, to: &directory); append16(0, to: &directory)
            append32(crc, to: &directory); append32(UInt32(bytes.count), to: &directory); append32(UInt32(bytes.count), to: &directory)
            append16(UInt16(filename.count), to: &directory); append16(0, to: &directory); append16(0, to: &directory)
            append16(0, to: &directory); append16(0, to: &directory); append32(0, to: &directory); append32(offset, to: &directory)
            directory.append(filename)
        }
        let directoryStart = UInt32(archive.count)
        archive.append(directory)
        append32(0x06054b50, to: &archive)
        append16(0, to: &archive); append16(0, to: &archive)
        append16(UInt16(files.count), to: &archive); append16(UInt16(files.count), to: &archive)
        append32(UInt32(directory.count), to: &archive); append32(directoryStart, to: &archive); append16(0, to: &archive)
        return archive
    }
}
