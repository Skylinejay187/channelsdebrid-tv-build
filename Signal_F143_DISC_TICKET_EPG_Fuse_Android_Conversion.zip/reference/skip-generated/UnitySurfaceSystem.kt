package signal.unity.lite

import skip.lib.*

import skip.foundation.*

// vBRDC182 — Code Name: UNITY Re-Core
//
// The app is one persistent shell with independently modifiable surfaces. Visual unity now
// means shared navigation, palette, focus/motion/lifecycle and resource ownership — not that
// every section must reuse the same layout or card theme.
//
// Compatibility note: the pre-v182 catalog/live-root contracts are preserved below while
// surface-by-surface migration moves their navigation authority into UnityAppCore.
internal enum class UnitySurfaceSystem {
    ;

    internal enum class SurfaceRole(override val rawValue: String, @Suppress("UNUSED_PARAMETER") unusedp: Nothing? = null): RawRepresentable<String> {
        liveRoot("liveRoot"),
        catalogBranch("catalogBranch"),
        sportsBranch("sportsBranch"),
        dedicatedSurface("dedicatedSurface");

        @androidx.annotation.Keep
        companion object {
            fun init(rawValue: String): UnitySurfaceSystem.SurfaceRole? {
                return when (rawValue) {
                    "liveRoot" -> SurfaceRole.liveRoot
                    "catalogBranch" -> SurfaceRole.catalogBranch
                    "sportsBranch" -> SurfaceRole.sportsBranch
                    "dedicatedSurface" -> SurfaceRole.dedicatedSurface
                    else -> null
                }
            }
        }
    }

    /// Rendering policy is intentionally separate from presentation style. A surface can keep
    /// its state resident while its pixels and expensive work are dormant underneath another
    /// owner. This is the core distinction between UNITY and simply stacking SwiftUI views.
    internal class RuntimePolicy {
        internal val stateResident: Boolean
        internal val pixelsResidentWhenCovered: Boolean
        internal val backgroundWorkWhenCovered: Boolean
        internal val ownsGlobalTopNavigation: Boolean

        constructor(stateResident: Boolean, pixelsResidentWhenCovered: Boolean, backgroundWorkWhenCovered: Boolean, ownsGlobalTopNavigation: Boolean) {
            this.stateResident = stateResident
            this.pixelsResidentWhenCovered = pixelsResidentWhenCovered
            this.backgroundWorkWhenCovered = backgroundWorkWhenCovered
            this.ownsGlobalTopNavigation = ownsGlobalTopNavigation
        }

        override fun equals(other: Any?): Boolean {
            if (other !is UnitySurfaceSystem.RuntimePolicy) return false
            return stateResident == other.stateResident && pixelsResidentWhenCovered == other.pixelsResidentWhenCovered && backgroundWorkWhenCovered == other.backgroundWorkWhenCovered && ownsGlobalTopNavigation == other.ownsGlobalTopNavigation
        }
    }

    @androidx.annotation.Keep
    companion object {
        internal val codeName = "Unity"
        internal val displayCodeName = "UNITY"

        internal fun role(for_: AppTab): UnitySurfaceSystem.SurfaceRole {
            val tab = for_
            when (tab) {
                AppTab.live -> return UnitySurfaceSystem.SurfaceRole.liveRoot
                AppTab.home, AppTab.movies, AppTab.shows -> return UnitySurfaceSystem.SurfaceRole.catalogBranch
                AppTab.sports -> return UnitySurfaceSystem.SurfaceRole.sportsBranch
                AppTab.favorites, AppTab.membership, AppTab.settings -> return UnitySurfaceSystem.SurfaceRole.dedicatedSurface
            }
        }

        internal fun runtimePolicy(for_: AppTab): UnitySurfaceSystem.RuntimePolicy {
            val tab = for_
            when (tab) {
                AppTab.live -> return RuntimePolicy(stateResident = true, pixelsResidentWhenCovered = true, backgroundWorkWhenCovered = false, ownsGlobalTopNavigation = true)
                AppTab.home, AppTab.movies, AppTab.shows -> return RuntimePolicy(stateResident = true, pixelsResidentWhenCovered = true, backgroundWorkWhenCovered = false, ownsGlobalTopNavigation = true)
                AppTab.sports, AppTab.favorites, AppTab.membership, AppTab.settings -> return RuntimePolicy(stateResident = true, pixelsResidentWhenCovered = false, backgroundWorkWhenCovered = false, ownsGlobalTopNavigation = true)
            }
        }

        // UNITY visual invariant: preserve the physical Live TV root, its decoded artwork,
        // and the shared catalog backdrop across every non-playback tab. Covered work is
        // suspended independently of visual identity.
        internal fun keepsLiveTVRootMounted(for_: AppTab): Boolean {
            val tab = for_
            return runtimePolicy(for_ = tab).stateResident
        }

        internal fun shouldCompositeLiveTVRoot(for_: AppTab): Boolean {
            val tab = for_
            when (role(for_ = tab)) {
                UnitySurfaceSystem.SurfaceRole.liveRoot, UnitySurfaceSystem.SurfaceRole.catalogBranch, UnitySurfaceSystem.SurfaceRole.sportsBranch -> return true
                UnitySurfaceSystem.SurfaceRole.dedicatedSurface -> return false
            }
        }

        internal fun catalogBranchActive(for_: AppTab): Boolean {
            val tab = for_
            return role(for_ = tab) == UnitySurfaceSystem.SurfaceRole.catalogBranch
        }

        internal fun quickPanelBranchActive(for_: AppTab): Boolean {
            val tab = for_
            when (role(for_ = tab)) {
                UnitySurfaceSystem.SurfaceRole.catalogBranch, UnitySurfaceSystem.SurfaceRole.sportsBranch -> return true
                UnitySurfaceSystem.SurfaceRole.liveRoot, UnitySurfaceSystem.SurfaceRole.dedicatedSurface -> return false
            }
        }

        internal fun backDestination(from: AppTab): AppTab {
            val tab = from
            when (role(for_ = tab)) {
                UnitySurfaceSystem.SurfaceRole.catalogBranch, UnitySurfaceSystem.SurfaceRole.sportsBranch -> return AppTab.live
                UnitySurfaceSystem.SurfaceRole.liveRoot, UnitySurfaceSystem.SurfaceRole.dedicatedSurface -> return tab
            }
        }

        internal fun SurfaceRole(rawValue: String): UnitySurfaceSystem.SurfaceRole? = SurfaceRole.init(rawValue = rawValue)
    }
}
