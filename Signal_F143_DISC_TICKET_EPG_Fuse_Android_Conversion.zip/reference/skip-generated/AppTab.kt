package signal.unity.lite

import skip.lib.*
import skip.lib.Array

import skip.foundation.*
@androidx.annotation.Keep
internal enum class AppTab(override val rawValue: String, @Suppress("UNUSED_PARAMETER") unusedp: Nothing? = null): CaseIterable, Identifiable<String>, RawRepresentable<String> {
    home("Home"),
    movies("Movies"),
    shows("Shows"),
    sports("Sports"),
    favorites("Favorites"),
    live("Live TV"),
    membership("Membership"),
    settings("Settings");
    override val id: String
        get() = rawValue

    @androidx.annotation.Keep
    companion object: CaseIterableCompanion<AppTab> {
        fun init(rawValue: String): AppTab? {
            return when (rawValue) {
                "Home" -> AppTab.home
                "Movies" -> AppTab.movies
                "Shows" -> AppTab.shows
                "Sports" -> AppTab.sports
                "Favorites" -> AppTab.favorites
                "Live TV" -> AppTab.live
                "Membership" -> AppTab.membership
                "Settings" -> AppTab.settings
                else -> null
            }
        }

        override val allCases: Array<AppTab>
            get() = arrayOf(home, movies, shows, sports, favorites, live, membership, settings)
    }
}

internal fun AppTab(rawValue: String): AppTab? = AppTab.init(rawValue = rawValue)
