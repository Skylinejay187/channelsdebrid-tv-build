package com.channelsdebrid.tv

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.channelsdebrid.tv.data.UnifiedCatalogRepository
import com.channelsdebrid.tv.playback.MediaDetailsActivity
import com.channelsdebrid.tv.playback.PlayerActivity
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.Locale

class SearchActivity : AppCompatActivity() {
    private lateinit var queryBox: EditText
    private lateinit var results: LinearLayout
    private lateinit var repo: UnifiedCatalogRepository
    private val executor = Executors.newFixedThreadPool(2)
    private val handler = Handler(Looper.getMainLooper())
    private var searchVersion = 0
    private val activeSearches = mutableListOf<Future<*>>()
    private val mergeLock = Any()

    private fun cancelActiveSearches() {
        activeSearches.forEach { it.cancel(true) }
        activeSearches.clear()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = UnifiedCatalogRepository(this)
        setContentView(buildLayout())
        executor.execute { repo.warmSearchIndex() }
        renderResults("")
        queryBox.requestFocus()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun buildLayout(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(4, 7, 11))
            setPadding(dp(54), dp(34), dp(54), dp(34))
        }
        root.addView(TextView(this).apply {
            text = "⌕ Search"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Search movies, TV shows, live channels, and guide events across the app"
            textSize = 14f
            setTextColor(0xFFD7CCBF.toInt())
            setPadding(0, dp(4), 0, dp(18))
        })
        queryBox = EditText(this).apply {
            hint = "Type a movie, show, channel, NFL game, team, or program..."
            setSingleLine(true)
            textSize = 22f
            setTextColor(Color.WHITE)
            setHintTextColor(0x88FFFFFF.toInt())
            setPadding(dp(18), 0, dp(18), 0)
            background = rounded(0x22FFFFFF, 0x665EE6FF, dp(18), dp(2))
            minHeight = dp(58)
            setOnEditorActionListener { _, _, _ -> renderResults(text?.toString().orEmpty()); true }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    val version = ++searchVersion
                    handler.postDelayed({ if (version == searchVersion) renderResults(s?.toString().orEmpty()) }, 85L)
                }
                override fun afterTextChanged(s: Editable?) {}
            })
            setOnKeyListener { _, keyCode, event ->
                if (event.action == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                    results.getChildAt(0)?.requestFocus(); true
                } else false
            }
        }
        root.addView(queryBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60)))
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            setPadding(0, dp(24), 0, 0)
        }
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(results)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return root
    }

    private fun renderResults(rawQuery: String) {
        val query = rawQuery.trim()
        val version = ++searchVersion
        cancelActiveSearches()

        if (query.isBlank()) {
            renderItems(emptyList(), query, loading = true)
            return
        }

        // v2.8.1 Option B: TMDB is the fast network path when a key exists, but
        // installed Stremio/Cinemeta addons and Live/Guide matches are searched in
        // parallel as fallback/background sources. Search UI never waits for streams.
        renderItems(emptyList(), query, loading = true)

        val start = System.currentTimeMillis()
        val merged = linkedMapOf<String, UnifiedCatalogRepository.MediaItem>()

        fun mergeKey(item: UnifiedCatalogRepository.MediaItem): String {
            val id = item.externalId.ifBlank { item.streamUrl }.ifBlank { item.title }
            return "${item.type.lowercase(Locale.US)}|${id.lowercase(Locale.US)}|${item.title.lowercase(Locale.US)}"
        }

        fun publish(sourceLabel: String, items: List<UnifiedCatalogRepository.MediaItem>) {
            if (Thread.currentThread().isInterrupted) return
            synchronized(mergeLock) {
                items.forEach { item -> merged.putIfAbsent(mergeKey(item), item) }
            }
            handler.post {
                if (version != searchVersion || isFinishing || isDestroyed) return@post
                val snapshot = synchronized(mergeLock) { merged.values.toList() }
                renderItems(snapshot, query, loading = false, elapsedMs = System.currentTimeMillis() - start, sourceLabel = sourceLabel)
            }
        }

        activeSearches += executor.submit searchTask@{
            val tmdbItems = runCatching { repo.fastNetworkSearch(query) }.getOrDefault(emptyList())
            publish(if (tmdbItems.isNotEmpty()) "TMDB fast results" else "TMDB unavailable — checking addons", tmdbItems)
        }

        activeSearches += executor.submit searchTask@{
            val addonItems = runCatching { repo.stremioAddonSearchQuick(query) }.getOrDefault(emptyList())
            publish(if (addonItems.isNotEmpty()) "Stremio addon results" else "No addon matches yet", addonItems)
        }

        activeSearches += executor.submit searchTask@{
            val liveItems = runCatching { repo.liveAndGuideSearchQuick(query) }.getOrDefault(emptyList())
            publish(if (liveItems.isNotEmpty()) "Live TV / Guide results" else "", liveItems)
        }

        handler.postDelayed({
            if (version != searchVersion || isFinishing || isDestroyed) return@postDelayed
            val snapshot = synchronized(mergeLock) { merged.values.toList() }
            if (snapshot.isEmpty()) {
                renderItems(emptyList(), query, loading = false, elapsedMs = System.currentTimeMillis() - start, sourceLabel = "TMDB key required for fastest search • Stremio fallback checked")
            }
        }, 2400L)
    }

    private fun renderItems(items: List<UnifiedCatalogRepository.MediaItem>, rawQuery: String, loading: Boolean, elapsedMs: Long = -1L, sourceLabel: String = "") {
        results.removeAllViews()
        if (items.isEmpty()) {
            results.addView(TextView(this).apply {
                text = if (loading) {
                    if (rawQuery.isBlank()) "Type to search TMDB, Stremio addons, Live TV, and guide…" else "Searching instantly… results appear while typing"
                } else {
                    if (sourceLabel.isNotBlank()) "$sourceLabel\nNo movies, shows, live channels, or guide events matched that search." else "No movies, shows, live channels, or guide events matched that search."
                }
                textSize = 18f
                setTextColor(0xCCFFFFFF.toInt())
                setPadding(0, dp(18), 0, 0)
            })
            return
        }
        if (rawQuery.isNotBlank()) {
            results.addView(TextView(this).apply {
                text = when {
                    loading -> "TMDB network search + Stremio fallback — posters load lazily"
                    sourceLabel.isNotBlank() && elapsedMs >= 0L -> "$sourceLabel • ${elapsedMs}ms • streams load after selection"
                    elapsedMs >= 0L -> "Search results • ${elapsedMs}ms • streams load after selection"
                    else -> "Search results"
                }
                textSize = 14f
                setTextColor(0x99FFFFFF.toInt())
                setPadding(0, 0, 0, dp(10))
            })
        }
        items.take(if (loading) 0 else 45).forEach { item -> results.addView(resultView(item, deferPoster = true)) }
    }

    private fun resultView(item: UnifiedCatalogRepository.MediaItem, deferPoster: Boolean = false): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isFocusable = true
            isClickable = true
            setPadding(dp(12), dp(8), dp(18), dp(8))
            background = rounded(0x18FFFFFF, 0x00000000, dp(18), 0)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(118)).apply { bottomMargin = dp(12) }
        }
        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFF0B0F18.toInt())
        }
        row.addView(img, LinearLayout.LayoutParams(dp(76), dp(102)).apply { rightMargin = dp(16) })
        val text = TextView(this).apply {
            val typeLabel = when (item.type) { "series", "tv" -> "TV Show"; "live" -> "Live"; else -> "Movie" }
            this.text = "${item.title}\n$typeLabel${if (item.meta.isNotBlank()) "  •  ${item.meta}" else ""}"
            textSize = 17f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            maxLines = 3
        }
        row.addView(text, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        val art = item.posterUrl.ifBlank { item.backdropUrl }.ifBlank { item.logoUrl }
        if (art.isNotBlank()) {
            if (deferPoster) img.postDelayed({ if (!isFinishing && !isDestroyed) Glide.with(this).load(com.channelsdebrid.tv.net.BackendEndpoint.imageProxyUrl(art)).diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.ALL).thumbnail(0.12f).centerCrop().into(img) }, 35L)
            else Glide.with(this).load(com.channelsdebrid.tv.net.BackendEndpoint.imageProxyUrl(art)).diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.ALL).thumbnail(0.12f).centerCrop().into(img)
        }
        row.setOnFocusChangeListener { v, hasFocus ->
            v.background = if (hasFocus) rounded(0x225EE6FF, 0xAA5EE6FF.toInt(), dp(18), dp(2)) else rounded(0x18FFFFFF, 0x00000000, dp(18), 0)
            v.animate().scaleX(if (hasFocus) 1.01f else 1f).scaleY(if (hasFocus) 1.01f else 1f).setDuration(120L).start()
        }
        row.setOnClickListener { openItem(item) }
        return row
    }

    private fun openItem(item: UnifiedCatalogRepository.MediaItem) {
        if (item.type == "live" && item.streamUrl.isNotBlank()) {
            startActivity(Intent(this, PlayerActivity::class.java).apply {
                putExtra(PlayerActivity.EXTRA_STREAM_URL, item.streamUrl)
                putExtra(PlayerActivity.EXTRA_TITLE, item.title)
                putExtra(PlayerActivity.EXTRA_SOURCE_LABEL, item.meta)
            })
            return
        }
        startActivity(Intent(this, MediaDetailsActivity::class.java).apply {
            putExtra(MediaDetailsActivity.EXTRA_TITLE, item.title)
            putExtra(MediaDetailsActivity.EXTRA_META_LINE, item.meta)
            putExtra(MediaDetailsActivity.EXTRA_DESC, item.overview)
            putExtra(MediaDetailsActivity.EXTRA_MEDIA_TYPE, if (item.type == "series" || item.type == "tv") "series" else "movie")
            putExtra(MediaDetailsActivity.EXTRA_EXTERNAL_ID, item.externalId)
            putExtra(MediaDetailsActivity.EXTRA_POSTER_URL, item.posterUrl)
            putExtra(MediaDetailsActivity.EXTRA_BACKDROP_URL, item.backdropUrl)
            putExtra(MediaDetailsActivity.EXTRA_LOGO_URL, item.logoUrl)
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        cancelActiveSearches()
        executor.shutdownNow()
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int, strokeWidth: Int): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            setColor(fill)
            cornerRadius = radius.toFloat()
            if (strokeWidth > 0) setStroke(strokeWidth, stroke)
        }
    }
}
