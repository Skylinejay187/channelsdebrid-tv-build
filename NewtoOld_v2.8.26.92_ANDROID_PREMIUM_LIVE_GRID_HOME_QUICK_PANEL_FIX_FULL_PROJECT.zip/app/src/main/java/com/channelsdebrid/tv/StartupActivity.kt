package com.channelsdebrid.tv

import android.animation.ObjectAnimator
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class StartupActivity : AppCompatActivity() {
    private companion object {
        private const val TAG = "DebridChannels"
        @Volatile private var mainLaunchIssuedAt: Long = 0L
    }
    private val handler = Handler(Looper.getMainLooper())
    private var launchedMain = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i(TAG, "STARTUP_CINEMATIC_STABLE_REPAIR: no_extra_text=true no_baked_loading=true single_orange_bar=true launcher_untouched=true default_home=LiveTvActivity_v2_8_26_91_live_grid_default")
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val bg = ImageView(this).apply {
            setImageResource(R.drawable.startup_cinematic_no_text_no_bar)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = false
            alpha = 0f
        }
        root.addView(bg, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        val track = View(this).apply { background = rounded(0xFF171719.toInt(), 6); alpha = 0.78f }
        val bar = View(this).apply { background = rounded(0xFFFF8700.toInt(), 6); pivotX = 0f; scaleX = 0.02f }
        val glint = View(this).apply { background = rounded(0xFFFFD27A.toInt(), 8); alpha = 0f }
        val barWidth = dp(520)
        val barHeight = dp(5)
        val lp = FrameLayout.LayoutParams(barWidth, barHeight, Gravity.CENTER).apply { topMargin = dp(245) }
        root.addView(track, lp)
        root.addView(bar, FrameLayout.LayoutParams(barWidth, barHeight, Gravity.CENTER).apply { topMargin = dp(245) })
        root.addView(glint, FrameLayout.LayoutParams(dp(56), dp(7), Gravity.CENTER).apply { topMargin = dp(245); leftMargin = -barWidth / 2 })
        setContentView(root)
        ObjectAnimator.ofFloat(bg, "alpha", 0f, 1f).apply { duration = 420; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(bg, "scaleX", 0.992f, 1.0f).apply { duration = 1300; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(bg, "scaleY", 0.992f, 1.0f).apply { duration = 1300; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(bar, "scaleX", 0.02f, 1f).apply { duration = 1500; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(glint, "translationX", -barWidth / 2f, barWidth / 2f).apply { duration = 1500; interpolator = AccelerateDecelerateInterpolator(); start() }
        ObjectAnimator.ofFloat(glint, "alpha", 0f, 1f, 0f).apply { duration = 1500; interpolator = AccelerateDecelerateInterpolator(); start() }
        handler.postDelayed({
            val now = android.os.SystemClock.elapsedRealtime()
            if (!launchedMain && now - mainLaunchIssuedAt > 3000L) {
                launchedMain = true
                mainLaunchIssuedAt = now
                startActivity(Intent(this, LiveTvActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                })
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }
            finish()
        }, 1600)
    }
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
    private fun rounded(color: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = dp(radiusDp).toFloat() }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
