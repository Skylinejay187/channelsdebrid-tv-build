package com.channelsdebrid.tv

import android.graphics.Typeface
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.net.URL
import java.net.HttpURLConnection
import org.json.JSONObject
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import com.channelsdebrid.tv.data.SourceTestRunner
import com.channelsdebrid.tv.settings.CatalogSettings
import com.channelsdebrid.tv.settings.ChannelsDvrSettings
import com.channelsdebrid.tv.settings.DebridSettings
import com.channelsdebrid.tv.settings.LiveBackendSettings
import com.channelsdebrid.tv.settings.PlaybackSettings
import com.channelsdebrid.tv.settings.SettingsRepository
import com.channelsdebrid.tv.settings.StorageSettings
import com.channelsdebrid.tv.settings.StremioAddonSettings
import com.channelsdebrid.tv.settings.TmdbSettings
import com.channelsdebrid.tv.settings.TrailerSettings
import com.channelsdebrid.tv.settings.XtreamSettings

class SettingsActivity : AppCompatActivity() {
    private lateinit var repository: SettingsRepository

    private lateinit var backButton: Button
    private lateinit var cancelButton: Button
    private lateinit var saveButton: Button
    private val sourceTestRunner = SourceTestRunner()

    private lateinit var tmdbTestButton: Button
    private lateinit var stremioTestButton: Button
    private lateinit var channelsTestButton: Button
    private lateinit var xtreamTestButton: Button
    private lateinit var debridTestButton: Button
    private lateinit var liveBackendTestButton: Button
    private lateinit var channelsConnectButton: Button
    private lateinit var xtreamConnectButton: Button

    private lateinit var tmdbStatusText: TextView
    private lateinit var stremioStatusText: TextView
    private lateinit var channelsStatusText: TextView
    private lateinit var xtreamStatusText: TextView
    private lateinit var debridStatusText: TextView
    private lateinit var liveBackendStatusText: TextView

    private lateinit var tmdbApiKeyInput: EditText
    private lateinit var tmdbRegionInput: EditText
    private lateinit var tmdbLanguageInput: EditText

    private lateinit var catalogTrendingMoviesSwitch: SwitchCompat
    private lateinit var catalogPopularMoviesSwitch: SwitchCompat
    private lateinit var catalogTrendingShowsSwitch: SwitchCompat
    private lateinit var catalogPopularShowsSwitch: SwitchCompat
    private lateinit var catalogPlatformSwitch: SwitchCompat
    private lateinit var catalogStremioSwitch: SwitchCompat

    private lateinit var stremioEnabledSwitch: SwitchCompat
    private lateinit var stremioNameInput: EditText
    private lateinit var stremioManifestInput: EditText
    private lateinit var stremioAddSourceButton: Button
    private lateinit var stremioSourcesContainer: LinearLayout
    private lateinit var stremioSourceCountText: TextView
    private val stremioSources = mutableListOf<StremioAddonSettings>()

    private lateinit var realDebridEnabledSwitch: SwitchCompat
    private lateinit var realDebridApiKeyInput: EditText
    private lateinit var torBoxEnabledSwitch: SwitchCompat
    private lateinit var torBoxApiKeyInput: EditText
    private lateinit var preferredDebridInput: AutoCompleteTextView
    private lateinit var autoFallbackSwitch: SwitchCompat

    private lateinit var liveBackendBaseUrlInput: EditText
    private lateinit var liveBackendUserIdInput: EditText
    private lateinit var liveBackendAutoSyncSwitch: SwitchCompat

    private lateinit var channelsAutoDetectSwitch: SwitchCompat
    private lateinit var channelsBaseUrlInput: EditText

    private lateinit var xtreamEnabledSwitch: SwitchCompat
    private lateinit var xtreamServerInput: EditText
    private lateinit var xtreamUsernameInput: EditText
    private lateinit var xtreamPasswordInput: EditText
    private lateinit var xtreamM3uInput: EditText

    private lateinit var storageTargetInput: AutoCompleteTextView
    private lateinit var storageUsbInput: EditText
    private lateinit var storageNasInput: EditText
    private lateinit var timeshiftMinutesInput: EditText
    private lateinit var movieCacheSwitch: SwitchCompat

    private lateinit var trailerEnabledSwitch: SwitchCompat
    private lateinit var trailerAutoplaySwitch: SwitchCompat
    private lateinit var trailerDelayInput: EditText
    private lateinit var trailerModeInput: AutoCompleteTextView

    private lateinit var frameRateSwitch: SwitchCompat
    private lateinit var autoPlayBestSwitch: SwitchCompat
    private lateinit var preferExternalSwitch: SwitchCompat
    private lateinit var timeshiftEnabledSwitch: SwitchCompat
    private lateinit var fourKUiSwitch: SwitchCompat
    private lateinit var liveStatusChecksSwitch: SwitchCompat
    private lateinit var fileSizeLimitInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        repository = SettingsRepository(this)
        bindViews()

        storageTargetInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("internal", "usb", "nas")))
        trailerModeInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("center_modal", "fullscreen")))
        preferredDebridInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf("realdebrid", "torbox")))

        loadAll()
        stremioAddSourceButton.setOnClickListener { addCurrentStremioSource() }
        backButton.setOnClickListener { finish() }
        cancelButton.setOnClickListener { finish() }
        saveButton.setOnClickListener {
            saveAll()
            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
            finish()
        }
        wireTestButtons()
    }

    private fun bindViews() {
        backButton = findViewById(R.id.backButton)
        cancelButton = findViewById(R.id.cancelButton)
        saveButton = findViewById(R.id.saveButton)
        tmdbTestButton = findViewById(R.id.tmdbTestButton)
        stremioTestButton = findViewById(R.id.stremioTestButton)
        channelsTestButton = findViewById(R.id.channelsTestButton)
        xtreamTestButton = findViewById(R.id.xtreamTestButton)
        debridTestButton = findViewById(R.id.debridTestButton)
        liveBackendTestButton = findViewById(R.id.liveBackendTestButton)
        channelsConnectButton = findViewById(R.id.channelsConnectButton)
        xtreamConnectButton = findViewById(R.id.xtreamConnectButton)
        tmdbStatusText = findViewById(R.id.tmdbStatusText)
        stremioStatusText = findViewById(R.id.stremioStatusText)
        channelsStatusText = findViewById(R.id.channelsStatusText)
        xtreamStatusText = findViewById(R.id.xtreamStatusText)
        debridStatusText = findViewById(R.id.debridStatusText)
        liveBackendStatusText = findViewById(R.id.liveBackendStatusText)

        tmdbApiKeyInput = findViewById(R.id.tmdbApiKeyInput)
        tmdbRegionInput = findViewById(R.id.tmdbRegionInput)
        tmdbLanguageInput = findViewById(R.id.tmdbLanguageInput)

        catalogTrendingMoviesSwitch = findViewById(R.id.catalogTrendingMoviesSwitch)
        catalogPopularMoviesSwitch = findViewById(R.id.catalogPopularMoviesSwitch)
        catalogTrendingShowsSwitch = findViewById(R.id.catalogTrendingShowsSwitch)
        catalogPopularShowsSwitch = findViewById(R.id.catalogPopularShowsSwitch)
        catalogPlatformSwitch = findViewById(R.id.catalogPlatformSwitch)
        catalogStremioSwitch = findViewById(R.id.catalogStremioSwitch)

        stremioEnabledSwitch = findViewById(R.id.stremioEnabledSwitch)
        stremioNameInput = findViewById(R.id.stremioNameInput)
        stremioManifestInput = findViewById(R.id.stremioManifestInput)
        stremioAddSourceButton = findViewById(R.id.stremioAddSourceButton)
        stremioSourcesContainer = findViewById(R.id.stremioSourcesContainer)
        stremioSourceCountText = findViewById(R.id.stremioSourceCountText)

        realDebridEnabledSwitch = findViewById(R.id.realDebridEnabledSwitch)
        realDebridApiKeyInput = findViewById(R.id.realDebridApiKeyInput)
        torBoxEnabledSwitch = findViewById(R.id.torBoxEnabledSwitch)
        torBoxApiKeyInput = findViewById(R.id.torBoxApiKeyInput)
        preferredDebridInput = findViewById(R.id.preferredDebridInput)
        autoFallbackSwitch = findViewById(R.id.autoFallbackSwitch)

        liveBackendBaseUrlInput = findViewById(R.id.liveBackendBaseUrlInput)
        liveBackendUserIdInput = findViewById(R.id.liveBackendUserIdInput)
        liveBackendAutoSyncSwitch = findViewById(R.id.liveBackendAutoSyncSwitch)

        channelsAutoDetectSwitch = findViewById(R.id.channelsAutoDetectSwitch)
        channelsBaseUrlInput = findViewById(R.id.channelsBaseUrlInput)

        xtreamEnabledSwitch = findViewById(R.id.xtreamEnabledSwitch)
        xtreamServerInput = findViewById(R.id.xtreamServerInput)
        xtreamUsernameInput = findViewById(R.id.xtreamUsernameInput)
        xtreamPasswordInput = findViewById(R.id.xtreamPasswordInput)
        xtreamM3uInput = findViewById(R.id.xtreamM3uInput)

        storageTargetInput = findViewById(R.id.storageTargetInput)
        storageUsbInput = findViewById(R.id.storageUsbInput)
        storageNasInput = findViewById(R.id.storageNasInput)
        timeshiftMinutesInput = findViewById(R.id.timeshiftMinutesInput)
        movieCacheSwitch = findViewById(R.id.movieCacheSwitch)

        trailerEnabledSwitch = findViewById(R.id.trailerEnabledSwitch)
        trailerAutoplaySwitch = findViewById(R.id.trailerAutoplaySwitch)
        trailerDelayInput = findViewById(R.id.trailerDelayInput)
        trailerModeInput = findViewById(R.id.trailerModeInput)

        frameRateSwitch = findViewById(R.id.frameRateSwitch)
        autoPlayBestSwitch = findViewById(R.id.autoPlayBestSwitch)
        preferExternalSwitch = findViewById(R.id.preferExternalSwitch)
        timeshiftEnabledSwitch = findViewById(R.id.timeshiftEnabledSwitch)
        fourKUiSwitch = findViewById(R.id.fourKUiSwitch)
        liveStatusChecksSwitch = findViewById(R.id.liveStatusChecksSwitch)
        fileSizeLimitInput = findViewById(R.id.fileSizeLimitInput)
    }

    private fun loadAll() {
        val tmdb = repository.loadTmdb()
        tmdbApiKeyInput.setText(tmdb.apiKey)
        tmdbRegionInput.setText(tmdb.region)
        tmdbLanguageInput.setText(tmdb.language)

        val catalogs = repository.loadCatalogs()
        catalogTrendingMoviesSwitch.isChecked = catalogs.trendingMoviesEnabled
        catalogPopularMoviesSwitch.isChecked = catalogs.popularMoviesEnabled
        catalogTrendingShowsSwitch.isChecked = catalogs.trendingShowsEnabled
        catalogPopularShowsSwitch.isChecked = catalogs.popularShowsEnabled
        catalogPlatformSwitch.isChecked = catalogs.platformRowsEnabled
        catalogStremioSwitch.isChecked = catalogs.stremioCatalogRowsEnabled

        val addons = repository.loadStremioAddons()
        stremioEnabledSwitch.isChecked = addons.firstOrNull()?.enabled ?: true
        stremioSources.clear()
        stremioSources += addons
        stremioNameInput.setText("")
        stremioManifestInput.setText("")
        renderStremioSources()

        val debrid = repository.loadDebrid()
        realDebridEnabledSwitch.isChecked = debrid.realDebridEnabled
        realDebridApiKeyInput.setText(debrid.realDebridApiKey)
        torBoxEnabledSwitch.isChecked = debrid.torBoxEnabled
        torBoxApiKeyInput.setText(debrid.torBoxApiKey)
        preferredDebridInput.setText(debrid.preferredProvider, false)
        autoFallbackSwitch.isChecked = debrid.autoFallback

        val liveBackend = repository.loadLiveBackend()
        liveBackendBaseUrlInput.setText(liveBackend.baseUrl)
        liveBackendUserIdInput.setText(liveBackend.userId)
        liveBackendAutoSyncSwitch.isChecked = liveBackend.autoSyncSources

        val dvr = repository.loadChannelsDvr()
        channelsAutoDetectSwitch.isChecked = dvr.autoDetect
        channelsBaseUrlInput.setText(dvr.baseUrl)

        val xtream = repository.loadXtream()
        xtreamEnabledSwitch.isChecked = xtream.enabled
        xtreamServerInput.setText(xtream.server)
        xtreamUsernameInput.setText(xtream.username)
        xtreamPasswordInput.setText(xtream.password)
        xtreamM3uInput.setText(xtream.m3uUrl)

        val storage = repository.loadStorage()
        storageTargetInput.setText(storage.preferredTarget, false)
        storageUsbInput.setText(storage.usbPath)
        storageNasInput.setText(storage.nasPath)
        timeshiftMinutesInput.setText(storage.timeshiftMinutes.toString())
        movieCacheSwitch.isChecked = storage.movieCacheEnabled

        val trailers = repository.loadTrailers()
        trailerEnabledSwitch.isChecked = trailers.enabled
        trailerAutoplaySwitch.isChecked = trailers.autoplayOnFocus
        trailerDelayInput.setText(trailers.autoplayDelayMs.toString())
        trailerModeInput.setText(trailers.popupMode, false)

        val playback = repository.loadPlayback()
        frameRateSwitch.isChecked = playback.frameRateMatching
        autoPlayBestSwitch.isChecked = playback.autoPlayBestStream
        preferExternalSwitch.isChecked = playback.preferExternalStorageForCache
        timeshiftEnabledSwitch.isChecked = playback.timeshiftEnabled
        fourKUiSwitch.isChecked = playback.ultraHdGuideUiEnabled
        liveStatusChecksSwitch.isChecked = playback.liveStatusChecksEnabled
        fileSizeLimitInput.setText(playback.fileSizeLimitGb.toString())
    }

    private fun wireTestButtons() {
        tmdbTestButton.setOnClickListener {
            runSourceTest(tmdbStatusText, "Testing TMDB…") {
                sourceTestRunner.testTmdb(
                    tmdbApiKeyInput.text.toString().trim(),
                    tmdbRegionInput.text.toString().trim(),
                    tmdbLanguageInput.text.toString().trim()
                )
            }
        }
        stremioTestButton.setOnClickListener {
            runSourceTest(stremioStatusText, "Testing Stremio…") {
                val pending = buildAddonFromInputs()
                val addons = (stremioSources + listOfNotNull(pending))
                    .distinctBy { it.manifestUrl.trim().lowercase() }
                    .map { it.copy(enabled = stremioEnabledSwitch.isChecked) }
                if (addons.isEmpty()) {
                    "Add at least one manifest URL"
                } else {
                    addons.joinToString(" | ") { addon ->
                        sourceTestRunner.testStremio(addon.name.ifBlank { "Stremio" }, addon.manifestUrl)
                    }
                }
            }
        }
        channelsTestButton.setOnClickListener {
            runSourceTest(channelsStatusText, "Testing Channels DVR…") {
                sourceTestRunner.testChannelsDvr(
                    channelsAutoDetectSwitch.isChecked,
                    channelsBaseUrlInput.text.toString().trim()
                )
            }
        }
        xtreamTestButton.setOnClickListener {
            runSourceTest(xtreamStatusText, "Testing IPTV…") {
                sourceTestRunner.testXtream(
                    xtreamServerInput.text.toString().trim(),
                    xtreamUsernameInput.text.toString().trim(),
                    xtreamPasswordInput.text.toString().trim(),
                    xtreamM3uInput.text.toString().trim()
                )
            }
        }
        debridTestButton.setOnClickListener {
            runSourceTest(debridStatusText, "Testing Debrid…") {
                when {
                    realDebridEnabledSwitch.isChecked && realDebridApiKeyInput.text.toString().trim().isNotBlank() -> {
                        sourceTestRunner.testRealDebrid(realDebridApiKeyInput.text.toString().trim())
                    }
                    torBoxEnabledSwitch.isChecked && torBoxApiKeyInput.text.toString().trim().isNotBlank() -> {
                        sourceTestRunner.testTorBox(torBoxApiKeyInput.text.toString().trim())
                    }
                    else -> "Enable Real-Debrid or TorBox and enter an API key"
                }
            }
        }
        liveBackendTestButton.setOnClickListener {
            runSourceTest(liveBackendStatusText, "Testing backend…") {
                testLiveBackend(
                    liveBackendBaseUrlInput.text.toString().trim(),
                    liveBackendUserIdInput.text.toString().trim()
                )
            }
        }
        channelsConnectButton.setOnClickListener {
            runSourceTest(channelsStatusText, "Connecting Channels DVR…") {
                connectChannelsSourceToBackend()
            }
        }
        xtreamConnectButton.setOnClickListener {
            runSourceTest(xtreamStatusText, "Connecting IPTV…") {
                connectXtreamSourceToBackend()
            }
        }
    }

    private fun runSourceTest(statusView: TextView, runningText: String, block: () -> String) {
        statusView.text = runningText
        Thread {
            val result = runCatching(block).getOrElse { "Test failed" }
            runOnUiThread { statusView.text = result }
        }.start()
    }

    private fun parseStremioAddons(enabled: Boolean, rawNames: String, rawManifests: String): List<StremioAddonSettings> {
        val names = rawNames.lineSequence().map { it.trim() }.filter { it.isNotBlank() }.toList()
        val manifests = rawManifests.lineSequence().map { it.trim() }.filter { it.isNotBlank() }.toList()
        return manifests.mapIndexed { index, manifestUrl ->
            val inferredName = inferAddonName(manifestUrl)
            StremioAddonSettings(
                id = if (index == 0) "primary" else "addon_${index + 1}",
                name = names.getOrNull(index).orEmpty().ifBlank { inferredName.ifBlank { "Addon ${index + 1}" } },
                manifestUrl = manifestUrl,
                enabled = enabled
            )
        }
    }

    private fun inferAddonName(manifestUrl: String): String {
        return manifestUrl
            .substringBefore('?')
            .substringAfter("//", manifestUrl)
            .substringBefore('/')
            .substringBefore(':')
            .replace('-', ' ')
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
    }

    private fun fetchManifestName(manifestUrl: String): String? {
        val normalized = if (manifestUrl.endsWith("/manifest.json")) manifestUrl else manifestUrl.trimEnd('/') + "/manifest.json"
        return runCatching {
            val connection = java.net.URL(normalized).openConnection() as java.net.HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 5000
            connection.readTimeout = 5000
            connection.setRequestProperty("Accept", "application/json")
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()
            org.json.JSONObject(body).optString("name").trim().ifBlank { null }
        }.getOrNull()
    }

    private fun buildAddonFromInputs(): StremioAddonSettings? {
        val manifestUrl = stremioManifestInput.text.toString().trim()
        if (manifestUrl.isBlank()) return null
        val name = stremioNameInput.text.toString().trim().ifBlank { inferAddonName(manifestUrl).ifBlank { "Addon ${stremioSources.size + 1}" } }
        val normalized = if (manifestUrl.endsWith("/manifest.json")) manifestUrl else manifestUrl.trimEnd('/') + "/manifest.json"
        return StremioAddonSettings(
            id = "addon_${stremioSources.size + 1}",
            name = name,
            manifestUrl = normalized,
            enabled = stremioEnabledSwitch.isChecked
        )
    }

    private fun addCurrentStremioSource() {
        val addon = buildAddonFromInputs()
        if (addon == null) {
            Toast.makeText(this, "Paste a manifest JSON URL first", Toast.LENGTH_SHORT).show()
            return
        }
        if (stremioSources.any { it.manifestUrl.equals(addon.manifestUrl, ignoreCase = true) }) {
            Toast.makeText(this, "That source is already added", Toast.LENGTH_SHORT).show()
            return
        }
        stremioSources += addon
        stremioNameInput.setText("")
        stremioManifestInput.setText("")
        renderStremioSources()
        stremioStatusText.text = "Added ${addon.name}"
        Thread {
            val fetchedName = fetchManifestName(addon.manifestUrl)
            if (!fetchedName.isNullOrBlank()) {
                val updated = stremioSources.indexOfFirst { it.manifestUrl.equals(addon.manifestUrl, ignoreCase = true) }
                if (updated >= 0) {
                    stremioSources[updated] = stremioSources[updated].copy(name = fetchedName)
                    runOnUiThread {
                        renderStremioSources()
                        stremioStatusText.text = "Manifest detected • $fetchedName"
                    }
                }
            }
        }.start()
    }

    private fun renderStremioSources() {
        stremioSourcesContainer.removeAllViews()
        val density = resources.displayMetrics.density
        if (stremioSources.isEmpty()) {
            val empty = TextView(this).apply {
                text = "No Stremio JSON sources added yet."
                setTextColor(0xFFA9B2C8.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            }
            stremioSourcesContainer.addView(empty)
            stremioSourceCountText.text = "0 sources added"
            return
        }
        stremioSourceCountText.text = "${stremioSources.size} source${if (stremioSources.size == 1) "" else "s"} added"
        stremioSources.forEachIndexed { index, addon ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = getDrawable(R.drawable.settings_input_bg)
                setPadding((14 * density).toInt(), (12 * density).toInt(), (12 * density).toInt(), (12 * density).toInt())
            }
            val textWrap = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            val title = TextView(this).apply {
                text = addon.name
                setTextColor(0xFFF4EFE8.toInt())
                setTypeface(typeface, Typeface.BOLD)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            }
            val subtitle = TextView(this).apply {
                text = addon.manifestUrl
                setTextColor(0xFFA9B2C8.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                maxLines = 2
            }
            textWrap.addView(title)
            textWrap.addView(subtitle)
            val remove = ImageButton(this).apply {
                setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
                background = getDrawable(R.drawable.settings_fab_modern)
                layoutParams = LinearLayout.LayoutParams((38 * density).toInt(), (38 * density).toInt()).apply {
                    marginStart = (12 * density).toInt()
                }
                contentDescription = "Remove ${addon.name}"
                setOnClickListener {
                    stremioSources.removeAt(index)
                    renderStremioSources()
                    stremioStatusText.text = "Removed ${addon.name}"
                }
            }
            row.addView(textWrap)
            row.addView(remove)
            val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            if (index > 0) params.topMargin = (10 * density).toInt()
            stremioSourcesContainer.addView(row, params)
        }
    }



    private fun normalizeBackendBase(raw: String): String {
        val value = raw.trim()
        if (value.isBlank()) return ""
        val withScheme = if (value.startsWith("http://") || value.startsWith("https://")) value else "http://$value"
        return withScheme.trimEnd('/')
    }

    private fun testLiveBackend(baseUrlRaw: String, userIdRaw: String): String {
        val baseUrl = normalizeBackendBase(baseUrlRaw)
        val userId = userIdRaw.trim().ifBlank { "demo" }
        if (baseUrl.isBlank()) return "Backend URL missing"
        val healthCode = requestCode("$baseUrl/health")
        val sourcesCode = requestCode("$baseUrl/live/sources?user_id=$userId")
        return when {
            healthCode in 200..299 && sourcesCode in 200..299 -> "Backend connected • user $userId"
            healthCode in 200..299 -> "Backend reachable • live API unavailable"
            else -> "Backend failed • HTTP $healthCode"
        }
    }

    private fun connectChannelsSourceToBackend(): String {
        val baseUrl = normalizeBackendBase(liveBackendBaseUrlInput.text.toString())
        val userId = liveBackendUserIdInput.text.toString().trim().ifBlank { "demo" }
        val dvrUrl = channelsBaseUrlInput.text.toString().trim()
        if (baseUrl.isBlank()) return "Backend URL missing"
        if (dvrUrl.isBlank()) return "Channels DVR URL missing"
        val payload = JSONObject().apply {
            put("userId", userId)
            put("type", "channels_dvr")
            put("name", "Channels DVR")
            put("url", dvrUrl)
        }
        val code = postJson("$baseUrl/live/sources/connect", payload.toString())
        if (code !in 200..299) return "Backend rejected source • HTTP $code"
        postJson("$baseUrl/live/refresh", JSONObject().put("userId", userId).toString())
        return "Channels DVR synced to backend"
    }

    private fun connectXtreamSourceToBackend(): String {
        val baseUrl = normalizeBackendBase(liveBackendBaseUrlInput.text.toString())
        val userId = liveBackendUserIdInput.text.toString().trim().ifBlank { "demo" }
        if (baseUrl.isBlank()) return "Backend URL missing"
        val m3uUrl = xtreamM3uInput.text.toString().trim()
        val server = xtreamServerInput.text.toString().trim()
        val username = xtreamUsernameInput.text.toString().trim()
        val password = xtreamPasswordInput.text.toString().trim()
        val payload = JSONObject().apply {
            put("userId", userId)
            if (m3uUrl.isNotBlank()) {
                put("type", "m3u")
                put("name", "IPTV Playlist")
                put("url", m3uUrl)
            } else {
                if (server.isBlank() || username.isBlank() || password.isBlank()) return "Enter M3U URL or Xtream server credentials"
                put("type", "xtream")
                put("name", "Xtream Source")
                put("url", server)
                put("username", username)
                put("password", password)
            }
        }
        val code = postJson("$baseUrl/live/sources/connect", payload.toString())
        if (code !in 200..299) return "Backend rejected source • HTTP $code"
        postJson("$baseUrl/live/refresh", JSONObject().put("userId", userId).toString())
        return "IPTV source synced to backend"
    }

    private fun requestCode(url: String): Int {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 6000
        connection.readTimeout = 6000
        connection.setRequestProperty("Accept", "application/json")
        return try {
            connection.responseCode
        } finally {
            connection.disconnect()
        }
    }

    private fun postJson(url: String, body: String): Int {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = "POST"
        connection.connectTimeout = 8000
        connection.readTimeout = 8000
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/json")
        connection.outputStream.bufferedWriter().use { it.write(body) }
        return try {
            connection.responseCode.also {
                (if (it in 200..299) connection.inputStream else connection.errorStream)?.close()
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun saveAll() {
        repository.saveTmdb(
            TmdbSettings(
                apiKey = tmdbApiKeyInput.text.toString().trim(),
                region = tmdbRegionInput.text.toString().trim().ifEmpty { "US" },
                language = tmdbLanguageInput.text.toString().trim().ifEmpty { "en-US" }
            )
        )

        repository.saveCatalogs(
            CatalogSettings(
                trendingMoviesEnabled = catalogTrendingMoviesSwitch.isChecked,
                popularMoviesEnabled = catalogPopularMoviesSwitch.isChecked,
                trendingShowsEnabled = catalogTrendingShowsSwitch.isChecked,
                popularShowsEnabled = catalogPopularShowsSwitch.isChecked,
                platformRowsEnabled = catalogPlatformSwitch.isChecked,
                stremioCatalogRowsEnabled = catalogStremioSwitch.isChecked
            )
        )

        val pendingAddon = buildAddonFromInputs()
        val addonsToSave = (stremioSources + listOfNotNull(pendingAddon))
            .distinctBy { it.manifestUrl.trim().lowercase() }
            .mapIndexed { index, addon ->
                addon.copy(
                    id = if (index == 0) "primary" else "addon_${index + 1}",
                    enabled = stremioEnabledSwitch.isChecked
                )
            }
        repository.saveStremioAddons(addonsToSave)

        repository.saveDebrid(
            DebridSettings(
                realDebridEnabled = realDebridEnabledSwitch.isChecked,
                realDebridApiKey = realDebridApiKeyInput.text.toString().trim(),
                torBoxEnabled = torBoxEnabledSwitch.isChecked,
                torBoxApiKey = torBoxApiKeyInput.text.toString().trim(),
                preferredProvider = preferredDebridInput.text.toString().trim().ifEmpty { "realdebrid" },
                autoFallback = autoFallbackSwitch.isChecked
            )
        )

        repository.saveLiveBackend(
            LiveBackendSettings(
                baseUrl = normalizeBackendBase(liveBackendBaseUrlInput.text.toString().trim()),
                userId = liveBackendUserIdInput.text.toString().trim().ifEmpty { "demo" },
                autoSyncSources = liveBackendAutoSyncSwitch.isChecked
            )
        )

        val existingDvr = repository.loadChannelsDvr()
        val newBaseUrl = channelsBaseUrlInput.text.toString().trim()
        repository.saveChannelsDvr(
            ChannelsDvrSettings(
                autoDetect = channelsAutoDetectSwitch.isChecked,
                baseUrl = newBaseUrl,
                deviceId = if (existingDvr.baseUrl.trim().trimEnd('/') == newBaseUrl.trim().trimEnd('/')) existingDvr.deviceId else ""
            )
        )

        repository.saveXtream(
            XtreamSettings(
                server = xtreamServerInput.text.toString().trim(),
                username = xtreamUsernameInput.text.toString().trim(),
                password = xtreamPasswordInput.text.toString().trim(),
                m3uUrl = xtreamM3uInput.text.toString().trim(),
                enabled = xtreamEnabledSwitch.isChecked
            )
        )

        repository.saveStorage(
            StorageSettings(
                preferredTarget = storageTargetInput.text.toString().trim().ifEmpty { "internal" },
                usbPath = storageUsbInput.text.toString().trim(),
                nasPath = storageNasInput.text.toString().trim(),
                timeshiftMinutes = timeshiftMinutesInput.text.toString().toIntOrNull() ?: 90,
                movieCacheEnabled = movieCacheSwitch.isChecked
            )
        )

        repository.saveTrailers(
            TrailerSettings(
                enabled = trailerEnabledSwitch.isChecked,
                autoplayOnFocus = trailerAutoplaySwitch.isChecked,
                autoplayDelayMs = trailerDelayInput.text.toString().toLongOrNull() ?: 1500L,
                popupMode = trailerModeInput.text.toString().trim().ifEmpty { "center_modal" }
            )
        )

        repository.savePlayback(
            PlaybackSettings(
                frameRateMatching = frameRateSwitch.isChecked,
                preferExternalStorageForCache = preferExternalSwitch.isChecked,
                timeshiftEnabled = timeshiftEnabledSwitch.isChecked,
                autoPlayBestStream = autoPlayBestSwitch.isChecked,
                fileSizeLimitGb = fileSizeLimitInput.text.toString().toIntOrNull() ?: 40,
                ultraHdGuideUiEnabled = fourKUiSwitch.isChecked,
                liveStatusChecksEnabled = liveStatusChecksSwitch.isChecked
            )
        )

        if (liveBackendAutoSyncSwitch.isChecked) {
            Thread {
                runCatching { if (channelsBaseUrlInput.text.toString().trim().isNotBlank()) connectChannelsSourceToBackend() }
                runCatching { if (xtreamEnabledSwitch.isChecked && (xtreamM3uInput.text.toString().trim().isNotBlank() || (xtreamServerInput.text.toString().trim().isNotBlank() && xtreamUsernameInput.text.toString().trim().isNotBlank() && xtreamPasswordInput.text.toString().trim().isNotBlank()))) connectXtreamSourceToBackend() }
            }.start()
        }
    }
}
