package com.channelsdebrid.tv.playback

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.channelsdebrid.tv.R

class MediaDetailsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_media_details)

        val backdrop = intent.getStringExtra(EXTRA_BACKDROP_URL).orEmpty()
        val logo = intent.getStringExtra(EXTRA_LOGO_URL).orEmpty()
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val meta = intent.getStringExtra(EXTRA_META_LINE).orEmpty()
        val desc = intent.getStringExtra(EXTRA_DESC).orEmpty()
        val poster = intent.getStringExtra(EXTRA_POSTER_URL).orEmpty()

        Glide.with(this).load(backdrop.ifBlank { poster }).into(findViewById<ImageView>(R.id.detailsBackdrop))
        if (poster.isNotBlank()) {
            Glide.with(this).load(poster).into(findViewById<ImageView>(R.id.detailsPoster))
        }

        val logoView = findViewById<ImageView>(R.id.detailsLogo)
        val titleView = findViewById<TextView>(R.id.detailsTitle)
        if (logo.isNotBlank()) {
            Glide.with(this).load(logo).into(logoView)
        } else {
            logoView.visibility = View.GONE
            titleView.text = title
            titleView.visibility = TextView.VISIBLE
        }

        findViewById<TextView>(R.id.detailsMeta).text = meta
        findViewById<TextView>(R.id.detailsDesc).text = desc

        findViewById<Button>(R.id.detailsPlay).setOnClickListener {
            startActivity(Intent(this, SourceSelectionActivity::class.java).apply {
                putExtra(SourceSelectionActivity.EXTRA_TITLE, title)
                putExtra(SourceSelectionActivity.EXTRA_MEDIA_TYPE, intent.getStringExtra(EXTRA_MEDIA_TYPE).orEmpty())
                putExtra(SourceSelectionActivity.EXTRA_EXTERNAL_ID, intent.getStringExtra(EXTRA_EXTERNAL_ID).orEmpty())
                putExtra(SourceSelectionActivity.EXTRA_ARTWORK_URL, intent.getStringExtra(EXTRA_BACKDROP_URL).orEmpty())
                putExtra(SourceSelectionActivity.EXTRA_LOGO_URL, logo)
                putExtra(SourceSelectionActivity.EXTRA_POSTER_URL, poster)
                putExtra(SourceSelectionActivity.EXTRA_META_LINE, meta)
            })
        }
    }

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_META_LINE = "meta_line"
        const val EXTRA_DESC = "desc"
        const val EXTRA_MEDIA_TYPE = "media_type"
        const val EXTRA_EXTERNAL_ID = "external_id"
        const val EXTRA_POSTER_URL = "poster_url"
        const val EXTRA_BACKDROP_URL = "backdrop_url"
        const val EXTRA_LOGO_URL = "logo_url"
    }
}
