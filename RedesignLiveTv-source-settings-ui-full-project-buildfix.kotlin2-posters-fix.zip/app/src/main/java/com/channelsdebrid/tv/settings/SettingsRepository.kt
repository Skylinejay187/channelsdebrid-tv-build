package com.channelsdebrid.tv.settings

import android.content.Context

class SettingsRepository(context: Context) {
    private val prefs = context.getSharedPreferences("channels_debrid_settings", Context.MODE_PRIVATE)

    fun loadTmdb() = TmdbSettings(
        apiKey = prefs.getString("tmdb_api_key", SettingsScaffold.defaultTmdb.apiKey).orEmpty(),
        region = prefs.getString("tmdb_region", SettingsScaffold.defaultTmdb.region).orEmpty(),
        language = prefs.getString("tmdb_language", SettingsScaffold.defaultTmdb.language).orEmpty()
    )

    fun saveTmdb(value: TmdbSettings) {
        prefs.edit()
            .putString("tmdb_api_key", value.apiKey)
            .putString("tmdb_region", value.region)
            .putString("tmdb_language", value.language)
            .apply()
    }

    fun loadCatalogs() = CatalogSettings(
        trendingMoviesEnabled = prefs.getBoolean("catalog_trending_movies", true),
        popularMoviesEnabled = prefs.getBoolean("catalog_popular_movies", true),
        trendingShowsEnabled = prefs.getBoolean("catalog_trending_shows", true),
        popularShowsEnabled = prefs.getBoolean("catalog_popular_shows", true),
        platformRowsEnabled = prefs.getBoolean("catalog_platform_rows", true),
        stremioCatalogRowsEnabled = prefs.getBoolean("catalog_stremio_rows", true)
    )

    fun saveCatalogs(value: CatalogSettings) {
        prefs.edit()
            .putBoolean("catalog_trending_movies", value.trendingMoviesEnabled)
            .putBoolean("catalog_popular_movies", value.popularMoviesEnabled)
            .putBoolean("catalog_trending_shows", value.trendingShowsEnabled)
            .putBoolean("catalog_popular_shows", value.popularShowsEnabled)
            .putBoolean("catalog_platform_rows", value.platformRowsEnabled)
            .putBoolean("catalog_stremio_rows", value.stremioCatalogRowsEnabled)
            .apply()
    }

    fun loadPrimaryAddon(): StremioAddonSettings {
        return loadStremioAddons().firstOrNull() ?: StremioAddonSettings(
            id = "",
            name = "",
            manifestUrl = "",
            enabled = false
        )
    }

    fun loadStremioAddons(): List<StremioAddonSettings> {
        val defaultAddon = SettingsScaffold.defaultAddons.firstOrNull() ?: StremioAddonSettings(
            id = "",
            name = "",
            manifestUrl = "",
            enabled = false
        )
        val enabled = prefs.getBoolean("stremio_enabled", defaultAddon.enabled)
        val rawNames = prefs.getString("stremio_names_multiline", "").orEmpty().trim()
        val rawManifests = prefs.getString("stremio_manifests_multiline", "").orEmpty().trim()

        val manifestLines = rawManifests
            .lineSequence()
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .toList()

        val nameLines = rawNames
            .lineSequence()
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .toList()

        if (manifestLines.isNotEmpty()) {
            return manifestLines.mapIndexed { index, manifestUrl ->
                val explicitName = nameLines.getOrNull(index).orEmpty()
                val inferredName = manifestUrl
                    .substringBefore('?')
                    .substringAfter("//", manifestUrl)
                    .substringBefore('/')
                    .substringBefore(':')
                    .replace("-", " ")
                    .replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
                StremioAddonSettings(
                    id = "addon_${index + 1}",
                    name = explicitName.ifBlank { if (index == 0) defaultAddon.name else inferredName.ifBlank { "Addon ${index + 1}" } },
                    manifestUrl = manifestUrl,
                    enabled = enabled
                )
            }
        }

        val legacy = StremioAddonSettings(
            id = prefs.getString("stremio_id", defaultAddon.id).orEmpty(),
            name = prefs.getString("stremio_name", defaultAddon.name).orEmpty(),
            manifestUrl = prefs.getString("stremio_manifest", defaultAddon.manifestUrl).orEmpty(),
            enabled = enabled
        )
        val fallback = if (legacy.manifestUrl.isBlank()) defaultAddon else legacy
        return if (fallback.manifestUrl.isBlank()) emptyList() else listOf(fallback)
    }

    fun savePrimaryAddon(value: StremioAddonSettings) {
        saveStremioAddons(listOf(value))
    }

    fun saveStremioAddons(values: List<StremioAddonSettings>) {
        val cleaned = values
            .map { it.copy(name = it.name.trim(), manifestUrl = it.manifestUrl.trim()) }
            .filter { it.manifestUrl.isNotBlank() }
        val primary = cleaned.firstOrNull() ?: SettingsScaffold.defaultAddons.firstOrNull() ?: StremioAddonSettings(
            id = "",
            name = "",
            manifestUrl = "",
            enabled = false
        )
        prefs.edit()
            .putString("stremio_id", primary.id)
            .putString("stremio_name", primary.name)
            .putString("stremio_manifest", primary.manifestUrl)
            .putBoolean("stremio_enabled", values.firstOrNull()?.enabled ?: primary.enabled)
            .putString("stremio_names_multiline", cleaned.joinToString("\n") { it.name })
            .putString("stremio_manifests_multiline", cleaned.joinToString("\n") { it.manifestUrl })
            .apply()
    }


    fun loadDebrid() = DebridSettings(
        realDebridEnabled = prefs.getBoolean("debrid_rd_enabled", SettingsScaffold.defaultDebrid.realDebridEnabled),
        realDebridApiKey = prefs.getString("debrid_rd_api_key", SettingsScaffold.defaultDebrid.realDebridApiKey).orEmpty(),
        torBoxEnabled = prefs.getBoolean("debrid_torbox_enabled", SettingsScaffold.defaultDebrid.torBoxEnabled),
        torBoxApiKey = prefs.getString("debrid_torbox_api_key", SettingsScaffold.defaultDebrid.torBoxApiKey).orEmpty(),
        preferredProvider = prefs.getString("debrid_preferred_provider", SettingsScaffold.defaultDebrid.preferredProvider).orEmpty(),
        autoFallback = prefs.getBoolean("debrid_auto_fallback", SettingsScaffold.defaultDebrid.autoFallback)
    )

    fun saveDebrid(value: DebridSettings) {
        prefs.edit()
            .putBoolean("debrid_rd_enabled", value.realDebridEnabled)
            .putString("debrid_rd_api_key", value.realDebridApiKey)
            .putBoolean("debrid_torbox_enabled", value.torBoxEnabled)
            .putString("debrid_torbox_api_key", value.torBoxApiKey)
            .putString("debrid_preferred_provider", value.preferredProvider)
            .putBoolean("debrid_auto_fallback", value.autoFallback)
            .apply()
    }

    fun loadChannelsDvr() = ChannelsDvrSettings(
        autoDetect = prefs.getBoolean("dvr_auto_detect", true),
        baseUrl = prefs.getString("dvr_base_url", "").orEmpty(),
        deviceId = prefs.getString("dvr_device_id", "").orEmpty()
    )

    fun saveChannelsDvr(value: ChannelsDvrSettings) {
        prefs.edit()
            .putBoolean("dvr_auto_detect", value.autoDetect)
            .putString("dvr_base_url", value.baseUrl)
            .remove("dvr_username")
            .remove("dvr_password")
            .putString("dvr_device_id", value.deviceId)
            .apply()
    }

    fun loadXtream() = XtreamSettings(
        server = prefs.getString("xtream_server", "").orEmpty(),
        username = prefs.getString("xtream_username", "").orEmpty(),
        password = prefs.getString("xtream_password", "").orEmpty(),
        m3uUrl = prefs.getString("xtream_m3u_url", "").orEmpty(),
        enabled = prefs.getBoolean("xtream_enabled", false)
    )

    fun saveXtream(value: XtreamSettings) {
        prefs.edit()
            .putString("xtream_server", value.server)
            .putString("xtream_username", value.username)
            .putString("xtream_password", value.password)
            .putString("xtream_m3u_url", value.m3uUrl)
            .putBoolean("xtream_enabled", value.enabled)
            .apply()
    }

    fun loadStorage() = StorageSettings(
        preferredTarget = prefs.getString("storage_preferred", SettingsScaffold.defaultStorage.preferredTarget).orEmpty(),
        usbPath = prefs.getString("storage_usb_path", "").orEmpty(),
        nasPath = prefs.getString("storage_nas_path", "").orEmpty(),
        timeshiftMinutes = prefs.getInt("storage_timeshift_minutes", SettingsScaffold.defaultStorage.timeshiftMinutes),
        movieCacheEnabled = prefs.getBoolean("storage_movie_cache_enabled", SettingsScaffold.defaultStorage.movieCacheEnabled)
    )

    fun saveStorage(value: StorageSettings) {
        prefs.edit()
            .putString("storage_preferred", value.preferredTarget)
            .putString("storage_usb_path", value.usbPath)
            .putString("storage_nas_path", value.nasPath)
            .putInt("storage_timeshift_minutes", value.timeshiftMinutes)
            .putBoolean("storage_movie_cache_enabled", value.movieCacheEnabled)
            .apply()
    }

    fun loadTrailers() = TrailerSettings(
        enabled = prefs.getBoolean("trailers_enabled", true),
        autoplayOnFocus = prefs.getBoolean("trailers_autoplay_focus", false),
        autoplayDelayMs = prefs.getLong("trailers_delay_ms", 1500L),
        popupMode = prefs.getString("trailers_popup_mode", "center_modal").orEmpty()
    )

    fun saveTrailers(value: TrailerSettings) {
        prefs.edit()
            .putBoolean("trailers_enabled", value.enabled)
            .putBoolean("trailers_autoplay_focus", value.autoplayOnFocus)
            .putLong("trailers_delay_ms", value.autoplayDelayMs)
            .putString("trailers_popup_mode", value.popupMode)
            .apply()
    }

    fun loadPlayback() = PlaybackSettings(
        frameRateMatching = prefs.getBoolean("playback_frame_rate_matching", true),
        preferExternalStorageForCache = prefs.getBoolean("playback_prefer_external", true),
        timeshiftEnabled = prefs.getBoolean("playback_timeshift_enabled", true),
        autoPlayBestStream = prefs.getBoolean("playback_auto_best", true),
        fileSizeLimitGb = prefs.getInt("playback_file_limit_gb", 40),
        ultraHdGuideUiEnabled = prefs.getBoolean("playback_4k_ui_enabled", true),
        liveStatusChecksEnabled = prefs.getBoolean("playback_status_checks_enabled", true)
    )

    fun savePlayback(value: PlaybackSettings) {
        prefs.edit()
            .putBoolean("playback_frame_rate_matching", value.frameRateMatching)
            .putBoolean("playback_prefer_external", value.preferExternalStorageForCache)
            .putBoolean("playback_timeshift_enabled", value.timeshiftEnabled)
            .putBoolean("playback_auto_best", value.autoPlayBestStream)
            .putInt("playback_file_limit_gb", value.fileSizeLimitGb)
            .putBoolean("playback_4k_ui_enabled", value.ultraHdGuideUiEnabled)
            .putBoolean("playback_status_checks_enabled", value.liveStatusChecksEnabled)
            .apply()
    }


    fun loadLiveBackend() = LiveBackendSettings(
        baseUrl = prefs.getString("live_backend_base_url", "http://192.168.100.55:8181").orEmpty(),
        userId = prefs.getString("live_backend_user_id", "demo").orEmpty(),
        autoSyncSources = prefs.getBoolean("live_backend_auto_sync", true)
    )

    fun saveLiveBackend(value: LiveBackendSettings) {
        prefs.edit()
            .putString("live_backend_base_url", value.baseUrl)
            .putString("live_backend_user_id", value.userId)
            .putBoolean("live_backend_auto_sync", value.autoSyncSources)
            .apply()
    }

}
