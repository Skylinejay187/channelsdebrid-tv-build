package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.6.4 LIVE TV SOURCES + PLAYER WIRING";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.6.4_livetv_sources_xtream_channelsdvr_player_clean_base";
    private BuildMarkers() {}
}
