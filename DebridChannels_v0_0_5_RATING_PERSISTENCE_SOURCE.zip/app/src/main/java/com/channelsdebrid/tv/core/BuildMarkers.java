package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.0.5 RATING PERSISTENCE";
    public static final String LOG_MARKER = "DC_V0_0_5_RATING_PERSISTENCE_ACTIVE";
    private BuildMarkers() {}
}
