# Rewrite Build Audit — v0.0.5 Rating Persistence

Base used: stable v0.0.x clean line with v0.0.3 VOD flow and v0.0.1 visual behavior.

Rule followed: clean rewrite/consolidation only. Broken v7.x code was not used.

Changes:
- Hero ratings are cached in runtime state so async artwork/catalog refresh cannot wipe IMDb/TMDB badges after they briefly appear.
- Default rating display remains Hero only.
- Added Pro Layout Editor option: Hero + row card ratings, default Off.
- Preserved media information screen → stream selection → VOD player flow.
- Preserved card/logo visuals, row navigation, Pro Layout Editor, backend default URL.

Markers:
- versionName 0.0.5
- versionCode 5
- logcat DC_V0_0_5_RATING_PERSISTENCE_ACTIVE
