package com.channelsdebrid.tv.config

object UIConfigManager {

    enum class UiRenderMode {
        AUTO,
        FORCE_1080P,
        FORCE_4K
    }

    var uiRenderMode: UiRenderMode = UiRenderMode.AUTO

    fun is4KActive(context: android.content.Context): Boolean {
        val width = context.resources.displayMetrics.widthPixels
        return when (uiRenderMode) {
            UiRenderMode.FORCE_4K -> true
            UiRenderMode.FORCE_1080P -> false
            UiRenderMode.AUTO -> width >= 3840
        }
    }
}
