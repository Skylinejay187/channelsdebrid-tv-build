package com.channelsdebrid.tv.config

object UiModeApplier {

    fun apply(context: android.content.Context) {
        val metrics = context.resources.displayMetrics

        when (UIConfigManager.uiRenderMode) {

            UIConfigManager.UiRenderMode.FORCE_4K -> {
                metrics.density = 1.0f
                metrics.scaledDensity = 1.0f
            }

            UIConfigManager.UiRenderMode.FORCE_1080P -> {
                metrics.density = 2.0f
                metrics.scaledDensity = 2.0f
            }

            UIConfigManager.UiRenderMode.AUTO -> {
                if (metrics.widthPixels >= 3840) {
                    metrics.density = 1.0f
                    metrics.scaledDensity = 1.0f
                }
            }
        }
    }
}
