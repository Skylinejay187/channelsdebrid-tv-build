package com.channelsdebrid.tv

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.channelsdebrid.tv.live.LiveSourceResolver
import com.channelsdebrid.tv.playback.PlayerActivity
import com.channelsdebrid.tv.settings.SettingsRepository
import java.util.concurrent.Executors

class LiveTvActivity : AppCompatActivity() {

    private lateinit var settingsRepository: SettingsRepository
    private lateinit var statusText: TextView
    private lateinit var channelList: LinearLayout
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_live_tv)
        settingsRepository = SettingsRepository(this)

        statusText = findViewById(R.id.liveTvStatus)
        channelList = findViewById(R.id.liveTvChannelList)

        findViewById<View>(R.id.liveTvBackButton).setOnClickListener { finish() }
        loadChannels()
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    private fun loadChannels() {
        statusText.text = "Checking configured Live TV sources…"
        channelList.removeAllViews()

        val dvr = settingsRepository.loadChannelsDvr()
        val xtream = settingsRepository.loadXtream()

        executor.execute {
            val allChannels = mutableListOf<LiveSourceResolver.ChannelItem>()
            val statusParts = mutableListOf<String>()
            var dvrDeviceId = dvr.deviceId

            if (dvr.baseUrl.isNotBlank()) {
                val dvrResult = LiveSourceResolver.loadDvrChannels(dvr.baseUrl, dvr.deviceId)
                allChannels += dvrResult.channels
                statusParts += dvrResult.message
                if (!dvrResult.deviceId.isNullOrBlank() && dvrResult.deviceId != dvr.deviceId) {
                    dvrDeviceId = dvrResult.deviceId
                    settingsRepository.saveChannelsDvr(dvr.copy(deviceId = dvrDeviceId))
                }
            }

            if (xtream.enabled && xtream.server.isNotBlank() && xtream.username.isNotBlank() && xtream.password.isNotBlank()) {
                val (xtreamChannels, xtreamMessage) = LiveSourceResolver.loadXtreamChannels(
                    xtream.server,
                    xtream.username,
                    xtream.password
                )
                allChannels += xtreamChannels
                statusParts += xtreamMessage
            }

            val dedupedChannels = allChannels
                .distinctBy { it.source + "|" + it.name + "|" + it.url }
                .take(400)

            val message = when {
                dedupedChannels.isNotEmpty() -> buildString {
                    append("Live TV ready • ")
                    append(dedupedChannels.size)
                    append(" channels")
                    if (dvrDeviceId.isNotBlank()) {
                        append(" • DVR device ")
                        append(dvrDeviceId)
                    }
                    if (statusParts.isNotEmpty()) {
                        append("\n")
                        append(statusParts.joinToString(" • "))
                    }
                }
                statusParts.isNotEmpty() -> statusParts.joinToString(" • ")
                else -> "No source configured. Add Channels DVR or Xtream in Settings."
            }

            runOnUiThread {
                statusText.text = message
                if (dedupedChannels.isEmpty()) {
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                } else {
                    dedupedChannels.forEachIndexed { index, channel ->
                        channelList.addView(makeChannelRow(index + 1, channel))
                    }
                }
            }
        }
    }

    private fun makeChannelRow(index: Int, channel: LiveSourceResolver.ChannelItem): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14))
            isFocusable = true
            isClickable = true
            background = getDrawable(R.drawable.pill_dark)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.bottomMargin = dp(12)
            layoutParams = lp
            setOnClickListener {
                startActivity(
                    Intent(this@LiveTvActivity, PlayerActivity::class.java)
                        .putExtra(PlayerActivity.EXTRA_STREAM_URL, channel.url)
                        .putExtra(PlayerActivity.EXTRA_TITLE, channel.name)
                        .putExtra(PlayerActivity.EXTRA_SOURCE_LABEL, channel.source)
                        .putExtra(PlayerActivity.EXTRA_DEBUG_LABEL, channel.debug)
                )
            }
            setOnFocusChangeListener { v, hasFocus ->
                v.animate().cancel()
                v.animate().scaleX(if (hasFocus) 1.03f else 1f)
                    .scaleY(if (hasFocus) 1.03f else 1f)
                    .alpha(if (hasFocus) 1f else 0.96f)
                    .setDuration(140)
                    .start()
            }
        }

        val num = TextView(this).apply {
            text = index.toString().padStart(2, '0')
            setTextColor(0xFFEDEDED.toInt())
            textSize = 15f
            setPadding(0, 0, dp(16), 0)
        }
        val textColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val name = TextView(this).apply {
            text = channel.name
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 17f
            setSingleLine(true)
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val debug = TextView(this).apply {
            text = channel.debug.ifBlank { channel.url }
            setTextColor(0xFF9EA8B8.toInt())
            textSize = 11f
            setSingleLine(true)
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val source = TextView(this).apply {
            text = channel.source
            setTextColor(0xFFB7BDC6.toInt())
            textSize = 13f
        }

        textColumn.addView(name)
        textColumn.addView(debug)
        row.addView(num)
        row.addView(textColumn)
        row.addView(source)
        return row
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
