package com.channelsdebrid.tv

import android.animation.ObjectAnimator
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class StartupActivity : AppCompatActivity() {
    private companion object { private const val TAG = "DebridChannels" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i(TAG, "STARTUP_BRANDING_FULL_PASS: clean_black_splash=true centeredLogo=true noCrop=true launcherIconsReplaced=true")

        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(0, 0, 0)) }

        val logo = ImageView(this).apply {
            setImageResource(R.drawable.splash_branding)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            alpha = 0f
        }

        val track = View(this).apply { setBackgroundColor(0xFF242424.toInt()); alpha = 0f }
        val bar = View(this).apply { setBackgroundColor(0xFFFF8A00.toInt()); alpha = 0f; scaleX = 0f; pivotX = 0f }
        val label = TextView(this).apply {
            text = "LOADING..."
            textSize = 16f
            letterSpacing = 0.18f
            setTextColor(0xFFECECEC.toInt())
            gravity = Gravity.CENTER
            alpha = 0f
        }

        root.addView(logo, FrameLayout.LayoutParams(dp(760), dp(330), Gravity.CENTER).apply { bottomMargin = dp(70) })
        root.addView(track, FrameLayout.LayoutParams(dp(320), dp(4), Gravity.CENTER).apply { topMargin = dp(290) })
        root.addView(bar, FrameLayout.LayoutParams(dp(320), dp(4), Gravity.CENTER).apply { topMargin = dp(290) })
        root.addView(label, FrameLayout.LayoutParams(dp(420), dp(48), Gravity.CENTER).apply { topMargin = dp(350) })

        setContentView(root)

        ObjectAnimator.ofFloat(logo, "alpha", 0f, 1f).setDuration(420).start()
        ObjectAnimator.ofFloat(logo, "translationY", dp(18).toFloat(), 0f).setDuration(520).start()
        ObjectAnimator.ofFloat(track, "alpha", 0f, 1f).setDuration(420).start()
        ObjectAnimator.ofFloat(bar, "alpha", 0f, 1f).setDuration(420).start()
        ObjectAnimator.ofFloat(label, "alpha", 0f, 1f).setDuration(520).start()
        ObjectAnimator.ofFloat(bar, "scaleX", 0f, 1f).apply { duration = 1050; interpolator = LinearInterpolator(); start() }

        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }, 1250)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
