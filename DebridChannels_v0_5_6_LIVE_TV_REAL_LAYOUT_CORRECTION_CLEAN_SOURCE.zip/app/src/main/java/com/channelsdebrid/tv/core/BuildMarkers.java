package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.5.6 LIVE TV GOOGLE REFERENCE REAL LAYOUT";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.5.6_live_tv_google_reference_real_layout_no_sample_clean_base";
    private BuildMarkers() {}
}
