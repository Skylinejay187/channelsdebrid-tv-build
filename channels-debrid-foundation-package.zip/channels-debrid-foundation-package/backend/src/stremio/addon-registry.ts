import fs from "node:fs/promises"
import path from "node:path"

const ADDONS_PATH = path.join(process.cwd(), "data", "stremio-addons.json")

interface AddonDef {
  id: string
  name: string
  transportUrl: string
}

export function createAddonRegistry() {
  return {
    async listAddons(): Promise<AddonDef[]> {
      const raw = await fs.readFile(ADDONS_PATH, "utf8")
      return JSON.parse(raw)
    },

    async getCatalog(addonId: string, type: string, catalogId: string, limit: number) {
      const addons = await this.listAddons()
      const addon = addons.find(a => a.id === addonId)
      if (!addon) throw new Error(`Unknown addon ${addonId}`)
      const url = `${addon.transportUrl}/catalog/${type}/${catalogId}.json`
      const res = await fetch(url)
      if (!res.ok) throw new Error(`Addon catalog fetch failed: ${res.status}`)
      const data = await res.json()
      return (data.metas ?? []).slice(0, limit)
    }
  }
}
