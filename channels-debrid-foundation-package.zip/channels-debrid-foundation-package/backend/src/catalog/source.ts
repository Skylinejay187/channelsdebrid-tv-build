import type { CatalogItem, CatalogRowDefinition } from "./types.js"

export interface CatalogSource {
  canHandle(row: CatalogRowDefinition): boolean
  getItems(row: CatalogRowDefinition): Promise<CatalogItem[]>
}
