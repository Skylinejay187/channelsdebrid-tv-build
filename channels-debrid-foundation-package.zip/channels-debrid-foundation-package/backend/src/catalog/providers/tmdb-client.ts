const TMDB_BASE = "https://api.themoviedb.org/3"

async function fetchJson(url: string) {
  const res = await fetch(url)
  if (!res.ok) throw new Error(`TMDB error ${res.status}`)
  return res.json()
}

export function createTmdbClient(apiKey: string) {
  const auth = `api_key=${apiKey}`

  return {
    async trendingMovies(limit: number) {
      const data = await fetchJson(`${TMDB_BASE}/trending/movie/week?${auth}`)
      return (data.results ?? []).slice(0, limit)
    },
    async popularMovies(limit: number) {
      const data = await fetchJson(`${TMDB_BASE}/movie/popular?${auth}`)
      return (data.results ?? []).slice(0, limit)
    },
    async trendingShows(limit: number) {
      const data = await fetchJson(`${TMDB_BASE}/trending/tv/week?${auth}`)
      return (data.results ?? []).slice(0, limit)
    },
    async popularShows(limit: number) {
      const data = await fetchJson(`${TMDB_BASE}/tv/popular?${auth}`)
      return (data.results ?? []).slice(0, limit)
    },
    async providerMovies(provider: string, _mode: string, limit: number) {
      const providerId = mapProvider(provider)
      const data = await fetchJson(`${TMDB_BASE}/discover/movie?${auth}&with_watch_providers=${providerId}&watch_region=US&sort_by=popularity.desc`)
      return (data.results ?? []).slice(0, limit)
    },
    async providerShows(provider: string, _mode: string, limit: number) {
      const providerId = mapProvider(provider)
      const data = await fetchJson(`${TMDB_BASE}/discover/tv?${auth}&with_watch_providers=${providerId}&watch_region=US&sort_by=popularity.desc`)
      return (data.results ?? []).slice(0, limit)
    }
  }
}

function mapProvider(provider: string): string {
  switch (provider) {
    case "netflix": return "8"
    case "prime": return "9"
    case "disney": return "337"
    case "max": return "1899"
    case "hulu": return "15"
    case "apple": return "350"
    case "peacock": return "386"
    case "paramount": return "531"
    default: return "8"
  }
}
