import fs from "node:fs/promises"
import path from "node:path"
import type { CatalogRowDefinition } from "./types.js"

const CONFIG_PATH = path.join(process.cwd(), "data", "home-rows.json")

export async function loadRowConfig(): Promise<CatalogRowDefinition[]> {
  const raw = await fs.readFile(CONFIG_PATH, "utf8")
  const rows = JSON.parse(raw) as CatalogRowDefinition[]
  return rows.filter(r => r.enabled).sort((a, b) => a.position - b.position)
}

export async function saveRowConfig(rows: CatalogRowDefinition[]): Promise<void> {
  await fs.mkdir(path.dirname(CONFIG_PATH), { recursive: true })
  await fs.writeFile(CONFIG_PATH, JSON.stringify(rows, null, 2), "utf8")
}
