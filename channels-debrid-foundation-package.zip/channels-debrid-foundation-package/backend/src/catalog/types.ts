export type MediaType = "movie" | "series"

export interface ProviderInfo {
  id: string
  name: string
  logo?: string
}

export interface Badge {
  type: string
  label: string
}

export interface PlaybackInfo {
  available: boolean
  sourceType?: string
  sourceId?: string
  deepLink?: string
}

export interface MetaIds {
  tmdbId?: number
  imdbId?: string
  traktId?: number
}

export interface CatalogItem {
  id: string
  type: MediaType
  title: string
  originalTitle?: string
  year?: number
  rating?: number
  runtime?: number
  genres?: string[]
  description?: string
  poster?: string
  backdrop?: string
  logo?: string
  provider?: ProviderInfo
  badges?: Badge[]
  playback?: PlaybackInfo
  meta?: MetaIds
}

export interface CatalogRowDefinition {
  id: string
  title: string
  type: MediaType
  style: "landscape"
  source: "internal" | "stremio_addon"
  catalogId: string
  provider?: string
  addonId?: string
  limit: number
  enabled: boolean
  position: number
  removable: boolean
  replaceable: boolean
  reorderable: boolean
}

export interface HomeRow extends CatalogRowDefinition {
  items: CatalogItem[]
}

export interface HeroAction {
  id: string
  label: string
}

export interface HeroItem {
  id: string
  type: MediaType
  title: string
  subtitle?: string | null
  description?: string | null
  backdrop?: string | null
  logo?: string | null
  actions: HeroAction[]
}

export interface HomeResponse {
  hero?: HeroItem
  rows: HomeRow[]
}
