import type { CatalogSource } from "../source.js"
import type { CatalogItem, CatalogRowDefinition } from "../types.js"

export class InternalCatalogSource implements CatalogSource {
  constructor(
    private readonly tmdb: {
      trendingMovies: (limit: number) => Promise<any[]>
      popularMovies: (limit: number) => Promise<any[]>
      trendingShows: (limit: number) => Promise<any[]>
      popularShows: (limit: number) => Promise<any[]>
      providerMovies: (provider: string, mode: string, limit: number) => Promise<any[]>
      providerShows: (provider: string, mode: string, limit: number) => Promise<any[]>
    }
  ) {}

  canHandle(row: CatalogRowDefinition): boolean {
    return row.source === "internal"
  }

  async getItems(row: CatalogRowDefinition): Promise<CatalogItem[]> {
    let raw: any[] = []
    switch (row.catalogId) {
      case "movies.trending": raw = await this.tmdb.trendingMovies(row.limit); break
      case "movies.popular": raw = await this.tmdb.popularMovies(row.limit); break
      case "shows.trending": raw = await this.tmdb.trendingShows(row.limit); break
      case "shows.popular": raw = await this.tmdb.popularShows(row.limit); break
      default:
        if (row.catalogId.startsWith("provider.") && row.provider) {
          const [, provider, kind, mode] = row.catalogId.split(".")
          raw = kind === "movies"
            ? await this.tmdb.providerMovies(provider, mode, row.limit)
            : await this.tmdb.providerShows(provider, mode, row.limit)
        }
    }
    return raw.map(item => normalizeTmdbItem(item, row))
  }
}

function normalizeTmdbItem(item: any, row: CatalogRowDefinition): CatalogItem {
  const type = row.type
  const title = type === "movie" ? item.title : item.name
  const yearSource = type === "movie" ? item.release_date : item.first_air_date
  return {
    id: `tmdb_${type}_${item.id}`,
    type,
    title,
    originalTitle: type === "movie" ? item.original_title : item.original_name,
    year: yearSource ? Number(String(yearSource).slice(0, 4)) : undefined,
    rating: item.vote_average,
    description: item.overview,
    poster: item.poster_path ? `https://image.tmdb.org/t/p/w780${item.poster_path}` : undefined,
    backdrop: item.backdrop_path ? `https://image.tmdb.org/t/p/original${item.backdrop_path}` : undefined,
    provider: row.provider ? { id: row.provider, name: providerDisplayName(row.provider) } : undefined,
    badges: [
      ...(item.vote_average ? [{ type: "rating", label: `TMDB ${item.vote_average.toFixed(1)}` }] : []),
      ...(row.provider ? [{ type: "platform", label: providerDisplayName(row.provider) }] : [])
    ],
    playback: {
      available: true,
      sourceType: "catalog",
      sourceId: row.catalogId,
      deepLink: `/api/play/${type}/${item.id}`
    },
    meta: { tmdbId: item.id }
  }
}

function providerDisplayName(provider: string): string {
  switch (provider) {
    case "netflix": return "Netflix"
    case "prime": return "Prime Video"
    case "disney": return "Disney+"
    case "max": return "Max"
    case "hulu": return "Hulu"
    case "apple": return "Apple TV+"
    case "peacock": return "Peacock"
    case "paramount": return "Paramount+"
    default: return provider
  }
}
