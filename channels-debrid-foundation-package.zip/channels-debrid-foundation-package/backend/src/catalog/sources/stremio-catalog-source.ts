import type { CatalogSource } from "../source.js"
import type { CatalogItem, CatalogRowDefinition } from "../types.js"

export class StremioCatalogSource implements CatalogSource {
  constructor(
    private readonly addonRegistry: {
      getCatalog: (addonId: string, type: string, catalogId: string, limit: number) => Promise<any[]>
    }
  ) {}

  canHandle(row: CatalogRowDefinition): boolean {
    return row.source === "stremio_addon" && !!row.addonId
  }

  async getItems(row: CatalogRowDefinition): Promise<CatalogItem[]> {
    const metas = await this.addonRegistry.getCatalog(row.addonId!, row.type, row.catalogId, row.limit)
    return metas.map(meta => ({
      id: meta.id,
      type: row.type,
      title: meta.name ?? meta.title ?? "Unknown",
      year: meta.year,
      description: meta.description,
      poster: meta.poster ?? meta.posterShape,
      backdrop: meta.background ?? meta.poster,
      logo: meta.logo,
      badges: meta.imdbRating ? [{ type: "rating", label: `IMDb ${meta.imdbRating}` }] : [],
      playback: {
        available: true,
        sourceType: "stremio_addon",
        sourceId: row.addonId,
        deepLink: `/api/stremio/meta/${encodeURIComponent(meta.id)}`
      }
    }))
  }
}
