import { Router } from "express"
import { loadRowConfig, saveRowConfig } from "../catalog/config-store.js"

export function adminRowsRouter() {
  const router = Router()

  router.get("/api/admin/rows", async (_req, res, next) => {
    try {
      res.json({ rows: await loadRowConfig() })
    } catch (err) {
      next(err)
    }
  })

  router.post("/api/admin/rows/reorder", async (req, res, next) => {
    try {
      const order = req.body.order as string[]
      const rows = await loadRowConfig()
      const updated = rows
        .map(r => ({ ...r, position: Math.max(order.indexOf(r.id), 0) + 1 }))
        .sort((a, b) => a.position - b.position)
      await saveRowConfig(updated)
      res.json({ ok: true })
    } catch (err) {
      next(err)
    }
  })

  return router
}
