import express from "express"
import { homeRouter } from "./routes/home.js"
import { adminRowsRouter } from "./routes/admin-rows.js"
import { CatalogManager } from "./catalog/catalog-manager.js"
import { InternalCatalogSource } from "./catalog/sources/internal-catalog-source.js"
import { StremioCatalogSource } from "./catalog/sources/stremio-catalog-source.js"
import { createTmdbClient } from "./catalog/providers/tmdb-client.js"
import { createAddonRegistry } from "./stremio/addon-registry.js"

export async function createApp() {
  const app = express()
  app.use(express.json())

  const tmdb = createTmdbClient(process.env.TMDB_API_KEY ?? "")
  const addonRegistry = createAddonRegistry()

  const catalogManager = new CatalogManager([
    new InternalCatalogSource(tmdb),
    new StremioCatalogSource(addonRegistry)
  ])

  app.use(homeRouter(catalogManager))
  app.use(adminRowsRouter())

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true })
  })

  return app
}
