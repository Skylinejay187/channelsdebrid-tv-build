package com.channelsdebrid.tv.data

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale
import kotlin.math.roundToInt

class LiveGuideProgramResolver(
    private val backendBaseUrl: String = "http://192.168.100.55:8181",
    private val userId: String = "demo"
) {
    data class Program(
        val title: String,
        val start: String,
        val end: String,
        val widthDp: Int,
        val description: String = "",
        val imageUrl: String = ""
    )

    fun programsFor(channelName: String, channelNumber: String, tvgId: String = "", source: String = ""): List<Program> {
        val base = backendBaseUrl.trim().trimEnd('/').ifBlank { return emptyList() }
        val encodedName = enc(channelName)
        val encodedNumber = enc(channelNumber)
        val encodedTvg = enc(tvgId)
        val encodedSource = enc(source)
        val encodedUser = enc(userId.ifBlank { "demo" })
        val urls = listOf(
            "$base/live/guide?userId=$encodedUser&channelName=$encodedName&channelNumber=$encodedNumber&tvgId=$encodedTvg&source=$encodedSource",
            "$base/live/guide?user_id=$encodedUser&name=$encodedName&number=$encodedNumber&tvgId=$encodedTvg&source=$encodedSource",
            "$base/api/live/guide?userId=$encodedUser&channelName=$encodedName&channelNumber=$encodedNumber&tvgId=$encodedTvg&source=$encodedSource",
            "$base/api/live/guide?user_id=$encodedUser&name=$encodedName&number=$encodedNumber&tvgId=$encodedTvg&source=$encodedSource",
            "$base/live/epg?userId=$encodedUser&channelName=$encodedName&channelNumber=$encodedNumber&tvgId=$encodedTvg&source=$encodedSource",
            "$base/api/guide?userId=$encodedUser&name=$encodedName&number=$encodedNumber&tvgId=$encodedTvg",
            "$base/guide?userId=$encodedUser&name=$encodedName&number=$encodedNumber&tvgId=$encodedTvg"
        )
        for (url in urls) {
            val parsed = fetch(url)
            if (parsed.isNotEmpty()) return parsed
        }
        return emptyList()
    }

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

    private fun fetch(url: String): List<Program> = try {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 1800
            readTimeout = 3000
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
        }
        if (conn.responseCode !in 200..299) return emptyList()
        parse(conn.inputStream.bufferedReader().use { it.readText() })
    } catch (_: Exception) { emptyList() }

    private fun parse(body: String): List<Program> {
        if (body.isBlank()) return emptyList()
        val root = try {
            if (body.trim().startsWith("[")) JSONObject().put("programs", JSONArray(body)) else JSONObject(body)
        } catch (_: Exception) { return emptyList() }
        val arr = findProgramArray(root) ?: return emptyList()
        val out = mutableListOf<Program>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val title = firstString(obj, "title", "Title", "name", "Name", "program", "Program", "episodeTitle", "EpisodeTitle")
            if (title.isBlank()) continue
            val startRaw = firstString(obj, "startLabel", "start", "Start", "startTime", "StartTime", "airDateTime", "time")
            val endRaw = firstString(obj, "endLabel", "end", "End", "endTime", "EndTime", "stop")
            val start = labelTime(startRaw).ifBlank { if (i == 0) "Now" else "Next" }
            val end = labelTime(endRaw).ifBlank { "Later" }
            val minutes = durationMinutes(obj).coerceIn(15, 240)
            val description = firstString(obj, "description", "Description", "summary", "plot", "desc")
            val image = firstString(obj, "image", "Image", "imageUrl", "ImageURL", "poster", "backdrop", "fanart", "thumbnail")
            out += Program(title, start, end, ((minutes / 30f) * 120).roundToInt().coerceIn(100, 520), description, image)
        }
        return out.take(10)
    }

    private fun findProgramArray(root: JSONObject): JSONArray? {
        listOf("programs", "guide", "items", "epg", "data", "results", "airings", "listings").forEach { key ->
            root.optJSONArray(key)?.let { return it }
        }
        listOf("channel", "Channel", "schedule", "Schedule", "guideData").forEach { key ->
            val obj = root.optJSONObject(key) ?: return@forEach
            listOf("programs", "guide", "items", "epg", "airings", "listings").forEach { inner ->
                obj.optJSONArray(inner)?.let { return it }
            }
        }
        return null
    }

    private fun firstString(obj: JSONObject, vararg keys: String): String {
        for (key in keys) {
            val value = obj.optString(key).trim()
            if (value.isNotBlank() && !value.equals("null", true)) return value
        }
        return ""
    }

    private fun labelTime(raw: String): String {
        val value = raw.trim()
        if (value.isBlank()) return ""
        if (Regex("^[0-9]{1,2}:[0-9]{2}(\\s?[AP]M)?$", RegexOption.IGNORE_CASE).matches(value)) return value.uppercase(Locale.US)
        val candidates = listOf(
            "yyyy-MM-dd'T'HH:mm:ss.SSSX",
            "yyyy-MM-dd'T'HH:mm:ssX",
            "yyyy-MM-dd HH:mm:ss",
            "yyyyMMddHHmmss Z"
        )
        for (fmt in candidates) {
            try {
                val date = SimpleDateFormat(fmt, Locale.US).parse(value) ?: continue
                return SimpleDateFormat("h:mm a", Locale.US).format(date)
            } catch (_: Exception) {}
        }
        return value.takeLast(8).trim().ifBlank { value.take(12) }
    }

    private fun durationMinutes(obj: JSONObject): Int {
        val explicit = obj.optInt("durationMinutes", obj.optInt("duration", obj.optInt("Duration", 0)))
        if (explicit > 0) return if (explicit > 1000) explicit / 60 else explicit
        return 30
    }
}
