package com.channelsdebrid.tv.core;
public final class BuildMarkers {
    public static final String VERSION = "v0.7.4 Full UI Root Cleanup + Hero Density Toggle";
    public static final String LOG_MARKER = "DC_BUILD_MARKER: v0.7.4_full_ui_root_cleanup_hero_density_toggle_default_4k_clean_base";
}
