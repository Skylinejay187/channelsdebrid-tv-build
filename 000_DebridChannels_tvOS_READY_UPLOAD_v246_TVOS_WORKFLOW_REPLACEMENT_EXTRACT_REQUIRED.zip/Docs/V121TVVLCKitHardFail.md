# v121 TVVLCKit hard-fail packaging check

The previous v120 verification was still too weak. It could pass even when the final IPA stayed small and did not include a real VLC binary payload.

v121 refuses to package unless:
- TVVLCKit is present in Podfile.lock and Pods/Manifest.lock.
- VLC-related binary files exist inside the built `.app` bundle.
- The embedded VLC payload is at least 10MB.
- The app executable links against TVVLCKit/VLCKit/libvlc according to `otool -L`.
- The final IPA is at least 30MB.

If GitHub still produces a small IPA from this package, then the workflow from this ZIP is not the workflow being run in the repository.
