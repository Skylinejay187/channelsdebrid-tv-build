# v181 Live TV Select Command Compile Fix

- Removed unsupported SwiftUI `.onSelectCommand` calls that failed on the GitHub/tvOS build toolchain.
- Kept center-click playback through the Button action and tap/play handlers.
- Preserved the v179 single-step DPAD behavior.
- Preserved v180 Google-style guide structure and XMLTV/Gracenotes artwork matching.
