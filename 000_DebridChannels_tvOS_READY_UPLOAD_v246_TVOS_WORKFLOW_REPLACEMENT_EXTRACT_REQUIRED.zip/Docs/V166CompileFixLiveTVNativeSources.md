# V166 Compile Fix + Live TV Native Sources

Base: v165 Live TV native sources.

Fixes applied:
- Broke `PlayerControlButton.body` into smaller computed SwiftUI subviews/properties so Swift can type-check the overlay control expression reliably in GitHub Actions.
- Marked `LiveTVSourceModel.accent(for:)` as `nonisolated static` so cached/live channel model conversion can call the category color helper without violating MainActor isolation.
- Updated visible/runtime markers from v165/v164 to v166 where applicable.

Preserved:
- KSPlayer primary playback path.
- VLC fallback path.
- MPV removed.
- AVPlayer not restored as primary.
- v73/v155 visual geometry direction.
- sharp artwork renderer direction.
- v165 native Live TV source endpoints.
