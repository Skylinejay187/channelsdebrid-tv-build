# V170 Live TV Guide Scroll Gracenotes Focus Fix

- Removed remaining tvOS system Button focus frame from Live TV grid cards by replacing tile Buttons with custom focusable card containers.
- Rebuilt guide rows as custom focusable row containers so UP/DOWN scrolls through the guide instead of trapping focus inside repeated program buttons.
- Added ScrollViewReader auto-follow for the selected guide row.
- Removed duplicate guide clock/time rendering from the preview header and kept a single timeline header.
- Added XMLTV channel icon matching so guide/grid artwork can fill from XMLTV icons when M3U/DVR channel icons are missing.
- Added Channels DVR station image fallback using /images/station/{id} when native channel JSON does not provide an explicit logo URL.
- Improved guide match status reporting for channels/programs.
- Preserved Live TV cache-disabled playback path for TS/HLS direct streams through the existing KSPlayer/VLC stack.
- Updated visible build marker to v170.
