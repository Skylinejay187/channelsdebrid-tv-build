# V172 Live TV Menu / Guide / Gracenotes Fix

- Centered the main top menu at the true horizontal midpoint instead of sitting right-heavy.
- Removed the guide time header row that caused the unwanted double clock/time-header visual.
- Hardened Channels DVR endpoint usage:
  - /devices/ANY/channels.m3u
  - /devices/ANY/channels
  - /devices/ANY/guide/xmltv?duration=86400
  - /devices/ANY/guide/xmltv fallback
  - /devices
  - /dvr/lineups
- Added local Channels DVR base normalization so entering only an IP automatically uses http://IP:8089.
- Improved XMLTV/Gracenotes-style station matching across tvg-id, station id, channel number, display name, and logo text.
- Kept Live TV VOD cache disabled and playback routed direct for TS/HLS streams.
- Retuned Live TV card focus to use only the app's custom cyan/purple focus, not a white focus plate.
