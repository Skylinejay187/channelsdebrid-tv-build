import Foundation

// DEBRID_CHANNELS_TVOS_BUILD_V88_SLOW_REBUILD_FOCUS_RESOLVER_PLAYER
// Slow rebuild from v86/v73 baseline: select debounce, static right cards, expanded Stremio resolver,
// detail info shifted right, top menu visibility restored, v73 visuals preserved.

enum V88SlowRebuildAudit {
    static let marker = "DEBRID_CHANNELS_TVOS_BUILD_V88_SLOW_REBUILD_FOCUS_RESOLVER_PLAYER"
    static let visualBaseline = "v73 Home/detail visual baseline preserved"
    static let rightPosterAnimation = "removed"
    static let inputDebounce = "enabled"
    static let stremioResolver = "expanded endpoint/id scan with dedupe"
}
