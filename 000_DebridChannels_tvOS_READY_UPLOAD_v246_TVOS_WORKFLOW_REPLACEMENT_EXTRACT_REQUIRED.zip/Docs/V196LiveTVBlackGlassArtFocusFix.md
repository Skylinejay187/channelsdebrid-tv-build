# V196 Live TV Black Glass / Art / Focus Fix

Base: v195 stable black-glass/motion branch.

Changes:
- Live TV guide info panel background is now full black-glass instead of gray, so show details blend with the dark theme.
- Right-side preview window is locked to a fixed width/height so it no longer stretches into the info area.
- Live TV grid artwork priority is swapped: Gracenotes/program art is the large tile image, channel logo is contained in a small badge.
- Grid focus border is retuned away from the visible white tvOS outer plate and kept as a subtle custom cyan highlight.
- Build markers updated to v196.
