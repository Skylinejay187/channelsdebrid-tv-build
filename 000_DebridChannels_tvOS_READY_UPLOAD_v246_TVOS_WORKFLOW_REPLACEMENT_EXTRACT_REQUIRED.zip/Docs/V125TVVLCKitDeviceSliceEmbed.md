# V125 TVVLCKit Device Slice Embed Fix

Fixes v124 packaging failure. The VideoLAN archive downloads correctly (~121MB), but the actual tvOS arm64 device framework slice is about 35MB. v124 incorrectly rejected that real slice as too small.

V125 now:
- downloads the official TVVLCKit archive inside the Xcode build phase, because the user GitHub workflow only runs XcodeGen/xcodebuild from project.yml
- copies the full TVVLCKit.xcframework for inspection
- extracts and embeds the tvOS arm64 TVVLCKit.framework slice
- hard-fails only if the embedded device slice is below 30MB
- preserves the dual Apple Native + VLC Internal player pipeline and v73 visuals
