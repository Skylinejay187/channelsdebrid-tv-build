# V174 Live TV Android Guide Resolver Port

Base: v173 clean Live TV focus/DPAD rebuild.

Changes:
- Ported Android LiveGuideProgramResolver matching behavior into the tvOS LiveTVSourceModel.
- XMLTV programme parsing no longer assumes attribute order; channel/start/stop can appear in any order.
- Added Android-style guide lookup keys for tvg-id, tvc-guide-stationid, channel number, channel name, dot/dash/underscore variants, and normalized keys.
- Added HD/FHD/UHD/4K-stripped normalized matching so XMLTV/Gracenotes-style channel IDs match M3U and Channels DVR rows more reliably.
- Improved XMLTV channel icon backfill to use display-name aliases and normalized lookup keys.
- Preserved v173 invisible native focus target strategy and Live TV cache-disabled playback behavior.

Endpoints kept active:
- /devices
- /devices/ANY/channels.m3u
- /devices/{device}/channels
- /devices/{device}/channels/{channel}/stream.mpg
- /devices/ANY/guide/xmltv?duration=86400
- /devices/ANY/guide/xmltv
- /dvr/lineups
