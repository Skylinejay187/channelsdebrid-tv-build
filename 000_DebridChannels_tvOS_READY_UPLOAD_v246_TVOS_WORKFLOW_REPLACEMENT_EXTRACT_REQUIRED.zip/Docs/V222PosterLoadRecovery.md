# v222 Poster Load Recovery

Scope: corrective build after v221 compile recovery.

Preserved:
- v220 grid-first operating surface
- v221 missing-helper compile recovery
- Movies/Shows overlay slot-panel architecture
- Live TV guide/player behavior
- Top menu and hidden left utility panel behavior

Fix:
- Hardened RemoteImageFit URL normalization so poster/backdrop/logo artwork loads more reliably from Stremio/Cinemeta/backends.
- Handles trimmed URLs, protocol-relative artwork URLs, common HTTP-to-HTTPS artwork URLs, percent encoding fallback, and safer placeholder fallback.

Not changed:
- No signing/package structure changes
- No guide layout replacement
- No player pipeline changes
