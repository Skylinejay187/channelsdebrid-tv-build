# V99 Stremio Resource Initializer Fix

Fixed Swift compile error in `StremioResource.init(from:)` by avoiding mixed delegating/direct initialization paths.

- Keeps Stremio string/object resource decoding intact.
- Preserves v73 visuals and v98 Stremio API contract behavior.
