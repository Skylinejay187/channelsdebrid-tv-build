# V150 Layout/Logo Overlay Fix

- Moved the media information card left next to the stream link row/arrow area.
- Kept the media information card text-only; no logo inside the text box.
- Removed the old pulsing animation from the Home hero themed logo.
- Restored the themed logo in the VOD overlay as a static non-pulsing element.
- Preserved v73 Home/detail visual baseline, KSPlayer primary, VLC fallback, MPV removal, loading animation, and diagnostics work.
