# v158 VOD Controls, Cache, Progress, Artwork

- Removed KSPlayer engine/status text from under the VOD time/progress bar.
- Added stable current time/total duration display for KSPlayer/VLC surfaces with an internal playback clock until engine callbacks are available.
- UP/DOWN or tap shows controls for 15 seconds; pressing Play resumes and hides the overlay.
- Added cache-to-disk setting cycle: 5GB, 10GB, Unlimited.
- Reinforced English audio preferred and subtitles off default.
- Media information text box uses full text without ellipsis and adjusted placement beside link row area.
- Media-information backdrop artwork fitment isolated to reduce the left-edge artifact.
- MPV remains fully removed. KSPlayer primary and VLC fallback preserved.
