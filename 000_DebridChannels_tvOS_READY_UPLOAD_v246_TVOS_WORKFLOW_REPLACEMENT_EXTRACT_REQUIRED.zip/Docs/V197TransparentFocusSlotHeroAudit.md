# V197 Transparent Focus + Slot Hero Motion Audit

Base: v196 stable black-glass Live TV/art/focus build.

Changes:
- Kept the tvOS focus engine alive, but removed the opaque white focus plate visuals from top menu/category focus states.
- Retuned Live TV grid focused border to an ultra-subtle transparent cyan/glass edge so the white slab no longer blocks the UI.
- Preserved DPAD/focus/select behavior and the v193 soft ease-slide motion layer.
- Started the hero carousel behavior toward a slot model: the large left hero card stays anchored while incoming items use a soft edge-to-edge transition instead of a full canvas snap.
- Updated visible build markers to v197.

Regression guardrails:
- Do not remove focusable hit regions; only hide native visuals.
- Do not restore the v187-v190 full layout rewrite.
- Preserve Live TV no-cache playback and VOD cache-backed playback separation.
