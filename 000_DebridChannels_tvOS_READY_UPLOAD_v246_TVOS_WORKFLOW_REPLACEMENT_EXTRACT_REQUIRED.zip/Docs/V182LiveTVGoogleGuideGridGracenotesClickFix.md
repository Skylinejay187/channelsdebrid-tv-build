# v182 Live TV Google Guide / Grid Gracenotes / Click Fix

- Reworked Live TV guide into a Google-TV-style structure with a left source/category rail, top program preview, time header, and right-side program grid.
- Fixed XMLTV/Gracenotes program lookup so guide rows and grid cards use the same `tvg-id`, `tvc-guide-stationid`, number, logo, and channel-name matching paths.
- Fixed Gracenotes/program artwork crop in the guide preview by using fit-safe rendering inside a black-glass card.
- Added guide data/program artwork to Live TV grid cards, including current program title and channel details.
- Repaired grid center-click behavior by letting the native tvOS Button own select handling while preserving custom focus visuals and debounce.
- Preserved single-step DPAD behavior, manual DVR/M3U/XMLTV/Xtream sources, cache-disabled Live TV playback, and the v173 invisible native focus target approach.
