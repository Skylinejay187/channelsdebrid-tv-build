# V195 Menu / Live TV Box Fit Polish

Base: v193 top-menu/logo/soft-ease branch, preserving the v186/v191 stable Live TV behavior and motion restore.

Changes:
- Reworked the global top menu bar to be slightly more transparent while staying readable and locked below the safe top edge.
- Replaced the Debrid Channels top-logo treatment with a cleaner black-glass/orange-gradient mark.
- Tightened Live TV top padding after the menu so content does not collide with the header.
- Retuned Live TV grid tiles away from the older bright/cyan box look toward darker black-glass guide-style channel boxes.
- Reduced guide row/cell dimensions and darkened program-cell materials so the Google-style guide fits cleaner across the tvOS viewport.
- Preserved guide force refresh, Gracenotes artwork, live preview, no-cache Live TV playback, cached VOD playback, and v193 soft ease slide motion.
