# V192 motion restore on v186/v191 stable base

- Base: v191 rollback to v186 black-glass stable behavior.
- Restored only the safe raised-card scroll/motion visual layer from the motion experiment.
- Did not restore the v187-v190 full Home/card layout rewrite.
- Preserved v186/v191 geometry, Live TV guide, playback, cache, focus, and source systems.
- Updated visible/logcat markers to v192.
