# v157 Queue Push + Artwork Fit Careful Rebuild

- Preserves v73 approved Home/detail geometry.
- Adds Option K queue-push transition for hero/deck item changes without restoring old glitchy right-card motion.
- Keeps Home hero logos non-pulsing with blue glow.
- Keeps themed logo pulse only in media-information/detail section.
- Keeps VOD overlay logo static without pulse.
- Keeps MPV fully removed; KSPlayer primary and VLC fallback remain.
- Improves artwork rendering fitment path to avoid left-edge/stretch artifacts.
- Moves media information text box farther right/down while keeping it text-only.
