# V171 Live TV DPAD Debounce + Custom Focus Audit

- Corrected the guide issue reported as a "double click" during scrolling: the guide now gates DPAD move events so one physical remote press advances only one row/cell.
- Removed Live TV grid/guide rows from the native tvOS focus plate path and kept custom app-rendered focus state instead, eliminating the remaining white square around focused cards.
- Added a hidden DPAD capture control so Live TV can keep receiving remote move/selection commands while cards render without the system focus effect.
- Preserved RIGHT-to-guide behavior only from the final card in a row.
- Preserved Live TV no-cache behavior; VOD cache manager is not used for live playback.
