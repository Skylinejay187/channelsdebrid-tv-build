# v152 Media Info Logo Pulse Only

- Preserves v73 Home/detail visual baseline.
- Keeps Home hero themed logo static with blue glow, no pulse.
- Keeps VOD overlay themed logo static with no pulse.
- Restores/locks pulse animation only for the media-information/detail section themed logo.
- Keeps the media information text box text-only, with no logo inside it.
- Preserves KSPlayer primary, VLC fallback, MPV removed, loading animation, diagnostics, and poster-fit handling.
