# v241 Left Panel Restore + Movies/Shows Panel Height Audit

Base: v240.

Changes:
- Restored the Live TV category controls inside the hidden left panel.
- Kept Force Refresh Guide in the same left panel and focusable/clickable.
- Preserved forced-left behavior: first LEFT on the first card only arms the edge, second LEFT opens the panel.
- Increased Movies/Shows panel height from the overly-low v239/v240 size while keeping it below the earlier oversized versions.
- Preserved focused-card driven Movies/Shows panel background, poster-loading fixes, playback, guide preview, smoke deletion, and v228-style performance baseline.

Audit:
- No category row restored to the main grid surface.
- No smoke/ambient cinematic effect code reintroduced.
- No random poster rotation reintroduced.
