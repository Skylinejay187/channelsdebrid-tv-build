# V167 Live TV Settings + Guide Focus Fix

Careful rebuild from v166 compile-fix / v165 Live TV native sources base.

## Real changes
- Settings screen is now vertically scrollable so Live TV source inputs can be reached on tvOS.
- Live TV source fields are focusable/editable for Channels DVR, M3U, XMLTV, and Xtream server/user/password.
- Removed the bright white focused-card outer square from Live TV channel tiles.
- RIGHT now opens the full guide only when focus is on the last card in a row or the final card in an incomplete row.
- Removed the left-side guide category/icon panel from the full-screen Live TV guide.
- Updated visible/runtime markers to v167.

## Preserved
- KSPlayer primary playback path.
- VLC fallback path.
- MPV remains removed.
- Sharp artwork renderer and existing v73/v155 geometry rules preserved.
- Existing Live TV native source parsers/endpoints preserved.
