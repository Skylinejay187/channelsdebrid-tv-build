# v108 Careful Media Engine Rebuild

This pass targets the actual playback pipeline instead of UI-only fixes.

- AVFoundation remains first for Apple-native HLS/MP4/MOV HEVC/H.264/HDR/Dolby Vision capable streams.
- libVLC/TVVLCKit is used for obvious MKV/DTS/TrueHD/Profile 7 edge cases when the framework is present.
- Audio-only/no-video AVFoundation playback switches the same URL to libVLC when available before skipping.
- 4K streams get stronger buffering, hardware-path preference, peak bitrate unlimited, and 3840x2160 maximum-resolution preference.
- Playback diagnostics expose route and bitrates through status/log text.
