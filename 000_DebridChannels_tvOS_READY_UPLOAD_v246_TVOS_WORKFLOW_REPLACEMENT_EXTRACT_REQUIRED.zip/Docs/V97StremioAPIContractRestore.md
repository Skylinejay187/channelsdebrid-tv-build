# v97 Stremio API Contract Restore

This build fixes addon loading by matching the Stremio protocol more closely.

Key correction: manifests may expose `resources` as strings or objects. The previous decoder only accepted object form, so valid addons could fail to decode and block catalogs.

Catalog loading now uses protocol-valid endpoint candidates:

- `/catalog/{type}/{id}.json`
- `/catalog/{type}/{id}/skip=0.json`
- `/catalog/{type}/{id}/genre=popular.json`
- `/catalog/{type}/{id}/search=.json`

Catalog providers remain separate from stream-only providers so Torrentio/TorBox cannot wipe Home rows.
