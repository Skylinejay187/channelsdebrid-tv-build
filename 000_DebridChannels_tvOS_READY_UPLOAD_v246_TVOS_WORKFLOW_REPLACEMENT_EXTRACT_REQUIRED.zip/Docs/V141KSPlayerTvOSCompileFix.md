# V141 KSPlayer tvOS Compile Fix

Base: v140 KSPlayer native-first cadence rebuild.

Fixes:
- Removed the unavailable `UISlider` runtime type check from tvOS compile path.
- Kept KSPlayer primary, VLC fallback, Debrid VOD overlay, English audio preference, subtitles off by default.
- Preserved v73 Home/detail visuals.

No visual redesign was performed.
