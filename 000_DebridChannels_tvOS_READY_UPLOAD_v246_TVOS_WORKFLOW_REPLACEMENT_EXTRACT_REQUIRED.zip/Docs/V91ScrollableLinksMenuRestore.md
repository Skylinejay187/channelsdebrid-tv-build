# V91 Scrollable Links + Menu Restore

- Replaced the six-link cap with a DPAD-windowed stream link rail.
- Right/left on stream chips now walks through every resolved link and shifts the visible window instead of stopping at the first six links.
- Selecting any visible stream chip uses its absolute stream index and launches that exact stream URL when direct-playable.
- Search Links chip now shows the active range, such as `1-6 of 105`, so large addon results are visibly scrollable.
- Restored top menu vertical placement lower/clearer on detail/media information screens while preserving v73 menu style.
- Kept v73 Home/detail geometry and v90 compile cleanup.
