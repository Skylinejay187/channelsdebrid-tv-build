# V144 Careful Minimal VOD Rebuild

Base: latest KSPlayer/VLC line from v142/v143 behavior.

Preserved:
- v73 Home/detail visual baseline.
- KSPlayer primary internal player path.
- VLC fallback path.
- English audio preference and subtitles-off default logic from prior builds.
- Compact media information direction.

Changed:
- VOD overlay no longer renders the pulsing title/logo block.
- VOD overlay no longer renders the large text title below the logo.
- Portrait poster remains the visual title anchor.
- Metadata, rating/year badges, progress bar, controls, and external player handoff remain.

Notes:
- This pass is intentionally narrow to avoid destabilizing playback cadence or package integration.
