# v135 KSPlayer Options API Fix

Base: v134 KSPlayer raw-layer match fix.

Fixes the GitHub Actions compile failure where `KSOptions.isAutoPlay` is a static/global option, not an instance property.

Preserves:
- KSPlayer raw video surface / no second KSPlayer overlay
- KSPlayer buffering path
- VLC fallback
- external players
- v73 Home/detail baseline
