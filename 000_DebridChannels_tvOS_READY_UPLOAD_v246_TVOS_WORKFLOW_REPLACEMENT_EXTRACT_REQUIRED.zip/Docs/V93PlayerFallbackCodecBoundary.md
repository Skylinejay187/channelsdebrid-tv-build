# v93 Player fallback / codec boundary

This build adds the parts that can be implemented inside the current Swift/tvOS package without bundling external binary frameworks:

- adaptive retry across all direct playable stream URLs found by Stremio addons
- signed TorBox/debrid URL handling continues from v92
- AVPlayer buffer hardening and error diagnostics
- external subtitle URL capture from Stremio stream payloads
- clearer MKV/DTS/Dolby/profile failure messaging
- explicit boundary for future libVLC/FFmpeg framework integration

Important: true universal codec playback, raw MKV edge-case decoding, DTS decode, and magnet/torrent playback without debrid/backend conversion require adding compiled tvOS media/torrent frameworks. AVFoundation alone cannot provide those codecs.
