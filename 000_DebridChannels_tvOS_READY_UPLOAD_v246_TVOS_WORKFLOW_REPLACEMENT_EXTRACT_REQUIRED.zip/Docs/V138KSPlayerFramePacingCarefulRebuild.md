# v138 KSPlayer Frame Pacing Careful Rebuild

Built from the v136 KSPlayer/VLC line while preserving the v73 Home/detail visuals.

Changes:
- Kept KSPlayer as the primary internal engine and VLC as fallback.
- Increased KSPlayer forward/max buffering for high-bitrate 1080p/4K streams without reintroducing the v130 hardware-decode regression.
- Added more conservative FFmpeg analysis/probe queue values through KSPlayer options.
- Reduced Debrid VOD overlay redraw pressure while video is playing.
- Kept English audio preference and subtitles default-off behavior.
- Preserved the compact media information changes and player overlay structure.
