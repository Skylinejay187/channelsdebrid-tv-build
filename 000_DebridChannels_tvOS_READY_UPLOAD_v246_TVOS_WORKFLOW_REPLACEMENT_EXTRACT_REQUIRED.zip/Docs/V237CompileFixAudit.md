# v237 Compile Fix Audit

Base: v236_LEFT_PANEL_GRID_CONTROLS_CAREFUL_REBUILD

Purpose:
- Fix GitHub Actions Swift compiler failure in `gridQuickControlWindow(size:)`.
- Preserve v236 behavior and avoid feature rollback.

Build log issue:
- `DebridChannelsTVOSApp.swift:4132:9: error: the compiler is unable to type-check this expression in reasonable time; try breaking up the expression into distinct sub-expressions`

Change:
- Broke the combined left grid-control panel view into smaller SwiftUI subviews/helpers:
  - `quickPanelHeader`
  - `quickPanelCategorySection`
  - `quickPanelCategoryButton(_:)`
  - `quickPanelCategoryLabel(...)`
  - `quickPanelRefreshButton`
  - `quickPanelRefreshLabel`
  - panel/background/border helpers

Preserved:
- Live TV category/grid controls stay in hidden left panel.
- Force Refresh Guide stays in the same hidden left panel.
- Main grid surface does not show the category row.
- LEFT from first card in any row opens the panel.
- Panel remains hidden by default and does not auto-open.
- v235/v236 poster loading, clear focused wallpaper, stronger grid scale, reduced Movies/Shows panel height, deleted smoke effects, playback, guide preview, and focus fixes remain preserved.
