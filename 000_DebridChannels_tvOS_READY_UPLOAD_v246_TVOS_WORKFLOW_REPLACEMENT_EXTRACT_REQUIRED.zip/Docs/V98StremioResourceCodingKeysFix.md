# v98 Stremio Resource CodingKeys Fix

Fixes the GitHub Actions compile failure from v97:

- `CatalogStore.swift: cannot find CodingKeys in scope`

Cause: `StremioResource` added a custom `Decodable` initializer but did not declare its own `CodingKeys`.

Fix: added `enum CodingKeys: String, CodingKey { case name, types, idPrefixes }`.

Preserves v97 Stremio API contract behavior, v96 catalog restore, v95 playback restore, v94 TVVLCKit path, and v73 visual baseline.
