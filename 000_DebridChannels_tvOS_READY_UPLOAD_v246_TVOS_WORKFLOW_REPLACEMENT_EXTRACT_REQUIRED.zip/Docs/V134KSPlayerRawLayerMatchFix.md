# v134 KSPlayer Raw Layer + Match Playback Fix

- Replaced KSVideoPlayerView with low-level KSPlayerLayer rendering so KSPlayer native controls/overlay no longer appear under Debrid Channels VOD overlay.
- Keeps Debrid Channels as the only visible VOD chrome.
- Enables KSPlayer hardware decode preference and larger buffering through KSOptions.
- Adds frame/dynamic-range match guidance in player settings; tvOS Match Frame Rate/Dynamic Range still must be enabled in Apple TV settings for perfect cadence.
- Preserves v73 Home/detail visuals and v133 KSPlayer package resolution fix.
