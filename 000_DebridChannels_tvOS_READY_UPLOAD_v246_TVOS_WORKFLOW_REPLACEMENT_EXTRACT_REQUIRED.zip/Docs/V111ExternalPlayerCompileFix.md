# V111 External Player Compile Fix

Fixed external subtitle URL type conversion for external player handoff. Preserves v110 native playback pipeline, external player support, and v73 visual baseline.
