# V229 Card Depth + Panel Backdrop Fix

Base: v228 compile fix / v226 feature stack.

Changes:
- Kept the main Live TV/Grid OS background cinematic-only instead of painting random movie/show artwork across the full screen.
- Moved the rotating movie/show artwork layer into the Movies/Shows quick panel surface only, clipped to the bottom overlay panel.
- Added a frosted/cinematic glass panel treatment using a clipped ambient poster, lightweight cinematic background, black glass overlay, and soft gradient stroke.
- Strengthened the fixed-slot focused movie/show card depth effect with soft cyan bloom, layered black shadow, brighter/saturated focused artwork, and smoother spring elevation.
- Added light shadow separation to preview cards so the carousel feels more dimensional without using tvOS white focus halos.

Preserved:
- v222/v223 movie/show poster URL recovery behavior.
- v224 overlay focus containment.
- v225 single-stream Live TV guide preview cleanup.
- v226 guide preview audio and large-lineup virtual window work.
- v228 compile fix for artwork scope.
- Top Movies tab remains in the main menu.
