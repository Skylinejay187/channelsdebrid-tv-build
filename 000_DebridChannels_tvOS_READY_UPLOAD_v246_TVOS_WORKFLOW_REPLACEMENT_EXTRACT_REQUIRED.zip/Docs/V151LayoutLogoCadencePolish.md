# V151 Layout / Logo / Cadence Polish

Base: v150 line.

Changes:
- Moved media information card to the agreed spot beside the stream-link row / arrow area and raised it so it no longer covers the link chips.
- Kept the media information text box text-only; no logo inside that card.
- Restored blue glow behind themed logos.
- Removed Home hero logo pulse behavior; Home uses a steady glow.
- Kept media-detail logo pulse enabled only on the detail/media information screen.
- VOD overlay logo remains present and static with no pulse animation.
- Poster card artwork now uses fit behavior instead of crop in poster rows/player poster to preserve full artwork.
- Player stack remains KSPlayer primary + VLC fallback, MPV removed.
