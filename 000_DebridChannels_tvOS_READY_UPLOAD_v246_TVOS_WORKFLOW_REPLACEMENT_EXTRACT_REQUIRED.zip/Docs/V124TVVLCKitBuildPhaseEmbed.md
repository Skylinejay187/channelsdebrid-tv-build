# V124 TVVLCKit Build Phase Embed

The outer GitHub workflow used by this repo only extracts the uploaded ZIP, runs XcodeGen, and builds the generated Xcode project. It does not execute the workflow inside the uploaded ZIP.

V124 therefore moves the real TVVLCKit download/vendor step into the generated Xcode target as a pre-build script. The app target now links/embeds `Vendor/TVVLCKit/TVVLCKit.framework`, and the pre-build script downloads VideoLAN’s official TVVLCKit binary before link/embed.

If TVVLCKit cannot be downloaded or the payload is too small, the Xcode build fails before producing another small fake IPA.
