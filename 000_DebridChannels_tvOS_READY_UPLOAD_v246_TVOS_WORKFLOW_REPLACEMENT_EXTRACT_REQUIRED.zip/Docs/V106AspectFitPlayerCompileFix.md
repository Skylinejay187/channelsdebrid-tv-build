# v106 Aspect-Fit Player Compile Fix

- Fixed compile error: `cannot find AVPlayerControllerSurface in scope`.
- Added AVPlayerViewController-backed render surface with `showsPlaybackControls = false`.
- Kept video content default aspect-fit through `AVLayerVideoGravity.resizeAspect`.
- Did not crop/stretch movie content by default.
