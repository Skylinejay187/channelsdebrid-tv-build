# V191 Google guide preview + refresh fix

- Rebuilt Live TV guide toward the approved Google-TV-style mockup.
- Removed the guide side rail from the active layout.
- Added right-side live preview window placeholder that updates with focused channel/program.
- Added fixed-size Gracenotes/program thumbnails inside guide cells.
- Kept grid channel art/card size stable when Gracenotes images load.
- Added Force Refresh Guide button in the Live TV grid section.
- Preserved 3-hour Live TV lineup cache behavior and cache-disabled Live TV playback.
- Removed Debrid Channels Premium text if encountered in hero labels.
