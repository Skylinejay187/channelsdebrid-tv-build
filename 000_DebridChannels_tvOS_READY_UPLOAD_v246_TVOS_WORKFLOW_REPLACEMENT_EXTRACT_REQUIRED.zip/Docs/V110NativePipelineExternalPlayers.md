# v110 Native Pipeline + External Players

- Preserves v73 visual geometry.
- Keeps AVFoundation/AVKit as the first render path for every HTTP(S) stream to protect Apple TV hardware decoding, frame pacing, HDR/DV metadata, and 4K quality.
- Stops automatic URL-hint-based VLC routing before playback. VLC is only forced after AVFoundation produces a real failure/audio-only condition.
- Increases forward buffer for high-bitrate debrid links and keeps `preferredPeakBitRate = 0` so 4K is not artificially capped.
- Keeps `.resizeAspect` as the default video gravity so content is not stretched or cropped.
- Adds external player handoff controls for Infuse, VLC, and SenPlayer using best-known URL scheme candidates.
- Adds LSApplicationQueriesSchemes entries for external players.
