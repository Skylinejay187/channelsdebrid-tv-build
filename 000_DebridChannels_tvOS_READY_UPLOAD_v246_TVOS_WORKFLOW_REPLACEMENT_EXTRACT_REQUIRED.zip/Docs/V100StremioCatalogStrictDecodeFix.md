# v100 Stremio Catalog Strict Decode Fix

Fixes catalog loading regression where Cinemeta/third-party catalog endpoints returned valid Stremio JSON but the app rejected the whole response when one optional field used a number/bool/mixed type instead of a String.

Changes:
- Added lossy Stremio meta decoding.
- Added lossy catalog response item decoding.
- Added tolerant extra/options decoding.
- Preserved stream-only addon separation.
- Preserved v73 visuals and v99 compile fixes.
