# V146 player cleanup + loading animation

- Fully removes the legacy experimental engine app source references, controls, routing, messages, and docs from the active project.
- Keeps KSPlayer as primary internal playback engine and TVVLCKit/libVLC as fallback.
- Adds a cinematic loading animation while a movie stream/player surface is preparing.
- Preserves v73 Home/detail visuals and the minimal VOD overlay.
