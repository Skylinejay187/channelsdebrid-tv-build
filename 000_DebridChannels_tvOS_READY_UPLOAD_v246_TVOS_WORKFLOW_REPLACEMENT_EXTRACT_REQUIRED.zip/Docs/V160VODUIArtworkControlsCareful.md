# V160 VOD UI / Artwork / Controls Careful Rebuild

- Changed Home hero animation target to Option J cover-slide direction for the next visual pass baseline.
- Rebuilt Detail/media-information backdrop renderer only for the detail screen to preserve true 16:9 fit and remove the left-edge seam/artifact without affecting Home/VOD poster cards.
- Moved media information text box a half-inch right from v159 placement while keeping the agreed vertical position.
- Kept media info box text-only and removed ellipsis by allowing full vertical text expansion.
- Restored VOD themed logo static/no pulse.
- Removed KSPlayer status text under VOD timeline and replaced it with cache progress UI.
- Added cache progress row with 5GB/10GB/Unlimited setting display.
- Repaired VOD control select/click behavior by moving button actions back onto focusable button chips and preventing the parent player shell from double-consuming select.
- UP/DOWN shows controls and preserves focus for navigation; Play hides controls when playback resumes.
- Preserved v154/v155 playback cadence work, KSPlayer primary, VLC fallback, MPV fully removed, queue/hero visual work, and v73 layout baseline.
