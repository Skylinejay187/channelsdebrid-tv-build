# v202 Top Menu Focus Lock + Pill Fix

Base: v201/v200 branch.

Changes:
- Top menu focus no longer immediately drops into page content when moving across menu tabs.
- Section still changes on top-menu focus, matching Apple TV behavior.
- Content focus is only restored when pressing DOWN from the menu.
- Native white focus plate avoided by using focusable custom menu pills instead of Button-backed menu tabs.
- Focused menu text is black with a tight rounded pill shape.
- Existing Live TV/artwork/backend settings behavior preserved.
