# V198 Live TV Stretch / Focus / Logo Fix Audit

Base: v197 transparent-focus slot-hero branch.

Changes:
- Locked Live TV grid tile artwork into a fixed 16:9 frame so Gracenotes/poster art can no longer stretch the card dimensions.
- Locked guide preview art to fit inside its fixed preview window rather than stretching the preview card.
- Removed the boxed black panel behind the guide information hero so it blends naturally into the black-glass guide background.
- Added transparent native-focus suppression modifier where supported, while preserving real focus targets for DPAD/select reliability.
- Reduced visible focused-card strokes to very low-alpha cyan/orange accents instead of white plates.
- Replaced the Debrid Channels brand mark treatment with a cleaner orange-play black-glass mark.
- Updated visible/logcat build markers to v198.
