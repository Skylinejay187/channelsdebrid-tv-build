# V191 rollback black-glass stable

Base: v186 Google guide preview refresh fix.

Rollback scope:
- Removed v187-v190 full shell/Home/card-motion experiments by rebuilding from v186 source.
- Preserved v186 black-glass Live TV guide, fixed-size Gracenotes thumbnails, right-side preview, force refresh, and 3-hour Live TV cache behavior.
- Preserved KSPlayer/VLC playback paths and VOD cache behavior from v186.
- Updated visible build markers to v191.
