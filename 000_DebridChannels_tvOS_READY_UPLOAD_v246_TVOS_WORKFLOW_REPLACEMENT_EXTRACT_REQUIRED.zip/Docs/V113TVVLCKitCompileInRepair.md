# v120 TVVLCKit Compile-In Repair

Purpose: fix the runtime message `TVVLCKit was not compiled in` by making CocoaPods/TVVLCKit part of the GitHub Actions build path instead of only leaving a Podfile in the source tree.

Changes:
- Added full GitHub Actions workflow that runs XcodeGen, `pod install --repo-update`, then builds the generated `.xcworkspace`.
- Locked Podfile to official `TVVLCKit`, `~> 3.3.0`, for tvOS.
- Kept Apple Native AVKit as the first internal engine and embedded TVVLCKit as the second internal engine under the same Debrid VOD overlay.
- Preserved v73 Home/detail visuals and v112 Apple-style VOD overlay.
