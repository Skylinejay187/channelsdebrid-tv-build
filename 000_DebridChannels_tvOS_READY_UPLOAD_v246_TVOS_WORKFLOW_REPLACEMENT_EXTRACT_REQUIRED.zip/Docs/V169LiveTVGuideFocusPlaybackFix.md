# V169 Live TV Guide Focus Playback Fix

- Reworked Live TV grid DPAD routing so RIGHT only opens the full guide from the last card in a row. Non-edge RIGHT now moves to the next card instead of trapping/freezing focus.
- Disabled the default tvOS white focus effect on Live TV cards and guide program buttons; focus is now shown by the app-owned purple border/shadow only.
- Kept the full-screen guide clean with no left category panel.
- Disabled temporary VOD cache for Live TV playback. Live TS/HLS streams open directly through KSPlayer primary / VLC fallback with no progress-cache recording.
- Expanded channel logo/artwork parsing for Channels DVR, M3U/XMLTV and guide metadata-style fields used by Gracenotes/TMS station feeds.
- Normalized relative M3U stream URLs against the source base URL so TS/HLS links launch correctly.
- Updated visible build marker to v169.
