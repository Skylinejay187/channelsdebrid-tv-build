# v103 Careful VOD Focus Rebuild

- Preserves v73 visual baseline and v101 playback handoff.
- Removes native tvOS Button rendering from VOD transport controls to stop the white focus plate/box.
- Uses custom focusable text controls with Debrid Channels cyan focus styling.
- Adds VOD player action debounce so one remote click cannot double-fire a control.
- Replaces playback-error Close button with a custom focusable control to avoid native focus plates.
