# v231 Glass Layer / Panel Backdrop Performance Fix

Base: v230 Premium Card Depth / Cinematic Motion.

Changes:
- Removed the extra global/litter visual layer from the Movies/Shows overlay surface.
- Kept one clean glass layer so cards do not stack strange outlines/glows.
- Restored rotating movie/show poster artwork inside the Movies/Shows panel only.
- Kept the main Live TV/Grid OS background free from random movie/show posters.
- Reduced heavy global smoke/timeline effects to lightweight ambient haze.
- Reduced Live TV grid card depth effects so large channel grids do not slow down.
- Preserved poster loading, overlay focus containment, single-stream preview logic, preview audio, and top menu behavior.
