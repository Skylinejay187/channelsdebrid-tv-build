Build v205 MENU_LOCK_REAL_TIME_TRANSPARENT_FOCUS_FIX
- Removes visible Debrid Channels logo from active top menu.
- Restores real device time in the top-right clock.
- Keeps top menu overlay locked above media information screens.
- Retunes Live TV grid text sizing/fitting for program/channel labels.
- Keeps native focus engine but suppresses visible focus plate as much as tvOS allows.
