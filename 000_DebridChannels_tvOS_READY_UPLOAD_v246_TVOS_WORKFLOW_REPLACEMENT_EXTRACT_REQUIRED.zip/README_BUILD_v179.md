# Debrid Channels tvOS v179

Ready-to-upload GitHub Actions repo ZIP.

Focus/DPAD update:
- Settings and guide no longer use duplicate manual movement on top of tvOS native focus movement.
- Normal DPAD movement is single-owner native focus.
- Debrid Channels only intercepts special Live TV transitions.
- Live TV card select/play is debounced to prevent ghost double launches.

Preserved:
- KSPlayer primary engine.
- VLC fallback engine.
- Live TV cache disabled.
- Manual Channels DVR/M3U/XMLTV/Xtream sources.
- Black-glass Live TV styling.
- v173 invisible focus target direction.
