# v206

Live TV grid cards no longer use Button-backed focus for the tile itself. The card is a focusable custom view with the native focus plate disabled, so only the card content raises. Grid text layout was tightened to fit program/channel text cleanly.
