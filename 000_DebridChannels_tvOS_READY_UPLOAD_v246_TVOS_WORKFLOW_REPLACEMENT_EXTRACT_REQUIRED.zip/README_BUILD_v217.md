# Debrid Channels tvOS v217 — Clean Grid Main Surface + Fullscreen Guide

Base: v216 Grid OS compile-fix branch.

This pass backs away from the bulky left Grid OS menu rail and returns to a cleaner grid-first approach:

- Live TV grid remains the main operating surface.
- Normal top menu bar is restored.
- Home / Movies / Shows open as overlay catalog shelves over the grid.
- Removed the large left navigation rail.
- Left side now only has a compact quick window for Force Refresh Guide and the RIGHT-guide hint.
- Removed the extra Guide button from grid controls; RIGHT from the grid opens the expanded guide.
- Full Guide mode was expanded vertically so it uses more of the screen and avoids bottom clipping.
- Media info popup flow and trailer-popup path remain preserved.
- Build markers updated to v217.

Rollback base remains v210/v209 if the Grid OS experiment needs to be backed out.
