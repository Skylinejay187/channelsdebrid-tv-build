# Debrid Channels tvOS v173

Ready-to-upload GitHub Actions repo ZIP.

## Main fix
Live TV focus and DPAD navigation were rebuilt cleanly so the tvOS focus engine has real grid/guide targets again while Debrid Channels keeps the custom invisible/native-focus visual treatment.

## Preserved
- KSPlayer primary / VLC fallback playback stack
- VOD temp watch-session cache behavior
- Live TV cache disabled
- Channels DVR endpoints on port 8089
- M3U/XMLTV/Xtream support
- Gracenotes-style logo/guide matching paths
- Signulous-compatible IPA workflow structure
