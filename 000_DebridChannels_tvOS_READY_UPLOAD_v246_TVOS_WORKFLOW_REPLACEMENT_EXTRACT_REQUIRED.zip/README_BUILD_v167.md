# Debrid Channels tvOS v167

Ready-to-upload GitHub repo source for GitHub Actions tvOS IPA build.

## Build marker
`v167 LIVE TV SETTINGS + GUIDE FOCUS FIX`

## Fixes in this build
- Settings is now vertically scrollable on tvOS.
- Live TV source fields are focusable/editable: Channels DVR, M3U, XMLTV, Xtream server, username, password.
- Live TV grid no longer draws the large white outer focused-card square.
- RIGHT opens the full guide only from the last box in a row, or the final box in an incomplete row.
- Full-screen guide no longer includes the left icon/category panel.

## Preserved
- KSPlayer primary engine.
- VLC fallback engine.
- MPV removed.
- Existing v73/v155 visual geometry and sharp artwork renderer direction.
- Existing Channels DVR/Xtream/M3U/XMLTV native source logic.
- Signulous-compatible Payload/*.app IPA packaging in GitHub Actions.
