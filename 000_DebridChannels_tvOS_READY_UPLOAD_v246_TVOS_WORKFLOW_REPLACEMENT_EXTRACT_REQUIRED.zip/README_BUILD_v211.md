# Debrid Channels tvOS v211

Experimental Grid OS branch: Live TV grid is the main app surface. Home/Movies/Shows catalogs are layered as overlays on top of the grid. Media info popup and trailer popup path are preserved.
