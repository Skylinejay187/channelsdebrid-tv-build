# Debrid Channels tvOS v218 — Grid Overlay Focus Panel Rebuild

Built from v217 clean grid/top-menu branch.

Changes:
- Left Force Refresh panel is fully off-screen by default.
- LEFT on first grid-column card reveals the quick panel.
- Movies/Shows/Home catalog overlays now own DPAD focus.
- Back/Menu closes the overlay instead of exiting the app.
- Movies/Shows overlays use portrait posters by default.
- Focused poster expands into a landscape card with smooth Apple-style spring motion.
- Normal top menu and full guide behavior are preserved.
- Media info popup and trailer popup path are preserved.
