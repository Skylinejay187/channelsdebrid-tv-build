package com.channelsdebrid.tv.prolayout;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.*;
import java.util.*;

public final class ProLayoutRepository {
    private static final String PREFS = "dc_v097_advanced_pro_layout";
    private static final int SNAP_DP = 8;
    private ProLayoutRepository() {}

    public static ArrayList<ProLayoutItem> defaults() {
        ArrayList<ProLayoutItem> items = new ArrayList<>();
        items.add(new ProLayoutItem("heroText", "Hero text", 80, 210, 560, 190));
        items.add(new ProLayoutItem("heroLogo", "Hero logo", 80, 118, 430, 96));
        items.add(new ProLayoutItem("topMenu", "Top menu", 360, 34, 820, 66));
        items.add(new ProLayoutItem("posterRows", "Poster rows", 32, 430, 1210, 260));
        items.add(new ProLayoutItem("extraArtwork", "Extra artwork", 760, 120, 240, 160));
        items.add(new ProLayoutItem("statusHub", "Status hub", 905, 622, 315, 46));
        return items;
    }

    public static ArrayList<ProLayoutItem> load(Context c) {
        String json = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("layout_json", "");
        if (json == null || json.trim().isEmpty()) return defaults();
        try { return parse(json); } catch (Exception ignored) { return defaults(); }
    }

    public static void save(Context c, ArrayList<ProLayoutItem> items) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("layout_json", toJson(items).toString())
            .putLong("saved_at", System.currentTimeMillis())
            .apply();
        mirrorToUiState(c, items);
    }

    public static void clear(Context c) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply();
    }

    public static String exportJson(Context c) {
        return toJson(load(c)).toString();
    }

    public static void importJson(Context c, String json) {
        ArrayList<ProLayoutItem> parsed = parse(json);
        save(c, parsed);
    }

    public static int snap(int v) {
        return Math.round(v / (float) SNAP_DP) * SNAP_DP;
    }

    private static JSONArray toJson(ArrayList<ProLayoutItem> items) {
        JSONArray arr = new JSONArray();
        for (ProLayoutItem item : items) {
            JSONObject o = new JSONObject();
            try {
                o.put("id", item.id); o.put("label", item.label);
                o.put("xDp", item.xDp); o.put("yDp", item.yDp);
                o.put("widthDp", item.widthDp); o.put("heightDp", item.heightDp);
                arr.put(o);
            } catch (Exception ignored) {}
        }
        return arr;
    }

    private static ArrayList<ProLayoutItem> parse(String json) {
        try {
            JSONArray arr = new JSONArray(json);
            ArrayList<ProLayoutItem> out = new ArrayList<>();
            for (int i=0;i<arr.length();i++) {
                JSONObject o = arr.getJSONObject(i);
                String id = o.optString("id", "custom"+i);
                String label = o.optString("label", id);
                out.add(new ProLayoutItem(id, label,
                    o.optInt("xDp", 0), o.optInt("yDp", 0),
                    Math.max(40, o.optInt("widthDp", 120)), Math.max(30, o.optInt("heightDp", 80))));
            }
            return out.isEmpty() ? defaults() : out;
        } catch (JSONException ignored) {
            return defaults();
        }
    }

    private static void mirrorToUiState(Context c, ArrayList<ProLayoutItem> items) {
        SharedPreferences.Editor e = c.getSharedPreferences("dc_v5_ui_state", Context.MODE_PRIVATE).edit();
        for (ProLayoutItem item : items) {
            if ("heroText".equals(item.id)) { e.putInt("heroTextLeftDp", item.xDp - 80); e.putInt("heroTextTopDp", item.yDp - 210); }
            if ("heroLogo".equals(item.id)) { e.putInt("heroLogoLeftDp", item.xDp - 80); e.putInt("heroLogoTopDp", item.yDp - 118); e.putInt("heroLogoWidthDp", item.widthDp); e.putInt("heroLogoHeightDp", item.heightDp); }
            if ("topMenu".equals(item.id)) { e.putInt("topMenuOffsetDp", item.xDp - 360); }
            if ("posterRows".equals(item.id)) { e.putInt("rowLeftDp", item.xDp); e.putInt("rowTopDp", item.yDp); }
            if ("extraArtwork".equals(item.id)) { e.putInt("extraArtworkXdp", item.xDp); e.putInt("extraArtworkYdp", item.yDp); e.putInt("extraArtworkWidthDp", item.widthDp); e.putInt("extraArtworkHeightDp", item.heightDp); }
            if ("statusHub".equals(item.id)) { e.putInt("statusHubRightDp", Math.max(0, 1220 - item.xDp - item.widthDp)); e.putInt("statusHubBottomDp", Math.max(0, 690 - item.yDp - item.heightDp)); e.putInt("statusHubWidthDp", item.widthDp); e.putInt("statusHubHeightDp", item.heightDp); }
        }
        e.putLong("layoutSavedAt", System.currentTimeMillis()).apply();
    }
}
