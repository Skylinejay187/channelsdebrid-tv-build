
package com.channelsdebrid.tv

import android.animation.Animator
import android.content.Intent
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.graphics.Outline
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.channelsdebrid.tv.databinding.ActivityMainBinding
import com.channelsdebrid.tv.settings.SettingsRepository
import com.channelsdebrid.tv.data.TmdbLiveLoader
import com.channelsdebrid.tv.data.StremioLiveLoader
import com.channelsdebrid.tv.data.SourceProbe
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var settingsRepository: SettingsRepository
    private val tmdbLiveLoader = TmdbLiveLoader()
    private val stremioLiveLoader = StremioLiveLoader()
    private val sourceProbe = SourceProbe()
    private val liveExecutor = Executors.newSingleThreadExecutor()
    private var tmdbRequestVersion = 0
    private var stremioRequestVersion = 0
    private var startupFocusLocked = true

    private enum class RowSection {
        FIRST,
        SECOND
    }

    private data class HomeRowSpec(
        val title: String,
        val subtitle: String,
        val section: RowSection,
        val items: List<TitleCard>
    )

    data class TitleCard(
        val title: String,
        val meta: String,
        val desc: String,
        val badge: String,
        val brand: String,
        val footer: String,
        val progress: Float,
        val backgroundRes: Int,
        val posterUrl: String? = null,
        val backdropUrl: String? = null
    )

    private val heroTitles = listOf(
        TitleCard("SHŌGUN", "S1 E7: A Stick of Time  •  43 min left", "A premium lean-back presentation for your media center, with live TV, trending shows, smart recommendations, and instant playback.", "⚑  Instant Playback Ready", "FX", "43 min left", 0.58f, R.drawable.bg_shogun),
        TitleCard("THE BATMAN", "2h 56m  •  IMAX", "A darker detective spotlight with premium backdrop changes and clean TV-safe row alignment.", "⚑  Direct Play Ready", "PLEX", "IMAX", 0.42f, R.drawable.bg_batman),
        TitleCard("FALLOUT", "49 min left  •  Prime", "Post-apocalyptic action with large-format hero art and poster rows that stay locked in place.", "⚑  Synced to Library", "prime", "49 min left", 0.51f, R.drawable.bg_fallout),
        TitleCard("DUNE", "2h 35m  •  Max", "Expansive cinema-style focus treatment with large typography and backdrop-driven navigation.", "⚑  HDR Available", "max", "Featured", 0.46f, R.drawable.bg_dune),
        TitleCard("HALO", "Series  •  Prime", "Sci-fi recommendations rendered in the same composition language as your reference shot.", "⚑  Resume Synced", "prime", "Series", 0.33f, R.drawable.bg_halo),
        TitleCard("WONKA", "Movie  •  Max", "Bright contrast title art for spotlight and recently-added rows without breaking the layout grid.", "⚑  Trailer Ready", "max", "Movie", 0.37f, R.drawable.bg_wonka),
        TitleCard("MAYOR OF KINGSTOWN", "Series  •  Paramount+", "Grounded drama hero state with full-screen poster changes as focus moves across rows.", "⚑  Watched on Device", "P+", "Series", 0.28f, R.drawable.bg_mayor),
        TitleCard("CIVIL WAR", "Movie  •  109 min", "Poster rows line up under the hero so the screen still feels premium and intentional.", "⚑  Cache Eligible", "A24", "109 min", 0.22f, R.drawable.bg_civilwar),
        TitleCard("AVATAR", "Movie  •  Disney+", "High-contrast blockbuster art for the lower row examples and future trailer pop-up placement.", "⚑  Dolby Vision", "D+", "Featured", 0.48f, R.drawable.bg_avatar)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        settingsRepository = SettingsRepository(this)

        setHero(heroTitles[3])
        applySettingsToHome()
        lockRowsForStartup()
        wireTopControls()
        wireRowNavigation()
        binding.contentScroll.post {
            binding.contentScroll.scrollTo(0, 0)
            binding.navSmart.isFocusableInTouchMode = true
            binding.navSmart.requestFocus()
            binding.contentScroll.postDelayed({
                binding.contentScroll.scrollTo(0, 0)
                binding.navSmart.requestFocus()
            }, 120)
            binding.contentScroll.postDelayed({
                unlockRowsAfterStartup()
                binding.contentScroll.scrollTo(0, 0)
            }, 420)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        liveExecutor.shutdownNow()
    }

    override fun onResume() {
        super.onResume()
        applySettingsToHome()
    }

    private fun applySettingsToHome() {
        val catalogs = settingsRepository.loadCatalogs()
        val tmdb = settingsRepository.loadTmdb()
        val stremio = settingsRepository.loadPrimaryAddon()
        val debrid = settingsRepository.loadDebrid()
        val dvr = settingsRepository.loadChannelsDvr()
        val xtream = settingsRepository.loadXtream()
        val trailers = settingsRepository.loadTrailers()
        val playback = settingsRepository.loadPlayback()
        val storage = settingsRepository.loadStorage()
        val sourceSummary = buildInitialSourceSummary(stremio.enabled, dvr, xtream, debrid)

        val rowSpecs = mutableListOf<HomeRowSpec>()
        if (catalogs.trendingMoviesEnabled) {
            rowSpecs += HomeRowSpec(
                title = "Trending in Movies",
                subtitle = "TMDB ${tmdb.region} • fresh now",
                section = RowSection.FIRST,
                items = List(24) { index -> heroTitles[(index + 3) % heroTitles.size] }
            )
        }
        if (catalogs.popularMoviesEnabled) {
            rowSpecs += HomeRowSpec(
                title = "Popular Movies",
                subtitle = "Popular picks • 4–5 visible cards",
                section = if (rowSpecs.isEmpty()) RowSection.FIRST else RowSection.SECOND,
                items = List(24) { index -> heroTitles[(index + 5) % heroTitles.size] }
            )
        }
        if (catalogs.trendingShowsEnabled && rowSpecs.size < 2) {
            rowSpecs += HomeRowSpec(
                title = "Trending in Shows",
                subtitle = "Series picks • ${tmdb.language}",
                section = if (rowSpecs.isEmpty()) RowSection.FIRST else RowSection.SECOND,
                items = List(24) { index -> heroTitles[(index + 6) % heroTitles.size] }
            )
        }
        if (catalogs.popularShowsEnabled && rowSpecs.size < 2) {
            rowSpecs += HomeRowSpec(
                title = "Popular Shows",
                subtitle = "Popular series • autoplay-ready",
                section = if (rowSpecs.isEmpty()) RowSection.FIRST else RowSection.SECOND,
                items = List(24) { index -> heroTitles[(index + 1) % heroTitles.size] }
            )
        }
        if (catalogs.platformRowsEnabled && rowSpecs.size < 2) {
            rowSpecs += HomeRowSpec(
                title = "Trending on Streaming",
                subtitle = "Netflix • Prime • Max • Disney+",
                section = if (rowSpecs.isEmpty()) RowSection.FIRST else RowSection.SECOND,
                items = List(24) { index -> heroTitles[(index + 2) % heroTitles.size] }
            )
        }
        if (catalogs.stremioCatalogRowsEnabled && rowSpecs.size < 2) {
            val addonName = stremio.name.ifBlank { "Stremio" }
            rowSpecs += HomeRowSpec(
                title = "$addonName Catalog",
                subtitle = if (stremio.enabled) "Addon ready • custom rows" else "Addon configured • currently disabled",
                section = if (rowSpecs.isEmpty()) RowSection.FIRST else RowSection.SECOND,
                items = List(24) { index -> heroTitles[(index + 4) % heroTitles.size] }
            )
        }
        if (rowSpecs.isEmpty()) {
            rowSpecs += HomeRowSpec(
                title = "Trending in Movies",
                subtitle = "Enable rows in Settings",
                section = RowSection.FIRST,
                items = List(24) { index -> heroTitles[(index + 3) % heroTitles.size] }
            )
        }

        bindRowSpec(rowSpecs.getOrNull(0), binding.rowOneTitle, binding.rowOneSubtitle, binding.rowOneScroll, binding.rowOne)
        bindRowSpec(rowSpecs.getOrNull(1), binding.rowTwoTitle, binding.rowTwoSubtitle, binding.rowTwoScroll, binding.rowTwo)

        binding.infoChip.text = buildInfoChipText(trailers.enabled, playback.autoPlayBestStream, storage.movieCacheEnabled, sourceSummary)
        binding.statusBadge.text = buildStatusBadgeText(debrid.realDebridEnabled, debrid.torBoxEnabled, dvr.baseUrl.isNotBlank(), xtream.enabled)
        binding.heroMeta.text = "${tmdb.region} • ${tmdb.language} • ${if (trailers.enabled) "Trailers On" else "Trailers Off"}"

        wireRowNavigation()
        binding.contentScroll.post {
            snapToRow(RowSection.FIRST, smooth = false)
        }

        maybeLoadLiveTmdbRows(catalogs, tmdb)
        maybeLoadLiveStremioRow(catalogs, stremio)
        probeSourceStatuses(stremio, dvr, xtream, debrid, trailers, playback, storage)
    }

    private fun maybeLoadLiveTmdbRows(catalogs: com.channelsdebrid.tv.settings.CatalogSettings, tmdb: com.channelsdebrid.tv.settings.TmdbSettings) {
        if (tmdb.apiKey.isBlank()) return

        val enabledKeys = buildList {
            if (catalogs.trendingMoviesEnabled) add("trending_movies")
            if (catalogs.popularMoviesEnabled) add("popular_movies")
            if (catalogs.trendingShowsEnabled) add("trending_shows")
            if (catalogs.popularShowsEnabled) add("popular_shows")
            if (catalogs.platformRowsEnabled) add("platform_rows")
        }.take(2)

        if (enabledKeys.isEmpty()) return
        val requestVersion = ++tmdbRequestVersion

        liveExecutor.execute {
            val rows = runCatching {
                tmdbLiveLoader.loadRows(
                    apiKey = tmdb.apiKey,
                    region = tmdb.region.ifBlank { "US" },
                    language = tmdb.language.ifBlank { "en-US" },
                    enabledKeys = enabledKeys
                )
            }.getOrDefault(emptyList())

            if (rows.isEmpty()) return@execute
            runOnUiThread {
                if (isFinishing || requestVersion != tmdbRequestVersion) return@runOnUiThread
                applyLiveRows(rows)
            }
        }
    }

    private fun applyLiveRows(rows: List<TmdbLiveLoader.LiveRow>) {
        bindLiveRow(rows.getOrNull(0), RowSection.FIRST, binding.rowOneTitle, binding.rowOneSubtitle, binding.rowOneScroll, binding.rowOne)
        bindLiveRow(rows.getOrNull(1), RowSection.SECOND, binding.rowTwoTitle, binding.rowTwoSubtitle, binding.rowTwoScroll, binding.rowTwo)
        wireRowNavigation()
        rows.firstOrNull()?.items?.firstOrNull()?.let { setHero(mapLiveItemToTitleCard(it, 0)) }
        binding.contentScroll.post { snapToRow(RowSection.FIRST, smooth = false) }
    }

    private fun bindLiveRow(
        row: TmdbLiveLoader.LiveRow?,
        section: RowSection,
        titleView: TextView,
        subtitleView: TextView,
        scrollView: HorizontalScrollView,
        rowLayout: LinearLayout
    ) {
        if (row == null) {
            titleView.visibility = View.GONE
            subtitleView.visibility = View.GONE
            scrollView.visibility = View.GONE
            rowLayout.removeAllViews()
            return
        }
        titleView.visibility = View.VISIBLE
        subtitleView.visibility = View.VISIBLE
        scrollView.visibility = View.VISIBLE
        titleView.text = row.title
        subtitleView.text = row.subtitle
        rowLayout.removeAllViews()
        row.items.forEachIndexed { index, item ->
            rowLayout.addView(makeCard(mapLiveItemToTitleCard(item, index), scrollView, binding.contentScroll, index, 258, 145))
        }
    }

    private fun mapLiveItemToTitleCard(item: TmdbLiveLoader.LiveCatalogItem, index: Int): TitleCard {
        val fallback = heroTitles[index % heroTitles.size]
        return TitleCard(
            title = item.title,
            meta = item.meta,
            desc = item.desc,
            badge = item.badge,
            brand = item.brand,
            footer = item.footer,
            progress = item.progress.coerceIn(0.12f, 0.92f),
            backgroundRes = fallback.backgroundRes,
            posterUrl = item.posterUrl,
            backdropUrl = item.backdropUrl
        )
    }

    private fun bindRowSpec(
        spec: HomeRowSpec?,
        titleView: TextView,
        subtitleView: TextView,
        scrollView: HorizontalScrollView,
        rowLayout: LinearLayout
    ) {
        if (spec == null) {
            titleView.visibility = View.GONE
            subtitleView.visibility = View.GONE
            scrollView.visibility = View.GONE
            rowLayout.removeAllViews()
            return
        }
        titleView.visibility = View.VISIBLE
        subtitleView.visibility = View.VISIBLE
        scrollView.visibility = View.VISIBLE
        titleView.text = spec.title
        subtitleView.text = spec.subtitle

        rowLayout.removeAllViews()
        spec.items.forEachIndexed { index, item ->
            rowLayout.addView(makeCard(item, scrollView, binding.contentScroll, index, 258, 145))
        }
    }

    private fun buildInfoChipText(trailersEnabled: Boolean, autoBest: Boolean, movieCacheEnabled: Boolean, sourceSummary: String? = null): String {
        val parts = mutableListOf<String>()
        parts += if (trailersEnabled) "Trailers On" else "Trailers Off"
        parts += if (autoBest) "Auto Best Stream" else "Manual Source Select"
        parts += if (movieCacheEnabled) "Movie Cache Ready" else "Cache Limited"
        sourceSummary?.takeIf { it.isNotBlank() }?.let { parts += it }
        return parts.joinToString("  •  ")
    }

    private fun buildStatusBadgeText(rdEnabled: Boolean, torBoxEnabled: Boolean, dvrReady: Boolean, xtreamEnabled: Boolean): String {
        return when {
            rdEnabled -> "⚑  Real-Debrid Ready"
            torBoxEnabled -> "⚑  TorBox Ready"
            dvrReady -> "⚑  Channels DVR Ready"
            xtreamEnabled -> "⚑  IPTV Ready"
            else -> "⚑  Instant Playback Ready"
        }
    }

    private fun buildInitialSourceSummary(
        stremioEnabled: Boolean,
        dvr: com.channelsdebrid.tv.settings.ChannelsDvrSettings,
        xtream: com.channelsdebrid.tv.settings.XtreamSettings,
        debrid: com.channelsdebrid.tv.settings.DebridSettings
    ): String {
        val parts = mutableListOf<String>()
        if (stremioEnabled) parts += "Stremio Configured"
        if (debrid.realDebridEnabled) parts += "Real-Debrid Armed"
        if (debrid.torBoxEnabled) parts += "TorBox Armed"
        if (dvr.autoDetect || dvr.baseUrl.isNotBlank()) parts += "Channels DVR Ready"
        if (xtream.enabled) parts += "Xtream Ready"
        return parts.take(2).joinToString("  •  ")
    }

    private fun maybeLoadLiveStremioRow(
        catalogs: com.channelsdebrid.tv.settings.CatalogSettings,
        stremio: com.channelsdebrid.tv.settings.StremioAddonSettings
    ) {
        if (!catalogs.stremioCatalogRowsEnabled || !stremio.enabled || stremio.manifestUrl.isBlank()) return
        val requestVersion = ++stremioRequestVersion
        liveExecutor.execute {
            val row = runCatching {
                stremioLiveLoader.loadPrimaryRow(stremio.name.ifBlank { "Stremio" }, stremio.manifestUrl)
            }.getOrNull() ?: return@execute
            runOnUiThread {
                if (isFinishing || requestVersion != stremioRequestVersion) return@runOnUiThread
                bindStremioLiveRow(row)
            }
        }
    }

    private fun bindStremioLiveRow(row: com.channelsdebrid.tv.data.StremioLiveLoader.LiveRow) {
        val useSecond = binding.rowTwoTitle.visibility == View.VISIBLE || binding.rowOneTitle.text.toString().contains("Movies", true)
        if (useSecond) {
            bindStremioRowInto(binding.rowTwoTitle, binding.rowTwoSubtitle, binding.rowTwoScroll, binding.rowTwo, row)
        } else {
            bindStremioRowInto(binding.rowOneTitle, binding.rowOneSubtitle, binding.rowOneScroll, binding.rowOne, row)
        }
        wireRowNavigation()
    }

    private fun bindStremioRowInto(
        titleView: TextView,
        subtitleView: TextView,
        scrollView: HorizontalScrollView,
        rowLayout: LinearLayout,
        row: com.channelsdebrid.tv.data.StremioLiveLoader.LiveRow
    ) {
        titleView.visibility = View.VISIBLE
        subtitleView.visibility = View.VISIBLE
        scrollView.visibility = View.VISIBLE
        titleView.text = row.title
        subtitleView.text = row.subtitle
        rowLayout.removeAllViews()
        row.items.forEachIndexed { index, item ->
            rowLayout.addView(makeCard(mapStremioItemToTitleCard(item, index), scrollView, binding.contentScroll, index, 258, 145))
        }
    }

    private fun mapStremioItemToTitleCard(item: com.channelsdebrid.tv.data.StremioLiveLoader.LiveCatalogItem, index: Int): TitleCard {
        val fallback = heroTitles[index % heroTitles.size]
        return TitleCard(
            title = item.title,
            meta = item.meta,
            desc = item.desc,
            badge = item.badge,
            brand = item.brand,
            footer = item.footer,
            progress = item.progress.coerceIn(0.12f, 0.92f),
            backgroundRes = fallback.backgroundRes,
            posterUrl = item.posterUrl,
            backdropUrl = item.backdropUrl
        )
    }

    private fun probeSourceStatuses(
        stremio: com.channelsdebrid.tv.settings.StremioAddonSettings,
        dvr: com.channelsdebrid.tv.settings.ChannelsDvrSettings,
        xtream: com.channelsdebrid.tv.settings.XtreamSettings,
        debrid: com.channelsdebrid.tv.settings.DebridSettings,
        trailers: com.channelsdebrid.tv.settings.TrailerSettings,
        playback: com.channelsdebrid.tv.settings.PlaybackSettings,
        storage: com.channelsdebrid.tv.settings.StorageSettings
    ) {
        liveExecutor.execute {
            val parts = mutableListOf<String>()
            if (stremio.enabled && stremio.manifestUrl.isNotBlank()) {
                sourceProbe.probeStremio(stremio.manifestUrl)?.let { parts += it }
            }
            sourceProbe.probeChannelsDvr(dvr.autoDetect, dvr.baseUrl)?.let { parts += it }
            if (xtream.enabled) {
                sourceProbe.probeXtream(xtream.server, xtream.username, xtream.password)?.let { parts += it }
            }
            val summary = parts.take(2).joinToString("  •  ")
            if (summary.isBlank()) return@execute
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                binding.infoChip.text = buildInfoChipText(trailers.enabled, playback.autoPlayBestStream, storage.movieCacheEnabled, summary)
                if (!debrid.realDebridEnabled && !debrid.torBoxEnabled) {
                    binding.statusBadge.text = "⚑  $summary"
                }
            }
        }
    }

    private fun lockRowsForStartup() {
        startupFocusLocked = true
        blockRowFocus(binding.rowOne)
        blockRowFocus(binding.rowTwo)
    }

    private fun unlockRowsAfterStartup() {
        startupFocusLocked = false
        allowRowFocus(binding.rowOne)
        allowRowFocus(binding.rowTwo)
    }

    private fun blockRowFocus(row: LinearLayout) {
        row.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        for (i in 0 until row.childCount) {
            row.getChildAt(i).apply {
                isFocusable = false
                isFocusableInTouchMode = false
            }
        }
    }

    private fun allowRowFocus(row: LinearLayout) {
        row.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        for (i in 0 until row.childCount) {
            row.getChildAt(i).apply {
                isFocusable = true
                isFocusableInTouchMode = true
            }
        }
    }

    private fun wireTopControls() {
        val focusables = listOf(
            binding.menuButton,
            binding.homeButton,
            binding.navResume,
            binding.navSmart,
            binding.navLive,
            binding.navMovies,
            binding.settingsCard
        )

        binding.settingsCard.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }

        focusables.forEach { v ->
            v.setOnFocusChangeListener { view, hasFocus ->
                view.animate().cancel()
                view.animate()
                    .scaleX(if (hasFocus) 1.05f else 1f)
                    .scaleY(if (hasFocus) 1.05f else 1f)
                    .alpha(if (hasFocus) 1f else 0.96f)
                    .setDuration(150)
                    .start()
            }
        }
    }


    private fun wireRowNavigation() {
        val rowOneCount = binding.rowOne.childCount
        val rowTwoCount = binding.rowTwo.childCount
        val pairCount = minOf(rowOneCount, rowTwoCount)

        for (i in 0 until pairCount) {
            val rowOneCard = binding.rowOne.getChildAt(i)
            val rowTwoCard = binding.rowTwo.getChildAt(i)
            rowOneCard.nextFocusDownId = rowTwoCard.id
            rowTwoCard.nextFocusUpId = rowOneCard.id
        }

        val firstCardId = binding.rowOne.getChildAt(0)?.id ?: View.NO_ID
        binding.homeButton.nextFocusDownId = firstCardId
        binding.navResume.nextFocusDownId = firstCardId
        binding.navSmart.nextFocusDownId = firstCardId
        binding.navLive.nextFocusDownId = firstCardId
        binding.navMovies.nextFocusDownId = firstCardId
        binding.settingsCard.nextFocusUpId = binding.rowTwo.getChildAt(0)?.id ?: View.NO_ID
    }

    private fun populateRows() {
        applySettingsToHome()
    }

    private fun makeCard(item: TitleCard, scrollView: HorizontalScrollView, verticalScroll: ScrollView, index: Int, widthDp: Int, heightDp: Int): View {
        val density = resources.displayMetrics.density
        val widthPx = (widthDp * density).toInt()
        val heightPx = (heightDp * density).toInt()
        val marginEnd = (16 * density).toInt()
        val pad = (14 * density).toInt()
        val progressHeight = 3
        val progressWidth = ((widthPx - (pad * 2)) * item.progress).toInt().coerceAtLeast((40 * density).toInt())
        val pillRadius = 34f * density

        val frame = FrameLayout(this).apply {
            id = View.generateViewId()
            layoutParams = LinearLayout.LayoutParams(widthPx, heightPx).apply { rightMargin = marginEnd }
            isFocusable = true
            isClickable = true
            foreground = null
            background = (ContextCompat.getDrawable(this@MainActivity, item.backgroundRes)?.mutate() as? GradientDrawable)?.apply {
                cornerRadius = pillRadius
            } ?: ContextCompat.getDrawable(this@MainActivity, item.backgroundRes)
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, pillRadius)
                }
            }
        }

        val posterImage = ImageView(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFF0B0F18.toInt())
        }
        loadCardArtworkInto(posterImage, item, highQuality = false)

        val overlay = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            background = (ContextCompat.getDrawable(this@MainActivity, R.drawable.card_overlay)?.mutate() as? GradientDrawable)?.apply {
                cornerRadius = pillRadius
            } ?: ContextCompat.getDrawable(this@MainActivity, R.drawable.card_overlay)
        }

        val bottomWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
            setPadding(pad, 0, pad, pad)
        }

        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }

        val title = TextView(this).apply {
            text = item.title
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 13.5f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 1
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val brand = TextView(this).apply {
            text = item.brand
            setTextColor(0xFFEFE6DA.toInt())
            textSize = 8.5f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

        val progressTrack = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (progressHeight * density).toInt()).apply {
                topMargin = (6 * density).toInt()
            }
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.pill_dark)
            alpha = 0.45f
        }

        val progressBar = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(progressWidth, (progressHeight * density).toInt(), Gravity.START or Gravity.CENTER_VERTICAL)
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.button_primary)
            alpha = 0.95f
        }

        val progressFrame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (progressHeight * density).toInt()).apply {
                topMargin = (6 * density).toInt()
            }
            addView(progressTrack)
            addView(progressBar)
        }

        val footer = TextView(this).apply {
            text = item.footer
            setTextColor(0xFFE6DCCD.toInt())
            textSize = 8.5f
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = (6 * density).toInt()
            }
        }

        brandRow.addView(title)
        brandRow.addView(brand)
        bottomWrap.addView(brandRow)
        bottomWrap.addView(progressFrame)
        bottomWrap.addView(footer)

        frame.addView(posterImage)
        frame.addView(overlay)
        frame.addView(bottomWrap)

        frame.cameraDistance = 12000f

        frame.setOnFocusChangeListener { view, hasFocus ->
            pulseAnimator(view, hasFocus)
            view.alpha = if (hasFocus) 1f else 0.96f
            view.translationZ = if (hasFocus) 10f * resources.displayMetrics.density else 0f
            frame.foreground = if (hasFocus) makeFocusRing(pillRadius) else null
            loadCardArtworkInto(posterImage, item, highQuality = hasFocus)
            if (hasFocus) {
                setHero(item)
                if (!startupFocusLocked) {
                    revealFocusedCard(scrollView, verticalScroll, view, index)
                }
            }
        }
        return frame
    }


    private fun revealFocusedCard(scrollView: HorizontalScrollView, verticalScroll: ScrollView, view: View, index: Int) {
        scrollView.post {
            val leftAnchorPx = (40f * resources.displayMetrics.density).toInt()
            val horizontalTarget = when {
                index <= 0 -> 0
                else -> (view.left - leftAnchorPx).coerceAtLeast(0)
            }
            scrollView.smoothScrollTo(horizontalTarget, 0)

            val section = when (scrollView.id) {
                binding.rowOneScroll.id -> RowSection.FIRST
                binding.rowTwoScroll.id -> RowSection.SECOND
                else -> null
            }
            if (section != null) {
                snapToRow(section, smooth = true)
            } else {
                verticalScroll.smoothScrollTo(0, view.top)
            }
        }
    }

    private fun snapToRow(section: RowSection, smooth: Boolean) {
        val density = resources.displayMetrics.density
        val rowTop = when (section) {
            RowSection.FIRST -> binding.rowOneTitle.top
            RowSection.SECOND -> binding.rowTwoTitle.top
        }
        val target = when (section) {
            RowSection.FIRST -> 0
            RowSection.SECOND -> (rowTop - (22f * density).toInt()).coerceAtLeast(0)
        }
        binding.contentScroll.post {
            if (smooth) binding.contentScroll.smoothScrollTo(0, target)
            else binding.contentScroll.scrollTo(0, target)
        }
    }

    private fun pulseAnimator(view: View, hasFocus: Boolean) {
        (view.getTag(R.id.tag_pulse_animator) as? Animator)?.cancel()
        if (hasFocus) {
            val density = resources.displayMetrics.density
            val pulse = ObjectAnimator.ofPropertyValuesHolder(
                view,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1.012f, 1.02f, 1.015f, 1.012f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1.012f, 1.02f, 1.015f, 1.012f),
                PropertyValuesHolder.ofFloat(View.TRANSLATION_Y, 0f, -0.4f * density, -0.2f * density, 0f),
                PropertyValuesHolder.ofFloat(View.ALPHA, 0.994f, 1f, 0.996f, 0.994f)
            ).apply {
                duration = 5200
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.RESTART
                start()
            }
            view.setTag(R.id.tag_pulse_animator, pulse)
        } else {
            view.animate().cancel()
            view.animate()
                .scaleX(1f)
                .scaleY(1f)
                .translationY(0f)
                .setDuration(220)
                .start()
            view.setTag(R.id.tag_pulse_animator, null)
        }
    }

    private fun makeFocusRing(radius: Float): Drawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius
            setColor(0x00000000)
            setStroke((2f * resources.displayMetrics.density).toInt(), 0xFFDCEBFF.toInt())
        }
    }

    private fun setHero(item: TitleCard) {
        loadBackdropInto(binding.heroBackdrop, item.backdropUrl, item.backgroundRes)
        binding.heroTitle.text = item.title
        binding.heroMeta.text = item.meta
        binding.heroDesc.text = item.desc
        binding.statusBadge.text = item.badge
    }


    private fun loadCardArtworkInto(imageView: ImageView, item: TitleCard, highQuality: Boolean) {
        val wideUrl = item.backdropUrl?.takeIf { it.isNotBlank() }
        val posterUrl = item.posterUrl?.takeIf { it.isNotBlank() }
        val targetUrl = wideUrl ?: posterUrl
        val usePosterFallback = wideUrl == null && posterUrl != null

        if (targetUrl == null) {
            imageView.scaleType = ImageView.ScaleType.CENTER_CROP
            imageView.setImageDrawable(safeDrawable(item.backgroundRes))
            return
        }

        val reqWidth = if (highQuality) 960 else 640
        val reqHeight = if (highQuality) 540 else 360

        imageView.scaleType = if (usePosterFallback) ImageView.ScaleType.FIT_CENTER else ImageView.ScaleType.CENTER_CROP

        val request = Glide.with(this)
            .load(targetUrl)
            .override(reqWidth, reqHeight)
            .placeholder(item.backgroundRes)
            .error(item.backgroundRes)
            .transition(DrawableTransitionOptions.withCrossFade(if (highQuality) 180 else 120))

        if (usePosterFallback) {
            request.fitCenter().into(imageView)
        } else {
            request.centerCrop().into(imageView)
        }
    }

    private fun loadBackdropInto(imageView: ImageView, url: String?, fallbackRes: Int) {
        imageView.scaleType = ImageView.ScaleType.CENTER_CROP
        if (url.isNullOrBlank()) {
            imageView.setImageDrawable(safeDrawable(fallbackRes))
            return
        }
        Glide.with(this)
            .load(url)
            .override(1280, 720)
            .placeholder(fallbackRes)
            .error(fallbackRes)
            .centerCrop()
            .transition(DrawableTransitionOptions.withCrossFade(180))
            .into(imageView)
    }

    private fun safeDrawable(resId: Int): Drawable? = ContextCompat.getDrawable(this, resId)
}
